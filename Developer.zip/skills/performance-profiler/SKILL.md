---
name: performance-profiler
version: '1.7.0'
disable-model-invocation: true
argument-hint: "<service-name> [api=/path] [env=production|acceptance|development] [concern=rvp|lib|...] [time=<window>] [traceId=<id>] [problem description]"
description: "Systematic performance profiling for slow backend services (JVM/Spring Boot, Node.js) and frontend pages (Angular, React). Covers P95/P99 latency, CPU throttling, OOM kills, heap pressure, bundle size analysis, memory leaks, GKE pod resources, and traffic pattern analysis. All data from GCP-native tooling — no secrets or test runs required.\n"
allowed-tools:
- Bash
- AskUserQuestion
- mcp__claude_ai_Maxxton_Knowledge__get_service_overview
- mcp__claude_ai_Maxxton_Knowledge__get_call_chain
- mcp__claude_ai_Maxxton_Knowledge__search_technical_graph
- mcp__claude_ai_Maxxton_Knowledge__query_openapi
- mcp__plugin_developer_github__get_file_contents
- mcp__plugin_developer_github__search_code
- mcp__plugin_developer_github__list_commits
---

# Performance Profiler

Systematic performance profiling for microservices running on GKE/GCP. Covers backend
(JVM and Node.js), frontend (Angular and React), and GCP observability. All data sourced
from Cloud Trace and Cloud Logging — no service tokens or test runs required.

---

## How to Use This Skill

Invoke with `/performance-profiler` followed by a plain-English description of the problem.

| Parameter | Example | Impact |
|---|---|---|
| **Service / repo** | `"workorder-service"` | Required |
| **API endpoint** | `PUT /api/v1/workorders/issues/batch` | Required (or ask) |
| **Environment** | `production`, `acceptance`, `development` | Required |
| **TraceId** | `abc123def456` | Skips all trace fetch steps — fastest path |
| **Concern** | `rvp`, `lib`, `fmc`, `acs` | Narrows to one concern; cuts noise |
| **Time window** | `"last night midnight–2am"`, `"today 13:00–14:00 CEST"` | Reduces results ~10× |
| **How observed** | `"Alertmanager P99 > 2s"`, `"slow only Tuesdays at midnight"` | Guides signal analysis |

**Routing by what you provide:**

| Input | What happens |
|---|---|
| `traceId` (with or without API details) | → Fetch COMPLETE on that ID, skip all scans |
| service + api + env | → Full investigation (namespace check → ROOTSPAN scan → COMPLETE) |
| service + env, no api | → Ask which endpoint to investigate before proceeding |
| Nothing useful | → Ask for service, endpoint, and environment |

---

## Core Rules

**Rule 1 — Measure Before You Fix.**
Profile → confirm the bottleneck → fix → measure again.

**Rule 2 — Stay Focused on the Named API.**
Investigate only the endpoint the user named. If other log entries appear from the same service
(different batch jobs, other endpoints, unrelated errors), skip them — they are out of scope
unless they are on the direct call path of the named endpoint.

**Rule 3 — Traces First, Logs Second.**
Get a trace ID before querying logs. Never run broad exploratory log scans — scope every log
query to a trace ID or timestamp window extracted from a trace.

**Rule 4 — Narrow Before Fetching.**
If the user gives a concern or time window, apply them to the trace query upfront.
Fetching 7 days of traces when the issue only happens at midnight is wasteful.

---

## Step 1 — Resolve Context: Environment, Concern, and Time Window

### Environment → Namespace mapping (Maxxton)

| Environment | GKE Namespace |
|---|---|
| `production` | `mxts-prod` |
| `acceptance` | `mxts-acc` |
| `development` | `mxts-dev` |

If the user says "all environments", run each step once per namespace.

### Concern codes (Maxxton)

Concern codes map to the `mxt.concern` label on every trace span (e.g. `rvp`, `lib`, `fmc`,
`acs`, `ons`, `csh`). If the user names a concern, filter all trace and log queries to that
concern — do not surface findings from other concerns.

### Time window

If the user describes when the issue occurs, convert it to UTC `startTime` / `endTime` before
querying. Examples:

| User says | UTC window to use |
|---|---|
| `"last night midnight–2am"` (CEST = UTC+2) | yesterday 22:00Z → today 00:00Z |
| `"today 13:00–14:00 CEST"` | today 11:00Z → today 12:00Z |
| `"nightly around midnight UTC"` | last 3 nights 23:30Z → 02:30Z |
| _(nothing given)_ | default to last 7 days |

A 2-hour window returns far fewer traces than 7 days — use it whenever available.

### Resolve GCP project

```powershell
gcloud config get-value project
```

Default Maxxton project: `maxxton-software`. If unset, ask the user.

---

## Step 2 — Get Service Context (Maxxton Knowledge)

```
get_service_overview(service_name)
```

Confirms tech stack, databases, and direct dependencies. Clarifies which reference file
applies and which downstream services may be the bottleneck.

For endpoint investigations, also run:

```
get_call_chain(service_name, direction=outbound, depth=4)
```

**MCP unavailable fallback:** if Maxxton Knowledge MCP is not authenticated, use
`search_code` to find the service's main class and infer tech stack from imports.

**Frontend detection:** if the service name ends in `-client`, or `get_service_overview`
confirms an Angular/React frontend, there are no backend traces — skip Steps 3–7 and
offer codebase analysis immediately (Step 9).

---

## Step 3 — Namespace Check + Find Traces

> **TraceId shortcut:** if the user provided a traceId, skip 3a and 3b entirely — jump
> directly to **3c** using that ID. No scan needed.

Span names follow the format `http <method> <path>`.
Apply concern and time window from Step 1 before running.

### 3a — Namespace existence check (one request, skip if empty)

```powershell
$token = (gcloud auth print-access-token)
$nsF = [System.Uri]::EscapeDataString('label:"service.namespace=<namespace>"')
$nsCheck = Invoke-RestMethod `
    -Uri "https://cloudtrace.googleapis.com/v1/projects/maxxton-software/traces?pageSize=1&view=ROOTSPAN&filter=$nsF" `
    -Headers @{Authorization="Bearer $token"}
if (-not $nsCheck.traces) {
    Write-Host "Namespace <namespace> has no traces — skip Steps 3–7, offer codebase analysis (Step 9)."
}
```

### 3b — Phase 1: ROOTSPAN scan (latency + labels, ~10× cheaper than COMPLETE)

```powershell
$method  = "<get|post|put|patch>"
$path    = "<endpoint path>"
$concern = "<concern code, or $null to skip>"

# Default: last 24 hours. Use user-specified window if provided.
$start = "<resolved UTC startTime>"   # e.g. (Get-Date).AddHours(-24).ToUniversalTime()...
$end   = "<resolved UTC endTime>"     # e.g. (Get-Date).ToUniversalTime()...

$filter = [System.Uri]::EscapeDataString("span:`"http $method $path`"")
$url = "https://cloudtrace.googleapis.com/v1/projects/maxxton-software/traces" +
       "?pageSize=100&view=ROOTSPAN&startTime=$start&endTime=$end&filter=$filter"

$r = Invoke-RestMethod -Uri $url -Headers @{Authorization="Bearer $token"}

$results = $r.traces | ForEach-Object {
    $s = $_.spans | Where-Object { $_.name -eq "http $method $path" }
    if (-not $s) { return }
    if ($concern -and $s.labels.'mxt.concern' -ne $concern) { return }
    $dur = [math]::Round(([datetime]::Parse($s.endTime)-[datetime]::Parse($s.startTime)).TotalMilliseconds,1)
    $params = $s.labels.'mxt.request.params'
    $page = if ($params -match 'page=(\d+)') { [int]$Matches[1] } else { $null }
    $size = if ($params -match 'size=(\d+)') { [int]$Matches[1] } else { $null }
    [PSCustomObject]@{
        TraceId    = $_.traceId
        Start      = $s.startTime
        DurationMs = $dur
        Status     = $s.labels.'mxt.status_code'
        Concern    = $s.labels.'mxt.concern'
        User       = $s.labels.'mxt.username'
        ClientId   = $s.labels.'mxt.client_id'
        Page       = $page; PageSize = $size
        Offset     = if ($page -and $size) { $page * $size } else { $null }
        Params     = $params
    }
}

Write-Host "Total traces: $($results.Count)"
$results | Sort-Object DurationMs -Descending | Select-Object -First 15 |
    Format-Table TraceId, Start, DurationMs, Status, Concern, User, Offset -AutoSize
```

### 3c — Phase 2: COMPLETE waterfall (top 1–3 slow trace IDs only)

```powershell
$slowIds = $results | Sort-Object DurationMs -Descending | Select-Object -First 3 -ExpandProperty TraceId
foreach ($id in $slowIds) {
    $t = Invoke-RestMethod `
         -Uri "https://cloudtrace.googleapis.com/v1/projects/maxxton-software/traces/$id" `
         -Headers @{Authorization="Bearer $token"}
    $t.spans | ForEach-Object {
        $dur = [math]::Round(([datetime]::Parse($_.endTime)-[datetime]::Parse($_.startTime)).TotalMilliseconds,1)
        "[$dur ms] $($_.name)  svc=$($_.labels.'service.name')  status=$($_.labels.'mxt.status_code')  exc=$($_.labels.exception)"
    }
}
```

> **Log analysis:** to fetch and interpret GCP Cloud Logging entries for a specific trace,
> use `/trace-investigate <traceId>` — it queries the Maxxton apps log scope, extracts
> errors and stack traces, and can create a Jira bug from the findings.

---

## Step 4 — Read the Traces: Automated Signal Detection

Before routing to Type A or Type B, run these four checks on `$results`. Each check either
confirms a known pattern or rules it out in one pass — no extra API calls needed.

### Signal A — Latency distribution

```powershell
$buckets = @{"<200ms"=0;"200ms–1s"=0;"1–3s"=0;"3–10s"=0;">10s"=0}
$results | ForEach-Object {
    if     ($_.DurationMs -lt 200)   { $buckets["<200ms"]++ }
    elseif ($_.DurationMs -lt 1000)  { $buckets["200ms–1s"]++ }
    elseif ($_.DurationMs -lt 3000)  { $buckets["1–3s"]++ }
    elseif ($_.DurationMs -lt 10000) { $buckets["3–10s"]++ }
    else                             { $buckets[">10s"]++ }
}
$buckets.GetEnumerator() | Sort-Object Name | ForEach-Object { "$($_.Key): $($_.Value)" }
```

**Interpret:** if >50% of calls are in a single slow bucket it is a systematic issue.
If slow calls are scattered across buckets it is intermittent — look at time-of-day next.

### Signal B — Single-caller detection

```powershell
$results | Group-Object User | Sort-Object Count -Descending |
    Select-Object -First 5 | Format-Table Name, Count -AutoSize
$results | Group-Object ClientId | Sort-Object Count -Descending |
    Select-Object -First 5 | Format-Table Name, Count -AutoSize
```

**Interpret:** if one `User` or `ClientId` owns all the slow calls, the issue is a bulk/export
client — not a real-user-facing problem. Example: a nightly `crunch` client paginating through
millions of records with `size=2000` will cause all slow traces.

### Signal C — Deep pagination detection

```powershell
$results | Where-Object { $_.Offset -gt 0 } |
    Sort-Object Offset |
    Select-Object Page, PageSize, Offset, DurationMs |
    Format-Table -AutoSize
```

**Interpret:** if `DurationMs` grows with `Offset`, the root cause is Oracle/SQL `OFFSET n ROWS`
cost — O(n) scan that discards all rows before the page. At offset >500,000 calls typically
exceed 10s. Fix: replace with keyset (cursor) pagination using `WHERE id > :lastId`.

### Signal D — Time-of-day clustering

```powershell
$results | Where-Object { $_.DurationMs -gt 3000 } | ForEach-Object {
    ([datetime]::Parse($_.Start)).ToUniversalTime().ToString("HH")
} | Group-Object | Sort-Object Name |
    ForEach-Object { "UTC $($_.Name):00 → $($_.Count) slow calls" }
```

**Interpret:** if slow calls cluster in a 1–3 hour UTC window (e.g. 00:00–02:00), a nightly
scheduler or bulk export is the trigger. Cross-reference with `mxt.username` from Signal B.
The user can narrow future queries to that window using the `time` parameter.

---

## Step 5 — Determine API Type and Route Investigation

### Type A — Synchronous API

**Signal:** multiple child spans AND `DurationMs` is the real user latency.

→ The trace waterfall **is** the investigation. Find the widest child span:
- `db:` / `mongo:` / `redis:` — data store time
- `http:` — outbound Feign call
- Many small repeated spans — N+1 query pattern
- `Spans = 1` with long duration — JDBC not instrumented; all time is in one silent DB query.
  Check slow-query logs or enable Spring JDBC tracing to get visibility.

**Other services in the waterfall:** if slow spans belong to services OTHER than the named
service, list them (service name + duration), then ask:
> "I also see latency in: [list]. Continue with [named-service], or investigate one of these?"
Wait for the user's answer — do not analyse other services without confirmation.

Skip to **Step 7** after identifying the bottleneck span.

### Type B — Async Batch API (fire-and-forget)

**Signal (Phase 1):** `DurationMs < 500ms` AND endpoint is known to return a `TaskExecution`
ID. Confirm via Phase 2 COMPLETE — async traces typically have ≤4 spans total.

→ Trace only captures the trigger handoff. Extract `taskExecId` and proceed to **Step 6**.

```powershell
$t.spans | Where-Object { $_.labels.'service.name' -eq "<service-name>" } |
    ForEach-Object { $_.labels | ConvertTo-Json }
# Look for: taskExecId, id, executionId in the labels
```

If not in labels, check the status endpoint:

```bash
curl -s -H "Authorization: Bearer $<TOKEN>" \
  "<SERVICE_HOST>/api/task-executions?status=RUNNING&type=<BATCH_TYPE>" \
  | jq '.[] | {taskExecId, status, startedAt, progress}'
```

---

## Step 6 — Async Batch Investigation

### Pre-check: Is a batch already running?

```bash
curl -s -H "Authorization: Bearer $<TOKEN>" \
  "<SERVICE_HOST>/api/task-executions?status=RUNNING&type=<BATCH_TYPE>" \
  | jq '.[] | {taskExecId, status, startedAt, progress}'
```

If one is running, **do not start another**. Attach to it using its `taskExecId`.

### Poll, stream logs, check resources

```bash
# Status
TASK_ID="<taskExecId>"
curl -s -H "Authorization: Bearer $<TOKEN>" \
  "<SERVICE_HOST>/api/task-executions/$TASK_ID" \
  | jq '{taskExecId, status, progress, startedAt, updatedAt, errorMessage}'

# Pod resources
kubectl top pods -n <namespace> --sort-by=cpu | head -10

# All execution logs (Maxxton log scope)
gcloud logging read \
  'resource.labels.container_name="<service-name>" AND
   resource.labels.namespace_name="<namespace>" AND
   jsonPayload.taskExecId="'"$TASK_ID"'"' \
  --project=maxxton-software \
  --resource-names="projects/maxxton-software/locations/global/logScopes/apps" \
  --order=asc --limit=500 \
  --format="value(timestamp,severity,jsonPayload.message,jsonPayload.step,jsonPayload.durationMs)"
```

### Batch signal table

| Signal | Root Cause |
|---|---|
| Timestamp gaps between log entries | Time lost in that step — profile it |
| `updatedAt` not advancing >5 min | Stalled — take thread dump |
| Repeated identical log lines | Retry loop — transient DB timeout or HTTP 429 |
| Pod CPU pinned at limit | Single-threaded hot loop |
| Memory climbing without plateau | Unbounded collection or heap leak |
| `hikaricp.connections.pending > 0` | Connection pool exhaustion |
| Many small DB calls per record | N+1 — batch-fetch instead |
| URL-encoded filter values in warnings | Filter parser not URL-decoding before regex match |
| TaskExecutor metric re-registered on each run | Executor created per-run instead of as singleton `@Bean` |

### Stall detection + thread dump

```bash
BEFORE=$(curl -s -H "Authorization: Bearer $<TOKEN>" \
  "<SERVICE_HOST>/api/task-executions/$TASK_ID" | jq -r '.updatedAt')
sleep 120
AFTER=$(curl -s -H "Authorization: Bearer $<TOKEN>" \
  "<SERVICE_HOST>/api/task-executions/$TASK_ID" | jq -r '.updatedAt')
echo "Before: $BEFORE  After: $AFTER"

# If identical (stalled):
POD=$(kubectl get pods -n <namespace> -l app=<service-name> \
  --field-selector=status.phase=Running -o jsonpath='{.items[0].metadata.name}')
kubectl exec -n <namespace> $POD -- jcmd 1 Thread.print \
  | grep -A4 "BLOCKED\|waiting on\|waiting to lock" | head -60
```

---

## Step 7 — Route to the Right Reference

| Symptom | Reference File |
|---|---|
| Backend API slow (Java/Spring Boot) | `references/backend-jvm.md` + `references/gcp-observability.md` |
| Backend API slow (Node.js) | `references/backend-node.md` + `references/gcp-observability.md` |
| Memory growing, OOM kills | `references/backend-jvm.md` or `references/backend-node.md` |
| Frontend page loads slowly | `references/frontend.md` |
| Traffic pattern / load analysis | `references/load-testing.md` (GCP-native — no credentials needed) |

---

## Step 8 — Codebase Investigation Gate

After completing the trace and log analysis, ask:

> "I've completed the analysis. Would you like me to check `MaxxtonGroup/<repo-name>`
> to find improvement areas in `<METHOD> <endpoint>`?"

Use `AskUserQuestion` with **Yes** / **No**.

**If Yes:** proceed to Step 9.
**If No:** present the before/after findings template and stop.

---

## Step 9 — Codebase Improvement Analysis (One at a Time)

```
search_code(repo="MaxxtonGroup/<repo-name>", query="<endpoint path>")
get_file_contents(repo="MaxxtonGroup/<repo-name>", path="<controller file>")
```

**Workflow:** find one highest-impact improvement → present it with file + line → ask "next?" → repeat only if yes.

**Priority order:**
1. Offset pagination where keyset/cursor pagination should be used
2. N+1 query or missing `@Transactional` boundary
3. URL-encoded filter values not decoded before regex match
4. `TaskExecutor` created per-run instead of injected singleton `@Bean`
5. Missing DB index (inferred from query patterns)
6. Synchronous Feign call that could be async or cached
7. Missing `@Cacheable` on an expensive read
8. Single-threaded batch processing that could use `TaskExecutor` partitioning

---

## Step 10 — Document Before/After

```markdown
## Performance Investigation: [What Was Fixed]

**Date:** YYYY-MM-DD  **Service:** [service]  **Environment:** [env]
**Endpoint:** [METHOD /api/path]  **Concern:** [concern code or "all"]
**Ticket:** [ticket ID]

### Symptom
[P95 latency / batch duration / OOM / deep pagination, etc.]

### Root Cause
[What trace analysis or code review revealed]

### Baseline (Before)
| Metric | Value |
|--------|-------|
| P95 latency | |
| Batch duration | |
| Deepest offset | |

### Fix Applied
[What changed]

### After
| Metric | Before | After | Δ |
|--------|--------|-------|---|
| P95 latency | | | |
| Batch duration | | | |

### Verification
[Load test output or Grafana link]
```

---

## Common Pitfalls

- **Skipping the namespace existence check** — always do a `pageSize=1&view=ROOTSPAN` preflight; two round-trips against an empty namespace are avoidable.
- **Using view=COMPLETE for the initial scan** — use `view=ROOTSPAN` (Phase 1) to identify slow trace IDs first; only switch to `view=COMPLETE` for 1–3 specific IDs in Phase 2 (~10× cheaper).
- **Running trace steps against a frontend repo** — service names ending in `-client` have no backend traces; skip to Step 9 immediately.
- **Not applying concern or time window before fetching** — always scope the query; fetching 7 days when the issue is a 2-hour nightly window wastes tokens and returns noise.
- **Reporting findings from other endpoints or batch jobs** — if not on the call path of the named API, it is out of scope.
- **Treating a fire-and-forget API as synchronous** — ≤4 spans + fast response = async; follow `taskExecId`.
- **Attributing user-facing slowness to a bulk client** — check `mxt.username` across slow traces first; a single automated caller (e.g. `crunch`) paginating millions of rows can saturate the DB without affecting real users.
- **Starting a second batch run without checking if one is active** — causes contention and duplicate writes.
- **One change at a time** — isolate variables so you know what actually caused the improvement.
