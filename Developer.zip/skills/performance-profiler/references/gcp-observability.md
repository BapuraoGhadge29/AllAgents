# GCP Observability: Logs, Traces, Metrics, and Profiler

Use this reference to investigate performance using GCP Cloud Logging, Cloud Trace, Cloud Profiler, Prometheus/Grafana, and GKE tooling. This is the right starting point when you have a symptom (slow endpoint, spiking error rate, pod restarts) but don't yet know the root cause.

---

## Step 1: Identify the Affected Service and Time Window

```bash
# Confirm which project you're working in
gcloud config get-value project

# List namespaces and find your service
kubectl get pods -A | grep <service-name>

# Get the exact pod name and check basic health
kubectl describe pod <pod-name> -n <namespace> | tail -30
```

---

## GCP Cloud Trace — Trace Slow Requests

Cloud Trace shows the full request lifecycle with timing for each span (DB calls, external HTTP, internal service calls). This is the fastest way to understand *where time is being spent*.

```bash
# List recent traces for a service that were slow (>500ms)
gcloud trace list \
  --project=<GCP_PROJECT_ID> \
  --filter="displayName:<your-endpoint-path> AND latency>500ms" \
  --limit=20 \
  --format="table(traceId, displayName, startTime, latency)"

# Get the full detail of a specific trace
gcloud trace describe <TRACE_ID> --project=<GCP_PROJECT_ID>

# Or: open GCP Console → Cloud Trace → Trace List
# Filter by latency > Xms, your service name
# The waterfall view shows every span — click the widest ones to find the bottleneck
```

**Reading a trace waterfall:**
- The longest span is your primary bottleneck
- Spans labelled `db:` or `mongo:` or `redis:` indicate data store time
- `http:` spans indicate outbound calls to other services or external APIs
- Many small repeated spans = N+1 query pattern
- A single very long span in your own service code = CPU-bound work or a blocking synchronous call

---

## GCP Cloud Logging — Slow Queries and Errors

All application logs and infrastructure logs are in Cloud Logging. Query them to find slow queries, exceptions, and error patterns.

```bash
# Find slow query log entries for a service (last 1 hour)
gcloud logging read \
  'resource.type="k8s_container" AND
   resource.labels.namespace_name="<namespace>" AND
   resource.labels.container_name="<service-name>" AND
   jsonPayload.message=~"slow query|slow_query|SlowQuery|execution time" AND
   timestamp>="'$(date -u -d '1 hour ago' +%Y-%m-%dT%H:%M:%SZ)'"' \
  --project=<GCP_PROJECT_ID> \
  --limit=50 \
  --format="table(timestamp, jsonPayload.message)"

# Find errors / exceptions in a service
gcloud logging read \
  'resource.type="k8s_container" AND
   resource.labels.namespace_name="<namespace>" AND
   resource.labels.container_name="<service-name>" AND
   severity>=ERROR AND
   timestamp>="'$(date -u -d '1 hour ago' +%Y-%m-%dT%H:%M:%SZ)'"' \
  --project=<GCP_PROJECT_ID> \
  --limit=50

# Find HTTP 5xx errors with their trace IDs
gcloud logging read \
  'resource.type="k8s_container" AND
   resource.labels.container_name="<service-name>" AND
   httpRequest.status>=500 AND
   timestamp>="'$(date -u -d '1 hour ago' +%Y-%m-%dT%H:%M:%SZ)'"' \
  --project=<GCP_PROJECT_ID> \
  --limit=20 \
  --format="json" | jq '.[].trace'

# Get all log entries for a specific trace ID (full request reconstruction)
gcloud logging read \
  'trace="projects/<GCP_PROJECT_ID>/traces/<TRACE_ID>"' \
  --project=<GCP_PROJECT_ID> \
  --format="table(timestamp, severity, jsonPayload.message)"
```

**Tip:** Use the GCP Console Logs Explorer for interactive investigation — it lets you search with autocomplete, pivot by field, and see structured log payloads. Use the CLI for scripting and automation.

---

## GCP Cloud Profiler — Continuous Profiling

Cloud Profiler collects CPU and heap profiles continuously from running services. No performance overhead, no restarts needed.

```bash
# List available profiles (shows services that have the profiler agent attached)
gcloud profiler profiles list \
  --project=<GCP_PROJECT_ID> \
  --service=<SERVICE_NAME> \
  --start-time=$(date -u -d '24 hours ago' +%Y-%m-%dT%H:%M:%SZ) \
  --format="table(name, startTime, profileType, duration)"

# Download a CPU profile for offline flamegraph analysis
gcloud profiler profiles export \
  --project=<GCP_PROJECT_ID> \
  --profile=<PROFILE_NAME> \
  --output=./cpu-profile.pb.gz

# The easiest way: GCP Console → Cloud Profiler → select service → flame chart appears
# Filter by time range, profile type (CPU/HEAP/GOROUTINE), and version
```

**Check if profiler is attached to your pods:**
```bash
# For Java services: look for the agent in JVM args
kubectl exec <pod-name> -n <namespace> -- \
  ps aux | grep java | grep -o '\-agentpath:[^ ]*'

# Or check for the env var
kubectl describe pod <pod-name> -n <namespace> | grep -i "GOOGLE_CLOUD_PROFILER\|profiler"
```

---

## Prometheus / Grafana — Metrics and Alerts

Prometheus metrics give you quantitative trends over time. Use these queries in Grafana or via the Prometheus console.

```promql
# HTTP request latency percentiles (Spring Boot / Micrometer)
# P95 latency for a specific endpoint over the last 5 minutes
histogram_quantile(0.95,
  rate(http_server_requests_seconds_bucket{
    application="<service-name>",
    uri="/api/your-endpoint"
  }[5m])
) * 1000  -- multiply by 1000 to get milliseconds

# Error rate (5xx responses as a fraction of total)
sum(rate(http_server_requests_seconds_count{
  application="<service-name>", status=~"5.."
}[5m]))
/
sum(rate(http_server_requests_seconds_count{
  application="<service-name>"
}[5m]))

# JVM heap usage over time
jvm_memory_used_bytes{application="<service-name>", area="heap"}
/ jvm_memory_max_bytes{application="<service-name>", area="heap"}
* 100  -- percentage

# Thread pool active threads (Spring @Async, executor)
executor_active_threads{application="<service-name>"}

# Node.js event loop lag (if prom-client is configured)
nodejs_eventloop_lag_seconds{service="<service-name>"} * 1000

# CPU throttling on a pod (high values = pod is hitting its CPU limit)
rate(container_cpu_cfs_throttled_seconds_total{
  namespace="<namespace>",
  pod=~"<service-name>.*"
}[5m])
/
rate(container_cpu_cfs_periods_total{
  namespace="<namespace>",
  pod=~"<service-name>.*"
}[5m])
```

```bash
# Quick Prometheus query from CLI (if port-forwarded)
kubectl port-forward svc/prometheus-operated 9090:9090 -n monitoring

# Then in another terminal:
curl -s "http://localhost:9090/api/v1/query?query=http_server_requests_seconds_count" | jq '.data.result[0]'
```

---

## GKE Pod / Node Resource Investigation

```bash
# See CPU and memory usage for all pods in a namespace
kubectl top pods -n <namespace> --sort-by=cpu

# See node-level resource usage (are nodes near capacity?)
kubectl top nodes

# Check pod resource limits and requests
kubectl describe pod <pod-name> -n <namespace> | grep -A6 "Limits\|Requests"

# Check if pods are CPU throttled (containers hitting their limits)
# High CPU throttling means the pod needs a higher CPU limit, or the code needs optimisation
kubectl get --raw "/apis/metrics.k8s.io/v1beta1/namespaces/<namespace>/pods/<pod-name>" | jq .

# Check HPA (Horizontal Pod Autoscaler) status — is it scaling correctly?
kubectl get hpa -n <namespace>
kubectl describe hpa <hpa-name> -n <namespace>
# Look for: "ScalingActive: True" and current vs desired replicas

# Check pod events for recent issues
kubectl get events -n <namespace> --sort-by='.lastTimestamp' | grep <service-name> | tail -20
```

---

## Putting It Together: Investigation Flow

When you have a symptom but not a root cause, follow this sequence:

```
1. kubectl top pods         → Is a specific pod consuming disproportionate CPU/memory?
2. kubectl get events       → Any OOMKills, pod restarts, scheduling failures?
3. gcloud trace list        → Which requests are slow? What span is widest?
4. gcloud logging read      → Are there errors, exceptions, or slow query log lines?
5. Cloud Profiler           → Where is CPU time actually going in the code?
6. Prometheus (Grafana)     → Is this new (a recent deploy) or gradually worsening?
```

The trace tells you *what* operation is slow. The profiler tells you *why* in the code. The logs give you clues about external factors (DB, external services). The metrics tell you about trends over time.
