# Backend Node.js Profiling

Use this reference when a Node.js service is slow, consuming too much CPU, growing in memory, or blocking the event loop.

---

## Option A: clinic.js (Best for Local / Staging Dev)

clinic.js gives flamegraphs, heap profiles, and event loop diagnostics with a single command.

```bash
# Install globally
npm install -g clinic autocannon

# CPU flamegraph — run your service through clinic, hit it with load, then Ctrl+C
clinic flame -- node dist/server.js
# While it's running in another terminal:
autocannon -c 50 -d 30 http://localhost:8000/api/your-endpoint
# A flamegraph HTML opens automatically in your browser

# Heap profiler — find what's allocating memory
clinic heapprofiler -- node dist/server.js
# Run some load, then Ctrl+C — opens a flame chart of heap allocations

# Bubble chart — detect event loop blocking (sync operations on the main thread)
clinic bubbles -- node dist/server.js
# Large bubbles = event loop was blocked for that duration
```

**Reading the CPU flamegraph:**
- Wide bars at the top = hot code paths
- Look for your own module paths (e.g., `src/services/`, `src/routes/`) in the wide bars
- `JSON.parse` / `JSON.stringify` appearing wide = large payload serialisation overhead
- `crypto` or `bcrypt` in the hot path = expensive sync crypto (move to async or cache results)

**Reading the bubble chart:**
- Large or clustered bubbles = event loop is blocked by synchronous work
- Common culprits: `fs.readFileSync`, `JSON.parse` of large objects, synchronous regex on large strings

---

## Option B: Node.js Built-in Profiler (Zero Dependencies)

Works in any environment, no extra tools needed.

```bash
# Run with profiling enabled
node --prof dist/server.js

# Hit the service with some load (in another terminal)
autocannon -c 20 -d 20 http://localhost:8000/api/your-endpoint

# Stop the server (Ctrl+C). A file named isolate-*.log is created.
# Process it into a human-readable report
node --prof-process isolate-*.log > profile-report.txt

# Read the report — look for the "Bottom up (heavy) profile" section
# The [JavaScript] section shows your code's hot functions
head -100 profile-report.txt
```

---

## Option C: Node.js Inspector (Chrome DevTools)

Best for interactive investigation directly from Chrome DevTools.

```bash
# Start server with inspector
node --inspect dist/server.js
# or for a pod: kubectl port-forward <pod> 9229:9229 -n <namespace>

# Open Chrome → chrome://inspect → Click "inspect" under your Node process
# Go to Performance tab → Record → run some requests → Stop
# Flamegraph appears showing CPU time breakdown
```

---

## Heap Snapshot / Memory Leak Detection

When Node.js memory is growing over time and not being released after GC:

```bash
# Add a debug endpoint to your server (protect with auth / internal-only routing)
# In your Express/Fastify app:
```

```javascript
// Add to server (dev/staging only — protect this endpoint)
import v8 from 'v8'

app.post('/internal/heap-snapshot', (req, res) => {
  const filename = `/tmp/heap-${Date.now()}.heapsnapshot`
  v8.writeHeapSnapshot(filename)
  res.json({ filename })
})
```

```bash
# Port-forward to the pod
kubectl port-forward <pod-name> 3000:3000 -n <namespace>

# Take a snapshot before load
curl -X POST http://localhost:8000/internal/heap-snapshot

# Run load for 5 minutes
autocannon -c 50 -d 300 http://localhost:8000/api/your-endpoint

# Take a second snapshot
curl -X POST http://localhost:8000/internal/heap-snapshot

# Copy both snapshots out
kubectl cp <namespace>/<pod-name>:/tmp/heap-<timestamp1>.heapsnapshot ./heap-before.heapsnapshot
kubectl cp <namespace>/<pod-name>:/tmp/heap-<timestamp2>.heapsnapshot ./heap-after.heapsnapshot

# Open Chrome DevTools → Memory tab → Load both snapshots → "Comparison" view
# Sort by "Size Delta" descending — the top entries are your leak suspects
```

**Common Node.js memory leak causes:**
- Event listeners added but never removed (`emitter.on()` inside a function called repeatedly)
- Caches (Maps, plain objects) that grow without eviction logic
- Closures capturing large objects unintentionally
- `setInterval` / `setTimeout` callbacks referencing large data structures
- Database connection pools not being released on error paths

---

## Detect Event Loop Blocking in Production

```bash
# Install blocked-at
npm install blocked-at

# Add to server startup (remove before prod, or guard with a flag)
import blocked from 'blocked-at'

blocked((time, stack) => {
  console.warn(`[PERF] Event loop blocked for ${time}ms`)
  console.warn(stack.join('\n'))
}, { threshold: 50 }) // alert if blocked > 50ms
```

You can also check event loop lag via Prometheus if `prom-client` is configured:
```
# In Grafana / promtool:
nodejs_eventloop_lag_seconds{service="your-service"} * 1000
# If this is > 50ms consistently, the event loop is under pressure
```

---

## Quick Wins Checklist

```
□ Are there sync file I/O calls (fs.readFileSync) in hot paths?
□ Is JSON.parse/stringify being called on large objects per request?
□ Are heavy computations (regex, crypto, compression) running synchronously?
□ Are DB/HTTP calls awaited in series when they could be Promise.all'd?
□ Is a module being require()'d inside a request handler instead of at startup?
□ Are event listeners accumulating (emitter.listenerCount() growing)?
□ Is the Node.js heap limit set appropriately? (--max-old-space-size)
   Recommended: ~75% of pod memory limit
□ Is connection pooling configured for DB clients? (not creating new connections per request)
```
