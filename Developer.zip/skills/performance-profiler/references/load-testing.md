# Traffic Pattern Analysis (GCP-native)

Use this reference to understand traffic volume, latency distribution, and resource
pressure from GCP data — no credentials, test runs, or external tools required.

---

## Latency percentiles from Cloud Trace

The ROOTSPAN scan in Step 3b already captures latency for recent requests.
Compute P50/P95/P99 directly from `$results`:

```powershell
$sorted = $results | Sort-Object DurationMs
$n = $sorted.Count
if ($n -gt 0) {
    $p50 = $sorted[[math]::Floor($n * 0.50)].DurationMs
    $p95 = $sorted[[math]::Floor($n * 0.95)].DurationMs
    $p99 = $sorted[[math]::Floor($n * 0.99)].DurationMs
    "P50: ${p50}ms  P95: ${p95}ms  P99: ${p99}ms  (n=$n traces)"
}
```

---

## Request volume per hour

```powershell
$results | ForEach-Object {
    ([datetime]::Parse($_.Start)).ToUniversalTime().ToString("yyyy-MM-dd HH")
} | Group-Object | Sort-Object Name |
    ForEach-Object { "$($_.Name):00 UTC → $($_.Count) requests" }
```

**Interpret:** a spike in one hour that correlates with high latency points to a traffic
burst or scheduled batch job as the trigger.

---

## Error rate from traces

```powershell
$total = $results.Count
$errors = ($results | Where-Object { $_.Status -ge 500 }).Count
if ($total -gt 0) { "Error rate: $([math]::Round($errors / $total * 100, 1))% ($errors/$total)" }
```

---

## GKE pod resource usage

```bash
# CPU and memory per pod
kubectl top pods -n <namespace> -l app=<service-name> --sort-by=cpu

# Node-level pressure
kubectl top nodes
```

Correlate resource spikes with the high-latency time window from Signal D (Step 4).

---

## Cloud Monitoring request metrics (read-only, no token needed)

```bash
# List available metrics for the service
gcloud monitoring metrics list \
  --filter="metric.labels.service_name=<service-name>" \
  --project=maxxton-software \
  --format="value(type)" | head -20
```

Use `gcloud monitoring read` to pull specific metrics (request count, latency) for the
time window identified in Step 1. No service credentials are required — only GCP project
access via `gcloud auth`.

---

## Interpreting before/after

Compare two ROOTSPAN scans (same endpoint, same time-of-day window):
- Run Step 3b **before** applying a fix → record P95, P99, request count
- Deploy the fix
- Run Step 3b again with the same window → compare

This uses real production/acceptance traffic as the load source — no synthetic test needed.
