# Frontend Performance Profiling (Angular & React)

Use this reference when a frontend application loads slowly, has a large bundle, or scores poorly on Core Web Vitals.

---

## Part 1: Bundle Size Analysis

Bundle bloat is the most common frontend performance issue — a large bundle means longer download and parse time for every user.

### Angular Bundle Analysis

```bash
# Step 1: Build with stats output
ng build --stats-json
# This creates dist/<app-name>/stats.json (Angular 12+)
# For older versions: ng build --prod --stats-json

# Step 2: Analyse the bundle
npx webpack-bundle-analyzer dist/<app-name>/stats.json

# A treemap opens in your browser showing every module and its size.
# What to look for:
# - Unexpectedly large dependencies (moment.js, lodash, chart libraries)
# - The same package appearing multiple times (duplicate versions)
# - Lazy-loaded chunks that are larger than ~200kB parsed
```

```bash
# Quick CLI size check — see all chunks and their sizes
ng build 2>&1 | grep -E "^\s+(Initial|Lazy)" | sort -k3 -rh
# Or check the dist folder directly
ls -lh dist/<app-name>/*.js | sort -k5 -rh | head -20

# Check your budget — Angular CLI enforces size budgets in angular.json
# Look for "budgets" in angular.json:
cat angular.json | grep -A10 '"budgets"'
# If your initial bundle exceeds the budget, the build will warn/error
```

### React / Next.js Bundle Analysis

```bash
# Install the analyzer
npm install --save-dev @next/bundle-analyzer
# or for Create React App:
npm install --save-dev source-map-explorer

# Next.js: add to next.config.js
const withBundleAnalyzer = require('@next/bundle-analyzer')({
  enabled: process.env.ANALYZE === 'true',
})
module.exports = withBundleAnalyzer({})

# Run the analyzer
ANALYZE=true npm run build
# Opens a treemap in the browser

# For Create React App:
npm run build
npx source-map-explorer 'build/static/js/*.js'
```

---

## Part 2: Common Bundle Wins

These substitutions consistently reduce bundle size significantly:

```javascript
// ❌ moment.js (67kB gzipped) — avoid
import moment from 'moment'
// ✅ date-fns (import only what you need, tree-shaken)
import { format, differenceInDays } from 'date-fns'
// ✅ or dayjs (7kB gzipped)
import dayjs from 'dayjs'

// ❌ lodash full import (71kB)
import _ from 'lodash'
// ✅ specific function import (2-3kB per function)
import debounce from 'lodash/debounce'
import groupBy from 'lodash/groupBy'

// ❌ Static import of heavy components (always in main bundle)
import HeavyCalendar from './HeavyCalendar'
// ✅ Lazy/dynamic import (loaded on demand, split into its own chunk)
// Angular:
const routes = [{ path: 'calendar', loadChildren: () => import('./calendar/calendar.module').then(m => m.CalendarModule) }]
// React:
const HeavyCalendar = React.lazy(() => import('./HeavyCalendar'))
```

```bash
# Check for duplicate packages (two versions of the same library)
# npm:
npm dedupe --dry-run
npx npm-check-duplicates

# Check what's actually contributing to bundle size
# Visit bundlephobia.com and search for your largest dependencies
# It shows gzipped size, download time on 3G, and suggests alternatives
```

---

## Part 3: Runtime Performance (Angular Change Detection)

Bundle size aside, Angular apps can be slow at runtime due to excessive change detection cycles.

```bash
# Enable Angular DevTools in Chrome (install the extension)
# Go to the Profiler tab → Record → interact with the slow component → Stop
# Look for:
# - Components with high "Check duration" (ms per change detection cycle)
# - Components that are being checked far more often than expected
```

```typescript
// The most impactful runtime optimisation is OnPush change detection
// Change components that are "dumb" (input-driven) to OnPush:
@Component({
  selector: 'app-booking-card',
  changeDetection: ChangeDetectionStrategy.OnPush, // ← add this
  template: `...`
})
export class BookingCardComponent {
  @Input() booking: Booking
}

// OnPush means the component only re-renders when:
// 1. An @Input() reference changes
// 2. An event fires from within the component
// 3. An async pipe emits a new value
// This can reduce change detection cycles by 80-90% on list-heavy views
```

```typescript
// Use trackBy on *ngFor to prevent DOM re-creation on list updates
// ❌ Without trackBy — recreates all DOM nodes when the array changes
<div *ngFor="let booking of bookings">

// ✅ With trackBy — only updates the changed nodes
<div *ngFor="let booking of bookings; trackBy: trackByBookingId">

trackByBookingId(index: number, booking: Booking): string {
  return booking.id
}
```

---

## Part 4: Core Web Vitals / Lighthouse

Core Web Vitals measure real user experience. Run Lighthouse from the CLI for a reproducible score.

```bash
# Install Lighthouse CLI
npm install -g lighthouse

# Run against staging (authenticated pages need --extra-headers)
lighthouse https://staging.your-app.com \
  --output=html \
  --output-path=./lighthouse-report.html \
  --form-factor=desktop \
  --throttling-method=simulate \
  --only-categories=performance

# Open the report
open lighthouse-report.html

# For mobile simulation (stricter — closer to real user conditions):
lighthouse https://staging.your-app.com \
  --output=html \
  --output-path=./lighthouse-mobile.html \
  --form-factor=mobile
```

**Key metrics to focus on:**

| Metric | What It Measures | Good Target |
|--------|-----------------|-------------|
| LCP (Largest Contentful Paint) | How fast the main content appears | < 2.5s |
| FID / INP (Interaction to Next Paint) | How quickly the page responds to user input | < 200ms |
| CLS (Cumulative Layout Shift) | How much the page layout jumps around | < 0.1 |
| TBT (Total Blocking Time) | How long the main thread is blocked | < 200ms |

**Most common causes of poor Lighthouse scores:**
- Large unoptimised images (use WebP, set explicit width/height, lazy-load below-fold images)
- Render-blocking JavaScript (defer non-critical scripts)
- Large initial bundle (lazy load routes/features)
- No caching headers on static assets
- Fonts blocking render (use `font-display: swap`)

---

## Quick Wins Checklist

```
□ Are images using WebP format and properly sized (not 2000px images displayed at 200px)?
□ Are images below the fold using loading="lazy"?
□ Are heavy routes/features lazy-loaded (not in the main bundle)?
□ Is moment.js or lodash (full) included? Replace with lighter alternatives.
□ Are Angular components using OnPush where appropriate?
□ Are *ngFor lists using trackBy?
□ Are HTTP calls being deduplicated/cached (shareReplay in RxJS)?
□ Are fonts using font-display: swap?
□ Are static assets served with long Cache-Control max-age headers?
□ Is gzip/brotli compression enabled on the server/CDN?
```
