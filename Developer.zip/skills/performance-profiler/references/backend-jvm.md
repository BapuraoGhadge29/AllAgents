# Backend JVM Profiling (Java / Spring Boot)

Use this reference when a Java or Spring Boot service is slow, consuming too much CPU, growing in memory, or being OOM-killed.

---

## Option A: GCP Cloud Profiler (Recommended First Step)

GCP Cloud Profiler collects continuous CPU and heap profiles from running services with near-zero overhead. If the service is already instrumented (most GKE-deployed services are), you don't need to redeploy anything — just query what's already collected.

```bash
# List available profiles for a service (last 24 hours)
gcloud profiler profiles list \
  --project=<GCP_PROJECT_ID> \
  --service=<SERVICE_NAME> \
  --start-time=$(date -u -d '24 hours ago' +%Y-%m-%dT%H:%M:%SZ) \
  --format="table(name, startTime, profileType, duration)"

# Download a specific CPU profile for offline analysis
gcloud profiler profiles export \
  --project=<GCP_PROJECT_ID> \
  --profile=<PROFILE_NAME> \
  --output=profile.pb.gz

# Alternatively, open GCP Console → Cloud Profiler → select your service
# This gives a flamegraph UI directly in the browser
```

**Reading the flamegraph:**
- Wide bars = hot code paths spending the most CPU time
- Look for your service's own packages near the top of wide stacks
- Ignore JVM internals (java.*, sun.*) unless they're unusually wide
- Spring framework methods (org.springframework.*) in a wide bar usually mean serialization or reflection overhead

```bash
# Check if Cloud Profiler agent is already attached to your pods
kubectl describe deployment <deployment-name> -n <namespace> | grep -i profiler
# Look for: -agentpath:/opt/cprof/profiler_java_agent.so
# or the env var: GOOGLE_CLOUD_PROFILER_ENABLED=true
```

If the agent isn't attached, add it to your deployment. See the Cloud Profiler Java setup docs — it's a one-line JVM flag addition to your Helm chart values.

---

## Option B: async-profiler (On-Demand, Low Overhead)

async-profiler is the best tool for a targeted investigation of a specific pod — it can profile a running JVM process without restarting it.

```bash
# Copy async-profiler into the running pod (download first if not available)
# https://github.com/async-profiler/async-profiler/releases
kubectl cp async-profiler.tar.gz <namespace>/<pod-name>:/tmp/

# Exec into the pod
kubectl exec -it <pod-name> -n <namespace> -- /bin/bash

# Inside the pod — find the JVM PID
jps -l

# Run a 60-second CPU profile, output as flamegraph HTML
./profiler.sh -d 60 -f /tmp/cpu-flame.html <PID>

# Run a 60-second allocation (memory) profile
./profiler.sh -e alloc -d 60 -f /tmp/alloc-flame.html <PID>

# Exit and copy the flamegraph out
exit
kubectl cp <namespace>/<pod-name>:/tmp/cpu-flame.html ./cpu-flame.html
# Open cpu-flame.html in your browser
```

**What to look for in the CPU flamegraph:**
- Your business logic methods (e.g., `BookingService.calculateAvailability`) spending disproportionate time
- Database/ORM calls (Hibernate `Session.get`, MongoDB codec serialisation) that are unexpectedly wide
- JSON serialisation (`ObjectMapper.writeValue`) — often a hidden bottleneck on large response payloads
- Thread pool exhaustion — if `ThreadPoolExecutor.execute` is wide and shows `wait` states

**What to look for in the allocation flamegraph:**
- Objects being created at a high rate in hot paths (unnecessary `new ArrayList<>()` inside loops)
- Large objects being serialised and deserialised on every request

---

## Option C: Java Flight Recorder (JFR) — Production Safe

JFR is built into the JVM (Java 11+) and has extremely low overhead. Good for longer recordings.

```bash
# Attach to a running JVM in a pod
kubectl exec -it <pod-name> -n <namespace> -- /bin/bash

# Start a 2-minute JFR recording
jcmd <PID> JFR.start duration=120s filename=/tmp/recording.jfr settings=profile

# Wait 2 minutes, then download
exit
kubectl cp <namespace>/<pod-name>:/tmp/recording.jfr ./recording.jfr

# Open in JDK Mission Control (JMC) on your local machine
# Download JMC: https://adoptopenjdk.net/jmc
# File → Open → recording.jfr → Method Profiling, GC, Thread tabs
```

**Key JFR views:**
- **Method Profiling** → same as flamegraph, shows hottest methods
- **GC** → GC pause times and frequency. If GC is pausing >100ms frequently, you likely have a memory/allocation issue
- **Threads** → blocked threads, lock contention. Wide "BLOCKED" states = thread contention

---

## Memory Leak / OOM Investigation

When pods are being OOM-killed or heap is growing over time:

```bash
# Check if pods are being OOM-killed
kubectl describe pod <pod-name> -n <namespace> | grep -A5 "OOMKilled\|Last State"

# Check memory limits vs actual usage
kubectl top pods -n <namespace> | grep <service-name>

# Get a heap dump from a running pod (WARNING: causes a pause — do on a non-prod replica)
kubectl exec -it <pod-name> -n <namespace> -- \
  jcmd <PID> VM.heap_dump /tmp/heapdump.hprof

kubectl cp <namespace>/<pod-name>:/tmp/heapdump.hprof ./heapdump.hprof
# Analyse with Eclipse MAT (Memory Analyzer Tool) or VisualVM
# Look for: Leak Suspects, Dominator Tree (largest object trees)
```

**Common JVM memory leak causes:**
- Static collections accumulating data (`static Map<>` used as a cache without eviction)
- Unclosed resources (JDBC connections, HTTP clients) leaking into finalizer queue
- ThreadLocal variables not cleaned up in thread pools
- Event listener registrations that are never removed
- Large Hibernate/JPA second-level cache with no size limit

---

## Spring Boot Actuator Metrics (Quick Health Check)

If Spring Boot Actuator is enabled (most services have it), you get free metrics without any profiling:

```bash
# Port-forward to the pod's actuator port (usually 8080 or 8081)
kubectl port-forward <pod-name> 8081:8081 -n <namespace>

# Check JVM memory pools
curl -s http://localhost:8081/actuator/metrics/jvm.memory.used | jq .

# Check active HTTP requests and response times
curl -s http://localhost:8081/actuator/metrics/http.server.requests | jq .

# Check thread pool state
curl -s http://localhost:8081/actuator/metrics/executor.active | jq .

# Check DB connection pool (HikariCP)
curl -s http://localhost:8081/actuator/metrics/hikaricp.connections.active | jq .
curl -s http://localhost:8081/actuator/metrics/hikaricp.connections.pending | jq .
```

A high `hikaricp.connections.pending` value means your service is waiting for DB connections — the bottleneck is connection pool exhaustion, not query speed.

---

## Quick Wins Checklist (Check These Before Deep Profiling)

```
□ Is there a missing index? Check GCP Logs for slow query log entries
□ Is the connection pool undersized? (hikaricp.connections.pending > 0)
□ Are N+1 queries happening? (many fast small DB calls per request)
□ Is there synchronous I/O on a reactive/async thread? 
□ Is JSON serialization of large objects happening on every request?
□ Is a @Cacheable annotation missing on an expensive read?
□ Is the JVM heap sized correctly for the pod's memory limit?
   (heap should be ~75% of pod memory limit, set via -Xmx)
□ Is GC running too frequently? (check GC pause time in JFR or Cloud Profiler)
```
