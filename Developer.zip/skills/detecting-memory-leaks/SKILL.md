---
name: detecting-memory-leaks
disable-model-invocation: true
argument-hint: "<service-name> [env=production|acceptance|development] [pod=<pod-name>]"
description: "Detects JVM memory leaks in Maxxton Spring Boot services on GKE. Tracks heap growth trends, captures heap dumps via jcmd, and identifies leak root causes using Eclipse MAT patterns. Use when heap memory grows over time, GC frequency increases, or pods are approaching their memory limit before being OOM-killed.\n"
allowed-tools:
- Bash
- Read
- Edit
- AskUserQuestion
- mcp__claude_ai_Maxxton_Knowledge__get_service_overview
- mcp__claude_ai_GitHub__get_file_contents
- mcp__claude_ai_GitHub__search_code
---

# Memory Leak Detector

Systematic memory leak investigation for JVM/Spring Boot services on Maxxton GKE. Tracks
heap growth via Spring Boot Actuator and Prometheus, captures heap dumps with `jcmd`, and
maps findings to common Spring/Hibernate leak patterns. All steps are read-only except heap
dump capture, which causes a brief GC pause — always target a non-primary replica.

---

## How to Use This Skill

Invoke with `/detecting-memory-leaks <service-name>` and optionally pass `env` and `pod`.

| Parameter | Example | Notes |
|---|---|---|
| **service** | `reservation-service` | Required |
| **env** | `production`, `acceptance`, `development` | Required |
| **pod** | `reservation-service-abc12-xyz` | Optional — targets a specific pod for heap dump |

**If pods are already being OOM-killed,** start with `/diagnosing-oom-kills` — it routes here
once it confirms a leak is the cause.

---

## Step 1 — Resolve Context

### Environment → Namespace

| Environment | GKE Namespace |
|---|---|
| `production` | `mxts-prod` |
| `acceptance` | `mxts-acc` |
| `development` | `mxts-dev` |

### Confirm tech stack

```
get_service_overview(service_name)
```

Confirms the service runs JVM/Spring Boot. If it is a Node.js service, this skill does
not apply — the Node.js heap snapshot workflow differs significantly.

```powershell
gcloud config get-value project  # should be: maxxton-software
```

---

## Step 2 — Check Current Memory State

```powershell
$ns  = "<namespace>"
$svc = "<service-name>"

# Pod memory usage vs limits
kubectl top pods -n $ns | Select-String $svc

# Memory limits and requests from the deployment
kubectl describe deployment $svc -n $ns | Select-String -Pattern "memory" -Context 0,2

# Recent pod events — look for OOMKilled or Evicted
kubectl get events -n $ns --sort-by='.lastTimestamp' | Select-String $svc | Select-Object -Last 20
```

**Interpret:**
- Memory usage > 80% of limit → leak or undersized limit; continue investigation
- Repeated `OOMKilled` events → use `/diagnosing-oom-kills` if not already there
- Memory stable below 60% with no growth trend → no active leak; baseline is normal

### Spring Boot Actuator — JVM memory pools

```powershell
$pod = "<pod-name>"
kubectl port-forward $pod 8081:8081 -n $ns &
Start-Sleep 2

# JVM heap used vs max
curl -s http://localhost:8081/actuator/metrics/jvm.memory.used | ConvertFrom-Json |
  Select-Object -ExpandProperty measurements
curl -s http://localhost:8081/actuator/metrics/jvm.memory.max | ConvertFrom-Json |
  Select-Object -ExpandProperty measurements

# GC pause count and total time (rising values over time = GC under pressure)
curl -s http://localhost:8081/actuator/metrics/jvm.gc.pause | ConvertFrom-Json

# HikariCP connection pool (pending > 0 = DB connections exhausted, not a heap leak)
curl -s http://localhost:8081/actuator/metrics/hikaricp.connections.pending | ConvertFrom-Json
```

If Actuator is unavailable, skip to Step 3 and rely on Prometheus only.

---

## Step 3 — Detect Heap Growth Pattern

### Prometheus heap trend (Grafana)

Run this PromQL with a 24h–7d time range:

```promql
jvm_memory_used_bytes{
  application="<service-name>",
  area="heap"
}
```

| Pattern | Meaning |
|---|---|
| Stable sawtooth | Healthy — GC collecting all short-lived objects normally |
| Rising sawtooth (floor climbs each cycle) | Memory leak — objects surviving GC and accumulating |
| No sawtooth, flat line near limit | GC running continuously but unable to reclaim enough; heap pressure critical |
| Sudden spike then drop | Traffic spike or large job — not a leak; check scaling and batch jobs |

A genuine leak shows a **rising sawtooth floor** — each GC cycle clears some memory but the
baseline keeps climbing. Confirm by zooming out to 7 days: the floor should show a clear upward trend.

### GC frequency

```promql
rate(jvm_gc_pause_seconds_count{application="<service-name>"}[5m])
```

GC frequency rising over hours without a corresponding traffic increase confirms heap pressure
is building. Combined with a rising heap floor, this is strong evidence of a leak.

---

## Step 4 — Capture Heap Dump

> **Warning:** `VM.heap_dump` causes a brief stop-the-world GC pause (typically 1–5s for heaps
> under 2 GB). Always run on a **non-primary** replica. If the service has only one pod, warn
> the user that requests will pause briefly.

```powershell
$ns  = "<namespace>"
$pod = "<pod-name>"  # pick a non-primary replica

# Find the JVM PID
kubectl exec $pod -n $ns -- jps -l

# Capture heap dump (live=true excludes already-collected objects — smaller, more actionable)
kubectl exec $pod -n $ns -- jcmd <PID> VM.heap_dump /tmp/heapdump.hprof

# Check file size before downloading
kubectl exec $pod -n $ns -- ls -lh /tmp/heapdump.hprof

# Copy to local machine
kubectl cp "${ns}/${pod}:/tmp/heapdump.hprof" ./heapdump.hprof

# Clean up — heap dumps can be several GB
kubectl exec $pod -n $ns -- rm /tmp/heapdump.hprof
```

For heaps > 2 GB, use Eclipse MAT standalone (lower memory footprint than VisualVM).

---

## Step 5 — Analyse Leak Suspects

### Option A — CLI class histogram (no GUI, runs against the live JVM)

This is the **fastest path** — no heap dump required. Run directly against the live pod:

```powershell
$ns  = "<namespace>"
$pod = "<pod-name>"

# Top classes by instance count and bytes — shows what is filling the heap right now
kubectl exec $pod -n $ns -- jcmd <PID> GC.class_histogram | Select-Object -First 30
```

**Interpret the output:**

| Top entry | Likely cause |
|---|---|
| `[B` (byte arrays) with high bytes | Large buffers retained — `ByteArrayOutputStream`, response body caching |
| `char[]` / `java.lang.String` high | String data accumulating — log buffers, JSON payloads held in memory |
| `com.maxxton.*` class in top 10 | That class is the leak suspect — use it directly as the search query in Step 6 |
| Only JDK classes (no `com.maxxton.*`) | Leak is inside a framework object — proceed to Option C (Eclipse MAT) |

Run the histogram **twice**, 5 minutes apart, and compare instance counts for the
suspect class — a growing count between runs confirms an active leak.

### Option B — YourKit (Maxxton has a corporate license)

YourKit provides live heap profiling and allocation flamegraphs without capturing a static
dump. Maxxton holds a corporate license — ask your team lead for access.

Attach to the pod (port-forward the YourKit agent port, usually 10001):

```powershell
kubectl port-forward $pod 10001:10001 -n $ns
# Connect YourKit → Memory tab → Heap → Object allocation recording
# Run representative load → Stop → sort by "Retained size" to find the largest live objects
```

See: https://www.yourkit.com/docs/java/help/running_profiler.jsp

### Option C — Eclipse MAT (fallback when histogram shows only JDK classes)

If `GC.class_histogram` shows no `com.maxxton.*` suspects in the top entries, the leak is
inside a framework-owned object tree. Capture a heap dump (Step 4) and open it in Eclipse
MAT on your local machine:

1. File → Open Heap Dump → `heapdump.hprof`
2. Run **Leak Suspects Report**
3. Open **Dominator Tree** — sort by "Retained Heap"

> **This is a user-performed step.** Once MAT loads, share the top entry from the
> Leak Suspects report (class name + retained bytes) here and investigation continues.

### Leak pattern lookup

| Finding in MAT | Likely cause | Fix |
|---|---|---|
| Large `HashMap` / `ConcurrentHashMap`, no size bound | Static cache without eviction | Add TTL or switch to `Caffeine.newBuilder().maximumSize(...).expireAfterWrite(...)` |
| `ArrayList` / `LinkedList` growing unbounded | Collection used as log or queue without draining | Add a size cap or drain on a schedule |
| Thousands of instances of the same class | Event listener added but never removed | Call `removeListener()` / `emitter.off()` symmetrically |
| `ThreadLocal` entries per thread | ThreadLocal not cleared in thread pools | Call `threadLocal.remove()` in a `finally` block |
| `Session` / `EntityManager` objects accumulating | Hibernate session not closed | Ensure `@Transactional` boundary; avoid detached sessions in async contexts |
| Large `byte[]` or `String` blocks | Response bodies or file contents buffered in memory | Stream large responses instead of loading them fully |
| Multiple Spring `ApplicationContext` instances | Singleton scope violated; context created per-request | Move context creation to application startup (`@Bean` singleton) |
| `ForkJoinPool` / `commonPool` objects accumulating | `parallelStream()` under load saturating the common pool | **Never use `parallelStream` in production** — replace with sequential stream or a named `ThreadPoolTaskExecutor` `@Bean` (Maxxton Performance Guide) |
| Growing thread objects / `Runnable` queue entries | `@Async` without a bounded `ThreadPoolTaskExecutor` | Define a `ThreadPoolTaskExecutor` `@Bean`; Spring's default creates an unbounded new thread per call |

---

## Step 6 — Fix and Verify

Ask the user before checking the codebase:

> "I've identified [suspect class / pattern] as the leak source. Would you like me to check
> `MaxxtonGroup/<repo>` to find the specific implementation and apply a fix?"

Use `AskUserQuestion` with **Yes** / **No**.

**If yes — find, fix, and apply:**

1. **Derive the search query from the finding:**
   - From histogram: use the `com.maxxton.*` class name from the top entry
     (e.g. `ResortClient` if `com.maxxton.reservation.ResortClient` is the top suspect)
   - From MAT Leak Suspects: use the class name reported by the user
2. `search_code(repo="MaxxtonGroup/<repo>", query="<ClassName>")` — locate the file
3. `get_file_contents(repo="MaxxtonGroup/<repo>", path="<file>")` — read the implementation
4. Match the code against the leak pattern table — identify the **specific anti-pattern
   in this file** (e.g. a specific `static Map` field on line 42, not a generic template)
5. Produce the **actual fix for this code** — show the real old lines → new lines as a diff
6. Ask: *"Should I apply this change?"* using `AskUserQuestion` (Yes / No)
7. **If yes:** apply with `Edit`, then tell the developer to deploy with a rolling restart

### Common fix patterns

```java
// Static cache without eviction → Caffeine with size and TTL
private static final Cache<String, Data> CACHE = Caffeine.newBuilder()
    .maximumSize(1_000)
    .expireAfterWrite(5, TimeUnit.MINUTES)
    .build();

// ThreadLocal leak in thread pool → always remove in finally
try {
    CONTEXT.set(value);
    doWork();
} finally {
    CONTEXT.remove();
}

// Hibernate session in async context → explicit transaction boundary
@Transactional(readOnly = true)
public List<Result> fetchData() { ... }

// Large export buffered in memory → stream to output immediately
// BAD: entire result set held in heap before flushing
List<Record> all = repo.findAll();
writeToFile(all);

// GOOD: stream rows directly to the output — heap never holds the full set
// (requires JDBC cursor / Stream support in your repo layer)
try (Stream<Record> stream = repo.findAllStream()) {
    stream.forEach(record -> writeRecord(record, outputStream));
}

// @Async without executor → unbounded thread creation
// BAD: Spring creates a new thread per call
@Async
public void process() { ... }

// GOOD: bounded thread pool prevents runaway memory growth
@Bean("taskExecutor")
public ThreadPoolTaskExecutor taskExecutor() {
    ThreadPoolTaskExecutor exec = new ThreadPoolTaskExecutor();
    exec.setCorePoolSize(4);
    exec.setMaxPoolSize(10);
    exec.setQueueCapacity(100);
    exec.initialize();
    return exec;
}
@Async("taskExecutor")
public void process() { ... }
```

### Verify the fix

After deploying, re-run the class histogram immediately to get the post-fix baseline:

```powershell
# Run after 10–15 minutes of normal traffic
kubectl exec $pod -n $ns -- jcmd <PID> GC.class_histogram | Select-Object -First 20
```

Compare the instance count of the suspect class from Step 5 — it should be stable or
dropping between the two runs (no longer growing). Record explicitly:

> "Before: `ResortClient` 4,821 instances / 96 MB → After: 312 instances / 6 MB. ✓"

Then re-run the Prometheus heap trend from Step 3 over the next 2–4 hours and confirm
the sawtooth floor is no longer rising. If it still climbs, a second leak source exists —
repeat from Step 5 with the updated histogram output.

---

## Common Pitfalls

- **Taking a heap dump under no load** — a cold heap shows few suspects. Take the dump when
  the service is actively serving traffic and heap usage is elevated.
- **Fixing the symptom (raising the memory limit)** — this postpones the OOM but the leak keeps
  growing. Fix the root cause first; right-size limits after verifying the fix.
- **Confusing a traffic spike with a leak** — a spike drops after GC; a leak's sawtooth floor
  keeps rising across multiple GC cycles over hours or days.
- **Not cleaning up the heap dump file** — heap dumps can be several GB. The cleanup step in
  Step 4 is mandatory; skipping it will fill the pod's ephemeral storage.

---

## Examples

User says: `/detecting-memory-leaks reservation-service env=production`
Claude checks the heap trend via Prometheus, captures a heap dump from a non-primary replica, and identifies the top leak suspects using Eclipse MAT patterns.

## Troubleshooting

- **Heap dump capture hangs**: the JVM is under extreme GC pressure — wait briefly and retry, or apply a rolling restart first to free memory before capturing.
- **`jcmd` not found**: the pod may run a JRE without diagnostic tools — verify with `kubectl exec <pod> -- which jcmd`; if absent, use async-profiler's allocation profiler (`-e alloc`) instead.
- **Heap dump is 0 bytes**: the JVM PID is wrong — re-run `jps -l` to confirm the correct PID and retry.

## Integration with Other Skills

- `/diagnosing-oom-kills` — start here if pods are already being killed; it routes to this skill
  when a leak is confirmed as the cause
- `/profiling-cpu` — if GC frames are wide in a CPU flamegraph, high object allocation is the
  root cause; use this skill to find the allocating code
- `/investigating-alerts` — use when a memory alert fired and you need broader incident context
  (recent deploys, correlated errors) before starting leak analysis
