# Skill Overrides: detecting-memory-leaks

## disable-model-invocation not set → N/A (flag is present)

## [SHOULD FIX] No quoted trigger phrase in description

**Reason:** Skill has `disable-model-invocation: true` and is purely user-invoked via
`/detecting-memory-leaks`. Quoted trigger phrases aid auto-invocation discovery, which is
disabled for this skill. Per `best-practices.md`: "Strong override reason: the skill has
no natural user phrasing because it's invoked by a tool/hook, not a human" — equivalent
applies here since the skill is explicitly user-commanded.

## [SHOULD FIX] PowerShell code blocks (OS-specific instructions)

**Reason:** Maxxton GKE investigation skills use PowerShell by established convention.
The companion skill `performance-profiler` (already in production in this plugin) uses
identical PowerShell syntax for GCP REST API calls and kubectl operations. Maxxton
developers work on Windows; diverging from the `performance-profiler` pattern would create
inconsistency across the performance investigation skill set in this plugin.
