---
user-invocable: false
name: creating-jira-bugs
description: Create a Jira Bug ticket from GCP trace investigation findings — structures root cause, affected services, and reproduction steps into a well-formed issue with Team and Epic fields. Use '/creating-jira-bugs' when creating a Jira Bug ticket after a GCP trace investigation.
disable-model-invocation: true
allowed-tools:
- mcp__claude_ai_Atlassian_MCP__getAccessibleAtlassianResources
- mcp__claude_ai_Atlassian_MCP__discover
- mcp__claude_ai_Atlassian_MCP__executeRead
- mcp__claude_ai_Atlassian_MCP__createJiraIssue
- mcp__claude_ai_Atlassian_MCP__getJiraIssue
- mcp__claude_ai_Atlassian_MCP__editJiraIssue
---

# Jira Bug Create

> **Cloud ID:** Call `mcp__claude_ai_Atlassian_MCP__getAccessibleAtlassianResources` first to resolve the Atlassian Cloud ID — required for all Jira calls.

Provides guidance for creating a well-structured Jira Bug ticket from trace investigation findings, including resolving custom field IDs for Team and Epic at runtime.

## Resolving Custom Field IDs

Jira custom fields like Team and Epic have project-specific IDs (e.g. `customfield_10014`). Resolve them at runtime using `mcp__claude_ai_Atlassian_MCP__executeRead` with `name: getJiraIssueTypeMetaWithFields` (find the operation via `mcp__claude_ai_Atlassian_MCP__discover` if needed):

1. Call `mcp__claude_ai_Atlassian_MCP__executeRead` with `name: getJiraIssueTypeMetaWithFields`, `cloudId` top-level, and the target project key and issue type `Bug` in `inputs`
2. Scan the returned fields for names matching "Team" and "Epic Link" (or "Epic Name")
3. Note the field IDs — use them when calling `createJiraIssue`

Known Maxxton field IDs (verify at runtime — these can change):
- **Epic Link**: `customfield_10014`
- **Team**: `customfield_10049` (option ID `10379` for "Pricing & Availability")

If a field is marked as required in the metadata, it must be included in the create call or the API will reject it.

---

## Bug Ticket Structure

### Summary

Write a concise, scannable one-liner:

```
[ServiceName] ExceptionType: brief description of what failed
```

**Good examples:**
- `[order-service] NullPointerException on POST /api/orders`
- `[payment-gateway] Timeout connecting to Stripe after 30s`
- `[user-service] Database connection pool exhausted during peak load`

**Avoid:**
- Generic: `Service is broken`
- Too long: `The order service encountered a null pointer exception when processing a POST request to the orders API endpoint`

### Description

Pass the description as a **plain markdown string** to `createJiraIssue`. Do NOT pass an ADF JSON object; `contentFormat` accepts only `markdown` (default) or `html`. In the JSON parameter value, `\n` is a real newline and is correct — do NOT double-escape as `\\n`, which produces a literal backslash-n in the rendered ticket.

Structure the description as follows:

```
## Root Cause
{2-3 sentence explanation based on log evidence}

## Error Details
- **Exception:** {exception class or error type}
- **Message:** {error message}
- **Service:** {affected service name}
- **Trace ID:** {traceId}

## Stack Trace
{stack trace if available}

## Timeline
- {timestamp}: {first relevant log entry}
- {timestamp}: {error log entry}

## Reproduction Steps
{inferred from logs — endpoint called, payload if visible, or "Unknown — derived from trace {traceId}"}
```

### Fields Summary

| Field | Value |
|-------|-------|
| Project | Developer-provided project key |
| Issue Type | Bug |
| Summary | `[service] ExceptionType: description` |
| Description | Root cause + error details + trace ID |
| Team | Developer-provided team name → resolved to custom field |
| Epic Link | Developer-provided epic key |

---

## Epic Link Validation

Before setting `customfield_10014`, verify the provided issue key is actually of type **Epic**:

1. Call `getJiraIssue` with the provided epic key
2. Check that `fields.issuetype.name` equals `"Epic"`
3. If it is not an Epic, **skip the field** and inform the developer:

> Epic key PROJ-100 is not an Epic type — skipping Epic Link. Link it manually in Jira.

Never set `customfield_10014` to a non-Epic issue key — the ticket will be created but the Epic Link field will be silently invalid.

---

## Creating the Ticket

Use `createJiraIssue` with the resolved field IDs:

```json
{
  "projectKey": "PROJ",
  "summary": "[order-service] NullPointerException on POST /api/orders",
  "issueType": "Bug",
  "description": "## Root Cause\n...\n\n## Error Details\n...",
  "customfield_10014": "PROJ-100",
  "customfield_10049": { "id": "10379" }
}
```

If `createJiraIssue` fails due to a missing required field, re-fetch the field metadata and check which required fields were not included.

If the description renders incorrectly after creation (e.g. markdown not formatted), use `editJiraIssue` to update it with corrected content.

---

## Confirmation Flow

Always show a draft and get explicit confirmation before creating:

1. Present the full draft (summary + description + Team + Epic)
2. Ask: "Shall I create this ticket?"
3. Wait for confirmation
4. Create and return the ticket URL

Never create a ticket without developer confirmation.

## Instructions

Invoke with "/creating-jira-bugs" in Claude Code. The skill guides you through the workflow step by step.

## Examples

User says: "/creating-jira-bugs"
Claude creates a structured Jira bug ticket from the provided error logs, trace ID, or description.

## Troubleshooting

- **Ticket created in wrong project**: verify the project key before confirming.
- **Epic Link not set**: confirm the epic key is of type Epic and exists in the target project.
