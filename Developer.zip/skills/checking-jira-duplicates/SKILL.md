---
user-invocable: false
name: checking-jira-duplicates
description: Search Jira for existing bug tickets matching a newly found error — evaluates similarity to avoid creating duplicate tickets before filing a new bug. Use '/checking-jira-duplicates' when checking whether a matching Jira bug already exists before filing a new one.
disable-model-invocation: true
allowed-tools:
- mcp__claude_ai_Atlassian_MCP__searchJiraIssuesUsingJql
---

# Jira Duplicate Check

Provides guidance for searching Jira for existing bug tickets before creating a new one, to avoid duplicates and surface prior investigations.

## Building the JQL Query

Use `mcp__claude_ai_Atlassian_MCP__searchJiraIssuesUsingJql` to execute each query.

Construct a JQL query using the most specific signals available from the log analysis:

**Primary: search by error message keywords**
```jql
project = "PROJECT_KEY" AND issuetype = Bug AND summary ~ "ErrorClassName" ORDER BY created DESC
```

**With service name:**
```jql
project = "PROJECT_KEY" AND issuetype = Bug AND (summary ~ "ErrorClassName" OR summary ~ "service-name") ORDER BY created DESC
```

**Broaden if no results:**
```jql
project = "PROJECT_KEY" AND issuetype = Bug AND text ~ "ErrorClassName" ORDER BY created DESC
```

Extract search terms from the log analysis in this order of preference:
1. Exception class name (e.g. `NullPointerException`, `TimeoutException`)
2. Key phrase from the error message (3-5 distinctive words)
3. Affected service name

Avoid overly generic terms like "error" or "failed" that will return too many irrelevant results.

---

## Evaluating Matches

When results are returned, evaluate each candidate:

| Signal | Strong match | Weak match |
|--------|-------------|------------|
| Summary | Same exception + same service | Same exception, different service |
| Status | Open or In Progress | Closed/Done more than 30 days ago |
| Description | Same stack trace or same endpoint | Similar but different context |
| Recency | Created or updated within 90 days | Older than 6 months |

**Treat as a duplicate if**: same exception class AND same service, regardless of status.

**Treat as related (not duplicate) if**: same exception class but different service or different endpoint.

**Ignore if**: same service but clearly different error, or ticket is resolved with a known fix that hasn't been applied.

---

## Presenting Results

Present found tickets clearly so the developer can make an informed decision:

```
## Possible duplicate tickets found

- **[PROJ-123]** NullPointerException in order-service — *Open* (3 days ago)
  https://your-org.atlassian.net/browse/PROJ-123

- **[PROJ-87]** order-service timeout on POST /api/orders — *In Review* (2 weeks ago)
  https://your-org.atlassian.net/browse/PROJ-87

Do you want to:
1. Create a new ticket anyway
2. Add a comment to an existing ticket with this trace ID
3. Skip ticket creation
```

Wait for the developer to choose before proceeding.

---

## When No Duplicates Are Found

If the JQL query returns no results, state this briefly and continue:

> No existing bug tickets found for this error. Proceeding to create a new ticket.

Do not perform more than two JQL searches — if the first specific search and one broader search both return nothing, accept that there are no duplicates.

## Instructions

Invoke with "/checking-jira-duplicates" in Claude Code. The skill guides you through the workflow step by step.

## Examples

User says: "/checking-jira-duplicates"
Claude searches Jira for tickets similar to the provided summary and lists potential duplicates with similarity scores.

## Troubleshooting

- **No results returned**: broaden the search terms or check Jira connectivity.
- **Too many false positives**: refine the JQL query with a stricter project filter.
