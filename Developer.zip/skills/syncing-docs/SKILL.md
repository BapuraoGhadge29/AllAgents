---
name: syncing-docs
description: Check and fix documentation drift — verifies Javadoc, README references, and OpenAPI annotations match the current code, then applies corrections. Use '/syncing-docs' when documentation is out of sync with the current code.
disable-model-invocation: true
argument-hint: "[file, directory, or 'recent']"
allowed-tools:
- Read
- Write
- Edit
- Bash
- Grep
- Glob
- mcp__claude_ai_Maxxton_Knowledge__query_openapi
---

# Documentation Sync

Detect code-level documentation that has drifted from the actual implementation and fix it. Covers Javadoc, inline comments, README references, and OpenAPI/Swagger annotations.

## Step 1: Determine Scope

Parse the user's input to determine what to scan:

- **File path** → scan that file
- **Directory** → scan all source files and READMEs in that directory
- **"recent"** → run `git diff main...HEAD --name-only` to get changed files. If no commits on the branch yet, fall back to `git diff --name-only`

Report the scope:
> **Scope:** 8 files changed on this branch

---

## Step 2: Scan for Documentation Drift

For each file in scope, check the following categories:

### 2a. Javadoc Drift

For each method/class with Javadoc:
1. Compare `@param` names against actual parameter names → flag mismatches and missing params
2. Compare `@return` description against what the method actually returns → flag if the description contradicts the code
3. Compare `@throws` declarations against actual thrown exceptions → flag missing or extra declarations
4. Read the Javadoc summary and compare against the method body → flag if the description no longer matches the behavior (e.g. Javadoc says "returns null when not found" but the method now throws an exception)

### 2b. Inline Comment Drift

For comments that describe specific behavior (not task-comment or explanatory):
1. Read the comment and the code it sits next to
2. Flag if the comment describes behavior the code no longer performs
3. Common patterns: "this loop iterates over X" when X was renamed, "we use Y because Z" when Y was replaced

### 2c. README References

For README.md and other markdown files in scope:
1. Extract file paths, class names, and endpoint URLs referenced in the text
2. Verify each reference:
   - File paths → check the file exists using Glob
   - Class names → grep for the class definition
   - Endpoint URLs → check for matching `@RequestMapping` / `@GetMapping` annotations
3. Flag references to files, classes, or endpoints that no longer exist

### 2d. Deprecated Without Documentation

For methods annotated with `@Deprecated` or with a Javadoc `@deprecated` tag:
1. Check if the Javadoc includes a `@deprecated` tag explaining the replacement
2. Flag if the annotation is present but the Javadoc tag is missing or empty

### 2e. OpenAPI/Swagger Annotation Drift

For Spring Boot controllers with OpenAPI annotations:
1. Compare `@Operation(summary = "...")` against actual method behavior
2. Compare `@ApiResponse` status codes against actual returned status codes
3. Compare `@Parameter` annotations against actual method parameters
4. Use `mcp__claude_ai_Maxxton_Knowledge__query_openapi` to cross-reference the published API contract if available — skip if unavailable

---

## Step 3: Present Findings

Show each finding with a before/after suggestion:

```
## Documentation Drift — src/main/java/com/example/

### Javadoc Issues

**UserService.java:45** — `@param` mismatch
- Current: `@param userId the user ID`
- Actual parameter name: `accountId`
- Suggested fix: `@param accountId the account ID`

**OrderController.java:89** — stale description
- Current Javadoc: "Returns the order or null if not found"
- Actual behavior: throws `OrderNotFoundException`
- Suggested fix: Update Javadoc to "Returns the order. Throws OrderNotFoundException if not found."

### README Issues

**README.md:34** — dead file reference
- References `src/main/java/com/example/LegacyService.java`
- File does not exist (deleted in commit abc1234)

### Missing Deprecation Docs

**PaymentGateway.java:112** — `@Deprecated` without explanation
- Suggested: add `@deprecated Use {@link NewPaymentGateway} instead`
```

**Wait for user approval** before applying any changes. User can approve all or select individual fixes.

---

## Step 4: Apply Fixes

1. Apply the approved documentation changes
2. Run the build to check for Javadoc warnings or compilation issues:
   - Gradle: `./gradlew build`
   - npm: `npm run build`
3. If the build fails due to a documentation change (e.g. Javadoc lint error), fix and re-run

---

## Step 5: Summary

```
## Doc Sync Summary

Fixed 7 documentation issues across 4 files:
- 3 Javadoc param mismatches
- 1 stale method description
- 1 dead README reference
- 1 missing deprecation doc
- 1 OpenAPI annotation drift

Build: PASSED
```

---

## Tips

- **Don't rewrite working docs** — only fix things that are factually wrong or reference things that no longer exist
- **Preserve author voice** — match the existing Javadoc style in the file (terse vs verbose, first person vs third person)
- **OpenAPI annotations are source of truth for API consumers** — drift here is high-priority since it affects generated API docs
- **`@deprecated` tags matter** — they show up in IDE warnings and help developers migrate

## Examples

User says: "/syncing-docs"
Claude scans source files changed since the last commit and updates the corresponding documentation to stay in sync.

## Troubleshooting

- **Docs not updated**: verify the docs directory path matches the configured location.
- **Too many diffs**: narrow scope by specifying a single file or module.
