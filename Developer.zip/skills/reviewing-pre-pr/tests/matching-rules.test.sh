#!/usr/bin/env bash
# Tests for scripts/matching-rules.py — which project rules a review must apply,
# given the changed files on stdin. Runs on macOS, Linux and Windows (Git Bash).
# Usage: bash tests/matching-rules.test.sh

set -uo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
RUN_PY="$SCRIPT_DIR/../../../hooks/run-python.sh"
SCRIPT="$SCRIPT_DIR/../scripts/matching-rules.py"

PASS=0; FAIL=0
pass() { echo "  PASS  $1"; PASS=$((PASS+1)); }
fail() { echo "  FAIL  $1"; FAIL=$((FAIL+1)); }

# A workspace folder with its own rule, and a repo inside it with plugin copies.
_WS=$(mktemp -d)
trap 'rm -rf "$_WS"' EXIT
_REPO="$_WS/repositories/svc"
mkdir -p "$_WS/.claude/rules" "$_REPO/.claude/rules/developer" "$_REPO/.claude/rules/java"

_rule() {  # $1 = file, $2 = paths: block ("" for none), $3 = body
  { printf -- '---\n'
    [ -n "$2" ] && printf 'paths:\n%s\n' "$2"
    printf 'description: x\n---\n\n%s\n' "$3"
  } > "$1"
}
_rule "$_WS/.claude/rules/workspace-conventions.md" "" "WORKSPACE BODY"
_rule "$_REPO/.claude/rules/developer/commit-message-format.md" "" "COMMIT BODY"
_rule "$_REPO/.claude/rules/java/function-design.md" '  - "**/*.java"' "JAVA BODY"
_rule "$_REPO/.claude/rules/java/test-naming.md" '  - "**/src/test/java/**/*Test.java"' "TEST BODY"
_rule "$_REPO/.claude/rules/java/gradle.md" '  - "**/build.gradle"
  - "**/settings.gradle"' "GRADLE BODY"

_run() { printf '%s\n' "$@" | bash "$RUN_PY" "$SCRIPT" "$_REPO" 2>&1; }

out=$(_run "src/main/java/demo/Demo.java")
case "$out" in *"JAVA BODY"*) pass "a **/*.java rule applies to a nested .java file" ;; *) fail "java rule missing: $out" ;; esac
case "$out" in *"TEST BODY"*) fail "test-only rule applied to main code" ;; *) pass "a test-path rule does not apply to main code" ;; esac
case "$out" in *"GRADLE BODY"*) fail "gradle rule applied to a .java change" ;; *) pass "a non-matching rule is left out" ;; esac

out=$(_run "Demo.java")
case "$out" in *"JAVA BODY"*) pass "**/ also matches a file at the repo root" ;; *) fail "**/*.java missed a root-level file" ;; esac

out=$(_run "svc/src/test/java/demo/DemoTest.java")
case "$out" in *"TEST BODY"*) pass "a rule matches through ** in the middle of a pattern" ;; *) fail "test rule missing: $out" ;; esac

out=$(_run "settings.gradle")
case "$out" in *"GRADLE BODY"*) pass "any one of several paths: entries is enough" ;; *) fail "second paths: entry ignored" ;; esac

out=$(_run "README.md")
case "$out" in *"COMMIT BODY"*"WORKSPACE BODY"*|*"WORKSPACE BODY"*"COMMIT BODY"*)
  pass "rules without paths: always apply, from the repo and its parent folders" ;;
  *) fail "unscoped or parent-folder rule missing: $out" ;; esac
case "$out" in *"description: x"*) fail "frontmatter leaked into the output" ;; *) pass "only rule bodies are printed" ;; esac
case "$out" in *"[rule: java/function-design]"*) fail "unmatched rule named" ;; *) pass "an unmatched rule is not named" ;; esac

out=$(_run "src/main/java/demo/Demo.java")
case "$out" in *"[rule: java/function-design]"*) pass "each rule is headed by the tag findings use" ;; *) fail "rule tag missing: $out" ;; esac

# Repos set up before rules were copied still hold a link to the plugin's rules.
_linked=$(mktemp -d)
_rule "$_linked/linked-rule.md" "" "LINKED BODY"
if ln -s "$_linked" "$_REPO/.claude/rules/security" 2>/dev/null && [ -L "$_REPO/.claude/rules/security" ]; then
  out=$(_run "README.md")
  case "$out" in *"LINKED BODY"*) pass "rules behind a linked folder are read" ;; *) fail "linked rules folder skipped" ;; esac
else
  echo "  SKIP  linked rules folder (platform cannot create links)"
fi
rm -rf "$_linked"

out=$(printf '' | bash "$RUN_PY" "$SCRIPT" "$_REPO" 2>&1); rc=$?
if [ "$rc" -eq 0 ]; then pass "no changed files → exit 0"; else fail "no changed files → exit $rc"; fi

echo ""
echo "Results: $PASS passed, $FAIL failed"
[ "$FAIL" -eq 0 ]
