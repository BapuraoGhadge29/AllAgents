#!/usr/bin/env bash
# Tests for scripts/pre-pr-markers.sh
# Usage: bash tests/pre-pr-markers.test.sh
#
# Discrimination was checked against two stubs, not assumed.
#
# Against the 2.31.3 logic (repo-wide `find -delete`, `find | head -1` selection),
# five cases flip to FAIL: "another branch's pass marker", "another branch's
# findings record", "same-prefix files with no sha", "only another branch's
# record", and "non-sha reviewed_sha".
#
# Against this script's own first draft (no branch-tip check, first-found
# selection), two flip: "stacked parent branch's tip" and "two ancestor records".
# Both were found by the pre-PR review of this branch.
#
# Of the nine match-pass cases, four flip to FAIL without the action: the three
# asserting a positive answer ("identical", "messages-only", and the preference
# between them), plus "unresolvable base", which requires exit 0 where an unknown
# action gives 2. The other five assert "no match" or exit 2, which a script that
# does not know the action produces anyway — they pin behaviour, not discriminate.
#
# A tenth case, "merge-base moved under an unchanged base/tree", discriminates
# against a narrower baseline: match-pass before the merge-base commit joined the
# signature. It rewrites a branch onto a different ancestor of the same base commit
# while keeping base_sha, tree_sha and the commit message byte-identical — the exact
# gap (base_sha, tree_sha) left open — and fails against that baseline (returns
# "identical" instead of no match).
#
# "HEAD's sha sorts later" is deliberately NOT claimed as a regression test.
# The 2.31.3 selection had no `sort`, so which record it read depended on
# directory order — it passes or fails by luck. That indeterminacy is the defect;
# the case is kept because it pins the new behaviour, not because it fails on the
# old. The two cases above instead force the sha order, so they fail reliably.
set -uo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SCRIPT="$SCRIPT_DIR/../scripts/pre-pr-markers.sh"

PASS=0; FAIL=0
pass() { printf '  \033[0;32mPASS\033[0m  %s\n' "$1"; PASS=$((PASS+1)); }
fail() { printf '  \033[0;31mFAIL\033[0m  %s\n' "$1"; FAIL=$((FAIL+1)); }

# A repo with main, plus feature-a and feature-b diverging from it. Returns the
# repo path; callers read shas with `_sha <repo> <rev>`.
_new_repo() {
  local repo
  repo=$(mktemp -d)
  git -C "$repo" init -q -b main
  git -C "$repo" config user.email t@example.com
  git -C "$repo" config user.name Test
  echo base > "$repo/base.txt"
  git -C "$repo" add -A
  git -C "$repo" commit -qm base
  git -C "$repo" checkout -q -b feature-a
  echo a > "$repo/a.txt"; git -C "$repo" add -A; git -C "$repo" commit -qm a
  git -C "$repo" checkout -q main
  git -C "$repo" checkout -q -b feature-b
  echo b > "$repo/b.txt"; git -C "$repo" add -A; git -C "$repo" commit -qm b
  printf '%s' "$repo"
}

_git_dir() { git -C "$1" rev-parse --absolute-git-dir; }
_sha() { git -C "$1" rev-parse "$2"; }

_bogus_sha() { printf '%040d' "$1"; } # 40 hex, valid shape, names nothing

# The signature a pass marker records for HEAD against <base-rev>.
_sig() { # repo base-rev
  local b mb t m
  b=$(git -C "$1" rev-parse "$2^{commit}")
  mb=$(git -C "$1" merge-base "$b" HEAD)
  t=$(git -C "$1" rev-parse 'HEAD^{tree}')
  m=$(git -C "$1" log --format=%B "$b..HEAD" | git -C "$1" hash-object --stdin)
  printf '%s %s %s %s' "$b" "$mb" "$t" "$m"
}

_write_pass() { # repo sha signature-or-empty
  printf '%s\n' "$3" > "$(_git_dir "$1")/pre-pr-review-$2"
}

_write_findings() { # repo sha marker-text
  printf '{"reviewed_sha":"%s","base":"main","findings":[{"file":"%s","line":1,"what":"w","why":"y"}]}\n' \
    "$2" "$3" > "$(_git_dir "$1")/pre-pr-findings-$2.json"
}

# ── select-findings ──────────────────────────────────────────────────────────

test_select_no_records() {
  local repo out; repo=$(_new_repo)
  out=$(bash "$SCRIPT" "$repo" select-findings)
  if [ -z "$out" ]; then pass "no records → prints nothing"
  else fail "no records → prints nothing (got '$out')"; fi
  rm -rf "$repo"
}

test_select_ancestor_record() {
  local repo out prev; repo=$(_new_repo)
  prev=$(_sha "$repo" HEAD)
  echo more > "$repo/b.txt"; git -C "$repo" commit -qam b2   # HEAD moves past prev
  _write_findings "$repo" "$prev" HEADs-own
  out=$(bash "$SCRIPT" "$repo" select-findings)
  if [ "$out" = "$(_git_dir "$repo")/pre-pr-findings-$prev.json" ]; then
    pass "record for an ancestor of HEAD → selected"
  else fail "record for an ancestor of HEAD → selected (got '$out')"; fi
  rm -rf "$repo"
}

# REGRESSION: `find | head -1` returns the lexicographically smallest sha, so it
# reads the other branch's record whenever HEAD's own sha sorts later.
test_select_prefers_head_lineage_over_sort_order() {
  local repo out a b picked; repo=$(_new_repo)
  a=$(_sha "$repo" feature-a); b=$(_sha "$repo" feature-b)
  # Put HEAD on whichever branch's sha sorts LAST, so filename order is wrong.
  if [[ "$a" < "$b" ]]; then git -C "$repo" checkout -q feature-b; else git -C "$repo" checkout -q feature-a; fi
  _write_findings "$repo" "$a" on-feature-a
  _write_findings "$repo" "$b" on-feature-b
  out=$(bash "$SCRIPT" "$repo" select-findings)
  picked=$(sed -n 's/.*"reviewed_sha"[^"]*"\([^"]*\)".*/\1/p' "$out" 2>/dev/null | head -1)
  if [ "$picked" = "$(_sha "$repo" HEAD)" ]; then
    pass "two records, HEAD's sha sorts later → still selects HEAD's lineage"
  else fail "two records → selected '${picked:0:7}', want HEAD '$(_sha "$repo" HEAD | cut -c1-7)'"; fi
  rm -rf "$repo"
}

# Two records can both be ancestors of HEAD once clear-lineage spares a stacked
# parent's, so first-found is not good enough — the nearest one must win, or
# verification mode checks the parent's findings and misses this branch's.
# Found in pre-PR review of this branch.
test_select_prefers_nearest_ancestor_record() {
  local repo out picked parent_tip own; repo=$(_new_repo)
  git -C "$repo" checkout -q feature-a
  parent_tip=$(_sha "$repo" HEAD)
  git -C "$repo" checkout -q -b feature-a-stacked
  echo s > "$repo/s.txt"; git -C "$repo" add -A; git -C "$repo" commit -qm stacked
  own=$(_sha "$repo" HEAD)
  # Force the parent's sha to sort FIRST, so name order actively points at the
  # wrong record. Without this the case passes or fails by luck.
  local n=0
  while [[ "$parent_tip" > "$own" ]] && [ "$n" -lt 40 ]; do
    git -C "$repo" commit -q --amend -m "stacked $n"
    own=$(_sha "$repo" HEAD); n=$((n+1))
  done
  [[ "$parent_tip" < "$own" ]] || { fail "setup: could not order the shas after $n tries"; rm -rf "$repo"; return; }
  _write_findings "$repo" "$parent_tip" PARENT
  _write_findings "$repo" "$own" OWN
  out=$(bash "$SCRIPT" "$repo" select-findings)
  picked=$(sed -n 's/.*"file":"\([^"]*\)".*/\1/p' "$out" 2>/dev/null | head -1)
  if [ "$picked" = "OWN" ]; then
    pass "two ancestor records (stacked parent + own) → selects the nearest"
  else fail "two ancestor records → selected '$picked', want OWN"; fi
  rm -rf "$repo"
}

test_select_ignores_other_branch_only() {
  local repo out; repo=$(_new_repo)
  _write_findings "$repo" "$(_sha "$repo" feature-a)" on-feature-a   # HEAD is feature-b
  out=$(bash "$SCRIPT" "$repo" select-findings)
  if [ -z "$out" ]; then pass "only another branch's record → prints nothing (full review)"
  else fail "only another branch's record → prints nothing (got '$out')"; fi
  rm -rf "$repo"
}

test_select_skips_malformed_sha() {
  local repo out g; repo=$(_new_repo); g=$(_git_dir "$repo")
  printf '{"reviewed_sha":"not-a-sha","base":"main","findings":[]}\n' > "$g/pre-pr-findings-not-a-sha.json"
  out=$(bash "$SCRIPT" "$repo" select-findings)
  if [ -z "$out" ]; then pass "record with a non-sha reviewed_sha → skipped, no crash"
  else fail "record with a non-sha reviewed_sha → skipped (got '$out')"; fi
  rm -rf "$repo"
}

# ── clear-lineage ────────────────────────────────────────────────────────────

test_clear_supersedes_own_pass_marker() {
  local repo g prev; repo=$(_new_repo); g=$(_git_dir "$repo")
  prev=$(_sha "$repo" HEAD)
  touch "$g/pre-pr-review-$prev"
  echo more > "$repo/b.txt"; git -C "$repo" commit -qam b2
  bash "$SCRIPT" "$repo" clear-lineage >/dev/null
  if [ ! -f "$g/pre-pr-review-$prev" ]; then
    pass "pass marker for an ancestor of HEAD → cleared"
  else fail "pass marker for an ancestor of HEAD → cleared (it survived)"; fi
  rm -rf "$repo"
}

# REGRESSION: the repo-wide sweep deleted this, costing feature-a a full
# re-review the next time the developer switched back to it.
test_clear_spares_other_branch_pass_marker() {
  local repo g a; repo=$(_new_repo); g=$(_git_dir "$repo")
  a=$(_sha "$repo" feature-a)
  touch "$g/pre-pr-review-$a"          # feature-a passed; HEAD is feature-b
  bash "$SCRIPT" "$repo" clear-lineage >/dev/null
  if [ -f "$g/pre-pr-review-$a" ]; then
    pass "another branch's pass marker → spared"
  else fail "another branch's pass marker → spared (it was deleted)"; fi
  rm -rf "$repo"
}

# REGRESSION: same sweep destroyed the other branch's outstanding findings.
test_clear_spares_other_branch_findings() {
  local repo g a; repo=$(_new_repo); g=$(_git_dir "$repo")
  a=$(_sha "$repo" feature-a)
  _write_findings "$repo" "$a" on-feature-a
  bash "$SCRIPT" "$repo" clear-lineage >/dev/null
  if [ -f "$g/pre-pr-findings-$a.json" ]; then
    pass "another branch's findings record → spared"
  else fail "another branch's findings record → spared (it was deleted)"; fi
  rm -rf "$repo"
}

# A stacked branch's parent tip is an ancestor of HEAD, so the ancestor rule
# alone deletes it — costing the parent branch a full re-review on checkout.
# Found in pre-PR review of this very change.
test_clear_spares_stacked_parent_tip() {
  local repo g parent_tip; repo=$(_new_repo); g=$(_git_dir "$repo")
  git -C "$repo" checkout -q feature-a
  parent_tip=$(_sha "$repo" HEAD)
  touch "$g/pre-pr-review-$parent_tip"                 # feature-a passed
  git -C "$repo" checkout -q -b feature-a-stacked      # stacked on top of it
  echo s > "$repo/s.txt"; git -C "$repo" add -A; git -C "$repo" commit -qm stacked
  git -C "$repo" merge-base --is-ancestor "$parent_tip" HEAD \
    || { fail "setup: parent tip is not an ancestor of the stacked HEAD"; rm -rf "$repo"; return; }
  bash "$SCRIPT" "$repo" clear-lineage >/dev/null
  if [ -f "$g/pre-pr-review-$parent_tip" ]; then
    pass "stacked parent branch's tip → spared despite being an ancestor of HEAD"
  else fail "stacked parent branch's tip → spared (it was deleted)"; fi
  rm -rf "$repo"
}

# The counterpart: HEAD's own marker must still go, or the findings path would
# leave a recorded pass beside the findings it is about to write.
test_clear_removes_head_own_marker() {
  local repo g head; repo=$(_new_repo); g=$(_git_dir "$repo")
  head=$(_sha "$repo" HEAD)
  touch "$g/pre-pr-review-$head"
  bash "$SCRIPT" "$repo" clear-lineage >/dev/null
  if [ ! -f "$g/pre-pr-review-$head" ]; then
    pass "HEAD's own marker → cleared even though HEAD is a branch tip"
  else fail "HEAD's own marker → cleared (it survived)"; fi
  rm -rf "$repo"
}

test_clear_reaps_amended_away_marker() {
  local repo g old; repo=$(_new_repo); g=$(_git_dir "$repo")
  old=$(_sha "$repo" HEAD)
  touch "$g/pre-pr-review-$old"
  git -C "$repo" commit -q --amend -m "b amended"
  # The object still exists via the reflog, so is-ancestor alone never reaps it.
  git -C "$repo" cat-file -e "$old^{commit}" 2>/dev/null || { fail "setup: amended commit already gone"; rm -rf "$repo"; return; }
  bash "$SCRIPT" "$repo" clear-lineage >/dev/null
  if [ ! -f "$g/pre-pr-review-$old" ]; then
    pass "marker for an amended-away commit → cleared (no branch contains it)"
  else fail "marker for an amended-away commit → cleared (it survived)"; fi
  rm -rf "$repo"
}

test_clear_reaps_marker_for_missing_commit() {
  local repo g gone; repo=$(_new_repo); g=$(_git_dir "$repo")
  gone=$(printf 'd%039d' 0 | tr ' ' '0')   # well-formed sha, no such object
  touch "$g/pre-pr-review-$gone"
  bash "$SCRIPT" "$repo" clear-lineage >/dev/null
  if [ ! -f "$g/pre-pr-review-$gone" ]; then
    pass "marker whose commit does not exist → cleared"
  else fail "marker whose commit does not exist → cleared (it survived)"; fi
  rm -rf "$repo"
}

test_clear_spares_unattributable_files() {
  local repo g; repo=$(_new_repo); g=$(_git_dir "$repo")
  touch "$g/pre-pr-review-notes.txt" "$g/pre-pr-findings-scratch.json"
  bash "$SCRIPT" "$repo" clear-lineage >/dev/null
  if [ -f "$g/pre-pr-review-notes.txt" ] && [ -f "$g/pre-pr-findings-scratch.json" ]; then
    pass "same-prefix files with no sha → spared"
  else fail "same-prefix files with no sha → spared (one was deleted)"; fi
  rm -rf "$repo"
}

test_clear_handles_path_with_space() {
  local repo g prev parent; parent=$(mktemp -d); repo="$parent/my repo"
  mkdir -p "$repo"
  git -C "$repo" init -q -b main
  git -C "$repo" config user.email t@example.com; git -C "$repo" config user.name Test
  echo x > "$repo/x.txt"; git -C "$repo" add -A; git -C "$repo" commit -qm x
  g=$(_git_dir "$repo"); prev=$(_sha "$repo" HEAD)
  touch "$g/pre-pr-review-$prev"
  echo y > "$repo/x.txt"; git -C "$repo" commit -qam y
  bash "$SCRIPT" "$repo" clear-lineage >/dev/null
  if [ ! -f "$g/pre-pr-review-$prev" ]; then
    pass "repo path containing a space → still scoped and cleared"
  else fail "repo path containing a space → still scoped and cleared"; fi
  rm -rf "$parent"
}

# ── fail-closed ──────────────────────────────────────────────────────────────

test_no_args_deletes_nothing() {
  local repo g prev rc=0; repo=$(_new_repo); g=$(_git_dir "$repo")
  prev=$(_sha "$repo" HEAD); touch "$g/pre-pr-review-$prev"
  bash "$SCRIPT" >/dev/null 2>&1 || rc=$?
  if [ "$rc" -eq 2 ] && [ -f "$g/pre-pr-review-$prev" ]; then
    pass "no arguments → exit 2 and nothing deleted"
  else fail "no arguments → exit 2 and nothing deleted (rc=$rc)"; fi
  rm -rf "$repo"
}

test_not_a_git_repo() {
  local dir rc=0; dir=$(mktemp -d)
  bash "$SCRIPT" "$dir" clear-lineage >/dev/null 2>&1 || rc=$?
  if [ "$rc" -eq 2 ]; then pass "target is not a git repository → exit 2"
  else fail "target is not a git repository → exit 2 (rc=$rc)"; fi
  rm -rf "$dir"
}

# ── match-pass ───────────────────────────────────────────────────────────────

test_match_no_markers() {
  local repo out; repo=$(_new_repo)
  out=$(bash "$SCRIPT" "$repo" match-pass main)
  if [ -z "$out" ]; then pass "no pass marker → nothing to carry forward"
  else fail "no pass marker → nothing to carry forward (got '$out')"; fi
  rm -rf "$repo"
}

test_match_empty_legacy_marker() {
  local repo out; repo=$(_new_repo)
  # Written by a version that recorded no signature. It establishes nothing, and
  # must not be read as a match, or every pre-upgrade marker silently skips a review.
  _write_pass "$repo" "$(_sha "$repo" HEAD)" ""
  out=$(bash "$SCRIPT" "$repo" match-pass main)
  if [ -z "$out" ]; then pass "signature-less marker → full review, as before"
  else fail "signature-less marker → full review, as before (got '$out')"; fi
  rm -rf "$repo"
}

test_match_identical_content() {
  local repo out; repo=$(_new_repo)
  _write_pass "$repo" "$(_sha "$repo" HEAD)" "$(_sig "$repo" main)"
  out=$(bash "$SCRIPT" "$repo" match-pass main)
  if [ "$out" = "identical" ]; then pass "same base, tree and messages → identical"
  else fail "same base, tree and messages → identical (got '$out')"; fi
  rm -rf "$repo"
}

test_match_messages_only() {
  local repo out b mb t; repo=$(_new_repo)
  b=$(_sha "$repo" main); mb=$(git -C "$repo" merge-base "$b" HEAD)
  t=$(git -C "$repo" rev-parse 'HEAD^{tree}')
  _write_pass "$repo" "$(_sha "$repo" HEAD)" "$b $mb $t $(_bogus_sha 1)"
  out=$(bash "$SCRIPT" "$repo" match-pass main)
  if [ "$out" = "messages-only" ]; then pass "same base and tree, new messages → messages-only"
  else fail "same base and tree, new messages → messages-only (got '$out')"; fi
  rm -rf "$repo"
}

test_match_rejects_moved_base() {
  local repo out t; repo=$(_new_repo)
  t=$(git -C "$repo" rev-parse 'HEAD^{tree}')
  # HEAD is untouched, but the verdict was reached against a different base
  # commit, so the diff it judged is not the diff that would be judged now.
  _write_pass "$repo" "$(_sha "$repo" HEAD)" "$(_bogus_sha 2) $(_bogus_sha 5) $t $(_bogus_sha 1)"
  out=$(bash "$SCRIPT" "$repo" match-pass main)
  if [ -z "$out" ]; then pass "base commit moved → no match"
  else fail "base commit moved → no match (got '$out')"; fi
  rm -rf "$repo"
}

test_match_rejects_moved_merge_base() {
  local repo out
  repo=$(mktemp -d)
  git -C "$repo" init -q -b main
  git -C "$repo" config user.email t@example.com
  git -C "$repo" config user.name Test
  echo base > "$repo/base.txt"; git -C "$repo" add -A; git -C "$repo" commit -qm base   # M0
  echo m1 > "$repo/m1.txt"; git -C "$repo" add -A; git -C "$repo" commit -qm m1         # M1, main's tip

  # Original feature: branches from main's tip (M1), one commit on top.
  git -C "$repo" checkout -q -b feature
  echo f > "$repo/f.txt"; git -C "$repo" add -A; git -C "$repo" commit -qm "add f"
  _write_pass "$repo" "$(_sha "$repo" HEAD)" "$(_sig "$repo" main)"

  # Rewrite feature onto M0 instead of M1, replaying both diffs as one commit with
  # the exact same message and the exact same final tree as before. base_sha
  # (main's tip, M1) and tree_sha come out unchanged, but merge-base(M1, feature)
  # moves from M1 to M0 — the gap (base_sha, tree_sha) alone left open.
  git -C "$repo" checkout -q "$(_sha "$repo" main)~1"
  echo m1 > "$repo/m1.txt"; echo f > "$repo/f.txt"
  git -C "$repo" add -A; git -C "$repo" commit -qm "add f"
  git -C "$repo" branch -qf feature
  git -C "$repo" checkout -q feature

  out=$(bash "$SCRIPT" "$repo" match-pass main)
  if [ -z "$out" ]; then pass "merge-base moved under an unchanged base/tree → no match"
  else fail "merge-base moved under an unchanged base/tree → no match (got '$out')"; fi
  rm -rf "$repo"
}

test_match_rejects_changed_tree() {
  local repo out b mb; repo=$(_new_repo)
  b=$(_sha "$repo" main); mb=$(git -C "$repo" merge-base "$b" HEAD)
  _write_pass "$repo" "$(_sha "$repo" HEAD)" "$b $mb $(_bogus_sha 3) $(_bogus_sha 1)"
  out=$(bash "$SCRIPT" "$repo" match-pass main)
  if [ -z "$out" ]; then pass "content changed → no match"
  else fail "content changed → no match (got '$out')"; fi
  rm -rf "$repo"
}

test_match_prefers_identical_over_messages_only() {
  local repo out b mb t; repo=$(_new_repo)
  b=$(_sha "$repo" main); mb=$(git -C "$repo" merge-base "$b" HEAD)
  t=$(git -C "$repo" rev-parse 'HEAD^{tree}')
  # Both on offer. Answering messages-only here would re-review messages that a
  # marker already cleared. Order-independent by construction: the loop returns
  # early on identical and only falls back otherwise.
  _write_pass "$repo" "$(_sha "$repo" feature-a)" "$b $mb $t $(_bogus_sha 1)"
  _write_pass "$repo" "$(_sha "$repo" HEAD)" "$(_sig "$repo" main)"
  out=$(bash "$SCRIPT" "$repo" match-pass main)
  if [ "$out" = "identical" ]; then pass "identical wins over messages-only"
  else fail "identical wins over messages-only (got '$out')"; fi
  rm -rf "$repo"
}

test_match_requires_base() {
  local repo rc=0; repo=$(_new_repo)
  bash "$SCRIPT" "$repo" match-pass >/dev/null 2>&1 || rc=$?
  if [ "$rc" -eq 2 ]; then pass "match-pass without a base → exit 2"
  else fail "match-pass without a base → exit 2 (rc=$rc)"; fi
  rm -rf "$repo"
}

test_match_unresolvable_base() {
  local repo out rc=0; repo=$(_new_repo)
  out=$(bash "$SCRIPT" "$repo" match-pass no-such-ref 2>/dev/null) || rc=$?
  if [ "$rc" -eq 0 ] && [ -z "$out" ]; then pass "unresolvable base → no match, not an error"
  else fail "unresolvable base → no match, not an error (rc=$rc out='$out')"; fi
  rm -rf "$repo"
}

# ── record-pass / record-findings ────────────────────────────────────────────
# The skill used to compute these in its own shell, as `$(git ...)` substitutions
# and a heredoc. A worktree-isolated session refuses both, so the fork could not
# record any verdict there; inside this script the guard never sees them.

test_record_pass_writes_signature() {
  local repo g head out; repo=$(_new_repo); g=$(_git_dir "$repo"); head=$(_sha "$repo" HEAD)
  out=$(bash "$SCRIPT" "$repo" record-pass main)
  if [ "$out" = "$g/pre-pr-review-$head" ] && [ "$(cat "$g/pre-pr-review-$head")" = "$(_sig "$repo" main)" ]; then
    pass "record-pass → HEAD's marker holds the signature, path printed"
  else fail "record-pass → HEAD's marker holds the signature (out='$out')"; fi
  rm -rf "$repo"
}

test_record_pass_round_trips_through_match_pass() {
  local repo out; repo=$(_new_repo)
  bash "$SCRIPT" "$repo" record-pass main >/dev/null
  git -C "$repo" commit -q --amend --no-edit --date=now   # new sha, same content
  out=$(bash "$SCRIPT" "$repo" match-pass main)
  if [ "$out" = "identical" ]; then pass "record-pass then a content-identical amend → identical"
  else fail "record-pass then a content-identical amend → identical (got '$out')"; fi
  rm -rf "$repo"
}

test_record_pass_clears_lineage() {
  local repo g prev; repo=$(_new_repo); g=$(_git_dir "$repo"); prev=$(_sha "$repo" HEAD)
  _write_findings "$repo" "$prev" outstanding
  echo more > "$repo/b.txt"; git -C "$repo" commit -qam b2
  bash "$SCRIPT" "$repo" record-pass main >/dev/null
  if [ ! -f "$g/pre-pr-findings-$prev.json" ]; then pass "record-pass → superseded findings record cleared"
  else fail "record-pass → superseded findings record cleared (it survived)"; fi
  rm -rf "$repo"
}

test_record_pass_unresolvable_base() {
  local repo g rc=0; repo=$(_new_repo); g=$(_git_dir "$repo")
  bash "$SCRIPT" "$repo" record-pass no-such-ref >/dev/null 2>&1 || rc=$?
  if [ "$rc" -eq 2 ] && [ ! -f "$g/pre-pr-review-$(_sha "$repo" HEAD)" ]; then
    pass "record-pass with an unresolvable base → exit 2, no marker"
  else fail "record-pass with an unresolvable base → exit 2, no marker (rc=$rc)"; fi
  rm -rf "$repo"
}

# The hook only tests that HEAD's marker exists, so a pass recorded earlier against
# another base would still open the gate after this failed run. Found in PR review.
test_record_pass_failure_revokes_head_pass() {
  local repo g head rc=0; repo=$(_new_repo); g=$(_git_dir "$repo"); head=$(_sha "$repo" HEAD)
  _write_pass "$repo" "$head" "$(_sig "$repo" main)"
  bash "$SCRIPT" "$repo" record-pass no-such-ref >/dev/null 2>&1 || rc=$?
  if [ "$rc" -eq 2 ] && [ ! -f "$g/pre-pr-review-$head" ]; then
    pass "record-pass that cannot sign → HEAD's earlier pass revoked"
  else fail "record-pass that cannot sign → HEAD's earlier pass revoked (rc=$rc)"; fi
  rm -rf "$repo"
}

test_record_findings_moves_draft() {
  local repo g head draft out; repo=$(_new_repo); g=$(_git_dir "$repo"); head=$(_sha "$repo" HEAD)
  touch "$g/pre-pr-review-$head"            # a pass for this commit must not outlive its findings
  draft=$(bash "$SCRIPT" "$repo" draft-path)
  printf '{"reviewed_sha":"%s","base":"main","findings":[{"file":"f","line":1,"what":"runs `nohup` with $HOME","why":"y"}]}\n' "$head" > "$draft"
  out=$(bash "$SCRIPT" "$repo" record-findings "$draft")
  if [ "$out" = "$g/pre-pr-findings-$head.json" ] && grep -qF '`nohup` with $HOME' "$out" \
     && [ ! -f "$draft" ] && [ ! -f "$g/pre-pr-review-$head" ]; then
    pass "record-findings → draft moved verbatim, HEAD's pass cleared, path printed"
  else fail "record-findings → draft moved verbatim, HEAD's pass cleared (out='$out')"; fi
  rm -rf "$repo"
}

# The draft sits in the working tree, so a rejected one left behind is review text
# that a later `git add -A` puts into the PR. Found in pre-PR review of this branch.
test_record_findings_rejects_other_sha() {
  local repo g draft rc=0; repo=$(_new_repo); g=$(_git_dir "$repo")
  draft=$(bash "$SCRIPT" "$repo" draft-path)
  printf '{"reviewed_sha":"%s","base":"main","findings":[]}\n' "$(_sha "$repo" feature-a)" > "$draft"
  bash "$SCRIPT" "$repo" record-findings "$draft" >/dev/null 2>&1 || rc=$?
  if [ "$rc" -eq 2 ] && [ -z "$(find "$g" -maxdepth 1 -name 'pre-pr-findings-*')" ] && [ ! -f "$draft" ]; then
    pass "record-findings whose reviewed_sha is not HEAD → exit 2, nothing recorded, draft removed"
  else fail "record-findings whose reviewed_sha is not HEAD → exit 2, draft removed (rc=$rc)"; fi
  rm -rf "$repo"
}

# A review cut off between Write and record-findings still leaves the draft, so
# git must ignore it before it is written. Keyed to HEAD so it cannot be a file the
# repository already has. Found in pre-PR review and PR review of this branch.
test_draft_path_is_git_ignored() {
  local repo out exclude; repo=$(_new_repo)
  out=$(bash "$SCRIPT" "$repo" draft-path)
  bash "$SCRIPT" "$repo" draft-path >/dev/null      # a second call adds nothing
  echo '{}' > "$out"
  exclude=$(git -C "$repo" rev-parse --git-path info/exclude)
  case "$exclude" in /*) ;; *) exclude="$repo/$exclude" ;; esac
  if [ "$out" = "$(git -C "$repo" rev-parse --show-toplevel)/pre-pr-findings-draft-$(_sha "$repo" HEAD).json" ] \
     && [ -z "$(git -C "$repo" status --porcelain)" ] \
     && [ "$(grep -cxF '/pre-pr-findings-draft-*.json' "$exclude")" -eq 1 ]; then
    pass "draft-path → prints a HEAD-keyed draft path, which git ignores, excluded once"
  else fail "draft-path → prints a HEAD-keyed draft path, which git ignores (out='$out')"; fi
  rm -rf "$repo"
}

# Only the exact path draft-path printed may be consumed: the path comes from the
# model, and a wrong one must never move or delete a real file. Found in PR review.
test_record_findings_refuses_path_outside_repo() {
  local repo dir name rc=0; repo=$(_new_repo); dir=$(mktemp -d)
  name=$(basename "$(bash "$SCRIPT" "$repo" draft-path)")
  printf '{"reviewed_sha":"%s"}\n' "$(_sha "$repo" HEAD)" > "$dir/$name"
  bash "$SCRIPT" "$repo" record-findings "$dir/$name" >/dev/null 2>&1 || rc=$?
  if [ "$rc" -eq 2 ] && [ -f "$dir/$name" ]; then
    pass "record-findings on a same-named file outside the repo → exit 2, file untouched"
  else fail "record-findings on a same-named file outside the repo → exit 2, untouched (rc=$rc)"; fi
  rm -rf "$repo" "$dir"
}

test_record_findings_refuses_symlink() {
  local repo dir draft rc=0; repo=$(_new_repo); dir=$(mktemp -d)
  draft=$(bash "$SCRIPT" "$repo" draft-path)
  printf '{"reviewed_sha":"%s"}\n' "$(_sha "$repo" HEAD)" > "$dir/real.json"
  ln -s "$dir/real.json" "$draft" 2>/dev/null || { echo "  SKIP  symlinked draft (platform cannot create links)"; rm -rf "$repo" "$dir"; return; }
  bash "$SCRIPT" "$repo" record-findings "$draft" >/dev/null 2>&1 || rc=$?
  if [ "$rc" -eq 2 ] && [ -f "$dir/real.json" ]; then
    pass "record-findings on a symlinked draft → exit 2, link target untouched"
  else fail "record-findings on a symlinked draft → exit 2, target untouched (rc=$rc)"; fi
  rm -rf "$repo" "$dir"
}

test_record_findings_missing_draft() {
  local repo rc=0; repo=$(_new_repo)
  bash "$SCRIPT" "$repo" record-findings /no/such/draft.json >/dev/null 2>&1 || rc=$?
  if [ "$rc" -eq 2 ]; then pass "record-findings with no draft file → exit 2"
  else fail "record-findings with no draft file → exit 2 (rc=$rc)"; fi
  rm -rf "$repo"
}

test_unknown_action() {
  local repo rc=0; repo=$(_new_repo)
  bash "$SCRIPT" "$repo" frobnicate >/dev/null 2>&1 || rc=$?
  if [ "$rc" -eq 2 ]; then pass "unknown action → exit 2"
  else fail "unknown action → exit 2 (rc=$rc)"; fi
  rm -rf "$repo"
}

echo "select-findings"
test_select_no_records
test_select_ancestor_record
test_select_prefers_head_lineage_over_sort_order
test_select_prefers_nearest_ancestor_record
test_select_ignores_other_branch_only
test_select_skips_malformed_sha
echo
echo "match-pass"
test_match_no_markers
test_match_empty_legacy_marker
test_match_identical_content
test_match_messages_only
test_match_rejects_moved_base
test_match_rejects_moved_merge_base
test_match_rejects_changed_tree
test_match_prefers_identical_over_messages_only
test_match_requires_base
test_match_unresolvable_base
echo
echo "clear-lineage"
test_clear_supersedes_own_pass_marker
test_clear_spares_other_branch_pass_marker
test_clear_spares_other_branch_findings
test_clear_spares_stacked_parent_tip
test_clear_removes_head_own_marker
test_clear_reaps_amended_away_marker
test_clear_reaps_marker_for_missing_commit
test_clear_spares_unattributable_files
test_clear_handles_path_with_space
echo
echo "record-pass / record-findings"
test_record_pass_writes_signature
test_record_pass_round_trips_through_match_pass
test_record_pass_clears_lineage
test_record_pass_unresolvable_base
test_record_pass_failure_revokes_head_pass
test_record_findings_moves_draft
test_record_findings_rejects_other_sha
test_record_findings_refuses_path_outside_repo
test_record_findings_refuses_symlink
test_draft_path_is_git_ignored
test_record_findings_missing_draft
echo
echo "fail-closed"
test_no_args_deletes_nothing
test_not_a_git_repo
test_unknown_action

echo
echo "Results: $PASS/$((PASS+FAIL)) passed"
[ "$FAIL" -eq 0 ]
