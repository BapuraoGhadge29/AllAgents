# Argument recovery

Read this when the invocation did not arrive as two clean tokens (base, then
repository path). Invocation forms themselves are in `examples.md`.

## The shapes that arrive

A third of real invocations are not canonical:

| Shape | Example | Recovered by |
|---|---|---|
| `key=value` pair | `base=develop dir=/path` | rule 2 |
| prose with the path embedded | a sentence naming `/path/to/repo` | rule 3 |
| reversed pair | `/path/to/repo develop` | rule 3 — it scans by position-independent *shape*, not argument index |
| swapped pair of two branch names | `feature/MXTS-1234-thing master` | rule 4 (no path present) |
| a single token | `develop` | rule 4 (no path present) |

The first three still contain the path. The last two contain none at all, so only
the hook's hand-off can supply it.

## Resolution order

Resolve in this order:

1. Strip surrounding quotes from the whole argument string.
2. If the text contains `repo=`, `dir=` or `base=`, take those values directly.
3. Otherwise `repo` is the **longest substring starting at a `/` or `~` that names
   an existing directory** — scanned anywhere in the string, not just the second
   token. Expand `~` before testing, and extend the candidate across whitespace
   while it still names a directory, so a path containing spaces survives. This
   recovers both the swapped pair and the prose form.
4. If rules 2 and 3 found no path, read the **hand-off** the hook wrote when it
   denied the PR — see "Rule 4 in detail: the hook's hand-off" below. It is
   single-use, expiring, and only usable while exactly one request is live.
5. `base` is the first remaining token that is not part of `repo`. Resolve it
   against the repository, trying the bare token and then `origin/<token>`:

   ```bash
   git -C "$repo" rev-parse --verify --quiet "<token>^{commit}" ||
   git -C "$repo" rev-parse --verify --quiet "origin/<token>^{commit}"
   ```

   The `origin/` fallback is not optional. A PR onto `release/v2026.35.0` from a
   checkout that never had that branch locally resolves only as
   `origin/release/v2026.35.0`; treating it as unresolvable would default the base
   to `main` and diff in everything merged since the branches diverged — the exact
   failure Step 2 stops for. Release branches are a normal base here.
6. When no candidate resolves either way: with **exactly one** candidate token,
   keep it as `$base` and let Step 2 stop on it — the caller named a base, and that
   it does not exist is a finding, not something to silently replace. With
   **several** tokens (a prose invocation), none is a base claim: leave `$base`
   empty and let Step 2 resolve the default.

## Rule 4 in detail: the hook's hand-off

The hook wrote the repository and base it had already resolved when it denied the
PR, so this is a recorded fact rather than a guess — but it is not proof of
ownership: nothing here can check the request was written for *this* invocation.
The safety rests entirely on the single-live-request rule below, which separates
sessions and repositories, not successive attempts on one repository, where the
newer request supersedes the older. Prefer the arguments whenever they carry a path.

```bash
dir="${CLAUDE_PRE_PR_REVIEW_DIR:-$HOME/.claude/pre-pr-review}"
ls "$dir"/request-*.json 2>/dev/null   # expect exactly one
handoff=<the single path listed>
```

Use it only when **exactly one** file is listed. Read `repo`, `base` and `head`
from it, and confirm `head` still matches `git -C "$repo" rev-parse HEAD`.

- **Several files listed** — two PR attempts are in flight and nothing here
  identifies which is yours. Stop and say so.
- **`head` no longer matches** — the hand-off is stale. Stop rather than review a
  commit nobody asked about.
- **Older than the hook's `REQUEST_TTL_SECONDS`** (30 minutes at the time of
  writing — read the constant rather than trusting this number) — it belongs to an
  abandoned attempt, not to you. Delete it and stop. Do not rely on the hook having
  expired it: the hook prunes when it runs, and an abandoned attempt is followed by
  no hook run at all.

A hand-off is **single-use**. Delete it as soon as you have bound `repo` from it,
before reviewing anything:

```bash
rm -f "$handoff"
```

Left on disk it outlives the PR it belongs to, and the next review arriving without
a usable argument would find it, see a HEAD that still matches because that
repository never moved, and review a repository nobody asked about — the
MXTS-80544 failure through a different door.
