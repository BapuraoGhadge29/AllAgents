# Examples

The usual trigger is the hook's denial: `gh pr create` is denied naming a base and
a directory, Claude loads this skill with those two values, reviews `$base...HEAD`
in that repo, records the pass, and retries the denied command.

- `/developer:reviewing-pre-pr main /path/to/worktree` — reviews `main...HEAD` in
  that worktree, then records the pass or reports findings. Use this form whenever
  the PR targets a checkout other than the one the session is working in, which is
  most of the time.
- `/developer:reviewing-pre-pr develop /path/to/worktree` — the same against a
  different base.

Other shapes no longer fail outright: the resolution rules in
`argument-recovery.md` recover them, and its rule 4 falls back to the hook's
hand-off when no path is present at all. That recovery is
a **safety net, not a licence** — it costs extra work, and a path appearing nowhere
in the arguments can only be recovered while exactly one hand-off is live. Pass the
two tokens when you have them.
