# Troubleshooting

## The review asked a question instead of running

Cause: the fork treated a missing or surprising input as something to clarify. It
has no one to clarify with, so the invocation ends with no verdict and
`gh pr create` stays blocked.

Fix: re-invoke as `/developer:reviewing-pre-pr <base> <repo>` — two tokens, nothing
else. Prose is recoverable (Step 0 rule 3 scans it for a path) but it is not the
reliable form, and answering a fork that has already ended reaches nobody.
Re-invoke rather than reply. Do not hand-write a marker either — that records a
pass nothing earned.

## The review covered the wrong repository

Cause: `$repo` did not survive the invocation — usually because something other
than a bare path was passed — so the review fell back to the session's working
directory. The tell-tale signs are findings in files the branch never touched, and
commits already merged into the target's default branch.

Fix: re-run with the repository directory as the **second** argument, after the
base. Quote it if it contains whitespace. Treat the earlier verdict as void, and
check whether it wrote a marker into the wrong repository's git directory
(`pre-pr-review-*`); delete it if so. Check that repository for an unrequested pull
request as well.

Arguments themselves are **not** the problem: a base and a repository path, passed
as two clean tokens, reach the forked context and are honoured. Verified by
invoking the review against one repository from a session working in another — it
scoped correctly and left the session's repository untouched.

## `gh pr create` is still blocked after a clean review

Cause: the marker was not written, or `HEAD` moved after the review (a new commit,
an amend, or a rebase).

Fix: check `git rev-parse HEAD` against the marker filenames in the git directory.
Re-run the review if `HEAD` has moved; report the failure to the developer rather
than creating the marker by hand.

## There is no diff to review

Cause: `$base` resolved to a branch that already contains every local commit.

Fix: confirm the base branch is right. If it is, record the pass — there is
genuinely nothing to review. In verification mode an empty delta means the
opposite: nothing was fixed, so re-report the findings and do not record a pass.

## The diff is too large to review in one pass

Cause: a very large or wide-ranging change.

Fix: review the highest-risk files first (service boundaries, auth, money, data
migrations), then the rest. Report partial coverage explicitly instead of recording
a pass that did not cover everything.
