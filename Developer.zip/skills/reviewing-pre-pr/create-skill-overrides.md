# Accepted overrides — reviewing-pre-pr

## `disable-model-invocation` omitted (model-invocable from day one)

**Repo default:** new skills under `plugins/` should ship with
`disable-model-invocation: true` until their trigger surface is validated.

**Override reason (strong):** the skill is a required link in a documented
multi-skill chain — best-practices.md, "part of a documented multi-step workflow
where auto-loading is required for the chain to work".

`plugins/developer/hooks/pre-pr-review.py` denies `gh pr create` with a message
instructing Claude to run `/developer:reviewing-pre-pr`. With the flag set, Claude
could not act on that instruction and every PR would need the developer to type
the command by hand. That is exactly the dead-end MXTS-77121 documented on the
`ci-monitor-review-comments` rule: a directive ordering an action the flag makes
impossible. The flag would recreate it here.

**Side effects:** one marker file in the repository's git directory
(`pre-pr-review-<sha>`), never committed, cleared on each new pass. The skill makes
no network calls, opens nothing, and writes nothing to the working tree.

**Spurious-trigger control:** the description names the gate and PR creation
specifically rather than the generic word "review", so it does not compete with
`/developer:reviewing-code-quality` or `/code-review` for ordinary review requests.

## `user-invocable: false` was tried and reverted

Not an override — a record, so it is not attempted again without the blocker
being fixed first.

The intent was for the gate to run end to end with no human in the loop, which
also kept a command out of the `/` menu that nobody should need to type. It was
reverted because **automatic invocation does not currently work**: the forked
context arrives with no `$base`, no `$repo` and no task, and stalls asking what
to do. That happens with arguments passed explicitly, so it is argument delivery
into the fork rather than anything in this file.

While that holds, running the skill by hand is the only reliable path, and
`user-invocable: false` removes it — leaving `gh pr create` denied with no way
through and no clue that the flag is the cause. Revisit once a forked invocation
demonstrably receives its arguments.
