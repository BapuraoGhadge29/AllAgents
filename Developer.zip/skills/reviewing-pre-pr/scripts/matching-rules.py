"""Print the project rules a review must apply to a change.

Usage: <changed file paths, one per line> | matching-rules.py <repo>

A rule applies when it has no `paths:` or one of its `paths:` globs matches a
changed file. Rules are read from `.claude/rules/` in the repo and in every folder
above it, as Claude Code loads them; a rule found nearer the repo wins. Reviews
inline this output instead of relying on rules loading on Read, which a diff-only
review may never trigger, nor on a forked skill loading them at all.
"""
import os
import re
import sys

# `**/` spans any folders, including none, so `**/*.java` also matches `Demo.java`.
GLOB_TOKENS = {"**/": "(?:.*/)?", "**": ".*", "*": "[^/]*", "?": "[^/]"}
FRONTMATTER = re.compile(r"\A---\n(.*?)\n---\n?(.*)\Z", re.DOTALL)
PATHS_BLOCK = re.compile(r"^paths:[ \t]*\n((?:[ \t]*-[ \t].*\n?)+)", re.MULTILINE)


def glob_regex(pattern):
    tokens = re.split(r"(\*\*/|\*\*|\*|\?)", pattern)
    return re.compile("".join(GLOB_TOKENS.get(t, re.escape(t)) for t in tokens) + r"\Z")


def split_rule(text):
    """Return (paths, body); paths is empty for a rule that applies everywhere."""
    match = FRONTMATTER.match(text.replace("\r\n", "\n"))
    if not match:
        return [], text.strip()
    block = PATHS_BLOCK.search(match.group(1) + "\n")
    items = block.group(1).splitlines() if block else []
    paths = [item.split("-", 1)[1].strip().strip("\"'") for item in items]
    return paths, match.group(2).strip()


def folders_up(repo):
    """The repo and every folder above it, nearest first."""
    folder = os.path.abspath(repo)
    while True:
        yield folder
        parent = os.path.dirname(folder)
        if parent == folder:
            return
        folder = parent


def rules_in(folder):
    """Yield (tag, file) for each rule under <folder>/.claude/rules, sorted."""
    root = os.path.join(folder, ".claude", "rules")
    # Repos set up before rules were copied still link <plugin>/ to the plugin.
    for dirpath, dirnames, filenames in os.walk(root, followlinks=True):
        dirnames.sort()
        for name in sorted(n for n in filenames if n.endswith(".md")):
            path = os.path.join(dirpath, name)
            yield os.path.relpath(path, root)[:-3].replace(os.sep, "/"), path


def applies(paths, changed):
    return not paths or any(glob_regex(p).match(f) for p in paths for f in changed)


def matching_rules(repo, changed):
    """Yield (tag, file, body) per applicable rule; a nearer copy hides a farther one."""
    seen = set()
    for folder in folders_up(repo):
        for tag, path in rules_in(folder):
            if tag in seen:
                continue
            seen.add(tag)
            with open(path, encoding="utf-8") as f:
                paths, body = split_rule(f.read())
            if applies(paths, changed):
                yield tag, path, body


def main():
    changed = [line.strip().replace("\\", "/") for line in sys.stdin if line.strip()]
    for tag, path, body in matching_rules(sys.argv[1], changed):
        print(f"## [rule: {tag}] ({path})\n\n{body}\n")


if __name__ == "__main__":
    main()
