#!/usr/bin/env bash
# Pre-PR marker bookkeeping for the reviewing-pre-pr skill.
#
#   pre-pr-markers.sh <repo> select-findings
#       Prints the path of the findings record belonging to HEAD's lineage —
#       reviewed_sha an ancestor of HEAD, nearest one first — or nothing. Never
#       guesses: picking by filename order reads whichever sha sorts first, which
#       is another branch's record, or a stacked parent's, as often as HEAD's own.
#
#   pre-pr-markers.sh <repo> match-pass <base>
#       Prints what an earlier pass still establishes about HEAD's content, or
#       nothing when no pass covers it:
#         identical      same base commit, same merge-base, same tree, same
#                        commit messages — the reviewed content is
#                        byte-identical, so the verdict holds and no diff
#                        needs reading again.
#         messages-only  same base commit, merge-base and tree, different
#                        messages — the diff is unchanged, so only the
#                        messages need review.
#       `base...HEAD` is really `merge-base(base,HEAD)...HEAD`, so the base
#       commit and tree alone do not fix that diff: a rewrite that lands HEAD
#       on a different ancestor of the same base commit moves the merge-base,
#       and so the diff, without changing either. A pass marker records
#       `<base_sha> <merge_base_sha> <tree_sha> <messages_sha>`; an empty one
#       (written before this existed) establishes nothing and is skipped,
#       which leaves the full review as the default it always was.
#
#   pre-pr-markers.sh <repo> clear-lineage
#       Deletes the markers HEAD's own lineage has superseded, and the ones
#       abandoned by every branch. Spares any marker that is still some other
#       branch's tip — including a stacked parent branch, whose tip is also an
#       ancestor of HEAD. One .git is shared by every branch, so a repo-wide
#       sweep destroys review state the developer is coming back to.
#       HEAD's own marker is never spared: the caller rewrites it immediately.
#
#   pre-pr-markers.sh <repo> record-pass <base>
#       Runs clear-lineage, then writes HEAD's pass marker holding the
#       match-pass signature, and prints its path. Exit 2 when <base> does not
#       resolve, with HEAD's earlier pass revoked: the hook trusts any marker.
#
#   pre-pr-markers.sh <repo> draft-path
#       Adds /pre-pr-findings-draft-*.json to the repo's info/exclude (once),
#       then prints <toplevel>/pre-pr-findings-draft-<HEAD sha>.json: where to
#       Write the draft.
#
#   pre-pr-markers.sh <repo> record-findings <the draft-path path>
#       Runs clear-lineage, then moves the draft to HEAD's findings record and
#       prints its path. Exit 2 for any other path or a symlink, and exit 2 with
#       the draft deleted when its reviewed_sha is not HEAD.
#
# The two record actions exist for worktree-isolated sessions: their guard
# refuses `$(git ...)` and heredocs in the skill's own shell, but not here.
#
# Both markers are keyed to a full 40-hex commit sha, which is what makes the
# ownership question answerable at all.
#
# Deletions go through `find` plus a per-file `rm`, never a glob: zsh aborts a
# whole command when any glob matches nothing, so `rm -f a-* b-*` removes neither
# when only one pattern matches — and "findings recorded, no pass marker yet" is
# exactly that case.
set -uo pipefail

repo="${1:-}"
action="${2:-}"

# Fail closed. Without a scoped repository there is no HEAD to judge ownership
# against, and this script deletes files.
if [ -z "$repo" ] || [ -z "$action" ]; then
  echo "usage: pre-pr-markers.sh <repo> select-findings|match-pass <base>|clear-lineage|record-pass <base>|draft-path|record-findings <draft>" >&2
  exit 2
fi
GIT=(git -C "$repo")
if ! git_dir=$("${GIT[@]}" rev-parse --absolute-git-dir 2>/dev/null); then
  echo "pre-pr-markers: not a git repository: $repo" >&2
  exit 2
fi
if ! head_sha=$("${GIT[@]}" rev-parse --verify --quiet HEAD 2>/dev/null); then
  echo "pre-pr-markers: no HEAD commit in $repo" >&2
  exit 2
fi

# Filename -> sha, or empty when the name is not one of ours. A file we cannot
# attribute is never deleted: the directory holds other tools' state too.
_sha_of() {
  local base="${1##*/}"
  case "$base" in
    pre-pr-review-*)        printf '%s' "${base#pre-pr-review-}" ;;
    pre-pr-findings-*.json) local s="${base#pre-pr-findings-}"; printf '%s' "${s%.json}" ;;
  esac
}

_is_sha() { [ ${#1} -eq 40 ] && [ -z "${1//[0-9a-f]/}" ]; }

# Sets base_sha, mb_sha, tree_sha and msg_sha for HEAD against base_ref; the four
# together fix the reviewed `base...HEAD` diff. Returns 1 when any cannot be read.
_signature() {
  local base_ref="$1"
  base_sha=$("${GIT[@]}" rev-parse --verify --quiet "$base_ref^{commit}" 2>/dev/null) || return 1
  tree_sha=$("${GIT[@]}" rev-parse --verify --quiet 'HEAD^{tree}' 2>/dev/null) || return 1
  # The base COMMIT, not the ref name: `develop` moving changes the reviewed
  # diff without changing HEAD, and a verdict reached against the old one says
  # nothing about the new.
  #
  # `base...HEAD` is really `merge-base(base,HEAD)...HEAD`, so base_sha and
  # tree_sha alone do not fix it: a rewrite that lands HEAD on a different
  # ancestor of the same base commit moves the merge-base — and so the diff —
  # while leaving base_sha and tree_sha exactly as they were. Track the
  # merge-base itself rather than trusting base_sha to stand in for it.
  mb_sha=$("${GIT[@]}" merge-base "$base_sha" HEAD 2>/dev/null) || return 1
  _is_sha "${mb_sha:-}" || return 1
  # `pipefail` (set above) makes this assignment's exit status reflect either
  # command's failure, not just hash-object's — hash-object still succeeds (on
  # empty input) when `git log` fails, so without pipefail a broken log would
  # silently hash to a valid-looking sha instead of failing the match.
  msg_sha=$("${GIT[@]}" log --format=%B "$base_sha..HEAD" 2>/dev/null | "${GIT[@]}" hash-object --stdin 2>/dev/null) || return 1
  _is_sha "${msg_sha:-}" || return 1
}

# Where the findings draft is written. Keyed to HEAD, so it can never be a file
# the repository already has; record-findings consumes exactly this path.
_draft_path() {
  local toplevel
  toplevel=$("${GIT[@]}" rev-parse --show-toplevel 2>/dev/null) || return 1
  printf '%s/pre-pr-findings-draft-%s.json' "$toplevel" "$head_sha"
}

_clear_lineage() {
  tips=$("${GIT[@]}" for-each-ref --format='%(objectname)' refs/heads 2>/dev/null)
  while IFS= read -r f; do
    sha=$(_sha_of "$f")
    _is_sha "$sha" || continue
    if ! "${GIT[@]}" cat-file -e "$sha^{commit}" 2>/dev/null; then
      rm -f "$f" && printf 'cleared (commit gone): %s\n' "${f##*/}"
    elif [ "$sha" != "$head_sha" ] && printf '%s\n' "$tips" | grep -qxF "$sha"; then
      : # Some branch's tip, and not ours: that marker is its live verdict.
        # Checked before the ancestor rule on purpose — with stacked branches
        # the parent branch's tip IS an ancestor of HEAD, and deleting it costs
        # that branch a full re-review the moment it is checked out again.
    elif "${GIT[@]}" merge-base --is-ancestor "$sha" HEAD 2>/dev/null; then
      rm -f "$f" && printf 'cleared (superseded on this branch): %s\n' "${f##*/}"
    elif [ -z "$("${GIT[@]}" branch --contains "$sha" 2>/dev/null)" ]; then
      # Reachable object, but no branch holds it: an amend or rebase left it
      # behind. is-ancestor alone never reaps these, which is how they pile up.
      rm -f "$f" && printf 'cleared (abandoned by every branch): %s\n' "${f##*/}"
    fi
  done < <(find "$git_dir" -maxdepth 1 \
    \( -name 'pre-pr-review-*' -o -name 'pre-pr-findings-*.json' \) 2>/dev/null | sort)
}

case "$action" in
  select-findings)
    # Nearest wins, not first-found. Several records can be ancestors of HEAD at
    # once — a stacked parent branch keeps its own, and clear-lineage spares it —
    # and taking the first in name order would verify the parent's findings while
    # this branch's own went unchecked. Distance 0 is HEAD's own record.
    best=""; best_dist=""
    while IFS= read -r f; do
      sha=$(sed -n 's/.*"reviewed_sha"[^"]*"\([^"]*\)".*/\1/p' "$f" | head -1)
      _is_sha "$sha" || continue
      "${GIT[@]}" merge-base --is-ancestor "$sha" HEAD 2>/dev/null || continue
      dist=$("${GIT[@]}" rev-list --count "$sha..HEAD" 2>/dev/null) || continue
      [ -n "$dist" ] || continue
      if [ -z "$best_dist" ] || [ "$dist" -lt "$best_dist" ]; then
        best="$f"; best_dist="$dist"
      fi
    done < <(find "$git_dir" -maxdepth 1 -name 'pre-pr-findings-*.json' 2>/dev/null | sort)
    [ -n "$best" ] && printf '%s\n' "$best"
    exit 0
    ;;
  match-pass)
    base_ref="${3:-}"
    if [ -z "$base_ref" ]; then
      echo "usage: pre-pr-markers.sh <repo> match-pass <base>" >&2
      exit 2
    fi
    # An unresolvable base is not an error worth failing on — it simply means no
    # pass can be matched, and the caller reviews in full.
    _signature "$base_ref" || exit 0

    # `identical` wins over `messages-only` wherever both are on offer, so every
    # marker is read before answering.
    answer=""
    while IFS= read -r f; do
      sha=$(_sha_of "$f")
      _is_sha "$sha" || continue
      IFS=' ' read -r m_base m_mb m_tree m_msg _rest < "$f" 2>/dev/null || continue
      _is_sha "${m_base:-}" || continue
      _is_sha "${m_mb:-}" || continue
      _is_sha "${m_tree:-}" || continue
      _is_sha "${m_msg:-}" || continue
      [ "$m_base" = "$base_sha" ] || continue
      [ "$m_mb" = "$mb_sha" ] || continue
      [ "$m_tree" = "$tree_sha" ] || continue
      if [ "$m_msg" = "$msg_sha" ]; then
        printf 'identical\n'
        exit 0
      fi
      answer="messages-only"
    done < <(find "$git_dir" -maxdepth 1 -name 'pre-pr-review-*' 2>/dev/null | sort)
    [ -n "$answer" ] && printf '%s\n' "$answer"
    exit 0
    ;;
  clear-lineage)
    _clear_lineage
    exit 0
    ;;
  record-pass)
    base_ref="${3:-}"
    if [ -z "$base_ref" ]; then
      echo "usage: pre-pr-markers.sh <repo> record-pass <base>" >&2
      exit 2
    fi
    # The hook only tests that HEAD's marker exists, so a pass recorded earlier
    # against another base would still open the gate: revoke it before failing.
    if ! _signature "$base_ref"; then
      rm -f "$git_dir/pre-pr-review-$head_sha"
      echo "pre-pr-markers: cannot sign the reviewed diff against base: $base_ref; HEAD's pass revoked" >&2
      exit 2
    fi
    _clear_lineage >&2
    marker="$git_dir/pre-pr-review-$head_sha"
    printf '%s %s %s %s\n' "$base_sha" "$mb_sha" "$tree_sha" "$msg_sha" > "$marker" || exit 2
    printf '%s\n' "$marker"
    exit 0
    ;;
  draft-path)
    # The draft is written in the working tree (the only place Write may reach in
    # an isolated session), so ignore it locally first: a review cut off before
    # record-findings must not leave review text for `git add -A` to commit.
    draft=$(_draft_path) || exit 2
    exclude=$("${GIT[@]}" rev-parse --git-path info/exclude 2>/dev/null) || exit 2
    case "$exclude" in /*) ;; *) exclude="${draft%/*}/$exclude" ;; esac
    if ! grep -qxF '/pre-pr-findings-draft-*.json' "$exclude" 2>/dev/null; then
      mkdir -p "${exclude%/*}" && printf '/pre-pr-findings-draft-*.json\n' >> "$exclude" || exit 2
    fi
    printf '%s\n' "$draft"
    exit 0
    ;;
  record-findings)
    draft="${3:-}"
    # The path comes from the model; consuming only the exact path draft-path
    # printed, and never through a link, keeps a wrong one from moving or
    # deleting a real file.
    if [ "$draft" != "$(_draft_path)" ] || [ -L "$draft" ] || [ ! -f "$draft" ]; then
      echo "pre-pr-markers: not the draft-path draft, or not a regular file: ${draft:-<none>}" >&2
      exit 2
    fi
    # A record keyed to HEAD but naming another commit would have the next review
    # verify the wrong delta, so a mismatch is refused rather than corrected. The
    # draft is deleted either way: left in the working tree, `git add -A` commits it.
    reviewed=$(sed -n 's/.*"reviewed_sha"[^"]*"\([^"]*\)".*/\1/p' "$draft" | head -1)
    if [ "$reviewed" != "$head_sha" ]; then
      rm -f "$draft"
      echo "pre-pr-markers: draft reviewed_sha '$reviewed' is not HEAD $head_sha; draft deleted" >&2
      exit 2
    fi
    _clear_lineage >&2
    record="$git_dir/pre-pr-findings-$head_sha.json"
    mv "$draft" "$record" || exit 2
    printf '%s\n' "$record"
    exit 0
    ;;
  *)
    echo "pre-pr-markers: unknown action: $action" >&2
    exit 2
    ;;
esac
