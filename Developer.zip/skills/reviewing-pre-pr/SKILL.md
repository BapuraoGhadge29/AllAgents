---
name: reviewing-pre-pr
description: "Reviews the commits a pull request is about to contain and records the pass that unblocks `gh pr create`. Use when opening a pull request, or when the pre-PR hook denies PR creation asking for a \"pre-PR review\" — then retry the blocked command.\n"
argument-hint: "[base-branch] [repo-dir]"
context: fork
background: false
model: opus
effort: low
allowed-tools:
- Bash
- Read
- Write
- Grep
- Glob
---

# Reviewing Pre PR

Reviews the commits between the base branch and `HEAD`, then records a pass for the
exact commit reviewed. `plugins/developer/hooks/pre-pr-review.py` blocks
`gh pr create` until that record exists. Runs forked on purpose: the review must
judge the diff on its own merits, not inherit the conversation that produced it.

## Instructions

**Start the review immediately and carry it to a verdict. Never ask what to do.**
The fork has no conversation history and no user attached, so a question reaches
nobody — the invocation simply ends, and the developer is left with a still-blocked
`gh pr create` and no verdict. Report a missing target as a finding; never turn it
into a question, and never into a guess.

Stop early only for these, all findings rather than uncertainty: no repository can
be recovered from the arguments or the hand-off, more than one hand-off is live so
none is provably yours, the hand-off's HEAD no longer matches (Step 0), `$repo` is
not a git repository (Step 1), a supplied `$base` does not exist (Step 2), or the
review found issues (Step 4). Otherwise decide and continue.

### Step 0: Recover `base` and `repo` from the invocation

Both values arrive as **raw text in the arguments you were invoked with**. The
canonical form is two whitespace-separated tokens — base first, repository path
second — and that is what the hook's deny message prints.

Callers do not reliably produce it — a third of real invocations arrive as a
`key=value` pair, prose with the path embedded, a swapped pair, or a single token.
**When the arguments are not exactly two clean tokens, recover them by following
`${CLAUDE_SKILL_DIR}/references/argument-recovery.md`** rather than stopping: an
avoidable stop costs a full review round-trip, and that retry is the main reason
this gate feels slow.

Recovering a path from the arguments or the hand-off is **not** the same as
defaulting to the session's working directory. Never do the latter: `repo` must come
from the text you were invoked with or the hook's hand-off, and if neither names an
existing directory, stop and name the value you were given (MXTS-80544).

State what you bound and where each value came from before reviewing — that line is
what makes a misdirected run visibly different from a correct one:

```
repo=<path> (from argument | key=value | scan | hook hand-off)
base=<ref>  (from argument | origin/HEAD | default)
```

Do not expect frontmatter `$name` substitution to have filled these in. It does not
run when the model invokes this skill rather than the developer typing it as a
slash command, which left both empty and made the gate unusable (MXTS-80599).

### Step 1: Scope every git command to the repository under review

**When `$repo` is still empty after Step 0, stop and report that the target was not
received.** Never substitute the working directory: only the hook knows which
repository the PR targets, and it puts the path in its deny message. Guessing
produces a confident verdict about unrelated code and a pass marker in a repository
nobody asked about — worse than no review at all.

Run **every** git command below as its own plain call, `git -C <repo> …`, with the
path written out in full and quoted — never a bare `git`, and never git behind a
variable, an array or a `$(…)`. Below, `<repo>`, `<base>` and `<sha>` mean "write
the value out", not shell variables:

```bash
git -C '/abs/path/to/repo' rev-parse --show-toplevel
```

Each Bash call is a fresh shell, so a variable set in one is gone in the next. And
a worktree-isolated session refuses any command whose git it cannot verify —
`GIT=(git -C "$repo")` then `"${GIT[@]}"`, `HEAD_SHA=$(git …)`, array-built
pathspecs, `git … && base=…` — with "names git in a form too complex to verify".
Read a value from one call's output and write it into the next; multi-step git
work lives in `scripts/pre-pr-markers.sh`, whose insides the guard does not check.

An erroring git command invites a retry without `-C`, which *does* land the review
on the session's repository. **Never retry a failed `git -C` without `-C`**: that
failure means the target is wrong, not that the scoping is in the way.

Use `git -C`, not `cd`: a forked context cannot always change its working directory
(worktree isolation pins it), so a `cd` can silently no-op.

State the target before judging anything, and in the final verdict — toplevel
(`rev-parse --show-toplevel`), project (`remote get-url origin`) and branch
(`rev-parse --abbrev-ref HEAD`), each via `git -C <repo>`, and each named with **where
it came from**. A misdirected review otherwise reads exactly like a correct one:
clean and confident, its only tells a file list nobody checks and a marker nobody
was looking at.

When `$repo` was supplied it is **authoritative — proceed with it**. The working
directory will usually be a different repository; that is expected, and the whole
reason `-C` is used. Stop only when the resolved toplevel is not the repository the
developer named — a `$repo` that does not exist or is not a git repository.

### Step 2: Collect the pending changes

`$base` is the PR's base branch. When empty, resolve it via
`git -C <repo> symbolic-ref --short refs/remotes/origin/HEAD` — keep the full remote
ref, since the default branch may exist only as one — then the first of `develop`,
`main`, `master` that exists.

Whether supplied or resolved, confirm the base exists before diffing against it:

```bash
git -C <repo> rev-parse --verify --quiet '<base>^{commit}'
```

When a supplied `$base` does not exist, **stop and report that**. Never substitute
another branch: a base behind the real one makes `$base...HEAD` diff from the
merge-base and pull in everything merged since the branches diverged, so other
people's merged work gets reviewed as this PR's.

A base that exists can still be wrong. A local `main` that has not been pulled sits
behind `origin/main` and inflates the diff the same way. The PR merges into the
*remote* branch, so prefer the remote-tracking ref when one exists — when this
prints a sha, use `origin/<base>` as the base from here on:

```bash
git -C <repo> rev-parse --verify --quiet 'origin/<base>^{commit}'
```

Skip that when `$base` already names a remote ref.

**First ask whether an earlier pass already covers this content.** A rewrite that
changes no content at all — a no-op rebase, a force-push, an amend that only edits a
commit message — moves `HEAD` and so voids a marker keyed to the old sha, even though
the diff under review is byte-identical:

```bash
bash "${CLAUDE_SKILL_DIR}/scripts/pre-pr-markers.sh" <repo> match-pass <base>
```

It prints one of:

- **`identical`** — same base commit, same merge-base, same tree, same commit
  messages. The verdict holds. Record the pass for the new sha (Step 4) and stop;
  read no diff.
- **`messages-only`** — same base commit, merge-base and tree, different messages.
  The diff is unchanged, so review **only** `git -C <repo> log --format=%B <base>..HEAD` against the repo's
  commit conventions. Commit messages are in this review's remit — a forbidden trailer
  or a missing ticket key is exactly the kind of thing it catches — so they are never
  carried forward silently.
- **empty** — no pass covers this content. Continue below.

A marker written before this existed carries no signature and matches nothing, so the
full review stays the default for every pre-existing one.

**Then choose the review's scope.** Addressing a finding makes a new commit, which
voids the pass marker; re-judging the whole branch every round is what makes this
gate feel slow. A narrowed diff is safe only when the intent of everything in it is
already known, so read any findings record an earlier review left:

```bash
bash "${CLAUDE_SKILL_DIR}/scripts/pre-pr-markers.sh" <repo> select-findings
```

`select-findings` prints the path of the record nearest `HEAD` among those whose
`reviewed_sha` is an ancestor of it — never another branch's verdict, and your own
in preference to a stacked parent's — or nothing. When it prints a path, Read that
file and take its `reviewed_sha` and `base` (`recorded_base` below).

- **No record** — either no earlier review left one for this branch, or a rebase,
  amend or force-push rewrote the commit it named, so nothing the earlier verdict
  established still holds *about outstanding findings*. Review `$base...HEAD` in full.
  The default, and the only mode for a first review. (A rewrite that changed no
  content was already answered by `match-pass` above; reaching here means the content
  differs.)
- **`$recorded_base` differs from the resolved `$base`** — the PR was retargeted, or
  the deny named another base. That verdict was reached against a different
  comparison and carries nothing forward: review `$base...HEAD` in full.
- **A record was selected and the bases match** — *verification mode*. Review
  `$reviewed_sha..HEAD` and confirm each recorded finding is either fixed or
  **accepted** (below). **Escalate to the full `$base...HEAD` review the moment the
  delta contains anything that is not a fix for a recorded finding** — a revert, a
  new feature, an unrelated refactor. A narrowed diff shows which lines changed,
  not what the branch now means: a commit reverting already-passed work reads as
  harmless alone while breaking a caller the delta never touches.

Two markers, two jobs: `pre-pr-review-<sha>` is the pass the hook reads;
`pre-pr-findings-<sha>.json` is what is outstanding, read only here. Both are keyed
to a commit, which is what lets Step 4 clear this branch's without touching others'.

In **full review** mode, separate the dependency lockfiles from everything else.
Copy these pathspecs exactly — single-quoted, so git does the matching and the
shell does not glob them, and an entry matching nothing is simply ignored:

```bash
git -C <repo> diff <base>...HEAD -- ':/' ':(exclude,top)*.lockfile' ':(exclude,top)*package-lock.json' ':(exclude,top)*pnpm-lock.yaml' ':(exclude,top)*yarn.lock'
git -C <repo> diff <base>...HEAD --numstat -- ':(top)*.lockfile' ':(top)*package-lock.json' ':(top)*pnpm-lock.yaml' ':(top)*yarn.lock'
git -C <repo> log <base>..HEAD --oneline
```

- The first — everything but the lockfiles, read in full. This is what the Step 3
  dimensions apply to.
- The second — the lockfiles as one line each, never as hunks.
- The third — the commits being proposed.

**Both sides must be anchored, and the two buckets must partition the diff.** `:/`
and `:(top)` anchor at the repository root rather than at `$repo`; use them rather
than `.` and a bare pattern. Argument recovery can resolve `$repo` to a
subdirectory, and there an unanchored pathspec is silently prefixed with that
subdirectory: the exclusions stop covering the root lockfiles *and* the `--numstat`
side stops finding them, so a root lockfile lands in **neither** diff and the
Step 4 both-diffs-empty rule records a pass over something nobody read.

Each pattern also carries a leading `*`, because git pathspec globs cross `/`
(unlike `.gitignore`): `*.lockfile` already matches at any depth, so
`package-lock.json` without the `*` would match only the repository root and a
nested one would be read as hunks. Verified from three different working
directories: 6 changed files split 2 read / 4 lockfile every time, with nothing in
both buckets and nothing in neither.

Judge a lockfile at **coordinate level, not line level** — a dependency the build
file never declares, an unexpected group, a version moving backwards. "Logic
errors, races, N+1 queries, swallowed exceptions" cannot exist in a lockfile, so
reading its hunks line by line buys nothing, and it is the largest avoidable
cost in this gate: on a Spring Boot major upgrade the relocked `gradle.lockfile`
was 937 of 2,120 diff lines, because such an upgrade always relocks (measured on
imply-service, MXTS-81222).

**The Gradle wrapper is not in that bucket, deliberately.** `gradlew`,
`gradlew.bat` and `gradle/wrapper/*` are generated too, but a changed
`gradle-wrapper.jar` executes on every build and `distributionUrl` /
`distributionSha256Sum` decide which Gradle runs in CI — the canonical
supply-chain vector in a Gradle repo. Read them: check the distribution host is
official, that a `distributionSha256Sum` is present and changed consistently with
the URL, and treat any `gradle-wrapper.jar` change as needing a reason in the
commit message. On the diff measured above they are 191 lines against the
lockfile's 937, so keeping them readable costs almost none of the saving.

Reformatting churn is the same trap one level down. Where CI runs a formatter, an
import reorder touches many files with no semantic change; Step 3 already says to
skip what CI enforces, so read `--numstat -- :/` first and let a one-line-moved
file declare itself instead of opening each one to find that out.

Check that commit list against the branch. If it holds commits plainly not this
branch's work, the base is wrong — stop instead of reviewing them. Only when
**both** diffs are empty is there nothing to review: go to Step 4 and record the
pass. An empty non-lockfile diff beside a non-empty lockfile one is **not** nothing
to review — a relock, a Dependabot bump or a wrapper-only upgrade lands exactly
there — so apply the coordinate-level check described above before any pass.

In **verification** mode, run instead:

- `git -C <repo> diff <reviewed_sha>..HEAD` — only what changed since the review
- `git -C <repo> log <reviewed_sha>..HEAD --oneline` — the commits to account for

Here an **empty delta does not mean there is nothing to review — it means nothing
was fixed.** Re-report the recorded findings and stop; do not record a pass. The
retry that produced it is the reflex the deny message invites, and treating it as a
clean branch would open the gate with every finding still outstanding.

**One exception, and only this one:** an empty delta where *every* recorded finding
carries a non-empty `accepted_reason` is resolved, not unfixed — go to Step 4 and
record the pass. Accepting a finding produces no commit by definition, so without
this the escape hatch below can never fire and the gate deadlocks. A single
finding without a reason keeps the branch blocked.

### Step 3: Review the diff

Read the repository's root `CLAUDE.md` plus any `CLAUDE.md` in directories the diff
touches. Then print the project rules that apply to the branch, in either mode:

```bash
git -C <repo> diff --name-only <base>...HEAD -- ':/' | bash "${CLAUDE_PLUGIN_ROOT}/hooks/run-python.sh" "${CLAUDE_SKILL_DIR}/scripts/matching-rules.py" <toplevel>
```

`<toplevel>` is the `rev-parse --show-toplevel` output from Step 1, written out.

A rule loads on its own only when a matching file is opened with Read, which a
diff review may never do, so this output is the rule set. Treat every line of each
printed rule as a check, and tag a violation with the rule's heading, e.g.
`[rule: java/function-design]`. Hold the changes against all of that as well as:

- **Correctness** — logic errors, unhandled errors, races, off-by-one, null handling.
- **Security** — injection, missing boundary validation, hardcoded secrets, logged
  PII or tokens.
- **Performance** — N+1 queries, unbounded result sets, work hoistable out of a loop.
- **Architecture** — boundary violations, coupling, logic duplicated from elsewhere.
- **Silent failure** — swallowed exceptions, a fallback masking an error, a guard
  turning failure into a success-looking no-op.

Report only what a senior engineer would raise. Skip style nitpicks, formatting,
and anything the repo's CI already enforces; a violated project rule is never a
nitpick, even when it is about naming or length.

### Step 4: Record the verdict

**When the review found actionable issues**, report them as a short list of
`file:line` — what is wrong and why it matters — and stop. Do not write the marker:
`gh pr create` stays blocked until the issues are addressed and a fresh review
passes.

Record those findings before stopping, so the next round can verify them instead of
re-reviewing the branch (Step 2). Write the same list you just reported — a finding
you leave out is one the next review will not know to check.

**Print the record's path in the verdict**, and when a finding looks like one the
developer may accept rather than fix, print the snippet that accepts it. You run
forked, so this verdict is the only channel to the session that can act: it never
reads this file, and cannot guess a field name or the sha keying.

```
Accept a finding by adding "accepted_reason" to its object in
<git-dir>/pre-pr-findings-<sha>.json, then re-run this review:
  {"file": "...", "line": 42, "what": "...", "why": "...",
   "accepted_reason": "why this is intended and will not be fixed"}
```

First get the draft's path. It sits in the working tree, so this also has git
ignore it locally — a review cut off before the move leaves nothing to commit:

```bash
bash "${CLAUDE_SKILL_DIR}/scripts/pre-pr-markers.sh" <repo> draft-path
```

Write the record to the printed path with the **Write tool**, never a shell heredoc.
Review prose routinely holds backticks and `$`, which a heredoc can run or expand,
and which the worktree guard refuses outright; Write stores the text as given. Write
the real values out yourself:

```json
{
  "reviewed_sha": "<git -C <repo> rev-parse HEAD, written out>",
  "base": "<the resolved base, written out>",
  "findings": [
    {"file": "path/to/file", "line": 42, "what": "what is wrong", "why": "why it matters",
     "accepted_reason": "omit unless the developer accepted it; see below"}
  ]
}
```

Then move the draft into place, in the very next call. The script clears this
branch's superseded markers and prints the record's path. A draft whose
`reviewed_sha` is not `HEAD` is refused and deleted; write it again and retry:

```bash
bash "${CLAUDE_SKILL_DIR}/scripts/pre-pr-markers.sh" <repo> record-findings <the printed draft path>
```

Every value is a JSON string, so escape any `"` and `\` in the finding text. If a
finding cannot be expressed safely, **write no record at all** rather than a broken
one: a missing record means the next review is a full one, which is the safe
default, whereas a record that does not parse would have the next run select its
mode from garbage.

#### A finding the developer accepts rather than fixes

Some findings have no code fix. The resolution is a decision — a deliberate
temporary state, a convention the repo follows on purpose, a constraint outside
this branch. Re-reporting those every round deadlocks the gate: the fix that would
clear them is text in a pull-request body, and the body cannot be written because
this gate is what blocks creating it.

So a recorded finding may carry an `accepted_reason`. A finding that has one counts
as resolved for the pass, and is **still reported** — never silently dropped.

Three rules make this an audit trail rather than a rubber stamp:

- **The review never writes it.** You are the fork that raised the finding;
  accepting your own is not review. It is written by the developer's own session,
  and only after the developer says so in as many words. If you believe a finding
  should be accepted, say so in the verdict and leave it outstanding.
- **No reason, no acceptance.** An empty or missing `accepted_reason` is an
  outstanding finding. The reason is the whole artefact.
- **Say it in the verdict, every round.** Name each accepted finding and quote its
  reason when you record the pass, because that text is what the developer carries
  into the pull-request body — it is how a human reviewer ever learns the finding
  existed. Copy `accepted_reason` into the record you write for the new sha too, or
  the next round re-raises it.

Acceptance does not survive a retarget: a `recorded_base` that no longer matches
discards the whole record, which forces the decision to be made again against the
new base. That is deliberate — a finding accepted against `develop` may matter
against `master`.

**When the review is clean** (or every finding is purely informational, or every
remaining one is accepted), record the pass and say so:

```bash
bash "${CLAUDE_SKILL_DIR}/scripts/pre-pr-markers.sh" <repo> record-pass <base>
```

It runs `clear-lineage`, writes `pre-pr-review-<HEAD sha>` holding
`<base_sha> <merge_base_sha> <tree_sha> <messages_sha>`, and prints its path. The
marker records **what** was reviewed, not only which commit carried it, which is
what lets `match-pass` carry the verdict across a content-identical rewrite. The hook
tests only that the file exists, so its contents are free to say this.

The base is stored as a **commit sha, not a ref name**: `develop` moving changes the
`$base...HEAD` diff without touching `HEAD`, and a verdict reached against the old one
says nothing about the new. But `$base...HEAD` is really
`merge-base($base, HEAD)...HEAD`, so the base commit and tree alone do not fix it: a
rewrite that lands `HEAD` on a different ancestor of the same base commit moves the
merge-base — and so the diff — while leaving both exactly as they were.
`(base_sha, merge_base_sha, tree_sha)` together fix the reviewed diff exactly, which
is what makes carrying it forward sound rather than a guess.

`clear-lineage` removes the markers this branch has moved past — any whose commit is
an ancestor of `HEAD` *and* is not still some branch's tip, plus any orphaned by an
amend or rebase. `HEAD`'s own always goes, so a recorded pass can never outlive the
findings written for that same commit.

It spares other branches' markers on purpose. Every branch shares one `.git`, so the
repo-wide sweep this replaced meant a review on branch A discarded B's pass and B's
outstanding findings, and B paid a full re-review on the next switch. A pass for a
non-`HEAD` commit opens nothing anyway: the hook looks up `HEAD`'s own sha.

Pass the repository path to the script, and scope every git call with `git -C <repo>`.
Unscoped, the pass lands in whatever repository the working directory happens to be
and the clear revokes that repository's legitimate one. Then say the review passed,
naming the repository and commit SHA — the two facts that make a misdirection obvious.

**When the invocation carried a denied command**, recording the pass and retrying
it are one action — unblocking it is what the developer asked for. Do not stop in
between to ask whether to proceed; that leaves them holding a verdict to act on by
hand, the same dead end as asking a question.

**When it did not** — this skill also runs ahead of the deny — recording the pass is
the whole job, so stop there. Never reconstruct a plausible `gh pr create` from the
repository you happen to be sitting in: a guessed retry opens a real pull request,
on whatever branch that checkout has, for work nobody asked you to propose.

The marker is keyed to the commit, so any new commit needs a fresh review.

## Examples

User says: `/developer:reviewing-pre-pr main /path/to/worktree` — the canonical
two-token form: reviews `main...HEAD` there, then records the pass or reports
findings. **Prefer exactly two whitespace-separated tokens: a base and a repository
path.** That is what the hook prints and the only form needing no recovery.

`${CLAUDE_SKILL_DIR}/references/examples.md` also covers the hook-denial trigger
and retry, a non-default base, and why recovery is a safety net rather than a
licence to pass anything.

## Troubleshooting

Read `${CLAUDE_SKILL_DIR}/references/troubleshooting.md` for any of:

- the review asked a question instead of running
- it covered the wrong repository
- `gh pr create` is still blocked after a clean review
- there is no diff to review
- the diff is too large to review in one pass
