---
name: reviewing-sigrid-guardrails
description: "Runs Sigrid Guardrails on changed code to surface maintainability issues and security vulnerabilities. Use when reviewing a diff, before committing, or during a PR review. Invoke with '/reviewing-sigrid-guardrails'.\n"
disable-model-invocation: true
context: fork
allowed-tools:
- Read
- Bash
- mcp__claude_ai_Maxxton_Knowledge__sigrid_code_quality_guardrails
---

# Reviewing Sigrid Guardrails

Catch quality and security issues in changed code using Sigrid Guardrails.

## Prerequisites

The **Maxxton Knowledge** MCP connector must be connected in your claude.ai account — it provides the Sigrid tools with no token or environment setup required. Run `/mcp` to verify it shows as connected.

## Instructions

1. **Determine scope** — identify changed files from `git diff`, user specification, or PR diff
2. **Read changed files** — gather code content for each changed file
3. **Run guardrails check** — call `sigrid_code_quality_guardrails` with the code content
4. **Report findings** — surface issues grouped by severity; highlight security vulnerabilities first

Present findings as:
- **Critical / High** — security vulnerabilities and major maintainability blockers
- **Medium / Low** — code quality improvements

For each finding: file, line range, issue description, suggested fix if provided.

### When the tool is unavailable

If `sigrid_code_quality_guardrails` is unavailable (Maxxton Knowledge connector not connected), do not fabricate findings. Tell the user to connect the connector and run `/mcp`, then end your response with this sentinel line so orchestrators (e.g. `reviewing-all`) can detect the skip:

```
SIGRID_SKIP: Maxxton Knowledge connector not connected
```

## Examples

User says: "Check the code I just changed for quality issues" → runs Sigrid Guardrails on `git diff` output.

User says: "Run Sigrid on this PR before I commit" → reads staged files and reports findings grouped by severity.

## Troubleshooting

**Maxxton Knowledge connector not connected** — the `sigrid_code_quality_guardrails` tool will be unavailable. Connect the Maxxton Knowledge MCP connector in your claude.ai account and run `/mcp` to confirm it shows as connected. See [When the tool is unavailable](#when-the-tool-is-unavailable) for the `SIGRID_SKIP` sentinel emitted in this case.

**No changed files found** — ensure there are staged or unstaged changes (`git diff` or `git diff --cached` must return output). Pass a file path explicitly if needed.

