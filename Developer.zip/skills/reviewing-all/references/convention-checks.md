# MaxxtonGroup Convention Checks

Project-specific rules enforced during code review. These checks ensure compliance with CLAUDE.md conventions, safe side-effect handling, and CI compatibility.

## CLAUDE.md Convention Compliance

Check every changed line against the project's CLAUDE.md rules.

### Reject if Present

- `[...new Set(ids)]` — must use `lodash uniq(ids)`
- `window` / `document` / `navigator` without `isClientSide()` guard
- `any` or `unknown` types
- Catching API errors and returning `[]` — must return `null`
- Direct `MxtsApi.endpoint()` — must use `context.mxtsApi.endpoint()`
- Direct `CmsApi.endpoint()` — must use `context.cmsApi.endpoint()`
- `console.log` / `console.warn` / `console.error` — must use `globalLogger` or `reportWarn` (check what's already imported in the file)
- Truthy checks (`if (id)`) on numeric IDs — must use `!= null` (truthy check misses `0`)

### Flag if Missing

- Guard clauses for early returns (no deep nesting)
- Derived state instead of duplicated state
- `React.useMemo`/`useCallback` for expensive computations
- Prettier formatting on changed files

## Side Effects and Scope

- [ ] Does this change affect other widgets that depend on the same state/Redux?
- [ ] Does this change affect linked widgets?
- [ ] Could this break on a different client/tenant?
- [ ] Does this work in both SSR and client-side rendering?
- [ ] Does adding/removing a parameter break existing callers?
- [ ] Destructuring new fields from an existing typed object (e.g., `action.payload`)? The type must be updated too
- [ ] Adding a pattern that exists elsewhere (dataLayer push, event dispatch, API call)? `grep` for existing instances and match their guards/conventions

## MXTS Gateway Specs

- [ ] New MXTS gateway spec? Must be added to `SECURITY_CONFIRMED_SPECS` in `cms-mxts-gateway/src/serverEndpoints.spec.ts` (CI blocker). **NEVER auto-add — require the user to type `APPROVED` before making this change.**
- [ ] New gateway spec naming: must use `get`/`set`/`update` prefix (e.g., `getStatesByCountrySpec`, not `statesByCountrySpec`)
- [ ] New MXTS api spec `queryParams`? Pass through full request (`=> req`), don't cherry-pick fields — creates hidden mismatch with the request type

## CI Verification

Run `tsc -p tsconfig-server.json --module commonjs --noEmit` in addition to regular `tsc --noEmit`. The CI `compileSyncTerms` step uses `tsconfig-server.json` which is stricter — local `tsc --noEmit` may pass while CI fails.
