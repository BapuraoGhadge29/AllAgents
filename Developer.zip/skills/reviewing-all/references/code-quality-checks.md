# Code Quality and Data Integrity Checks

General code quality, data integrity, and performance checks applicable across the codebase.

## Code Quality

- [ ] No `.map()` used purely for side effects — use `.forEach()` instead
- [ ] No unused imports or variables (check every import against usage in the file)
- [ ] No dead code (unreachable branches, commented-out code)
- [ ] No mutation-only loops returning unused arrays
- [ ] Functions do one thing — no 100+ line functions that should be split
- [ ] Proper error logging (not empty `catch` blocks)
- [ ] String-indexed generics: if the key references the **same type**, suggest `keyof T`; if it references a **cross-entity field** (e.g., `dependsOn` pointing to another widget's variable), `Record<string, unknown>` cast is correct — don't blindly flag as needing `keyof`
- [ ] No async IIFEs (`await (async () => { ... })()`). Flag as a readability smell — refactor to a plain `if/else` block with early returns instead
- [ ] New async method shares significant boilerplate with an existing async method? Suggest merging to avoid jscpd duplicate-code detection blocking the commit

## Data Integrity

- [ ] API errors distinguished from empty results (`null` vs `[]`)
- [ ] Array bounds checked before index access (`array?.[0]` or length check)
- [ ] No redundant API calls (check if same data is fetched elsewhere)
- [ ] Aggregations spread-merged, not replaced: `[...(filter.aggregations || []), NEW]` not `filter.aggregations = [NEW]` — replacing silently drops existing aggregation results
- [ ] Module-level debounce/batch globals keyed by tenant+locale (`baseUrl:concern:locale`) — bare module-level state causes cross-tenant data mixing in multi-tenant SSR

## Performance

- [ ] Expensive computations memoized when in render path
- [ ] No N+1 patterns (API call inside a loop)
- [ ] New `<img>` tags include `width` and `height` attributes (or `aspect-ratio` CSS on the container) — missing dimensions cause Cumulative Layout Shift (CLS). `backgroundImage: "none"` toggling on lazy background images is a CLS source; use `visibility: hidden` or `aspect-ratio` to reserve space
