# React and Async Safety Patterns

The most common source of bugs. Check every async operation and React effect against these patterns.

## Async Patterns

- [ ] No fire-and-forget `.then()` — use `await` inside `Promise.all` or handle errors
- [ ] Async effects use cancelled/stale flag pattern (snapshot context before `await`, check after)
- [ ] No ref-based guards that race with re-renders (ref set before await, checked after — second invocation sees stale ref)
- [ ] Sequential `setState` calls don't cause intermediate inconsistent states
- [ ] `Promise.all` used for independent fetches (not sequential `await`)

## React Patterns

- [ ] `useEffect` dependencies use scalar values (`.length`, `.join(",")`) not array/object references
- [ ] No stale closures in callbacks (deps array includes all referenced values)
- [ ] No direct state mutation
- [ ] Special widget values resolved before numeric conversion (e.g., `"currentYear"`)
- [ ] State reset effects don't race with data-fetching effects (synchronous reset + async fetch = blank UI)
- [ ] In `UNSAFE_componentWillReceiveProps`: use `nextProps.onChange` / `nextProps.xxx`, NOT `this.props.xxx` (stale callback/value)

## React Performance

- [ ] No `.bind(this, ...)` in `render()` — creates a new function reference on every render, defeating `PureComponent`'s shallow comparison. Use class property arrow functions (`handleClick = () => {...}`) instead
- [ ] No new `React.memo` without profiling evidence — adds comparison overhead on every render. Only beneficial on components inside `.map()` loops where the parent re-renders frequently with unchanged props
- [ ] New boolean state that gates validation or `isDisabled`? Check its initial value: if the data is fetched async, the safe default is `true` (block until resolved). Initializing to `false` creates a window where validation is silently skipped before the fetch completes

## React Sortable Tree

- [ ] `react-sortable-tree` `handleChange`: only call for structural changes (drag/drop/add/remove). Visual-only state (`expanded`) must use `setState` only — calling `handleChange` for expanded state triggers a full save cycle and can blank the page
