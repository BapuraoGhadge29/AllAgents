# Skill Overrides: reviewing-all

## disable-model-invocation: true

**Reason:** Orchestrator skill that spawns six parallel sub-agents (reviewing-code-quality, /code-review with Maxxton criteria, reviewing-sigrid-guardrails, a Context7 library check, a git-history check, and a Jira-ticket spec check). Auto-invocation on ambient "review" conversation would be disruptive — each run is expensive and time-consuming. Must be user-triggered via `/reviewing-all`.

## References loaded by a sub-agent, not preloaded

**Reason:** `references/code-quality-checks.md`, `convention-checks.md` and `react-async-patterns.md` are the task spec for sub-agent C, read inside that sub-agent rather than by the orchestrator. `react-async-patterns.md` is read only when the diff touches React or TypeScript files. This is the dispatch-style exception in `best-practices.md` — the orchestrator body never loads them, so they cost nothing on runs that do not need them.
