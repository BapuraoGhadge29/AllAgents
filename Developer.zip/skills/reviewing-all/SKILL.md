---
name: reviewing-all
description: Full-depth code review orchestrator. Use for a "full review" or "deep review" combining all review skills. Runs quality, Maxxton-criteria, Sigrid, Context7 library, git-history and Jira-ticket spec checks as parallel sub-agents and synthesises a unified severity-ranked report.
disable-model-invocation: true
argument-hint: "[GitHub PR URL, branch name, or omit for current diff]"
allowed-tools:
- Agent
- Skill
- Bash
- Read
- Grep
- Glob
- mcp__claude_ai_Context7__resolve-library-id
- mcp__claude_ai_Context7__query-docs
- mcp__claude_ai_Atlassian_MCP__getJiraIssue
- mcp__claude_ai_Atlassian_MCP__getAccessibleAtlassianResources
---

# Reviewing All

Orchestrates a full-depth review by running all review sub-agents in parallel and synthesising findings into a single severity-ranked report.

## Instructions

### Step 1 — Determine review target

Run:
```
git rev-list --count main..HEAD
```

If the count is `0`, stop and tell the user: "Nothing to review — no commits ahead of main on the current branch."

Parse the argument (ARGUMENTS variable):

- **GitHub PR URL** — pass verbatim to sub-agents as `args`
- **Branch name** — pass verbatim to sub-agents as `args`
- **No argument** — sub-agents receive no `args` and review the current diff

### Step 2 — Launch sub-agents in parallel

Dispatch all sub-agents in a single message so they run concurrently. For each sub-agent, substitute `<target>` with the argument value (PR URL or branch), or omit it entirely if no argument was provided.

Sub-agents D and E are cheap and mechanical — dispatch both with `model: "haiku"`.

Sub-agents A, B and C resolve `<target>` themselves. D, E and F cannot: D and E read raw git state, so on a PR-URL run they would review the working tree while everyone else reviews the PR, and F works only from what is pasted into its prompt. Resolve the review input **once** before dispatching and paste it into their prompts:

```
git diff --name-only <base>...HEAD    # changed files
git diff <base>...HEAD                # the diff itself
```

For a PR URL, make the PR's head available first (`gh pr checkout <url>`), or take the changed files and diff from `gh pr diff <url>`. If the PR's commits cannot be fetched locally, say so in both prompts: D can still work from the diff text, but E has no history to read and must skip.

Sub-agent F needs the originating Jira ticket. Take the key from the branch name (`feature/MXTS-1234-…`), the PR title, or the PR description (`gh pr view <url> --json title,body`), in that order, then fetch it once with `mcp__claude_ai_Atlassian_MCP__getJiraIssue` (resolve the cloudId with `mcp__claude_ai_Atlassian_MCP__getAccessibleAtlassianResources` if unknown) and paste its summary, description and acceptance criteria into F's prompt. No key, Atlassian not connected, or a ticket with no description → tell F so; it returns a skip.

**Sub-agent A — Five-axis quality review**

```
Call the Skill tool:
  skill: "developer:reviewing-code-quality"
  args: "<target>"   ← substitute or omit

Return the complete findings report verbatim. Prefix every finding line with [Quality].
```

**Sub-agent B — Sigrid guardrails**

```
Call the Skill tool:
  skill: "developer:reviewing-sigrid-guardrails"
  args: "<target>"   ← substitute or omit, same as sub-agent A

That skill takes its scope from a user specification when one is given and from
`git diff` otherwise, so passing the target keeps it on the same diff as the rest
of the review instead of on whatever the working tree happens to hold.

Return the complete findings report verbatim. Prefix every finding line with [Sigrid].
When the check cannot run (e.g. the Maxxton Knowledge MCP connector is not connected), the skill ends its output with a `SIGRID_SKIP: <reason>` sentinel line — return exactly that line and nothing else.
```

**Sub-agent C — Maxxton custom quality checks (via `/code-review`)**

```
Invoke the built-in `/code-review` skill, read-only (do NOT pass `--comment`):
  /code-review <target>   ← substitute <target> with the PR URL or branch, or omit for the current diff

`/code-review` reviews at the session's effort level.

Steer the review with these Maxxton-specific criteria on top of /code-review's default lens. Read every changed file in full, plus the root and per-directory `CLAUDE.md`. Print the project rules that apply by piping the changed file names (`git diff --name-only <base>...HEAD`, or `gh pr diff <n> --name-only` for a PR) into `bash "${CLAUDE_PLUGIN_ROOT}/hooks/run-python.sh" "${CLAUDE_PLUGIN_ROOT}/skills/reviewing-pre-pr/scripts/matching-rules.py" "$(git rev-parse --show-toplevel)"`, and treat every line of each printed rule as a check.

Read `${CLAUDE_SKILL_DIR}/references/code-quality-checks.md` and `${CLAUDE_SKILL_DIR}/references/convention-checks.md` before judging. Read `${CLAUDE_SKILL_DIR}/references/react-async-patterns.md` as well, but only when the diff touches React or TypeScript files.

- Reliability & operability: resource cleanup on error paths (try/finally, with, defer); collision-safe output paths (no date-only suffixes); no import-time crashes on bad config; fail-fast on empty/missing required config; `.strip()` text from external sources before concatenation; timezone-aware datetimes.
- Security (extends default): `subprocess(shell=True)` with any interpolated value; `eval`/`exec`/`pickle.loads`/unsafe `yaml.load` on untrusted input; secrets in Dockerfile/compose/CI YAML.
- Documentation consistency: PR-description claims vs code (table/env/path names); CLAUDE.md/README freshness when behaviour changes; no misleading commented-out config.
- General: match existing patterns before adding new ones; update types/schemas when destructuring new fields; no fire-and-forget promises/un-awaited coroutines; parallelise independent fetches; no silent empty catch/except; flag duplicate-code smell; assess cross-caller/cross-tenant side effects.
- Test coverage: new public methods and changed branches without a test; assertions that cannot fail (vacuous collection checks, a flag-gated test that never flips the flag); fixtures asserted instead of behaviour.
- Project rules: for each printed rule, flag violations with its heading tag, e.g. `[rule: java/function-design]`.

Emit findings as `[axis]/[severity] file:line — problem. Fix: remediation.` (axis ∈ Reliability, Security, Docs, General, Tests, `rule: <name>`; severity ∈ Critical/High/Medium/Low/Informational). Skip anything already covered by sub-agent A; don't nitpick.

When a finding rests on a `CLAUDE.md` or rule violation, quote the line that forbids it. If no line actually says so, drop the finding to Informational — an invented convention is worse than a missed one.

If there are no Maxxton-specific findings, return exactly `NO_CUSTOM_FINDINGS` (the entire response, nothing else) — do NOT prefix it with `[Custom]`; the orchestrator treats it as a clean pass.

Otherwise return the complete findings report verbatim with `[Custom]` prefixed to every finding line.
```

**Sub-agent D — Library checker (Context7)**

```
Review target: <target>   ← substitute, or "the current diff" if no argument
Changed files: <changed-file list resolved above>
Diff:
<diff resolved above>

Scan that diff for added or changed import / require / dependency statements.

If there are none, return exactly `NO_LIBRARY_FINDINGS` and nothing else.

For each library found:
1. `resolve-library-id` (Context7 MCP) to get its library ID.
2. `query-docs` (Context7 MCP) to check the APIs the diff actually calls for
   deprecation, security advisories, and incorrect usage.

Only report a library whose docs contradict the diff — a deprecated call, an
advisory affecting the version in use, or an API used against its contract. Do
not report a library merely for being new, nor suggest version bumps.

If the Context7 tools are unavailable or every lookup fails, return exactly
`LIBRARY_SKIP: <reason>` and nothing else. Never fall back to memory: a
deprecation asserted without docs behind it is worse than no answer, because the
report reads as though the libraries were checked.

Cite the import line and the call site. Prefix every finding line with [Library].
```

**Sub-agent E — History checker**

```
Review target: <target>   ← substitute, or "the current diff" if no argument
Changed files: <changed-file list resolved above>
Diff:
<diff resolved above>

For each of those changed files, run `git log -L` on the changed hunks or
`git blame` on the surrounding lines, and read enough history to judge whether
the change fits the file.

Report only these three things:
- The diff breaks a pattern the file follows everywhere else (e.g. the file uses
  a shared logger throughout and the diff introduces a raw print/console call).
- The diff reverts or re-breaks something a recent commit deliberately fixed —
  name that commit.
- A comment or commit message in that area states a constraint the diff violates.

This is the only sub-agent that reads history, so a pattern break invisible in
the diff alone is exactly what it exists to catch. Say which commit taught you
each conclusion. Ignore formatting churn and file age.

If nothing qualifies, return exactly `NO_HISTORY_FINDINGS` and nothing else.

If the history is not there to read — a shallow clone, or the target's commits
are not available locally — return exactly `HISTORY_SKIP: <reason>` and nothing
else. Do not substitute a read of the diff alone: this sub-agent exists to
compare against history, so "nothing found" without history is not the same
answer as "nothing found" with it.

Prefix every finding line with [History].
```

**Sub-agent F — Spec checker (Jira ticket)**

```
Review target: <target>   ← substitute, or "the current diff" if no argument
Ticket: <key, summary, description and acceptance criteria resolved above — or the reason it is missing>
Changed files: <changed-file list resolved above>
Diff:
<diff resolved above>

If the ticket is missing or has no description, return exactly
`SPEC_SKIP: <reason>` and nothing else.

Compare the diff with what the ticket asks for. Report only these three things:
- Missing: a requirement or acceptance criterion with no matching change.
- Wrong: a requirement implemented differently from what the ticket says.
- Scope creep: a behaviour change the ticket does not ask for.

Quote the ticket line each finding rests on. Refactors and tests that serve the
ticket are not scope creep. Do not judge code quality — other sub-agents do that.

If nothing qualifies, return exactly `NO_SPEC_FINDINGS` and nothing else.

Prefix every finding line with [Spec].
```

### Step 3 — Synthesise findings

Collect results from every sub-agent. A sentinel-only reply contributes no findings, but a clean pass and a skip are different outcomes and must not be collapsed:

| Sentinel | Record as |
|---|---|
| `NO_CUSTOM_FINDINGS`, `NO_LIBRARY_FINDINGS`, `NO_HISTORY_FINDINGS`, `NO_SPEC_FINDINGS` | clean pass — the check ran and found nothing |
| `SIGRID_SKIP: <reason>`, `LIBRARY_SKIP: <reason>`, `HISTORY_SKIP: <reason>`, `SPEC_SKIP: <reason>` | skip — the check did not run; carry the reason into the summary |

A sub-agent that returns neither a sentinel nor parseable findings — an error message, a refusal, an empty reply — is a **skip, not a pass**. Record it as `⚠ skipped — unparseable reply` rather than merging its text as a finding. Reporting a check as passed when it never ran is the one failure this report cannot afford.

Merge the rest into a unified list:

1. **Deduplicate** — if two or more sub-agents flag the same `file:line` for the same issue, keep one entry and combine the tags (e.g. `[Quality][Sigrid][Custom]`).
2. **Rank by severity** — Critical → High → Medium → Low → Informational. Sub-agents D, E and F do not emit severities: rank a `[Library]` finding by what its docs say (a live advisory is Critical/High, a deprecation is Medium), a `[History]` finding by what re-breaking the pattern costs, and a `[Spec]` finding as High for Missing/Wrong and Medium for scope creep.
3. **Preserve attribution** — every finding carries its source tag(s). Custom-skill findings keep their inner axis tag too (e.g. `[Custom][Reliability]`, `[Custom][rule: developer/prefer-simplicity]`).

### Step 4 — Present unified report

```
## Review Summary

**Target:** <PR URL / branch / current diff>
**Sub-reviews:** every check below carries its own state — `✓` only when it actually ran.
  reviewing-code-quality {✓ / ⚠ skipped — <reason>}
  /code-review {✓ / ⚠ skipped — <reason>}
  reviewing-sigrid-guardrails {✓ / ⚠ skipped — <reason>}
  library {✓ / ⚠ skipped — <reason>}
  history {✓ / ⚠ skipped — <reason>}
  spec (Jira ticket) {✓ / ⚠ skipped — <reason>}
**Total findings:** N (X critical, Y high, Z medium, W low)

---

## Critical / High

<findings with file:line, tag, description>

## Medium

<findings>

## Low / Informational

<findings>

---

## Verdict

{APPROVED | APPROVED WITH COMMENTS | CHANGES REQUIRED}

<One sentence rationale.>
```

If every sub-agent ran and none returned findings, output: `APPROVED — no issues found across all review dimensions.`

If any sub-agent skipped, do not use that line — it claims coverage that did not happen. Say which dimensions were not checked: `APPROVED — no issues found in the checks that ran; <list> skipped.`

## Examples

User says: `/reviewing-all` — reviews current branch diff with every sub-review.
User says: `/reviewing-all https://github.com/MaxxtonGroup/mxts/pull/456` — full review of PR #456.
User says: `/reviewing-all feature/MXTS-9901` — reviews branch `feature/MXTS-9901` against main.

## Troubleshooting

- **Sub-agent A times out** — include `⚠ reviewing-code-quality timed out` in the summary header; continue with the other sub-reviews.
- **Sub-agent C times out** — include `⚠ /code-review timed out` in the summary header; continue with the other sub-reviews.
- **Sigrid skipped** — normal when the Maxxton Knowledge MCP connector is not connected. The other sub-reviews still run; note the skip in the summary line.
- **Context7 unavailable** — sub-agent D returns `LIBRARY_SKIP: Context7 not connected`, which the summary renders as `library ⚠ skipped`. It must never guess from memory: a deprecation claim with no docs behind it is worse than no claim.
- **Shallow clone, or the target's commits are not local** — sub-agent E returns `HISTORY_SKIP: <reason>`. This is a skip, not `NO_HISTORY_FINDINGS`: without history there is nothing to compare against, so "found nothing" would overstate what was checked.
- **No Jira key in the branch name, PR title or PR description** — sub-agent F returns `SPEC_SKIP: no ticket key`. To include the spec check, run the review on a branch or PR that carries the key in one of those places.
- **A sub-agent replies with an error or nothing at all** — treat it as a skip, never as a pass, and never merge its text into the findings list. See the sentinel table in Step 3.
- **This review does not post to GitHub** — it is read-only by design. To leave inline comments on a PR, run the built-in `/code-review <target> --comment` separately.
- **No commits ahead of main** — stop at Step 1; do not launch sub-agents.
