# Skill Authoring Overrides

## Model invocation override

**Rule:** `disable-model-invocation: true` (default for new skills)

**Override decision:** Model-invocable (flag omitted)

**Justification:** This skill is designed to be fired from a Claude Code hook. When the hook fires, Claude needs to auto-load the skill to know how to handle the context. With `disable-model-invocation: true`, the skill would not be visible to the model at hook fire time, requiring the user to type `/starting-ticket-branch` explicitly — which defeats the purpose of the hook.

**Applies to:** Strong override reason — skill is part of a documented automated workflow where auto-loading is required for the chain to work.

**Side-effect mitigation:** All side effects (worktree creation, git branch creation) are gated behind an explicit confirmation in Step 4. The skill will not create anything without developer approval.
