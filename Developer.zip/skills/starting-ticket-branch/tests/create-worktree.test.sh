#!/usr/bin/env bash
# Tests for scripts/create-worktree.sh
# Usage: bash tests/create-worktree.test.sh
#
# Worktrees must sit inside the project folder: Claude Code undoes a `cd` to a
# folder outside it after each command, so commits, pushes and `gh pr create`
# ran in the main checkout (MXTS-83500).
set -uo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SCRIPT="$SCRIPT_DIR/../scripts/create-worktree.sh"

PASS=0; FAIL=0
pass() { printf '  \033[0;32mPASS\033[0m  %s\n' "$1"; PASS=$((PASS+1)); }
fail() { printf '  \033[0;31mFAIL\033[0m  %s\n' "$1"; FAIL=$((FAIL+1)); }

TMP=$(mktemp -d); trap 'rm -rf "$TMP"' EXIT
TMP=$(cd "$TMP" && pwd -P)
ORIGIN="$TMP/origin.git"
REPO="$TMP/repo"
git init -q --bare "$ORIGIN"
git clone -q "$ORIGIN" "$REPO" 2>/dev/null
git -C "$REPO" config user.email test@example.com
git -C "$REPO" config user.name Test
git -C "$REPO" commit -q --allow-empty -m base
git -C "$REPO" branch -M main
git -C "$REPO" push -q origin main

echo "create-worktree.sh"

out=$(cd "$REPO" && bash "$SCRIPT" feature/MXTS-1 main 2>&1)
want="$REPO/.claude/worktrees/feature-MXTS-1"
if [ "$(git -C "$want" branch --show-current 2>/dev/null)" = feature/MXTS-1 ]; then
  pass "worktree created under the project's .claude/worktrees"
else
  fail "worktree not at $want (output: $out)"
fi

if printf '%s' "$out" | grep -Fq "Path:    $want"; then
  pass "prints the absolute path to enter"
else
  fail "output does not print $want (output: $out)"
fi

if [ -z "$(git -C "$REPO" status --porcelain)" ]; then
  pass "main checkout stays clean (worktree folder ignored)"
else
  fail "main checkout shows: $(git -C "$REPO" status --porcelain)"
fi

out=$(cd "$want" && bash "$SCRIPT" feature/MXTS-2 main 2>&1)
want2="$REPO/.claude/worktrees/feature-MXTS-2"
if [ -d "$want2" ] && [ ! -e "$want/.claude/worktrees/feature-MXTS-2" ]; then
  pass "run from inside a worktree → next to it, not nested"
else
  fail "worktree not at $want2 (output: $out)"
fi

if [ "$(grep -c '^/.claude/worktrees/$' "$REPO/.git/info/exclude")" = 1 ]; then
  pass "exclude entry written once, not per worktree"
else
  fail "exclude: $(cat "$REPO/.git/info/exclude")"
fi

(cd "$REPO" && bash "$SCRIPT" feature/MXTS-3 main "$TMP/elsewhere" >/dev/null 2>&1)
if [ -d "$TMP/elsewhere/feature-MXTS-3" ] && [ "$(grep -c 'elsewhere' "$REPO/.git/info/exclude")" = 0 ]; then
  pass "explicit worktrees-dir → used as given, exclude untouched"
else
  fail "explicit dir not honoured or exclude changed: $(cat "$REPO/.git/info/exclude")"
fi

if (cd "$REPO" && bash "$SCRIPT" feature/MXTS-1 main >/dev/null 2>&1); then
  fail "existing path must fail"
else
  pass "existing path → fails"
fi

echo ""
echo "Results: $PASS/$((PASS+FAIL)) passed"
[ "$FAIL" -eq 0 ]
