---
name: starting-ticket-branch
description: 'Derives and creates a git branch and worktree from a Jira ticket key. Use when a developer says "start working on MXTS-XXXX" or "create a branch for MXTS-XXXX".'
argument-hint: "[ticket-key]"
allowed-tools:
- Bash
- AskUserQuestion
- EnterWorktree
- mcp__claude_ai_Atlassian_MCP__getJiraIssue
- mcp__claude_ai_Atlassian_MCP__getAccessibleAtlassianResources
---

# Starting Ticket Branch

Fetches a Jira ticket's type and priority, derives the correct git branch name and base branch per Maxxton naming conventions, confirms with the developer, then creates a git worktree for isolated development.

## Instructions

### Step 0 — Check local git state

Run `git status --short`. If uncommitted or unstaged changes are present, warn the developer:

> You have uncommitted changes in the current working tree. These won't be copied to the new worktree — consider stashing or committing them first to avoid confusion.

Do not block on this; continue once the developer acknowledges or asks to proceed anyway.

### Step 1 — Fetch ticket

Extract the ticket key from the argument or user message (e.g. `MXTS-12345`). If not provided, ask.

Call `mcp__claude_ai_Atlassian_MCP__getJiraIssue` with the key and the Maxxton cloudId. If the cloudId is unknown, call `mcp__claude_ai_Atlassian_MCP__getAccessibleAtlassianResources` first to resolve it.

If the Atlassian connector is unavailable or the ticket is not found, stop:

> Cannot reach Jira. Check that the Atlassian connector is configured in claude.ai → Settings → Connectors and that the ticket key is correct (e.g. MXTS-12345).

Extract from the Jira response: `issuetype.name`, `priority.name`, and `summary`.

### Step 2 — Derive branch name

Run the bundled script with the extracted Jira fields:

```bash
bash "${CLAUDE_SKILL_DIR}/scripts/derive-branch-name.sh" "{issuetype.name}" "{priority.name}" "{ticket-key}"
```

The script outputs the full branch name (e.g. `hotfix/MXTS-12345`, `bugfix/MXTS-12345`, or `feature/MXTS-12345`).

### Step 3 — Determine base branch

**If the developer stated a preferred base branch upfront** (e.g. "target main", "use develop"), use it directly — skip to Step 4 with that branch pre-selected.

Otherwise, run the bundled script using the first segment of the branch name as the prefix (e.g. `hotfix` from `hotfix/MXTS-12345`):

```bash
bash "${CLAUDE_SKILL_DIR}/scripts/select-base-branch.sh" "{prefix}" "{priority.name}"
```

The script runs `git fetch --prune` and prints candidate branches one per line:

- **1 line**: use it directly — no selection needed.
- **2 lines**: present an `AskUserQuestion` with those two options (first is recommended):
  - Question: `Which base branch for {branch-name}?`
  - Option 1: first line of script output (e.g. `origin/main`)
  - Option 2: second line of script output (e.g. `origin/release/2026.18`)

### Step 4 — Confirm

Present the confirmation summary:

```
Branch:    hotfix/MXTS-12345
Base:      origin/main
Ticket:    [P1 Bug] Handle null pointer in payment flow
Worktree:  .claude/worktrees/hotfix-MXTS-12345

Proceed with origin/main, select a different base, or cancel?
```

Do not create anything until the developer confirms.

### Step 5 — Create worktree

Run the bundled script:

```bash
bash "${CLAUDE_SKILL_DIR}/scripts/create-worktree.sh" "{branch-name}" "{base-branch}"
```

Where `{base-branch}` is the base branch — either `release/2026.18` or `origin/release/2026.18`; the script strips a leading `origin/` automatically.

The script handles `mkdir -p`, pre-flight path check, `git worktree add`, and reports the absolute path. Show its output to the developer. If it reports that the path already exists, show its `git worktree remove` command and stop.

### Step 6 — Enter the worktree

Call `EnterWorktree` with `path` set to the `Path:` line of the script output. That moves the whole session into the worktree, so commits, pushes and `gh pr create` run there. Never `cd` into the worktree instead: a `cd` does not carry over to the next command.

## Examples

### Example 1: P3 Bug, develop exists

User says: "start working on MXTS-99001"

Ticket `MXTS-99001` — P3 Bug — "Fix login redirect loop"
→ branch `bugfix/MXTS-99001`, base `origin/develop`

```
Branch:    bugfix/MXTS-99001
Base:      origin/develop
Ticket:    [P3 Bug] Fix login redirect loop
Worktree:  .claude/worktrees/bugfix-MXTS-99001

Proceed with origin/develop, select a different base, or cancel?
```

### Example 2: P1 Story, release branch exists

Ticket `MXTS-88002` — P1 Story — "Add payment gateway webhook", one release branch available

`AskUserQuestion` presents:
- Option 1: `origin/main` (recommended)
- Option 2: `origin/release/2026.18`

User picks 1 → branch `feature/MXTS-88002`, base `origin/main`, worktree `.claude/worktrees/feature-MXTS-88002`

### Example 3: P2 Bug

Ticket `MXTS-77003` — P2 Bug — "Null pointer in checkout flow"
→ branch `hotfix/MXTS-77003`, base `origin/main` (no release branch in this repo), worktree `.claude/worktrees/hotfix-MXTS-77003`

### Example 4: P1 Bug

Ticket `MXTS-55001` — P1 Bug — "Payment gateway down"
→ branch `hotfix/MXTS-55001`, base `origin/main`, worktree `.claude/worktrees/hotfix-MXTS-55001`

## Troubleshooting

### Jira ticket not found or Atlassian connector unavailable
Cause: wrong key format, ticket doesn't exist, or connector not configured.
Fix: verify key (e.g. `MXTS-12345`); check Atlassian connector in claude.ai → Settings → Connectors.

### No release branch for P1/P2 non-Bug
Cause: repo uses trunk-based development — no `release/*` branches.
Fix: skill falls back to `main`/`master`.

### Worktree path already exists
Cause: a previous worktree for this branch was not cleaned up.
Fix: run the `git worktree remove "<absolute path>"` command the script printed, then retry, or `git worktree prune` to remove stale entries. The path is absolute because a relative one resolves inside the current worktree when the skill runs from one.
