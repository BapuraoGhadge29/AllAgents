#!/usr/bin/env bash
# Usage: create-worktree.sh <branch-name> <base-branch> [worktrees-dir]
# Creates a git worktree for a Jira ticket branch.
# - Handles mkdir -p for the parent directory
# - Fails fast if the worktree path already exists
# - Reports the absolute path to enter with EnterWorktree on success
#
# Worktrees go under the main checkout's .claude/worktrees: Claude Code undoes a
# `cd` to a folder outside the project after each command, so a worktree there
# had commits, pushes and `gh pr create` run in the main checkout (MXTS-83500).
set -euo pipefail

if [ $# -lt 2 ]; then
  echo "Usage: create-worktree.sh <branch-name> <base-branch> [worktrees-dir]" >&2
  exit 1
fi

BRANCH="$1"
BASE="${2#origin/}"
# The first listed worktree is the main checkout, also when run from a worktree.
MAIN_CHECKOUT=$(git worktree list --porcelain | sed -n '1s/^worktree //p')
WORKTREES_DIR="${3:-$MAIN_CHECKOUT/.claude/worktrees}"
SANITIZED=$(echo "$BRANCH" | tr '/' '-')
WORKTREE_PATH="$WORKTREES_DIR/$SANITIZED"

if [ -e "$WORKTREE_PATH" ]; then
  echo "ERROR: Path already exists: $WORKTREE_PATH" >&2
  echo "Remove the old worktree first: git worktree remove \"$WORKTREE_PATH\"" >&2
  exit 1
fi

mkdir -p "$WORKTREES_DIR"

# Keep the worktrees out of the main checkout's `git status`. The local exclude
# file, not .gitignore: that one is tracked, and the developer post-checkout hook
# adds the entry there in Maxxton repositories anyway.
if [ $# -lt 3 ] && ! git -C "$MAIN_CHECKOUT" check-ignore -q "$WORKTREES_DIR/"; then
  EXCLUDE="$(git rev-parse --path-format=absolute --git-common-dir)/info/exclude"
  # info/ is missing when init.templateDir holds only hooks, as Maxxton's does.
  mkdir -p "$(dirname "$EXCLUDE")"
  printf '/.claude/worktrees/\n' >> "$EXCLUDE"
fi

if git show-ref --verify --quiet "refs/heads/$BRANCH"; then
  # Branch exists locally — check it out into the new worktree
  git worktree add "$WORKTREE_PATH" "$BRANCH"
elif git show-ref --verify --quiet "refs/remotes/origin/$BRANCH"; then
  # Branch exists on remote only — create local tracking branch in the worktree
  git worktree add -b "$BRANCH" "$WORKTREE_PATH" "origin/$BRANCH"
else
  # New branch — create from the specified base
  git worktree add -b "$BRANCH" "$WORKTREE_PATH" "origin/$BASE"
fi

ABS_PATH=$(cd "$WORKTREE_PATH" && pwd)
echo ""
echo "Worktree created:"
echo "  Branch:  $BRANCH  (based on origin/$BASE)"
echo "  Path:    $ABS_PATH"
