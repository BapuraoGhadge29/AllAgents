#!/usr/bin/env bash
# Usage: select-base-branch.sh <prefix> <priority>
# Prints candidate base branches, one per line.
# - hotfix or feature with priority < 3: origin/main + latest release/* (if any)
# - bugfix or feature with priority >= 3: origin/develop (fallback main/master)
# Callers should present AskUserQuestion only when output has 2 lines.
set -euo pipefail

if [ $# -lt 2 ]; then
  echo "Usage: select-base-branch.sh <prefix> <priority>" >&2
  exit 1
fi

PREFIX="$1"
PRIORITY="$2"
PRIO_NUM=$(echo "$PRIORITY" | grep -oE '[0-9]+' || echo "99")

git fetch --prune --quiet

_main() {
  if git show-ref --verify --quiet refs/remotes/origin/main; then
    echo "origin/main"
  elif git show-ref --verify --quiet refs/remotes/origin/master; then
    echo "origin/master"
  else
    echo "ERROR: neither origin/main nor origin/master found" >&2
    exit 1
  fi
}

_develop() {
  if git show-ref --verify --quiet refs/remotes/origin/develop; then
    echo "origin/develop"
  else
    _main
  fi
}

_latest_release() {
  git branch -r | grep -E "origin/release/[0-9]{4}\.[0-9]+" | awk '{print $1}' | sort -t/ -k3 -Vr | head -1
}

_high_priority() {
  _main
  latest=$(_latest_release)
  if [ -n "$latest" ]; then
    echo "$latest"
  fi
}

case "$PREFIX" in
  hotfix)
    _high_priority
    ;;
  bugfix)
    _develop
    ;;
  feature)
    if [ "$PRIO_NUM" -lt 3 ]; then
      _high_priority
    else
      _develop
    fi
    ;;
  *)
    echo "Unknown prefix: $PREFIX" >&2
    exit 1
    ;;
esac
