#!/usr/bin/env bash
# Usage: derive-branch-name.sh <issuetype> <priority> <ticket-key>
# Outputs the full branch name per Maxxton naming conventions.
set -euo pipefail

if [ $# -lt 3 ]; then
  echo "Usage: derive-branch-name.sh <issuetype> <priority> <ticket-key>" >&2
  exit 1
fi

ISSUETYPE="$1"
PRIORITY="$2"
TICKET="$3"

PRIO_NUM=$(echo "$PRIORITY" | grep -oE '[0-9]+' || echo "99")

if [ "$ISSUETYPE" = "Bug" ]; then
  if [ "$PRIO_NUM" -lt 3 ]; then
    echo "hotfix/$TICKET"
  else
    echo "bugfix/$TICKET"
  fi
else
  echo "feature/$TICKET"
fi
