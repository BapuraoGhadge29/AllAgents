---
name: debugging-maxxton-workloads
description: "Gathers evidence on services running on Maxxton GKE, Cloud Run or buddy pipelines: resolves cluster and namespace through buddy, then checks pods, connectivity, logs and errors. Use when debugging a deployed service, in systematic-debugging Phase 1, or for \"check the pods in mxts\".\n"
allowed-tools:
- Bash
- Read
- mcp__claude_ai_Buddy__list_environments
- mcp__claude_ai_Buddy__list_apps
- mcp__claude_ai_Buddy__get_app
- mcp__claude_ai_Buddy__get_deployment
- mcp__claude_ai_Buddy__list_pipeline_runs
- mcp__claude_ai_Buddy__get_pipeline_run
---

# Debugging Maxxton Workloads

Evidence gathering for anything deployed on Maxxton infrastructure. When
`superpowers:systematic-debugging` is active, this is how its Phase 1 collects evidence here;
its process, hypotheses and fix discipline still apply.

Standing rules for the whole investigation:

- **Resolve, never guess.** Cluster, project, region and namespace come from buddy, not from
  memory or a table. Buddy is the source of truth for where workloads run.
- **Read-only by default.** Ask before anything that changes state: creating a probe pod,
  `port-forward` to production, restarting, scaling, deleting or rolling back.
- **Price every BigQuery query first.** Dry-run it; above $2, ask the user with the total
  cost before running, and fall back to `gcloud logging read` or the Trace API if they
  decline.
- **Empty is not evidence.** Several Maxxton sources return nothing instead of an error when
  you look in the wrong place (log buckets, Error Reporting, PromQL). Before concluding "no
  logs" or "no errors", confirm with a query that must return something.

## Step 1 — Resolve where it runs

| You know | Call | Use from the result |
|---|---|---|
| Namespace | `list_environments(namespace=...)` | `kubectlContext`, `getCredentials`, `gcp.*` |
| Cluster or project | `list_environments(cluster=...)` / `(project=...)` | same |
| App / repository | `list_apps(search=...)` → `get_app(owner, repository)` | latest deployment's `resources.lookup` and `instanceSelector` |
| A specific revision | `get_deployment(owner, repository, envName, revision)` | that revision's release, chart and lookups |
| A build or deploy | `list_pipeline_runs(search=...)` → `get_pipeline_run` | linked deployments and the ready-made `gcloud logging read` command |

If `list_environments` is missing, the buddy MCP predates it: go through `get_app`. If buddy
has no match, ask the user rather than picking a cluster.

Run every command with an explicit `--context "$CTX"` and `-n "$NS"`, never the current
context. If the context is not in the kubeconfig, run the `getCredentials` command buddy
returned.

## Step 2 — Workload state

```bash
kubectl --context "$CTX" -n "$NS" get pods -l "$SEL" -o wide      # status, restarts, pod IP, node
kubectl --context "$CTX" -n "$NS" describe pod "$POD"             # last state, exit code, probes
kubectl --context "$CTX" -n "$NS" get events --sort-by=.lastTimestamp | tail -30
kubectl --context "$CTX" -n "$NS" logs "$POD" --all-containers --tail=200
kubectl --context "$CTX" -n "$NS" logs "$POD" --all-containers --previous   # after a restart or OOMKill
```

Without a selector from buddy, drop `-l "$SEL"` and filter by name.

### Cloud Run services

When the service runs on Cloud Run, skip the kubectl steps. Take the project from buddy
(`get_app` → `gcp.project`) or the repo's deploy config, and pass `--project` and `--region`
explicitly:

```bash
gcloud run services describe "$SVC" --project "$PROJECT" --region "$REGION"   # URL, ingress, serving revision
gcloud run revisions list --service "$SVC" --project "$PROJECT" --region "$REGION"
gcloud logging read "resource.type=cloud_run_revision AND resource.labels.service_name=$SVC" \
  --project "$PROJECT" --freshness=1d --limit=50
```

Compare the serving revision with the previous one (image, env, secrets). Ask before
`update-traffic` or any rollback.

## Step 3 — Connectivity

Pod IPs are internal to the VPC, so they are reachable only from inside the cluster or over
the VPN. In order of preference:

1. `kubectl --context "$CTX" -n "$NS" exec "$POD" -- <check>` from a pod that already has the tooling.
2. `kubectl --context "$CTX" -n "$NS" port-forward "pod/$POD" 8080:8080` and test locally. Ask first in production.
3. A throwaway probe pod. It creates a resource, so ask first:
   `kubectl --context "$CTX" -n "$NS" run "netcheck-$RANDOM" --rm -i --restart=Never --image=busybox:1.36 -- nc -zv -w 3 "$IP" 8080`

A timeout from a probe pod does not prove the target is down. Namespaces run default-deny
NetworkPolicies, and egress is granted through the `*.firewall.maxxton.com` labels that a
bare probe pod lacks. Probe from a labelled pod, or check the policies with
`kubectl --context "$CTX" -n "$NS" get networkpolicy`, before blaming the target.

`kubectl --context "$CTX" -n "$NS" auth can-i <verb> <resource> --as <principal>` checks RBAC
only, never IAM. For IAM questions use `gcloud policy-troubleshoot iam`.

## Step 4 — Logs, traces, errors and metrics

Read `${CLAUDE_SKILL_DIR}/references/logs-and-errors.md` before the first `gcloud logging`,
`bq query`, Error Reporting or PromQL query. Default queries silently miss Maxxton logs.
Use `gcloud logging read` to read individual entries and `bq query` on the linked log and
trace datasets for anything that counts or ranks.

## Step 5 — Known silent failures

When the evidence shows a service that is "up but wrong" (config ignored, secret looks set but
fails, a deploy that did something unexpected), read
`${CLAUDE_SKILL_DIR}/references/known-failure-modes.md` and check each matching entry before
forming a hypothesis.

## Examples

User says: "List a pod IP in mxts and try port 8080." Call
`list_environments(namespace="mxts")`, run `get pods -o wide` with the returned context, then
follow Step 3 and ask before creating a probe pod.

User says: "reservation-service has no logs since this morning." Go to Step 4: query
`eu-app-log-bucket` on `jsonPayload.message` before concluding anything.

User says: "Which endpoints return the most 5xx in the last hour?" Go to Step 4: one
`bq query` on `<project>.trace_spans._AllSpans` with `--location=US`, a `start_time` filter
and `--maximum_bytes_billed`, grouped by service and route. Do not page through
`gcloud logging read`.

## Troubleshooting

- **Buddy tools are not available:** the Buddy connector is not authorised in claude.ai.
  Tell the user, and do not fall back to guessing a cluster.
- **`kubectl` reports `Unable to connect to the server`:** clusters only accept allowlisted
  networks. Report it as an access gap, not a cluster outage.
- **`gke-gcloud-auth-plugin` is missing:** this is deliberate in some runners (claude-runner).
  Report that kubectl is unavailable there.

## Hand-back

Report what you checked, with the exact commands and the context and namespace used. Separate
observed facts from inferences, and state what you could not check and why (access, a missing
tool, a step that needed approval). Then return to the debugging process for hypothesis
forming.
