# Accepted overrides — debugging-maxxton-workloads

## `disable-model-invocation` omitted (model-invocable from day one)

**Override reason (strong):** the skill is the target of a hook-driven chain.
`plugins/developer/hooks/debugging-companion.py` tells Claude to load it whenever
`superpowers:systematic-debugging` is loaded. With the flag set, Claude could not act on
that instruction, which is the same dead end recorded for `reviewing-pre-pr`.

**Side effects:** none by default. The skill reads cluster state, logs and buddy metadata.
Every state-changing step (probe pod, production `port-forward`, restart, scale, delete,
rollback) is behind an explicit "ask first" standing rule.

**Spurious-trigger control:** the description names Maxxton GKE, Cloud Run and buddy, not
generic "debug" or "fix", so it does not compete with `systematic-debugging` on local code
or test failures. The hook text also tells Claude to skip it for those.

## Bash rather than PowerShell

`diagnosing-oom-kills` and `detecting-memory-leaks` use PowerShell. This skill uses bash
because it must work in Claude Code cloud sessions, which run Linux. The commands are plain
`kubectl` and `gcloud` and also run under Git Bash on Windows.
