# Known Silent Failure Modes

Each entry gives the symptom, then the cause and the quickest check. These are cases where
nothing errors and the system quietly does something else.

## Config and secrets

- **Env var has no effect.** Fundamentals lowercases env var names and splits them on `_`, so
  an env var can never set a camelCase key (`MONGODB_ATLAS_USE_ATLAS` sets
  `mongodb.atlas.use.atlas`). Values in `config/application-*.yaml` are baked into the image.
- **Python service runs with empty config.** If `APP_NAME` is not `<baseName>-<component>`,
  the loader asks for a non-existent ConfigMap, gets a 403 and carries on with no config.
- **Feature flag never turns on.** `Settings.get(x) === "true"` is false when YAML returns a
  native boolean `true`.

## Deploy and chart

- **An environment disappeared after a deploy.** `enabled: false` in `deploy-<env>.yml` runs a
  terraform destroy for that environment. It does not skip the deploy.
- **A deploy.yaml setting does nothing.** The `app` chart silently ignores `tf-app`-only keys
  (`oauthProxy`/IAP, BigQuery, CIDR egress). tf-app ignores `secrets:` under a component.
  Check the key exists in the chart actually deployed (`get_deployment` → `chartName`).
- **Long requests cut off at about 60s.** `gateway.settings.timeout` (default 60) is an idle
  timeout on `INGRESS` (nginx), but a cap on the *total* response time on `GATEWAY` and
  `GKE_INGRESS`. Keepalive bytes do not help behind GATEWAY.
- **IAP or Cloud Armor bypassed.** `gateway.controller: [INGRESS, GATEWAY]` creates two live
  fronts on separate IPs, and only the Gateway is protected.
- **Raw `*.run.app` URL reachable.** Cloud Run behind a load balancer without
  `INGRESS_TRAFFIC_INTERNAL_LOAD_BALANCER` lets an `allUsers` binding skip IAP and Cloud
  Armor.

## Database and network

- **Cannot connect to Cloud SQL.** PSC-only instances need Cloud SQL Auth Proxy v2 with
  `--psc`, an A record in the private zone `sql-goog-<region>`, and egress on port **3307**.
  The platform NetworkPolicy `default-egress-allow-to-cloudsql-<instance>` allows only 5432,
  so the symptom is `i/o timeout`.
- **`UCP-29: Failed to get a connection`.** The Oracle UCP pool is exhausted. The wait timeout
  is 30s in production and the pool max is 10 unless overridden per concern. This is usually
  a symptom of locks or slow remote calls held inside transactions, not the root cause.
  Look at `db_pool_connections_*` pending vs borrowed per concern.

## buddy

- **Pipeline status looks stale.** `get_pipeline_run` can lag the cluster by up to a minute.
  Re-read it before acting on "still running".
- **A pipeline task was skipped, not failed.** In Tekton, a failed task publishes no results,
  so `when` guards that depend on them skip the downstream task.
