# Logs, Errors and Metrics on Maxxton GCP

## Cloud Logging

- **App logs live in a custom regional bucket**, not `_Default`. In `maxxton-software` the
  `app-logs` sink routes `mxts*` namespace logs to `eu-app-log-bucket`, and `_Default`
  excludes them. Query the bucket explicitly:

  ```bash
  gcloud logging sinks list --project "$PROJECT"        # find where a namespace's logs go
  gcloud logging read "$FILTER" --project "$PROJECT" \
    --bucket=eu-app-log-bucket --location=eu --view=_AllLogs --freshness=1d --limit=50
  ```

- **`roles/logging.viewer` is not enough** for custom buckets. `entries.list` then returns
  nothing, with no error. You also need `roles/logging.viewAccessor` on the bucket view.
- **The message is in `jsonPayload.message`**, not `textPayload`. A `textPayload:"..."`
  filter silently matches nothing. Filter on `jsonPayload.message` or `jsonPayload.concern`.
- **`gcloud logging read` fetches entries; `bq query` counts them.** Use `gcloud logging read`
  to look at individual entries. For anything that aggregates (counts, top errors, per-service
  or per-concern breakdowns, trends), query the BigQuery linked datasets instead of paging
  through entries. See [BigQuery: aggregate logs and traces](#bigquery-aggregate-logs-and-traces).
- **buddy pipeline step logs** go to project `dynamic-concept-192711`, namespace
  `mxtb-pipelines`. Use the command `get_pipeline_run` returns. The deployed app's own logs
  stay in the service project.
- **Integration-test pods in the `mxts` namespace on dev02 are not shipped to Cloud Logging.**
  An empty query is a collection gap. Capture them while the job runs, with the context from
  `list_environments(namespace="mxts")`:
  `kubectl --context "$CTX" -n "$NS" logs -l job-name=<release> -c <release> -f`, or read the
  JUnit XML in the run's artifacts.

Sanity check: before reporting "no logs", run the same query without the narrowing terms and
confirm it returns entries.

## BigQuery: aggregate logs and traces

Every project built on the `gcp-project` Terraform module (maxxton-develop, maxxton-acceptance,
maxxton-software, dynamic-concept-192711, koolecontrols-production) has read-only linked
datasets on its log buckets and Cloud Trace spans. They copy no data; only the bytes a query
scans are billed.

| Dataset view | Source | `--location` |
|---|---|---|
| `<project>.app_logs._AllLogs` | `eu-app-log-bucket` (app logs) | `EU` |
| `<project>.app_logs.apps` | same bucket, only entries from this project | `EU` |
| `<project>.default_logs._AllLogs` | `eu-log-bucket` (everything the `_Default` sink routes) | `EU` |
| `<project>.trace_spans._AllSpans` | Cloud Trace `_Trace` / `Spans` | `US` |

Pick the project by where the workload runs, not by its environment name. Acceptance (acc01)
runs in maxxton-develop, so its traces and app logs are in `maxxton-develop`; filter on
`mxt.active_profile` containing `acceptance`, or on `k8s.cluster.name = "acc01"` in
`resource.attributes`. `maxxton-acceptance.trace_spans` holds only Cloud SQL Query Insights
spans and its `app_logs` is empty. Production is maxxton-software.

Standing rules for every `bq query`:

- **Always filter on time**: `timestamp` for logs, `start_time` for spans. Both prune
  partitions. Start with one hour and widen only when needed. Without a time filter one spans
  query on maxxton-software scans about 4.4 TB, roughly $27.
- **Mind what you read from spans.** `attributes` is billed in full as soon as one key is
  read: one hour of maxxton-software spans costs about 8 GB with any `JSON_VALUE(attributes,
  ...)`, 11 GB with `SELECT *`, but under 0.5 GB for `name` plus `start_time`. Never
  `SELECT *`. For windows longer than a few hours, aggregate once into a small result and
  query that instead of re-scanning.
- **Always pass `--project_id`, `--location` and `--maximum_bytes_billed`.** The job runs in
  `--project_id` (developers hold `bigquery.jobUser` on the service projects); without the
  location the job fails to find the dataset; the cap stops a runaway scan.
- **Dry-run every query and price it before running it.** Run the exact query with
  `--dry_run` and compute the cost at the on-demand rate of $6.25 per TiB:

  ```bash
  BYTES=$(bq query --dry_run --format=json --project_id="$PROJECT" --use_legacy_sql=false \
    --location=US "$SQL" | jq -r .statistics.totalBytesProcessed)
  echo "$BYTES" | awk '{printf "%.1f GB, $%.2f\n", $1/1e9, $1/1099511627776*6.25}'
  ```

  - **$2 or less** (about 350 GB): run it with `--maximum_bytes_billed` set to the dry-run
    bytes, so the real run cannot cost more than was priced.
  - **Over $2**: do not run it. Show the user the query, the bytes and the total cost in
    dollars, and ask for explicit approval. Narrowing the window or dropping `attributes` reads
    usually brings it under $2; offer that too.
  - **Not approved**: fall back to the regular APIs. Use `gcloud logging read` with a tight
    filter and `--limit` for logs, and the Cloud Trace API for traces (below), and say the
    answer comes from a sample rather than a full count.
- **Aggregate personal data, never print it.** `mxt.username`, `mxt.client_id`,
  `mxt.client_ip`, `client.address` and log messages that echo request data identify people.
  Use them in `WHERE`, `GROUP BY` or `COUNT(DISTINCT ...)`, but do not select them into the
  output. Select messages only through the masking in the examples below (emails and digit
  runs replaced, which also groups messages that differ only by id), and do not repeat a
  masked message that still names a person. `db.statement` can carry bound values; leave it
  out too.
- **Logs (EU) and spans (US) cannot be joined in one query.** Correlate with two queries on
  `trace_id`; see below.

### Logs

`json_payload`, `resource.labels` and `labels` are JSON columns: wrap them in `JSON_VALUE`,
or `GROUP BY` fails with "Grouping by expressions of type JSON is not allowed". Apps that do
not log JSON put the message in `text_payload`.

Top error messages per workload in the last hour:

```bash
bq query --project_id=maxxton-software --use_legacy_sql=false --location=EU \
  --maximum_bytes_billed=5000000000 '
SELECT
  JSON_VALUE(resource.labels.namespace_name) AS namespace,
  JSON_VALUE(resource.labels.container_name) AS container,
  LEFT(REGEXP_REPLACE(REGEXP_REPLACE(
    COALESCE(JSON_VALUE(json_payload.message), text_payload),
    r"[\w.+-]+@[\w-]+(\.[\w-]+)+", "<email>"), r"\d+", "#"), 120) AS message,
  COUNT(*) AS n
FROM `maxxton-software.app_logs._AllLogs`
WHERE timestamp >= TIMESTAMP_SUB(CURRENT_TIMESTAMP(), INTERVAL 1 HOUR)
  AND severity = "ERROR"
GROUP BY namespace, container, message
ORDER BY n DESC
LIMIT 20'
```

Swap `message` for `JSON_VALUE(json_payload.concern)` for a per-concern breakdown. Then fetch
a few full entries for the top row with `gcloud logging read`.

### Traces

`attributes` is JSON and `resource` is a RECORD whose `attributes` is JSON. Two span
generations sit side by side, so most fields need a `COALESCE`:

| Field | OTLP spans | Legacy spans |
|---|---|---|
| Service, `service.*`, `gcp.apphub.*`, `mxt.active_profile` | `resource.attributes` | `attributes` |
| Span kind | `kind` (2 = server) | `attributes."/kind"` (`server`), `kind` is NULL |
| HTTP status | `http.response.status_code` | `mxt.status_code` or `/http/status_code` |
| Route | `http.route` | `uri` (templated on services, `UNKNOWN` when unmatched), `mxt.request.uri` (raw path) |

On gateway-server both `uri` and `mxt.request.uri` are raw paths with ids (thousands of
distinct values per hour), so the example replaces numeric and UUID path segments before
grouping.

MXTS request attributes on legacy spans: `mxt.username`, `mxt.concern`, `mxt.client_id`,
`mxt.request.uri`, `mxt.method`, `mxt.status_code`. Other columns: `trace_id`, `span_id`,
`parent_span_id`, `name`, `start_time`, `duration_nano`, `status` (`code`, `message`).

Endpoints with the most 5xx responses in the last hour. Server spans only, so outgoing
client calls are not counted too. A request through gateway-server still appears twice, once
for the gateway and once for the service behind it; add
`AND ... service.name != "gateway-server"` to count it once.

```bash
bq query --project_id=maxxton-software --use_legacy_sql=false --location=US \
  --maximum_bytes_billed=20000000000 '
SELECT
  COALESCE(JSON_VALUE(resource.attributes, "$.\"service.name\""),
           JSON_VALUE(attributes, "$.\"service.name\"")) AS service,
  REGEXP_REPLACE(
    COALESCE(NULLIF(JSON_VALUE(attributes, "$.uri"), "UNKNOWN"),
             JSON_VALUE(attributes, "$.\"http.route\""),
             JSON_VALUE(attributes, "$.\"mxt.request.uri\""), name),
    r"/([0-9]+|[0-9a-fA-F-]{36})\b", "/{id}") AS endpoint,
  COUNT(*) AS errors_5xx,
  COUNT(DISTINCT JSON_VALUE(attributes, "$.\"mxt.username\"")) AS users
FROM `maxxton-software.trace_spans._AllSpans`
WHERE start_time >= TIMESTAMP_SUB(CURRENT_TIMESTAMP(), INTERVAL 1 HOUR)
  AND (kind = 2 OR JSON_VALUE(attributes, "$.\"/kind\"") = "server")
  AND SAFE_CAST(COALESCE(JSON_VALUE(attributes, "$.\"mxt.status_code\""),
                         JSON_VALUE(attributes, "$.\"http.response.status_code\""),
                         JSON_VALUE(attributes, "$.\"/http/status_code\"")) AS INT64) >= 500
GROUP BY service, endpoint
ORDER BY errors_5xx DESC
LIMIT 20'
```

For latency, aggregate `APPROX_QUANTILES(duration_nano / 1e6, 100)[OFFSET(95)]` as p95 in ms.
`users` counts distinct `mxt.username` values without printing them; it is 0 for OTLP-only
services, which do not set that attribute.

### Correlating logs and spans

Spans carry `trace_id` as 32 hex characters; log entries carry
`trace = "projects/<project>/traces/<trace_id>"`. Pick the trace ids from a spans query, then
look up their logs in a second query:

```bash
bq query --project_id=maxxton-software --use_legacy_sql=false --location=EU \
  --maximum_bytes_billed=5000000000 '
SELECT timestamp, severity,
  LEFT(REGEXP_REPLACE(REGEXP_REPLACE(
    COALESCE(JSON_VALUE(json_payload.message), text_payload),
    r"[\w.+-]+@[\w-]+(\.[\w-]+)+", "<email>"), r"\d+", "#"), 200) AS message
FROM `maxxton-software.app_logs._AllLogs`
WHERE timestamp >= TIMESTAMP_SUB(CURRENT_TIMESTAMP(), INTERVAL 1 HOUR)
  AND REGEXP_EXTRACT(trace, r"/traces/([0-9a-f]+)$") IN ("<trace_id>", "<trace_id>")
ORDER BY timestamp'
```

Fallback when a spans query is not approved: list a bounded sample through the Cloud Trace
API instead of BigQuery.

```bash
curl -s -G -H "Authorization: Bearer $(gcloud auth print-access-token)" \
  "https://cloudtrace.googleapis.com/v1/projects/$PROJECT/traces" \
  --data-urlencode "startTime=$(date -u -v-1H +%FT%TZ 2>/dev/null || date -u -d '1 hour ago' +%FT%TZ)" \
  --data-urlencode "filter=+/http/status_code:500" \
  --data-urlencode "view=ROOTSPAN" --data-urlencode "pageSize=100"
```

Only a minority of log entries carry a `trace`, so an empty result does not mean the request
logged nothing.

## Error Reporting

- Use the **regional** endpoint. The global one returns empty for regional buckets, which
  looks like "not found":
  `https://clouderrorreporting.<region>.rep.googleapis.com/v1beta1/projects/<p>/locations/<region>/groupStats?groupId=<id>`
- `roles/errorreporting.viewer` on the project is enough. `roles/logging.viewer` grants no
  Error Reporting permissions. Do not send `x-goog-user-project`, which causes
  `SERVICE_DISABLED`.
- Notification payloads for regional buckets carry only `group_info`. Look up the details
  through the API above.

## Metrics (Google Managed Prometheus)

Query GMP rather than an in-cluster Prometheus:

```bash
curl -s -H "Authorization: Bearer $(gcloud auth print-access-token)" \
  "https://monitoring.googleapis.com/v1/projects/$PROJECT/location/global/prometheus/api/v1/query" \
  --data-urlencode "query=$PROMQL"
```

- GCP system metrics are named `<domain>_googleapis_com:<path_with_underscores>`. A wrong
  name returns an empty success, not an error.
- System metrics are per-interval deltas, so do not wrap them in `rate()` or `increase()`.
- Useful app series: `jvm_threads_live_threads`, `db_pool_connections_*` (label
  `apphub_application_id`).
