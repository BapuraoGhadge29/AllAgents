# Skill Overrides: reviewing-code-quality

## disable-model-invocation not set

**Reason:** Skill is read-only with no side effects (uses only `Read`, `Bash`, `Grep`, `Glob` — no MCP write tools). Already validated as model-invocable in the personal plugin (`steven166/personal`) where it has been in production use. Trigger surface is well-defined and domain-specific ("review this code", "code review before merge").
