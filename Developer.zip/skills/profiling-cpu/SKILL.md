---
name: profiling-cpu
disable-model-invocation: true
argument-hint: "<service-name> [env=production|acceptance|development] [pod=<pod-name>] [duration=60s]"
description: "Profiles CPU consumption in Maxxton JVM/Spring Boot services on GKE. Detects throttling, identifies hot code paths via Cloud Profiler and async-profiler, and recommends limit right-sizing. Use when CPU usage is high, throttling alerts fire, or response times are slow without a database bottleneck in traces.\n"
allowed-tools:
- Bash
- Read
- Edit
- AskUserQuestion
- mcp__claude_ai_Maxxton_Knowledge__get_service_overview
- mcp__claude_ai_GitHub__get_file_contents
- mcp__claude_ai_GitHub__search_code
---

# CPU Consumption Profiler

Systematic CPU investigation for JVM/Spring Boot services on Maxxton GKE (namespaces
`mxts-prod`, `mxts-acc`, `mxts-dev`). Covers throttling detection, Cloud Profiler flamegraphs,
and async-profiler on-demand recordings. All data sourced from GCP and kubectl — no service
restarts required.

---

## How to Use This Skill

Invoke with `/profiling-cpu <service-name>` and optionally pass `env`, `pod`, or `duration`.

| Parameter | Example | Notes |
|---|---|---|
| **service** | `workorder-service` | Required |
| **env** | `production`, `acceptance`, `development` | Required — defaults to production if omitted |
| **pod** | `workorder-service-abc12-xyz` | Optional — targets a specific pod for async-profiler |
| **duration** | `60s` | On-demand profiling duration; default 60s |

**Routing:**

| Input | What happens |
|---|---|
| service + env | Full investigation — throttling → Cloud Profiler → recommend |
| service + env + pod | Targets that pod for async-profiler immediately after throttling check |
| Nothing useful | Ask for service name and environment before proceeding |

---

## Step 1 — Resolve Context

### Environment → Namespace

| Environment | GKE Namespace |
|---|---|
| `production` | `mxts-prod` |
| `acceptance` | `mxts-acc` |
| `development` | `mxts-dev` |

### Confirm tech stack

```
get_service_overview(service_name)
```

Confirms the service runs JVM/Spring Boot. If it is a Node.js service or a frontend
(`-client` suffix), this skill does not apply — suggest `/performance-profiler` instead.

### Resolve GCP project

```powershell
gcloud config get-value project
```

Default Maxxton project: `maxxton-software`. If unset, ask the developer.

---

## Step 2 — Check Current CPU State

### Pod CPU usage vs limits

```powershell
$ns  = "<namespace>"
$svc = "<service-name>"

kubectl top pods -n $ns | Select-String $svc
kubectl describe deployment $svc -n $ns | Select-String -Pattern "cpu" -Context 0,2
```

**Interpret:**
- CPU near or above the pod limit → throttling is likely active; continue to throttling check
- CPU low but responses still slow → CPU is not the bottleneck; suggest `/performance-profiler`
  to examine the request trace instead

### Throttling ratio (PromQL)

Run this query in Grafana to measure how much CPU time the pod is losing to throttling:

```promql
rate(container_cpu_cfs_throttled_seconds_total{
  namespace="<namespace>",
  pod=~"<service-name>.*"
}[5m])
/
rate(container_cpu_cfs_periods_total{
  namespace="<namespace>",
  pod=~"<service-name>.*"
}[5m])
```

| Throttling ratio | Meaning |
|---|---|
| < 10% | Not the issue — proceed to Step 3 to check code-level CPU usage |
| 10–25% | Moderate — worth profiling to see if code can be optimised before raising limits |
| > 25% | Significant — pod regularly hitting its CPU limit; profiling + limit right-sizing both needed |
| > 50% | Severe — causing latency spikes even when `kubectl top` looks normal |

---

## Step 3 — Cloud Profiler (Check Existing Profiles)

Cloud Profiler collects continuous CPU profiles from running pods with near-zero overhead.
Check for existing profiles before running any on-demand tool.

```powershell
$token = (gcloud auth print-access-token)
$start = (Get-Date).AddHours(-24).ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ssZ")

gcloud profiler profiles list `
  --project=maxxton-software `
  --service=<service-name> `
  --start-time=$start `
  --format="table(name, startTime, profileType, duration)"
```

If CPU profiles exist, open them in GCP Console → Cloud Profiler → select service → filter
by time window → flamegraph view. Or download for offline analysis:

```powershell
gcloud profiler profiles export `
  --project=maxxton-software `
  --profile=<PROFILE_NAME> `
  --output=cpu-profile.pb.gz
```

**Reading the flamegraph:**
- Wide bars = code paths consuming the most CPU time
- Look for your service packages (e.g. `com.maxxton.*`) near the top of wide stacks
- `org.springframework.*` wide bars → serialisation or reflection overhead
- `com.sun.proxy.*` wide bars → Spring AOP proxy overhead (too many interceptors)
- GC-related frames dominating → excessive object allocation; see `/detecting-memory-leaks`
- `java.util.regex.*` wide → regex compiled per-call in a hot path; pre-compile as a static field

**If no profiles exist** — Cloud Profiler agent is not attached. Check and proceed to Step 4.

```powershell
kubectl describe deployment <service-name> -n <namespace> | Select-String "cprof\|PROFILER"
# Look for: -agentpath:/opt/cprof/profiler_java_agent.so
```

If missing, the agent is added as a JVM flag (`-agentpath:/opt/cprof/profiler_java_agent.so=,,project_id=maxxton-software`)
in the Helm chart values — requires a rolling redeploy.

---

## Step 4 — On-Demand Profiling

When Cloud Profiler has no data or you need to capture a specific traffic pattern now.

### Option A — async-profiler (recommended, no restart needed)

```powershell
$ns  = "<namespace>"
$pod = "<pod-name>"  # kubectl get pods -n $ns | Select-String "<service-name>"

# Find the JVM PID
kubectl exec $pod -n $ns -- jps -l

# Copy async-profiler into the pod
# Download from: https://github.com/async-profiler/async-profiler/releases
kubectl cp async-profiler.tar.gz "${ns}/${pod}:/tmp/"
kubectl exec $pod -n $ns -- bash -c "cd /tmp && tar xzf async-profiler.tar.gz"

# Record a 60-second CPU flamegraph
kubectl exec $pod -n $ns -- bash -c "/tmp/async-profiler/profiler.sh -d 60 -f /tmp/cpu-flame.html <PID>"

# Copy flamegraph to local machine and open in a browser
kubectl cp "${ns}/${pod}:/tmp/cpu-flame.html" ./cpu-flame.html
```

### Option B — Java Flight Recorder (built into JVM, no external tool)

```powershell
# Start a 2-minute JFR recording
kubectl exec $pod -n $ns -- jcmd <PID> JFR.start duration=120s filename=/tmp/recording.jfr settings=profile

# After 2 minutes, copy it out
kubectl cp "${ns}/${pod}:/tmp/recording.jfr" ./recording.jfr
# Open in JDK Mission Control → Method Profiling tab → hottest methods
```

### Option C — YourKit (Maxxton has a corporate license)

YourKit is a commercial Java profiler with excellent CPU flamegraph and thread-level views.
Maxxton holds a corporate license — ask your team lead for access before using.

Attach YourKit to a running pod by port-forwarding the YourKit agent port (usually 10001):

```powershell
kubectl port-forward $pod 10001:10001 -n $ns
# Then connect YourKit IDE plugin or standalone profiler to localhost:10001
# CPU Profiling → Start → run representative load → Stop → analyse flamegraph
```

See the YourKit docs for full setup: https://www.yourkit.com/docs/java/help/running_profiler.jsp

---

## Step 5 — Identify Hot Code Paths

After obtaining a flamegraph (Steps 3 or 4), match wide bars to known patterns:

| Pattern in flamegraph | Likely cause | Fix direction |
|---|---|---|
| `com.maxxton.*` business method dominates | Inefficient algorithm or unbounded loop | Optimise or cache |
| `ObjectMapper.writeValue` / Jackson wide | Large payload serialised on every request | Reduce response size; use streaming |
| `com.sun.proxy.*` wide on every request | Too many Spring AOP interceptors | Remove unused aspects |
| `java.util.regex.*` wide | Pattern compiled per call | Pre-compile as `static final Pattern` |
| GC / G1GC frames wide | High object allocation rate | See `/detecting-memory-leaks` |
| `BLOCKED` / `waiting on monitor` | Thread contention | Narrow lock scope; use concurrent collections |
| `ForkJoinPool` / `commonPool` wide | `parallelStream()` in production code | **Never use `parallelStream`** on limited CPU cores — the common pool saturates; replace with a sequential stream or a named `@Bean ThreadPoolTaskExecutor` (Maxxton Performance Guide) |
| Many short-lived threads per request | `@Async` without a `ThreadPoolTaskExecutor` | Spring defaults to a new thread per `@Async` call — define a `ThreadPoolTaskExecutor` `@Bean` and set it as the executor |

Ask the user before checking the codebase:

> "I've identified [hot path] as the primary CPU consumer. Would you like me to check
> `MaxxtonGroup/<repo>` to find the specific implementation?"

Use `AskUserQuestion` with **Yes** / **No**.

**If yes — find, fix, and apply (one issue at a time):**

1. **Derive the search query from the flamegraph finding** — extract the class name shown in
   the wide bar (e.g. `com.maxxton.reservation.CacheManager`; use just the class name,
   not the full package).
2. `search_code(repo="MaxxtonGroup/<repo>", query="<ClassName>")` — locate the file and line.
3. `get_file_contents(repo="MaxxtonGroup/<repo>", path="<file>")` — read the implementation.
4. Identify the exact anti-pattern in this specific code against the table above.
5. Produce the **actual fix for this file** — not the generic template but the real change
   to this method (show the specific old lines → new lines as a diff).
6. Ask: *"Should I apply this change?"* using `AskUserQuestion` (Yes / No).
7. **If yes:** apply with `Edit`, then tell the developer: *"Deploy with a rolling restart and
   re-run Step 6 verification once traffic is live."*
8. Ask *"Check the next hottest path?"* — repeat only if the developer says yes.

---

## Step 6 — Fix and Right-Size

### CPU limit right-sizing

```powershell
# Check current requests and limits
kubectl describe deployment <service-name> -n <namespace> | Select-String "cpu" -Context 1,2

# Check actual peak usage across all replicas
kubectl top pods -n <namespace> | Select-String <service-name>
```

**Sizing rule:** CPU limit should be 2–3× the sustained p95 usage from `kubectl top`.
CPU request should be ~50% of limit. If throttling ratio (Step 2) exceeds 25%, double
the limit and re-measure after 24 hours before making further code changes.

### Verify with load testing

After applying a code fix, simulate realistic load to confirm the improvement before closing
the ticket. Maxxton uses K6 and Apache Benchmark for this:

```bash
# Apache Benchmark — 5000 requests, 100 concurrent (simple baseline)
ab -n 5000 -c 100 https://<service-host>/api/your-endpoint

# K6 — scenario-based load test (write in JavaScript)
# See examples: https://k6.io/docs/examples/
k6 run load-test.js
```

After deploying, re-run the exact measurements from Step 2 and compare numbers explicitly:

```powershell
# Re-run pod CPU — compare to the baseline recorded before the fix
kubectl top pods -n <namespace> | Select-String <service-name>
```

Re-run the throttling PromQL from Step 2. Then take a new 60s async-profiler recording
(Step 4 Option A) and compare the hot-path width. Record the result as a before/after:

> "Before: throttling 45%, `CacheManager.get` 38% of CPU time.
>  After: throttling 9%, `CacheManager.get` 4% of CPU time. ✓"

If only one metric improved, the fix was partial — a second hot path may have become
dominant. Re-run Step 5 against the new flamegraph to find it.

---

## Common Pitfalls

- **Profiling only one pod** — hot traffic may land on a specific replica. Always profile the
  pod with the highest CPU from `kubectl top` output.
- **Profiling under no load** — flamegraphs are meaningless without representative traffic.
  Trigger real requests before reading any profile.
- **Raising the CPU limit without fixing the code** — this masks the issue. Identify the hot
  path first; right-size limits after confirming the fix.
- **Attributing slow responses to CPU when the trace shows a DB span** — run `/performance-profiler`
  first to check whether the bottleneck is CPU or a database call.

---

## Examples

User says: `/profiling-cpu workorder-service env=production`
Claude checks the throttling ratio, lists Cloud Profiler profiles for the last 24h, and produces a flamegraph-based hot-path analysis with fix recommendations.

## Troubleshooting

- **No Cloud Profiler profiles found**: the agent is not attached — check for `-agentpath:/opt/cprof/profiler_java_agent.so` in JVM args (Step 3).
- **async-profiler copy fails**: the pod may have a read-only filesystem or restrictive security context — use JFR instead (Step 4 Option B).
- **`kubectl top` shows 0m CPU**: metrics-server may not be running — verify with `kubectl top nodes`; if that also returns no data, contact your cluster administrator.

## Integration with Other Skills

- `/performance-profiler` — run first to confirm CPU (not DB) is the bottleneck via traces
- `/detecting-memory-leaks` — if GC frames are wide in the flamegraph, high allocation is the cause
- `/investigating-alerts` — use when a CPU throttling alert fired and you need incident context
