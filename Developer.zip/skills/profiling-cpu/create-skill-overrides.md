# Skill Overrides: profiling-cpu

## disable-model-invocation not set → N/A (flag is present)

## [SHOULD FIX] No quoted trigger phrase in description

**Reason:** Skill has `disable-model-invocation: true` and is purely user-invoked via
`/profiling-cpu`. Quoted trigger phrases aid auto-invocation discovery, which is disabled
for this skill. Per `best-practices.md`: "Strong override reason: the skill has no natural
user phrasing because it's invoked by a tool/hook, not a human" — equivalent applies here
since the skill is explicitly user-commanded.

## [SHOULD FIX] PowerShell code blocks (OS-specific instructions)

**Reason:** Maxxton GKE investigation skills use PowerShell by established convention.
The companion skill `performance-profiler` (already in production in this plugin) uses
identical PowerShell syntax for GCP REST API calls (`Invoke-RestMethod`) and kubectl
operations. Maxxton developers work on Windows; bash equivalents would require WSL or
a different shell that is not part of the standard Maxxton developer setup. Diverging
from the `performance-profiler` pattern would create inconsistency in the plugin.
