---
name: calling-mxts-api
description: Makes authenticated REST calls to the MXTS dev API through the mxts CLI, installed on demand. Discovers the endpoint from Maxxton OpenAPI specs; the Bearer token never reaches Claude. Use when a developer asks to "call the MXTS API", "query MXTS data", or read across all concerns.
argument-hint: "[describe what you want to do]"
allowed-tools:
- Bash
- mcp__claude_ai_Maxxton_Knowledge__list_openapi_documents
- mcp__claude_ai_Maxxton_Knowledge__query_openapi
- mcp__claude_ai_Maxxton_Knowledge__get_openapi_document
---

# Calling the MXTS API

Makes authenticated REST calls to `https://api-dev.maxxton.net` with the `mxts` CLI (`@maxxton/mxts-sdk`). The CLI attaches the Bearer token itself — it is never printed to Claude's output.

## Prerequisites

- Node.js 20 or newer (`npx` on PATH)
- `gcloud` CLI logged in (`gcloud auth login`) — its access token authenticates the download from the private Maxxton npm registry
- For `--concern all` only: identity has `roles/iam.serviceAccountTokenCreator` on `keycloak-signer-mxts@maxxton-develop.iam.gserviceaccount.com`, and `python3` on PATH
- **Scope**: dev environment only (`api-dev.maxxton.net`, `login-dev.maxxton.net`)

### The `mxts` CLI

Always run the CLI through the bundled launcher, never a bare `mxts`:

```bash
bash "${CLAUDE_SKILL_DIR}/scripts/mxts.sh" <mxts args>
```

The launcher installs nothing globally. Each run resolves `@maxxton/mxts-sdk@latest` through `npx --prefer-online`, so it always uses the newest published version, even when an older `mxts` is installed globally. Registry credentials come from `gcloud auth print-access-token`, written to a throwaway npmrc that is deleted after the run; `~/.npmrc` is neither read nor changed.

The launcher refuses `mxts auth token`, because that prints the token. Never work around this.

### Logging in

Single-concern calls run as the developer, using their `mxts` session for that concern. Sessions are per concern and survive between runs (stored encrypted by the CLI). Check them with:

```bash
bash "${CLAUDE_SKILL_DIR}/scripts/mxts.sh" auth status
```

When a call fails with `not logged in` or `session expired`, log in for that concern and retry the call:

```bash
bash "${CLAUDE_SKILL_DIR}/scripts/mxts.sh" auth login --env=dev --concern=<code>
```

This opens the developer's browser with a one-time code and waits until they confirm it. Tell the developer to confirm the code in their browser, and run the command with a Bash timeout of at least 300000 ms.

### Concern (tenant)

MXTS uses **concerns** to scope data to a specific Keycloak realm/tenant. The default concern is `mxt` (the main Maxxton Software realm). Other concerns — such as `krm` — map to different realms and return different data.

Specify the concern with `--concern <code>` (or `--concern=<code>`) or by exporting `MXTS_CONCERN=<code>` before calling the script.

The special value `--concern all` runs the same GET across **every** concern — see [Querying all concerns](#querying-all-concerns---concern-all).

## Instructions

### Step 1 — Discover the endpoint

Use the Maxxton Knowledge OpenAPI tools to find the right endpoint before calling it.

**Search by topic:**
```
mcp__claude_ai_Maxxton_Knowledge__query_openapi  query="reservations list"
mcp__claude_ai_Maxxton_Knowledge__query_openapi  query="accommodation availability"
```

**Browse all available endpoints:**
```
mcp__claude_ai_Maxxton_Knowledge__list_openapi_documents
```

**Get the full spec for a specific endpoint:**
```
mcp__claude_ai_Maxxton_Knowledge__get_openapi_document  name="<service>/<method>-<path>"
```

From the OpenAPI result, extract: HTTP method, path, required headers, query parameters, and request body schema.

### Step 2 — Make the API call

Use the bundled `call-mxts-api.sh` script. It runs `mxts api` for the dev environment; the token never appears in Claude's context. `GET`, `HEAD` and `OPTIONS` run with `mxts api --readonly`, which also refuses curl options the CLI does not know.

```bash
bash "${CLAUDE_SKILL_DIR}/scripts/call-mxts-api.sh" [--concern <code>] METHOD /path [curl-options]
```

**Important:** `Content-Type: application/json` is set automatically — do not add it manually. Passing it again creates a duplicate header and results in HTTP 415.

**Confirm before any write.** `GET` calls run immediately. For any mutating method (`POST`, `PUT`, `PATCH`, `DELETE`), stop and confirm with the developer first — show the exact concern, method, path, and request body you are about to send, and proceed only after they approve. This matters because the skill is model-invocable: it can be auto-loaded, so a write must never be inferred without explicit go-ahead. Writes always target a single explicit concern (`--concern <code>`); never fan a write across concerns (see [Querying all concerns](#querying-all-concerns---concern-all)).

Examples:

```bash
# GET request (default mxt concern)
bash "${CLAUDE_SKILL_DIR}/scripts/call-mxts-api.sh" GET /accommodations

# GET with a non-default concern
bash "${CLAUDE_SKILL_DIR}/scripts/call-mxts-api.sh" --concern krm GET /accommodations

# GET with query parameters
bash "${CLAUDE_SKILL_DIR}/scripts/call-mxts-api.sh" GET "/accommodations?page=0&size=10"

# POST with a JSON body (no --header needed — Content-Type is already set)
bash "${CLAUDE_SKILL_DIR}/scripts/call-mxts-api.sh" POST /reservations \
    --data '{"guestId": 123, "accommodationId": 456}'

# Custom header (for non-Content-Type headers only)
bash "${CLAUDE_SKILL_DIR}/scripts/call-mxts-api.sh" GET /accommodations \
    --header 'Accept-Language: nl'
```

Transient connection drops (curl exit 56) are retried automatically up to three times. HTTP 4xx/5xx errors are not retried — the response body is always printed so the cause is visible.

### Step 3 — Interpret and present the response

Parse the JSON response and present the relevant fields to the developer.

**Large responses:** pipe through `jq` to extract only the fields you need:

```bash
bash "${CLAUDE_SKILL_DIR}/scripts/call-mxts-api.sh" GET /reservations | jq '.content[] | {id, status, guestId}'
```

**Narrow server-side** with query parameters or request body filters where the API supports it — this is faster than filtering a large payload locally:

```bash
# Filter by clientId to avoid downloading the full dataset
bash "${CLAUDE_SKILL_DIR}/scripts/call-mxts-api.sh" POST /reservations/search \
    --data '{"clientId": 42, "page": 0, "size": 20}'
```

If the response contains an error, check the Troubleshooting section.

## Querying all concerns (`--concern all`)

Use this when a developer wants the same read across **every** tenant (e.g. "which currencies does each concern have?"). The fan-out is **read-only — GET only**. Never run a write (POST/PUT/PATCH/DELETE) across all concerns; writes must target a single explicit concern via `call-mxts-api.sh --concern <code>`.

The bundled `call-mxts-api-all.sh` does the parallel HTTP fan-out and returns one aggregated JSON object; Claude turns that into a report. Each per-concern call still goes through `call-mxts-api.sh` and the `mxts` CLI, so the Bearer token never reaches Claude.

The fan-out does not use the developer's `mxts` sessions — logging in to dozens of concerns in the browser is not practical. It authenticates each concern with a gcloud-signed service-account token, passed to the CLI as `MXTS_TOKEN` (see [Service-account token cache](#service-account-token-cache)).

### Step 1 — Discover the endpoint

Same as the single-concern flow: use the Maxxton Knowledge OpenAPI tools to find the GET endpoint before calling it.

### Step 2 — Confirm it is a GET

`all` mode is read-only. If the developer asked for a write across all concerns, stop and explain that writes must target one concern at a time.

### Step 3 — Run the fan-out

```bash
# Every concern (concern list is fetched live, then fanned out in parallel)
bash "${CLAUDE_SKILL_DIR}/scripts/call-mxts-api-all.sh" GET "/maxxton/v2/currencies?size=50"

# Restrict to a subset (useful for a quick check or a targeted comparison)
bash "${CLAUDE_SKILL_DIR}/scripts/call-mxts-api-all.sh" --concerns mxt,krm,ooa GET "/maxxton/v2/currencies?size=50"
```

The script emits a JSON object keyed by concern code:

```json
{
  "mxt": { "ok": true,  "exit": 0,  "body": { "content": [ ... ] } },
  "dse": { "ok": false, "exit": 22, "body": { "status": 403, "error": "Forbidden" } }
}
```

`ok` is `true` only for HTTP 2xx. Failing concerns keep their error body so the cause is visible (a `403`/`Forbidden` means that tenant does not grant the client access to the endpoint — a genuine per-tenant condition, not a bug).

### Step 4 — Aggregate and report

Parse the keyed JSON and present a concise per-concern summary — typically a table (`concern | ok | key fields`) — and explicitly call out any concerns where `ok` is `false` together with their status code.

For heavy per-concern interpretation you may spawn one subagent per batch of concerns that each runs `call-mxts-api-all.sh --concerns <a,b,c> GET /path` — not `call-mxts-api.sh`, which would need a browser login per concern. The default path is the single aggregated `call-mxts-api-all.sh` run above.

## Common Pitfalls

### Datetime format

MXTS endpoints use the Spring `LocalDateTime` format — ISO-8601 **without** a timezone suffix and **with** milliseconds:

```
2026-05-30T00:00:00.000
```

Do not use `Z` (Zulu/UTC suffix) or omit the milliseconds:

```
2026-05-30T00:00:00.000Z  ← rejected (has Z)
2026-05-30T00:00:00       ← rejected (missing milliseconds)
```

### Content-Type header

Never pass `--header 'Content-Type: application/json'` — the script already sets it. Duplicating it produces HTTP 415 and wastes three retries.

## Service-account token cache

Only `--concern all` uses these tokens. They are cached in four tiers (checked in order), keyed per concern:

| Tier | Storage | Platform | Notes |
|---|---|---|---|
| 1 | `$MXTS_ACCESS_TOKEN` env var | All | Session-only; concern-agnostic — ensure it matches the requested concern |
| 2 | macOS Keychain (`mxts-dev-token-<concern>`) | macOS | OS-encrypted via Keychain Services; survives reboots |
| 3 | DPAPI file (`%LOCALAPPDATA%\mxts\token-<concern>.dpapi`) | Windows (Git Bash / Cygwin) | `ConvertFrom-SecureString` encrypted; only decryptable by same Windows user on same machine |
| 4 | `~/.cache/mxts/token-<concern>` (chmod 600) | Linux / WSL2 | Plaintext; permission-restricted to current user |

A cached token is reused if its JWT `exp` claim is more than 60 s in the future. On cache miss, a fresh token is obtained via `get-mxts-token.sh` and all available tiers are populated. The first all-concern run authenticates every concern (slower); later runs reuse the cached tokens.

To clear the cache manually (replace `<concern>` with e.g. `mxt` or `krm`):

```bash
# macOS Keychain
security delete-generic-password -s mxts-dev-token-<concern> -a mxts 2>/dev/null

# Windows DPAPI file (Git Bash)
rm -f "${LOCALAPPDATA}/mxts/token-<concern>.dpapi"

# Linux / WSL2 file cache
rm -f ~/.cache/mxts/token-<concern>

# Session env var (all platforms)
unset MXTS_ACCESS_TOKEN
```

To end a developer `mxts` session instead:

```bash
bash "${CLAUDE_SKILL_DIR}/scripts/mxts.sh" auth logout --env=dev --concern=<concern>
```

## Examples

User says: "get me a list of accommodations from MXTS"

```bash
bash "${CLAUDE_SKILL_DIR}/scripts/call-mxts-api.sh" GET /accommodations
```

User says: "fetch reservation 12345 from MXTS for the krm concern"

```bash
bash "${CLAUDE_SKILL_DIR}/scripts/call-mxts-api.sh" --concern krm GET /reservations/12345
```

User says: "show me the currencies for every concern"

```bash
bash "${CLAUDE_SKILL_DIR}/scripts/call-mxts-api-all.sh" GET "/maxxton/v2/currencies?size=50"
```

## Troubleshooting

| Error | Cause | Fix |
|---|---|---|
| `command not found` / exit 127 | Wrong script name used | Use `call-mxts-api.sh` (with `mxts`, not `mxt`) |
| `npx not found` / `needs Node.js 20 or newer` | Node.js missing or too old | Install Node.js 20+ |
| `could not get a gcloud access token` | gcloud not logged in | Run `gcloud auth login` |
| npm `E403` / `E401` while resolving `@maxxton/mxts-sdk` | gcloud identity lacks read access on the Maxxton npm registry | Ask a GCP admin for Artifact Registry reader access |
| `not logged in` / `session expired for dev/<realm>` | No valid `mxts` session for that concern | Run `mxts.sh auth login --env=dev --concern=<code>` — see [Logging in](#logging-in) |
| `readonly mode: ... is not allowed` / `unknown curl option ... in readonly mode` | A GET was combined with an option the CLI's readonly guard rejects | Drop the option, or use the method the endpoint needs |
| `PERMISSION_DENIED` on sign-jwt (`--concern all`) | Missing `roles/iam.serviceAccountTokenCreator` | Ask a GCP admin to grant the role on the signer SA |
| HTTP 401 on API call | Session or cached service-account token stale | Log in again, or clear the service-account cache for `--concern all` |
| HTTP 403 on API call | The identity has no access to that endpoint in that concern | A genuine per-tenant condition; check the developer's roles in that concern |
| HTTP 404 on API call | Wrong path or missing path parameter | Re-check the OpenAPI spec with `query_openapi` |
| HTTP 415 on API call | Duplicate `Content-Type` header passed via `--header` | Remove the manual `--header 'Content-Type: application/json'` |
| `token was not issued by realm ...` | `MXTS_TOKEN` is set in the environment for another concern | `unset MXTS_TOKEN` and retry |
