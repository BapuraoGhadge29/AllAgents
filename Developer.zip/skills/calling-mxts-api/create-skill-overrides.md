# create-skill overrides — calling-mxts-api

## Model invocation enabled (`disable-model-invocation` removed)

**Decision:** This skill is model-invocable (the `disable-model-invocation: true` flag has been removed at the user's explicit request).

**Justification:**
- **Read-only by default surface.** Endpoint discovery and the all-concern fan-out (`--concern all` / `call-mxts-api-all.sh`) are strictly GET — the fan-out script refuses any non-GET method, so auto-invocation cannot mutate tenants.
- **Writes are gated and user-initiated.** SKILL.md Step 2 carries an explicit confirmation gate: any mutating method (POST/PUT/PATCH/DELETE) requires the developer to approve the exact concern, method, path, and body before it runs. GETs run immediately; writes never. The exact `call-mxts-api.sh` command is also surfaced as a Bash tool call the user approves, and the token never reaches Claude either way.
- **Dev-only scope.** The skill targets `api-dev.maxxton.net` only; it cannot reach production.
