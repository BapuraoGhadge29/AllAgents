#!/usr/bin/env bash
# Fan a single GET out across every MXTS concern (tenant) and emit one aggregated
# JSON object keyed by concern code. Reuses call-mxts-api.sh per concern, which
# calls the `mxts` CLI. Each concern authenticates with a gcloud-signed service
# account token passed as MXTS_TOKEN, so the fan-out needs no browser login per
# concern. The Bearer token is never printed to stdout.
#
# This is the engine behind the skill's `--concern all` mode. It is READ-ONLY:
# only GET is permitted, because fanning a mutation across all tenants at once is
# dangerous. Writes must target a single explicit concern via call-mxts-api.sh.
#
# Usage:
#   ./call-mxts-api-all.sh [--concerns a,b,c] GET /path [extra curl args...]
#
#   --concerns a,b,c   Restrict the fan-out to an explicit comma-separated subset
#                      (primarily for testing). Also accepts --concerns=a,b,c.
#                      When omitted, the full concern list is fetched live.
#
# Examples:
#   ./call-mxts-api-all.sh GET "/maxxton/v2/currencies?size=50"
#   ./call-mxts-api-all.sh --concerns mxt,krm,ooa GET "/maxxton/v2/currencies?size=50"
#
# Output (stdout): a JSON object
#   { "<code>": { "ok": <bool>, "exit": <int>, "body": <json-or-string> }, ... }

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
CALL="${SCRIPT_DIR}/call-mxts-api.sh"
TOKEN="${SCRIPT_DIR}/get-mxts-token-cached.sh"

# Max concurrent per-concern calls. Bounded so we never fire dozens of
# `gcloud sign-jwt` authentications simultaneously on a cold cache.
MAX_PARALLEL="${MXTS_ALL_PARALLEL:-6}"
if ! [[ "${MAX_PARALLEL}" =~ ^[1-9][0-9]*$ ]]; then
    echo "ERROR: MXTS_ALL_PARALLEL must be a positive integer (got '${MAX_PARALLEL}')." >&2
    exit 2
fi

# ── Parse --concerns flag ────────────────────────────────────────────────────
CONCERNS_CSV=""
PASSTHROUGH_ARGS=()
while [[ $# -gt 0 ]]; do
    case "$1" in
        --concerns)
            CONCERNS_CSV="${2:?--concerns requires a value (e.g. --concerns mxt,krm)}"
            shift 2
            ;;
        --concerns=*)
            CONCERNS_CSV="${1#--concerns=}"
            shift
            ;;
        *)
            PASSTHROUGH_ARGS+=("$1")
            shift
            ;;
    esac
done
set -- "${PASSTHROUGH_ARGS[@]}"

METHOD="${1:?Usage: call-mxts-api-all.sh [--concerns a,b,c] GET /path [curl-options...]}"
API_PATH="${2:?Missing API path}"
shift 2

# ── GET-only guard ───────────────────────────────────────────────────────────
# `all` mode is read-only by design — fanning a write across every tenant is unsafe.
METHOD_UC="$(printf '%s' "${METHOD}" | tr '[:lower:]' '[:upper:]')"
if [[ "${METHOD_UC}" != "GET" ]]; then
    echo "ERROR: --concern all is read-only — only GET is allowed (got '${METHOD}')." >&2
    echo "       To write, target a single concern: call-mxts-api.sh --concern <code> ${METHOD} ${API_PATH}" >&2
    exit 2
fi

# Resolve @maxxton/mxts-sdk@latest once, not once per concern.
if [[ -z "${MXTS_BIN:-}" ]]; then
    MXTS_BIN="$(bash "${SCRIPT_DIR}/mxts.sh" --which)"
    export MXTS_BIN
fi

call_as_service_account() {
    local concern="$1"; shift
    local token
    token="$("${TOKEN}" "${concern}")" || return 1
    MXTS_TOKEN="${token}" "${CALL}" --concern "${concern}" "$@"
}

# ── Resolve the concern list ─────────────────────────────────────────────────
CONCERNS=()
if [[ -n "${CONCERNS_CSV}" ]]; then
    IFS=',' read -r -a CONCERNS <<< "${CONCERNS_CSV}"
else
    # The concern-list endpoint only authorizes with an mxt-concern token — pin it.
    echo "[mxts-all] Fetching concern list..." >&2
    CONCERNS_JSON="$(call_as_service_account mxt GET /api/v1/maxxton/concerns)"
    # Portable array build (no `mapfile` — unavailable on macOS Bash 3.2).
    while IFS= read -r code; do
        [[ -n "${code}" ]] && CONCERNS+=("${code}")
    done < <(printf '%s' "${CONCERNS_JSON}" | python3 -c '
import sys, json
for c in json.load(sys.stdin):
    code = c.get("code")
    if code:
        print(code)
')
fi

# Validate/normalize concern codes: they become filenames under WORK_DIR and the
# --concerns list is user-supplied, so strip whitespace and reject anything that
# is not a plain code (blocks path traversal like `../x` and CSV entries with spaces).
VALID_CONCERNS=()
for c in "${CONCERNS[@]}"; do
    c="$(printf '%s' "${c}" | tr -d '[:space:]')"
    [[ -z "${c}" ]] && continue
    if ! [[ "${c}" =~ ^[a-z0-9]+$ ]]; then
        echo "ERROR: invalid concern code '${c}' — expected lowercase letters and digits only." >&2
        exit 2
    fi
    VALID_CONCERNS+=("${c}")
done
CONCERNS=("${VALID_CONCERNS[@]}")

if [[ ${#CONCERNS[@]} -eq 0 ]]; then
    echo "ERROR: no concerns to query." >&2
    exit 1
fi

echo "[mxts-all] Fanning GET ${API_PATH} across ${#CONCERNS[@]} concern(s) (max ${MAX_PARALLEL} in parallel)..." >&2

# ── Fan out (bounded parallelism) ────────────────────────────────────────────
WORK_DIR="$(mktemp -d "${TMPDIR:-/tmp}/mxts-all.XXXXXX")"
trap 'rm -rf "${WORK_DIR}"' EXIT

run_one() {
    local concern="$1"; shift
    local body_file="${WORK_DIR}/${concern}.body"
    local err_file="${WORK_DIR}/${concern}.err"
    local exit_file="${WORK_DIR}/${concern}.exit"
    local rc=0
    # Capture stderr so token/curl failures that produce no response body are
    # still diagnosable from the aggregated JSON (surfaced as `body` below).
    call_as_service_account "${concern}" GET "${API_PATH}" "$@" > "${body_file}" 2>"${err_file}" || rc=$?
    printf '%s' "${rc}" > "${exit_file}"
}

for concern in "${CONCERNS[@]}"; do
    [[ -z "${concern}" ]] && continue
    run_one "${concern}" "$@" &
    # Throttle: wait whenever we hit the parallelism cap. `wait -n` blocks until a
    # job finishes on Bash 4+; on Bash 3.2 it isn't supported and returns at once,
    # so fall back to a short sleep to avoid a CPU-spinning busy-loop.
    while [[ "$(jobs -rp | wc -l)" -ge "${MAX_PARALLEL}" ]]; do
        wait -n 2>/dev/null || sleep 0.2
    done
done
wait

# ── Aggregate into a single keyed JSON object ────────────────────────────────
# Each concern's body is parsed as JSON when possible, else kept as a raw string
# so HTTP-error bodies survive. ok = (exit code 0, i.e. HTTP 2xx via --fail-with-body).
# Concern codes are passed via a file (not stdin) because `python3 -` consumes the
# heredoc on stdin for its own script source.
printf '%s\n' "${CONCERNS[@]}" > "${WORK_DIR}/_concerns.txt"
python3 - "${WORK_DIR}" <<'PYEOF'
import sys, os, json

work_dir = sys.argv[1]
result = {}
with open(os.path.join(work_dir, "_concerns.txt")) as cf:
    concern_lines = cf.readlines()
for line in concern_lines:
    concern = line.strip()
    if not concern:
        continue
    body_path = os.path.join(work_dir, f"{concern}.body")
    exit_path = os.path.join(work_dir, f"{concern}.exit")
    try:
        with open(exit_path) as f:
            rc = int(f.read().strip() or "1")
    except OSError:
        rc = 1
    raw = ""
    try:
        with open(body_path) as f:
            raw = f.read()
    except OSError:
        pass
    try:
        body = json.loads(raw) if raw.strip() else None
    except ValueError:
        body = raw
    # On failure with no response body (e.g. token acquisition or a connection
    # error before any HTTP response), surface captured stderr so the cause isn't lost.
    if rc != 0 and (body is None or body == ""):
        try:
            with open(os.path.join(work_dir, f"{concern}.err")) as ef:
                err_text = ef.read().strip()
        except OSError:
            err_text = ""
        if err_text:
            body = err_text
    result[concern] = {"ok": rc == 0, "exit": rc, "body": body}

json.dump(result, sys.stdout, indent=2, ensure_ascii=False)
sys.stdout.write("\n")
PYEOF
