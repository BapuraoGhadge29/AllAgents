#!/usr/bin/env bash
# Run the latest `mxts` CLI (@maxxton/mxts-sdk) through npx.
#
# Usage:
#   ./mxts.sh <mxts args...>      e.g. ./mxts.sh auth status
#   ./mxts.sh --which             print the path of the resolved mxts binary
#
# Every run re-resolves @maxxton/mxts-sdk@latest against the private Artifact
# Registry, so a globally installed (possibly older) `mxts` is never used. Set
# MXTS_BIN to a path from `--which` to skip the resolution (the fan-out does this
# once instead of once per concern).

set -euo pipefail

PACKAGE="@maxxton/mxts-sdk@latest"
REGISTRY="https://europe-npm.pkg.dev/dynamic-concept-192711/maxxton-npm-registry/"

# The CLI joins every non-flag word into the command and flags may come first,
# with values as separate words (`--env dev auth token`), or one word may hold both.
# Only `api` owns the args after `--` (curl's); elsewhere keep scanning past it, so
# the guard does not rely on how a future @latest treats a misplaced separator.
COMMAND_WORDS=""
for arg in "$@"; do
    if [[ "${arg}" == "--" ]]; then
        [[ "${COMMAND_WORDS}" == " api" ]] && break
        continue
    fi
    [[ "${arg}" == -* ]] && continue
    COMMAND_WORDS="${COMMAND_WORDS} ${arg}"
done
COMMAND_WORDS="$(printf '%s' "${COMMAND_WORDS}" | tr -s '[:space:]' ' ')"
if [[ "${COMMAND_WORDS} " == *" auth token "* ]]; then
    echo "ERROR: 'mxts auth token' prints the bearer token; use 'mxts api' so the token stays out of the output." >&2
    exit 2
fi

if [[ -n "${MXTS_BIN:-}" && "${1:-}" != "--which" ]]; then
    exec "${MXTS_BIN}" "$@"
fi

if ! command -v npx >/dev/null 2>&1; then
    echo "ERROR: npx not found. Install Node.js 20 or newer (https://nodejs.org) and retry." >&2
    exit 1
fi
NODE_MAJOR="$(node -p 'process.versions.node.split(".")[0]' 2>/dev/null || echo 0)"
if [[ "${NODE_MAJOR}" -lt 20 ]]; then
    echo "ERROR: @maxxton/mxts-sdk needs Node.js 20 or newer (found $(node --version 2>/dev/null || echo none))." >&2
    exit 1
fi

if ! REGISTRY_TOKEN="$(gcloud auth print-access-token 2>/dev/null)" || [[ -z "${REGISTRY_TOKEN}" ]]; then
    echo "ERROR: could not get a gcloud access token for the Maxxton npm registry. Run: gcloud auth login" >&2
    exit 1
fi

# A throwaway userconfig replaces ~/.npmrc for this run only, so a stale
# registry token there cannot shadow the fresh one and nothing is persisted.
NPMRC_DIR="$(mktemp -d "${TMPDIR:-/tmp}/mxts-npmrc.XXXXXX")"
trap 'rm -rf "${NPMRC_DIR}"' EXIT
NPMRC="${NPMRC_DIR}/npmrc"
(
    umask 077
    printf '@maxxton:registry=%s\n//%s:_authToken=%s\n' \
        "${REGISTRY}" "${REGISTRY#https://}" "${REGISTRY_TOKEN}" > "${NPMRC}"
)

NPX=(npx --yes --prefer-online --loglevel=error --package="${PACKAGE}")

if [[ "${1:-}" == "--which" ]]; then
    NPM_CONFIG_USERCONFIG="${NPMRC}" "${NPX[@]}" -- node -e '
const { execFileSync } = require("node:child_process");
const cmd = process.platform === "win32" ? "where" : "which";
process.stdout.write(execFileSync(cmd, ["mxts"]).toString().split(/\r?\n/)[0] + "\n");
'
    exit 0
fi

# Not exec: the EXIT trap must still remove the npmrc holding the registry token.
NPM_CONFIG_USERCONFIG="${NPMRC}" "${NPX[@]}" -- mxts "$@"
