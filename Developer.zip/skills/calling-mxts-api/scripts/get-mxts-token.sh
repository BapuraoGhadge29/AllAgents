#!/usr/bin/env bash
# Obtain a fresh Maxxton Software (MXTS) Bearer token via GCP service account
# JWT authentication. Outputs the token to stdout; all other messages go to stderr.
#
# Prerequisites:
#   - gcloud CLI authenticated (gcloud auth application-default login, or Workload Identity)
#   - Your identity has roles/iam.serviceAccountTokenCreator on the signer SA
#   - python3 and curl on PATH
#
# Usage:
#   ./get-mxts-token.sh [concern]
#
# Usually called via get-mxts-token-cached.sh — invoke directly only to force
# a fresh token regardless of cache state.

set -euo pipefail

CONCERN="${1:-mxt}"
SIGNER_SA="keycloak-signer-mxts@maxxton-develop.iam.gserviceaccount.com"
KEYCLOAK_CLIENT="mxts-maxxton-software-development"
LOGIN_BASE="https://login-dev.maxxton.net"

# Step 1: Resolve realm from concern
REALM_JSON=$(curl -sf "${LOGIN_BASE}/authenticate/realms/master/concerns/${CONCERN}/realm")
REALM=$(echo "${REALM_JSON}" | python3 -c "import sys,json; print(json.load(sys.stdin)['realm'])")
echo "Realm: ${REALM}" >&2

# Step 2: Get current GCP identity — fail fast if unset
IDENTITY=$(gcloud config get-value account 2>/dev/null)
if [[ -z "${IDENTITY}" || "${IDENTITY}" == "(unset)" ]]; then
    echo "ERROR: No active gcloud account. Run: gcloud auth application-default login" >&2
    exit 1
fi
echo "Identity: ${IDENTITY}" >&2

# Step 3: Build JWT payload
# Use a unique temp DIR (terminal XXXXXX → randomized on both GNU and BSD/macOS
# mktemp). A fixed filename collides when several concerns authenticate at once,
# e.g. during the all-concern fan-out (call-mxts-api-all.sh).
JWT_TMP_DIR=$(mktemp -d "${TMPDIR:-/tmp}/mxts-jwt.XXXXXX")
PAYLOAD_FILE="${JWT_TMP_DIR}/payload.json"
SIGNED_FILE="${JWT_TMP_DIR}/payload.signed.json"
trap 'rm -rf "${JWT_TMP_DIR}"' EXIT

python3 - "${PAYLOAD_FILE}" "${KEYCLOAK_CLIENT}" "${LOGIN_BASE}" "${REALM}" "${IDENTITY}" <<'PYEOF'
import sys, json, time, uuid
payload_file, client_id, login_base, realm, identity = sys.argv[1:]
now = int(time.time())
payload = {
    "iss": client_id,
    "sub": client_id,
    "aud": f"{login_base}/authenticate/realms/{realm}",
    "exp": now + 300,
    "iat": now,
    "jti": str(uuid.uuid4()),
    "act": {"sub": identity}
}
with open(payload_file, "w") as f:
    json.dump(payload, f)
PYEOF

# Step 4: Sign the JWT
gcloud iam service-accounts sign-jwt \
    --iam-account="${SIGNER_SA}" \
    "${PAYLOAD_FILE}" "${SIGNED_FILE}" >&2

# Step 5: Exchange for Keycloak access token
# Strip trailing newlines to avoid %0A encoding in the curl --data-urlencode
JWT_TOKEN=$(tr -d '\n\r' < "${SIGNED_FILE}")
RESPONSE=$(curl -sf \
    --location "${LOGIN_BASE}/authenticate/realms/${REALM}/protocol/openid-connect/token" \
    --header 'Content-Type: application/x-www-form-urlencoded' \
    --data-urlencode 'grant_type=client_credentials' \
    --data-urlencode "client_id=${KEYCLOAK_CLIENT}" \
    --data-urlencode 'client_assertion_type=urn:ietf:params:oauth:client-assertion-type:jwt-bearer' \
    --data-urlencode "client_assertion=${JWT_TOKEN}")

ACCESS_TOKEN=$(echo "${RESPONSE}" | python3 -c "import sys,json; print(json.load(sys.stdin)['access_token'])")
EXPIRES_IN=$(echo "${RESPONSE}" | python3 -c "import sys,json; print(json.load(sys.stdin).get('expires_in','?'))")

echo "Token obtained (expires in ${EXPIRES_IN}s)" >&2
printf '%s' "${ACCESS_TOKEN}"
