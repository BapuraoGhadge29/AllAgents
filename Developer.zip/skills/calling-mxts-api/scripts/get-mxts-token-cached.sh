#!/usr/bin/env bash
# Return a valid MXTS Bearer token for the given concern, using a four-tier cache:
#   1. MXTS_ACCESS_TOKEN env var   (session cache — fastest, no disk I/O)
#   2. macOS Keychain              (OS-encrypted, survives reboots)
#   3. Windows DPAPI file          (DPAPI-encrypted, Git Bash / Cygwin only)
#   4. Restricted file             (chmod 600, cross-platform fallback)
#
# The concern (Keycloak realm identifier, e.g. "mxts" or "krm") is taken from
# the first positional argument and defaults to "mxts". Cache keys are namespaced
# per concern so tokens for different tenants never collide.
#
# A token is considered valid if its JWT exp claim is > 60 s in the future.
# On cache miss or expiry, a fresh token is obtained and all available cache
# layers are updated.
#
# The token is ONLY written to stdout. It is never logged or echoed elsewhere.

set -euo pipefail

CONCERN="${1:-mxt}"

# Cache keys are concern-scoped to prevent cross-tenant token reuse.
KEYCHAIN_SERVICE="mxts-dev-token-${CONCERN}"
KEYCHAIN_ACCOUNT="mxts"
CACHE_FILE="${HOME}/.cache/mxts/token-${CONCERN}"
# Windows DPAPI file lives in %LOCALAPPDATA%\mxts\token-<concern>.dpapi
DPAPI_FILE="${LOCALAPPDATA:-}/mxts/token-${CONCERN}.dpapi"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

_is_windows() { [[ "$OSTYPE" == msys || "$OSTYPE" == cygwin ]]; }

# Parse the exp claim from a JWT. Returns 0 on any parse error.
_jwt_exp() {
    python3 - "$1" <<'EOF'
import sys, base64, json
try:
    parts = sys.argv[1].strip().split('.')
    padded = parts[1] + '=' * (-len(parts[1]) % 4)
    print(json.loads(base64.urlsafe_b64decode(padded))['exp'])
except Exception:
    print(0)
EOF
}

_token_valid() {
    local tok="$1"
    [[ -z "$tok" ]] && return 1
    local exp now
    exp=$(_jwt_exp "$tok")
    now=$(date +%s)
    [[ "$exp" -gt $((now + 60)) ]]
}

# Retrieve a DPAPI-encrypted token written by _store_token on Windows.
_windows_dpapi_read() {
    [[ -f "${DPAPI_FILE}" ]] || return 1
    # Pass the file path as an env var to avoid quoting issues with Windows paths
    DPAPI_PATH="${DPAPI_FILE}" powershell.exe -NoProfile -NonInteractive -Command '
        try {
            $enc = Get-Content $env:DPAPI_PATH -Raw
            $sec = ConvertTo-SecureString $enc
            [Runtime.InteropServices.Marshal]::PtrToStringAuto(
                [Runtime.InteropServices.Marshal]::SecureStringToBSTR($sec)
            )
        } catch {}
    ' 2>/dev/null | tr -d '\r'
}

# Encrypt and persist a token using all available cache layers.
_store_token() {
    local tok="$1"

    # macOS Keychain
    if command -v security >/dev/null 2>&1; then
        security add-generic-password \
            -s "${KEYCHAIN_SERVICE}" -a "${KEYCHAIN_ACCOUNT}" \
            -w "${tok}" -U 2>/dev/null || true
    fi

    # Windows DPAPI file (Git Bash / Cygwin)
    # Token is passed via env var so it never appears in the process argument list.
    if _is_windows && command -v powershell.exe >/dev/null 2>&1; then
        MXTS_TOKEN_PLAIN="${tok}" DPAPI_PATH="${DPAPI_FILE}" \
        powershell.exe -NoProfile -NonInteractive -Command '
            $dir = Split-Path $env:DPAPI_PATH
            if (-not (Test-Path $dir)) { New-Item -ItemType Directory -Path $dir | Out-Null }
            $sec = ConvertTo-SecureString $env:MXTS_TOKEN_PLAIN -AsPlainText -Force
            ConvertFrom-SecureString $sec | Set-Content $env:DPAPI_PATH
        ' 2>/dev/null || true
    fi

    # Restricted file (Linux / macOS fallback / WSL2)
    if ! _is_windows; then
        mkdir -p "$(dirname "${CACHE_FILE}")"
        chmod 700 "$(dirname "${CACHE_FILE}")"
        printf '%s' "${tok}" > "${CACHE_FILE}"
        chmod 600 "${CACHE_FILE}"
    fi
}

# ── Tier 1: env var ──────────────────────────────────────────────────────────
# MXTS_ACCESS_TOKEN bypasses all cache tiers. Useful for one-off overrides but
# is concern-agnostic — ensure the token matches the requested concern.
if _token_valid "${MXTS_ACCESS_TOKEN:-}"; then
    printf '%s' "${MXTS_ACCESS_TOKEN}"
    exit 0
fi

# ── Tier 2: macOS Keychain ───────────────────────────────────────────────────
if command -v security >/dev/null 2>&1; then
    CACHED=$(security find-generic-password \
        -s "${KEYCHAIN_SERVICE}" -a "${KEYCHAIN_ACCOUNT}" \
        -w 2>/dev/null || true)
    if _token_valid "${CACHED:-}"; then
        printf '%s' "${CACHED}"
        exit 0
    fi
fi

# ── Tier 3: Windows DPAPI ────────────────────────────────────────────────────
if _is_windows; then
    CACHED=$(_windows_dpapi_read || true)
    if _token_valid "${CACHED:-}"; then
        printf '%s' "${CACHED}"
        exit 0
    fi
fi

# ── Tier 4: restricted file (Linux / WSL2) ───────────────────────────────────
if [[ -f "${CACHE_FILE}" ]]; then
    CACHED=$(cat "${CACHE_FILE}")
    if _token_valid "${CACHED:-}"; then
        printf '%s' "${CACHED}"
        exit 0
    fi
fi

# ── Cache miss: obtain a fresh token ─────────────────────────────────────────
echo "[mxts-token] No valid cached token for concern '${CONCERN}' — authenticating..." >&2
FRESH=$("${SCRIPT_DIR}/get-mxts-token.sh" "${CONCERN}")
_store_token "${FRESH}"
printf '%s' "${FRESH}"
