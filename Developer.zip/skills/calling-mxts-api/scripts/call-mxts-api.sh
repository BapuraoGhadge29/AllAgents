#!/usr/bin/env bash
# Make an authenticated call to the MXTS API at https://api-dev.maxxton.net
# through the `mxts` CLI. The Bearer token is attached by the CLI — it is never
# printed to stdout.
#
# Usage:
#   ./call-mxts-api.sh [--concern <code>] METHOD /path [extra curl args...]
#
# The concern identifies the Keycloak realm / tenant (default: mxt).
# Override with --concern or by setting $MXTS_CONCERN before calling this script.
# Authenticates with your `mxts auth login` session, or with $MXTS_TOKEN when set.
#
# Examples:
#   ./call-mxts-api.sh GET /accommodations
#   ./call-mxts-api.sh --concern krm GET /accommodations
#   ./call-mxts-api.sh POST /reservations --data '{"guestId":1}'
#   ./call-mxts-api.sh GET "/accommodations?page=0&size=10"
#   ./call-mxts-api.sh GET /accommodations --header 'Accept-Language: nl'

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

CONCERN="${MXTS_CONCERN:-mxt}"
PASSTHROUGH_ARGS=()
while [[ $# -gt 0 ]]; do
    case "$1" in
        --concern)
            CONCERN="${2:?--concern requires a value (e.g. --concern krm)}"
            shift 2
            ;;
        --concern=*)
            CONCERN="${1#--concern=}"
            : "${CONCERN:?--concern requires a value (e.g. --concern=krm)}"
            shift
            ;;
        *)
            PASSTHROUGH_ARGS+=("$1")
            shift
            ;;
    esac
done
set -- "${PASSTHROUGH_ARGS[@]}"

# `all` is not a real concern — it's an orchestration mode handled by the skill
# via call-mxts-api-all.sh. Reject it here so we never try to resolve realm "all".
if [[ "${CONCERN}" == "all" ]]; then
    echo "ERROR: 'all' is not a real concern. Use the fan-out script for all-concern queries:" >&2
    echo "       call-mxts-api-all.sh GET ${2:-/path}" >&2
    exit 2
fi

METHOD="${1:?Usage: call-mxts-api.sh [--concern <code>] METHOD /path [curl-options...]}"
API_PATH="${2:?Missing API path}"
shift 2

METHOD_UC="$(printf '%s' "${METHOD}" | tr '[:lower:]' '[:upper:]')"
READONLY=()
case "${METHOD_UC}" in
    GET|HEAD|OPTIONS) READONLY=(--readonly) ;;
esac

# --fail-with-body: exit non-zero on HTTP 4xx/5xx but still print the body
# --retry 3: auto-retry transient connection drops (e.g. curl exit 56); does NOT retry 4xx/5xx
exec bash "${SCRIPT_DIR}/mxts.sh" api --env=dev --concern="${CONCERN}" ${READONLY[@]+"${READONLY[@]}"} -- \
    -s --fail-with-body --retry 3 \
    -X "${METHOD_UC}" \
    -H "Content-Type: application/json" \
    "${API_PATH}" \
    "$@"
