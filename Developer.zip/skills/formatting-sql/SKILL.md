---
name: formatting-sql
description: Formats and lints SQL queries to Maxxton conventions using sqlfluff with an Oracle-friendly ansi dialect. Use when the user explicitly invokes "/formatting-sql" to format, reformat, clean up, or lint a SQL snippet — runs the full sqlfluff fix → lint pipeline before returning the result.
disable-model-invocation: true
allowed-tools:
- Bash
- Read
- Write
- Edit
---

# Formatting SQL — Maxxton Conventions

Always run the full tooling pipeline (sqlfluff fix → sqlfluff lint) on any SQL before
returning it. Never return SQL based on memory or manual formatting alone.

## Instructions

Execute the four steps below in order. Stop and rework the SQL manually only when sqlfluff
cannot fix a violation (see "What sqlfluff cannot auto-fix" further down).

### 1. Install sqlfluff if needed

Skip if `sqlfluff --version` already succeeds.

```bash
pip install sqlfluff --break-system-packages -q
```

### 2. Write the config to `/tmp/.sqlfluff`

This is the Maxxton-tuned config. Write it verbatim — every rule block matters.

```ini
[sqlfluff]
dialect = ansi
max_line_length = 120
indent_unit = space
tab_space_size = 2
exclude_rules = RF02

[sqlfluff:indentation]
indented_joins = false
indented_using_on = true
template_blocks_indent = false
tab_space_size = 2

[sqlfluff:rules:capitalisation.keywords]
capitalisation_policy = upper

[sqlfluff:rules:capitalisation.identifiers]
capitalisation_policy = lower
ignore_words = SYSDATE,CURRENT_DATE

[sqlfluff:rules:capitalisation.functions]
capitalisation_policy = upper

[sqlfluff:rules:capitalisation.literals]
capitalisation_policy = upper

[sqlfluff:rules:capitalisation.types]
capitalisation_policy = upper

[sqlfluff:rules:aliasing.expression]
aliasing = explicit

[sqlfluff:rules:aliasing.column]
aliasing = explicit

[sqlfluff:rules:aliasing.table]
aliasing = implicit

[sqlfluff:rules:convention.not_equal]
preferred_not_equal_style = ansi

[sqlfluff:rules:convention.terminator]
require_final_semicolon = true

[sqlfluff:rules:convention.left_join]
fully_qualify_join_types = both

[sqlfluff:rules:layout.commas]
comma_style = trailing

[sqlfluff:rules:ambiguous.union]
preferred_union_syntax = union_all

[sqlfluff:rules:convention.count_rows]
prefer_count_1 = true
```

> **Note:** `dialect = ansi` is used instead of `oracle` because sqlfluff 4.x has a
> parsing bug (ST12 loop) with the oracle dialect. All Oracle-specific syntax (SYSDATE,
> CURRENT_DATE, NVL, ROWNUM, etc.) passes through fine under ansi.
> RF02 is excluded because it false-positives on Oracle pseudo-columns like SYSDATE.

### 3. Write SQL to `/tmp/query.sql` and fix

Save the incoming SQL to `/tmp/query.sql`, then run the auto-fixer.

```bash
sqlfluff fix /tmp/query.sql --config /tmp/.sqlfluff
```

### 4. Lint and verify

If lint passes (exit 0) → return the SQL. If violations remain → fix manually and re-lint.

```bash
sqlfluff lint /tmp/query.sql --config /tmp/.sqlfluff
```

## Style rules reference

| Rule | Convention | Enforced by |
|------|-----------|-------------|
| SQL keywords | UPPERCASE | sqlfluff CP01 |
| Table & column names | lowercase_with_underscores | sqlfluff CP02 |
| Function names | UPPERCASE — `COUNT()`, `NVL()`, `TO_DATE()` | sqlfluff CP03 |
| Data types | UPPERCASE — `VARCHAR2`, `NUMBER`, `DATE` | sqlfluff CP05 |
| Null literal | UPPERCASE — `NULL` | sqlfluff CP04 |
| Boolean literals | UPPERCASE — `TRUE`, `FALSE` | sqlfluff CP04 |
| Oracle pseudo-columns | UPPERCASE — `SYSDATE`, `CURRENT_DATE` | CP02 ignore_words |
| Indent | 2 spaces inside SELECT and CTE body | sqlfluff LT02 |
| Max line length | 120 chars | sqlfluff LT05 |
| Table aliases | implicit — `FROM employee c`, not `FROM employee AS c` | sqlfluff AL01 |
| Column aliases | explicit — always use AS | sqlfluff AL02 |
| Alias format | lowercase_with_underscores, no quotes | manual + RF05 |
| One space before AS | `c.firstname AS first_name` — no padding alignment | manual |
| Trailing commas | comma at end of line, not start of next | sqlfluff LT04 |
| WHERE layout | first condition same line as WHERE; each AND/OR on new unindented line | manual |
| NULL comparison | use IS / IS NOT NULL — never `= NULL` | sqlfluff CV05 |
| Not-equal operator | `<>` only — never `!=` | sqlfluff CV01 |
| Join style | LEFT JOIN or JOIN only — no RIGHT JOIN, no implicit joins | sqlfluff CV08 |
| UNION | always explicit UNION ALL or UNION DISTINCT — never bare UNION | sqlfluff AM02 |
| Semicolon | every statement ends with `;` | sqlfluff CV06 |
| COUNT | use `COUNT(1)` — never `COUNT(*)` | sqlfluff CV04 |
| Derived table alias | always add a meaningful alias to subqueries in FROM | manual + AL10 |
| CTE subqueries | prefer CTEs over inline subqueries in FROM/JOIN where practical | sqlfluff ST05 |
| Positional ORDER BY | use column references, not numbers | sqlfluff AM06 |

## What sqlfluff cannot auto-fix (handle manually before running fix)

- **Quoted aliases** — `"First Name"` → `first_name` (remove quotes, replace spaces with underscores)
- **Right joins** — rewrite query so the driving table is on the left
- **Implicit joins** — `FROM a, b WHERE a.id = b.id` → explicit `JOIN ... ON ...`
- **Positional ORDER BY** — `ORDER BY 1, 2` → `ORDER BY c.lastname, c.firstname`
- **Derived table alias** — add a meaningful alias to any subquery in FROM: `(...) employee_base`
- **WHERE layout** — sqlfluff indents conditions under WHERE; manually rewrite to keep
  the first condition on the same line as WHERE, each AND/OR on a new unindented line:
  ```sql
  WHERE c.client_type = 'employee'
  AND c.off_duty IS NOT NULL
  AND c.last_login_time > SYSDATE - 30
  ```

## Examples

User says: `format this SQL: select c.firstname, c.lastname from employee c where c.client_type = 'employee';` — write to `/tmp/query.sql`, run `sqlfluff fix` then `sqlfluff lint` with `/tmp/.sqlfluff`, and return the result in the shape shown under "Simple query" below.

### Simple query

Demonstrates the canonical shape: uppercase keywords, lowercase identifiers, 2-space
indent on SELECT columns, AS for column aliases, no AS for table aliases, WHERE-AND
layout at base indent.

```sql
SELECT
  c.firstname AS first_name,
  c.middlename AS middle_name,
  c.lastname AS last_name,
  c.emp_email_id AS email_address,
  c.login AS login_username,
  cg.name AS employee_group,
  c.last_login_time AS last_login_on,
  c.off_duty AS on_duty_till
FROM employee c
LEFT JOIN employeegroup cg ON c.group_id = cg.employeegroup_id
WHERE c.client_type = 'employee'
AND c.off_duty IS NOT NULL
AND c.last_login_time > SYSDATE - 30;
```

### Subquery wrapper

Shows a derived table with a meaningful alias and `COUNT(1)` (never `COUNT(*)`).

```sql
SELECT COUNT(1) FROM (
  SELECT
    c.firstname AS first_name,
    c.lastname AS last_name,
    c.emp_email_id AS email_address
  FROM employee c
  LEFT JOIN employeegroup cg ON c.group_id = cg.employeegroup_id
  WHERE c.client_type = 'employee'
  AND c.off_duty IS NOT NULL
  AND c.last_login_time > SYSDATE - 30
) active_employees;
```

## Troubleshooting

### sqlfluff parser enters an ST12 loop / hangs on Oracle syntax

Cause: sqlfluff 4.x has a known parsing bug on the `oracle` dialect.
Fix: keep `dialect = ansi` in the config (already set above). Oracle keywords like
SYSDATE, CURRENT_DATE, NVL, ROWNUM pass through under ansi.

### Lint flags `SYSDATE` or `CURRENT_DATE` as wrong case

Cause: CP02 lowercases identifiers and treats Oracle pseudo-columns as identifiers.
Fix: ensure `ignore_words = SYSDATE,CURRENT_DATE` is present under
`[sqlfluff:rules:capitalisation.identifiers]`.

### Lint complains about pseudo-columns (RF02)

Cause: RF02 cannot tell that `SYSDATE` is not a missing-reference identifier.
Fix: keep `exclude_rules = RF02` in `[sqlfluff]`.

### `sqlfluff fix` exits 0 but the layout is still wrong

Cause: some violations are not auto-fixable (quoted aliases, right joins, implicit
joins, positional ORDER BY, WHERE layout).
Fix: rewrite manually using the "What sqlfluff cannot auto-fix" section, then re-run
fix and lint.
