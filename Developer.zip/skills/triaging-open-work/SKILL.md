---
name: triaging-open-work
description: Pulls GitHub and Jira activity since the last working day, then buckets open PRs by who's blocking each (🔴 action-on-you, 🟡 first-review, 🟠 re-review, 🟢 ready). Use when the developer asks for a status update, what's open, or where they left off.
disable-model-invocation: true
allowed-tools:
- Bash
- mcp__claude_ai_Atlassian_MCP__getAccessibleAtlassianResources
- mcp__claude_ai_Atlassian_MCP__searchJiraIssuesUsingJql
---

# Triaging Open Work

Pull recent activity from **GitHub** and **Jira**, scoped to **changes since the last working day**, then show open work bucketed by who's blocking each PR. Goal: the developer sees both "what moved" and "what's stuck where" at a glance, with action ownership clear without clicking into PRs.

## Instructions

### Step 1: Determine the date window

- "Last working day" = previous business day. Today is a Monday → look back to Friday. Today is Saturday/Sunday → look back to last Friday. Otherwise → yesterday.
- Anchor on today's date. Format as `YYYY-MM-DD` for `gh search` and `>= "YYYY-MM-DD"` for JQL.

### Step 2: Gather data — run all in parallel

`gh` uses `@me` to mean the authenticated user. For Jira, use JQL's `currentUser()`. The Jira cloudId is needed for every `mcp__claude_ai_Atlassian_MCP__searchJiraIssuesUsingJql` call — if you don't know it, call `mcp__claude_ai_Atlassian_MCP__getAccessibleAtlassianResources` once (cheap, returns one entry per accessible site) and use its `id` for the rest of the run.

Run all of these in a single message (parallel tool calls):

**A. Recent activity since last working day**
```bash
# PRs the developer authored that moved
gh search prs --author @me --state open --updated ">=[YYYY-MM-DD]" \
  --json number,title,isDraft,url,repository,updatedAt --limit 50

# PRs the developer authored that closed/merged
gh search prs --author @me --state closed --updated ">=[YYYY-MM-DD]" \
  --json number,title,url,repository,updatedAt,state --limit 50
```

**B. Open work — author side**
```bash
gh search prs --author @me --state open \
  --json number,title,isDraft,url,repository,updatedAt --limit 50
```

**C. Open work — reviewer side**
```bash
gh search prs --review-requested @me --state open \
  --json number,title,url,repository,author,updatedAt,isDraft --limit 50
```

**D. Jira (always run both: open and recently-touched)**
- JQL `assignee = currentUser() AND statusCategory != Done ORDER BY updated DESC` — all open assigned issues.
- JQL `assignee = currentUser() AND updated >= "[YYYY-MM-DD]" ORDER BY updated DESC` — recently-touched.
- Use `mcp__claude_ai_Atlassian_MCP__searchJiraIssuesUsingJql` with the cloudId discovered above, fields `["summary","status","issuetype","priority","updated","created"]`.

Note `gh search prs` doesn't support `reviewDecision` in `--json`. Don't pass it; fetch per-PR in step 3.

### Step 3: Bucket each open PR

`reviewDecision` alone is misleading — both `CHANGES_REQUESTED` and `APPROVED` are sticky until the reviewer acts again. NEVER bucket from `reviewDecision` alone.

**CRITICAL: Use `reviews`, NOT `latestReviews`.** `latestReviews` is unreliable — it can return only one author (e.g. just Copilot) even when multiple humans have reviewed. The full `reviews` array always contains every review event. If you only check `latestReviews`, you will silently miss human review activity and misbucket PRs as 🟡 first-review when they actually belong in 🟠 re-review. **Don't even fetch `latestReviews`.**

For every open PR from step 2B, run a compact summary that surfaces what matters in one screen. Each open PR's `repository.nameWithOwner` from step 2B is already in the form `owner/repo` — use it directly. Substitute the `set --` line with `"owner/repo:num"` entries (one per open PR from step 2B):

```bash
set -- "owner/repo:123" "owner/other-repo:456"   # one "owner/repo:num" entry per PR
for pr in "$@"; do
  repo="${pr%:*}"; num="${pr#*:}"
  echo "=== $repo#$num ==="
  data=$(gh pr view "$num" --repo "$repo" \
    --json reviewDecision,reviewRequests,mergeStateStatus,reviews,commits,statusCheckRollup)
  echo "--- decision ---"
  echo "$data" | jq '{reviewDecision, reviewRequests, mergeStateStatus}'
  echo "--- reviews ---"
  echo "$data" | jq '.reviews | map({author: .author.login, state: .state, submittedAt: .submittedAt})'
  echo "--- last commit ---"
  echo "$data" | jq '.commits | last | {date: .committedDate, msg: .messageHeadline}'
  echo "--- checks ---"
  echo "$data" | jq '[.statusCheckRollup[] | select(.conclusion != null) | .conclusion] | group_by(.) | map({state: .[0], n: length})'
done
```

The positional-arg form is the only shell pattern that reliably word-splits in this harness (a `for pr in $list` over a space-separated string has been observed to collapse into a single token). Run the whole loop in one Bash invocation — don't fan out one Bash tool call per PR.

Use these signals, in priority order:

**Signal C (primary, cheapest, strongest) — re-requested reviewers.** If `reviewDecision == CHANGES_REQUESTED` AND any reviewer who left a `CHANGES_REQUESTED` review (check `reviews[].state`) is present in `reviewRequests[].login` → the author re-requested review after addressing the comments → **🟠 re-review**, NOT 🔴.

**Signal A — commit time vs last human review time.** If the latest commit on the PR is after the last human (non-`copilot-pull-request-reviewer`) review/comment, the author has likely pushed fixes → re-review. **This applies even to APPROVED reviews:** an approval followed by a new commit means the approver still needs to re-confirm — that's 🟠, not 🟢.

**Signal B — unresolved review threads.** Check via GraphQL when A and C are inconclusive:
```bash
gh api graphql -f query='{ repository(owner:"<owner>", name:"<repo>") { pullRequest(number:<num>) { reviewThreads(first:100) { nodes { isResolved comments(first:1) { nodes { author { login } } } } } } } }'
```
Filter for `isResolved: false` AND author is human. Unresolved human threads → 🔴. All resolved → 🟠.

**Sanity check before writing the report:** for any PR you're about to put in 🟡 first-review, scan `reviews[]` for *any* non-Copilot author. If one exists, it is NOT 🟡 — re-bucket as 🟠 (or 🔴/🟢 per the other signals). 🟡 means truly zero human reviewer activity, ever.

### Buckets

- **🔴 Action on you** — `CHANGES_REQUESTED` AND reviewer NOT in `reviewRequests` AND no commits after the review. Unresolved human threads are *supporting* evidence; their absence does not disqualify (a reviewer may have left only a summary-level CR with no inline threads).
- **🟡 First review** — only Copilot/bot has reviewed; no human reviewer activity yet. Suggest pinging.
- **🟠 Re-review** — reviewer is back in `reviewRequests` after a CHANGES_REQUESTED, OR all human threads resolved, OR commits pushed after the last human review. Ball is in the reviewer's court.
- **🟢 Ready** — `APPROVED` + CI green + no further author activity since approval. Flag if blocked on a paired/sibling PR (e.g. core PR + client PR pair).

When in doubt between 🔴 and 🟠, default to 🟠.

### Step 4: Format the report

Markdown with clickable links. Section order:

```
### Since last working day (<weekday> <YYYY-MM-DD>)
- ✅ Merged [...]
- 🔄 Pushed updates to [...]
- 📋 Jira [KEY](link) — <one-liner>

### Open work — bucketed

#### 🔴 Action on you
- [repo#NN](url) — title — <reviewer> requested changes <date>

#### 🟡 First review (waiting)
- [repo#NN](url) — title

#### 🟠 Re-review
- [repo#NN](url) — title — re-requested <reviewer> <date>

#### 🟢 Ready to merge
- [repo#NN](url) — title

### Awaiting your review
- [repo#NN](url) by @author — title

**TL;DR:** <one sentence, e.g. "1 needs your reply, 2 in re-review, 4 waiting on a first reviewer.">
```

Empty buckets: write `*(none)*`. Skip the buckets entirely only if every bucket is empty (very rare).

## Constraints

- Don't read working directories or run `git log`. This is an external-systems snapshot only.
- Don't post comments, transition Jira, or take any external action. Read-only.
- Don't propose follow-up actions unless the developer asks — they'll decide what to act on.

## Examples

**User says: `give me a status update`** — runs the four GitHub searches and two Jira JQL queries in parallel, then the per-PR loop for each open authored PR, then outputs the bucketed report.

**User says: `where am I?` on a Monday** — date window resolves to the previous Friday. Recent-activity sections show what moved between Friday and now. Buckets show all currently-open work regardless of when it last moved.

**Developer asks `what's open?` and they have an approved PR with a new commit on top** — the PR ends up in 🟠 Re-review (not 🟢), because Signal A overrides the sticky `APPROVED` state.

**Developer has zero open PRs and zero assigned Jira tickets** — every bucket renders with `*(none)*` rather than being omitted. TL;DR notes the empty state.

## Troubleshooting

### `gh: command not found`

Install the GitHub CLI from <https://cli.github.com/> and authenticate with `gh auth login`.

### `gh search prs` returns nothing

Verify `gh auth status` shows you're logged in. The `@me` shorthand resolves to the authenticated user — if the wrong account is active, all searches will look empty.

### `mcp__claude_ai_Atlassian_MCP__searchJiraIssuesUsingJql` fails with "cloudId not found"

The cloudId for the Atlassian site wasn't resolved. Call `mcp__claude_ai_Atlassian_MCP__getAccessibleAtlassianResources` first and use the `id` field of the matching site.

### A PR ends up in the wrong bucket

The most common cause is relying on `latestReviews` instead of `reviews` — the former drops human reviewers when bots have also reviewed. Re-fetch with the `reviews` field (full array) and re-bucket per Signals A/B/C.

### The per-PR loop produces empty output

If the loop collapses all PRs into one entry (only the first PR is processed), the shell word-split the list as a single token. Use the `set -- "owner/repo:num" "owner/repo:num"` positional-arg form shown in Step 3 — `for pr in $list` is unreliable in this harness.
