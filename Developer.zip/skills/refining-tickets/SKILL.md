---
name: refining-tickets
description: Refine a Jira ticket with a functional design into a technical design with independently deployable sub-tickets — performs impact analysis using the Maxxton Knowledge graph, identifies affected services, and creates linked sub-tickets in Jira. Use '/refining-tickets' when refining a Jira ticket into technical sub-tickets.
disable-model-invocation: true
argument-hint: "[Jira ticket key, e.g. PROJ-1234]"
allowed-tools:
- mcp__claude_ai_Atlassian_MCP__getAccessibleAtlassianResources
- mcp__claude_ai_Atlassian_MCP__getJiraIssue
- mcp__claude_ai_Atlassian_MCP__discover
- mcp__claude_ai_Atlassian_MCP__executeRead
- mcp__claude_ai_Atlassian_MCP__searchJiraIssuesUsingJql
- mcp__claude_ai_Atlassian_MCP__createJiraIssue
- mcp__claude_ai_Atlassian_MCP__executeWrite
- mcp__claude_ai_Atlassian_MCP__addOrEditJiraIssueComment
- mcp__claude_ai_Atlassian_MCP__getConfluenceContent
- mcp__claude_ai_Maxxton_Knowledge__list_repo_info_documents
- mcp__claude_ai_Maxxton_Knowledge__list_openapi_documents
- mcp__claude_ai_Maxxton_Knowledge__search_repo_info
- mcp__claude_ai_Maxxton_Knowledge__get_repo_info_document
- mcp__claude_ai_Maxxton_Knowledge__get_service_overview
- mcp__claude_ai_Maxxton_Knowledge__get_entity_usage
- mcp__claude_ai_Maxxton_Knowledge__query_openapi
- mcp__claude_ai_Maxxton_Knowledge__get_openapi_document
- mcp__claude_ai_Maxxton_Knowledge__search_technical_graph
- mcp__claude_ai_Maxxton_Knowledge__get_call_chain
- mcp__claude_ai_Maxxton_Knowledge__find_path_between_nodes
- mcp__claude_ai_Maxxton_Knowledge__search_repo_docs
- mcp__claude_ai_GitHub__search_code
- mcp__claude_ai_GitHub__get_file_contents
- mcp__claude_ai_Context7__resolve-library-id
- mcp__claude_ai_Context7__query-docs
- WebSearch
- TodoWrite
- AskUserQuestion
- Read
---

# Ticket Refinement: Functional Design → Technical Design

Transform a Jira ticket containing a functional design into a complete
technical design, broken down into independently deployable sub-tickets
following the OpenSpec standard. Automates codebase research, impact
analysis, and ticket creation.

## Required Connectors

- **Maxxton Knowledge** — codebase architecture research (repo info,
  technical graph, OpenAPI specs, entity usage, call chains)
- **Atlassian** — Jira ticket management and Confluence access
- **GitHub MCP** (`github`) — bundled; code-level analysis, event schemas,
  team-service mapping. See `references/mcp-usage-patterns.md` for patterns.
  Do not fall back to browser tools — flag gaps and ask the user.
- **Context7** (optional) — external library/framework documentation. Fall
  back to `WebSearch` if unavailable, then built-in knowledge with flag:
  "Based on training data — verify against current docs."

## Core Principles

Four non-negotiable rules govern every technical design:

1. **Independent deployability.** Every sub-ticket must be implementable,
   buildable, testable, and deployable on its own. API changes must be
   backward-compatible, database migrations additive, and new consumers must
   handle the absence of new fields/events gracefully. If a change cannot be
   made independently deployable, include a migration strategy (feature
   flags, API versioning, or expand-contract — see
   `references/maxxton-references.md`).

2. **Breaking change detection.** Before proposing any change, trace its
   impact across the entire service landscape. If changing a field in
   service A would break service B, surface it — consult the user before
   proceeding. Provide workarounds or a migration plan for every breaking
   change.

3. **Think big on data and scale.** Maxxton serves hospitality businesses
   with high-volume reservation data and seasonal peak loads. Every design
   decision must consider millions of records and 10x growth. Never design
   for today's data volume.

4. **Framework-first design.** Before proposing custom implementations,
   verify whether the framework already provides a built-in mechanism. Prefer
   configuration over code, library-native solutions over bespoke ones.
   Prefer reusing existing shared infrastructure over introducing new
   dependencies.

## Workflow Overview

The workflow is iterative — findings from later stages may require revisiting
earlier stages. At the start of each session, create a TodoWrite list with
the stages to execute. Whenever multiple tool calls are independent, make
them in the same turn (marked with ⚡ in the detailed procedures).

**Use `Read` to load the relevant reference file when entering each phase:**
- **`references/workflow-context.md`** — Stages 0–2.5 (classify, gather, validate, diagnose)
- **`references/workflow-research.md`** — Stages 3–4 (codebase research, impact analysis)
- **`references/workflow-delivery.md`** — Stages 5–9 (design, teams, split, validate, create)

### Stage 0: Classify the Ticket

Classify into one of three paths after reading the ticket:
- **Path A — Full refinement**: multi-service feature, run all stages
- **Path B — Lightweight plan**: single-repo bug/debt, run only stages 0–2.5
  (use `references/workflow-context.md` only), then post fix plan as comment;
  reclassify to Path A or C if investigation reveals new infrastructure,
  deploy-config, or cluster-config changes, or if additional tickets are
  needed
- **Path C — Scoped refinement**: single-service feature, lighter research

Confirm classification with the user via `AskUserQuestion` before proceeding.

### Stage 1: Gather Context

- **1a.** ⚡ Read the Jira ticket, discover project issue types and required
  fields (especially custom fields for sub-ticket creation)
- **1b.** Search for related tickets, detect duplicates, flag in-flight
  conflicts
- **1c.** *(Path A/C only; skip for Path B)* Load the Maxxton glossary from
  Confluence (see `references/maxxton-references.md`)
- **1d.** *(Path A/C only; skip for Path B)* ⚡ Discover the full service
  landscape via `list_repo_info_documents` and `list_openapi_documents`

### Stage 2: Validate the Functional Design

- **2a.** Completeness check (edge cases, error scenarios, scope clarity)
- **2b.** Ambiguity detection (vague language, undefined terms, glossary
  conflicts)
- **2c.** Present findings to user via `AskUserQuestion` with multiple-choice
  options before proceeding

### Stage 2.5: Root Cause & Framework Analysis

*Apply for bug/error/improvement tickets (Path B/C). Skip for greenfield
features.*

- **2.5a.** Diagnose root cause — work backwards from symptoms, research
  framework defaults via Context7
- **2.5b.** Research framework-native solutions before proposing custom code
- **2.5c.** Enumerate existing shared infrastructure before proposing new
  dependencies
- **2.5d.** Infrastructure provisioning chain analysis — trace cluster-config
  and deploy-config wiring, surface provisioning sub-tickets

### Stage 3: Research the Codebase

- **3a.** ⚡ Identify affected repositories, fetch repo info and service
  overviews in parallel
- **3b.** Map existing data models — entity usage, API contracts, ownership
- **3c.** Trace integration flows — call chains inbound and outbound
- **3d.** Check API contracts in detail — OpenAPI specs and ADRs
- **3e.** Detect shared libraries and common modules — flag wide blast radius
- **3f.** Analyze event schemas — all publishers and consumers, treat like
  API changes
- **3g.** Check non-functional requirements (performance, security, GDPR)
- **3h.** Look up external library documentation via Context7 (mandatory
  before Stage 5)

### Stage 4: Impact Analysis

- **4a.** Breaking change detection — trace consumers, classify impact as
  non-breaking/potentially breaking/breaking. **STOP and consult the user**
  for any breaking changes with three options (workaround, expand-contract,
  coordinated deployment)
- **4b.** Security review (auth, input validation, data exposure,
  multi-tenancy, GDPR)
- **4c.** Scalability assessment (query performance, event throughput, data
  growth)

### Stage 5: Technical Design

- **5a.** Explore at least two alternative approaches with pros/cons
- **5b.** Write the structured technical design (template in
  `references/workflow-delivery.md`)

### Stage 6: Determine Team Ownership

Fetch team-service mapping from GitHub
(see `references/maxxton-references.md`). Flag cross-team coordination needs.

### Stage 7: Split into Sub-Tickets

Split per repository (primary) and by feature slice (secondary). Each
sub-ticket must be self-contained and independently deployable. Use the
template in `references/sub-ticket-template.md`. Estimate as S/M/L — split
further if exceeding L.

- **Slice vertically within a repo.** Each sub-ticket delivers one complete,
  testable behaviour through every layer it needs (API, logic, persistence,
  tests). Never one ticket per layer — a "DTOs only" or "tests only" ticket
  cannot be verified on its own.
- **Prefactor first.** A refactor that makes the change easy is its own
  sub-ticket, and the feature tickets list it under **Depends on**.
- **Wide refactors use expand–contract.** A mechanical change with a large
  blast radius (rename a column, retype a shared field) cannot land in one
  green slice: expand (add the new form beside the old), migrate callers in
  batches (one ticket each, depending on the expand), contract (remove the
  old form, depending on every batch).
- **Fill Depends on / Blocks for every sub-ticket.** A ticket with no
  dependencies can start immediately.

### Stage 8: Validate and Review

- **8a.** Traceability check — every FR maps to sub-tickets and vice versa
- **8b.** Independent deployability check for each sub-ticket
- **8c.** Present complete plan for user review before creating tickets

### Stage 9: Create in Jira

⚡ Create all sub-tickets in parallel, then link them. Labels:
`gh-<repository>` and `Refined`. Run post-creation checklist (labels,
parent, team, links) before presenting results.

## Important Considerations

### Limited Knowledge Connector Data

If a search returns sparse results for a service, say so explicitly rather
than guessing. Flag it: "Limited data available for [service] — validate
with a developer familiar with this service."

### Iterative Nature

Common reasons to loop back: user answers change scope (redo Stage 3),
impact analysis reveals design issues (redo Stage 5), user feedback requires
changes (adjust and re-validate).

## Reference Files

- **`references/workflow-context.md`** — Stages 0–2.5: classify, gather
  context, validate design, root cause analysis
- **`references/workflow-research.md`** — Stages 3–4: codebase research,
  impact analysis
- **`references/workflow-delivery.md`** — Stages 5–9: technical design, team
  ownership, sub-ticket splitting, validation, Jira creation
- **`references/maxxton-references.md`** — Glossary location, team-service
  mapping, expand-contract pattern
- **`references/mcp-usage-patterns.md`** — GitHub MCP and Context7 usage
  patterns
- **`references/sub-ticket-template.md`** — OpenSpec-style sub-ticket template


## Available MCP Tools

The following MCP tools are used throughout this workflow:

**Atlassian Jira:** `mcp__claude_ai_Atlassian_MCP__getAccessibleAtlassianResources`, `mcp__claude_ai_Atlassian_MCP__getJiraIssue`, `mcp__claude_ai_Atlassian_MCP__discover`, `mcp__claude_ai_Atlassian_MCP__executeRead` (operations `listJiraProjectIssueTypesMetadata`, `getJiraIssueTypeMetaWithFields`), `mcp__claude_ai_Atlassian_MCP__searchJiraIssuesUsingJql`, `mcp__claude_ai_Atlassian_MCP__createJiraIssue`, `mcp__claude_ai_Atlassian_MCP__executeWrite` (operation `createJiraIssueLink`), `mcp__claude_ai_Atlassian_MCP__addOrEditJiraIssueComment`, `mcp__claude_ai_Atlassian_MCP__getConfluenceContent` (`detail: full` for the body)

**Maxxton Knowledge:** `mcp__claude_ai_Maxxton_Knowledge__list_repo_info_documents`, `mcp__claude_ai_Maxxton_Knowledge__list_openapi_documents`, `mcp__claude_ai_Maxxton_Knowledge__search_repo_info`, `mcp__claude_ai_Maxxton_Knowledge__get_repo_info_document`, `mcp__claude_ai_Maxxton_Knowledge__get_service_overview`, `mcp__claude_ai_Maxxton_Knowledge__get_entity_usage`, `mcp__claude_ai_Maxxton_Knowledge__query_openapi`, `mcp__claude_ai_Maxxton_Knowledge__get_openapi_document`, `mcp__claude_ai_Maxxton_Knowledge__search_technical_graph`, `mcp__claude_ai_Maxxton_Knowledge__get_call_chain`, `mcp__claude_ai_Maxxton_Knowledge__find_path_between_nodes`, `mcp__claude_ai_Maxxton_Knowledge__search_repo_docs`

**GitHub:** `mcp__claude_ai_GitHub__search_code`, `mcp__claude_ai_GitHub__get_file_contents`

**Context7:** `mcp__claude_ai_Context7__resolve-library-id`, `mcp__claude_ai_Context7__query-docs`

## Instructions

Invoke with "/refining-tickets" in Claude Code. The skill guides you through the workflow step by step.

## Examples

User says: "/refining-tickets"
Claude reads the Jira ticket, fills in missing acceptance criteria, splits large stories, and flags ambiguous requirements.

## Troubleshooting

- **Ticket not found**: verify the Jira ticket key and that you have read access to the project.
- **Acceptance criteria unclear**: share the feature context in the conversation for better output.
