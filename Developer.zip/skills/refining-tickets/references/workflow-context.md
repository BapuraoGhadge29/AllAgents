# Workflow: Context & Validation (Stages 0–2.5)

Detailed procedures for classifying the ticket, gathering context, validating
the functional design, and diagnosing root causes for bug/improvement tickets.

---

## Stage 0: Classify the Ticket

Not every ticket needs the full 9-stage treatment. After reading the Jira
ticket in Stage 1a, classify it into one of three paths:

- **Path A — Full refinement** (multi-service feature, functional design
  present). The ticket describes new functionality spanning multiple services
  or requiring significant architectural decisions. Run all stages.

- **Path B — Lightweight technical plan** (single-repo bug fix, small tech
  debt). The ticket describes a bug, error, or small improvement confined to
  one service. Skip stages 1c (glossary), 1d (service landscape), 4a–4c
  (full impact analysis), 6 (team ownership), and 7 (sub-ticket splitting).
  Instead: read ticket → research the one affected service → write a fix plan
  → post it as a comment on the ticket. Usually no sub-tickets are needed.
  If the fix requires new infrastructure, deploy-config changes,
  cluster-config changes, or otherwise requires additional tickets,
  reclassify to Path A or Path C before proceeding.

- **Path C — Scoped refinement** (single-service feature, narrow scope). The
  ticket is a feature but affects only one or two services. Run all stages
  but with lighter-weight research — skip the full service landscape discovery
  and focus research on the known affected services.

Present the classification to the user for confirmation before proceeding.
Use `AskUserQuestion` with the three paths as options. If the user disagrees
with your classification, adjust accordingly.

---

## Stage 1: Gather Context

Before touching the technical design, build a comprehensive picture of the
feature and its context.

### 1a. Read the Jira ticket and discover project configuration

⚡ **Parallelize these calls in a single turn:**

1. Use `getJiraIssue` to fetch the ticket by key. Extract the description
   (the functional design), check for linked issues, attachments, and child
   tickets that already exist. Note the ticket's project, issue type, status,
   and any custom field values (especially the team field).
2. Use `mcp__claude_ai_Atlassian_MCP__executeRead` with `name: listJiraProjectIssueTypesMetadata` to discover available issue types
   in the project (Sub-task, Story, Task, etc.).
3. Use `getJiraIssueTypeMetaWithFields` for the Sub-task issue type to
   discover required and available fields. Pay special attention to required
   custom fields (e.g., `customfield_10049` for Maxxton Team). Cache these —
   they will be needed when creating sub-tickets in Stage 9.

This early discovery prevents creation failures later. If a required field
has a fixed set of allowed values, note them now so the right value can be
selected when creating tickets.

### 1b. Search for related tickets and detect duplicates

Use `searchJiraIssuesUsingJql` to find context the ticket itself doesn't
contain:

- **Similar past implementations** — search for tickets in the same project
  with similar keywords that are already Done. How were similar features built
  before? What patterns were used?
- **Related bugs or tech debt** — are there known issues in the affected area
  that should be addressed alongside this work?
- **In-flight work** — search for tickets currently In Progress or In Review
  that touch the same services or domain. If another developer is modifying
  the same service or entity right now, flag this as a potential conflict.

**Duplicate detection.** If existing tickets cover the same or overlapping
scope, present them to the user immediately using `AskUserQuestion` with
options like:
- "These are duplicates — consolidate under the current ticket"
- "The current ticket is a subset of this broader initiative"
- "These are separate work that happens to overlap"

Resolving this early prevents creating redundant work.

### 1c. Load the domain glossary

Fetch the Maxxton glossary from Confluence (see `references/maxxton-references.md`
for page ID and space details) using `getConfluenceContent` with
`content_format: "markdown"` and `detail: "full"`. Use this glossary throughout the entire process
to ensure terminology is consistent. If the functional design uses a term
that doesn't match the glossary (e.g., "booking" instead of "reservation"),
note this as an ambiguity to resolve.

### 1d. Discover the service landscape

⚡ **Parallelize these calls:**

Use `list_repo_info_documents` and `list_openapi_documents` to enumerate all
known services. This gives the complete landscape — so no service is missed
that semantic search might not return.

---

## Stage 2: Validate the Functional Design

Before investing effort in a technical design, check whether the functional
design is actually ready for refinement.

### 2a. Completeness check

Review the functional design against these criteria:
- Are all user-facing requirements clearly stated?
- Are edge cases covered? (What if the input is null? What if the user does
  step 3 before step 2? What if the entity already exists?)
- Are error scenarios described? (What should happen when things go wrong?)
- Is the scope clear? (Is this one feature or several features bundled?)
- Are acceptance criteria defined or derivable from the description?

### 2b. Ambiguity detection

Scan for language that introduces ambiguity:
- Vague quantifiers: "some", "various", "many", "etc."
- Unclear references: "the system should handle this", "it should work
  as expected", "similar to before"
- Passive voice hiding responsibility: "the data will be updated" (by whom?
  which service?)
- Undefined terms or terms that conflict with the Maxxton glossary
- Implicit assumptions that aren't stated explicitly

### 2c. Present findings to the user

If completeness gaps or ambiguities are found, present them **before
proceeding** using `AskUserQuestion`. Structure ambiguities as
multiple-choice questions with concrete options where possible — this is
faster for the user and reduces misunderstandings.

Group related ambiguities together (max 4 questions per `AskUserQuestion`
invocation). Provide a recommended option where there is enough context.

---

## Stage 2.5: Root Cause & Framework Analysis

**Apply this stage for bug, error, and improvement tickets** (Path B and
Path C where the problem originates in library or framework behavior). For
greenfield features with no existing misbehavior, skip to Stage 3.

The goal is to diagnose the problem at the right level before touching code.
Many bugs are framework configuration issues in disguise.

### 2.5a. Diagnose the root cause

Do not accept the ticket's description as the root cause — it typically
describes the symptom. Work backwards:

- What is the observed behavior, and what is the expected behavior?
- At which layer does the divergence occur: business logic, framework
  behavior, library version, configuration, infrastructure, or external
  dependency?
- Is the problem deterministic or intermittent? Intermittent problems often
  point to concurrency, caching, or resource exhaustion — not application
  code.
- **Research the framework's default behaviors** in the affected area. Many
  bugs are the framework behaving exactly as designed, but with defaults
  that don't suit the deployment context. Use Context7 to look up the
  framework's defaults before concluding that custom code is needed.
- Use `search_repo_docs` and `search_technical_graph` to check whether this
  problem area has been touched before (ADRs, known issues, prior fixes).

State the root cause hypothesis explicitly before researching solutions.

### 2.5b. Research framework-native solutions

Once there is a root cause hypothesis, research what the framework or library
already provides:

- Use Context7 (`resolve-library-id` + `query-docs`) to fetch current
  documentation. Look specifically for: built-in mechanisms, configuration
  properties, pluggable interfaces, and known gotchas.
- Use `WebSearch` to search GitHub Issues on the relevant repository.
  Construct targeted queries like
  `site:github.com/<org>/<repo>/issues <error message or behavior keyword>`.
  Look for: confirmed bugs with referenced issue numbers, workarounds posted
  by maintainers, fixed versions, recommended configuration changes.
- Check whether the affected service is using an outdated version of the
  library that has a known fix in a newer release.

**Decision rule**: If a framework-native solution exists (configuration
change, version upgrade, enabling a built-in feature), propose that first.
Only proceed to designing custom code if framework-native options are
exhausted or genuinely insufficient. Document why a custom solution was
necessary.

### 2.5c. Enumerate infrastructure-native solutions

Before proposing new infrastructure, check what already exists:

- Use `search_repo_info` with queries like "cache", "redis", "kafka",
  "secret", "database", "broker" to enumerate shared infrastructure.
- Cross-reference with `get_repo_info_document` for the affected service to
  see which infrastructure it already connects to.
- If the solution requires caching, message brokering, secret management,
  or persistent storage — first verify whether an existing shared instance
  can be reused before proposing a new one.

### 2.5d. Infrastructure provisioning chain analysis

**Apply this step when the design introduces a new infrastructure dependency
for a service that does not currently use it.** Skipping this step is the
most common cause of missing sub-tickets.

For every new infrastructure dependency:

1. **Find services that already use it.** Use `search_repo_info` to find
   services with the same dependency. Pick one as a reference.

2. **Trace the provisioning chain in cluster-config.** Use
   `get_repo_info_document` or `search_repo_docs` on `cluster-config` to
   understand how the infrastructure is provisioned at the cluster level.

3. **Trace the per-service wiring in deploy-config.** Use
   `get_repo_info_document` or `search_repo_docs` on `deploy-config` to
   understand how individual services declare their dependency.

4. **Surface the provisioning sub-tickets.** If wiring requires changes to
   `cluster-config` or `deploy-config`, these are separate sub-tickets that
   must precede or accompany the application sub-ticket.
