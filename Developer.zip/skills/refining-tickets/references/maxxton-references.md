# Maxxton References

## The Expand-Contract Pattern

The go-to strategy for making breaking changes independently deployable:

1. **Expand**: Add the new field/endpoint alongside the old one. Both work.
   Deploy this.
2. **Migrate**: Update all consumers to use the new field/endpoint. Deploy
   each consumer independently.
3. **Contract**: Remove the old field/endpoint once all consumers have
   migrated. Deploy this.

Each step is its own sub-ticket with its own deployment.

---

## Maxxton Glossary

The canonical domain glossary is maintained on Confluence:
- **Space**: Maxxton Help Centre (mxhc)
- **Page ID**: 2348384258
- **Site**: maxxton.atlassian.net

Always fetch the latest version at the start of each refinement session using
`getConfluenceContent`. Key domain terms to watch for: reservation (not booking),
accommodation type (not room type), add-on (not extra), distribution channel
(not sales channel), unit (not room), location (not property/park).

---

## Team-Service Mapping

The mapping of which team owns which service is maintained in GitHub:
- **Repository**: `MaxxtonGroup/cluster-config`
- **Path**: `templates/cluster/subcharts/kube-metrics/metrics-service/values.yaml`
- **Access**: Use GitHub MCP `get_file_contents` with `owner: "MaxxtonGroup"`,
  `repo: "cluster-config"`, `path: "templates/cluster/subcharts/kube-metrics/metrics-service/values.yaml"`

Fetch the latest version at the start of each refinement session.
