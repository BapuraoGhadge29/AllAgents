# Workflow: Research & Impact Analysis (Stages 3–4)

Detailed procedures for codebase research and impact analysis.

---

## Stage 3: Research the Codebase

Build a complete picture of the current architecture relevant to this change,
using the Maxxton Knowledge connector.

### 3a. Identify affected repositories

Use `search_repo_info` with queries derived from the domain concepts. Search
broadly — a reservation change might affect reservation-service,
availability-service, pricing-service, and the customer-facing API gateway.

⚡ **For multiple affected repositories, fetch their details in parallel:**

For each potentially affected repository:
- Use `get_repo_info_document` to understand what the service does
- Use `get_service_overview` to see its endpoints, outbound Feign calls,
  and async events

### 3b. Map existing data models

For each domain entity mentioned in the functional design:
- Use `get_entity_usage` to find all repository methods that access the
  entity and the service methods that call them
- Use `query_openapi` to find how the entity appears in API contracts
- Note which services **own** the entity (write to it) vs. **consume** it
  (read from it)

### 3c. Trace integration flows

For the functionality being changed:
- Use `search_technical_graph` to find relevant controller methods, service
  methods, Feign clients, and events
- Use `get_call_chain` with `direction: "outbound"` to trace the full
  execution path from API entry points
- Use `get_call_chain` with `direction: "inbound"` to find everything that
  depends on the components to be changed
- Use `find_path_between_nodes` to verify whether two specific components
  are connected

### 3d. Check API contracts in detail

- Use `query_openapi` to find existing endpoint definitions that will need
  changes
- Use `get_openapi_document` for full request/response schemas
- Use `search_repo_docs` for any ADRs or design docs relevant to the area

### 3e. Detect shared libraries and common modules

Search for shared DTOs, common event schemas, or utility modules:
- Use `search_repo_info` and `search_repo_docs` with queries like "shared",
  "common", "client library"
- Use GitHub MCP `search_code` to find shared classes referenced across
  multiple repositories (see `references/mcp-usage-patterns.md`)

If the change requires modifying a shared library, flag it prominently and
list every service that depends on the library.

### 3f. Analyze event schemas

For any async events (Kafka topics, message broker messages) that the change
touches:
- Use `search_technical_graph` with `node_type: "Event"` to find all events
- For each event, use `get_call_chain` to find all publishers and consumers
- Use GitHub MCP to find and read event class source code
- Treat event schema changes with the same rigor as API changes — they can
  break every consumer silently

### 3g. Check non-functional requirements

Use `search_repo_docs` and `search_repo_info` to look for documented NFRs:
performance requirements, scalability constraints, security policies,
data retention or GDPR requirements for affected entities.

### 3h. Look up external library documentation (mandatory before Stage 5)

**This step is not optional.** If any part of the technical design touches a
third-party library or framework, fetch its current documentation before
proceeding to Stage 5. Use Context7 (see `references/mcp-usage-patterns.md`).
If unavailable, fall back to `WebSearch`; if that also fails, use built-in
knowledge but flag it: "Based on training data — verify against current docs."

Do not begin Stage 5 if library documentation is relevant and could not be
retrieved. Surface the gap to the user and ask how to proceed.

---

## Stage 4: Impact Analysis

The gatekeeper stage. Before designing any changes, analyze what will break.

### 4a. Breaking change detection

For each proposed change:

1. **Trace consumers.** Use `get_call_chain` with `direction: "inbound"` on
   the methods to be changed. Use `get_entity_usage` to find all services
   that read/write the affected entities.

2. **Check API consumers.** Use `query_openapi` and `search_technical_graph`
   (filtering by `node_type: "FeignMethod"`) to find all services that call
   the endpoints to be modified.

3. **Check event consumers.** For event schema changes, use the technical
   graph and GitHub code search to find all consuming services.

4. **Classify each impact:**
   - **Non-breaking**: New optional field, new endpoint, new event
   - **Potentially breaking**: Changed semantics, added required field,
     modified response structure
   - **Breaking**: Removed field, renamed endpoint, changed consumed event
     schema

5. **For every breaking or potentially breaking change: STOP and consult the
   user.** Present: what the change is, which services are affected, and
   three options:
   - Option A: A workaround that avoids the breaking change
   - Option B: A migration plan using expand-contract
     (see `references/maxxton-references.md`)
   - Option C: Accept the breaking change with coordinated deployment
     (least preferred — violates independent deployability)

### 4b. Security review

Review every proposed change:
- Authentication & authorization for new endpoints
- Input validation for new API inputs
- Data exposure — does this accidentally expose PII or internal IDs?
- Multi-tenancy isolation — could Park A access Park B's data?
- GDPR considerations for personal guest data

Flag security concerns explicitly and include mitigations in sub-tickets.

### 4c. Scalability assessment

For each significant change:
- Database queries: performance with millions of records, indexes, N+1 risks
- API endpoints: call volume, caching, rate limiting, pagination
- Event throughput: burst traffic during peak booking season, backpressure
- Data growth: archiving or cleanup policies needed
- Batch operations: maximum batch size, blocking concerns

Include scalability considerations in the relevant sub-tickets.
