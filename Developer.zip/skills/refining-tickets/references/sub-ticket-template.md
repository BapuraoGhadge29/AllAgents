# Sub-Ticket Template (OpenSpec-style)

Each sub-ticket description follows this structure, optimized for both human
review and consumption by a coding agent in plan mode.

**Adapt the template to the work.** The structure below is oriented toward
Java microservice changes, but not every ticket fits that shape. For
infrastructure/DevOps tickets, the Tasks section might use categories like
"Repository Setup", "Docker/Container", "Helm Deployment", "Verification"
instead of the standard Data/Business/API/Integration layers. For frontend-only
tickets, the categories might be "Component", "State Management", "Styling",
"E2E Tests". The key skeleton to always preserve is:
Intent → Scope → Design → Delta Spec → Security → Tasks → Acceptance Criteria.

```markdown
# Intent

[What this sub-ticket achieves and why. Link to the parent ticket for full
functional context.]

**Parent ticket:** [TICKET-KEY] — [Feature Name]
**Team:** [Owning team from the team-service mapping]
**Depends on:** [TICKET-KEY-1], [TICKET-KEY-2] (or "None")
**Blocks:** [TICKET-KEY-3] (or "None")
**Estimated effort:** [S/M/L with brief justification]

# Scope

- [Concrete deliverable 1 — e.g., "Add `loyaltyTier` field to Customer entity"]
- [Concrete deliverable 2 — e.g., "Expose GET /customers/{id}/loyalty endpoint"]
- [Concrete deliverable 3]

**Out of scope:** [Explicitly what NOT to touch — prevents over-scoping]

**Traces to requirements:** FR-1, FR-3

# Design

## Technical Approach
[Architecture and implementation strategy for this specific sub-ticket]

## Key Components
[Which existing classes/methods to modify, with fully-qualified names from
the knowledge connector]
[What new components to create]

## Decisions
[Design choices made and why — helps the coding agent understand intent]

# Delta Spec

## ADDED
- [New entity/field/endpoint/event with specification]

## MODIFIED
- [Changed component with before → after]
- (Previously: [original behavior])

## REMOVED
- [Removed component with reason]

# Security Checklist
- [ ] New endpoints require authentication
- [ ] Authorization checks scope data to correct tenant
- [ ] Input validation covers all new fields
- [ ] No PII exposed in logs or error messages
- [ ] [Any feature-specific security items]

# Scalability Considerations
[What to watch for: index requirements, caching needs, expected data volume,
batch size limits, etc.]

# Data Migration
[If existing records need backfilling or patching, describe the patch/repair
SQL script that should be included in this ticket's repository. This script
runs as part of the deployment.]

# Feature Flag
[If applicable: which feature flag to use, default state, how to check it]

# Tasks

Structure tasks test-first. The coding agent should be able to work through
these sequentially.

## 1. Data Layer
- [ ] Write migration for [entity change]
- [ ] Write patch/repair SQL for existing data (if applicable)
- [ ] Write tests for repository method [X]
- [ ] Implement repository method [X]

## 2. Business Logic
- [ ] Write unit tests for [service method]
- [ ] Implement [service method]

## 3. API Layer
- [ ] Write integration tests for [endpoint] (contract testing)
- [ ] Implement [endpoint]
- [ ] Update OpenAPI spec

## 4. Integration
- [ ] Write integration tests for [Feign client / event handler]
- [ ] Implement [Feign client / event handler]

## 5. Verification
- [ ] All existing tests still pass (backward compatibility)
- [ ] New functionality works end-to-end
- [ ] Service starts and deploys independently
- [ ] Security checklist items verified

# Acceptance Criteria

- [ ] [Testable assertion 1]
- [ ] [Testable assertion 2]
- [ ] Existing API consumers are unaffected (backward compatible)
- [ ] Service deploys independently without errors
- [ ] [Performance criteria if applicable — e.g., "Query returns in <200ms
      with 1M records"]
```
