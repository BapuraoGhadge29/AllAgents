# Workflow: Design & Delivery (Stages 5–9)

Detailed procedures for producing the technical design, splitting into
sub-tickets, validating, and creating in Jira.

---

## Stage 5: Technical Design

Produce the technical design. Consider at least two approaches before
committing to one.

### 5a. Explore alternative approaches

For the overall design (and significant individual components), identify at
least two technically viable approaches. For each: describe the approach,
list pros and cons, assess complexity/risk/alignment, and state the
recommendation with justification.

Present alternatives to the user if trade-offs are significant. For
straightforward decisions, state the chosen approach with brief
justification.

### 5b. Write the technical design

Structure the technical design as follows:

```markdown
# Technical Design: [Feature Name]

## Overview
[1-2 paragraph summary of approach]

## Functional Requirements
[Numbered list: FR-1, FR-2, etc. for traceability]

## Design Decisions
[Key alternatives considered and why the chosen approach was selected]

## Affected Services
| Repository | Team | Role | Type of Change |
|---|---|---|---|

## Impact Analysis Summary
[Breaking/non-breaking changes, decisions made, security findings]

## Data Model Changes
[Per entity: current state, proposed changes, migration strategy, backfill]

## API Changes
[Per endpoint: current contract, proposed changes, backward compatibility]

## Event / Async Changes
[Per event: current schema, proposed changes, backward compatibility,
all known consumers and their required updates]

## Integration Changes
[New/modified Feign calls, sync flows, async consumers/producers]

## Cross-Cutting Concerns
[Security, performance, feature flags, multi-tenancy, GDPR]

## Shared Library Changes
[If any, with blast radius]

## Testing Strategy
- Unit tests, integration tests (contract testing), E2E tests, performance

## Deployment Order
[Ordered list with dependency explanations]

## Traceability Matrix
| Requirement | Covered by Sub-Tickets |
|---|---|
[Every FR must map to at least one sub-ticket]
```

---

## Stage 6: Determine Team Ownership

Fetch the team-service mapping from GitHub (see
`references/maxxton-references.md` for the file location). Parse the YAML
to determine which team owns each affected repository. Each sub-ticket must
be assigned to the correct team.

**Cross-team coordination**: If the feature spans services owned by different
teams, flag this prominently:
"This feature requires changes in services owned by [Team A] and [Team B].
Cross-team coordination is needed. Suggested approach: [Team A] completes
PROJ-101 first (data model changes), then [Team B] can start PROJ-102
(consumer updates)."

---

## Stage 7: Split into Sub-Tickets

**Primary split: per repository.** Each affected repository gets its own
sub-ticket, naturally aligning with independent deployability.

**Secondary split: by feature slice.** If a single repository's changes are
too large (>3 distinct areas of change or >3 days of work), split further
into vertical slices.

**Each sub-ticket must be self-contained.** After deploying just this one
ticket's changes, the system must still work correctly:
- New API fields are optional (or have sensible defaults)
- New event consumers handle the absence of the event gracefully
- Database migrations are forward-compatible
- Data backfill scripts live in the same repository

**Feature flag considerations:** If gradual rollout is needed, include the
feature flag setup in the first sub-ticket. Subsequent sub-tickets should
respect the feature flag.

### Sub-Ticket Format

Use `Read` to load `references/sub-ticket-template.md` for the full
OpenSpec-style template. The key skeleton to always preserve is:
Intent → Scope → Design → Delta Spec → Security → Tasks → Acceptance Criteria.

**Required metadata for every sub-ticket:**

| Field | Value |
|---|---|
| Labels | `gh-<repository>`, `Refined` |
| Team | Determined in Stage 6 |
| Parent | The original Jira ticket key |

### Estimation Guidance

- **S (~0.5-1 day)**: Single entity change, one endpoint, minimal integration
- **M (~1-3 days)**: Multiple related changes, some integration, moderate
  testing
- **L (~3-5 days)**: Significant changes, multiple integration points,
  complex logic

If an estimate exceeds L, the sub-ticket should be split further.

---

## Stage 8: Validate and Review

### 8a. Traceability check

- Every FR maps to at least one sub-ticket
- Every sub-ticket traces back to at least one FR
- Flag gaps; justify or remove sub-tickets that don't trace to any FR

### 8b. Independent deployability check

For each sub-ticket, verify:
- Could this be deployed right now without any other sub-ticket?
- Are all API changes backward-compatible?
- Are all event schema changes backward-compatible?
- Do database migrations only add (not remove or rename)?
- If a feature flag is needed, is it set up in the first ticket?

### 8c. Present for review

Present the complete plan:
1. Overall technical design (from Stage 5)
2. Proposed sub-tickets with descriptions
3. Deployment order with dependency explanations
4. Traceability matrix
5. Cross-team coordination requirements
6. Open questions or decisions needing human input

"Want me to adjust anything before I create these in Jira?"

---

## Stage 9: Create in Jira

After the user approves:

⚡ **Parallelize sub-ticket creation.** Create all sub-tickets in a single
turn if they have no field dependencies on each other. Then create issue
links after all tickets exist.

1. Create each sub-ticket as a child/sub-task of the parent ticket using
   `createJiraIssue`, setting the correct issue type and all required fields
   discovered in Stage 1a (especially custom fields like Maxxton Team).
   Include two labels via the `labels` field:
   - `gh-<repository>` — traceable to the correct GitHub repository
   - `Refined` — marks this ticket went through technical refinement
2. Set up issue links between dependent tickets using `mcp__claude_ai_Atlassian_MCP__executeWrite` with
   `name: createJiraIssueLink` (use "Blocks" link type for dependencies)
3. If duplicate tickets were identified in Stage 1b, link them now using
   the "Duplicate" link type
4. Add the technical design summary as a comment on the parent ticket using
   `addOrEditJiraIssueComment`
5. If the feature spans multiple teams, note cross-team coordination
   requirements in the parent ticket comment
6. **Run the post-creation checklist** before presenting results:
   - [ ] Label `gh-<repository>` is set
   - [ ] Label `Refined` is set
   - [ ] Parent link is set
   - [ ] Team field is set
   - [ ] Issue links (Blocks) are created for all dependencies

   Fix any missing items before continuing.
7. Present the user with links to all created tickets
