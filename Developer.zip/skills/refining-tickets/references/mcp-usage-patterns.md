# MCP Usage Patterns

Reference for using the GitHub MCP and Context7 MCP during refinement.

## GitHub MCP (`github`)

The GitHub MCP is essential for code-level analysis that goes beyond what the
Maxxton Knowledge connector provides.

### Common Search Patterns

**Finding event class definitions:**
```
search_code: "content:class ReservationEvent language:Java org:MaxxtonGroup"
```

**Finding all consumers of a shared DTO:**
```
search_code: "content:import com.maxxton.shared.dto.CustomerDto org:MaxxtonGroup"
```

**Reading a specific source file:**
```
get_file_contents: owner=MaxxtonGroup, repo=reservation-service,
  path=src/main/java/com/maxxton/reservation/events/ReservationCreatedEvent.java
```

**Finding shared library dependencies:**
```
get_file_contents: owner=MaxxtonGroup, repo=reservation-service, path=pom.xml
```

**Searching for feature flag usage patterns:**
```
search_code: "content:featureFlag language:Java org:MaxxtonGroup"
```

### When GitHub MCP Is Unavailable

Do not fall back to Chrome browser tools. Instead, flag the gap explicitly:
"Unable to verify [X] without code-level access — this should be validated
by a developer before implementation." Ask the user if they can provide the
relevant code or file contents directly.

---

## Context7 MCP

Context7 provides up-to-date documentation for third-party libraries and
frameworks. Use it when the technical design involves technologies where
correct implementation patterns matter.

### When to Use Context7

- The implementation requires a specific library pattern (e.g., how to set
  up a new Kafka consumer, how to use a specific Spring Boot annotation)
- You need to verify the correct API for a framework version
- The sub-ticket tasks reference a technology the developer might need
  documentation for
- You want to include code examples or implementation hints in the sub-ticket

### Usage Patterns

**Looking up a framework pattern:**
1. `resolve-library-id`: libraryName="spring-boot", query="Kafka consumer configuration"
2. `query-docs`: libraryId="/spring-projects/spring-boot", query="How to configure Kafka consumer group with error handling"

**Checking a library API:**
1. `resolve-library-id`: libraryName="spring-data-jpa", query="entity auditing"
2. `query-docs`: libraryId="/spring-projects/spring-data-jpa", query="Entity lifecycle callbacks and auditing annotations"

**Verifying a migration tool pattern:**
1. `resolve-library-id`: libraryName="flyway", query="SQL migration naming"
2. `query-docs`: libraryId="/flyway/flyway", query="Migration file naming conventions and repeatable migrations"

Include relevant documentation links or code snippets in sub-ticket tasks when
they would help the implementing developer.

### When Context7 Is Unavailable

If Context7 is at quota or unavailable, fall back to `WebSearch` to find
library documentation. If web search also fails, use built-in knowledge but
flag it: "Based on training data — verify against current docs before
implementing."
