---
name: fixing-builds
description: Diagnose and fix build failures — Gradle, npm, or webpack compilation errors, dependency resolution failures, and missing artifact issues. Use '/fixing-builds' when a Gradle, npm, or webpack build fails.
disable-model-invocation: true
argument-hint: "[optional: pasted error output]"
allowed-tools:
- Read
- Edit
- Write
- Bash
- Grep
- Glob
- mcp__claude_ai_Maxxton_Knowledge__search_repo_info
- mcp__claude_ai_Maxxton_Knowledge__search_repo_docs
---

# Build Error Resolver

Diagnose and fix build failures from Gradle (Java/Spring Boot) or npm/webpack (frontend). Supports Kotlin DSL (`build.gradle.kts`) and multi-module projects. Integrates with the Maxxton Knowledge Base to resolve errors involving internal libraries.

## Step 1: Detect Build System

Determine the project's build tool by checking for these files in order:

1. `gradlew` or `build.gradle` or `build.gradle.kts` → **Gradle**
   - Read `gradle/wrapper/gradle-wrapper.properties` for Gradle version
   - Read `build.gradle` (or `build.gradle.kts`) for Spring Boot version (`org.springframework.boot`)
   - Check for multi-module project (`settings.gradle` or `settings.gradle.kts` with `include` statements)
2. `package.json` → **npm/Node**
   - Check `scripts.build` for the build command (`tsc`, `webpack`, `vite`, `next build`, etc.)
3. None found → ask the user: *"I can't detect a build tool. What command do you use to build?"*

Report what was detected:
> **Detected:** Gradle 8.5 + Spring Boot 3.2.1, multi-module project (3 modules)

---

## Step 2: Run the Build

**If the user pasted error output**, skip this step and go directly to Step 3.

**Otherwise**, run the build:

- Gradle: `./gradlew build 2>&1`
- npm: `npm run build 2>&1`

Capture the full output including stderr.

---

## Step 3: Parse and Categorize Errors

Analyze the build output and categorize each error:

| Category | Example Patterns |
|----------|-----------------|
| **Compilation** | `error: cannot find symbol`, `TS2304: Cannot find name`, `incompatible types` |
| **Dependency** | `Could not resolve`, `Module not found`, `No matching version`, `FAILED: dependency resolution` |
| **Test failure** | `> Task :test FAILED`, `Test suite failed to run`, `FAIL src/...` |
| **Config** | `Could not find or load main class`, `Invalid Gradle configuration`, `Plugin not found` |

If the error format is not recognizable, present the raw output to the user:
> *"I can't automatically categorize this error. Here's the relevant output — can you point me to the error?"*

---

## Step 4: Diagnose and Fix Each Error

For each error, in order:

### 4a. Read Context

1. Open the failing file at the reported line number
2. Read surrounding code (50 lines above and below) for context
3. If it's a dependency error, read `build.gradle` / `package.json` for the dependency declaration

### 4b. Check Knowledge Base

Query the Maxxton Knowledge Base for known patterns:
- `mcp__claude_ai_Maxxton_Knowledge__search_repo_info` — for repository structure and dependency info
- `mcp__claude_ai_Maxxton_Knowledge__search_repo_docs` — for READMEs, ADRs and design docs on internal libraries

Skip if the Knowledge Base is unavailable or returns no results. This is an enhancement, not a requirement.

### 4c. Propose Fix

Present the fix with:
1. **Root cause** — one sentence explaining why the build failed
2. **Fix** — the exact code change
3. **Confidence** — HIGH (certain this fixes it), MEDIUM (likely fix, may need adjustment), LOW (best guess)

**Wait for user approval** before applying.

### 4d. Apply and Re-verify

1. Apply the approved fix
2. Re-run the build
3. If new errors appear, go back to Step 3 for the new errors
4. If the same error persists, propose an alternative fix

---

## Step 5: Completion

When the build is green:
> **Build passed.** Fixed N error(s) across M file(s).

List what was changed.

---

## Multi-Module Gradle Projects

When `settings.gradle` includes multiple modules:
- Run `./gradlew build` at the root to see all failures
- Target specific modules for faster iteration: `./gradlew :module-name:build`
- Check cross-module dependencies when a symbol is not found — it may live in a sibling module

## Tips

- **Don't fix test failures here** — if the only errors are test failures, suggest using the `/superpowers:test-driven-development` skill instead
- **Version conflicts** — for Gradle, check `dependencyInsight`: `./gradlew dependencyInsight --dependency <name>`
- **Clean build** — if errors seem stale, try `./gradlew clean build` or `rm -rf node_modules && npm install`

## Examples

User says: "/fixing-builds"
Claude reads the build error output, identifies the root cause, and applies the minimal fix to make the build green.

## Troubleshooting

- **Fix doesn't compile**: run the build again and share the new error output.
- **Test failures after fix**: share the failing test output for a follow-up fix.
