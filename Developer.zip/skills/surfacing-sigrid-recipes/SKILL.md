---
name: surfacing-sigrid-recipes
description: "Surfaces Sigrid Modernization Recipes — maintainability ratings, ranked refactoring candidates, and open security and reliability findings — and can update finding status. Use '/surfacing-sigrid-recipes' for tech-debt triage on a Sigrid-onboarded repo.\n"
disable-model-invocation: true
allowed-tools:
- Bash
- Read
- mcp__claude_ai_Maxxton_Knowledge__sigrid_refactoring_candidates
- mcp__claude_ai_Maxxton_Knowledge__sigrid_maintainability_ratings
- mcp__claude_ai_Maxxton_Knowledge__sigrid_list_security_findings
- mcp__claude_ai_Maxxton_Knowledge__sigrid_list_reliability_findings
- mcp__claude_ai_Maxxton_Knowledge__sigrid_edit_finding_status
---

# Surfacing Sigrid Recipes

Inspect and reduce existing technical debt using Sigrid Modernization Recipes.

## Prerequisites

- The **Maxxton Knowledge** MCP connector is connected in your claude.ai account — it provides the Sigrid tools with no token or environment setup required. Run `/mcp` to verify.
- Repo is onboarded to Sigrid (contains `sigrid.yml` or `sigrid.yaml` at the repo root)

## Sigrid context

Resolve customer and system before calling any tool:

1. **Check for `sigrid.yml`** — confirm `sigrid.yml` or `sigrid.yaml` exists at the repo root. If neither is present, exit early with:
   > "This repo isn't tracked by Sigrid (no sigrid.yml found at `<repo-root>`). Add one or run from a Sigrid-tracked repo."
2. **Customer** — always `maxxton`.
3. **System name** — run `git remote get-url origin` and parse the repo name (e.g. `git@github.com:MaxxtonGroup/mcms-api.git` → `mcms-api`). Present it as the default and ask the user to confirm or override.

## Instructions

Ask the user what they want to focus on, then call the appropriate tool with `customer=maxxton` and the confirmed system name:

| Goal | Tool |
|------|------|
| Overall health overview | `sigrid_maintainability_ratings` |
| Where to start refactoring | `sigrid_refactoring_candidates` |
| Open security issues | `sigrid_list_security_findings` |
| Open reliability issues | `sigrid_list_reliability_findings` |
| Mark a finding resolved or suppressed | `sigrid_edit_finding_status` |

1. **Clarify focus** — ask which area (security, reliability, maintainability, or refactoring) if not specified
2. **Fetch data** — call the relevant tool(s) with the resolved customer and system
3. **Prioritize** — present findings ranked by severity/impact
4. **Update status** (optional) — confirm with the user before calling `sigrid_edit_finding_status`; it modifies state in Sigrid

## Examples

User says: "Show me the maintainability ratings for my-service" → confirms `mcms-api` (from git remote), calls `sigrid_maintainability_ratings` with `customer=maxxton`, presents an overview.

User says: "Where should I start refactoring?" → confirms the detected system name, calls `sigrid_refactoring_candidates` ranked by impact.

## Troubleshooting

**Maxxton Knowledge connector not connected** — the Sigrid tools will be unavailable. Connect the Maxxton Knowledge MCP connector in your claude.ai account and run `/mcp` to confirm it shows as connected.

**No `sigrid.yml` found** — the repo isn't onboarded to Sigrid. Either add a scope file (see [Sigrid onboarding docs](https://docs.sigrid-says.com/)) or run from a different repo.

**System name not recognised by Sigrid** — the derived name from the git remote may not match what's registered in Sigrid. Override with the exact system name from the Sigrid dashboard (top-left selector); it is case-sensitive.

**`sigrid_edit_finding_status` rejected** — verify the finding ID is correct and your Sigrid account has write permissions.
