---
name: investigating-alerts
description: Investigate a production alert or incident — Prometheus/Alertmanager alerts, OOM kills, elevated error rates, CPU/memory spikes, stuck jobs, or pod crashloops. Correlates GCP logs, recent commits, Slack threads, and Jira tickets. Use '/investigating-alerts' when investigating a production alert, incident, or error spike.
disable-model-invocation: true
argument-hint: "[alert description or link]"
allowed-tools:
- Bash
- mcp__claude_ai_GitHub__list_commits
- mcp__claude_ai_GitHub__list_pull_requests
- mcp__claude_ai_GitHub__get_commit
- mcp__claude_ai_Slack__slack_search_public_and_private
- mcp__claude_ai_Atlassian_MCP__searchJiraIssuesUsingJql
---

# Investigate Production Alert

A structured, evidence-gated investigation process for production alerts and incidents. Prevents premature conclusions by requiring evidence from multiple independent sources before presenting a root cause.

## Core Principle

**Evidence before diagnosis.** Do not present a root cause until you have checked at least 3 independent data sources that corroborate it. If you cannot reach that threshold, say so and list what additional data would raise confidence.

---

## Phase 1: Gather Context

Before touching any system, clarify the scope with the developer:

1. **What fired?** — Get the alert name, message, and affected service/component
2. **When did it start?** — Exact time or approximate window
3. **Chronic or new?** — Has this alert fired before? Is it a known flaky alert or something new?
4. **What changed recently?** — Deploys, config changes, infrastructure changes in the last 48h

If the developer doesn't know the answers, that's fine — note the gaps and move on. Do not assume.

---

## Phase 2: Collect Evidence

Gather raw data from **at least 3 independent sources** before forming any hypothesis. Pick from:

| Source | What to check | Tool |
|--------|--------------|------|
| Pod/container state | `kubectl describe pod`, `kubectl get events`, restart counts, OOM signals | Bash (`kubectl`) |
| Application logs | Recent ERROR/CRITICAL entries, stack traces, log patterns | Bash (`gcloud logging read`, `kubectl logs`) |
| Metrics/dashboards | CPU, memory, request latency, error rate trends | Grafana, Cloud Monitoring |
| Recent deploys | Helm releases, Cloud Run revisions, merged PRs and deploy timestamps | Bash (`helm list`, `gcloud run revisions list`), GitHub MCP (`list_pull_requests`, `list_commits`) |
| Git history | Recent commits with PR context (title, author, linked issues) | GitHub MCP (`list_commits`, `get_commit`) |
| Configuration | ConfigMaps, environment variables, feature flags | Bash (`kubectl get configmap`) |
| Dependencies | Upstream/downstream service health, database connections | Bash (logs from dependent services) |
| Alert history | Previous firings, resolved incidents, oncall discussion | Bash (Alertmanager/Prometheus), Slack (`slack_search_public_and_private`), Jira (`mcp__claude_ai_Atlassian_MCP__searchJiraIssuesUsingJql`) |

### Rules for evidence collection

- **Fetch raw data first, interpret later.** Run commands and read output before drawing conclusions.
- **Cast a wide net.** Check sources you think are irrelevant — surprises live there.
- **Note timestamps.** Every piece of evidence should be anchored to a time.
- **Preserve exact output.** Quote actual log lines, metric values, and command output — do not paraphrase.

---

## Phase 3: Form Hypotheses

After collecting evidence, form **exactly 3 ranked hypotheses**. For each:

```
### Hypothesis N: [Short description]

**Evidence for:**
- [Specific data point with timestamp]
- [Specific data point with timestamp]

**Evidence against:**
- [Contradicting signal, or "none found yet"]

**What would confirm this:**
- [Specific check that would prove/disprove]
```

### Recent Change Bias Check

Before ranking, explicitly answer this question:

> **Does the evidence show this issue existed before the most recent deploy/change?**

Check logs, metrics, or alert history from *before* the last change. If the issue predates it, demote any hypothesis that blames the recent change. This is the single most common source of wrong conclusions — Claude and humans alike tend to blame the last thing that changed.

---

## Phase 4: Validate Top Hypothesis

For the top-ranked hypothesis, run the specific checks listed under "What would confirm this." If the check contradicts the hypothesis, promote the next one and repeat.

Do **not** skip this phase. Do **not** combine it with Phase 3.

---

## Phase 5: Present Findings

Use this format:

```
## Investigation Summary

**Alert:** [name and description]
**Affected:** [service/component]
**Time window:** [first signal] → [current state]

### Cause / Leading Hypothesis
[1-2 sentence description. If Confidence is **High**, you may relabel this section as "Root Cause".]

### Confidence: [High/Medium/Low] ([N] sources corroborate; see thresholds below)

### Evidence
- [Source]: [specific finding with timestamp]
- [Source]: [specific finding with timestamp]
- [Source]: [specific finding with timestamp]

### Ruled Out
- [Hypothesis that was disproved and why]

### Recommended Action
- [Specific fix or next step]

### Open Questions
- [Anything unresolved or uncertain]
```

### Confidence thresholds

| Level | Criteria |
|-------|----------|
| **High** | 3+ independent sources corroborate, no contradicting evidence, mechanism is clear — you may present this as the confirmed root cause |
| **Medium** | Exactly 2 independent sources corroborate, minor gaps remain, mechanism is plausible but not proven — present as a strong leading hypothesis and state what additional evidence is needed for High confidence |
| **Low** | Fewer than 2 independent sources, or contradicting evidence exists — present as "best current theory" / "leading hypothesis" and list what's needed to raise confidence |

Only when confidence is **High** should you label something as the "root cause" rather than a hypothesis.

If confidence is **Low**, explicitly say: *"I don't have enough evidence to confidently identify the root cause. Here's what I'd check next: [list]."*

---

## Red Flags — Stop If You Catch Yourself

| Thought | What to do instead |
|---------|--------------------|
| "It's probably the last deploy" | Check if the issue predates the deploy (Phase 3 bias check) |
| "This is obviously X" | Still collect 3 sources — obvious things are often wrong |
| "I'll just check one more thing to confirm" | You're confirming, not investigating. Look for disconfirming evidence |
| "The logs don't show anything, so it must be Y" | Absence of evidence is not evidence. Check other sources |
| "This is a transient spike, it'll resolve itself" | Check the history — is it actually transient, or has it been happening for months? |
| "I've seen this pattern before" | This incident is not the last one. Collect fresh evidence |

---

## Integration with Other Skills

- Use **trace-investigate** for detailed GCP log queries by traceId
- Use **top-errors** to surface error patterns across a time window
- Use **jira-duplicate-check** before creating a bug ticket
- Use **jira-bug-create** to file a ticket after root cause is confirmed

## Instructions

Invoke with "/investigating-alerts" in Claude Code. The skill guides you through the workflow step by step.

## Examples

User says: "/investigating-alerts"
Claude queries logs and traces for the alerted service, identifies the root cause, and produces a structured incident report.

## Troubleshooting

- **No logs found**: verify the service name and time range match the alert.
- **Trace ID not found**: check that the tracing system is enabled for the alerted service.
