---
name: assessing-migration-impact
description: Oracle migration impact analysis across MaxxtonGroup repos — maps DB component / table / column dependencies and classifies each PL/SQL object (dead-code / annotation-only / service-rewrite / blocked-on-upstream). Use when "assess migration impact", "analyse Oracle DB component", or "validate schema change" triggers dependency mapping across codebases.
disable-model-invocation: true
argument-hint: "[Jira ticket key, e.g. MXTS-12345] or [component name, e.g. PropertyMgr.updateProperty] or [table/column name]"
allowed-tools:
- mcp__claude_ai_Atlassian_MCP__getAccessibleAtlassianResources
- mcp__claude_ai_Atlassian_MCP__getJiraIssue
- mcp__claude_ai_Atlassian_MCP__searchJiraIssuesUsingJql
- mcp__claude_ai_Maxxton_Knowledge__search_technical_graph
- mcp__claude_ai_Maxxton_Knowledge__get_entity_usage
- mcp__claude_ai_Maxxton_Knowledge__get_service_overview
- mcp__claude_ai_Maxxton_Knowledge__get_call_chain
- mcp__claude_ai_GitHub__search_code
- mcp__claude_ai_GitHub__get_file_contents
- mcp__claude_ai_GitHub__pull_request_read
- Read
- Glob
- Grep
- Bash
- Write
- Agent
- AskUserQuestion
---

# DB Migration Impact Analysis

Full impact analysis for Oracle-to-Java database migration. Covers DB-level dependencies and Java backend service impacts — then produces a component-specific migration plan that is safe within Maxxton's DB-first deployment window. Frontend analysis is skipped (frontend applications do not directly invoke DB-level components).

## Reference Files

Read these files at the stages indicated:

- **`references/migration-patterns.md`** — initiative context, deployment timeline, component-specific migration strategies, key patterns from completed PRs, exclusion rules. **Read before Stage 1** for DB impact constraints/exclusion rules, and **consult again before Stage 5** for migration-strategy recommendations.
- **`references/repo-catalogue.json`** — categorized list of all MaxxtonGroup repos with team and domain. **Read before Stage 2** to identify the correct backend service repos to search.
- **`references/schema-object-path.md`** — full Schema Object Validation Path workflow (steps S1–S4). **Read immediately when INPUT_TYPE = `schema_object`**, before doing anything else in that path.
- **`references/cascade-trace.md`** — recursive algorithm for tracing each caller back to its root entry point when an upstream dependency is retired. **Read before Stage 3.5** if Stage 0.5 captured a retired upstream.
- **`references/classification-rules.md`** — first-match rules for classifying each PL/SQL object as `dead-code`, `annotation-only:<X>`, `service-rewrite`, or `blocked-on-upstream`. **Read before Stage 4a** for per-object classification.
- **`references/report-format.md`** — standard markdown structure for the impact analysis section of the Stage 6 output. **Read before Stage 6**.
- **`references/retired-upstream-modules.md`** — authoritative list of modules already retired in production. **Read during Stage 0.5** to decide whether to mark `UPSTREAM_STATUS = retired` automatically or ask the developer.
- **`references/migration-recommendations-template.md`** — full template for the Stage 5 migration plan. **Read before Stage 5**.

---

## Known Retired Upstream Modules

The authoritative list of upstream modules already retired in production lives in **`references/retired-upstream-modules.md`**. Stage 0.5 consults that list before asking the developer; entries are added there as the project lead confirms each retirement.

---

## Stage 0: Resolve the Input

### 0a. Determine input type

The user provides one of three things:
1. A **Jira ticket key** (e.g. `MXTS-12345`) — matches `[A-Z]+-\d+`
2. A **DB component name** (e.g. `PropertyMgr.updateProperty`, `trg_accommodation_bi`, `install_memomanager_src`) — PascalCase with dot, or starts with `trg_`/`install_`, or the user explicitly describes a procedure/package/function/trigger/FK
3. A **schema object** (table or column name, e.g. `addressmanager`, `reservation_base`, `reservation_base.start_date`) — lowercase, snake_case, no PascalCase, no `trg_`/`install_` prefix; OR the user explicitly says "table" or "column"

Record the detected type as **INPUT_TYPE**: `jira_ticket`, `db_component`, or `schema_object`.

If the input is ambiguous (e.g. a simple lowercase word that could be either a table name or a package name), use `AskUserQuestion`:
- Question: `"Is '<input>' a table/column name (schema change) or a DB component (procedure/package/trigger/function/FK) for migration analysis?"`
- Options: `"Table or column name"`, `"DB component (procedure/package/trigger/FK)"`

---

**If INPUT_TYPE = `jira_ticket`:**
- First call `mcp__claude_ai_Atlassian_MCP__getAccessibleAtlassianResources` to resolve the Maxxton Atlassian site and capture its `cloudId` (do not hardcode `maxxton.atlassian.net`; use the UUID returned by `mcp__claude_ai_Atlassian_MCP__getAccessibleAtlassianResources`). Reuse this resolved `cloudId` for all subsequent `mcp__claude_ai_Atlassian_MCP__getJiraIssue` and `mcp__claude_ai_Atlassian_MCP__searchJiraIssuesUsingJql` calls in this workflow.
- Fetch the ticket with `mcp__claude_ai_Atlassian_MCP__getJiraIssue` using the resolved `cloudId`.
- Extract from title + description:
  - Component name(s) — the specific procedure/package/function/trigger/FK being migrated
  - Component type — procedure, package method, standalone function, non-event trigger, FK constraint
  - The SQL install file(s) involved (e.g. `install_amenitymanager_src.sql`)
  - Any explicitly mentioned table names

**If INPUT_TYPE = `db_component`:**
- Accept it directly; ask the user for component type if not clear from the name

**If INPUT_TYPE = `schema_object`:**
- If the input contains a dot (e.g. `reservation_base.start_date`), split into table name and column name.
- If no dot, ask via `AskUserQuestion`:
  - Question: `"Is '<input>' a table name or a column name?"`
  - Options: `"Table name"`, `"Column name (I'll provide the table name too)"`, `"Both — search for the column inside a specific table"`
- If column name only, ask for the table name (helps reduce false positives): `"What table does column '<column>' belong to? (Leave blank to search all tables)"`
- Record as **SCHEMA_OBJECT_TABLE** and **SCHEMA_OBJECT_COLUMN** (either may be null).
- Also ask: `"What schema change are you planning?"` with options:
  - `"DROP TABLE"`, `"DROP COLUMN"`, `"RENAME TABLE"`, `"RENAME COLUMN"`, `"ALTER COLUMN TYPE"`, `"Other / not sure yet"`
- Record as **PLANNED_CHANGE**.

### 0b. Scope confirmation

> **Skip this step if INPUT_TYPE = `schema_object`** — scope is always the single table/column provided.

If multiple components are named in the ticket (e.g. a whole package with 5 methods), confirm with `AskUserQuestion` whether the user wants:
- A) Full impact analysis across all components in the ticket
- B) A single specific component

Proceed once scope is confirmed.

### 0c. Output preference

Before starting the analysis, ask the user where to save the report.

**Step 1** — Use `AskUserQuestion`:

- Question: `"Where should the impact analysis report be saved?"`
- Options:
  - **"Downloads folder (default)"** — saves to the user's Downloads folder
  - **"Custom location"** — user will provide their preferred folder path
  - **"Console only"** — display in chat only; no file is written

**Step 2** — If the user chose **"Custom location"**, ask a follow-up:

- Question: `"Enter the folder path where the report should be saved (e.g. C:\Users\name\Documents or /home/name/reports):"`
- Options: _(any two placeholder options are fine — the user will type their path via the "Other" free-text field)_
  - **"Use Downloads folder instead"** — fall back to the default
  - **"Cancel — Console only"** — switch to console output

Record the result as:
- **OUTPUT_MODE**: `file` or `console`
- **OUTPUT_PATH** (only when OUTPUT_MODE = `file`):
  - For **Downloads (default)**: resolve the folder with `Bash`:
    ```bash
    echo "${USERPROFILE:-$HOME}/Downloads"
    ```
  - For **Custom location**: use the folder path the user typed
  - In both cases append a filename: `impact-analysis-<component-slug>-<YYYY-MM-DD>.txt`
    where `<component-slug>` is the component name lowercased with spaces, dots, and slashes replaced by hyphens, and `<YYYY-MM-DD>` is today's date.

---

### 0d. Exclusion check

> **Skip this step if INPUT_TYPE = `schema_object`** — the event-trigger exclusion is specific to the Oracle-to-Java migration path.

If the component is an **event trigger** (identifiable by: fires on an event/audit table, or name contains `_auai`, `_auad`, or `_event`), stop and inform the user:
> "Event triggers are out of scope for Oracle-to-Java database migration and are excluded from impact analysis."

---

### 0e. Source Code Access Check

Before Stage 1, verify that GitHub code search is working by attempting a lightweight probe:

```
mcp__claude_ai_GitHub__get_file_contents:
  owner: MaxxtonGroup
  repo: newyse
  path: src
```

**If the probe succeeds** (returns a file listing): set `CODE_SOURCE = github`. Proceed normally — Stages 1a and 2a, plus the Schema Object path steps, will use `mcp__claude_ai_GitHub__search_code` and `mcp__claude_ai_GitHub__get_file_contents`.

**If the probe fails** (404 or access denied): set `CODE_SOURCE = local`.

**Step 1 — Check memory for known local paths**: Before asking the user, scan `MEMORY.md` and any referenced memory files (e.g. `reference_local_paths.md`) for previously resolved local paths. If found, record them as defaults and skip to Step 3.

**Step 2 — Ask for paths** via `AskUserQuestion` (two questions in one call). For each question, offer the most likely path for this machine as the first option (based on any partial context you have), plus a "Skip" option. The user can type a custom path via the "Other" free-text field:
  1. **"Where is your local newyse checkout?"** — the root folder of the newyse repo. SQL files will be searched under `<path>/src/`.
     - Options: `"<most likely path>"`, `"Skip — no local newyse checkout"`
  2. **"Where are your local MXTS Java service repos?"** — the parent folder containing individual service directories (e.g. where `resource-service`, `rate-service`, etc. are sub-folders).
     - Options: `"<most likely path>"`, `"Skip — no local service checkouts"`

**Step 3 — Verify paths exist**: After recording the paths, verify each one with Bash before proceeding:
```bash
ls "<NEWYSE_LOCAL_PATH>/src" 2>/dev/null | head -3 || echo "NOT FOUND"
ls "<SERVICES_LOCAL_PATH>" 2>/dev/null | head -3 || echo "NOT FOUND"
```
- If a path is confirmed (listing returned): proceed.
- If a path returns `NOT FOUND`: scan the parent directory (`ls "<parent>"`) to locate the correct sub-directory, report what you found, and update the path before continuing. Do not ask the user again — resolve it automatically if possible.

Record the final verified results as:
- **NEWYSE_LOCAL_PATH**: the verified newyse root, or `null` if skipped/not found
- **SERVICES_LOCAL_PATH**: the verified services parent directory, or `null` if skipped/not found

If both are null, continue with Maxxton Knowledge graph only and note clearly in the report that DB-level SQL and Java source analysis were skipped due to unavailable code access.

---

### 0f. Branch based on input type

- **If INPUT_TYPE = `schema_object`**: skip Stages 0.5–6. Follow **`references/schema-object-path.md`** (Schema Object Validation Path), then stop.
- **If INPUT_TYPE = `jira_ticket`**: continue with Stage 0.5 (Upstream-dependency check), then Stage 1.
- **If INPUT_TYPE = `db_component`**: skip Stage 0.5 (no ticket description to parse) and continue with Stage 1.

---

## Stage 0.5: Upstream-dependency check (Jira ticket only)

> Runs only when `INPUT_TYPE = jira_ticket`. Skip for `db_component` and `schema_object`.

If the ticket description mentions a precondition (e.g. *"once X is retired"*, *"when Y is closed"*, *"after the module is gone"*), capture the named target as `UPSTREAM_DEPENDENCY`.

1. **Check `references/retired-upstream-modules.md`.** If the captured phrase matches a known-retired entry (or a clear synonym), mark `UPSTREAM_STATUS = retired`.
2. **Otherwise, ask the developer** via `AskUserQuestion`: *"Is `<dependency>` already retired/closed in production?"* — *"Yes, retired"* → `retired`; *"Not yet — block this work"* → `not_yet`.
3. If `UPSTREAM_STATUS = not_yet`, classify every object as `blocked-on-upstream` (Stage 4a), skip Stages 1–3.5, and jump to Stage 4b/6 to emit the report.

If no precondition is mentioned, `UPSTREAM_STATUS = none` (default; Stage 3.5 cascade trace will not run).

---

## Schema Object Validation Path

See **`references/schema-object-path.md`** for the full workflow (steps S1–S4). Run all steps in that file, then stop — do not continue to Stages 1–6.

---

## Stage 1: DB-Level Impact Analysis

> **Goal**: Find every other database object that calls or depends on this component.

Read `references/migration-patterns.md` now (the Newyse repo structure and exclusion rules are critical here).

### 1a. Search the newyse SQL codebase

**If `CODE_SOURCE = github`**: Use `mcp__claude_ai_GitHub__search_code` with `repo: MaxxtonGroup/newyse`:
1. The component name exactly (e.g. `PropertyMgr.updateProperty` or `trg_rentability_marker_a`)
2. The package name alone if a package method (e.g. `PropertyMgr`)
3. Any table names associated with the component (search for `INSERT INTO table_name`, `UPDATE table_name`, `DELETE FROM table_name`)

**If `CODE_SOURCE = local` and `NEWYSE_LOCAL_PATH` is set**: Use `Grep` on the local SQL directory:
- Search root: `<NEWYSE_LOCAL_PATH>/src/`
- Run the following Grep searches:
  1. Pattern: `<component name>` — glob: `*.sql` — finds all SQL files referencing the component
  2. Pattern: `<package name>\.` (if package method) — glob: `*.sql`
  3. Pattern: `INSERT INTO <table>|UPDATE <table>|DELETE FROM <table>` (for each known table) — glob: `*.sql`
- Use `Read` to open any matching `.sql` file to confirm the nature of the reference (definition vs. call).
- Use `Glob` pattern `<NEWYSE_LOCAL_PATH>/src/install_*.sql` to enumerate all install files if you need to understand the full file inventory.

**If `CODE_SOURCE = local` and `NEWYSE_LOCAL_PATH` is null**: Skip this step. Note "DB-level SQL analysis skipped — no newyse access" in the report.

For each match (regardless of source), identify:
- Which `install_xxx_src.sql` or `install_xxx_ext.sql` file contains the reference
- Whether the reference is a **call** (dependency) or a **definition** (where the component lives)
- What type of DB object is making the call (another procedure, a trigger, a view, a cron call)

**Exclusion rule (strictly enforced)**: Ignore any matches in:
- `newyse-old` or `newyse_old` repository or any such sub-path in a local checkout (both naming variants exist)
- `.java` files anywhere in the newyse repo
- `.xml` files anywhere in the newyse repo

### 1b. Classify DB-level dependents

Group findings into:
- **Direct callers**: Other procedures/packages that explicitly call this component
- **Trigger dependencies**: Triggers on the same table that may rely on side effects (e.g. a BEFORE trigger setting `:NEW.id` that an AFTER trigger reads)
- **View/constraint dependencies**: Views or check constraints referencing this function
- **Cron/scheduler references**: Scheduler jobs that invoke the procedure

### 1c. Check for already-migrated related tickets

Search Jira:
```jql
project = MXTS AND text ~ "ComponentName" AND (parent = MXTS-43651 OR parent = MXTS-47522 OR parent = MXTS-73822 OR parent = MXTS-73823 OR parent = MXTS-73824 OR parent = MXTS-73825)
```

Note any tickets already in progress or resolved for this component — avoids duplicate work.

---

## Stage 2: Java Backend Impact Analysis

> **Goal**: Find which Java MXTS services call this DB component directly, and which services own the tables it touches.

### 2a. Search Java service repositories

**If `CODE_SOURCE = github`**: Read `references/repo-catalogue.json` and take the repository names listed under `backend`, filtered to Java service repos only (skip repos where the primary language is Python, TypeScript, Dockerfile, or other non-Java). Use `mcp__claude_ai_GitHub__search_code` scoped to those repos individually (not `org:MaxxtonGroup` broadly). For each filtered Java backend repo, search for:
1. The procedure/function/package name as a string literal (case-insensitive)
2. Patterns: `CallableStatement`, `SimpleJdbcCall`, `@Procedure`, `@NamedStoredProcedureQuery`, `StoredProcedure`
3. The SQL install file name (e.g. `install_amenitymanager_src.sql` references in comments or migration scripts)

If `references/repo-catalogue.json` cannot be read or does not contain enough metadata to identify Java repos, fall back to a broader `org:MaxxtonGroup` GitHub search only as a last resort, and note the broader search scope and catalogue limitation in the report. Do not treat non-Java backend repos as covered by this stage.

**If `CODE_SOURCE = local` and `SERVICES_LOCAL_PATH` is set**: Use `Grep` on the local services directory. The expected layout is `<SERVICES_LOCAL_PATH>/<service-name>/` per service from `references/repo-catalogue.json → backend`. Run:
1. `Grep` pattern: `<component name>` — path: `<SERVICES_LOCAL_PATH>` — glob: `*.java` — to find any direct string references
2. `Grep` pattern: `CallableStatement|SimpleJdbcCall|@Procedure|@NamedStoredProcedureQuery` — path: `<SERVICES_LOCAL_PATH>` — glob: `*.java` — to find all stored procedure call sites, then filter results to those near the component name
3. `Grep` pattern: `install_<module>manager` — path: `<SERVICES_LOCAL_PATH>` — glob: `*.java` — to find comments referencing the SQL file

For each local match, use `Read` to open the file around the matched line for context (class name, method, transaction scope).

**Exclusion (strictly enforced)**: The Java search must only target MXTS microservice repos — do not search inside `newyse`, `newyse_old`, or `newyse-old` directories when looking for Java callers. Newyse `.java` and `.xml` files are not in scope for the migration. When using local `Grep`, filter out any result whose file path contains `newyse` or `newyse_old` as a directory segment before reporting findings.

**If `CODE_SOURCE = local` and `SERVICES_LOCAL_PATH` is null**: Rely solely on Maxxton Knowledge graph (Stage 2b–2d). Note "Java source search skipped — no local service checkout" in the report.

For each match (regardless of source), note:
- Repository name and file path
- How the component is invoked (direct JDBC call, Spring Data proc, JPA annotation)
- Whether there is an existing Java equivalent already

### 2b. Find table owners via Maxxton Knowledge

For each table the component reads from or writes to:
1. Use `mcp__claude_ai_Maxxton_Knowledge__get_entity_usage` or `mcp__claude_ai_Maxxton_Knowledge__search_technical_graph` to find which Java services declare `@Entity` / `@Table` for those tables
2. Use `mcp__claude_ai_Maxxton_Knowledge__get_service_overview` on the owning service to understand its domain and team

These services are **primary candidates** for receiving the migrated logic.

### 2c. Trace call chains

If a Java service is identified in 2a or 2b, use `mcp__claude_ai_Maxxton_Knowledge__get_call_chain` to understand:
- Which service methods invoke the stored procedure
- Whether the call is synchronous (in a transaction) or asynchronous (via event/job)

### 2d. Check for existing Java equivalents

Search the owning service's codebase for any partial Java implementation:
```
mcp__claude_ai_GitHub__search_code: repo:<service-repo> <ComponentName OR table-related business logic keywords>
```

Flag if a Java equivalent already exists (partial or full).

---

## Stage 3: Frontend Impact Analysis — SKIPPED

Frontend applications do not directly invoke DB-level components (procedures, packages, triggers, FK constraints). Skip this stage entirely. Do not search frontend repos or query OpenAPI for frontend tracing.

The owning Java service's API endpoints are identified in Stage 2b as a side-effect of finding the table owner — that is sufficient context for the report.

---

## Stage 3.5: Removal cascade detection (recursive trace)

> Run this step **only** when `UPSTREAM_STATUS = retired` (Stage 0.5 captured a retired upstream). Skip otherwise.

For every object with non-zero callers from Stages 1–2, recursively trace each caller back to its root entry point per the algorithm in **`references/cascade-trace.md`** (which includes the *recency-check rule*: even if a caller lives inside a retired upstream's namespace, flag as `unknown` when the consuming repo's default branch was touched recently — verify the consuming repo's latest commit date with `mcp__claude_ai_GitHub__pull_request_read` or a `gh api .../commits` call via `Bash`).

Per call site, record one of: `unreachable` / `reachable` / `unknown`.

Stage 4a classification follows the **worst label** across callers: any `reachable` → `service-rewrite`; all `unreachable` → `dead-code`; any `unknown` → flag and stop.

---

## Stage 4: Compile the Impact Report

### 4a. Per-object classification

For each PL/SQL object, apply the first-match rules in **`references/classification-rules.md`**. Possible values: `dead-code`, `annotation-only:<X>`, `annotation-only:composite`, `service-rewrite`, `blocked-on-upstream` (only when `UPSTREAM_STATUS = not_yet`). The reference also lists recommended actions per classification (`delete` / `annotate-only` / `migrate-to-service` / `keep-open-await-prerequisite`) and the rationale-writing rules (for `service-rewrite`: read the target service's repository layer first so the rewrite matches the existing data-access style; add a `limitations_note` flagging cross-customer scope).

### 4b. Report format

Present the findings in this format:

```
## Impact Analysis: [Component Name] ([Component Type])

**Ticket**: [MXTS-XXXXX — Title] (if applicable)
**Component**: [full name, e.g. PropertyMgr.updateProperty]
**Component type**: [Procedure / Package method / Function / Non-event trigger / FK constraint]
**Classification**: [dead-code / annotation-only:<X> / service-rewrite / blocked-on-upstream]
**Recommended action**: [delete / annotate-only / migrate-to-service / keep-open-await-prerequisite]
**SQL install file(s)**: [install_xxx_src.sql]

---

### DB-Level Impact

| Dependent Object | File | Type | Nature of Dependency |
|---|---|---|---|
| [name] | [file] | [trigger/procedure/view/cron] | [calls it / side-effect dependency / table overlap] |

**Already-in-progress tickets**: [list or "None found"]

---

### Backend Service Impact

| Service | Repository | How it uses the component | Team |
|---|---|---|---|
| [service name] | [repo] | [CallableStatement / @Procedure / table owner] | [MXTS team] |

**Table owners** (services that own the affected tables and should receive the migrated logic):
- [service-name] owns [table_name] — [domain]

---

### Summary

- **DB dependents**: N objects call or depend on this component
- **Backend services affected**: N services (N direct callers, N table owners)
- **Existing Java equivalent**: [Yes (partial/full) / No]
- **Already-migrated related tickets**: [list / None]
```

---

## Stage 5: Migration Recommendations

Read `references/migration-patterns.md` now for component-specific patterns and the deployment timeline constraint.

Provide a migration plan tailored to the component type. The plan **must** address the 12-hour deployment window between DB release (morning) and services release (+12h same day).

Structure the recommendation following the full template in **`references/migration-recommendations-template.md`** — Approach + Phase 1 (Migration: DB + Java same release cycle, with the 12-hour deployment window safety section and the optional Same-Window Release alternative) + Per-Repo Developer Instructions (one block per repo from Stage 2 + newyse) + Phase 2 (Obsolete code removal) + Risks/Mitigations table + Suggested Ticket Structure (separate migration ticket vs cleanup ticket).

---

## Stage 6: Output

Based on the **OUTPUT_MODE** captured in Stage 0c. Read **`references/report-format.md`** for the exact structure of the impact analysis section.

### OUTPUT_MODE = `file`

1. Assemble the full report as a single markdown-formatted string. It must include:
   - The complete Impact Analysis block from Stage 4b (all tables, summary, with per-object Classification + Recommended action) — use the structure from **`references/report-format.md`**
   - The complete Migration Recommendation block from Stage 5
   - A header line: `# DB Migration Impact Analysis — <Component Name>` and `Generated: <YYYY-MM-DD>`

2. Use the `Write` tool to write the report to **OUTPUT_PATH**.

3. Tell the user: `Report saved to: <OUTPUT_PATH>`

4. Also display the **Summary** sub-section from Stage 4b in chat (the 5-bullet block + classifications table) so the user can see key findings without opening the file.

### OUTPUT_MODE = `console`

Display the full Impact Analysis (Stage 4b) and Migration Recommendation (Stage 5) in the chat as normal. No file is written.

---

## Stage 7: Branch Setup Advisory

> Run only when `INPUT_TYPE = jira_ticket`. Skip for `db_component` and `schema_object` inputs.

This stage is advisory only — the skill does not create branches itself. Using the ticket type and priority fetched in Stage 0a, output a recommended branch name and base branch for each repo identified in Stage 2 + newyse.

**Branch naming rules (Maxxton triage conventions):**

| Ticket type | Priority | Branch prefix | Base branch |
|---|---|---|---|
| Bug | P1 or P2 | `hotfix/<TICKET>` | `main` (or latest `release/YYYY.WW` if one exists) |
| Bug | P3 or lower | `bugfix/<TICKET>` | `develop` |
| Non-Bug (Story, Task, etc.) | P1 or P2 | `feature/<TICKET>` | `main` (or latest `release/YYYY.WW` if one exists) |
| Non-Bug | P3 or lower | `feature/<TICKET>` | `develop` |

Output these recommendations under the **Per-Repo Developer Instructions** section of the migration recommendation report (Stage 5). Each entry follows the block structure in `references/migration-recommendations-template.md`.

---

## Rules

### Rules for the DB Component / Migration path (INPUT_TYPE = `db_component` or `jira_ticket`)

1. **Never include event triggers** in the analysis. If the component turns out to be an event trigger, stop and inform the user.
2. **Never include newyse `.java`/`.xml` files or any newyse-old files** in the impact analysis. The newyse repository is where the DB SQL code lives (search `src/` SQL files freely), but its Java and XML layers are out of scope for the Oracle-to-Java migration initiative. If a broken call from newyse Java to a removed DB procedure is discovered as a side-effect, flag it for the Newyse team — but do not include it in the migration scope.
3. **Always address the 12-hour DB-first deployment window** in the migration recommendation — every plan must be safe during that gap.
4. **If a Java equivalent already exists** (even partial), flag it prominently and suggest building on it rather than starting from scratch.
5. **If a DB-level dependent is itself already queued for migration**, note the ordering dependency — the caller should be migrated before or together with the callee.
6. **If impact is unclear** (sparse Maxxton Knowledge results, no GitHub matches), say so explicitly: "Limited data — validate with a developer familiar with [service]."
7. **Skip frontend analysis entirely** — frontend applications do not directly invoke DB-level components and are not in scope for this analysis.
8. **Obsolete code removal** is a separate phase — never bundle it into the same ticket as the Java migration unless the component has zero DB dependents and the migration risk is minimal.

### Rules for the Schema Object Validation path (INPUT_TYPE = `schema_object`)

9. **Newyse Java and XML files ARE in scope** — the entire newyse codebase (SQL, Java, XML) must be searched. The only exclusion is `newyse-old` / `newyse_old`.
10. **Search all repo categories** — do not skip CMS, legacy, or any other category in `repo-catalogue.json`. A missed dependency in any codebase can cause a production incident.
11. **Always identify the JPA entity owner** before flagging a DROP as safe — if a service owns the entity, the schema change must be coordinated with that team.
12. **Flag high-noise searches explicitly** — if the table or column name is very short or generic (e.g. `id`, `name`, `type`), warn the user that results may contain false positives and manual review is required.
13. **The usage report is the deliverable** — do not produce a migration plan for this path. The report is meant to be attached to the schema change ticket as evidence of a safe (or blocked) change.

### Universal rules

14. **Markdown URL formatting required.** Every URL in any output must be a markdown link `[descriptive text](url)`. Bare URLs do not render as clickable links in Jira clients. Before returning, scan the output for any unwrapped `http(s)://` and wrap them. This includes ticket keys (`[MXTS-12345](https://maxxton.atlassian.net/browse/MXTS-12345)`), PR references, GitHub file paths, and Confluence links.

## Instructions

Invoke with `/assessing-migration-impact` in Claude Code. The skill guides you through the workflow step by step.

## Examples

User says: "/assessing-migration-impact"
Claude maps all usages of the specified DB component, table, or column across all codebases and produces a dependency report.

## Troubleshooting

- **No usages found**: verify the DB component name matches exactly what is used in the codebase.
- **Missing repos**: check that all codebases are listed in `references/repo-catalogue.json`.
