# Cascade-trace algorithm — Stage 3.5

When an `UPSTREAM_DEPENDENCY` is retired and the target object still has callers in newyse SQL or other repos, this algorithm decides whether each caller is reachable, unreachable, or unknown. Output feeds Stage 4a's classification.

## Inputs

* `TARGET_OBJECT` — the PL/SQL object the ticket asks to remove
* `UPSTREAM_DEPENDENCY` — the retired module name (e.g. *"Newyse pricecompare"*, *"nws module"*, *"Newyse Postoffice"*)
* `CALL_SITES` — list of `{file, line, snippet}` from Stages 1-2

## Per call site

0. **Pre-flight: collapse retired-module callers.** If the call site lives in a retired-module repo or path — typically `newyse-old`, `newyse_old`, `nwsportal/newyse/<retired-subsystem>/`, or any path matching a retired entry in `retired-upstream-modules.md` — classify it `unreachable` IMMEDIATELY without running steps 1–5. **Do not enumerate these in the cascade-trace output.** They are already known to be retired before cascade even begins; restating them per-caller wastes the developer's time and adds noise. Instead emit a single summary line at the top of the cascade section:

   ```
   Skipped N retired-module callers (auto-unreachable, pre-collapsed):
   newyse-old (N), <other retired path> (N), ...
   ```

   The cascade-trace output proper should ONLY include sites in active code that needed recursive tracing (steps 1–5 below).

1. **Fetch enclosing block.** Use `mcp__claude_ai_GitHub__get_file_contents` on the caller file. Locate the enclosing `CREATE OR REPLACE PROCEDURE|FUNCTION|TRIGGER|VIEW|PACKAGE BODY` whose body contains the call line (for SQL callers), or the enclosing Java class/method (for Java callers). Record its `ENCLOSING_NAME`.

2. **Find callers of the enclosing block.** Three searches:
   * newyse SQL — `mcp__claude_ai_GitHub__search_code repo:MaxxtonGroup/newyse path:src/ "<ENCLOSING_NAME>"`
   * Java services — `mcp__claude_ai_GitHub__search_code org:MaxxtonGroup -repo:MaxxtonGroup/newyse-old language:java "<ENCLOSING_NAME>"`
   * Cron / scheduler — `mcp__claude_ai_GitHub__search_code repo:MaxxtonGroup/newyse "<ENCLOSING_NAME>" path:src/install_scheduler` and similar scheduler-suffixed files

3. **Classify each parent caller:**
   * **Live root** if it is one of:
     * a REST endpoint or `@Controller`-reachable Java service method
     * a cron job or scheduler row that is still active
     * a `BEFORE/AFTER INSERT|UPDATE|DELETE` trigger on a table that is still written to from live code paths
   * **Retired root** if it is a procedure/function/trigger whose name or comment explicitly references the `UPSTREAM_DEPENDENCY` (e.g. `pricecomparePkg.something`, `modreservation_*` table, `nws_*` trigger, `nwsportal/newyse/postoffice/*` paths)
   * **Intermediate** otherwise — recurse with this parent as the new call site (step 1)

4. **Recursion limit.** Maximum **5 hops** total. If hop 5 still yields intermediates, mark the call site as `unknown` and stop.

5. **Recency-check rule (added from MXTS-58012 finding).** Before labelling a caller `unreachable`, check the *consuming repo*'s default-branch HEAD commit date:
   * **Applies to non-retired-module callers only** — retired-module callers (newyse-old, etc.) are pre-collapsed at step 0 and never reach this check.
   * If the default branch was touched within the **last ~30 days**, the upstream-closed assumption is potentially stale — flag the call site as `unknown` (forcing manual verification with the consuming team) rather than `unreachable`.
   * Why: in MXTS-58012, `nwsportal/newyse/mailing/*` (under the *closed* Newyse Postoffice namespace, but in the live `portal` repo — NOT in newyse-old) was wrongly classified `unreachable` by a naïve namespace check; the consuming `portal` repo had been committed to 2 days earlier, and a related ticket (MXTS-43838) was actively refactoring email code. The naïve label would have shipped a P1 SQL-schema-drop against tables still being SELECTed live.
   * Practical check: `mcp__claude_ai_GitHub__pull_request_read` (or `gh api repos/MaxxtonGroup/<repo>/commits?sha=<default_branch>&per_page=1`) — read the most recent commit's `committed_at` date.

6. **Label the original call site:**
   * `unreachable` — every parent (across all branches) terminated at a Retired root, AND the recency check (step 5) does not raise concerns
   * `reachable` — at least one parent (any branch) terminated at a Live root
   * `unknown` — recursion limit reached, no clear Live/Retired terminus found, OR recency check flagged the consuming repo as actively maintained

## Optimisations

* **Memoise** the classification of every `ENCLOSING_NAME` you've already traced. Multiple call sites often share an enclosing block.
* **Batch parent searches** when several enclosing blocks share a prefix (e.g. all `reservationPkg.*` methods).
* **Prefer the technical graph** when the enclosing block is a Java method: `mcp__claude_ai_Maxxton_Knowledge__search_technical_graph` gives faster, structured results than GitHub code search.

## Output format

Add a `Cascade trace` subsection per object in the Stage 6 workspace payload (or under the per-object detail in the user-mode report). Lead with the pre-collapse summary (step 0), then list only the active call sites that needed real tracing (steps 1–5):

```
**Cascade trace:**

Skipped 4 retired-module callers (auto-unreachable, pre-collapsed):
newyse-old (4).

Active call sites traced:
- `src/install_accountancy_src.sql:7409` (enclosing: `accountancyPkg.computeResortRev`) → reachable
  Path: enclosing procedure called from `install_settlement_src.sql:1142` (live trigger on settlement_base) → live root.
- `src/install_reservation_ext.sql:257` (enclosing: view `reservedresource_view`) → unreachable
  Path: view's only parent caller terminates at a Retired root (no live consumers); consuming-repo recency check N/A (in-newyse).
- `src/install_reservation_src.sql:1842` (enclosing: procedure `reservationPkg.processSpecials`) → unknown
  Path: 5 hops in, last parent was `reservationCorePkg.adjustBill` with 14 callers — manual review recommended.
- `nwsportal/newyse/mailing/MailingMapper.xml:47` → unknown
  Path: namespace match suggests retired, BUT consuming repo `portal` default branch touched 2 days ago AND MXTS-43838 refactoring adjacent email code — defer to portal team before drop.
```

Stage 4a's recommended classification follows the **worst** label across all callers: any `reachable` → `service-rewrite`; all `unreachable` → `dead-code` (one-PR cascade removal); any `unknown` → flag and stop, write blocked-on-investigation rationale.

## Rules

1. **Always memoise.** A procedure with 30 callers traced 5 times is 150 searches — memoisation drops that to 30.
2. **Newyse-only retired markers count.** If `ENCLOSING_NAME` lives in a file whose path or name explicitly contains the retired module (`install_pricecompare_*`, `install_modreservation_*`, `install_nws_*`, `nwsportal/newyse/postoffice/*`), classify as Retired root without further trace **unless** the recency check (step 5) flags the consuming repo as actively maintained — in which case downgrade to `unknown`.
3. **Java callers are usually live roots.** Any non-test Java method reachable from a `@Controller`/`@RestController` counts as Live root.
4. **Never assume.** If a trace is ambiguous, label `unknown` — do not bias toward `reachable` or `unreachable` to keep things simple.
5. **Recency check is non-negotiable for non-newyse consumers.** Any caller in a repo other than `newyse` itself must pass the step-5 recency check before being marked `unreachable`.
