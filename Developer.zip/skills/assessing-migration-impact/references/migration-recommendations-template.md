# Migration recommendation template — Stage 5

Stage 5 of `assessing-migration-impact` follows this template.

The plan **must** address the 12-hour deployment window between DB release (morning) and services release (+12h same day) — every recommendation must be safe during that gap.

## Template

````markdown
## Migration Recommendation: [Component Name]

### Approach
[1-3 sentences: recommended strategy and rationale]

### Phase 1 — Migration (DB + Java, same release cycle)

**Newyse (database) changes:**
1. [Specific SQL change — e.g. "Add ContextPkg.isTaskEnabled('task_name') guard to <component>"]
2. [Release upgrade/patch script to deploy the guard]

**Java service changes ([service-repo]):**
1. [Implement equivalent logic in Java — specific class/method suggestion]
2. [Unit/integration tests to cover migrated logic]
3. [Enable the task flag after deployment is confirmed stable]

**Deployment window safety:**
[Explain what happens in the 12-hour window between DB release and services release, and why it is safe]

### Alternative: Same-Window Release (Optional)

If the team wants to avoid the two-release cycle and ship DB + Java changes together:

1. Schedule both the DB and services releases in the **same deployment window** (e.g., same evening maintenance slot)
2. Deploy DB changes first — the `isTaskEnabled` guard is in place but the task flag stays **disabled**, so the DB component continues running normally during the gap
3. Deploy the Java service **immediately after** the DB release is confirmed healthy (within the same window, not 12 hours later)
4. Enable the task flag once the Java service is confirmed stable — the DB component becomes a no-op from that point

**Use this approach when**: The Java equivalent has been thoroughly tested, call volume is manageable, and the team can monitor both deployments back-to-back in the same window.
**Stick with the standard 12-hour window when**: The component is high-volume or business-critical and a longer observation period between DB and services release is safer.

### Per-Repo Developer Instructions

One block per repo identified in Stage 2 (Java services) plus newyse. The skill fills these in using the discovered call sites and the per-repo conventions (`.claude/rules/`, `CLAUDE.md`, enabled-plugins) it can see during analysis.

#### Repo: <repo-name>

- **Branch:** `<prefix>/<TICKET>` cut from `origin/<base>` (Maxxton triage rule for <Ticket type> + <Priority>)
- **Files to add:**
  - `<path>`
    - <Class / signature description>
    - <Style constraints — e.g. @Service, @Transactional(readOnly = true) at class level>
- **Files to edit:**
  - `<path>`
    - <Specific edit — e.g. wrap procedure body with ContextPkg.isTaskEnabled('task_name') guard>
- **Style constraints (mandatory):**
  - <Per-repo style — e.g. "Default: Spring Data + JPA Criteria / Specifications. JPQL only when the query is too complex to express otherwise. Never entityManager.createNativeQuery. Match the repository style in src/main/java/.../repository/.">
- **Verify:** `<command>` (e.g. `./gradlew test`)
- **Commit subject:** `<type(scope): TICKET: imperative summary>` per Maxxton commit-message-format rule

### Phase 2 — Obsolete Code Removal (next release cycle or same if low risk)

1. [Remove the DB component body from install_xxx_src.sql]
2. [Add DROP statement to release patch script]
3. [Remove Java JDBC/procedure call code in service repos]
4. [Disable and remove any cron jobs calling the procedure]
5. [Verify no remaining references with GitHub code search]

### Risks and Mitigations

| Risk | Mitigation |
|---|---|
| [risk] | [mitigation] |

### Suggested Ticket Structure

- **Migration ticket** (under current migration epic): "[Component] — Migrate to Java ([service-repo])"
  - Newyse SQL guard + Java implementation + tests
- **Cleanup ticket** (under current cleanup epic): "[Component] — Obsolete code removal"
  - Remove DB code, patch script, remove JDBC calls
````

## Filling the template

- Cite the `service-rewrite` rationale from Stage 4a when explaining the Approach.
- Reference specific files and methods identified in Stages 1–2 (file paths + line numbers).
- If Stage 3.5 ran (retired upstream), include any `unknown` cascade results as Risks.
- The `Suggested Ticket Structure` always splits Migration from Cleanup — never bundle them unless the component has zero callers and removal carries no risk.
