# Schema Object Validation Path

> This path runs when a **table name or column name** is provided. The goal is to find every codebase that references the schema object before a structural change (DROP, RENAME, ALTER) is made — replacing the error-prone manual search that led to the RP-28981 incident.

### S1. Build search terms

Derive the search patterns from the resolved input:

**For a table name** (SCHEMA_OBJECT_TABLE set, SCHEMA_OBJECT_COLUMN null):
- SQL DML: `FROM {table}`, `JOIN {table}`, `INTO {table}`, `UPDATE {table}`, `DELETE FROM {table}`, `TABLE {table}`
- JPA / Java: `@Table(name = "{table}")`, `@Table(name="{table}")`, `"{table}"` near `@Entity`
- Plain string: `{table}` (broad catch-all — verify matches in context)

**For a column name** (SCHEMA_OBJECT_COLUMN set):
- SQL: `{column}` near the table name (if known), `@Column(name = "{column}")`, `@Column(name="{column}")`
- Plain string: `{column}` — note this is noisy; flag likely false positives (e.g. column names that are also common words)

**For a table.column pair**:
- Use both sets of patterns above; prefer matches where both names appear in the same file.

---

### S2. Search all codebases

Read `references/repo-catalogue.json` now to identify all repository categories and names.

Classify repos into:
- **Active** — `backend` category (MXTS Java microservices)
- **Legacy** — `newyse`, `cms`, or any category explicitly tagged as legacy in the catalogue

Search **every active and legacy repo** — do not skip any category. This is the critical difference from the migration path: the entire codebase must be checked.

Run the searches in this order:

#### S2a. Newyse SQL (legacy)

**If `CODE_SOURCE = github`**: Use `mcp__claude_ai_GitHub__search_code` with `repo: MaxxtonGroup/newyse`, search under `src/`:
1. Each SQL DML pattern for the table name
2. `{column}` if a column search

**If `CODE_SOURCE = local` and `NEWYSE_LOCAL_PATH` is set**: Use `Grep` on `<NEWYSE_LOCAL_PATH>/src/` with glob `*.sql`.

For each match, note: install file, line context, type of usage (SELECT/INSERT/UPDATE/DELETE/DDL).

#### S2b. Newyse Java and XML (legacy)

> **IMPORTANT**: Newyse `.java` and `.xml` files ARE in scope for this path — they were specifically the source of the missed dependency in RP-28981.

**If `CODE_SOURCE = github`**: Use `mcp__claude_ai_GitHub__search_code` with `repo: MaxxtonGroup/newyse`:
1. `{table}` — glob: `*.java`
2. `{table}` — glob: `*.xml` (MyBatis mappers, Hibernate XML, Spring config)
3. `{column}` (if set) — glob: `*.java`, `*.xml`

**If `CODE_SOURCE = local` and `NEWYSE_LOCAL_PATH` is set**: Use `Grep` on `<NEWYSE_LOCAL_PATH>` with glob `*.java` and `*.xml`. Exclude `newyse-old` or `newyse_old` path segments.

For each match, note: file path, class/method name, nature of usage.

#### S2c. Active MXTS backend services

From `references/repo-catalogue.json → backend`, search each Java service repo:

**If `CODE_SOURCE = github`**: For each backend repo, use `mcp__claude_ai_GitHub__search_code`:
1. `{table}` — finds string literals, entity annotations, native queries, JPQL
2. `@Table(name = "{table}")` — confirms JPA entity ownership
3. `{column}` (if set) — finds `@Column` annotations and query references

**If `CODE_SOURCE = local` and `SERVICES_LOCAL_PATH` is set**: Use `Grep` on `<SERVICES_LOCAL_PATH>` with glob `*.java`:
1. Pattern: `{table}` — finds all Java references
2. Pattern: `@Table.*{table}|@Column.*{column}` — JPA annotations

For each match, note: repo name, file path, class name, type of usage (entity owner, query, etc.).

#### S2d. CMS and other legacy repos

From `references/repo-catalogue.json`, identify any repos tagged as `cms` or other non-backend non-newyse legacy categories.

For each such repo, use `mcp__claude_ai_GitHub__search_code`:
1. `{table}` — any reference
2. `{column}` (if set)

Note: repo name, file path, usage context.

#### S2e. Maxxton Knowledge graph

Use `get_entity_usage` or `search_technical_graph` to find which Java services declare a JPA `@Entity` / `@Table` mapping for the table. This identifies the **owning service** — the one most impacted by a DROP or structural change.

If a table owner is found, use `get_service_overview` to capture its domain and team.

---

### S3. Compile the Schema Object Usage Report

Present findings in this format:

```
## Schema Object Usage Report: {table} [.{column}]

**Planned change**: {PLANNED_CHANGE}
**Search date**: {YYYY-MM-DD}

---

### Active Codebases (MXTS Backend Services)

| Repository | File | Usage type | Detail |
|---|---|---|---|
| [repo] | [file:line] | [JPA entity owner / query / native SQL] | [brief context] |

**JPA entity owner**: [service-name] — [domain] (this service is the primary owner of [{table}])

---

### Legacy Codebases

#### Newyse (SQL)

| Install file | Line | Usage type |
|---|---|---|
| [install_xxx_src.sql] | [line ref] | [SELECT / INSERT / UPDATE / DELETE / DDL] |

#### Newyse (Java / XML)

| File | Class / Mapper | Usage type |
|---|---|---|
| [file path] | [ClassName or mapper id] | [query call / entity mapping / XML mapper] |

#### CMS and other legacy

| Repository | File | Usage type |
|---|---|---|
| [repo] | [file] | [reference type] |

---

### Summary

- **Total repositories with usages**: N (N active, N legacy)
- **JPA entity owner**: [service or "Not found"]
- **SQL usages in Newyse**: N files
- **Java/XML usages in Newyse**: N files
- **CMS/other legacy usages**: N files
- **Safe to proceed?**: [Yes — no active dependencies found / Caution — active dependencies found in N repos / Blocked — owning entity found, coordinate with [team]]

---

### Recommended next steps before {PLANNED_CHANGE}

1. [Service-specific action — e.g. "Update JPA entity in [service-repo] to remove the column mapping"]
2. [Newyse SQL action — e.g. "Remove SELECT of {column} from install_xxx_src.sql"]
3. [Newyse Java action — e.g. "Update DTO/mapper in newyse to stop reading {column}"]
4. [Ticket suggestion — e.g. "Create a sub-task under the schema change ticket for each impacted service"]
```

If no usages are found in active codebases and only legacy references exist, state clearly:
> "No active MXTS service dependencies found. Legacy references in Newyse/CMS exist but are expected for a legacy table — coordinate with the Newyse team before dropping."

If the search returned many false positives (e.g. a very short column name), flag it:
> "High noise warning: '{column}' is a common term — review each match carefully before concluding safety."

---

### S4. Output (Schema Object path)

Follow the same output logic as Stage 6:
- **OUTPUT_MODE = `file`**: Write the full report to **OUTPUT_PATH**. Display the Summary block in chat.
- **OUTPUT_MODE = `console`**: Display the full report in chat.

**End of Schema Object Validation Path.** Do not continue to Stages 1–6.
