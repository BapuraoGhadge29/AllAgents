# Classification Rules — Oracle PL/SQL → Java migration

Source of truth for Stage 4a of the `assessing-migration-impact` skill. The trigger-migration playbook on Confluence is the authoritative human reference: <https://maxxton.atlassian.net/wiki/spaces/POL/pages/1868890155/>

Apply rules in order. **First match wins.**

## Rule 0 — blocked-on-upstream

Stage 0.5 captured an `UPSTREAM_DEPENDENCY` and the developer confirmed `UPSTREAM_STATUS = not_yet`. The ticket cannot proceed until the prerequisite is retired/closed/removed.

→ Classification: `blocked-on-upstream`
→ Recommended action: `keep-open-await-prerequisite`
→ Rationale includes the dependency text (e.g. *"blocked on Newyse pricecompare retirement"*)

When this rule fires, **all** objects in the ticket get this classification regardless of their caller counts — there's no value in deeper analysis until the prerequisite clears.

## Rule 1 — dead-code

Body has zero callers across all sources from Stages 1-3 (newyse SQL, Java services, MyBatis XML), OR all callers were classified `unreachable` in the Stage 3.5 cascade trace.

→ Classification: `dead-code`
→ Recommended action: `delete`

## Rule 2 — annotation-only:@ConcernId

Body contains **only** `:NEW.concern_id := contextpkg.getConcernId();` (with optional whitespace and an optional surrounding `BEGIN`/`END;`).

→ Classification: `annotation-only:@ConcernId`
→ Java equivalent: `@ConcernId` on the entity's `concern_id` field

## Rule 3 — annotation-only:@ClientId

Body contains **only** `:NEW.employee_id := contextpkg.getemployeeid();`

→ Classification: `annotation-only:@ClientId`
→ Java equivalent: `@ClientId` on the entity's `employee_id` field

> **Naming convention note:** the DB column is `employee_id` and the SQL function is `contextpkg.getemployeeid()`, but the Java annotation is `@ClientId`. This is intentional — Maxxton's legacy schema names the client/operator identifier `employee_id` for historical reasons, and the JPA layer abstracts it as `@ClientId`. Do not rename either side.

## Rule 4 — annotation-only:@CreationTimestamp

BEFORE INSERT trigger whose body is only `:NEW.creation_date := SYSDATE;`

→ Classification: `annotation-only:@CreationTimestamp`
→ Java equivalent: `@CreationTimestamp` + `updatable = false` on the entity's `creation_date` field

## Rule 5 — annotation-only:@UpdateTimestamp

BEFORE UPDATE trigger whose body is only `:NEW.modified_date := SYSDATE;`

→ Classification: `annotation-only:@UpdateTimestamp`
→ Java equivalent: `@UpdateTimestamp` on the entity's `modified_date` field

## Rule 5b — annotation-only:@SequenceGenerator

Body matches the PK-sequence pattern with an optional null guard:

```
IF :NEW.<pk_col> IS NULL OR :NEW.<pk_col> <= 0 THEN
  SELECT seq_<table>.NEXTVAL INTO :NEW.<pk_col> FROM dual;
END IF;
```

Or unconditional: `SELECT seq_<x>.NEXTVAL INTO :NEW.<pk_col> FROM dual;`

The `IF ... IS NULL OR ... <= 0` is a "simple null guard" and does **not** disqualify Rule 5b. Only the PK column is assigned; no other side effects.

→ Classification: `annotation-only:@SequenceGenerator`
→ Java equivalent: `@SequenceGenerator(name = "seq_<table>", sequenceName = "seq_<table>", allocationSize = 1)` + `@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seq_<table>")` on the entity's `@Id` field

Composite triggers that include a PK sequence **plus** one of Rules 2–6 fall to Rule 7 (`annotation-only:composite`), not here.

## Rule 6 — annotation-only:@ManagerId (and variants)

Body sets a single manager-id column via `SEQ_<NAME>MANAGER.NEXTVAL` or `eventmgr.m_createinstance('<thing>')`. Variants by sequence:

| Sequence / pattern | Annotation |
| --- | --- |
| `SEQ_MANAGER.NEXTVAL` | `@ManagerId` |
| `SEQ_IMAGEMANAGER.NEXTVAL` | `@ImageManagerId` |
| `SEQ_ADDRESSMANAGER.NEXTVAL` | `@AddressManagerId` |
| `SEQ_RESOURCEMANAGER.NEXTVAL` | `@ResourceManagerId` |
| `SEQ_CLUSTERMANAGER.NEXTVAL` | `@ClusterManagerId` |
| `eventmgr.m_createinstance('<x>')` | `@ManagerId` with `eventCategory = "<x>"` |

→ Classification: `annotation-only:<annotation>` (use the specific variant)
→ Java equivalent: the matching annotation on the manager-id field of the owning entity

## Rule 7 — annotation-only:composite

Body contains **multiple** `:NEW.*` assignments, each matching a single rule from Rules 2–6, **and no other logic** (no IF/CASE, no SELECT, no DML on other tables, no exception handlers, no PRAGMA, no COMMIT).

→ Classification: `annotation-only:composite`
→ Java equivalent: the field-to-annotation map (one entry per assignment)

## Rule 8 — service-rewrite (catch-all)

Body contains any of:

* `IF`/`CASE` blocks (other than a simple null guard)
* `EXCEPTION WHEN` handlers with business logic
* Cursor loops (`FOR ... IN ... LOOP`, `BULK COLLECT`, `FORALL`)
* DML (`INSERT`/`UPDATE`/`DELETE`) on a table other than the trigger's own `:NEW`/`:OLD` table
* Calls to other packages (e.g. `rentabilityPkg.something()`, `eventmgr.m_*` for purposes beyond Rule 6)
* `LISTAGG`, `NVL`, `SUBSTR`-in-WHERE-clause, `ROWNUM`
* `COMMIT` or `PRAGMA AUTONOMOUS_TRANSACTION`
* Multiple `:NEW.*` assignments **plus** any of the above (cannot be Rule 7)

→ Classification: `service-rewrite`
→ Recommended action: `migrate-to-service`

**Rationale rule for `service-rewrite`:** before writing the rationale, read the target Java service's existing repository layer (e.g. `*-service/src/main/java/.../repository/*.java`). Note the data-access style in use (Spring Data method names like `findByX`, `MaxxtonJpaRepository` extensions, etc.) and recommend a rewrite that matches it. Do not invent a new style — match what the service already does.

**Limitations footer:** every `service-rewrite` object gets a one-line `limitations_note`: *"Cross-customer impact data (WEE / Powerplay / CMS / MyKrim) is out of this skill's reach and must be confirmed manually before merge."*
