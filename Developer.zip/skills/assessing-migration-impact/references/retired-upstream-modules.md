# Known retired upstream modules

The project lead has confirmed the following modules are fully retired in production. When Stage 0.5 captures an `UPSTREAM_DEPENDENCY` matching one of these (or a clear synonym), mark it as **retired** automatically — do **not** ask the developer. Check git history of this file for the confirmation date.

## Retired modules

| Module / phrase | Notes |
| --- | --- |
| `Newyse module` / `nws module` / `nws client` / *"once nws is closed"* | Fully retired everywhere. |
| `Newyse pricecompare` / `modreservation` | Retired (subset of Newyse closure). |
| `Newyse Postoffice` / *"once postoffice is closed"* / *"when the postoffice is gone"* | Retired (subset of Newyse closure). Confirmed via MXTS-58012 ticket workflow. |
| `PostofficeReservationSearchPkg` | Removed via MXTS-58020 patch on 01-JUN-2026 (Newyse Postoffice dependency). |

## How matches work

Match the captured `UPSTREAM_DEPENDENCY` phrase from the ticket description against the *Module / phrase* column above:

- **Exact match** — case-insensitive, ignoring leading/trailing punctuation. Mark `UPSTREAM_STATUS = retired`.
- **Clear synonym** — e.g. *"the postoffice"* matches *"Newyse Postoffice"*; *"the nws side"* matches *"nws module"*. Mark `UPSTREAM_STATUS = retired`.
- **No match** — fall through to the `AskUserQuestion` step in Stage 0.5.

When in doubt, ask the developer rather than mark `retired` on a fuzzy match. False-positive `retired` flags lead to wrong classifications later in the cascade trace.

## Adding entries

When a project lead confirms a new module is retired, add a new row to the table above with a one-line note. Include a ticket reference where possible (e.g. *"Removed via MXTS-XXXXX patch"*) so the audit trail is durable. The git history of this file serves as the confirmation log.

Do **not** remove entries from this list — once retired, retired.
