# Migration Patterns Reference

## Initiative Context

**Initiative**: MXTS-72535 — CM/BM Database code migration to MXTS  
**Goal**: Eliminate Content Manager's dependency on Oracle stored procedures by migrating business logic into Java MXTS services.  
**Quarterly cadence** (per initiative epics):
- Migration epic (e.g. MXTS-43651, MXTS-73822, MXTS-73823): Rewrite DB procedures/packages/triggers into Java
- Obsolete code removal epic (e.g. MXTS-47522, MXTS-73824, MXTS-73825): Remove DB code after Java is confirmed stable

**In scope for migration**: procedures, packages, functions, FK constraints, non-event triggers  
**Out of scope**: event triggers (do NOT include in impact analysis or migration plan)

---

## Critical Deployment Timeline Constraint

```
Production release day:
  [Morning]    → Database release  (newyse SQL scripts applied)
  [+12 hours]  → Services release  (Java services deployed)
```

**This creates a 12-hour window where the new DB schema is live but OLD Java services are still running.**

Migration must be designed so that:
1. After the DB release, old Java services continue to work correctly.
2. After the services release, the new Java logic takes over cleanly.
3. No functionality gap exists in the 12-hour window.

---

## Two-Phase Migration Pattern

### Phase 1: Migrate (Java implementation + DB toggle)

The DB component is NOT removed yet. Instead:
1. Implement the equivalent logic in the Java MXTS service.
2. Add a `ContextPkg.isTaskEnabled('task_name')` check inside the DB procedure/trigger so it becomes a no-op when the task is enabled.
3. DB release: Deploy the SQL changes (the DB component now checks the task flag and does nothing if enabled).
4. Services release: Deploy the Java service that now handles the logic. Enable the task flag to disable DB execution.

**Pattern in SQL (procedure/package)**:
```sql
CREATE OR REPLACE PROCEDURE my_procedure(...) AS
BEGIN
  IF ContextPkg.isTaskEnabled('my_java_task') THEN
    RETURN; -- Java handles this now
  END IF;
  -- original DB logic here
END;
```

**Pattern in SQL (trigger — non-event)**:
```sql
CREATE OR REPLACE TRIGGER trg_my_trigger
AFTER INSERT OR UPDATE ON my_table
FOR EACH ROW
BEGIN
  IF ContextPkg.isTaskEnabled('my_java_task') THEN
    RETURN;
  END IF;
  -- original trigger logic
END;
```

### Phase 2: Obsolete code removal (after Java is stable)

1. Remove the DB component body (or the entire trigger) from `install_xxx_src.sql`.
2. Add a patch script under `src/mxts/upgrade/YYYY/release_vXXXX.XX.X_patch.sql` to DROP the object at runtime.
3. Remove any Newyse Java or XML code that called the procedure (but keep the newyse-old exclusion — don't touch newyse-old files).

---

## Component-Specific Migration Strategies

### Procedures & Package Procedures

**DB impact search**:
- Search for `package_name.procedure_name` in other SQL install files
- Search for `CALL package_name.procedure_name` or `EXECUTE package_name.procedure_name`
- Look inside other packages that may call it

**Java impact search**:
- Search for `procedure_name` (case-insensitive) in all Java service repos
- Look for `@Procedure`, `CallableStatement`, `SimpleJdbcCall`, `StoredProcedure`
- Check `@NamedStoredProcedureQuery` annotations in JPA entities
- Check Newyse Java/XML files for calls (but those will remain in Newyse — just note them)

**Migration approach**:
- Add `ContextPkg.isTaskEnabled()` guard (Phase 1)
- Implement equivalent logic in the owning Java service (determined by which table/domain the procedure operates on)
- After validation, remove DB code (Phase 2)

---

### Packages (full package migration)

**Additional complexity**: A package may contain many procedures/functions, global variables, and cursors used by other packages.

**DB impact search**:
- Search for `package_name.` (dot access) across all install files
- Search for the package name in `install_xxx_ext.sql` files (these are extension files that override/extend base packages)

**Migration approach**:
- Migrate function by function; not necessarily all at once
- Global package variables may need to be replaced with Java application state or DB configuration tables
- Cursors become JPA queries or Spring Data queries

---

### Functions (standalone or within packages)

**DB impact search**:
- SQL functions can appear inline in SELECT/WHERE/DML — search broadly
- Check if function is used in computed columns, views, or constraints

**Java impact search**:
- Functions called from Java via `SimpleJdbcCall`, `@Function`, or native queries
- Check for functions used in `@Formula` JPA annotations

**Migration approach**:
- Implement as a Java service method
- If used in SQL queries, consider whether the query can be rewritten to avoid the function or whether the Java layer pre-computes the value

---

### Non-Event Triggers (BEFORE/AFTER INSERT/UPDATE/DELETE)

> **Note**: Event triggers (AUAI/AUAD patterns or triggers on event tables) are OUT OF SCOPE for migration.

**DB impact search**:
- Find what table the trigger fires on — all code touching that table may be affected by removing the trigger
- Check if other triggers on the same table depend on side effects of this trigger (e.g., values set in BEFORE triggers)
- Check if trigger sets `:NEW` values that subsequent code relies on

**Java impact search**:
- Find the Java service that owns the table (check `@Entity` / `@Table` annotations)
- The service that inserts/updates that table must now execute the trigger's logic itself
- Search for `@PrePersist`, `@PreUpdate` entity lifecycle hooks — check for conflicts

**Migration approach**:
- BEFORE INSERT sequence triggers: Replace with `seq_xxx.NEXTVAL` directly in INSERT statements, or use JPA `@GeneratedValue`
- Logic triggers: Move to the Java service method that performs the DML (typically in a `@Transactional` service method)
- Add the ContextPkg task check guard if the trigger fires frequently and cannot be removed atomically

**Deployment window risk for triggers**:
- After the DB release (trigger guard added), old Java services still run. The trigger check ensures the DB still handles the logic during the 12-hour window.
- After services release, Java handles it, trigger becomes a no-op.

---

### Foreign Key Constraints

**DB impact search**:
- Identify parent and child tables
- Find all INSERT/UPDATE/DELETE operations on both tables across all install files
- Check for `ON DELETE CASCADE` or `ON DELETE SET NULL` — these have implicit side effects

**Java impact search**:
- Find all services that write to the child table — they must now enforce referential integrity in Java
- Find services that delete from the parent table — they must handle child cleanup or check for orphans

**Deployment window risk for FK constraints**:
- FK removal is a DB-release change; Java enforcement must be in services release
- In the 12-hour window, no FK in DB and no Java check yet — data integrity relies on application code NOT deleting orphaned parents
- Recommend: Keep FK constraint in DB until services release and remove it as part of the same services release (via a migration script or a second DB patch); OR ensure Java validation is added prior to the DB FK removal

---

## Obsolete Code Removal Checklist

When the Java migration is confirmed stable:

- [ ] Remove the procedure/trigger/function body from `install_xxx_src.sql`
- [ ] Add an Oracle-safe drop to the release patch script — wrap in a PL/SQL block with exception handling, e.g.:
  ```sql
  BEGIN
    EXECUTE IMMEDIATE 'DROP PROCEDURE xxx';
  EXCEPTION WHEN OTHERS THEN
    IF SQLCODE != -4043 THEN RAISE; END IF; -- ORA-04043: object does not exist
  END;
  /
  ```
  Use the same PL/SQL loop pattern when dropping multiple legacy objects (see PR#20430 pattern above).
- [ ] Remove the `ContextPkg.isTaskEnabled()` check (no longer needed)
- [ ] Remove Newyse Java calls to the procedure (excluding newyse-old)
- [ ] Remove Newyse XML references
- [ ] Disable and remove any cron jobs that called the procedure
- [ ] Remove `@NamedStoredProcedureQuery`, `@Procedure`, `CallableStatement` in Java services
- [ ] Check if any views or other DB objects depend on the removed object — drop or rewrite them
- [ ] Verify no orphan references remain with a GitHub code search

---

## Newyse Repository Structure (key paths)

```
newyse/
  src/
    install_xxx_src.sql         — source file for module xxx (procedures, packages, triggers)
    install_xxx_ext.sql         — extension/override file for module xxx
    mxts/upgrade/YYYY/
      release_vXXXX.XX.X_install_ext_src.sql   — objects to create/recreate at upgrade
      release_vXXXX.XX.X_patch.sql              — DDL changes: DROP, ALTER, data patches
```

> **Exclusion rule**: Do NOT consider `.java` or `.xml` files from `newyse-old` or the `newyse` repository Java/XML code in impact analysis or migration tasks. Only consider `src/` SQL files from newyse.

---

## Key Patterns from Completed PRs

**PR#20405 (MXTS-57767)** — trg_rentability_marker_a + RentabilityChangePkg:
- Added `ContextPkg.isTaskEnabled('rentability_change_package')` guard to triggers and procedures
- Replaced `BEFORE INSERT` sequence trigger with explicit `seq_xxx.NEXTVAL` in INSERT statements
- Added release upgrade and patch scripts to drop the obsolete trigger

**PR#20430 (MXTS-75026)** — Reseller event triggers:
- Removed triggers from `install_reseller_event_src.sql`
- Added PL/SQL loop in patch script to DROP all legacy triggers at runtime

**Pattern from MXTS-44514/MXTS-62777** — AccommodationDoorlockPkg (two-phase example):
- Phase 1 (MXTS-44514): Migrated `generateDoorlockCodes` to Java MXTS service
- Phase 2 (MXTS-62777): Disabled cron jobs, removed DB package, dropped trigger on doorlock_kc_pincode table

---

## What NOT to Include in Impact Analysis

- Event triggers (AUAI, AUAD patterns) — excluded per initiative scope
- newyse-old repository files
- newyse `.java` and `.xml` files
