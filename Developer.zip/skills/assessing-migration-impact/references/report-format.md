# Impact Analysis Report Format

Standard output format for the impact analysis section of every skill run (Stage 6). The skill writes this to file or console per the output preference from Stage 0c.

## Rules

- **Every URL must be a markdown link** `[descriptive text](url)`. Bare URLs do not render as clickable links in Jira clients. Includes ticket keys (`[MXTS-12345](https://maxxton.atlassian.net/browse/MXTS-12345)`), PR references, GitHub file paths, Confluence links. Scan the output before returning and wrap any unwrapped `http(s)://`.

## Structure

````markdown
# Oracle PL/SQL Impact Analysis — <TICKET>

## Upstream dependency

**Captured:** *"<dependency phrase from ticket description>"* (or *"none"* if no precondition mentioned).
**Status:** **retired** | **not_yet** | **none** — and how it was determined (known-list match, developer-confirmed, or no precondition).

## Summary

| Object | Type | Callers | Classification | Action |
| --- | --- | --- | --- | --- |
| AgentSettlementPkg.createBillNumber | package_function | 3 SQL, 1 Java, 0 MyBatis | service-rewrite | migrate-to-service |
| trg_aset_bill_bi | trigger | — | annotation-only:@ManagerId | annotate-only |
| trg_touroperator_settle_gbd | trigger | — | dead-code | delete |

## Per-object detail

### <Object Name>

**Classification:** <classification>
**Recommended action:** <action>
**Limitations:** [for `service-rewrite`: include the cross-customer limitations_note]

**Newyse SQL callers:**
- [src/install_billing_src.sql:142](https://github.com/MaxxtonGroup/newyse/blob/main/src/install_billing_src.sql#L142) — "snippet of the call line"
- (or `none`)

**Java service callers:**
- [reservation-service / BillingService.java:88](https://github.com/MaxxtonGroup/reservation-service/blob/main/src/main/java/com/maxxton/reservation/BillingService.java#L88) — "@Procedure" / "CallableStatement" / etc.
- (or `none`)

**MyBatis XML callers:**
- [portal / nwsportal/newyse/mailing/persistence/MailingMapper.xml:47](https://github.com/MaxxtonGroup/portal/blob/main/nwsportal/newyse/mailing/persistence/MailingMapper.xml#L47) — "select id reference"
- (or `none`)

**Rationale:** <1-3 sentences. For `service-rewrite`, mention the body characteristics that triggered the rule (e.g. "Body contains a CASE block with cross-table INSERT into reservation_bill and conditional COMMIT — meets the service-rewrite rule"). Mention the active-caller count.

**Removal cascade** (only present if Stage 3.5 fired):
- `<caller>` → `unreachable` / `reachable` / `unknown` — short reason per the cascade-trace algorithm output.
- Suggested sub-ticket: *"<a sentence describing the cascade-removal follow-up>"* (optional).

### <Next Object Name>

... (repeat per object)

## Limitations of this analysis

- Any caveats — e.g. Maxxton Knowledge MCP unavailable this run, GitHub rate-limited mid-search, scope of org/repo searches, etc.
- Cross-customer impact (WEE / Powerplay / CMS / MyKrim) is always out of scope — note it explicitly when any object is classified `service-rewrite`.
````

## Stop after emitting the report

Do not call any tool after emitting the report. Do not write additional output. The developer drives the next steps using the migration recommendation from Stage 5.
