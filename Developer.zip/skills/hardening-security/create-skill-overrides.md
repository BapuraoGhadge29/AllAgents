# Skill Overrides: hardening-security

## disable-model-invocation not set

**Reason:** Skill is read-only with no side effects (uses only `Read`, `Bash`, `Grep`, `Glob` — no MCP write tools). Already validated as model-invocable in the personal plugin (`steven166/personal`). Auto-invocation when handling user input, authentication, or external integrations is desirable — the skill surfaces security guidance exactly when the user is building those features.
