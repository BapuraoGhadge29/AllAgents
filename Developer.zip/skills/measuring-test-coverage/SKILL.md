---
name: measuring-test-coverage
description: Use '/measuring-test-coverage' when generating JaCoCo unit test coverage reports for a Maxxton backend service, identify under-covered classes, and write missing unit tests following the project's existing test patterns. Also supports targeting a specific class or method directly without running a full coverage report.
argument-hint: "[service-name] | [ClassName] | [ClassName.methodName] | [path/to/ClassName.java]"
allowed-tools:
- Read
- Write
- Edit
- Bash
- Grep
- Glob
disable-model-invocation: true
---

# Unit Test Coverage

Generate a JaCoCo coverage report for a Maxxton backend service, identify classes that need more tests, and write the missing unit tests following the project's exact coding and testing conventions.

Alternatively, target a specific class or method directly — skipping the coverage report — to immediately write or improve tests for it.

---

## Step 0: Detect Mode

Inspect the argument to decide which workflow to follow:

| Condition | Mode |
|-----------|------|
| Argument ends with `.java` | **Class mode** — path to a source file |
| Argument contains `.` or `::` and the part before the separator is PascalCase (e.g. `AmenityService.findById` or `AmenityService::findById`) | **Class mode** — class + optional method |
| Argument is a single PascalCase word with no path separators (e.g. `AmenityService`) | **Class mode** — class name only |
| Anything else (hyphenated name, path containing `gradlew`, etc.) | **Service mode** |


### If Class mode → do the following, then skip to Step 4:

1. **Resolve the source file.**
   - If the argument is a file path ending in `.java`: use it directly as `CLASS_FILE`.
   - If the argument is `ClassName` or `ClassName.method` or `ClassName::method`: extract `ClassName`, then `Glob` for `**/<ClassName>.java` under the current working directory. If multiple matches are found, list them and ask the user which one to use.

2. **Extract the method name (if provided).**
   - If the argument contains `.` or `::`, the part after the separator is `TARGET_METHOD`. Record it — Step 5d will focus exclusively on this method.
   - If no method was specified, `TARGET_METHOD` is unset — all under-tested methods in the class will be targeted.

3. **Resolve `SERVICE_DIR`.**
   - Starting from the directory containing `CLASS_FILE`, walk up the directory tree until a directory containing `gradlew` is found. That directory is `SERVICE_DIR`.
   - If no `gradlew` is found after walking to the filesystem root, ask the user: *"I can't find a Gradle wrapper above `<CLASS_FILE>`. Please provide the service root path."*

4. **Resolve `GRADLEW`.**
   - `GRADLEW=./gradlew`
   - Use `<GRADLEW>` in every subsequent Bash command that invokes the Gradle wrapper.

5. **Skip Steps 1, 2, and 3.** Go directly to Step 4.

---

## Step 1: Locate the Service

Resolve the service directory from the argument provided by the user (e.g. `amenity-service` or a full path).

1. If the argument contains any path separator (`/` or `\`), treat it as a path — this covers:
   - Unix absolute paths (e.g. `/home/.../amenity-service`)
   - Home-relative paths (e.g. `~/.../amenity-service`)
   - Relative paths (e.g. `../amenity-service`)

   Use the argument directly as `SERVICE_DIR` — skip the Glob search. Resolve `~` to the user's home directory and convert the path to absolute if it is relative.

2. Otherwise, treat it as a service name:
   - Normalize it: replace spaces with hyphens (e.g. `amenity service` → `amenity-service`)
   - `Glob` for `**/<service-name>/gradlew`.
   - If neither is found, ask the user: *"I can't find a directory named `<service-name>` with a Gradle wrapper. Please provide the full path."*
3. Record `SERVICE_DIR` as the absolute path to the service root.
4. **Resolve `GRADLEW`.**
   - `GRADLEW=./gradlew`
   - Use `<GRADLEW>` in every subsequent Bash command that invokes the Gradle wrapper.

---

## Step 2: Generate the Coverage Report

Run tests and produce the JaCoCo report:

```bash
cd <SERVICE_DIR> && <GRADLEW> test jacocoTestReport 2>&1
```

- If the build fails due to compilation errors, stop and report the errors — do not proceed to report parsing.
- If the build fails due to test failures: by default Gradle stops before running `jacocoTestReport`, so the XML/HTML report will not be produced. In this case:
  1. Report which tests failed.
  2. Check whether the project has `test.finalizedBy(jacocoTestReport)` configured in its `build.gradle` — if so, a partial report may still exist; proceed to check.
  3. If no report is found, inform the user: *"Some tests are failing and no coverage report was produced. Please fix the failing tests first, then re-run the skill."* Do not attempt to generate tests on top of a broken test suite.
- After the run, check which report artifacts were actually produced:
  - XML: `<SERVICE_DIR>/build/reports/jacoco/test/jacocoTestReport.xml`
  - HTML: `<SERVICE_DIR>/build/reports/jacoco/test/html/index.html`

Report only what exists, for example:
> **Coverage report generated.** XML: `build/reports/jacoco/test/jacocoTestReport.xml` · HTML: `build/reports/jacoco/test/html/index.html`

Or, if only the XML was produced:
> **Coverage report generated.** XML: `build/reports/jacoco/test/jacocoTestReport.xml` (no HTML report found)

Or, if neither exists after a successful build, stop and inform the user that no report was produced and ask them to verify the JaCoCo plugin configuration.

---

## Step 3: Parse the Report and Identify Under-Covered Classes

### If XML report exists

Run the following `Bash` command to extract class-level LINE coverage for **all classes** in the report. It uses `iterparse` to stream the XML element by element, keeping memory usage low even on large reports:

```bash
python3 - <<'EOF'
import xml.etree.ElementTree as ET
path = '<SERVICE_DIR>/build/reports/jacoco/test/jacocoTestReport.xml'
for event, elem in ET.iterparse(path, events=('end',)):
    if elem.tag == 'class':
        name = elem.get('name', '')
        lc = lm = bc = bm = 0
        for counter in elem.findall('counter'):   # direct children only — skips method-level counters
            t = counter.get('type')
            if t == 'LINE':
                lc, lm = int(counter.get('covered', 0)), int(counter.get('missed', 0))
            elif t == 'BRANCH':
                bc, bm = int(counter.get('covered', 0)), int(counter.get('missed', 0))
        lt, bt = lc + lm, bc + bm
        pct  = (lc / lt * 100) if lt > 0 else 100
        bpct = (bc / bt * 100) if bt > 0 else 100
        print(f'{name},{lc},{lm},{pct},{bpct}')
        elem.clear()
EOF
```

This outputs one line per class: `class/path/Name,covered,missed,line_pct,branch_pct`.

The coverage values are unrounded floats — use them as-is for the `< 80%` filtering comparison. Only round to one decimal place when displaying in the table.

If `python3` is not available, retry the identical script substituting the interpreter — try these aliases in order before giving up on Python:

1. `python` — **only if it resolves to Python 3**. Verify first with `python --version`; if the output shows Python 2.x, skip this alias entirely.
2. `py` (Windows Python launcher — launches Python 3 by default when Python 3 is installed)

Replace `python3 - <<'EOF'` with `python - <<'EOF'` or `py - <<'EOF'` respectively. The script body is unchanged. The script requires Python 3.6+ (f-strings); it is not compatible with Python 2.

If no Python interpreter is available, fall back to `awk`, which can track XML nesting state and correctly ignores method-level counters:

```bash
awk '
/<method[ >]/{depth++}
/<\/method>/ {if(depth>0)depth--}
/<class /    {match($0,/name="([^"]+)"/,a); cls=a[1]}
/<counter /  && !depth && cls {
  match($0,/type="([^"]+)"/,t)
  match($0,/covered="([0-9]+)"/,c)
  match($0,/missed="([0-9]+)"/,m)
  counters[t[1]]=c[1]+0 SUBSEP m[1]+0
}
/<\/class>/  && cls {
  split(counters["LINE"],  l, SUBSEP); lt=l[1]+l[2]
  split(counters["BRANCH"],b, SUBSEP); bt=b[1]+b[2]
  lp = lt>0 ? (l[1]/lt*100) : 100
  bp = bt>0 ? (b[1]/bt*100) : 100
  printf "%s,%s,%s,%.6f,%.6f\n", cls, l[1], l[2], lp, bp
  cls=""; delete counters
}
' <SERVICE_DIR>/build/reports/jacoco/test/jacocoTestReport.xml
```

This produces the same `class/path/Name,covered,missed,line_pct,branch_pct` output as the Python script and is safe to use as a fallback.

### If only HTML report exists

Read `build/reports/jacoco/test/html/index.html` to get the full list of package links.

Then loop through **every** package page — not just low-coverage ones — to collect per-class coverage for all classes:

```
For each package link found in index.html:
  Read build/reports/jacoco/test/html/<package-name>/index.html
  Extract each class row: class name, line coverage %, branch coverage %
```

Continue until all package pages have been read. Do not stop early — skipping packages would produce an incomplete picture and an incorrect BEFORE_OVERALL baseline.

### Baseline

Before filtering, compute and record the **overall service line coverage** from the report (sum of all `covered` and `missed` LINE counters across all classes):

```
BEFORE_OVERALL = total_covered / (total_covered + total_missed) * 100
```

This value is used in Step 7 to show the overall improvement. Store it now — it must reflect the state before any new tests are written.

### Filtering

Collect all classes where **line coverage < 80%**, excluding:
- Classes in packages matching `**/domain/**`, `**/config/**`, `**/client/**`, `**/batch/**`
- Classes whose name ends with `Application`, `Configuration`, `Properties`

Also record the **before coverage %** for each class shown in the table — these are used in the Step 7 comparison.

Present the findings as a table and ask the user which classes to write tests for:

```
Classes below 80% line coverage:

| Class | Package | Line Cov. | Branch Cov. |
|-------|---------|-----------|-------------|
| AmenityService | com.maxxton.amenity.amenity | 31% | 24% |
| LinkService    | com.maxxton.amenity.link   | 27% | 14% |
...

Which classes should I write tests for? (Enter numbers, e.g. "1 3 5", or "all")
```

Wait for user confirmation before proceeding.

---

## Step 4: Establish Test Conventions (Once, Before Writing Any Tests)

Before touching any individual class, scan the entire test folder of the service to build a single, consistent picture of how tests are written. This is done **once** and the conventions discovered here are applied to every class in Step 5.

### 4a. Scan the Test Directory

Use `Glob` to list all `**/*Test.java` files under `<SERVICE_DIR>/src/test/java/`.

- If **10 or more** test files are found: read a representative sample — pick 2–3 files from different packages (e.g. one from a `*service*` package, one from a `*manager*` package, one from elsewhere). Prefer files that are larger/more complete.
- If **1–9** test files are found: read all of them.
- If **no test files are found at all**: the service has no test conventions to follow — see Step 4b below.

From the files read, extract and record the following as the **project test conventions**:

| Convention | What to look for |
|---|---|
| Test runner / extension | `@ExtendWith(MockitoExtension.class)`, `@SpringBootTest`, `@RunWith(...)` |
| Mock declaration style | `@Mock`, `@MockBean`, `Mockito.mock(...)` |
| Subject instantiation | `@InjectMocks`, `new ClassName(mocks...)`, `@Autowired` |
| Mock stubbing style | `when(...).thenReturn(...)`, `given(...).willReturn(...)`, `doReturn(...).when(...)` |
| Assertion library | JUnit 5 `assertEquals` / `assertThrows`, AssertJ `assertThat`, Hamcrest `assertThat` |
| Test method naming | e.g. `shouldDoXWhenY()`, `test_doX_givenY()`, `doX_returnsY_whenZ()` |
| `@BeforeEach` setup pattern | What is initialised in `setUp()` vs inline in each test |
| Exception testing | `assertThrows(...)`, `@Test(expected=...)`, `try/catch` + `fail()` |

Also scan for `**/*TestObjects.java` files and read 1–2 of them to understand:
- Whether test objects use static factory methods, inner builder classes, or plain constants
- Naming conventions for factory methods (e.g. `aValidAmenity()`, `createAmenity(...)`, `DEFAULT_AMENITY`)

### 4b. Fallback — No Tests Exist in This Service

If **no test files were found** in Step 4a:

Ask the user:
```
No existing tests found in <service-name>. I need a reference service to copy test conventions from.

Which service should I use as a reference? (e.g. capacity-service, amenity-service)
Enter the service name, or press Enter to skip and I will apply standard JUnit 5 + Mockito conventions.
```

If the user names a reference service:
1. Use `Glob` to locate `<REFERENCE_SERVICE_DIR>/src/test/java/`
2. Read 2–3 `*Test.java` files and 1–2 `*TestObjects.java` files from the reference service
3. Extract the same conventions table from Step 4a using those files
4. Record that conventions were sourced from `<reference-service-name>` — mention this when proposing tests in Step 5a

If the user skips: apply standard conventions (JUnit 5 + `@ExtendWith(MockitoExtension.class)` + Mockito `when/thenReturn` + AssertJ `assertThat`).

---

## Step 5 Pre-work: For Each Selected Class — Gather Class-Specific Context

For each class the user selected, gather the following before writing tests. The conventions from Step 4 already apply — this step collects class-specific details only.

### 5a. Locate the Source File

**If `CLASS_FILE` was already resolved in Step 0** (class mode where the argument was a `.java` path or a `ClassName`/`ClassName.method` that was resolved via Glob in Step 0): use `CLASS_FILE` directly — do not re-run the Glob.

**Otherwise** (service mode): use `Glob` to find `**/<ClassName>.java` under `<SERVICE_DIR>/src/main/java/`. If multiple matches are found, list them and ask the user which one to use.

Read the entire source file. Identify:
- All public and package-private methods
- Constructor(s)
- Fields and their types (dependencies to mock)
- Any annotations (`@Service`, `@Component`, `@Transactional`, etc.)

### 5b. Locate the Existing Test File

Use `Glob` to find `**/<ClassName>Test.java` under `<SERVICE_DIR>/src/test/java/`.

- If it exists: read it fully. Note which methods are already tested so Step 5d can identify gaps. Verify it follows the same conventions from Step 4 — if it diverges, follow this file's patterns for this class specifically (don't mix styles within a file).
- If it does not exist: a new file will be created in Step 6c using the conventions established in Step 4.

### 5c. Locate the Test Objects File

Use `Glob` to find `**/<ClassName>TestObjects.java` under `<SERVICE_DIR>/src/test/java/`.

- If it exists: read it fully to understand available test data.
- If it does not exist: check for any `*TestObjects.java` in the same test package that may be reusable. Note whether new objects will be needed.

### 5d. Identify Uncovered Methods

**If `TARGET_METHOD` is set (class mode with a specific method):**
- Focus only on that method. Read its body in full and note every branch, loop, and exception path.
- Check whether `<ClassName>Test.java` already has test methods that exercise it.
- List the branches/paths within `TARGET_METHOD` that are not yet covered by existing tests. These are the scenarios to write tests for.
- Skip any analysis of other methods in the class.

**Otherwise:**
Compare methods in `<ClassName>.java` against test methods in `<ClassName>Test.java`, and correlate this with the JaCoCo report.

A method is considered **uncovered** if:
- The JaCoCo report shows uncovered lines within its body.

If JaCoCo coverage data for the class or method is unavailable or clearly incomplete, then as a fallback consider a method **likely under-tested** if no test method appears to exercise it (based on direct or clearly visible indirect calls). Treat this as a heuristic and prioritize JaCoCo data wherever possible.

List the uncovered (and, where applicable, likely under-tested) methods explicitly before writing any tests.
---

## Step 6: Write the Missing Unit Tests

For each uncovered method identified in Step 5d, write tests following these rules:

### Rules

1. **Follow established conventions** — use the conventions recorded in Step 4. If the class already has a `<ClassName>Test.java`, follow that file's style specifically (it takes precedence over the general conventions for that class).
2. **Cover all code paths** — every `if/else` branch, every loop iteration (empty, one element, multiple), every `catch` block, every early `return`.
3. **One scenario per test method** — do not combine multiple branches in one test.
4. **Use existing test objects** — reuse objects from `<ClassName>TestObjects.java` wherever they fit. Only create new ones when existing objects do not cover the scenario.
5. **Do not modify or duplicate existing tests** — only add new test methods.
6. **New test objects** — if new test data is needed, add static factory methods or constants to `<ClassName>TestObjects.java` following existing patterns. If the file does not exist, create it.
7. **All tests must pass** — run each batch of new tests before moving to the next class.

### Java Test Guardrails (Non-Negotiable)

These rules apply to every Java test written by this skill, regardless of what the existing test files do:

**Visibility — never use reflection:**
- Test classes live in the same package as the class under test, so `protected` and package-private methods are directly callable — no `getDeclaredMethod` / `setAccessible` / `invoke` ever.
- If a method is `private`, test it through a `public` or `protected` caller. If you cannot, consider whether the method should be extracted or its visibility promoted — do not reach for reflection.

**Argument matchers — null safety:**
- `any(Type.class)` does **not** match `null`. When an argument may be `null` at the call site (e.g. a `Specification`, an optional `String`, a nullable domain object), use `(Type) any()` (zero-arg) or `nullable(Type.class)` instead.
- This applies especially to repository calls: `when(repo.findAll((Specification) any(), any(Pageable.class)))`.

**Spy stubbing order:**
- Always use `doReturn(value).when(spy).method(args)` — never `when(spy.method(args)).thenReturn(value)`. The `when(spy.method(...))` form invokes the real method before the stub is registered.

**Assertions — assert values, not just shape:**
- Assert exact content, not just size: `assertEquals(List.of("Mon"), result)` not `assertEquals(1, result.size())`.
- Trim before comparing strings that may carry insignificant whitespace: `assertEquals("expected", actual.trim())`.

**Constructor-created fields:**
- Fields the class initialises itself (e.g. `this.gson = new GsonBuilder().create()`) are not injectable by Mockito — do not add a `@Mock` for them. Mockito leaves them as-is; the real instance is used automatically in your tests.

**Framework-injected fields Mockito skips:**
- Some annotations — such as `@PersistenceContext`, `@Value`, or other container-specific injection markers — are not processed by Mockito. Before writing a test, read the class under test and check whether any field uses such an annotation. If it does, assign the mock manually in `@BeforeEach`; do not assume `@InjectMocks` covers all fields.

**Strict stubbing:**
- `MockitoExtension` uses strict stubbing by default. A stub that is set up but never triggered causes `UnnecessaryStubbingException` — including stubs declared in `@BeforeEach`. Only place stubs in `@BeforeEach` when every test in the class will trigger them. Place stubs needed by only some tests inside those test methods. Use `lenient().when(...)` for a stub that must be shared but will not be triggered by every test.

---

### Writing Process (per class)

#### 6a. Propose the tests

Present a numbered list of the test methods you plan to write, with a one-line description of what each covers. Mention which convention source is being followed (current service or reference service). Wait for user approval before writing.

#### 6b. Write test objects (if needed)

If new test data is required:
- If `<ClassName>TestObjects.java` exists: use `Edit` to add the new methods/constants following the same style found in that file.
- If it does not exist: use `Write` to create the file, modelling it exactly on the `*TestObjects.java` pattern established in Step 4.

#### 6c. Write the test methods

- If `<ClassName>Test.java` exists: use `Edit` to append the new test methods inside the existing test class (before the final closing brace).
- If it does not exist: use `Write` to create the full test class — apply the class structure (annotations, imports, mock declarations, `setUp`) from the conventions established in Step 4, then add the new methods.

#### 6d. Run the new tests

```bash
cd <SERVICE_DIR> && <GRADLEW> test --tests "<fully.qualified.ClassNameTest>" 2>&1
```

- If all pass: confirm and move to the next class.
- If any fail: diagnose the failure, fix the test (not the source), and re-run. Do not move on until green.

---

## Step 7: Final Coverage Report

**If in service mode:** regenerate the full report and show before/after for all classes that were worked on:

```bash
cd <SERVICE_DIR> && <GRADLEW> test jacocoTestReport 2>&1
```

Parse the updated report using the same Python script from Step 3 and present:

```
Coverage improvement for <service-name>:

| Class | Before | After |
|-------|--------|-------|
| AmenityService | 31% | 78% |
| LinkService    | 27% | 65% |

Overall line coverage: 38% → 56%
```

**If in class mode:** after the tests pass in Step 6d, run a targeted coverage report for the class only:

```bash
cd <SERVICE_DIR> && <GRADLEW> test --tests "<fully.qualified.ClassNameTest>" jacocoTestReport 2>&1
```

Parse the XML report and filter to the specific class. Report **class-level** line and branch coverage. Because Steps 2–3 are skipped in class mode there is no BEFORE baseline — report the after-only coverage and note that no baseline was recorded:

```
Coverage for <ClassName> (after):

| Metric | After |
|--------|-------|
| Line coverage   | 85% |
| Branch coverage | 72% |

No before baseline — Steps 2–3 were skipped in class mode.
```

---

## Notes

- **Do not touch source files** — only test files and test object files are modified.
- **Domain/config classes** are excluded from coverage targets by default; skip them unless the user explicitly requests otherwise.
- **If a class is untestable** (e.g. pure Spring configuration, Feign client interface) — note it and skip rather than writing trivial tests.
- **Mocking external dependencies** — always mock repository calls, Feign clients, and other service calls. Never make real database or HTTP calls in unit tests.

## Examples

User says: "/measuring-test-coverage"
Claude runs the JaCoCo coverage report for the specified module and identifies uncovered code paths.

## Troubleshooting

- **Report not generated**: run `./gradlew jacocoTestReport` manually first to verify the setup.
- **Low coverage for unexpected classes**: check that test source sets are correctly configured.
