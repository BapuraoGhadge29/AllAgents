---
name: auditing-dependencies
description: Audit and fix Gradle/npm/pip/Go dependencies in a GitHub repository — checks for outdated versions, CVEs, license risks, and transitive vulnerabilities, then opens a PR with upgrades. Use '/auditing-dependencies' when auditing dependencies for outdated versions, CVEs, or license risks.
disable-model-invocation: true
argument-hint: "[owner/repo]"
allowed-tools:
- AskUserQuestion
- WebSearch
- Agent
- mcp__claude_ai_GitHub__get_file_contents
- mcp__claude_ai_GitHub__search_code
- mcp__claude_ai_GitHub__create_branch
- mcp__claude_ai_GitHub__create_or_update_file
- mcp__claude_ai_GitHub__create_pull_request
- mcp__claude_ai_GitHub__list_branches
- mcp__claude_ai_Context7__resolve-library-id
- mcp__claude_ai_Context7__query-docs
---

# Dependency Audit and Fix

Reads all build files in a GitHub repository, audits every dependency for
outdated versions, known CVEs, license compliance risks, and transitive
dependency vulnerabilities — then upgrades them and opens a pull request.

Use this skill to improve your [Sigrid Open Source Health](https://sigrid-says.com)
score — for example, if Sigrid flags a service for outdated, vulnerable, or
non-compliant dependencies, run `/dependency-audit <owner/repo>` to
automatically audit and fix them.

## Supported Build Systems

| Build system | Files scanned | Lockfiles parsed |
|---|---|---|
| Gradle (JVM) | `build.gradle`, `build.gradle.kts`, `gradle.properties` | `gradle/dependency-locks/*.lockfile` |
| npm / yarn | `package.json` | `package-lock.json`, `yarn.lock` |
| pip / Poetry | `requirements.txt`, `pyproject.toml` | `poetry.lock` |
| Go modules | `go.mod` | `go.sum` |

## Required Connectors

- **GitHub MCP** — bundled with the `developer` plugin. No separate setup
  needed. Used for reading files, creating branches, committing changes, and
  opening PRs.
- **Context7 MCP** (optional) — secondary fallback for breaking-change docs
  when WebSearch results are insufficient.

---

## Workflow

### Stage 1: Parse the Argument and Verify Access

Extract `owner` and `repo` from the argument (e.g. `MaxxtonGroup/capacity-service`).

Use `list_branches` to confirm the repo exists and is accessible. If the call
fails or returns no results, stop and tell the user.

**Record the branch list** — you will reuse it in Stage 7a to determine the
base branch without making a second API call.

---

### Stage 2: Discover All Dependency and Lockfiles

Use `search_code` to find every dependency file and lockfile in the repo.

**Dependency files:**
```
filename:build.gradle repo:<owner>/<repo>
filename:build.gradle.kts repo:<owner>/<repo>
filename:gradle.properties repo:<owner>/<repo>
filename:package.json repo:<owner>/<repo>
filename:requirements.txt repo:<owner>/<repo>
filename:pyproject.toml repo:<owner>/<repo>
filename:go.mod repo:<owner>/<repo>
```

**Lockfiles (for transitive dep analysis in Stage 4f):**
```
filename:package-lock.json repo:<owner>/<repo>
filename:yarn.lock repo:<owner>/<repo>
filename:poetry.lock repo:<owner>/<repo>
filename:go.sum repo:<owner>/<repo>
path:gradle/dependency-locks repo:<owner>/<repo>
```

For multi-module Gradle projects, there will be multiple `build.gradle` files
(root + submodules). Fetch all of them with `get_file_contents`.

⚡ **Parallelize**: fetch all discovered files in a single turn.

---

### Stage 3: Extract All Dependencies

Parse each dependency file and build a flat list of all **direct** dependencies
with:

- Package identifier (e.g. `groupId:artifactId` for Gradle, `name` for npm/pip)
- Current declared version (or `managed` if version comes from a BOM/platform)
- Scope / dev-dependency flag
- Which file it lives in
- The **`sha`** returned by `get_file_contents` for that file — record this,
  you will need it when committing updates in Stage 6
- Build system (Gradle / npm / pip / Go)

Also parse any lockfiles found to extract the **transitive dependency tree** —
a flat list of all resolved transitive deps with their pinned versions. You will
use this in Stage 4f.

**Gradle specifics:**
- Version values are often declared in `gradle.properties` as variables — track
  which property key controls each dependency's version, and which other
  dependencies share that same variable.
- Handle BOM/platform imports: upgrading the BOM version is often the right fix
  rather than overriding individual managed versions.
- Skip version-less managed deps unless there's a reason to pin them.
- If `gradle/dependency-locks/` lockfiles are present, parse them to get the
  full resolved tree including transitive deps.

**npm specifics:**
- Separate `dependencies` from `devDependencies`.
- Ignore `peerDependencies` and `optionalDependencies` unless explicitly asked.
- If `package-lock.json` or `yarn.lock` is present, parse it for the full
  resolved dep tree including transitive deps.

---

### Stage 4: Audit Every Dependency

⚡ **Parallelize**: Dispatch one Agent per **direct** dependency (batch in
groups of 5). Each agent receives the package identifier, build system, and
current version and runs steps 4a–4e. Run step 4f separately after all
batches complete.

#### 4a. Latest Stable Version

Use **WebSearch** as the primary source:

| Build system | Search query |
|---|---|
| Gradle (JVM) | `{groupId} {artifactId} latest version site:search.maven.org` |
| npm | `{package} latest stable version site:npmjs.com` |
| pip | `{package} latest version site:pypi.org` |
| Go | `{module} latest release site:pkg.go.dev` |

If WebSearch returns insufficient results, use Context7 as secondary fallback:
`resolve-library-id` + `query-docs` with query "latest stable version".

Identify:
- **Current**: within the last minor release — no action needed
- **Patch behind**: safe to upgrade (e.g. `3.2.1` → `3.2.4`)
- **Minor behind**: upgrade with breaking-change check (see 4b)
- **Major behind**: upgrade only after breaking-change analysis (see 4b)
- **EOL / archived**: flag prominently, suggest replacement if known

#### 4b. Breaking Change Check (for minor and major bumps)

First, search via WebSearch:
```
{library} {current_version} to {latest_version} breaking changes migration guide
```

If results are insufficient, use Context7 as fallback:
1. `resolve-library-id`: libraryName="{artifactId}", query="migration breaking changes"
2. `query-docs`: query="breaking changes migration guide {current_version} to {latest_version}"

Classify the upgrade as:
- **Safe**: no breaking changes, drop-in replacement
- **Needs attention**: deprecations or API changes but non-breaking
- **Breaking**: requires code changes alongside the version bump

For **breaking upgrades**: do NOT auto-fix. Flag them in the audit report and
ask the user: "This upgrade requires code changes — skip it for now, include it
with a task comment, or handle it manually?"

#### 4c. CVE Check

Search for known vulnerabilities via WebSearch:
```
{package} {current_version} CVE security vulnerability
```
```
site:nvd.nist.gov {package} {current_version}
```

If a CVE exists in the current version AND the latest version is not affected,
mark this as **CRITICAL** and surface it prominently in the audit report. A
CVE fix that involves only a patch or minor bump is applied automatically. A
CVE fix that requires a **major (breaking) bump** still requires explicit user
confirmation before applying — present it clearly and ask the user whether to
proceed despite the breaking changes (see Rule #1 and Rule #5).

**Never invent CVE IDs** — only report CVEs found via search with a source URL
that confirms both the package name and the CVE ID.

#### 4d. Usage Check (non-test, non-devDependency only)

For compile/runtime-scoped Gradle deps or non-dev npm/pip deps, verify the
library is actually used in source code.

**Gradle (JVM) — search by full groupId as import prefix:**

Use the complete `groupId` (not a truncated prefix) to search for import
statements. This keeps the search specific to the exact artifact group:

```
import {groupId} language:Java repo:<owner>/<repo>
# e.g. groupId "com.fasterxml.jackson.core" → search: import com.fasterxml.jackson.core
# e.g. groupId "org.springframework.boot"   → search: import org.springframework.boot
```

**npm — search by require/import:**
```
"{package-name}" language:JavaScript repo:<owner>/<repo>
```

**pip — search by import name:**
```
import {package} language:Python repo:<owner>/<repo>
```

If no usage is found, flag as **potentially unused dependency** and ask the
user whether to remove it (see Stage 5 confirmation and Rule #2).

#### 4e. License Compliance Check

For every direct dependency, determine its SPDX license identifier via
WebSearch:
```
{groupId} {artifactId} license SPDX site:search.maven.org
{groupId} {artifactId} pom.xml license
```

Classify the license into one of three tiers:

| Tier | Licenses | Action |
|---|---|---|
| **Safe** | Apache-2.0, MIT, BSD-2-Clause, BSD-3-Clause, EPL-2.0, CDDL-1.0, ISC | No action needed |
| **REVIEW** | LGPL-2.1, LGPL-3.0, MPL-2.0, EUPL-1.2 | Copyleft with limited scope — flag for legal awareness, do not block |
| **RISK** | GPL-2.0, GPL-3.0, AGPL-3.0, SSPL-1.0, Elastic-2.0, BUSL-1.1, CC-BY-SA | Strong copyleft or commercial-use restriction — flag as blocker, do not auto-upgrade to a version that introduces this license |
| **Unknown** | Could not determine | Flag for manual check |

**Key rule:** If upgrading a dependency changes its license from Safe/REVIEW to
RISK, do **not** include that upgrade in the safe-upgrades list. Surface it
separately and require explicit user confirmation.

#### 4f. Transitive Dependency CVE Check

Run this step once, after all direct-dependency batches complete.

**If lockfiles were found (Stage 2/3):**

Parse the resolved transitive dependency tree. Focus on the highest-risk
transitive deps — prioritize well-known CVE targets:
- JVM: `log4j-core`, `logback-classic`, `jackson-databind`, `commons-text`,
  `snakeyaml`, `spring-core`, `netty-*`, `h2`
- npm: `lodash`, `minimist`, `axios`, `follow-redirects`, `semver`, `tough-cookie`
- pip: `Pillow`, `cryptography`, `urllib3`, `requests`, `paramiko`

For each high-risk transitive dep found in the lockfile, run a CVE check via
WebSearch (same as step 4c). If a CVE is found:
- Identify which **direct** dependency pulls it in
- Check if upgrading that direct dep (to the version found in 4a) resolves the
  transitive CVE
- If yes: add this as extra justification for the direct dep upgrade
- If no: flag as a transitive CVE that requires manual resolution and note the
  pull-through chain (e.g. `your-dep → vulnerable-transitive:version`)

**If no lockfiles were found:**

Note in the audit report:
> "Transitive dependencies could not be fully audited — no lockfiles found.
> Upgrading BOMs and direct deps (above) will pull in safer transitive versions.
> To enable full transitive auditing in future runs, add Gradle dependency
> locking (`gradle dependencies --write-locks`) or commit your `package-lock.json`."

---

### Stage 5: Present Audit Report and Confirm

Before making any changes, present the full audit to the user:

```
## Dependency Audit: <owner>/<repo>

### Summary
- X direct dependencies audited
- X transitive deps checked (from lockfiles) / lockfiles not found
- X safe upgrades ready
- X breaking upgrades (skipped — need manual review)
- X CVEs found (direct)
- X CVEs found (transitive)
- X license risks
- X potentially unused dependencies

### CRITICAL — CVEs in Direct Dependencies
- `group:artifact` 1.2.3 → 2.0.0
  CVE-2024-XXXX (CVSS 9.1) — [description] (source: <url>)

### CRITICAL — CVEs in Transitive Dependencies
- `transitive:dep` 1.0.0 — pulled in by `direct:dep`
  CVE-2024-YYYY (CVSS 8.5) — upgrade `direct:dep` to X.Y.Z to resolve

### License Risks
- `group:artifact` — AGPL-3.0 (RISK: commercial-use restriction)
- `group:artifact` — LGPL-3.0 (REVIEW: copyleft, check linking model)

### Upgrades Ready (safe, no breaking changes)
- `group:artifact` 1.2.3 → 1.2.8
- ...

### Breaking Upgrades (skipped)
- `group:artifact` 1.x → 2.0 — requires migration

### Potentially Unused Dependencies
- `group:artifact` — no usage found in source code
```

Use `AskUserQuestion` to confirm before proceeding:
- "Apply all safe upgrades, remove confirmed-unused deps, and open a PR?"
- "Apply safe upgrades only (keep unused deps)"
- "Apply only CVE fixes"
- "Cancel"

For each **potentially unused** dependency listed, ask the user explicitly:
"Remove `group:artifact`? (yes / no / not sure)"

Wait for the user's full answer before continuing.

---

### Stage 6: Apply the Fixes

Based on the user's choice, update all applicable build files with the new
versions and apply any confirmed removals.

**For each file that needs changes:**
1. Start from the full file content fetched in Stage 2
2. Apply all version substitutions (replace old version string with new)
3. Remove any dependencies the user confirmed as unused
4. Preserve formatting, comments, and indentation exactly
5. For Gradle BOM upgrades: update the BOM version, not individual managed deps
6. For `gradle.properties`: update the version variable there, not inline in
   build files

**Shared `gradle.properties` variables:**

If multiple dependencies share a single version variable (e.g. `jacksonVersion`
controls `jackson-core`, `jackson-databind`, and `jackson-annotations`), treat
the variable as one logical unit. Before changing it, confirm with the user:
"Updating `jacksonVersion` will also affect: `jackson-core`, `jackson-annotations`.
Proceed?" Note all affected artifacts in the PR body.

**Committing files:**

When calling `create_or_update_file` for an existing file, pass the latest
known `sha` for that file path (as recorded in Stage 3, or from a more recent
read of that file). The `sha` is per-path and only changes when that specific
file changes. Re-fetch the `sha` only if you are re-updating the same file
after another change (or after a failed update due to a SHA mismatch).

For multi-module Gradle projects: if the version is declared in the root
`build.gradle` or `gradle.properties`, update it there. Do not duplicate
version declarations in submodule build files.

---

### Stage 7: Create Branch and Commit

**7a. Determine the base branch:**

Use the branch list recorded in Stage 1. Check in this order:
1. `develop` — Maxxton's standard base branch; use if present
2. `main` — use if present and `develop` is absent
3. `master` — use if present and neither `develop` nor `main` exist
4. None of the above — ask the user: "Which branch should be used as the base
   for the fix PR?" and wait for their answer before continuing.

**7b. Create the branch:**

Branch name format: `fix/dependency-audit-{YYYY-MM-DD}`

Use `create_branch` from the base branch determined in 7a.

**7c. Commit each changed file:**

⚡ **Parallelize**: commit all changed files in parallel using
`create_or_update_file` on the new branch (see SHA note in Stage 6).

Commit message: `fix(deps): upgrade outdated dependencies`

For each file commit, include a summary in the commit message of which
deps were changed, e.g.:
```
fix(deps): upgrade outdated dependencies

- spring-boot-dependencies: 3.1.0 → 3.3.4
- jackson-databind: 2.14.0 → 2.17.2 (CVE-2024-XXXX)
- lombok: 1.18.26 → 1.18.34 (resolves transitive CVE-2024-YYYY in snakeyaml)
- unused-lib: removed (no usage found in source)
```

---

### Stage 8: Open the Pull Request

Use `create_pull_request` with:
- **Title**: `fix(deps): upgrade outdated dependencies`
- **Base**: the base branch from Stage 7a (`develop` / `main`)
- **Head**: the branch created in Stage 7b
- **Body**: the full audit report from Stage 5 + a note that CI will validate
  the changes compile and tests pass

**PR body structure:**
```markdown
## Dependency Upgrades

Automated dependency audit and upgrade for `<owner>/<repo>`.

### Changes
| Dependency | From | To | Reason |
|---|---|---|---|
| spring-boot-dependencies | 3.1.0 | 3.3.4 | Outdated + CVE-2024-XXXX |
| jackson-databind | 2.14.0 | 2.17.2 | CVE-2024-XXXXX + transitive CVE-2024-YYYY |
| lombok | 1.18.26 | 1.18.34 | Outdated |
| unused-lib | removed | — | No usage found in source code |

### Skipped (breaking upgrades — manual action needed)
| Dependency | Current | Latest | Reason |
|---|---|---|---|
| hibernate-core | 5.6.x | 6.4.x | Major API changes |

### License Risks (not changed — review manually)
| Dependency | License | Risk |
|---|---|---|
| some-artifact | AGPL-3.0 | Commercial-use restriction — legal review required |

### Transitive CVEs (could not auto-fix)
| Transitive Dep | Version | CVE | Pulled in by |
|---|---|---|---|
| snakeyaml | 1.30 | CVE-2022-1471 | spring-boot-dependencies (upgrade resolves) |

### Lockfile Notice
> No lockfiles found — transitive deps not fully audited.
> Recommend adding `gradle dependencies --write-locks` to enable full auditing.

CI will run on this PR to validate compilation and tests.
```

---

### Stage 9: Report Back

After the PR is created, tell the user:
- PR URL
- How many deps were upgraded
- Which CVEs are now resolved (direct and transitive)
- Which license risks were found
- Which breaking upgrades were skipped and why
- Whether transitive deps were fully audited or estimated
- Next steps: review PR, check CI, handle skipped breaking upgrades, address
  license risks, add lockfiles for full transitive coverage

---

## Rules

1. **Never upgrade a breaking dep without explicit user approval** — safe
   upgrades only by default
2. **Never remove a dep without explicit user confirmation** — flag unused deps
   and ask; only remove what the user approves
3. **Preserve file formatting exactly** — don't reformat or reorder build files
4. **One PR per repo** — all fixes in one PR, not one per dependency
5. **CVEs always require surfacing prominently** — if a CVE fix involves a
   breaking (major) bump, ask the user explicitly before applying
6. **Do not invent CVE IDs or latest versions** — only report what search
   returns with a source URL
7. **Use WebSearch as the primary source** — Context7 is a quota-limited
   fallback for when WebSearch results are insufficient
8. **Never auto-approve a RISK-tier license change** — if an upgrade introduces
   a GPL/AGPL/SSPL/BUSL license, surface it and require explicit user
   confirmation before including it in the PR

## Instructions

Invoke with "/auditing-dependencies" in Claude Code. The skill guides you through the workflow step by step.

## Examples

User says: "/auditing-dependencies"
Claude scans all build files, checks for outdated dependencies, CVE vulnerabilities, and produces a prioritised upgrade report.

## Troubleshooting

- **CVE search times out**: retry; NVD can be slow. If it keeps failing, note the dependency as unverified.
- **Build file not found**: verify the repo root contains a `build.gradle` or `pom.xml`.
