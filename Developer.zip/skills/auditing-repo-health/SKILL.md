---
name: auditing-repo-health
description: Analyze git history for codebase health signals — file churn, bus factor, bug hotspots, and firefighting frequency in the current repository. Use '/auditing-repo-health' when analyzing repository health, churn, or bus factor from git history.
argument-hint: "[time-window, e.g. '3m', '1y' — default 6 months]"
allowed-tools:
- Bash
disable-model-invocation: true
---

# Repository Health

Analyzes git history to produce a narrative health report — highlighting file churn, knowledge silos (bus factor), bug-prone code, and firefighting frequency. Inspired by the principle of reading git history before reading code.

## Parameters

| Parameter | Default | Description |
|-----------|---------|-------------|
| _(positional)_ | `6m` | Time window: `Nm` (months), `Nw` (weeks), `Ny` (years), or a raw `--since` value like `[YYYY-MM-DD]` |

---

## Step 1: Parse Time Window & Validate

**Parse the argument** into a `--since` value:

- No argument → `--since="6 months ago"`
- `Nm` (e.g. `3m`) → `--since="3 months ago"`
- `Nw` (e.g. `2w`) → `--since="2 weeks ago"`
- `Ny` (e.g. `1y`) → `--since="1 year ago"`
- ISO date (e.g. `[YYYY-MM-DD]`) → `--since="[YYYY-MM-DD]"`
- Anything else → reject with: "Unsupported time window format. Use Nm/Nw/Ny (e.g. 3m, 2w, 1y) or an ISO date (YYYY-MM-DD)."

Store the resolved value as `SINCE` for all subsequent commands.

**Validate this is a git repo:**

```bash
git rev-parse --is-inside-work-tree
```

If this fails, stop with: *"This directory is not inside a git repository. Run this skill from within a git repo."*

**Count commits in the window and get repo name:**

```bash
REPO_NAME=$(basename "$(git rev-parse --show-toplevel)")
COMMIT_COUNT=$(git rev-list --count --since="SINCE" HEAD)
echo "$REPO_NAME — $COMMIT_COUNT commits since SINCE"
```

If `COMMIT_COUNT` is 0, stop with: *"No commits found in the given time window. Try a wider range (e.g. `1y`)."*

---

## Step 2: Gather Raw Data

Run 2a first (it produces `TOP_FILES`, used by 2b). 2c and 2d are independent and can be executed in parallel with 2b once 2a has finished.

### 2a. File Churn (top 15 most-modified files, from a working-set of 30)

Materialize the filtered top-15 list once as `TOP_FILES` (tab-separated `count<TAB>path`) so later sections can reuse it without repeating the scan:

```bash
BINARY_EXT='\.(png|jpg|jpeg|gif|bmp|ico|webp|svg|pdf|zip|gz|tar|jar|war|exe|dll|so|dylib|class|o|a|lib|pyc|pyo|woff|woff2|ttf|eot|mp3|mp4|mov|avi|wav|ogg|webm|bin|dat|lock)$'

TOP_FILES=$(git log --since="SINCE" --pretty=format: --name-only \
  | grep -v '^$' \
  | grep -Ev "$BINARY_EXT" \
  | sort | uniq -c | sort -rn | head -30 \
  | while read -r count f; do
      if test -f -- "$f"; then
        printf '%s\t%s\n' "$count" "$f"
      fi
    done \
  | head -15)

echo "$TOP_FILES"
```

Starting from a working-set of 30 ensures 15 survivors even if some top-churn files have been deleted from the working tree. `TOP_FILES` is the single source of truth for the churn list used in 2b and the bug cross-reference below.

### 2b. Bus Factor / Ownership

For each path in `TOP_FILES` (reuse the list from 2a — do not rescan git history), count distinct authors:

```bash
echo "$TOP_FILES" | cut -f2 | while IFS= read -r f; do
  authors=$(git log --since="SINCE" --pretty=format:"%an" -- "$f" | sort -u)
  count=$(( $(echo "$authors" | wc -l) ))
  echo "$count authors — $f"
  if [ "$count" -le 1 ]; then
    echo "  ⚠ Single owner: $authors"
  fi
done
```

Flag files with only 1 author as **single-owner risks**.

### 2c. Bug Hotspots (top 10)

```bash
git log --since="SINCE" --grep="fix\|bug\|hotfix" -i --pretty=format: --name-only \
  | grep -v '^$' \
  | grep -Ev "$BINARY_EXT" \
  | sort | uniq -c | sort -rn | head -10
```

Cross-reference with `TOP_FILES` from 2a — files appearing on **both** lists get flagged as high-risk.

### 2d. Firefighting Frequency

```bash
git log --since="SINCE" --grep="revert\|hotfix\|rollback" -i \
  --format="%ad" --date=format:"%Y-%m" \
  | sort | uniq -c
```

This groups revert/hotfix/rollback commits by month. Note the trend direction (improving, worsening, or stable).

---

## Step 3: Synthesize Narrative Report

**Do not dump raw tables.** Read the data from all four analyses and write a narrative briefing structured as follows:


```
## Repository Health — {REPO_NAME}
**Period:** {SINCE} to today · **Commits:** {COMMIT_COUNT}
```

### Section 1: "Where the Pain Is"

Identify the highest-churn files and explain why they matter:
- Name the top 3–5 worst offenders with specific commit counts
- Cross-reference with bus factor — call out files that are both high-churn **and** single-owner
- Note any patterns (e.g. "3 of the top 5 are test config files" or "churn is concentrated in the API layer")

### Section 2: "Bug-Prone Areas"

Where do fix/bug commits cluster:
- Name the top files from the bug hotspot analysis with counts
- Highlight files that appear on **both** the churn list and the bug list — these are the highest-risk areas
- If no fix/bug commits are found, say so: *"No commits matching fix/bug/hotfix keywords — either commit messages don't follow this convention, or it's been a clean period."*

### Section 3: "Firefighting Trend"

Interpret the revert/hotfix/rollback frequency:
- Show the month-by-month counts
- State whether the trend is improving, worsening, or stable
- Call out any notable spikes (e.g. "December saw 8 hotfixes — 3x the average")
- If no firefighting commits are found, note that positively

### Section 4: "The Short Version"

End with **3–5 bullet points** of prioritized, actionable takeaways. Examples:
- *"src/api/auth.ts has 47 changes and only 1 author — schedule a knowledge-sharing session"*
- *"Bug fixes cluster in the billing module — consider adding integration tests"*
- *"Hotfix frequency has halved since October — whatever changed is working"*

---

## Edge Cases

- **Empty results in any section**: Handle naturally in prose — don't leave sections blank, explain what the empty result means
- **Binary files in churn/bug lists**: The `BINARY_EXT` regex in 2a filters these out before ranking — covers images (`png|jpg|jpeg|gif|bmp|ico|webp|svg`), archives (`zip|gz|tar|jar|war`), compiled artefacts (`exe|dll|so|dylib|class|o|a|lib|pyc|pyo`), fonts (`woff|woff2|ttf|eot`), media (`mp3|mp4|mov|avi|wav|ogg|webm`), and lockfiles (`lock`). Reuse `$BINARY_EXT` in 2c and any other file-ranking commands so outputs stay consistent
- **Monorepo**: If the top-churn files span many directories, note this and suggest running the analysis from a subdirectory for more focused results
- **Non-standard commit messages**: The bug hotspot and firefighting analyses depend on commit message conventions. If results are sparse, mention this: *"These analyses rely on keywords like 'fix', 'bug', 'hotfix', and 'revert' in commit messages. If your team uses different conventions, results may be incomplete."*

## Examples

User says: "/auditing-repo-health"
Claude runs all health checks on the current repository and outputs a dashboard with scores and recommended fixes.

## Troubleshooting

- **Score lower than expected**: run individual checks manually to identify which metric is failing.
- **Date range returning no results**: verify the `--since` value is in ISO format (e.g. `[YYYY-MM-DD]`).
