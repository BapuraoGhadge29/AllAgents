---
name: investigating-traces
description: Query Google Cloud Logging by traceId — fetches log entries via gcloud CLI, extracts error details from payloads, and analyses the log sequence to determine root cause. Use '/investigating-traces' when investigating a GCP trace or traceId-linked log sequence.
disable-model-invocation: true
argument-hint: "[traceId]"
allowed-tools:
- Bash
- mcp__claude_ai_Atlassian_MCP__searchJiraIssuesUsingJql
---

# GCP Trace Query

Provides guidance for querying Google Cloud Logging by traceId using the `gcloud` CLI and interpreting the returned log entries to extract meaningful error context.

## Querying Logs by TraceId

Always resolve the active project first. Note: this may differ from the target project — confirm with the developer if needed.

```bash
gcloud config get project
```

### Canonical Maxxton Query

Maxxton logs are scoped under `projects/maxxton-software/locations/global/logScopes/apps`. Use this as the primary query:

```bash
gcloud logging read 'trace="projects/maxxton-software/traces/TRACE_ID"' \
  --project=maxxton-software \
  --resource-names="projects/maxxton-software/locations/global/logScopes/apps" \
  --order=asc \
  --limit=200 \
  --freshness=7d \
  --format=json
```

### Generic Query

For other projects, substitute the correct PROJECT_ID:

```bash
gcloud logging read 'trace="projects/PROJECT_ID/traces/TRACE_ID"' \
  --project=PROJECT_ID \
  --order=asc \
  --format=json
```

If the full trace resource path is unknown, try a substring filter:

```bash
gcloud logging read 'trace=~"TRACE_ID"' \
  --project=PROJECT_ID \
  --order=asc \
  --format=json
```

Fetch **all log entries** — do not filter by severity at this stage. The full sequence (INFO → WARNING → ERROR) is needed to reconstruct the execution path that led to the failure.

---

## GCP Log Entry Structure

Each JSON log entry contains:

| Field | Description |
|-------|-------------|
| `timestamp` | ISO 8601 timestamp |
| `severity` | DEFAULT, DEBUG, INFO, NOTICE, WARNING, ERROR, CRITICAL, ALERT, EMERGENCY |
| `logName` | Full log name, e.g. `projects/my-project/logs/run.googleapis.com%2Fstdout` |
| `resource.type` | GCP resource type (`cloud_run_revision`, `k8s_container`, `gce_instance`, etc.) |
| `resource.labels` | Resource identifiers — `service_name`, `namespace_name`, `pod_name`, etc. |
| `textPayload` | Plain text log line |
| `jsonPayload` | Structured JSON — check `.message`, `.error`, `.exception`, `.stack_trace` |
| `httpRequest` | HTTP request details if the log is tied to an HTTP operation |
| `trace` | Full trace resource path |
| `spanId` | Span within the trace |

---

## Extracting Key Information

### Affected Service

Check in order:
1. `resource.labels.service_name` (Cloud Run)
2. `resource.labels.container_name` or `resource.labels.pod_name` (Kubernetes)
3. The suffix of `logName` after the last `/` (URL-decoded)

### Error Message

Check in order:
1. `jsonPayload.error`
2. `jsonPayload.message` on ERROR/CRITICAL entries
3. `jsonPayload.exception`
4. `textPayload` on ERROR/CRITICAL entries

### Stack Trace

Check in order:
1. `jsonPayload.stack_trace`
2. `jsonPayload.stackTrace`
3. `jsonPayload.exception` (may be a multi-line string)
4. Consecutive `textPayload` lines following an ERROR entry starting with whitespace or `at `

### Request Context

Check:
- `httpRequest.requestUrl` — the endpoint called
- `httpRequest.requestMethod` — GET/POST/etc.
- `jsonPayload.requestId` or `jsonPayload.correlationId`

---

## Interpreting the Log Sequence

To determine root cause, reconstruct the event flow:

1. **Find the first ERROR or CRITICAL entry** — this is typically where the failure began
2. **Look at entries immediately before it** — INFO/WARNING entries often reveal what triggered the failure
3. **Check if the error propagated** — multiple ERROR entries from different services indicate a cascading failure
4. **Identify the originating service** — the first service to log an ERROR is usually the root cause owner

### Cascade Pattern

```
[INFO]  service-a  Calling service-b for user 123
[INFO]  service-b  Processing request
[ERROR] service-b  Database timeout after 30s
[ERROR] service-a  Downstream call failed: service-b returned 500
```
Root cause: service-b database timeout. service-a error is a cascade.

### Internal Error Pattern

```
[INFO]  service-a  Received request POST /api/orders
[ERROR] service-a  NullPointerException at OrderService.java:142
[CRITICAL] service-a  Unhandled exception — request aborted
```
Root cause: NullPointerException in service-a.

---

## Summary Format

When summarising findings, extract:

- **Service**: the service responsible for the root cause error
- **Error**: the primary error message (one line)
- **Stack trace**: the exception class and top frames if available
- **Operation**: what the system was attempting when it failed
- **Time range**: first and last log entry timestamps

Keep the summary factual — only report what the logs actually show.

## Instructions

After analysis, use `mcp__claude_ai_Atlassian_MCP__searchJiraIssuesUsingJql` to check if a Jira bug already exists for the identified error before filing a new one.

Invoke with "/investigating-traces" in Claude Code. The skill guides you through the workflow step by step.

## Examples

User says: "/investigating-traces"
Claude follows the distributed trace from the provided trace ID, identifies the slowest or failing span, and surfaces the root cause.

## Troubleshooting

- **Trace not found**: confirm the trace ID is correct and the retention window has not expired.
- **Spans missing**: the service may not have tracing instrumented — check the service config.
