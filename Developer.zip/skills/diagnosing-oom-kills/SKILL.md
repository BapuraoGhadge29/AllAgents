---
name: diagnosing-oom-kills
disable-model-invocation: true
argument-hint: "<service-name> [env=production|acceptance|development] [pod=<pod-name>]"
description: "Triages OOM-killed pods in Maxxton JVM/Spring Boot services on GKE. Confirms the kill, classifies the cause (memory leak, traffic spike, or undersized limits), applies immediate relief, and routes to the appropriate long-term fix. Use when a pod is OOMKilled, shows CrashLoopBackOff due to memory, or an OOMKill Alertmanager alert fires.\n"
allowed-tools:
- Bash
- Read
- Edit
- AskUserQuestion
- mcp__claude_ai_Maxxton_Knowledge__get_service_overview
- mcp__claude_ai_GitHub__get_file_contents
- mcp__claude_ai_GitHub__search_code
---

# OOM Kill Investigator

Triages OOM-killed JVM/Spring Boot pods on Maxxton GKE. Follows a confirm → classify →
immediate relief → long-term fix sequence. For pods still running but approaching the limit,
the same steps apply — stop at Step 3 to classify and act before the kill happens.

---

## How to Use This Skill

Invoke with `/diagnosing-oom-kills <service-name>`.

| Parameter | Example | Notes |
|---|---|---|
| **service** | `pricing-service` | Required |
| **env** | `production`, `acceptance`, `development` | Required |
| **pod** | `pricing-service-abc12-xyz` | Optional — provide if you know the specific killed pod |

---

## Step 1 — Confirm the OOM Kill

### Environment → Namespace

| Environment | GKE Namespace |
|---|---|
| `production` | `mxts-prod` |
| `acceptance` | `mxts-acc` |
| `development` | `mxts-dev` |

```powershell
$ns  = "<namespace>"
$svc = "<service-name>"

# List pods and their restart counts
kubectl get pods -n $ns | Select-String $svc

# Check Last State on each restarting pod
kubectl describe pod <pod-name> -n $ns |
  Select-String -Pattern "OOMKilled|Last State|Exit Code|Reason|Finished" -Context 0,3
```

**OOM kill signatures:**
- `Reason: OOMKilled` in Last State
- `Exit Code: 137` (SIGKILL sent by the Linux OOM killer)
- `Terminated: OOMKilled` in container status

```powershell
# Recent cluster events for this service
kubectl get events -n $ns --sort-by='.lastTimestamp' |
  Select-String -Pattern "OOMKill|Evict|memory" | Select-Object -Last 20
```

If neither `OOMKilled` nor exit code 137 is present, this is not a memory kill — the pod may
be crashing for another reason. Use `/investigating-alerts` instead.

---

## Step 2 — Understand Memory Limits vs Actual Usage

```powershell
# Current usage across all surviving replicas
kubectl top pods -n $ns | Select-String $svc

# Limits and requests from the deployment
kubectl describe deployment $svc -n $ns | Select-String "memory" -Context 0,3

# JVM heap setting (should be ~75% of pod memory limit)
kubectl describe deployment $svc -n $ns | Select-String "Xmx\|JAVA_OPTS\|JAVA_TOOL_OPTIONS"
```

**The critical ratio:**

| Ratio | Meaning |
|---|---|
| `-Xmx` > 75% of pod memory limit | JVM heap + non-heap overhead can exceed the container limit — OOM is expected under load |
| Pod limit equals `-Xmx` exactly | No headroom for metaspace, NIO buffers, or thread stacks |
| No `-Xmx` set | JVM defaults to 25% of container memory — may still exceed limit if non-heap is large |

**Correct sizing formula:**

```
Pod memory limit:  X MiB
JVM -Xmx:          floor(0.75 × X) MiB   ← heap
Remaining 25%:     metaspace + NIO buffers + thread stacks + JVM overhead
```

If this ratio is wrong, fix it first (Step 5b) — further investigation may be unnecessary.

---

## Step 3 — Classify the Cause

Run all three signal checks before routing to a fix. Each check eliminates one hypothesis.

### Signal A — Gradual climb or sudden spike?

Run this PromQL in Grafana with a 24h–7d time range:

```promql
jvm_memory_used_bytes{application="<service-name>", area="heap"}
```

| Pattern | Cause |
|---|---|
| Rising sawtooth — floor climbs across GC cycles over days | **Memory leak** → Step 5a |
| Sudden spike aligned with traffic increase | **Traffic spike / undersized limit** → Step 5b |
| Spike immediately after a deploy | **Deploy regression** → check recent commits |
| Stable until a specific hour (e.g. midnight) | **Batch job** → Step 5c |

### Signal B — One pod or all pods?

```powershell
kubectl top pods -n $ns | Select-String $svc
```

| Pattern | Cause |
|---|---|
| One pod killed, others healthy and stable | Single large request or async job on that pod |
| All pods spiking together | Shared traffic surge or deploy-triggered regression |

### Signal C — Was a batch job or bulk export running?

```powershell
gcloud logging read `
  "resource.labels.container_name=`"$svc`" AND resource.labels.namespace_name=`"$ns`"" `
  --project=maxxton-software `
  --resource-names="projects/maxxton-software/locations/global/logScopes/apps" `
  --freshness=12h `
  --limit=100 `
  --format="value(timestamp,jsonPayload.message,jsonPayload.taskExecId)" `
  --order=asc
```

If logs show a bulk export, migration, or scheduled job running before the kill → the job
buffered too much data. Fix: paginate or stream the result (Step 5c).

Also scan for `parallelStream` or `ForkJoinPool` traces in logs — per the Maxxton
Performance Guide, `parallelStream` must **never** be used in production on limited CPU
cores. Under load it saturates the JVM common pool, causing unbounded thread creation and
heap exhaustion. Replace with a sequential stream or a named `ThreadPoolTaskExecutor` `@Bean`.

### Cause → Action mapping

| Cause | Immediate | Long-term |
|---|---|---|
| Memory leak (gradual growth) | Step 4A — rolling restart | Step 5a → `/detecting-memory-leaks` |
| Traffic spike (all pods, no growth) | Step 4C — scale out | Step 5b — right-size limits |
| Undersized JVM/pod ratio | Step 4B — raise limit | Step 5b — fix ratio in Helm values |
| Batch job loading all data at once | Step 4A — restart after job | Step 5c — paginate/stream the job |
| Deploy regression | Step 4A + roll back | Fix the regression, redeploy |

---

## Step 4 — Immediate Relief

Apply the fastest safe action to stop kills while the root cause is being fixed.

### Option A — Rolling restart (clears in-memory state)

```powershell
kubectl rollout restart deployment/$svc -n $ns
kubectl rollout status deployment/$svc -n $ns
```

Use when: the leak is slow enough that a restart buys hours for investigation. This is not
a fix — the pod will fill up again in the same time window.

### Option B — Temporarily raise the memory limit

Apply **only** when the JVM/pod ratio check in Step 2 confirms the limit is genuinely undersized:

```powershell
kubectl set resources deployment/$svc -n $ns `
  --limits=memory=<new-limit> `
  --requests=memory=<new-request>
```

Do not raise limits without fixing the ratio — raising a limit without adjusting `-Xmx`
does not help if the JVM heap is already at the old limit.

### Option C — Scale out (distribute load across more replicas)

```powershell
kubectl scale deployment/$svc -n $ns --replicas=<n>
```

Use only for traffic-spike cause where the load is legitimate and adding replicas will
distribute it. Does not help for leaks — all replicas will eventually be killed.

---

## Step 5 — Long-Term Fix

### 5a — Memory leak → detect and fix

Use `/detecting-memory-leaks` to identify and apply the leak fix. After the fix is deployed,
re-run the heap trend PromQL from Step 3 and confirm the sawtooth floor is stable. Re-run
`kubectl top pods` to confirm no pods are approaching the limit within the next 2 hours.

### 5b — Undersized limits → right-size JVM and pod together

Correct both `-Xmx` and the pod limit in the Helm chart values:

```yaml
# Example: 2 GiB pod with correct JVM heap
resources:
  limits:
    memory: "2Gi"
  requests:
    memory: "1.5Gi"
env:
  - name: JAVA_OPTS
    value: "-Xmx1536m -Xms512m"   # 75% of 2 GiB = 1536 MiB
```

**Verify:** after deploying the new values, re-run:

```powershell
kubectl top pods -n <namespace> | Select-String <service-name>
kubectl describe deployment <service-name> -n <namespace> | Select-String "memory" -Context 0,2
```

Memory usage should sit below 75% of the new limit within 30 minutes of normal traffic.
Re-run the heap trend PromQL from Step 3 to confirm no upward drift over the next hour.

Also check for `@Async` methods without a configured `ThreadPoolTaskExecutor` — Spring's
default creates an unbounded new thread per `@Async` call, which under sustained load
produces runaway memory growth. Define a bounded `ThreadPoolTaskExecutor` `@Bean` and
reference it explicitly: `@Async("taskExecutor")`.

### 5c — Batch job loading all data into memory → paginate or stream

Ask the user before checking the codebase:

> "The logs point to [batch job / method name from Signal C logs] loading too much data at
> once. Would you like me to check `MaxxtonGroup/<repo>` to find and fix the data loading
> pattern?"

Use `AskUserQuestion` with **Yes** / **No**.

**If yes — find, fix, and apply:**

1. **Derive the search query from the Signal C logs** — use the job class or method name
   found in the log entries (e.g. if logs show `ExportBatchJob` or `findAll`, use that)
2. `search_code(repo="MaxxtonGroup/<repo>", query="<BatchClassName>")` — locate the file
3. `get_file_contents(repo="MaxxtonGroup/<repo>", path="<file>")` — read the implementation
4. Determine whether the job uses `findAll()` (needs pagination) or buffers to output
   (needs streaming) — pick the correct fix from the patterns below
5. Produce the **actual fix for this file** — show the real old lines → new lines as a diff
6. Ask: *"Should I apply this change?"* using `AskUserQuestion` (Yes / No)
7. **If yes:** apply with `Edit`, then instruct: *"Deploy and monitor the next batch run
   with `kubectl top pods -n <ns> --watch` — peak memory should stay below 80% of the limit"*

**Fix patterns:**

```java
// BAD: loads entire result set into heap
List<Record> all = repo.findAll();
all.forEach(this::process);

// GOOD: page through in fixed-size chunks (Oracle OFFSET pagination)
Pageable page = PageRequest.of(0, 500);
Page<Record> chunk;
do {
    chunk = repo.findAll(page);
    chunk.forEach(this::process);
    page = chunk.nextPageable();
} while (chunk.hasNext());

// ALSO GOOD for exports: stream directly to output — heap never holds the full set
// (eliminates the buffer entirely; preferred for file/socket exports)
try (Stream<Record> stream = repo.findAllStream()) {
    stream.forEach(record -> writeRecord(record, outputStream));
}
```

> Per the Maxxton Performance Guide: "data in memory is something you want to drop as
> quickly as possible — streaming can be of great help" for export scenarios. Standard
> JDBC drivers do not support streaming, but Spring Data's `Stream<T>` return type on
> repository methods enables cursor-based streaming with Hibernate.

**Verify:** after deploying, trigger the batch job manually (or wait for the scheduled run)
and monitor memory in real time:

```powershell
kubectl top pods -n <namespace> --watch
```

Peak memory during the batch run should stay below 80% of the pod limit. Compare with the
pre-fix baseline — a successful streaming or pagination fix typically reduces peak by 50–80%.

---

## Step 6 — Prevention

### Prometheus alerts to add

Ensure these alerts exist for the service in the Alertmanager configuration:

```yaml
# Memory approaching limit — early warning
- alert: PodMemoryHigh
  expr: |
    container_memory_working_set_bytes{namespace=~"mxts-.*", container!=""}
    / container_spec_memory_limit_bytes{namespace=~"mxts-.*", container!=""}
    > 0.80
  for: 10m
  labels:
    severity: warning

# Pod was OOM-killed
- alert: PodOOMKilled
  expr: kube_pod_container_status_last_terminated_reason{reason="OOMKilled", namespace=~"mxts-.*"} > 0
  for: 1m
  labels:
    severity: critical
```

### GC logging (add to JAVA_OPTS)

```
-Xlog:gc*:file=/var/log/gc.log:time,uptime:filecount=5,filesize=20m
```

GC logs let you correlate heap pressure with specific time windows after a kill without needing
a live heap dump.

---

## Common Pitfalls

- **Raising the limit without adjusting `-Xmx`** — if `-Xmx` is already at 95% of the old
  limit, adding 512 MiB to the pod limit without adjusting the JVM flag gains almost nothing.
- **Rolling restart as a permanent fix** — restarts clear in-memory state but the leak returns.
  Always file a ticket to track the root cause fix.
- **Attributing a batch-job kill to a leak** — check logs and `mxt.username` on traces first.
  A nightly bulk export killing one pod has a different fix path than a multi-day heap trend.
- **Heap dump on the only pod** — `VM.heap_dump` causes a GC pause. On a single-replica service,
  warn the user before proceeding to Step 5a.

---

## Examples

User says: `/diagnosing-oom-kills pricing-service env=production`
Claude confirms the OOM kill via `kubectl describe`, checks the JVM/pod memory ratio, classifies the cause as leak or undersized limit, applies immediate relief, and routes to the appropriate long-term fix.

## Troubleshooting

- **`kubectl describe` shows no OOMKilled**: the pod may have been evicted (not OOM-killed) — look for `Reason: Evicted` in pod events; node memory pressure has a different fix path.
- **Heap trend data missing**: Prometheus may not be scraping the service — check whether `jvm_memory_used_bytes` returns data in Grafana; if not, verify Micrometer is on the classpath.
- **Rolling restart doesn't stop the kills**: the leak rate is faster than the restart buys time — apply a temporary limit increase (Step 4B) alongside the restart to hold it stable.

## Integration with Other Skills

- `/detecting-memory-leaks` — called from Step 5a when a leak is confirmed as the root cause
- `/investigating-alerts` — use when an OOMKill Alertmanager alert fired and you need broader
  incident context (recent deploys, correlated errors) before investigating
- `/profiling-cpu` — check whether CPU throttling is also occurring alongside memory pressure
- `/performance-profiler` — use when the OOM kill is also causing latency spikes on a specific
  endpoint and you need trace-level detail
