---
name: triaging-top-errors
description: Use this skill when a developer asks to surface the most frequent errors in GCP Cloud Logging for a project or time window. Relevant for "what errors are happening", "top errors", "error summary", "most common failures", or "error frequency in GCP".
disable-model-invocation: true
argument-hint: "[project=PROJECT_ID] [window=24h] [filter=EXTRA_FILTER] [limit=10000]"
allowed-tools:
- Bash
- mcp__claude_ai_Atlassian_MCP__searchJiraIssuesUsingJql
---

# GCP Top Errors

Queries Google Cloud Logging for ERROR-and-above entries, aggregates by normalized message using a shell pipeline, and presents the top 10 most frequent errors ranked by count.

## Parameters

| Parameter | Default | Description |
|-----------|---------|-------------|
| `project` | active gcloud project | GCP project ID to query |
| `window` | `24h` | Freshness window (e.g. `1h`, `6h`, `7d`) |
| `filter` | _(none)_ | Optional extra log filter expression appended with `AND` |
| `limit` | `10000` | Max log entries to fetch — increase for high-volume projects |

---

## Step 1: Resolve the GCP Project

```bash
gcloud config get project
```

- Use the output as `PROJECT_ID`.
- If empty or `(unset)`, ask the developer: *"Which GCP project should I query?"*
- If the developer provided an explicit `project` argument, use it without running this command.

---

## Step 2: Aggregate Error Messages via Shell Pipeline

Run a single command that fetches log entries and aggregates on the shell — output is just the top-10 table, not raw JSON.

Before constructing the command, validate all parameters:
- `WINDOW` must match `\d+[smhd]` (e.g. `1h`, `6h`, `7d`). If invalid, reject with: *"Invalid window value — expected a number followed by s, m, h, or d (e.g. `1h`, `7d`)."*
- `LIMIT` must be a positive integer ≤ 1,000,000. If invalid, reject with: *"Invalid limit value — expected a positive integer."*
- `EXTRA_FILTER` (if provided) must contain only GCP Logging filter syntax. Reject if it contains any shell metacharacters: `$`, `` ` ``, `\`, `;`, `|`, or `&`. If invalid, reject with: *"Invalid filter — contains forbidden characters."*

### Routing: which command to run

- If `PROJECT_ID` is `maxxton-software` (or starts with `maxxton-`): use the **Maxxton log-scope path** below.
- Otherwise: skip to the **fallback path** directly — do not run the Maxxton command for non-Maxxton projects.

### Maxxton log-scope path

Use this **only** when `PROJECT_ID` is a Maxxton project (`maxxton-software` or `maxxton-*`):

```bash
set -o pipefail
gcloud logging read 'severity>=ERROR' \
  --project=maxxton-software \
  --resource-names="projects/maxxton-software/locations/global/logScopes/apps" \
  --freshness="WINDOW" \
  --limit="LIMIT" \
  --format='value[separator=";"](severity,resource.labels.container_name,resource.labels.service_name,textPayload,jsonPayload.message,jsonPayload.error)' \
  | python3 -c "
import sys, re
from collections import defaultdict
counts = defaultdict(lambda: {'n': 0, 'sevs': set(), 'svcs': set()})
SEV = ['ERROR','CRITICAL','ALERT','EMERGENCY']
total = 0
for line in sys.stdin:
    parts = line.rstrip('\n').split(';')
    if len(parts) < 4: continue
    sev = parts[0].strip()
    svc = parts[1].strip() or parts[2].strip() or 'unknown'
    msg = next((p.strip() for p in parts[3:] if p.strip()), '')
    msg = msg.split('\n')[0].split('\\n')[0].strip()
    msg = re.sub(r'[0-9a-fA-F]{8,}', '<hex>', msg)
    msg = re.sub(r'\b\d{4,}\b', '<id>', msg)
    key = msg[:120]
    if not key: continue
    total += 1
    counts[key]['n'] += 1
    counts[key]['sevs'].add(sev)
    counts[key]['svcs'].add(svc)
distinct = len(counts)
print(f'Fetched ~{total} entries | {distinct} distinct patterns | window=WINDOW | limit=LIMIT')
print()
for i, (msg, v) in enumerate(sorted(counts.items(), key=lambda x: -x[1]['n'])[:10], 1):
    top_sev = max(v['sevs'], key=lambda s: SEV.index(s) if s in SEV else -1)
    svcs = ', '.join(sorted(v['svcs'])[:3])
    print(f'{i:2}. [{v[\"n\"]:5}x] [{top_sev}] {svcs} — {msg}')
"
```

If this command fails or returns `Fetched ~0 entries`, fall back to the generic path below.


```bash
set -o pipefail
gcloud logging read 'severity>=ERROR' \
  --project="PROJECT_ID" \
  --freshness="WINDOW" \
  --limit="LIMIT" \
  --format='value[separator=";"](severity,resource.labels.container_name,resource.labels.service_name,textPayload,jsonPayload.message,jsonPayload.error)' \
  | python3 -c "
import sys, re
from collections import defaultdict
counts = defaultdict(lambda: {'n': 0, 'sevs': set(), 'svcs': set()})
SEV = ['ERROR','CRITICAL','ALERT','EMERGENCY']
total = 0
for line in sys.stdin:
    parts = line.rstrip('\n').split(';')
    if len(parts) < 4: continue
    sev = parts[0].strip()
    svc = parts[1].strip() or parts[2].strip() or 'unknown'
    msg = next((p.strip() for p in parts[3:] if p.strip()), '')
    msg = msg.split('\n')[0].split('\\n')[0].strip()
    msg = re.sub(r'[0-9a-fA-F]{8,}', '<hex>', msg)
    msg = re.sub(r'\b\d{4,}\b', '<id>', msg)
    key = msg[:120]
    if not key: continue
    total += 1
    counts[key]['n'] += 1
    counts[key]['sevs'].add(sev)
    counts[key]['svcs'].add(svc)
distinct = len(counts)
print(f'Fetched ~{total} entries | {distinct} distinct patterns | window=WINDOW | limit=LIMIT')
print()
for i, (msg, v) in enumerate(sorted(counts.items(), key=lambda x: -x[1]['n'])[:10], 1):
    top_sev = max(v['sevs'], key=lambda s: SEV.index(s) if s in SEV else -1)
    svcs = ', '.join(sorted(v['svcs'])[:3])
    print(f'{i:2}. [{v[\"n\"]:5}x] [{top_sev}] {svcs} — {msg}')
"
```

### With additional filter

After validating `EXTRA_FILTER` per the rules in Step 2 (no `$`, backticks, `\`, `;`, `|`, `&`), append it using single quotes to prevent shell expansion. Note that double quotes would still allow `$()` and backtick expansion — always use single quotes for the complete filter string:

```bash
gcloud logging read 'severity>=ERROR AND EXTRA_FILTER' ...
```

---

## Step 3: Present the Results

The pipeline outputs a ready-to-display table. Present it directly with a header:

```
## Top 10 Errors — maxxton-software (last 24h)

Fetched ~5712 entries | 298 distinct patterns | window=24h | limit=10000

 1. [  571x] [ERROR] krm-cms-web-worker — (Use `node --trace-deprecation ...` to show where the warning was created)
 2. [   58x] [ERROR] airflow — INFO: detected pid 1, running init handler
 3. [   28x] [ERROR] customer-service — Row was updated or deleted by another transaction
...
```

Then for the top 3–5 entries, add a brief interpretation:

> **#1** is a Node.js deprecation warning logged at ERROR level — likely not a real failure. **#3** is an optimistic locking conflict in `customer-service` — may indicate concurrent writes.

---

## Edge Cases

**No output / empty result**: If the script reports `Fetched ~0 entries` and no errors are listed:
> No ERROR-or-above entries found in `PROJECT_ID` for the last `WINDOW`. Try `window=7d`, verify the project, or run `gcloud auth application-default login`.

**Authentication error** — if gcloud outputs `UNAUTHENTICATED`:
> Run `gcloud auth login` or `gcloud auth application-default login` and retry.

**Permission denied** — if output contains `PERMISSION_DENIED`:
> Verify project ID with `gcloud projects list` — your account needs `roles/logging.viewer`.

**High-volume warning** — if fetched count equals `LIMIT` exactly, add:
> ⚠️ Fetch limit of `LIMIT` entries reached. At this volume, results represent only the most recent portion of the `WINDOW`. Use `window=1h` for a complete picture of the last hour.

**gcloud not installed**:
> Install the gcloud CLI from https://cloud.google.com/sdk/docs/install, then run `gcloud auth login`.

## Integration

After identifying top errors, use `mcp__claude_ai_Atlassian_MCP__searchJiraIssuesUsingJql` to check if existing Jira bugs already track the top errors before creating new ones.

## Examples

User says: "/triaging-top-errors"
Claude queries the error monitoring system for the top errors in the specified timeframe and ranks them by impact.

## Troubleshooting

- **No errors returned**: check the time range and verify the error monitoring integration is configured.
- **Errors look stale**: confirm the monitoring system is receiving live events.
