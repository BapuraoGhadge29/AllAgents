---
name: spinning-up
description: Resolve and start the minimum set of local microservices needed to test a specific endpoint — uses the Maxxton Knowledge MCP call graph to determine service dependencies, then starts them sequentially. Use '/spinning-up' when starting local microservices to test a specific endpoint.
disable-model-invocation: true
argument-hint: "[URL or endpoint path]"
allowed-tools:
- Bash
- Read
- Glob
- Grep
- mcp__claude_ai_Maxxton_Knowledge__search_technical_graph
- mcp__claude_ai_Maxxton_Knowledge__query_openapi
- mcp__claude_ai_Maxxton_Knowledge__get_call_chain
---

# Local Microservice Spin-Up

Automatically starts the minimum set of local microservices needed to test an endpoint, using the Maxxton Knowledge MCP to resolve the call chain. Services not on the path fall through to the DEV environment.

## Step 1: Parse input

Accept one of:
- A full URL: `https://fmc-dev.maxxton.net/api/v1/reservations/12345`
- An endpoint path: `/api/v1/reservations/12345`
- A service name: `imply-service` (skip to step 4 — just start this service and its upstream callers)

Strip the domain and any path IDs to get a parameterized path pattern (e.g., `/api/v1/reservations/{reservationId}`).

## Step 2: Match to controller method

Use `search_technical_graph` with `node_type: ControllerMethod` to find the controller method that handles this endpoint. If the search doesn't match directly, use `query_openapi` as a fallback.

Extract:
- The **entry service** (the repository that owns the controller)
- The **controller method node ID** (for call chain tracing)

## Step 3: Detect target service

Infer the target service (the one the developer is working on) from the **current working directory**. Look for a recognizable repo name pattern in the cwd path (e.g., `/code/java/imply-service` → `imply-service`).

If the cwd doesn't clearly map to a service, ask the developer which service they're testing changes for.

## Step 4: Find the path

Use `get_call_chain` from the entry controller method (outbound, depth 10) to trace all downstream calls. Identify which services are on the path between the entry service and the target service.

**Only include services on the path.** All other dependencies fall through to the DEV environment. This is because:
- If a local service calls a DEV service, that DEV service will call other DEV services (not local ones)
- So you must run locally every service in the chain between entry and target

If the entry service IS the target service, only that single service needs to run.

## Step 5: Locate repos locally

Infer the services base directory from the **target service's location** (detected in Step 3 from the cwd). For example, if the cwd is `/home/dev/repos/java/imply-service`, the base directory is `/home/dev/repos/java/`. If the base directory cannot be inferred, ask the developer: *"Where are your service repos checked out? (e.g. `~/code/java/`)"*

Scan the base directory for directories matching the service names. Service names in the graph use the repository name (e.g., `reservation-service`, `price-engine-service`).

```bash
ls -d {base-dir}/{service-name} 2>/dev/null
```

If a repo is not found locally, warn the developer and ask if they want to clone it or skip it.

## Step 6: Ensure repos are up-to-date

**Before pulling, present the list of services and ask for explicit confirmation:**

> I'm about to `git pull` the following service repos to ensure they're up-to-date:
> - {service-1} (on branch `{branch}`)
> - {service-2} (on branch `{branch}`)
>
> Proceed?

Wait for confirmation. For each repo, check the current branch and pull latest:

```bash
cd {base-dir}/{service-name} && git status --short && git pull
```

**Do NOT switch branches** — the developer may be on a feature branch intentionally. Only pull to update the current branch.

**Exception:** The target service (cwd) should already be on the correct branch. Don't touch it.

## Step 7: Start services sequentially

**Before starting services, present the startup plan and ask for explicit confirmation:**

> Ready to start {N} services in this order (entry → target):
> 1. {service-1} on port 8000
> 2. {service-2} on port 8001
> ...
>
> Each service will run as a background `bootRun` process. Proceed?

Wait for confirmation. Start services in dependency order (entry service first, target service last). The first service to start gets port 8000, the second 8001, etc.

```bash
cd {base-dir}/{service-name} && ./gradlew bootRun --args="--server.port={port}"
```

Run each as a **background task**. After starting each service, wait for it to be healthy before starting the next:

```bash
curl -s -o /dev/null -w "%{http_code}" http://localhost:{port}/actuator/health
```

A response of `401` means the service is up (auth required on health endpoint). Retry every 10 seconds, with a timeout of 120 seconds per service.

## Step 8: Report status

Once all services are running, present a summary:

```
Target service: {target-service} (from cwd)
Entry point: {entry-service} -> {HTTP method} {path}

Path: {entry-service} -> ... -> {target-service}

Running locally:
  {service-1}  -> localhost:8000
  {service-2}  -> localhost:8001
  {service-N}  -> localhost:800N

Falling through to DEV:
  - {other-dependency-1}
  - {other-dependency-2}

Ready to test!
```

## Important notes

- **Never start all dependencies** — only the services on the path to the target. This is the key design principle.
- **Port allocation is sequential** — first service started gets 8000, there is no fixed port-per-service mapping.
- **If a service fails to start**, show the last 20 lines of its output and ask the developer how to proceed.
- **The developer may pass a curl command** instead of a URL. Extract the URL from it and proceed normally.

## Examples

User says: "/spinning-up"
Claude reads the repo setup docs, runs the required services, and verifies the local environment is ready for development.

## Troubleshooting

- **Service fails to start**: check Docker is running and ports are not already in use.
- **Missing environment variables**: copy `.env.example` to `.env` and fill in required values.
