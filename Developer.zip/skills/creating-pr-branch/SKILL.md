---
name: creating-pr-branch
description: Create a PR-ready Git branch from a base branch — checkout, pull, conflict handling, branch creation, commit, and push in one guided flow. Use '/creating-pr-branch' when creating a branch or PR for a task or ticket.
allowed-tools:
- Bash
- AskUserQuestion
disable-model-invocation: true
---

# Create Branch Workflow

This skill guides the developer through a safe, consistent branch creation flow:
check current state → pull latest → handle conflicts → create sub-branch → commit → push.

---

## Step 1: Detect current branch

Run:
```bash
git branch --show-current
```

Also check if there are any uncommitted changes:
```bash
git status --short
```

---

## Step 2: Determine the base branch

You need to know which branch to base the new work off. First, fetch the list of available remote branches to give the user accurate options:

```bash
git fetch --prune
git branch -r --sort=-committerdate | head -20
```

**If the user is already on the correct base branch** (they said so, or the current branch is a known integration branch like `develop`, `master`, `main`, or a `release/` branch), skip asking and go straight to Step 3.

**If the current branch is unclear or not what the user wants**, present them with the most relevant options. Common base branches at Maxxton are:

- `develop` — ongoing development, most common base for feature work
- `release/v<year>.<sprint>.<patch>` (e.g., `release/v2026.13.0`) — active release branch, use for release-targeted fixes
- `master` / `main` — production branch, use only for hotfixes
- An existing `feature/<name>` branch — when building on top of another feature

Ask the user:

> "You're currently on `<current-branch>`. Which branch would you like to base your new branch from?
> - `develop`
> - `release/v2026.13.0` *(or latest release branch)*
> - `master`
> - Other (tell me the name)"

If they want a different branch, check it out:
```bash
git checkout <target-base-branch>
```

---

## Step 3: Pull latest changes

Before pulling, check whether the working tree is clean:
```bash
git status --short
```

### If there are uncommitted changes (output is non-empty):

Do **not** run `git pull` yet — it will abort with "Your local changes would be overwritten". Instead, tell the user:

> "You have uncommitted changes. I need a clean working tree before pulling. Would you like to:
> - **Commit** — stage and commit them now (I'll help you write the message)
> - **Stash** — temporarily set them aside with `git stash` (including untracked files if any)
> - **Cancel** — stop here so you can handle it manually"

- **Commit path**: follow Steps 6–8 inline (stage → generate message → commit), then continue with the pull.
- **Stash path**: run `git stash --include-untracked`, then pull, then remind the user to run `git stash pop` after the new branch is created.
- **Cancel**: stop the workflow and let the user resolve it.

Don't proceed until `git status --short` returns empty output.

### Once the working tree is clean, pull:

Run:
```bash
git pull
```

### If there are merge conflicts after pull:

Don't silently fail. Tell the user clearly:

> "There are merge conflicts in the following files: [list them]. Would you like me to help resolve them, or abort and start fresh?"

- **Help resolve**: Go through each conflicted file, show the conflicts, and guide the user to pick the correct resolution. After resolving: `git add <file>` and `git rebase --continue` or `git merge --continue` as appropriate.
- **Abort approach**: The repo is mid-merge/rebase — `git stash` will fail in this state. First abort the in-progress operation:
  ```bash
  git merge --abort   # if mid-merge
  # or
  git rebase --abort  # if mid-rebase
  ```
  Then stash any remaining local changes and re-pull:
  ```bash
  git stash --include-untracked
  git pull
  ```
  Remind the user to run `git stash pop` after the new branch is created.

Don't proceed to branch creation until the working tree is clean.

---

## Step 4: Ask for the new branch name

Ask the user what to name the new branch:

> "What would you like to name the new branch?"

If the context already contains a ticket ID and title (e.g., from the conversation or a Jira ticket), suggest a name based on it:

> "Based on the ticket, I'd suggest `feature/MXTS-75114` or `feature/MXTS-75114-outer-layer-of-rule-and-default-value`. Would you like to use that, or a different name?"

**Accepted formats:**

| Type | Short form | Long form |
|------|-----------|-----------|
| Feature | `feature/MXTS-<id>` | `feature/MXTS-<id>-<short-description>` |
| Bug fix | `bugfix/MXTS-<id>` | `bugfix/MXTS-<id>-<short-description>` |
| Hotfix | `hotfix/MXTS-<id>` | `hotfix/MXTS-<id>-<short-description>` |

**Examples:**
- `feature/MXTS-74361` or `feature/MXTS-74361-outer-layer-of-rule-and-default-value`
- `bugfix/MXTS-74178` or `bugfix/MXTS-74178-fix-logic-in-flatten-function`
- `hotfix/MXTS-5632` or `hotfix/MXTS-5632-fix-null-pointer-in-reservation-checkout`

Both forms are valid. If a description is added it must be **lowercase and hyphen-separated** (no spaces). The human-readable description with spaces belongs in the commit message (see Step 7). Do not use `chore/` or other prefixes.

---

## Step 5: Create and checkout the new branch

```bash
git checkout -b <new-branch-name>
```

---

## Step 6: Stage changes

List the working-tree changes:
```bash
git status --short
```

Show the list to the user and stage only the files they confirm, by path:
```bash
git add <path> [<path> ...]
```

Never use `git add -A` or `git add .` — they sweep in stray files (local config, `.env`, scratch output, credentials). If a file looks like a secret or local-only config, call it out and leave it unstaged.

Then check what is actually staged now:
```bash
git diff --cached --stat
```

If the output is empty, let the user know:
> "There are no staged changes. You can make your changes and then ask me to commit and push."
And stop here — don't create an empty commit.

---

## Step 7: Generate and confirm the commit message

Build the commit message using the branch name as a prefix followed by a human-readable description:

**Format:** `<branch-name>: <short description>`

**Examples:**
- `feature/MXTS-74361: Outer layer of Rule and default value`
- `feature/MXTS-75114: remove e2e configuration from core repo`
- `bugfix/MXTS-74178: Fix logic in flatten function to push nodes`
- `hotfix/MXTS-5632: Fix null pointer in reservation checkout flow`

The description here can contain spaces and mixed case — this is a commit message, not a branch name.

Generate a message based on:
1. The branch name (always used as prefix)
2. The staged diff (`git diff --cached --stat`) to understand what changed
3. Any context from the conversation (ticket title, description)

Show the user the proposed message and confirm:

> "I'll use this commit message: `feature/MXTS-75114: remove e2e configuration from core repo`. Does that look good, or would you like to change it?"

---

## Step 8: Commit

```bash
git commit -m "<confirmed message>"
```

---

## Step 9: Push the branch

```bash
git push -u origin <new-branch-name>
```

After pushing, confirm success and show the branch URL if possible (GitHub remote can be inferred from `git remote get-url origin`).

Let the user know they can now open a PR from this branch.

---

## Error handling tips

- If `git push` fails due to auth, suggest the user check their SSH key or personal access token.
- If the branch already exists on remote, ask if they want to force push or use a different name.
- If `git checkout -b` fails because the branch already exists locally, offer to check it out with `git checkout <branch-name>` instead.

## Examples

User says: "/creating-pr-branch"
Claude guides you through checking out the base branch, pulling latest, creating a new branch, and pushing it to remote.

## Troubleshooting

- **Push rejected**: check SSH key or personal access token configuration.
- **Branch already exists**: use `git checkout <branch-name>` instead of `-b` to switch to the existing branch.
- **Merge conflicts on pull**: resolve conflicts file by file before creating the branch.
