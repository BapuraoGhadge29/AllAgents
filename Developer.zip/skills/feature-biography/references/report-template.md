# Feature Biography — Report Template

This is the full output template for Phase 8. Produce every section listed below.
If evidence is missing for a section, state it explicitly — absence of evidence
is itself meaningful.

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
📖 FEATURE BIOGRAPHY
Feature:   [name]
Mode:      [📚 Knowledge / 🔧 Improvement / 🐛 Bug / ⚠️ Diagnosis]
Generated: [today's date]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

📡 REPORT FRESHNESS
  Jira (MXTS):    last ticket [date], [N] total tickets found
  Jira (other):   last customer ticket [date], [N] found
  GitHub:         last PR [date], [N] PRs found across [M] repos
  Confluence:     most recent relevant page: [date] — [page title]
  ⚠️ Oldest useful Confluence page: [date] — may predate current architecture

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  [🐛 / ⚠️ only — shown first]
🔴 BUG ANCESTRY — READ THIS FIRST
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
[Full regression chain, oldest → newest, each node with ticket + fix PR.
 Dependency change hints inline where relevant.
 "No chain found" if nothing detected.]

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  [🐛 / ⚠️ only]
🔴 SUSPECT PRs — CHECK NEXT
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
[1–3 most suspicious PRs with: repo, #, title, date, author, reason suspect.
 Dependency change hints for any PRs that also changed manifests.]

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  [🐛 / 🔧 / ⚠️ only — always prominent]
⚡ BLAST RADIUS — CHECK BEFORE CHANGING ANYTHING
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
[Direct callers → indirect consumers → shared features.
 Minimum test scope listed explicitly.]

VERDICT: [emoji] [TYPE] — [one-sentence summary]

━━━━━━━━━━━━
ORIGIN
━━━━━━━━━━━━
Introduced:   [date] by [author role — "still at company" or "departed ~YYYY"]
Era:          [Maxxton / Newyse (pre-Maxxton)] — note if very old
Trigger:      [what made this necessary — incident, customer demand, compliance]
First ticket: [KEY-XXX — title + link]
Epic:         [EPIC-XX — title] (if applicable)
Branch type:  [hotfix / feature / release]
Customer:     [ticket key + customer name if customer-originated, else "internal"]

━━━━━━━━━━━━
THE STORY
━━━━━━━━━━━━
[3–6 paragraphs in plain narrative language. Tell it chronologically:
 business context at the time → problem identified → how implementation evolved
 → scope changes → deferred items → state when ticket closed.
 Quote key PR review comments and ticket comments verbatim with inline citations.
 For Newyse-era features, note what was known vs. what is uncertain.]

━━━━━━━━━━━━━━━━━━━━━━━━━━
DECISIONS MADE & REJECTED
━━━━━━━━━━━━━━━━━━━━━━━━━━
• Considered: [alternative] → Rejected: [reason] (source: PR #X / ADR-Y / comment)
• Chosen: [approach] → Rationale: [reason] (source: ...)
[If no decision trail: state explicitly — undocumented decisions are a risk signal]

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
ALL JIRA TICKETS  (total: [N] across [P] projects)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
[Oldest first. Group open/in-progress tickets at the end. Include all projects.]

  [KEY-XXX]   ✅ Done      — "Title"                   YYYY-MM-DD  type
  [KEY-XXX]   🔵 Open      — "Title"                   YYYY-MM-DD  type
  [KEY-XXX]   🆕 Recent    — "Title (last 90 days)"     YYYY-MM-DD  type
  [KEY-XXX]   ⚠️ Unowned   — "Open with no assignee"   YYYY-MM-DD  type

━━━━━━━━━━━━━━━━━━━━━━━
CUSTOMER DEMAND
━━━━━━━━━━━━━━━━━━━━━━━
[Non-MXTS tickets that drove this feature — discovered from issue links and
 comments. Show project key, title, customer name, date, status.]

  [KEY-XXX] — "[Customer name]: [what they asked for]" (YYYY-MM-DD)

[If none found: "No external customer tickets linked. May have been an
 internal initiative or verbally requested. Check with product team."]

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
📍 WHERE TO FIND THIS FEATURE IN MAXXTON
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Navigation path:
  [e.g. Content Manager → Units → [Unit] → Settings → Compliance]
  [Conditions: "tab only visible if address country = DK"]

Feature flag:   [Display Name] ([flag.code])
  Default:      [ON / OFF]

Permission to view:   [Display Name] ([permission.code])

Visibility conditions:
  [e.g. "Only shown for country = DK" / "Only for owner type: Individual"]

Validation rules (from code):
  [e.g. "Exactly 10 digits, no letters, cannot be blank if flag ON and country = DK"]
  Source: [ClassName.java, methodName()]

What happens on save:
  [e.g. "OwnerService.saveBfeId() → publishes OwnerUpdatedEvent"]

[Any item not found in code: state "not found — check with product team"]

━━━━━━━━━━━━━━━━━━━━━━━━
RECENT DEVELOPMENT  (last 90 days)
━━━━━━━━━━━━━━━━━━━━━━━━
[What is actively happening with this feature right now?]

  🆕 [KEY-XXX] In Progress — "Title" — @assignee
  🆕 [KEY-XXX] In Review   — "Title" — @assignee
[If quiet: "No active development in the last 90 days."]

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
PR HISTORY  (10 shown — [N] total)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
📦 [repo-name]  [[N] PRs, last: YYYY-MM-DD]
  #NNN — [MXTS-XXXXX] "PR title"  YYYY-MM-DD  @author  [⚠️ flag if suspect]
  #NNN — [MXTS-XXXXX] "PR title"  YYYY-MM-DD  @author
  #NNN — [no ticket]  "PR title"  YYYY-MM-DD  @author  ⚠️ no ticket linked

Format rules:
- MXTS ticket key always comes first, before the PR title — it is the primary
  cross-reference. If a PR has no linked ticket, show `[no ticket]` as a flag.
- Show branch name only when it adds context not already in the title.
- Suspect flags: ⚠️ hotfix, ⚠️ revert, ⚠️ Friday merge, ⚠️ dependency bump,
  ⚠️ no ticket linked (untracked change = higher risk).

Coverage summary after the list:
  Tickets with a linked PR:    [N] / [total MXTS tickets]
  Tickets with no PR found:    [N] — list them (⚠️ untracked changes)
  PRs with no ticket linked:   [N] — list them (⚠️ undocumented work)

[After the list:]
Showing 10 of [N] total PRs across [M] repos. Want to see more?
  → Yes, show all / Yes, next 10 / No

━━━━━━━━━━━━━━━━━━━━━━━━━━━
REPOSITORIES  ([N] total)
━━━━━━━━━━━━━━━━━━━━━━━━━━━
  • [repo-name]  — [N] PRs, last change: YYYY-MM-DD

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  [only shown if API endpoints found]
🔌 API SURFACE
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
REST Endpoints:
  [METHOD]  /path/to/endpoint  — ControllerClass.methodName()
  [METHOD]  /path/to/endpoint  — ControllerClass.methodName()

Feign Clients (services that call this API):
  [service-name] → [target-service] via [ClientInterface.method()]

OpenAPI Spec: [link if found, or "Not found in searched repos"]

[If no endpoints found: this section is omitted entirely]

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  [only shown if DB artifacts found]
🗄️ DATABASE ARTIFACTS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Tables:
  [table_name]  — entity: [EntityClass.java]
                  repo:   [RepositoryClass.java]
                  key columns: [col1 (TYPE), col2 (TYPE), ...]
                  introduced: [migration file + date]

Views:
  [view_name]   — used by: [ServiceClass.method()]
                  Newyse original name: [V_OLD_NAME] (if different)

Newyse mapping (where table/column names differ):
  Newyse table:  [TBL_OLD_NAME]     → Maxxton: [new_name]
  Newyse column: [OLD_COLUMN_NAME]  → Maxxton: [new_column_name]

Migrations:
  [migration_filename]  — [what it did + date]

[If no DB artifacts found: this section is omitted entirely]

━━━━━━━━━━━━━━━━━━━━━
UNRESOLVED DEPENDENCIES
━━━━━━━━━━━━━━━━━━━━━
⚠️ [KEY-XXX] — "title"
   Status: [status] | Assignee: [name or "⚠️ Unassigned"] | Last updated: [date]
   Was meant to: [description]
   Risk if never completed: [concrete consequence]
[If all resolved: "All known dependencies resolved ✅"]

━━━━━━━━━━━━━━━━━
LINKED INCIDENTS
━━━━━━━━━━━━━━━━━
• [INC-XXX] ([date]): [what happened, how this feature was involved]
[If none: "No linked incidents found in Jira."]

━━━━━━━━━━━━━━━━━━━━━━━━
RISK IF MODIFIED OR REMOVED
━━━━━━━━━━━━━━━━━━━━━━━━
Risk level: 🔴 CRITICAL / 🟡 HIGH / 🟢 MEDIUM / ⚪ LOW
[What breaks, which services, which scenarios, existing test coverage]

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  [🐛 / ⚠️ only]
CODE DIAGNOSTICS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Files read (source): [list]
Files read (tests):  [list — or "No test files found for these classes ⚠️"]

🔴 1. [file + method + specific risk + fix]
🟡 2. [...]
🟢 3. [...]
⚠️  [N]. [Dependency version change hint if applicable]

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  [🔧 only]
IMPROVEMENT OPPORTUNITIES
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Files read (source): [list]
Files read (tests):  [list]

🔴 1. [highest-priority improvement — specific, actionable]
🟡 2. [...]
🟢 3. [...]

━━━━━━━━━━━━━━━━━━━━━━
SUGGESTED NEXT STEPS  [all modes except 📚 Knowledge]
━━━━━━━━━━━━━━━━━━━━━━
1. [Most important immediate action]
2. [Second action]
3. [Third action — write a test, raise a ticket, talk to someone specific]

━━━━━━━━━━━━━━━━
👥 WHO TO TALK TO
━━━━━━━━━━━━━━━━
[Ranked list. Only show people still with the company. Include basis for ranking.]

  1. @[name]  — [N commits / N Jira comments / original author / tester / bug reporter]. Best for: [topic]. Active as of [date].
  2. @[name]  — [...]. Best for: [...].
  ⚠️ @[name] — Departed ~[year]. Orphaned intent risk for [specific code area].

━━━━━━━━━━━━
SOURCES
━━━━━━━━━━━━
Jira (MXTS):  [ticket links]
Jira (other): [customer/support ticket links]
GitHub PRs:   [PR links]
Confluence:   [page title + last-modified date + link]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

---

## Verdict Types

**🟢 LIVING GUARD** — Active, still-valid purpose. Do not touch without full context.
**🟡 TICKING BOMB** — Reason unclear or partially resolved. Investigate before changing.
**🔴 ZOMBIE CODE** — Trigger resolved. Likely safe to remove — verify unresolved items first.
**🔵 HISTORICAL CONTEXT** — Informational. No immediate modification risk.

---

## Handling Incomplete Evidence

- **Missing tickets** — State what's absent. Silence is meaningful.
- **Newyse-era features** — Note that pre-Maxxton history may only exist in
  institutional memory or archived systems not accessible here.
- **No customer tickets found** — Say so explicitly. May have been verbal or internal.
- **Missing PR thread** — Flag it. Undocumented reasoning is a risk signal.
- **Departed author** — "Orphaned intent": no living advocate for this code.
- **Stale Confluence only** — Flag the age. A 5-year-old ADR may not reflect
  current reality — always note the last-modified date when citing it.
- **Never fabricate** — A partial, honest report is always better than a
  confident but invented one.
