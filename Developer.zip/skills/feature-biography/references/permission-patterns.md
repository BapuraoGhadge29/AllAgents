# Permission Patterns — Feature Biography Phase 2f Reference

This file documents the complete pattern guide for Phase 2f Step 2: cross-referencing
permission and feature flag codes with the codebase.

---

## Two-Search Approach for Frontend Permission Enforcement

Run **both** searches in parallel — they find different things and must both be done.

### Search A — Literal sub-permission code (cross-feature uses)

```
'[permission.code]' in:file repo:MaxxtonGroup/content-manager-client
```

Example: `'contentmanager.qualitylevel'`

This finds components that reference the feature's permission from OUTSIDE the
feature's own module — typically batch update components, shared list components,
or cross-module navigation that need to gate a specific sub-feature.
The literal pattern is: `('[permission.code]' | ifPermission:'READ')`
and is almost always used to show/hide an entire section or accordion item.

Do NOT conclude "permission unused" if this search returns zero results — proceed
to Search B before drawing any conclusion.

### Search B — permissionRoute variable (own-module uses)

```
permissionRoute in:file path:[feature-name] repo:MaxxtonGroup/content-manager-client
```

Example: `path:quality-level`

This finds the feature's own store service and templates. Read the store's
`initialState` to find what string `permissionRoute` holds — it is frequently
the *parent module* (e.g. `'contentmanager'`), not the sub-permission code.
Then read each HTML template in that folder.

**Critical:** the newyse permission code and the `permissionRoute` are often
different strings. Example from quality level:
- Newyse code: `contentmanager.qualitylevel`
- permissionRoute in store: `contentmanager` (parent module)
- Literal usage in batch component: `'contentmanager.qualitylevel' | ifPermission:'READ'`

Both exist and guard different surfaces. Both must be reported.

---

## ifPermission Permission Types

What each type means in Maxxton templates:

| Type | Used to gate |
|---|---|
| `READ` | Visibility of an entire sub-section, tab, or cross-app navigation link (e.g. "Stocks" tab, "Import" button, "Rate manager" link, "History" view). Also disables sub-module entry buttons. |
| `EDIT` | Data-mutation controls: field editors, "Add period", "Change order", "Update" buttons. |
| `DELETE` | Destructive actions: remove, archive, unarchive, unlink buttons. ⚠️ Some features also guard media/drawer access with DELETE. |
| `CREATE` | Creation buttons and empty-state CTA buttons. |
| `EXECUTE` | Special actions beyond CRUD: export, download, replace media. Often used with `*ifPermission` structural directive rather than the pipe. |

---

## Two Syntaxes for the Permission Pipe

```html
<!-- 1. Variable-based (most common — module-level guard) -->
(permissionRoute | ifPermission:'EDIT')
→ permissionRoute comes from store initialState; resolves to parent module code

<!-- 2. Literal string (sub-feature or cross-module guard) -->
('contentmanager.addons.stocks' | ifPermission:'READ')
→ hardcoded code; used when a component checks a permission different from its own route
  e.g. to show/hide a tab, a cross-app link, or a sibling sub-module
```

For every matched store service and template, extract:
- The exact `permissionRoute` value from `initialState`
- Each guarded action by permission type — do not summarise as "standard CRUD":
  - `(permissionRoute | ifPermission:'READ')` → entire section/tab/nav link gated
  - `(permissionRoute | ifPermission:'EDIT')` → data-mutation controls
  - `(permissionRoute | ifPermission:'DELETE')` → destructive actions (remove, archive, unlink)
  - `(permissionRoute | ifPermission:'CREATE')` → creation buttons
  - `(permissionRoute | ifPermission:'EXECUTE')` → special actions (export, download, replace)
  - `*ifPermission="['code', 'TYPE']"` → structural directive form (same semantics)

---

## Full Output Template for the ACCESS CONTROL Block

```
🔐 ACCESS CONTROL

Permission code (newyse):  contentmanager.qualitylevel
Display name:              Content Manager - Quality levels
Module:                    CM_CONTENT_MGR

Frontend enforcement (content-manager-client):

  1. Own-module guards (via permissionRoute variable = 'contentmanager'):
     ← set in quality-level-store.service.ts initialState
     ← resolves against parent module, NOT the sub-permission code

     READ guard:   NOT PRESENT in own module — visibility is controlled by
                   the feature flag only

     EDIT guard:   quality-level.component.html
                   → "Change order" menu item disabled
                   quality-level-details.component.html
                   → Code field read-only

     DELETE guard: quality-level.component.html
                   → "Media" menu item disabled  ← unusual: DELETE gates Media
                   quality-level-details.component.html
                   → "Remove" button disabled
                   → "Archive" / "Unarchive" button disabled

     CREATE guard: quality-level.component.html
                   → "Create quality level" button disabled

  2. Cross-feature guard (literal sub-permission code):
     acco-type-batch-change-selection.component.html
     @if ( batchType == 'ACCOMMODATIONTYPE'
        && hasQualityLevelFlagEnabled
        && ('contentmanager.qualitylevel' | ifPermission:'READ' ) )
     → "Quality level" accordion item in batch update hidden without READ
        (double gate: feature flag AND sub-permission READ must both be true)

Feature flag (newyse):     accommodation.type.qualitylevels.enabled
Default:                   false
Flag enforcement:          own module hidden when off; also used as AND-condition
                           alongside the READ permission in batch update

Backend:                   no @PreAuthorize — access control is frontend-only
```

---

## Orphaned Registration Warning

If a permission or flag code is found in newyse but has zero matches as a literal
string AND the permissionRoute search also fails, flag as orphaned:

```
⚠️ ORPHANED: permission 'x.y' is registered in newyse but no frontend file
   references it as a literal string, and no feature folder uses a matching
   permissionRoute. May be unreleased, renamed, or enforced by a parent module only.
```
