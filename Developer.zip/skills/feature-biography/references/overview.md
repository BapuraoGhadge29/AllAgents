# Feature Biography

Complete feature intelligence for any Maxxton feature, concept, or code. Ask about history, trace bugs to their root, or understand blast radius before making a change — all from a single command.

## Usage

```
/feature-biography <feature name, Jira key, class/method, or plain question>
```

Examples:

```
/feature-biography BFE ID
/feature-biography MXTS-70322
/feature-biography ReservationService
/feature-biography Why does availability skip pricing?
/feature-biography loadGuestProfile --md
```

Add `--md` to save the report as a `.md` file instead of outputting inline.

## What it does

The skill runs a multi-phase investigation across Jira, GitHub, Confluence, and the Maxxton Knowledge graph, then produces a structured **Feature Biography report**.

### Four modes — detected automatically from your question

| Mode | Triggered by | Extra report sections |
|------|-------------|----------------------|
| 📚 **Knowledge** | "what is", "tell me about", "history of", "who built" | Full standard report |
| 🔧 **Improvement** | "improve", "refactor", "enhance", "make it better" | + Blast Radius, + Improvement Opportunities |
| 🐛 **Bug** | "bug", "broken", "not working", "wrong" | + Bug Ancestry chain, + Suspect PRs, + Blast Radius, + Code Diagnostics |
| ⚠️ **Diagnosis** | "behaving incorrectly", "unexpected behaviour", "why is it doing this" | + Bug Ancestry chain, + Suspect PRs, + Blast Radius, + Code Diagnostics |

### Report sections

| Section | Description |
|---------|-------------|
| **Report Freshness** | Last ticket/PR/page dates so you know how current the data is |
| **Bug Ancestry** | Regression chain from root cause to current bug (🐛 / ⚠️ only) |
| **Suspect PRs** | PRs most likely to have introduced the issue (🐛 / ⚠️ only) |
| **Blast Radius** | Direct callers, indirect consumers, shared features — with minimum test scope |
| **Verdict** | 🟢 Living Guard / 🟡 Ticking Bomb / 🔴 Zombie Code / 🔵 Historical Context |
| **Origin** | When introduced, by whom, what triggered it, which era (Maxxton vs. Newyse) |
| **The Story** | Chronological narrative — business context, scope changes, deferred items, key quotes |
| **Decisions Made & Rejected** | Design alternatives considered and why they were accepted or rejected |
| **All Jira Tickets** | Full ticket history across all projects, oldest → newest |
| **Customer Demand** | Non-MXTS tickets that drove the feature (dynamically discovered from issue links) |
| **Where to Find It** | Navigation path, feature flags, permissions, visibility conditions, validation rules |
| **Recent Development** | What is actively in progress or review right now |
| **PR History** | All PRs across all repos, with ticket cross-references and suspect flags |
| **Repositories** | Every repo that touches this feature |
| **API Surface** | REST endpoints and Feign clients (if applicable) |
| **Database Artifacts** | Entities, tables, migrations, Newyse legacy mappings (if applicable) |
| **Unresolved Dependencies** | Open tickets that were meant to follow up on this feature |
| **Linked Incidents** | Production incidents involving this feature |
| **Risk if Modified** | Risk level with specific blast radius detail |
| **Who to Talk To** | Up to 3 ranked contacts — by commit count, original authorship, or bug context |
| **Sources** | All Jira, GitHub PR, and Confluence links cited in the report |

## Required connectors

| Connector | Used for |
|-----------|----------|
| **Atlassian** | Jira ticket history (all projects), Confluence design docs |
| **GitHub MCP** (bundled) | PR history, code search, source file reading |
| **Maxxton Knowledge** | Call graph, service overview, entity usage |

## Read-only — no side effects

This skill never writes to Jira, Confluence, GitHub, or any connected system. It is safe to run at any time.

## Tips

- **Jira key is fastest** — `MXTS-70322` resolves instantly with no disambiguation.
- **Class names work** — `ReservationService`, `BfeIdValidator`, `loadGuestProfile` all route directly to the right code.
- **Plain questions work too** — "Why does availability skip pricing?" is a valid input.
- **Bug mode surfaces the regression chain first** — before the full report, so you often have the likely cause within the first response.
- **`--md` flag** — writes the report to `feature-biography-[name]-[YYYY-MM-DD].md` in the current directory and prints the file path: `/feature-biography MXTS-70322 --md`
