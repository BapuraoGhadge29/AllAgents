---
name: feature-biography
description: "Builds a feature biography for any Maxxton feature, concept or code: history back to the Newyse era, purpose, tickets, PRs, repos and blast radius, as a report. Use when asked \"Why does this code exist?\", \"How was [feature] developed?\", \"Who built this and why?\", or before changing a feature.\n"
disable-model-invocation: true
argument-hint: "[feature name, Jira key, class/method, or question]"
allowed-tools:
- mcp__claude_ai_Atlassian_MCP__getAccessibleAtlassianResources
- mcp__claude_ai_Atlassian_MCP__discover
- mcp__claude_ai_Atlassian_MCP__executeRead
- mcp__claude_ai_Atlassian_MCP__getJiraIssue
- mcp__claude_ai_Atlassian_MCP__searchJiraIssuesUsingJql
- mcp__claude_ai_Atlassian_MCP__atlassianUserInfo
- mcp__claude_ai_Atlassian_MCP__getConfluenceContent
- mcp__claude_ai_Atlassian_MCP__searchConfluence
- mcp__claude_ai_Atlassian_MCP__search
- mcp__claude_ai_Maxxton_Knowledge__search_repo_info
- mcp__claude_ai_Maxxton_Knowledge__search_repo_docs
- mcp__claude_ai_Maxxton_Knowledge__search_technical_graph
- mcp__claude_ai_Maxxton_Knowledge__get_call_chain
- mcp__claude_ai_Maxxton_Knowledge__get_entity_usage
- mcp__claude_ai_Maxxton_Knowledge__get_service_overview
- mcp__plugin_developer_github__search_code
- mcp__plugin_developer_github__get_file_contents
- mcp__plugin_developer_github__search_repositories
- mcp__plugin_developer_github__list_pull_requests
- mcp__plugin_developer_github__get_pull_request
- mcp__plugin_developer_github__list_pull_request_files
- mcp__plugin_developer_github__get_pull_request_reviews
- mcp__plugin_developer_github__list_commits
- mcp__plugin_developer_github__get_commit
- mcp__plugin_developer_github__search_issues
- WebSearch
- AskUserQuestion
- Write
---

# Feature Biography

Complete feature intelligence for any Maxxton feature, concept, or code.
Reconstructs the full story — through every bug, fix, customer demand, and PR —
to today. Produces a detailed, cited, human-readable report optionally saved as
a `.md` file.

---

## Read-Only Rule

**Strictly read-only.** Never write, create, edit, comment on, or modify
anything in Jira, Confluence, GitHub, or any other connected system.

---

## Output Flag

If the user's message contains `--md` or they ask to "save the report" or
"give me a file", use the `Write` tool to save the final report as:
`C:\Users\MahendraRoy\.claude\outputs\feature-biography-[feature-name]-[YYYY-MM-DD].md`
Then tell the user the full path. Otherwise output inline.

---

## Speed Contract

**📚 Knowledge mode: target 5–6 minutes, hard ceiling 10 minutes for very large features.**
**🐛 Bug / ⚠️ Diagnosis / 🔧 Improvement: be thorough — no strict time cap, but stay efficient.**

Maximum tool-call turns by mode:
- 📚 Knowledge: **≤ 3 turns** — Phase 1 → Phase 2 → Phase 8
- 🔧 Improvement: **≤ 5 turns** — Phase 1 → Phase 2 → Phase 6 → Phase 7 → Phase 8
- 🐛 Bug / ⚠️ Diagnosis: **≤ 6 turns** — Phase 0b → Phase 1 → Phase 2 → Phase 6 → Phase 7 → Phase 8

**Rules:**
- Fire every independent search in the **same turn** — never sequence calls that could be parallel.
- Stop early: two consecutive zero-result searches on the same topic = report "not found", move on.
- No speculative reads: only read a file if a prior search confirmed it is relevant.
- Read everything that adds new information — do not stop arbitrarily. A thin report from skipping data is worse than a slower thorough one.
- Customer ticket discovery: only run if issuelinks are visibly present in J1 — not a speculative call.

---

## Workflow

### Phase -1: Input Validation — No Tool Calls

Score the input before any API call:

| Signal | Examples | Action |
|---|---|---|
| ✅ Jira key | `MXTS-70322` | Proceed immediately |
| ✅ Technical term | `BFE ID`, `ReservationService` | Proceed |
| ✅ Domain term | `availability`, `blackout date`, `DAC7` | Proceed |
| ✅ Natural question | `"why does X happen"`, `"how was Y built"` | Proceed |
| ⚠️ Ambiguous single word | `invoice`, `report`, `user` | Ask one clarifying question |
| ❌ Nonsense / too short | `hello`, `test`, `abc` | Stop — do not search |
| ❌ Not a Maxxton concept | `pizza recipe` | Out of scope — stop |

After clarifying an ⚠️ input: run one JQL check (limit 3) to confirm the
feature exists before opening the full pipeline.

---

### Phase 0: Detect Intent — Ask Only When Unclear

| If the user says... | Mode |
|---|---|
| "what is", "tell me about", "explain", "how does", "history of", "who built" | 📚 Knowledge |
| "improve", "enhance", "build on", "refactor", "make it better" | 🔧 Improvement |
| "bug", "broken", "defect", "wrong", "incorrect", "not working", "issue" | 🐛 Bug |
| "behaving incorrectly", "unexpected behaviour", "why is it doing this" | ⚠️ Diagnosis |

Only use `AskUserQuestion` if intent cannot be determined. Mode shapes the report:

| Mode | Extra sections |
|---|---|
| 📚 Knowledge | All standard sections |
| 🔧 Improvement | + BLAST RADIUS, + IMPROVEMENT OPPORTUNITIES |
| 🐛 Bug / ⚠️ Diagnosis | + BUG ANCESTRY, + SUSPECT PRs, + BLAST RADIUS, + CODE DIAGNOSTICS |

---

### Phase 0b: Bug Ancestry — 🐛 Bug / ⚠️ Diagnosis Only (Turn 1 of 6)

**Run this as Turn 1 and surface the chain to the user immediately — before Phase 1.**
This alone solves most bugs in under a minute. Do not wait for user input after
presenting the chain — fire Phase 1 immediately in the next turn.

⚡ **Run both in parallel:**

**B1. Bug tickets:**
```jql
project = MXTS AND issuetype in (Bug, "Bug Fix", Incident)
  AND text ~ "[feature]" AND created >= -365d ORDER BY created DESC
```
If fewer than 3 results, re-run without the date filter. Search window has no
hard limit — go back as far as the chain leads, including Newyse era.

**B2. Bug/fix/revert PRs:**
```
[feature name] fix OR bug OR revert OR regression OR patch in:title,body
```

#### Build and Surface the Chain

Cross-reference B1 tickets with B2 PRs. For each ticket: which PR was linked,
what files changed, was a new bug filed shortly after touching those same files?

Present immediately, oldest → newest:
```
Bug ancestry for: [feature]

  🐛 MXTS-18432 — "Null pointer in guest profile" — 2021-07-03
     ↓ fixed by PR #301 — added null guard @sara.b — 2021-07-05
  🐛 MXTS-44821 — "Pricing skip on new owner" — 2023-11-10
     ↓ fixed by PR #387 — refactored null handling @tom.k — 2023-11-14
  🐛 Current: MXTS-75201 — (what you are investigating)

  👉 Most likely cause: PR #387, ReservationService.java, loadGuestProfile()
```

**Dependency version hint:** If any PR in the chain also changed `pom.xml` /
`build.gradle`, always surface:
```
⚠️ DEPENDENCY HINT: PR #387 (2023-11-14) also updated jackson-databind
   2.13.1 → 2.15.0. This may explain the behavior change you are seeing.
```

If no chain found: "No regression chain found — this appears to be a fresh defect.
Continuing full analysis."

---

### Phase 1: Discovery — One Parallel Turn (Turn 1/2 of ≤6)

> Fire ALL of the following as a **single parallel batch**.

**JIRA — 1 call:** (resolve `cloudId` once via `mcp__claude_ai_Atlassian_MCP__getAccessibleAtlassianResources`; `mcp__claude_ai_Atlassian_MCP__searchJiraIssuesUsingJql`)

**J1. MXTS full ticket history:**
```jql
project = MXTS AND text ~ "[feature]" ORDER BY created ASC
```
Fetch 50. First = origin date, last = most recent.

**GITHUB — 3 calls:**

**G1. Code search:**
```
[feature name or class name] in:file,path
```
Note every unique repository.

**G2. PR search by feature name:**
```
[feature name] in:title,body type:pr
```
Collect 10 most recent.

**G3. API surface search** (skip for 📚 Knowledge if clearly UI-only):
```
[feature name] @RestController OR @FeignClient OR @RequestMapping in:file
```

**CONFLUENCE — 1 call:** (`mcp__claude_ai_Atlassian_MCP__searchConfluence`)

**C1. Design docs:**
```cql
text ~ "[feature]" AND type IN (page) ORDER BY lastModified DESC
```
Limit 10.

**KNOWLEDGE — 2 calls:**

**K1.** `search_technical_graph("[feature]")` + `get_entity_usage("[entity]")`

**K2.** `get_service_overview("[service]")` — only if G1 identified a specific service.

**DB — conditional:**

**D1.** `[feature name] @Entity OR @Table OR @Repository OR CREATE TABLE in:file`
Skip if the feature is clearly computation-only with no persistence.

**FEATURE LOCATION (📚 Knowledge only) — 3 calls:**

**F1.** `[feature name] in:file path:install_featureflag_data.sql repo:MaxxtonGroup/newyse`
Extract: exact `'flag.code'` string and display name. This is authoritative.

**F2.** `[feature name] in:file path:install_permission_data.sql repo:MaxxtonGroup/newyse`
Extract: exact `'perm.code'` string, display name, and module constant.

**F3.** Speculative codebase usage (feature name as fallback — refined in Phase 2f):
```
[feature name] permissionRoute OR ifPermission OR featureFlagService
  OR getFlagValueByCode in:file
```

---

### Phase 2: Deep Reads — One Parallel Turn (Turn 2/3 of ≤6)

> Fire ALL reads in a **single parallel batch**.

**2a. Jira anchor tickets**

Read tickets with `mcp__claude_ai_Atlassian_MCP__getJiraIssue`; it omits comments, so fetch them with `mcp__claude_ai_Atlassian_MCP__executeRead` (`name: listJiraIssueComments`). Other read-only operations (find via `mcp__claude_ai_Atlassian_MCP__discover`, run via `mcp__claude_ai_Atlassian_MCP__executeRead`): `listJiraProjects`, `listJiraIssueRemoteIssueLinks`, `listJiraIssueLinkTypes`, `lookupJiraAccountId` (input `query`).

Read all tickets that add new information to the story. At minimum: the introducing
ticket (oldest), the most recent, and all tickets with substantial comments.
Do not skip a ticket just because you have already read several — each may reveal
scope changes, deferred items, or design decisions the others don't mention.
From each: full description, all comments chronologically, all issuelinks, reporter,
assignee, fix version, sprint. Collect non-MXTS keys from links/comments → fetch those too.
Flag: 🆕 last 90 days, ⚠️ unassigned open. Note if the original author has no
recent Jira activity — orphaned intent risk.

**2b. Confluence pages**

Read pages with `mcp__claude_ai_Atlassian_MCP__getConfluenceContent` (`detail: full`). Read-only operations via `mcp__claude_ai_Atlassian_MCP__executeRead`: `listConfluenceSpaces`, `listConfluenceContent` (`type: page`, `spaceId`), `getConfluenceContentDescendants` (`contentId`), `listConfluenceComments` (`content-id`, `comment-type: inline|footer`). For cross-product search use `mcp__claude_ai_Atlassian_MCP__search`.

Read every page that passes the quality filter:
- ✅ ADRs, retrospectives, design docs, runbooks — >500 words or linked from Jira
- ✅ Older pages with rich content — may hold original design intent unavailable elsewhere
- ❌ Stubs <30 days old with <3 paragraphs
- ❌ Pure link tables with no prose

Always cite the last-modified date. Do not skip a quality page to save time.

**2c. PR search by ticket keys — all keys**

For every MXTS ticket key from J1, run:
```
MXTS-XXXXX in:title,body type:pr
```
Run all in parallel. Merge with G2 results, deduplicate by PR number.
Flag tickets with no linked PR: "⚠️ MXTS-XXXXX — no PR found in GitHub."

**2d. PR detail reads**

Read the introducing PR (oldest), the most recent PR, and **every suspect PR**
(hotfix branch, "revert", "NPE", "workaround", Friday merge, no-ticket PR).
Do not skip a suspect PR — these are exactly the ones most likely to contain the
cause of a bug or an undocumented decision.
For each: `get_pull_request` + `list_pull_request_files` + `get_pull_request_reviews`.
Check if `pom.xml`/`build.gradle` changed in the same PR → dependency hint.

**2e. API surface — synthesise from G3**

Extract HTTP method + path, controller class + method, Feign client interfaces.
If G3 found nothing: state "No public API surface found."

**2f. Feature Location — 📚 Knowledge only, from F1+F2+F3**

Read matched lines from F1+F2 to extract exact codes and display names.
Then run two permission searches in parallel using the exact codes:
- **Search A** (literal sub-permission, org-wide):
  `('[perm.code]' | ifPermission) repo:MaxxtonGroup/[frontend-repo]`
- **Search B** (permissionRoute variable in feature folder):
  `permissionRoute path:[feature-folder] repo:MaxxtonGroup/[frontend-repo]`

See [permission-patterns.md](references/permission-patterns.md) for full
pattern guide, ifPermission type table, and output template.

Derive UI navigation path from frontend routes or Jira ticket descriptions.
Report: flag display name (flag.code) and permission display name (perm.code).
If nothing found for a code: state explicitly — do not invent.

**2g. DB artifacts — from D1**

Extract: entity class + table name, key columns, repository interface, migration
file + date. Newyse table/column mapping only if oldest MXTS ticket is pre-2022.
If nothing found: state so.

**BUG ANCESTRY chain — 🐛 Bug / ⚠️ Diagnosis only**

Using B1+B2 from Phase 0b, cross-reference bug tickets with their fix PRs and build
the full chain (already surfaced in Phase 0b — include in the final report too).

---

### Phase 6: Code Analysis — 🐛 Bug / ⚠️ Diagnosis / 🔧 Improvement Only (Turn 3/4)

> Only read files confirmed in G1. Read all relevant source files + their tests. One parallel turn.

**6a.** Read production file + corresponding test file side by side.
Missing tests for the buggy scenario = a finding.

**6b. Blast Radius** — `get_call_chain` (inbound) + `get_entity_usage`:
list direct callers, indirect consumers, shared features. State minimum test scope.

**6c. Diagnostics by mode:**

*🐛 Bug / ⚠️ Diagnosis:* Null reference risks, silent failures, race conditions,
data type issues (float for money), service contract violations, test coverage gaps.

*🔧 Improvement:* Long methods, N+1 queries, unbounded list loads, sync calls
that could be async, business logic paths with no tests.

Each finding: file + method + specific risk + suggested fix. Risk-rated:
🔴 critical / 🟡 medium / 🟢 low.

---

### Phase 7: Who to Talk To (Turn 4/5)

Show max 3 contacts ranked: most PR commits on this feature's files → original
author → tester/bug reporter. Derive activity from recency (last Jira activity
or commit within 12 months = active). Only call `mcp__claude_ai_Atlassian_MCP__atlassianUserInfo` if a
person's current status is genuinely ambiguous after checking recency.

---

### Phase 8: Report (final turn)

Produce the full report following the [report template](references/report-template.md).

---

## Reference Files

- [Overview](references/overview.md) — Usage, examples and modes for people browsing the skill.
- [Report template](references/report-template.md) — Full output
  template with all section headers, field labels, format rules, verdict types,
  and guidance for handling incomplete evidence.
- [Permission patterns](references/permission-patterns.md) — Complete
  Phase 2f permission guide: two-search approach, ifPermission type table, pipe
  syntax examples, full ACCESS CONTROL output template, orphaned registration warning.
