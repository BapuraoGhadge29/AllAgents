---
name: refactoring-code
description: Find and remove dead code — unused imports, unreachable methods, stale dependencies, and orphaned files in a specified directory or recently changed files. Use '/refactoring-code' when removing dead code, unused imports, or orphaned files.
disable-model-invocation: true
argument-hint: "[file, directory, or 'recent']"
allowed-tools:
- Read
- Write
- Edit
- Bash
- Grep
- Glob
- mcp__claude_ai_Maxxton_Knowledge__search_technical_graph
- mcp__claude_ai_Maxxton_Knowledge__get_entity_usage
---

# Refactor and Cleanup

Identify and remove dead code, unused imports, unreachable methods, and stale dependencies in a targeted area of the codebase. Uses confidence levels to avoid removing code that may be used via reflection or Spring dependency injection.

## Step 1: Determine Scope

Parse the user's input to determine what to scan:

- **File path** (e.g. `src/main/java/com/example/Service.java`) → scan that file
- **Directory** (e.g. `src/main/java/com/example/`) → scan all source files in that directory
- **"recent"** → run `git diff main...HEAD --name-only` to get changed files. If no commits on the branch yet, fall back to `git diff --name-only`

Report the scope:
> **Scope:** 12 files in `src/main/java/com/example/service/`

---

## Step 2: Scan for Dead Code

For each file in scope, check the following categories:

### 2a. Unused Imports

- **Java:** imports not referenced in the file body
- **TypeScript/JavaScript:** imports not referenced in the file body, including type-only imports

### 2b. Unreachable Methods

For each non-private method or exported function in the scoped files:
1. Grep the entire project for callers, excluding the method's own definition line and test files, but including genuine call sites from the same file
2. Check for framework annotations that indicate indirect usage:
   - `@RequestMapping`, `@GetMapping`, `@PostMapping`, etc. → called by Spring MVC
   - `@Scheduled`, `@EventListener`, `@Bean` → called by Spring container
   - `@Override` → called via interface/superclass contract
   - `export default` in React → imported by bundler
3. If zero callers and no framework annotation → candidate for removal

### 2c. Commented-Out Code

Detect blocks of 3+ consecutive commented lines that appear to be code (contain keywords like `if`, `for`, `return`, `function`, `class`, variable assignments).

Single-line comments and documentation comments are not flagged.

### 2d. Stale Dependencies

- **Gradle:** read `build.gradle` `dependencies` block. For each dependency, grep the source tree for its package imports. Flag dependencies with zero imports.
- **npm:** read `package.json` `dependencies` and `devDependencies`. For each package, grep for `require('pkg')` or `from 'pkg'`. Flag packages with zero references.

---

## Step 3: Assign Confidence Levels

For each finding, assign a confidence level:

| Level | Meaning | Criteria |
|-------|---------|----------|
| **HIGH** | Certain dead code | Zero callers, no reflection risk, no framework annotations, no `@Deprecated` |
| **MEDIUM** | Likely dead | Zero callers but possible reflection/Spring DI usage, or `@Deprecated` with no callers |
| **LOW** | Suspicious | Commented-out code blocks, dependencies with indirect usage patterns |

### Maxxton-Specific Checks

Before finalizing confidence:
1. For multi-module Gradle projects, grep sibling modules too — a method may be called cross-module
2. Query the technical graph (`mcp__claude_ai_Maxxton_Knowledge__search_technical_graph`, then `mcp__claude_ai_Maxxton_Knowledge__get_entity_usage` on the symbol) for callers outside this repo — some interfaces are implemented in other services. Skip if the graph is unavailable.
3. If a method implements an interface from a shared library, downgrade to LOW even if zero callers found locally

---

## Step 4: Present Findings

Group findings by category and confidence:

```
## Refactor & Cleanup — src/main/java/com/example/service/

### HIGH Confidence (safe to remove)
- [x] `UserService.java:45` — unused import `java.util.HashMap`
- [x] `OrderProcessor.java:112-134` — method `calculateLegacyDiscount()` has zero callers
- [x] `build.gradle` — dependency `commons-io` has zero imports

### MEDIUM Confidence (likely safe)
- [ ] `EventHandler.java:67-89` — method `handleLegacyEvent()` has zero callers but implements `EventListener` interface
- [ ] `build.gradle` — dependency `spring-boot-starter-actuator` only used via auto-configuration

### LOW Confidence (review manually)
- [ ] `PaymentService.java:23-31` — 9 lines of commented-out code (legacy payment flow)
```

HIGH items are pre-selected (marked `[x]`). MEDIUM and LOW items are unchecked — the user must explicitly select them.

**Wait for the user** to confirm which items to remove.

---

## Step 5: Apply Changes

1. Apply the approved removals
2. Run the build to verify nothing broke:
   - Gradle: `./gradlew build`
   - npm: `npm run build && npm test`
3. If the build fails, revert the last change and re-present with downgraded confidence

---

## Step 6: Summary

After successful cleanup:

```
## Cleanup Summary

Removed 23 lines across 4 files:
- 3 unused imports
- 1 dead method (22 lines)
- 1 stale dependency

Build: PASSED
```

---

## Tips

- **Don't remove `@Deprecated` methods with callers** — they're deprecated, not dead
- **Be cautious with Spring beans** — a class with zero direct callers may be injected via `@Autowired` or `@Bean`
- **Check test coverage** — if a method is only called from tests, it may still be dead (tests written for dead code)
- **Serialization** — fields used for JSON/XML serialization (Jackson, JAXB) may appear unused but are accessed via reflection

## Examples

User says: "/refactoring-code"
Claude identifies code smells in the specified files and applies minimal, behaviour-preserving refactors.

## Troubleshooting

- **Tests fail after refactor**: revert and re-examine the code path before re-applying the change.
- **Scope too large**: ask the skill to refactor one class or method at a time.
