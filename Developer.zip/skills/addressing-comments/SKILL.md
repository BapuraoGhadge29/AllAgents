---
name: addressing-comments
description: Process and resolve GitHub PR review comments — reads feedback threads, applies requested code changes, and posts replies to mark threads resolved. Use '/addressing-comments' when addressing review comments on a GitHub PR.
argument-hint: "[GitHub PR URL]"
allowed-tools:
- mcp__claude_ai_GitHub__pull_request_read
- mcp__claude_ai_GitHub__add_reply_to_pull_request_comment
- Bash
- Read
- Edit
- Write
- Grep
- Glob
---

# Address PR Review Comments

Structured workflow for checking out a PR branch, reading all review comments, validating each one, making code changes, replying with decisions, resolving threads, and pushing.

## 7-Step Workflow

### Step 0: Check out PR branch

**Parse the PR URL** to extract owner, repo, and PR number.

Use GitHub MCP `pull_request_read` to fetch:
- PR head branch name
- PR base branch name
- PR title and description

**Switch to the PR branch:**

```
git fetch origin {head_branch}
git checkout {head_branch}
git pull origin {head_branch}
```

**Verify clean working tree** with `git status`. If there are uncommitted changes, warn the developer:

> Your working tree has uncommitted changes. Please commit or stash them before proceeding.

Wait for the developer to resolve before continuing.

---

### Step 1: Read review comments

Use GitHub MCP `pull_request_read` (`get_review_comments`) to fetch all review threads on the PR.

**Important:** The MCP tool does not return thread node IDs needed for resolving threads. Fetch them separately via GraphQL:

```
gh api graphql -f query='
  query {
    repository(owner: "{owner}", name: "{repo}") {
      pullRequest(number: {pr_number}) {
        reviewThreads(first: 100) {
          pageInfo { hasNextPage endCursor }
          nodes {
            id
            isResolved
            comments(first: 10) {
              nodes {
                databaseId
                path
                line
                body
                author { login }
              }
            }
          }
        }
      }
    }
  }
'
```

If `pageInfo.hasNextPage` is `true`, re-run the query with `reviewThreads(first: 100, after: "{endCursor}")` until all threads are fetched.

Match each thread's `id` (the node ID) to the MCP comment data using `databaseId`, `path`, and `line`. Store the thread node ID for each comment — it is required in Step 6 to resolve threads.

Focus on **unresolved** threads. For each thread, extract:
- Thread node ID (from the GraphQL query above)
- Comment database ID (for replying via MCP)
- Comment author
- File path and line number
- Comment body (the suggestion or question)
- Whether it is part of a review or a standalone comment

Present a **numbered summary grouped by file**:

```
## Unresolved Review Comments

### src/main/java/com/example/UserService.java
1. @reviewer (L45): "Consider using batch fetch instead of N+1 loop"
2. @reviewer (L120): "Missing null check on userId parameter"

### src/test/java/com/example/UserServiceTest.java
3. @reviewer (L30): "Add edge case test for empty input"

### General (no file reference)
4. @reviewer: "Should we update the README for this new endpoint?"
```

If there are no unresolved comments, inform the developer:

> No unresolved review comments found on this PR. Nothing to address.

Stop here.

---

### Step 2: Validate each comment

For each unresolved comment:

1. **Read the referenced code context** using the Read tool (file + surrounding lines)
2. **Evaluate the suggestion** against:
   - Code correctness and best practices
   - Whether the suggestion is technically accurate
   - Whether the change is in scope for this PR
3. **Classify** as one of:
   - **Will fix** — The suggestion is valid and should be implemented
   - **Will discuss** — The suggestion has merit but needs discussion (trade-offs, scope concerns, alternative approaches)
   - **Won't fix** — The suggestion is incorrect, out of scope, or not applicable (provide reasoning)

---

### Step 3: Present action plan

Present the classification as a table and **wait for user confirmation**:

```
## Action Plan

| # | File | Comment | Classification | Reason |
|---|------|---------|---------------|--------|
| 1 | UserService.java:45 | Use batch fetch | Will fix | Valid N+1 concern |
| 2 | UserService.java:120 | Add null check | Will fix | Defensive coding |
| 3 | UserServiceTest.java:30 | Add edge case test | Will fix | Improves coverage |
| 4 | General | Update README | Won't fix | Out of scope for this PR |

Shall I proceed with these actions?
```

**Wait for explicit confirmation** before making any changes. If the developer wants to reclassify any items, update the plan accordingly.

---

### Step 4: Make code changes

For each item classified as **Will fix**:

1. Open the file and make the requested change using the Edit tool
2. Verify the change is correct and does not break surrounding code

After all changes are made:

```
git add {changed files}
git commit -m "Address PR review comments

- {brief description of each fix}"
```

---

### Step 5: Reply to each comment

For each review thread, use GitHub MCP `add_reply_to_pull_request_comment` to post a concise, professional reply:

**For "Will fix" items:**
> Fixed in {commit SHA short}. {Brief description of what was changed.}

**For "Will discuss" items:**
> {Explanation of the trade-off or concern. Proposal for how to proceed.}

**For "Won't fix" items:**
> {Professional explanation of why the suggestion was not applied — e.g., out of scope, alternative approach preferred, or technical reasoning.}

Keep replies concise and constructive. Never be dismissive of feedback.

---

### Step 6: Resolve threads and push

**Ask for confirmation before pushing:**

> Ready to push {N} commit(s) to `{branch}` and resolve addressed threads. Proceed?

Wait for explicit confirmation.

**Push changes:**

```
git push origin {head_branch}
```

**Resolve addressed threads (best-effort):**

For each thread classified as "Will fix" that has been addressed, attempt to resolve the thread using the `gh` CLI:

```
gh api graphql -f query='
  mutation {
    resolveReviewThread(input: { threadId: "{thread_node_id}" }) {
      thread { isResolved }
    }
  }
'
```

If `gh` is not available or the mutation fails, skip gracefully and inform the developer:

> Could not auto-resolve threads (gh CLI not available or insufficient permissions). You can resolve them manually on GitHub.

**Present final summary:**

```
## Summary

- Addressed: {N} comments
- Replied to: {N} threads
- Resolved: {N} threads (or "skipped — resolve manually")
- Pushed: {commit SHA short} to {branch}

PR: {PR URL}
```

---

### Step 7: Distill lessons into memory

After the summary, review every comment that was classified as **Will fix** or **Will discuss**. For each one, ask: *is this a repeatable, non-obvious pattern that would apply to future PRs beyond this ticket?*

**Bar for saving — only save if ALL of the following are true:**
- The issue is non-obvious (not already covered by CLAUDE.md or an existing memory entry)
- It would realistically recur in future work
- It reflects a pattern, not a one-off mistake

**Skip if:**
- It is ticket-specific (e.g. a wrong variable name in a specific context)
- It is already documented in CLAUDE.md or `memory/`
- It is a "Won't fix" item (invalid comment — no lesson to learn)

**For each lesson worth saving**, check the project memory directory for existing feedback files. If an existing entry covers the same pattern, update it rather than creating a new file. Otherwise create a new `feedback_*.md` file using this format:

```markdown
---
name: addressing-comments
type: feedback
---

[Rule: what to do or avoid]

**Why:** [the reviewer's concern or the bug it caused — reference the PR number for traceability]
**How to apply:** [the situation in which this guidance kicks in]
```

Add or update the pointer in `MEMORY.md`.

If no comments meet the bar, state: *"No new lessons extracted — all feedback was ticket-specific or already covered."*

---

## Tips

- **Dirty working tree:** If the developer has uncommitted changes, ask them to commit or stash before starting. Do not proceed with a dirty working tree.
- **Large PRs:** If there are many review threads, process them in batches grouped by file to keep the workflow manageable.
- **Outdated threads:** Some threads may reference code that has already changed. Check the current file content before classifying — the issue may already be resolved.
- **General comments:** Comments without a file reference (posted on the PR conversation tab) should still be included in the summary and classified, but they may not require code changes.
- **Partial addressing:** If the developer only wants to address some comments now, respect their selection in Step 3 and skip the rest.

## Instructions

Invoke with "/addressing-comments" in Claude Code. The skill guides you through the workflow step by step.

## Examples

User says: "/addressing-comments"
Claude reads all open review comments on the current PR branch and applies targeted code changes to address each one.

## Troubleshooting

- **No comments found**: confirm the branch has an open PR with unresolved review comments.
- **Wrong files modified**: check that the skill is running on the correct branch.
