---
paths:
  - "**/Dockerfile"
  - "**/Dockerfile.*"
  - "**/*.dockerfile"
  - "**/Containerfile"
---

# Dockerfile Pinned Versions

Pin every external base image in a `FROM` line to a literal, full `MAJOR.MINOR.PATCH` tag — no `ARG` or other variable inside the reference, no `latest`, no missing tag.

- Keep the variant prefix and suffix, but keep an OS suffix generic: `node:22.11.0-alpine`, not `node:22-alpine` or `node:22.11.0-alpine3.20`; `apache/airflow:slim-3.2.2-python3.10`. Dependabot only moves to tags with exactly the same suffix, so `-alpine3.20` stops updating once Alpine 3.20 builds stop.
- For an image without semver tags (e.g. distroless), pin a digest: `image:tag@sha256:<digest>`.
- `scratch`, references to an earlier build stage, and a `FROM ${IMAGE}` whose whole image is a build arg passed by the pipeline need no pin. The pipeline owns that pin.
- Look up a tag that exists before writing it: `docker manifest inspect <image>:<tag>`, or the registry's tag list. Never guess a version number. If you cannot verify one, ask the user which version to pin.
- Resolve an existing partial pin to the newest release it already covers (`node:22` → newest `22.x.y`). Do not change the major version unless asked.

Every `ARG` that pins a tool version (`ARG <NAME>_VERSION=<version>`) gets a Renovate comment on the line directly above it, so the self-hosted Renovate keeps it current:

```dockerfile
# renovate: datasource=npm depName=@anthropic-ai/claude-code
ARG CLAUDE_CODE_VERSION=2.1.292
# renovate: datasource=github-release-attachments depName=cli/cli
ARG GH_VERSION=v2.101.0
ARG GH_SHA256=9bca2d1c16825f109907a23307628a2f0698fbf99662b73a5cf0b020293072b8
```

- Use the datasource that really publishes the tool (`npm`, `pypi`, `github-releases`, `github-tags`, `docker`, ...) and its exact `depName`; look it up, never guess. Optional fields, in this order: `versioning=`, `extractVersion=`.
- With `github-release-attachments`, put `ARG <NAME>_SHA256` directly below the version; Renovate updates both. The version must be the release tag as written, `v` included.
- One `*_VERSION` per `ARG` line. An `ARG` without a default is set by the pipeline and needs no comment.
- `# renovate: ignore <reason>` opts a version out on purpose.

## Why

Dependabot bumps a Docker tag only at the precision it already has. `node:22` gets no patch PRs: the tag moves under us silently, so images change without review. `ARG`-based and `latest` tags get no PRs at all. A full patch tag gives one reviewable Dependabot PR per update, and the update policy (which bumps to allow or ignore) lives in `dependabot.yml`. Dependabot cannot see versions in `ARG`s at all; Renovate (MaxxtonGroup/renovate) updates only the ones carrying its comment.

The `dockerfile-pin-guard` hook blocks edits that break either part of this rule.
