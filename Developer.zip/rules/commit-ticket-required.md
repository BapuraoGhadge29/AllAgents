# Commit Ticket Required

1. **Never** invent a ticket number.
2. Call `AskUserQuestion` with two options:
   - **Provide ticket** — user pastes an existing key.
   - **Create ticket** — invoke `/global:creating-jira-tickets`, seeded with the
     current conversation (plan, diff, recent decisions).
3. Once a real key is in hand, prepend it to the commit message and retry.

Applies when committing without a Jira ticket (or after the commit-msg hook blocks one).
