# Protected Branches

The following branches are protected — **never commit directly to them**:
`main`, `master`, `develop`, `release/*`

When you would otherwise commit to a protected branch:

1. Stop and inform the user that direct commits to this branch are not allowed.
2. Offer to use `/starting-ticket-branch` to create an appropriate branch and continue.
3. **Never** use `--no-verify` to bypass the pre-commit hook.

This holds even when the user explicitly asks to commit directly to a protected branch.
