---
paths:
  - "**/*.component.spec.ts"
---

# angular-component-tests

Add `import '@angular/localize/init'` at the top of any spec for a component that calls `$localize`. Without it the component fails silently at runtime in tests.

- Configure TestBed with `imports` for standalone components. Use `declarations` only for legacy `standalone: false` components.
- Set `schemas: [NO_ERRORS_SCHEMA]` to isolate the component from large child module trees such as `ComponentsModule`.
- For signal inputs created with `input()`, set values via `fixture.componentRef.setInput('name', value); fixture.detectChanges();`. For legacy `@Input()` properties, assign directly on the component instance.
- Test outputs by spying on `emit` — this works for both `output()` signals and `@Output() EventEmitter`.
- Mock injected services with minimal `useValue` objects. For store services injected via DI that the component reads from but does not write to, supply `{}` and assign state directly.
- For narrow getter, computed, or translation tests on `@StoreAware` components, assign state directly on the instance (`component.contextState = { ... } as any`) instead of wiring the full store — full wiring is unnecessary at that scope.
