# planning

Before finalizing any plan:

1. **Gather relevant instructions.** Check available skills (via whatever discovery mechanism this environment provides), this CLAUDE.md, rules in `.claude/rules/**.md`, project docs, and the user's current request. Keep only the rules that affect *how* the task is done — skip stylistic defaults.

2. **Order by dependency.** Prerequisites (reading a skill, checking a constraint, verifying a fact) come before the actions that rely on them. Verification comes last.

3. **Surface conflicts up front.** If two instructions disagree, lead the plan with the conflict and ask before proceeding rather than silently picking one.

Present the plan as clean steps describing how the task will be carried out. Append a short "Governing rules" section at the end listing the instructions that shaped the plan and, where useful, which step each one applies to.

When opening a pull request as part of any workflow, always use `--draft` (`gh pr create --draft`). Never mark a PR ready-for-review automatically.
