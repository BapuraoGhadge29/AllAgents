# pr-creation-required

Open the pull request yourself once the work is committed and pushed. Never hand pull-request creation back to the developer because a review is outstanding.

Run `gh pr create --draft`. When a pre-PR gate denies it, run the review named in the deny message, then retry the same command. Report the PR URL, not a branch name.

Leave the pull request in draft. Mark it ready with `gh pr ready` only once CI is green, Copilot has posted its review, and every Copilot comment is resolved; a hook enforces all three. A draft that is ready too early pulls reviewers onto work that is still moving.

Stop and ask only when the developer said not to open a PR, or when the review reports findings you cannot address.

A pushed branch with no PR is invisible to CI and reviewers.
