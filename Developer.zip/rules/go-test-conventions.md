---
paths:
  - "**/*_test.go"
---

# go-test-conventions

Place test files next to the source they cover, with the `_test.go` suffix. Pick the package deliberately: `package foo` for white-box tests that need internal access, `package foo_test` for black-box tests that consume only the public API.

- Name test functions `Test{Subject}{Behavior}When{Condition}` (e.g. `TestCalculateTotalAppliesDiscountWhenNightsAtLeastSeven`). One behavior per `Test…` function — split rather than branch.
- Call `t.Parallel()` only on tests that are genuinely independent. Never call it inside a sub-test that shares mutable state with its siblings.
- Run a single test: `go test ./pkg/x -run TestX -v`. Run the full suite: `go test ./...`. Add `-race` whenever the code under test uses goroutines, channels, or shared state: `go test -race ./...`.
