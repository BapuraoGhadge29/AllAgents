# ci-monitor-review-comments

When a user message contains a `<ci-monitor-event>` tag carrying new PR review comments, invoke `/developer:addressing-comments` for the PR before any other action. It runs in this session, so it reasons about each comment against your context, then reads, replies, resolves, and pushes — its built-in confirm-and-push gates keep a human in control.

**Resolving `<PR-URL>`:** the skill's argument is a GitHub PR URL, but a `<ci-monitor-event>` payload identifies the PR by number. Build the URL as `https://github.com/<owner>/<repo>/pull/<pr>` from the event's `owner` and `repo` fields; if the event omits them, fall back to the repository the monitor is watching, and if neither is available, ask the developer for the PR URL. Never invoke the skill with a bare PR number — resolve the full URL first.

Do not read the comments manually, draft replies, or edit code yourself instead of invoking the skill — that skips required steps and risks dropping comments on the floor.

The rule only fires when the event payload type is `new_review_comments`. Other event types (`build_failed`, `merge_conflict`, etc.) route to their own skills.

## Promotion check

Run after `addressing-comments` completes for a `new_review_comments` event, or immediately on a `ci_passed` event. Run all four checks in order. Report the first failure and stop; take no further action. Do not ask for confirmation.

**1. Still a draft?**
```
gh pr view <pr> --repo <owner>/<repo> --json isDraft -q .isDraft
```
Must return `true`.

**2. Copilot has reviewed?**
```
gh pr view <pr> --repo <owner>/<repo> --json reviews --jq '[.reviews[]|select(.author.login|ascii_downcase|startswith("copilot"))]|length'
```
Must return > `0`.

**3. All threads resolved?** (`gh pr view --json reviewThreads` is unsupported — use GraphQL; fail closed if >100 threads)
```
gh api graphql -F owner='<owner>' -F repo='<repo>' -F pr=<pr> \
  -f query='query($owner:String!,$repo:String!,$pr:Int!){repository(owner:$owner,name:$repo){pullRequest(number:$pr){reviewThreads(first:100){pageInfo{hasNextPage}nodes{isResolved}}}}}' \
  --jq 'if .data.repository.pullRequest.reviewThreads.pageInfo.hasNextPage then 1 else ([.data.repository.pullRequest.reviewThreads.nodes[]|select(.isResolved==false)]|length) end'
```
Must return `0`.

**4. CI is green?**
```
gh pr view <pr> --repo <owner>/<repo> --json statusCheckRollup \
  --jq '[.statusCheckRollup[]|select((.conclusion//.state)|. != "SUCCESS" and . != "NEUTRAL" and . != "SKIPPED")]|length'
```
Must return `0`.

If all four pass:
```
gh pr ready <pr> --repo <owner>/<repo>
```
