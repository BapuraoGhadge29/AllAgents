# clarify-before-acting

When a task is unclear, incomplete, or has conflicting requirements — stop before writing any code or making changes.

**IMPORTANT: Do not guess. Do not proceed with a silent assumption.**

Instead:
1. Name the specific thing that is unclear
2. Present the options if there are obvious ones
3. Ask one focused question and wait for the answer

This applies at the start of a task AND mid-task when something unexpected is unclear.

**Examples of when to stop and ask:**
- A ticket mentions multiple portals but does not say which one
- The request conflicts with existing code patterns
- Scope is unclear (one service? all services?)

**Do not:**
- Pick one interpretation silently and hope it is right
- Mention assumptions only at the end after doing the work
- Ask several questions at once