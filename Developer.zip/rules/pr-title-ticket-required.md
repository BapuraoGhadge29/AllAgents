# Pr Title Ticket Required

Every pull request title must include a Jira ticket key, e.g.:

```
MXTS-1234: short description
MCMS-42: short description
```

The key must match `[A-Z]{2,4}-[0-9]+` and should be the ticket the branch is
for (derive it from the branch name — `feature/<ticket>`, `bugfix/<ticket>`,
`hotfix/<ticket>`).

1. **Never** invent a ticket number. If no ticket exists, follow
   `commit-ticket-required` — ask the user to provide a key or create one via
   `/global:creating-jira-tickets` before opening the PR.
2. Put the key at the **start** of the title so it is unambiguous.
3. Name no other ticket's key in the title or body. Refer to another ticket in
   words, or write its key with a non-breaking hyphen (`MXTS‑1234`, U+2011),
   which reads the same but Jira does not match. If the PR implements that
   ticket too, put its key in the title.

Why 3: the GitHub for Jira app links a PR to every key in its text. A key quoted
as context ("part of epic …", "out of scope …", "the earlier fix …") puts the PR
in that unrelated ticket's development panel.

Applies when creating or editing a PR with `gh pr create`, `gh pr edit` or the
GitHub MCP tools. Getting this right up front avoids the `pre-pr-review` and
`pr-foreign-key-guard` PreToolUse hooks denying it — those hooks are safeguards,
not the primary control.
