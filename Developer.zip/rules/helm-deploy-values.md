---
paths:
  - "**/deploy*.yml"
  - "**/deploy*.yaml"
---

# helm-deploy-values

Gather full chart and deploy-config context before writing values — never guess keys. These are Helm value files for charts in [MaxxtonGroup/helm-charts](https://github.com/MaxxtonGroup/helm-charts).

## 1. Detect the chart

Read the `chart:` block (`name`, `version`). `version` is a semver major; resolve it to the latest tag `<name>-v<major>.<minor>.<patch>`, failing closed if none matches. `REPO` is the deploying repository's name.

```bash
NAME=tf-app MAJOR=3 REPO=booking-service
TAG=$(gh api repos/MaxxtonGroup/helm-charts/tags --paginate --jq "[.[].name | select(startswith(\"$NAME-v$MAJOR.\"))] | sort_by(split(\".\") | map(tonumber? // 0)) | last")
[ -n "$TAG" ] || { echo "no $NAME-v$MAJOR tag" >&2; exit 1; }
```

## 2. Fetch chart files at that tag

From `chart/$NAME/` at `$TAG`, read `values.yaml`, `values.schema.json`, `README.md`, `docs/`, `examples/`. Fetch raw (no base64 decode) into the local files the merge consumes:

```bash
gh api -H "Accept: application/vnd.github.raw" "repos/MaxxtonGroup/helm-charts/contents/chart/$NAME/values.yaml?ref=$TAG" > chart-values.yaml
gh api -H "Accept: application/vnd.github.raw" "repos/MaxxtonGroup/helm-charts/contents/chart/$NAME/values.schema.json?ref=$TAG" > values.schema.json
```

## 3. Discover the project

```bash
PROJECT=$(gh api repos/MaxxtonGroup/$REPO/properties/values --jq '.[] | select(.property_name=="project") | .value')
[ -n "$PROJECT" ] || { echo "no 'project' property on $REPO" >&2; exit 1; }
```

## 4. Fetch inherited deploy-config values

`env` is unknown — list every config for this repo, then read each. Source: `https://github.com/MaxxtonGroup/deploy-config/blob/master/dist/<project>-<repo>-<env>.yml`

```bash
gh api repos/MaxxtonGroup/deploy-config/contents/dist --jq ".[].name | select(startswith(\"$PROJECT-$REPO-\"))"
```

## 5. Write and verify

Write valid keys using the schema, chart values, README, and examples. Set `ENV` to the deploy file's environment, then merge in override order — chart values, `deploy.y(a)ml`, `deploy-$ENV.y(a)ml`, deploy-config — and validate against the schema:

```bash
ENV=prod
yq eval-all '. as $i ireduce ({}; . * $i)' \
  chart-values.yaml deploy.yml "deploy-$ENV.yml" "$PROJECT-$REPO-$ENV.yml" \
  -o=json > merged.json
npx ajv-cli validate -s values.schema.json -d merged.json
```
