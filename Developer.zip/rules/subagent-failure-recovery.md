# subagent-failure-recovery

Confirm the artefact a subagent's "done" claim names before trusting or forwarding it, and after two failed attempts on the same subtask, stop and escalate to the user.

A subagent reports what it intended to do, not what happened. Check that:
1. The file it changed holds the change — not an empty or stub edit
2. The test, build, or check it says passed actually passes when you run it
3. The Jira ticket, PR comment, or log entry it references actually exists

A claim that fails this check is a failed run, not a success — recover from it, do not report it as done.

When a subagent fails, times out, goes silent, or its output fails verification:
1. Capture the failure context — input, error message, partial output
2. Diagnose before retrying — read the error, do not resend the same prompt or hand it to another subagent unexamined
3. Change something on retry — smaller scope, different agent, clearer prompt, or a manual workaround
4. Hard stop at 2 failed attempts on the same subtask. Escalate with what was tried, what failed, and where you are stuck

Example: a subagent reports a fixed build, but `gradle build` still fails when you run it.
