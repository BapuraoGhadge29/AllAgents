---
paths:
  - "**/src/test/java/**/*Test.java"
---

# java-unit-tests

Mirror the production class location under `src/test/java/` and name the class `{ProductionClass}Test`. Name test methods `methodName_state_expected` (e.g. `findById_nonExistingId_returnsEmpty`). Drop `@DisplayName` — the name self-documents.

- Test methods are package-private `void`, never `public`. No Javadoc.
- Body uses Arrange-Act-Assert with blank-line separators. One behavior per test.
- Use `@ExtendWith(MockitoExtension.class)`; `@Mock` for deps, `@InjectMocks` for SUT. Initialize state in `@BeforeEach`, never in a constructor.
- Use JUnit Jupiter assertions: `Assertions.assertEquals`, `assertNotNull`, `assertThrows`. Compare `BigDecimal` with `compareTo`, not `assertEquals` — `assertEquals` is scale-sensitive.
- Verify interactions with `verify(mock, times(n))`. Use `verifyNoInteractions(mock)` when something must NOT happen.
- Use the `XxxTestObjects` fixture pattern per aggregate: a class with `public static` fields reset by an `initObjects()` method called from `@BeforeEach`.
- Reach for `ArgumentCaptor<T>` when asserting on complex arguments, `lenient().when()` for optional stubs, and `doThrow()` / `doNothing()` / `doAnswer()` for void methods. Chain `thenReturn(a, b, c)` for successive calls.
- Skip tests that have no value: Lombok getters, MapStruct mappers, JPA basic CRUD, Spring DI wiring, trivial setters. Do not test private methods directly — exercise them through the public API.
- Single test: `./gradlew test --tests "fqcn.ClassTest.method_state_expected"`. Full suite: `./gradlew test`. Always use `./gradlew`, never the system `gradle`.
