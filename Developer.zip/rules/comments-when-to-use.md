# Comments When To Use

Comment the current constraint, not the change. Never narrate an edit — no
"previously this did X", "changed to Y", "this used to be", "fixed the bug where".
Skip comments that restate the code. Change history belongs in the commit message
and PR, not in the file.

This does not apply to docstrings/Javadoc/JSDoc on public APIs — keep those, just
keep them short.

## Acceptable

Comment only non-obvious things: invariants, upstream landmines, workarounds for
external bugs, business rules that look arbitrary. Keep to ~2 lines; go longer only
when the behaviour genuinely needs it.

```typescript
// Upstream sends partial updates that omit retired SKUs — see TICKET-12345.
rebuildCache();
```

If the comment would explain a workaround for a flaw in another piece of code (a
misbehaving constructor, a leaky interface, a bad API shape) rather than an external
or upstream constraint, don't narrate the workaround in place. Ask the user whether
to file a ticket for the underlying issue. Once filed, leave no comment at all — a
ticket reference left behind in this file won't get cleaned up when the fix lands
elsewhere, and the code is now correct on its own terms.

## Unacceptable

- Comments explaining **what** the code does — rename or extract instead.
- Redundant doc comments that paraphrase the signature.
- Bare ticket-reference markers with no explanation.
- Commented-out code and authorship tags.
