---
paths:
  - "**/*.spec.ts"
---

# typescript-test-mocking

Never call real HTTP endpoints from a test. Mock service dependencies with `GenericMockClass.create<Service>({ method: jest.fn().mockReturnValue(of(...)) })` from `@maxxton/core/lib/state-management`, or with an explicit mock object whose methods return `of(...)`.

- Construct domain models from JSON by passing the literal to the model constructor: `new Model({ field: value })`. Never spread a raw response object onto a domain model — the model contract may include validation or derived state that a spread bypasses.
