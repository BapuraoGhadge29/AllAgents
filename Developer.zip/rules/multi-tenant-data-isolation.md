# multi-tenant-data-isolation

Scope tenant data by the active concern by default. Never let one concern's data reach another concern's request, query, cache, log, message, or browser storage; widen access across concerns only with an explicit, justified reason.

Each customer is a separate **concern** (`concernCode`/`concernId`, plus `clientId`), with backend data in a per-concern schema/database and frontends served per site/concern. A cross-concern leak is a critical security defect.

**Handled for you in Java services — do not reimplement or bypass:**
- **Schema routing.** The `database`/`postgres`/`mongodb` libraries route each request to the active concern's schema/database (Oracle via `contextpkg`). With context set, repository and JPQL queries are already concern-isolated — do not add a manual `WHERE concernId = …` filter or hardcode a schema. Never inject `EntityManager` or use raw JDBC to dodge the library.
- **Soft deletes.** Archived rows are hidden by the library's Hibernate `@Filter`; do not hand-roll deleted-row filtering.
- **Messaging context.** `journal-library` writes `concernCode` on publish and re-establishes context on consume; do not pass tenants around by hand.

**Your responsibility:**
- **Establish tenant context at every entry point.** HTTP controllers that touch tenant data use `@SetContextPkg(clientId = true)` (populates `ClientIdentifier`/`ConcernIdentifier`). Jobs, schedulers, startup hooks, and off-request threads must set context explicitly — never run against whatever tenant was set last.
- **Never trust client-supplied tenant ids.** Overwrite `concernId`/`clientId` server-side after deserialization — see the `java` plugin's `security-insecure-design` rule.
- **Scope shared-schema and cross-concern data explicitly.** Tables carrying a `@ConcernId` column (or any shared/cross-concern store) are not schema-isolated; filter them on the concern from `ClientIdentifier`.
- **Key caches, shared state, and browser storage by tenant.** Caches, `static` fields, module-level variables, Redis keys, and `localStorage` keys holding tenant data must include the concern (`concernCode`/`concernId` or `siteId`). Bare keys cause cross-tenant cache poisoning and, in SSR, cross-tenant data mixing.

## Example

```java
// Context set here; the database library routes to this concern's schema.
@SetContextPkg(clientId = true)
@GetMapping("/reservations")
public List<Reservation> list() {
  return reservationRepository.findAll(); // already concern-isolated
}
```

```typescript
// Frontend libraries do NOT scope storage — key it yourself.
localStorage.setItem(`${siteId}_user_prefs`, value);
```
