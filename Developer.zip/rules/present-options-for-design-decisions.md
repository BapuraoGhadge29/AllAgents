# present-options-for-design-decisions

When a task contains a design or architectural decision with multiple valid paths, stop before implementing. Do not pick one silently.

Instead:
1. Name the decision being made.
2. Present 2–3 distinct options, each with a one-line tradeoff (cost, benefit, risk).
3. State which option you lean toward and why.
4. Wait for the user to choose. Do not write code until they pick.

Applies to: library or framework choices, schema designs, API shapes, migration strategies, deployment patterns, service boundaries, and error-handling styles that affect callers.

Does NOT apply to: variable names, local loop style, formatting, or other implementation choices that do not outlive the file.

**Examples of when to stop and present options:**
- Normalized table vs JSON column — different read/write tradeoffs.
- Two libraries that both fit the requirement.
- In-place migration vs parallel table + cutover.
- Where to put a new service boundary.

Common pitfalls:
- Picking one approach silently because it "feels right".
- Mentioning alternatives in a footnote after already implementing one.
- Presenting six options. Keep it to 2–3 distinct ones.
- Omitting the tradeoff line. "Option A, option B" without cost or benefit is not useful.

Related: `clarify-before-acting` — when the input itself is ambiguous, ask one focused question rather than presenting options.
