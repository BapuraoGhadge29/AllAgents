# Branch Naming

All feature/fix branches must follow this naming convention:

```
feature/<ticket>
bugfix/<ticket>
hotfix/<ticket>
feature/<ticket>-description
bugfix/<ticket>-description
hotfix/<ticket>-description
```

Where `<ticket>` is a Jira ticket number (e.g. `MXTS-1234`, `MCMS-42`).

When the branch-naming check blocks a commit, the hook distinguishes two cases:

- **Ticket number present but branch format is wrong** (e.g. `chore/MXTS-1234`, `MXTS-1234-fix`) →
  use `/starting-ticket-branch` to recreate the branch with the correct format.
- **No ticket number in branch name** (e.g. `my-feature`, `feature/no-ticket`) →
  ask the user: _do you have a ticket number?_
  - Yes → provide it, then use `/starting-ticket-branch` to create a properly named branch.
  - No → use `/global:creating-jira-tickets` to create a Jira ticket first.

Never use `--no-verify` to bypass the naming check. If the current branch name is wrong,
create a correctly named branch with `/starting-ticket-branch` and continue from there.
