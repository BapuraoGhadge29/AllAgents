---
paths:
  - "**/*-store.service.spec.ts"
  - "**/*-store.selectors.spec.ts"
---

# angular-store-service-tests

Test reducers and selectors by instantiating the service class directly and calling its methods. Skip TestBed — these classes are plain TypeScript and exercise faster as such.

- Pass `mockStoreDependencyService` (from `@maxxton/core/lib/state-management`) as the first constructor argument.
- For other dependencies, supply a real mock when the tested code calls them; only use a typed empty object (`{} as Service`) when the code under test never invokes that dependency.
- Build state from `Service.initialState`. Spread overrides for partial state: `{ ...Service.initialState, field: value }`.
- Call `service.ngOnDestroy()` in `afterEach` so each test starts from a clean subscription state.
- For partial state assertions use `expect.objectContaining({ field: value })`.
- Single test: `npx jest <spec> -t "name"`.
