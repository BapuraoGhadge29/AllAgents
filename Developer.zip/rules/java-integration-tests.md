---
paths:
  - "**/*IntegrationTest.java"
---

# java-integration-tests

Place integration tests under `src/integration-test/java/` with the suffix `IntegrationTest.java`. Extend `MaxxtonBaseIntegrationTest` (REST Assured-driven), or `HousekeeperBaseIntegrationTest<T>` when the test creates data that needs cleanup.

- Authenticate in `@BeforeEach` with `RestAssured.authentication = new ConcernAuthenticationScheme("...")`.
- Prefer base-class helpers — `getJson()`, `postJson()`, `putJson()`, `deleteJson()`, `getJsonViaGateway()` — over raw RestAssured chains. Use the raw chain only when no helper fits: `given().body(...).contentType(ContentType.JSON).post(path).then().statusCode(statusCodeSuccessful()).extract().jsonPath()`.
- Assertions use **Hamcrest** (`org.hamcrest.MatcherAssert.assertThat` + `org.hamcrest.Matchers.*`), not AssertJ. Example: `assertThat(result.getString("status"), equalTo("CONFIRMED"))`.
- Assert status codes explicitly with `statusCodeSuccessful()` or the literal code (`200`, `201`, `400`, `404`, `409`, `401`, `403`).
- Track created IDs in a list field and clean them up in `@AfterEach`. Tests must not depend on execution order.
- Cover the negative paths: validation errors (400), not-found (404), conflicts (409), unauthorized / forbidden (401 / 403), and business-rule outcomes.
- Single test: `./gradlew integrationTest --tests "fqcn.ClassIntegrationTest.method"`. Full suite: `./gradlew integrationTest`. Always `./gradlew`, never the system `gradle`.
