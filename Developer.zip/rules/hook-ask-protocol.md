# Hook Ask Protocol

When any git hook output contains a line tagged `[CLAUDE:ASK]`, you **must** surface
that question to the user using the `AskUserQuestion` tool — never ask in plain text
or skip it.

Strip the `[CLAUDE:ASK]` prefix and use only the remaining message text as the question
payload passed to `AskUserQuestion`. Rephrase for clarity if needed, but preserve the
intent and all options.

Lines tagged `[CLAUDE:INFO]` are context for you — they are not questions and must not
be presented to the user as such.
