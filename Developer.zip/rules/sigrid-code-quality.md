---
paths:
  - "**/*.java"
  - "**/*.ts"
  - "**/*.tsx"
  - "**/*.go"
  - "**/*.py"
  - "**/*.kt"
---

# sigrid-code-quality

Before reporting any task as complete, run the Sigrid Code Quality Guardrails check on all changed code.

## Quality Gate

1. Use `sigrid_code_quality_guardrails` (Maxxton Knowledge MCP connector).
2. Maintainability findings: refactor before marking done — do not accept findings unless the root cause is outside the current scope.
3. Security findings: surface every finding to the user with a clear description and fix before marking done.

If the Maxxton Knowledge connector is unavailable, state that the quality gate could not run and the code is unverified. Never claim the gate passed.
