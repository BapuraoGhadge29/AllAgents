---
paths:
  - "**/*.java"
  - "**/*.go"
  - "**/*.ts"
---

# test-driven-development

Write the test first and observe it fail red before editing any production code. Use the `test-driven-development` skill (superpowers) for the full red-green cycle.

- Write tests and implementation in separate, sequential edits.
- Mock at the system boundary (HTTP, DB, message broker, time).
- One behavior per test. Test names describe the requirement, not the implementation.
- For bug fixes, the first test reproduces the bug — written and run red before any fix.
