---
paths:
  - "**/buddy-workflow.yml"
---

# buddy-workflow

Set `pipeline.namespace` to `mxtb-pipelines` — no other value is valid.

Verify `pipeline.name` against `MaxxtonGroup/cluster-config` before writing:

```bash
for chart in $(gh api repos/MaxxtonGroup/cluster-config/contents/cluster-master02/namespaces/mxtb-pipelines --jq '.[].name'); do
  gh api "repos/MaxxtonGroup/cluster-config/contents/cluster-master02/namespaces/mxtb-pipelines/$chart/pipelines" \
    --jq '.[].name | sub(".yaml$"; "")' 2>/dev/null
done
```

- Match branch families with glob patterns in `triggers.branches` and `triggers.tags` — `release/*`, `hotfix/*`, `*` are valid.
- Fire on an upstream repository's build by adding `builds: [{repository: MaxxtonGroup/<repo>}]` to `triggers`.
- Add `maxxton-buddy[bot]` to `triggers.ignoreFromCommiter` on any pipeline that commits back to the repository.
