# prefer-simplicity

Match complexity to the task. Don't add abstractions, error handling, or features beyond what's required.

- No premature abstractions — don't build factories or generic helpers for hypothetical future needs.
- No defensive code at internal boundaries — trust internal callers and framework guarantees; validate only at system boundaries (user input, external APIs).
- No scope creep on bug fixes — fix the bug, skip the surrounding cleanup.
- Three similar lines is fine — don't extract a helper until there's a real third caller.
