# Commit Message Format

Every commit message must follow this format:

```
type(scope): TICKET-123: short description
```

**Type** — one of:
- `feat` — new feature or behaviour
- `fix` — bug fix
- `refactor` — restructuring without behaviour change
- `test` — adding or updating tests
- `docs` — documentation only
- `chore` — tooling, config, dependency updates
- `perf` — performance improvement
- `ci` — CI/CD pipeline changes

**Scope** — the plugin or component being changed (e.g. `developer`, `security`, `validating-skills`). Omit only when the change truly spans the whole repo.

**Ticket** — a valid Jira ticket number (`MXTS-1234`, `MCMS-42`). Required — zero tickets (`MXTS-0`) are not allowed.

**Short description** — imperative mood, lowercase, no trailing period. Max ~72 characters for the full subject line.

**Other tickets** — name only the subject's ticket as a Jira key, in the subject and the body. Refer to any other ticket in words, or write its key with a non-breaking hyphen (`MXTS‑1234`, U+2011). The GitHub for Jira app links the PR to every key in its commit messages, so "reverts the MXTS-1234 change" puts the PR in that ticket's development panel.

## Examples

```
feat(developer): MXTS-1234: add branch naming validation to pre-commit hook
fix(security): MCMS-42: handle null origin URL in gitleaks wrapper
refactor(developer): MXTS-99: extract branch check into helper function
test(developer): MXTS-5: add detached-HEAD test case to pre-commit suite
```
