#!/usr/bin/env python3
"""Points superpowers:systematic-debugging at Maxxton evidence gathering.

systematic-debugging is upstream (claude-plugins-official), so it cannot be
edited here. Both skills matching on description is unreliable: Claude tends to
load only the best match. This hook attaches the companion deterministically
whenever Claude loads systematic-debugging through the Skill tool. A user typing
/systematic-debugging bypasses the Skill tool, so this hook does not fire then.

Side effects: none. Reads stdin, writes stdout. Silent on any error.
"""

import json
import sys

TARGET = "systematic-debugging"

REMINDER = (
    "If this issue involves anything deployed on Maxxton infrastructure "
    "(GKE pods, Cloud Run, buddy pipelines, GCP logs or Error Reporting), "
    "load the developer:debugging-maxxton-workloads skill for Phase 1 evidence "
    "gathering. It resolves cluster and namespace through buddy instead of "
    "guessing, and lists the Maxxton sources that return empty rather than an "
    "error. Skip it for purely local code or test failures."
)

try:
    data = json.load(sys.stdin)

    if data.get("tool_name") != "Skill":
        sys.exit(0)

    skill = (data.get("tool_input") or {}).get("skill")
    # Matched with or without the plugin prefix: the prefix depends on the
    # marketplace superpowers was installed from.
    if not isinstance(skill, str) or skill.split(":")[-1] != TARGET:
        sys.exit(0)

    print(json.dumps({
        "hookSpecificOutput": {
            "hookEventName": "PostToolUse",
            "additionalContext": REMINDER,
        }
    }))
except Exception:
    sys.exit(0)
