#!/usr/bin/env bash
# Blocks Write/Edit operations on .github/ files managed by Terraform.
# Source of truth: cluster-config/maxxton-github. Contact @MaxxtonGroup/devsecops-senior.
set -euo pipefail

HOOK_EVENT_NAME="PreToolUse"

_block() {
  local reason="$1"
  printf '{"hookSpecificOutput":{"hookEventName":"%s","permissionDecision":"deny","permissionDecisionReason":"%s"}}\n' \
    "$HOOK_EVENT_NAME" "$reason"
  echo "[developer] $reason" >&2
  exit 0
}

input=$(cat)
tool_name=$(printf '%s' "$input" | jq -r '.tool_name // ""' 2>/dev/null || true)

case "$tool_name" in
  Write|Edit|MultiEdit) ;;
  *) exit 0 ;;
esac

file_path=$(printf '%s' "$input" | jq -r '.tool_input.file_path // ""' 2>/dev/null || true)
[[ -z "$file_path" ]] && exit 0

# Match only the literal .github/ directory segment.
# /.github/ guards against false-positives like foo.github/ or not-a-github/.
# .github/* handles repo-relative paths that start at the repo root.
github_rel=""
case "$file_path" in
  *"/.github/"*) github_rel="${file_path##*/.github/}" ;;
  ".github/"*)   github_rel="${file_path#.github/}" ;;
  *)             exit 0 ;;
esac

case "$github_rel" in
  CODEOWNERS \
  |dependabot.yml \
  |dependabot.yaml \
  |pull_request_template.md \
  |copilot-instructions.md \
  |workflows/auto-assign-labels.yml \
  |workflows/code_quality.yml \
  |workflows/code_quality_gcp.yml)
    _block ".github/${github_rel} is managed by Terraform (cluster-config/maxxton-github). Contact @MaxxtonGroup/devsecops-senior to make changes."
    ;;
esac

exit 0
