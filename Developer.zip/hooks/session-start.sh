#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

# Prefer the canonical marketplace install path so a stale init.templateDir is
# repaired to a stable location (never a transient plugin cache/tmp dir). Fall
# back to the script-relative path for local marketplace development.
CANONICAL_TEMPLATE_DIR="${HOME}/.claude/plugins/marketplaces/maxxton-marketplace/plugins/developer/git-template"
ORG_MARKETPLACE="claudeai-maxxtongroup-claude-marketplace"
# The claude.ai org marketplace has no clone; a GitHub clone left on disk is no
# longer updated, so a plugin from the org cache uses its own template. A removed
# revision is repaired below on the next session.
if [[ "${SCRIPT_DIR}" == */plugins/cache/${ORG_MARKETPLACE}/* ]]; then
  TEMPLATE_DIR="${SCRIPT_DIR}/../git-template"
  TEMPLATE_DIR="$(cd "${TEMPLATE_DIR}" 2>/dev/null && pwd || echo "${TEMPLATE_DIR}")"
elif [ -d "${CANONICAL_TEMPLATE_DIR}/hooks" ]; then
  TEMPLATE_DIR="${CANONICAL_TEMPLATE_DIR}"
else
  TEMPLATE_DIR="${SCRIPT_DIR}/../git-template"
fi

# Nothing to do if not inside a git repo
git rev-parse --git-dir > /dev/null 2>&1 || exit 0

# Guard: if the template dir is missing (partial install) don't touch global config
[ -d "${TEMPLATE_DIR}/hooks" ] || exit 0

# Sanity-check init.templateDir and repair it when broken. We only (re)write the
# value when it is empty, or when it is a maxxton-marketplace path that is stale
# (its hooks dir is gone — e.g. a cleaned-up tmp/cache install) or differs from
# the canonical one. A non-maxxton user template is never touched, even if it is
# currently broken — that is the user's config to manage.
_current_template="$(git config --global --get init.templateDir 2>/dev/null || true)"
_needs_template=false
if [ -z "${_current_template}" ]; then
  _needs_template=true
else
  case "${_current_template}" in
    *maxxton-marketplace*|*"/${ORG_MARKETPLACE}/"*)
      if [ ! -d "${_current_template}/hooks" ] || [ "${_current_template}" != "${TEMPLATE_DIR}" ]; then
        _needs_template=true
      fi
      ;;
  esac
fi
if [ "${_needs_template}" = "true" ]; then
  git config --global init.templateDir "${TEMPLATE_DIR}" 2>/dev/null || true
fi

# Install hook entry points into current repo if any are missing
HOOKS_DIR="$(git rev-parse --git-dir)/hooks"
for hook in pre-commit commit-msg pre-push post-checkout; do
  [ -x "${HOOKS_DIR}/${hook}" ] && continue
  # At least one entry point is missing — install all of them
  mkdir -p "${HOOKS_DIR}"
  for h in _run-hooks.sh pre-commit commit-msg pre-push post-checkout; do
    cp "${TEMPLATE_DIR}/hooks/${h}" "${HOOKS_DIR}/${h}" 2>/dev/null || true
  done
  break
done

# Each repo holds its own copy of the dispatcher, made when the hooks were first
# installed, so a fix to it (such as how it finds plugins) only arrives here.
if [ -f "${HOOKS_DIR}/_run-hooks.sh" ] && ! cmp -s "${TEMPLATE_DIR}/hooks/_run-hooks.sh" "${HOOKS_DIR}/_run-hooks.sh"; then
  cp "${TEMPLATE_DIR}/hooks/_run-hooks.sh" "${HOOKS_DIR}/_run-hooks.sh" 2>/dev/null || true
fi

# Refresh the rule copies, so a plugin update reaches them without a checkout.
# Called directly, not through the dispatcher, so a repo's own .git-hooks/
# post-checkout does not run at session start; same MaxxtonGroup-only guard.
_origin_url="$(git remote get-url origin 2>/dev/null || true)"
case "${MAXXTON_FORCE_GIT_HOOKS:-}:${_origin_url}" in
  1:*|*MaxxtonGroup*)
    bash "${SCRIPT_DIR}/../git-hooks/post-checkout.sh" HEAD HEAD 1 </dev/null >/dev/null 2>&1 || true
    ;;
esac
