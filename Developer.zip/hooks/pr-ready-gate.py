#!/usr/bin/env python3
# PreToolUse gate on `gh pr ready` (MXTS-81194).
#
# Marking a pull request ready is the moment CODEOWNERS get notified, so it is
# the moment worth gating. Claude may do it only when the work has actually
# settled:
#
#   1. the head commit has at least one check run, and none of them failed or is
#      still running. A NEUTRAL or SKIPPED conclusion counts as green: a
#      path-filtered job that never had work to do must not wedge the gate;
#   2. Copilot has reviewed the pull request;
#   3. every Copilot-authored review thread is resolved.
#
# Absent signals deny. A repository with no Copilot reviewer, or with no CI at
# all, cannot be marked ready by Claude — a human does it on GitHub instead.
# There is deliberately no override flag: an escape hatch here would be reached
# for exactly when the gate is doing its job.
#
# Staleness is deliberately NOT checked: any Copilot review counts, even if
# commits landed after it. Tightening that is cheap and was left out on purpose.
#
# Fail closed. Every path that cannot establish the three facts above denies,
# including a missing `gh`, an auth failure, a timeout, and unparseable JSON.
# A gate that waves things through when it cannot see is not a gate.
import json
import shlex
import subprocess
import sys

# Seconds per gh invocation. Two calls run at most, so keep the product under
# the `timeout` this hook is given in hooks.json.
GH_TIMEOUT = 8

# GraphQL fetches every fact in one round trip: head SHA, reviews, review
# threads and the check rollup. Four REST calls would blow the hook's budget.
PR_QUERY = """
query($owner:String!, $name:String!, $number:Int!) {
  repository(owner:$owner, name:$name) {
    pullRequest(number:$number) {
      isDraft
      reviews(first:100) { nodes { author { login } } }
      reviewThreads(first:100) {
        nodes { isResolved comments(first:1) { nodes { author { login } } } }
      }
      commits(last:1) {
        nodes { commit { statusCheckRollup { state
          contexts(first:100) { nodes {
            __typename
            ... on CheckRun { name status conclusion }
            ... on StatusContext { context state }
          } } } } }
      }
    }
  }
}
"""


def allow():
    sys.exit(0)


def deny(reason):
    print(json.dumps({'hookSpecificOutput': {
        'hookEventName': 'PreToolUse',
        'permissionDecision': 'deny',
        'permissionDecisionReason': reason,
    }}))
    sys.exit(0)


def run(args):
    """Run a command, returning (ok, stdout). Any failure is a failure to
    establish a fact, and every caller turns that into a denial."""
    try:
        p = subprocess.run(args, capture_output=True, text=True, timeout=GH_TIMEOUT)
    except (OSError, subprocess.SubprocessError):
        return False, ''
    if p.returncode != 0:
        return False, (p.stderr or '').strip()
    return True, (p.stdout or '').strip()


def ready_tokens(command):
    """Tokens following `gh pr ready`, or None when the command does not invoke
    it. An empty list means a real bare invocation, so the two cases must not
    collapse: `gh pr ready` with no arguments still marks a PR ready.

    Claude Code fires this hook for any Bash command whose text contains
    `gh pr ready`, including one that only mentions it inside a quoted argument
    (`grep "gh pr ready" …`), so match the token sequence, never the substring.
    """
    try:
        toks = shlex.split(command)
    except ValueError:
        return None
    for i in range(len(toks) - 2):
        if toks[i] == 'gh' and toks[i + 1] == 'pr' and toks[i + 2] == 'ready':
            return toks[i + 3:]
    return None


def expand_repo_flag(toks):
    """Rewrite gh's attached --repo forms into the separated pair.

    pflag accepts `--repo=owner/name` and `-Rowner/name` as well as `--repo X`.
    Both attached forms start with `-`, so a loop that only matches the
    separated pair drops them silently — and `gh pr view` then resolves a pull
    request from the hook's own working directory instead of the one being
    marked ready. That is a fail-open in a gate: an unrelated PR's green CI and
    resolved threads would open it.
    """
    out = []
    for tok in toks:
        if tok.startswith('--repo='):
            out += ['--repo', tok.split('=', 1)[1]]
        elif tok.startswith('-R') and len(tok) > 2:
            out += ['--repo', tok[2:]]
        else:
            out.append(tok)
    return out


def is_copilot(login):
    """GitHub reports the reviewer as `copilot-pull-request-reviewer` over
    GraphQL and `copilot-pull-request-reviewer[bot]` over REST; accept the
    `copilot-` family so a rename of the suffix does not silently open the gate.
    """
    return (login or '').lower().replace('[bot]', '').startswith('copilot-')


def failed_checks(rollup):
    """Names of check contexts that are not a success. A pending or queued run
    counts as failing here: 'CI is green' means finished and green."""
    bad = []
    for node in ((rollup or {}).get('contexts') or {}).get('nodes') or []:
        if node.get('__typename') == 'CheckRun':
            ok = node.get('status') == 'COMPLETED' and \
                node.get('conclusion') in ('SUCCESS', 'NEUTRAL', 'SKIPPED')
            label = node.get('name') or 'check'
            state = node.get('conclusion') or node.get('status') or '?'
        else:
            ok = node.get('state') == 'SUCCESS'
            label = node.get('context') or 'status'
            state = node.get('state') or '?'
        if not ok:
            bad.append('%s (%s)' % (label, state))
    return bad


def main():
    # A tty means someone ran this by hand rather than the harness firing it;
    # there is no pull request to judge, so there is nothing to gate.
    if sys.stdin.isatty():
        allow()
    try:
        event = json.load(sys.stdin)
    except (json.JSONDecodeError, EOFError, ValueError):
        # The harness only fires this hook for a command matching `gh pr ready`,
        # so a payload we cannot read is most likely one of those with nothing
        # left to check it against. Allowing here would be the one bypass in an
        # otherwise closed gate.
        deny('Cannot mark ready: the hook received an unreadable event payload, '
             'so the CI and Copilot checks could not run. This gate fails closed '
             '— mark the pull request ready on GitHub if that is intended.')

    if event.get('tool_name') != 'Bash':
        allow()
    toks = ready_tokens((event.get('tool_input') or {}).get('command', ''))
    if toks is None:
        allow()

    # `--undo` converts a pull request back to draft, and `--help` prints usage.
    # Neither exposes anything to reviewers, so neither is this gate's business.
    if any(t in ('--undo', '--help', '-h') for t in toks):
        allow()

    # Pass the caller's own selector and --repo through, so the hook resolves
    # exactly the pull request the command would have marked ready.
    view = ['gh', 'pr', 'view']
    toks = expand_repo_flag(toks)
    skip = False
    for i, tok in enumerate(toks):
        if skip:
            skip = False
            continue
        if tok in ('-R', '--repo'):
            view += [tok, toks[i + 1]] if i + 1 < len(toks) else [tok]
            skip = True
        elif not tok.startswith('-'):
            view.append(tok)
    ok, out = run(view + ['--json', 'number,url'])
    if not ok:
        deny('Cannot mark ready: could not resolve the pull request (`gh pr view` '
             'failed: %s). This gate fails closed — fix the command or mark it '
             'ready on GitHub.' % (out or 'no output'))
    try:
        pr = json.loads(out)
        number = int(pr['number'])
        owner, name = pr['url'].split('/')[3:5]
    except (ValueError, KeyError, IndexError, TypeError):
        deny('Cannot mark ready: could not parse the pull request identity from '
             '`gh pr view`. This gate fails closed.')

    ok, out = run(['gh', 'api', 'graphql',
                   '-f', 'query=' + PR_QUERY,
                   '-F', 'owner=' + owner, '-F', 'name=' + name,
                   '-F', 'number=%d' % number])
    if not ok:
        deny('Cannot mark ready: the GitHub API call failed (%s). This gate fails '
             'closed — retry, or mark it ready on GitHub.' % (out or 'no output'))
    try:
        node = json.loads(out)['data']['repository']['pullRequest']
    except (ValueError, KeyError, TypeError):
        deny('Cannot mark ready: could not parse the GitHub API response. '
             'This gate fails closed.')

    problems = []

    commits = (node.get('commits') or {}).get('nodes') or []
    rollup = (commits[0].get('commit') or {}).get('statusCheckRollup') if commits else None
    contexts = ((rollup or {}).get('contexts') or {}).get('nodes') or []
    if not contexts:
        problems.append(
            'no check runs on the head commit — CI has not reported. If this '
            'repository has no CI at all, a human marks the PR ready on GitHub.')
    else:
        bad = failed_checks(rollup)
        if bad:
            problems.append('checks not green: ' + ', '.join(bad[:5]))

    reviews = (node.get('reviews') or {}).get('nodes') or []
    if not any(is_copilot((r.get('author') or {}).get('login')) for r in reviews):
        problems.append(
            'Copilot has not reviewed this PR yet — wait for its review. If '
            'Copilot review is not enabled here, a human marks the PR ready.')
    else:
        unresolved = 0
        for t in (node.get('reviewThreads') or {}).get('nodes') or []:
            first = ((t.get('comments') or {}).get('nodes') or [{}])[0]
            if is_copilot((first.get('author') or {}).get('login')) and not t.get('isResolved'):
                unresolved += 1
        if unresolved:
            problems.append(
                '%d unresolved Copilot thread%s — address them, then reply and '
                'resolve (`/developer:addressing-comments`).'
                % (unresolved, '' if unresolved == 1 else 's'))

    if problems:
        deny('Not ready to mark PR #%d ready:\n- %s' % (number, '\n- '.join(problems)))
    allow()


if __name__ == '__main__':
    main()
