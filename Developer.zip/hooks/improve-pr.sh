#!/usr/bin/env bash
# Improve the open PR title and description. It requests no reviewers: a body it writes keeps
# the template's Default Reviewers text, and Buddy invites the teams named there.
# Called from hooks.json PostToolUse on git push ($1=push) and gh pr create ($1=create).

set -euo pipefail

TRIGGER="${1:-push}"

# The hook runs in the session's directory, but `cd other-repo && gh pr create` acts on
# another checkout. Replay the command's cd / `git -C` up to the trigger and move there,
# or this run checks the session's branch, finds no PR and stops.
_target_dir() {
  local input="$1" cmd dir arg trig rest re
  local tok='("[^"]*"|'"'"'[^'"'"']*'"'"'|[^[:space:];&|)]+)'
  command -v jq >/dev/null 2>&1 || return 1
  cmd=$(printf '%s' "$input" | jq -r '.tool_input.command // ""' 2>/dev/null) || return 1
  dir=$(printf '%s' "$input" | jq -r '.cwd // ""' 2>/dev/null) || dir=""
  [ -d "$dir" ] || dir="$PWD"
  if [ "$TRIGGER" = "create" ]; then trig='gh[[:space:]]+pr[[:space:]]+create'
  else trig="git[[:space:]]+(-C[[:space:]]+$tok[[:space:]]+)?push"; fi
  rest=""
  [[ "$cmd" =~ $trig ]] && rest="${cmd%%"${BASH_REMATCH[0]}"*}${BASH_REMATCH[0]}"
  re="(^|[;&|(]|then|do)[[:space:]]*(cd|git[[:space:]]+-C)[[:space:]]+$tok"
  while [[ "$rest" =~ $re ]]; do
    arg="${BASH_REMATCH[3]}"
    rest="${rest#*"${BASH_REMATCH[0]}"}"
    arg="${arg#[\"\']}"; arg="${arg%[\"\']}"
    case "$arg" in
      *'$'*|*'`'*|-*) return 1 ;;
      "~") arg="$HOME" ;;
      "~/"*) arg="$HOME/${arg#\~/}" ;;
    esac
    case "$arg" in /*) dir="$arg" ;; *) dir="$dir/$arg" ;; esac
  done
  [ -d "$dir" ] && printf '%s' "$dir"
}
if [ ! -t 0 ]; then
  _INPUT=""
  IFS= read -r -d '' -t 2 _INPUT || true
  if _DIR=$(_target_dir "$_INPUT"); then cd "$_DIR" 2>/dev/null || exit 0; fi
fi

# Dedup lock: git push && gh pr create fires both hooks in quick succession.
# mkdir is atomic on all platforms (including NTFS via Git Bash on Windows).
_BRANCH=$(git rev-parse --abbrev-ref HEAD 2>/dev/null) || exit 0
_GIT_DIR=$(git rev-parse --git-dir 2>/dev/null) || exit 0
_LOCK_DIR="${_GIT_DIR}/improve-pr-${_BRANCH//\//-}.lock"
_LOCK_STAMP="${_LOCK_DIR}/ts"
_LOCK_PID="${_LOCK_DIR}/pid"
_LOCK_TTL=60  # seconds; covers push+create latency without blocking intentional re-runs
_LOCK_MAX=600 # absolute ceiling; a recycled PID must never hold the lock for ever
_RUN_TIMEOUT="${IMPROVE_PR_RUN_TIMEOUT:-300}"  # wall-clock cap for the detached run

if [ -d "$_LOCK_DIR" ]; then
  _LOCK_TS=$(cat "$_LOCK_STAMP" 2>/dev/null || echo 0)  # missing stamp → 0 → always stale
  _NOW=$(date +%s 2>/dev/null || echo 0)
  _LOCK_AGE=$(( _NOW - _LOCK_TS ))
  # If _NOW=0 (date failed) treat as stale — negative difference < TTL would falsely skip.
  if [ "$_NOW" -gt 0 ] && [ "$_LOCK_AGE" -lt $_LOCK_TTL ]; then
    exit 0  # Another hook instance ran or is running; skip
  fi
  # Past the TTL the lock still holds while its own run is alive. The TTL was
  # sized for a synchronous hook, where the session physically waited and a second
  # run was unreachable; detached, a push returns at once, so a run outliving the
  # TTL would let the next push start a second `gh pr edit` against the same PR.
  # Bounded by _LOCK_MAX so a recycled PID cannot hold the lock indefinitely.
  _PREV_PID=$(cat "$_LOCK_PID" 2>/dev/null || echo '')
  if [ -n "$_PREV_PID" ] && [ "$_NOW" -gt 0 ] \
     && [ "$_LOCK_AGE" -lt $_LOCK_MAX ] \
     && kill -0 "$_PREV_PID" 2>/dev/null; then
    exit 0  # previous run still in flight
  fi
  rm -rf "$_LOCK_DIR"
fi
mkdir "$_LOCK_DIR" 2>/dev/null || exit 0  # Lost the race; skip
date +%s > "$_LOCK_STAMP" 2>/dev/null || rm -rf "$_LOCK_DIR"  # stamp failure → release lock

# Prompt tails, chosen by the child below. Building both here costs nothing and
# keeps every network call on the far side of the detach.
_COMMON="Check if the current branch is a feature/*, bugfix/*, or hotfix/* branch and has an open GitHub PR. Stop silently if not. Fetch the PR with: gh pr view --json number,title,body,baseRefName. Get commits with their messages: git log origin/<baseRefName>..HEAD --format='%s%n%b'. Get diff stats: git diff --stat origin/<baseRefName>..HEAD."

# The child picks one title sentence and one body sentence. The keep-sentences
# carry no write instruction at all: preservation used to be a prompt sentence,
# and a run that ignored it replaced a hand-written description carrying pre-PR
# review decisions recorded nowhere else (MXTS-81222). A prompt cannot protect
# the body or the title; having nothing to act on can.
_TITLE_TAIL="Then write a PR title (72 chars max, imperative mood) and set it with: gh pr edit --title ... If the branch name contains a ticket key such as ABC-1234, start the title with that key."
_KEEP_TITLE="NEVER pass --title and never change the PR title."

# Reviewer-first: a reviewer needs the problem, the approach, the evidence and the
# blast radius before the diff. The diff already shows what changed.
_BODY_TAIL="Then write the PR body. If .github/pull_request_template.md exists in the repo root, start the body with its ### Default Reviewers section copied word for word (the heading and every @Org/Team line under it): Buddy invites those reviewers, so never request reviewers yourself. After it, keep the body short (at most about 20 lines), with exactly these four sections in this order, each heading on its own line: a ## Why section with the problem this PR solves, in one or two sentences; a ## How section with the approach and the key decisions in 2-4 bullets, using backticks for file and resource names, without listing the diff file by file; a ## Verified section made only of lines copied word for word from the commit messages that say a command or check was run (such as 'Ran ...'); when no commit message has such a line, the section is the single line '- Not stated yet: add what you ran.' (a test that was added or changed is not a check that was run, and the diff is not evidence); a ## Risk section of 1-3 bullets, each naming a part or behaviour the diff changes that could break, phrased as 'Check whether ...' (for example 'Check whether callers that pass an empty list still get the old result'); never say that something was tested, works or is safe, and never write just 'None'. After the sections, keep any Closes or Fixes lines from the existing body or commit messages, and end with the line: 🤖 Generated with [Claude Code](https://claude.ai/claude-code). Write every Jira key that is not in the PR title or branch name with a non-breaking hyphen (U+2011) instead of '-', or name that ticket in words: the GitHub for Jira app links the PR to every key in its description, and pr-foreign-key-guard refuses the edit otherwise. Set it with: gh pr edit --body ..."
# Exactly one source sentence follows the body sentence. A short body a person
# wrote keeps its facts; the hook's own earlier body is rebuilt from the commits,
# so verification claims for older commits are not carried forward.
_FROM_PERSON="The existing body was written by a person: keep every fact in it, and count the checks it mentions as shown."
_FROM_COMMITS="Build every section from the commits and the diff only; do not copy sections or Verified bullets from the existing body."
_KEEP_BODY="NEVER pass --body and never edit the description in any other way."

# Branch-scoped record of the body this hook last wrote, so a later push can tell
# its own description from one a human has since edited. Lives beside the lock.
_BODY_HASH_FILE="${_GIT_DIR}/improve-pr-body-${_BRANCH//\//-}.sha"

# The decision, the nested run and the bookkeeping all live in the child, on the
# far side of the detach. See improve-pr-run.sh for why.
_RUN_SCRIPT="$(dirname "${BASH_SOURCE[0]}")/improve-pr-run.sh"
[ -r "$_RUN_SCRIPT" ] || { rm -rf "$_LOCK_DIR"; exit 0; }

# Detached: this nested run takes ~20s and PostToolUse blocks the parent session
# until the hook returns, so running it inline stalls every push by that long.
# Nothing here feeds back to the model — the PR edit lands via `gh` — so the wait
# bought nothing. All three fds are redirected so the harness never waits on a pipe,
# and stray output goes to a log instead of being swallowed as hook stdout.
_LOG_FILE="${_GIT_DIR}/improve-pr.log"

# Append, stamped: this log is the only remaining signal that a detached run
# failed, so truncating it means the next push destroys the evidence of the last
# one. Trim first so it cannot grow without bound.
if [ -f "$_LOG_FILE" ] && [ "$(wc -c < "$_LOG_FILE" 2>/dev/null || echo 0)" -gt 262144 ]; then
  # Rewrite the same inode rather than `mv`-ing a replacement over it: a detached
  # run that outlives the lock TTL still holds an O_APPEND fd, and swapping the
  # inode would send its remaining output to an unlinked file.
  # Fail-open throughout — errexit must never abort the hook before the launch.
  tail -c 65536 "$_LOG_FILE" > "$_LOG_FILE.trim" 2>/dev/null \
    && cat "$_LOG_FILE.trim" > "$_LOG_FILE" 2>/dev/null || true
  rm -f "$_LOG_FILE.trim" 2>/dev/null || true
fi
printf '\n=== %s %s (%s) ===\n' \
  "$(date -u +%Y-%m-%dT%H:%M:%SZ 2>/dev/null || echo unknown)" "$_BRANCH" "$TRIGGER" \
  >> "$_LOG_FILE" 2>/dev/null || true

# Detaching removed the only wall-clock bound: hooks.json's timeout capped the
# inline run, and it no longer applies to a backgrounded child. --max-turns bounds
# turns, not a hung call, so cap it here where `timeout` exists.
_cmd=(bash "$_RUN_SCRIPT" "$TRIGGER" "$_COMMON" "$_TITLE_TAIL" "$_KEEP_TITLE" \
  "$_BODY_TAIL" "$_FROM_PERSON" "$_FROM_COMMITS" "$_KEEP_BODY" "$_BODY_HASH_FILE")
_capped=0
command -v timeout >/dev/null 2>&1 && { _cmd=(timeout "$_RUN_TIMEOUT" "${_cmd[@]}"); _capped=1; } || true

nohup "${_cmd[@]}" </dev/null >>"$_LOG_FILE" 2>&1 &
_child=$!
printf '%s' "$_child" > "$_LOCK_PID" 2>/dev/null || true

# macOS ships no `timeout`, so cap the run here instead. Only when it is not
# already capped: every extra watchdog is another chance to signal a PID the
# kernel recycled during the wait, which `kill -0` narrows but cannot rule out.
if [ "$_capped" -eq 0 ]; then
  ( sleep "$_RUN_TIMEOUT"
    kill -0 "$_child" 2>/dev/null && kill "$_child" 2>/dev/null
  ) >/dev/null 2>&1 &
  disown 2>/dev/null || true
fi
# disown is unavailable / can fail in some non-interactive shells; ignore so the
# hook stays best-effort (errexit must not abort on it).
disown 2>/dev/null || true
exit 0
