#!/usr/bin/env python3

# Endpoint-change impact-analysis guard.
#
# Wired as PreToolUse on Edit | Write | MultiEdit. Blocks an edit to a backend
# Java endpoint contract — a controller method (HTTP/param annotation) OR a
# related DTO / request-response model (path, name, or serialization
# annotation) — until a cross-layer impact analysis has been run with the
# Maxxton Knowledge MCP. The deny message carries the exact MCP queries to run:
# Feign callers (inbound backend call chain), Angular consumers (a SEPARATE
# search — the graph does not auto-traverse the frontend/backend RESOLVES_TO
# boundary), and the component blast radius.
#
# Workspace-agnostic by design: this plugin is symlinked into many repos and
# runs in non-workspace contexts (incl. the maxxton-workspace gate-6 child
# sessions, which are rooted in a single service repo). It therefore keeps NO
# knowledge of the workspace's ai/<TICKET>/session.yaml — the gate-4 plan is the
# audit trail. The only state is a branch-scoped marker:
#
#     $CLAUDE_PROJECT_DIR/.claude/.endpoint-impact-ok   (content = git branch)
#
# Present AND matching the current branch -> allow (not deleted, so every edit
# on the same branch flows freely after one analysis). Absent or stale (written
# for a different branch) -> deny. Switching to a new ticket branch re-gates the
# next change automatically. The marker belongs in .gitignore.
#
# Fail-open: any malformed input / IO / subprocess error allows the edit. A hook
# bug must never block real work. The deny path is the only intentional block,
# and it still exits 0 (the decision travels in the JSON envelope, not the code).

import json
import os
import re
import subprocess
import sys
from pathlib import Path

MARKER_RELPATH = Path(".claude") / ".endpoint-impact-ok"

# --- detection patterns -----------------------------------------------------

# Path A — a controller endpoint: Spring HTTP mapping or request-param binding.
_HTTP_ANNOTATION = re.compile(
    r"@(?:Get|Post|Put|Delete|Patch|Request)Mapping"
    r"|@(?:RequestParam|PathVariable|RequestBody|RequestHeader)\b"
)
# Verb + path literal extraction, for the deny message.
_VERB = re.compile(r"@(Get|Post|Put|Delete|Patch)Mapping")
_PATH = re.compile(r"@\w+Mapping\s*\(\s*(?:(?:value|path)\s*=\s*)?[\"']([^\"']+)[\"']")

# Path B — a DTO / request-response model carrying contract shape.
_MODEL_PATH_SEGMENTS = ("/dto/", "/request/", "/response/", "/model/")
_MODEL_NAME_SUFFIX = re.compile(r"(?:Dto|Request|Response|Resource|ViewModel)$")
_SERIALIZATION_ANNOTATION = re.compile(
    r"@(?:JsonProperty|Schema|JsonIgnore|JsonSerialize|JsonDeserialize)\b"
)


def allow():
    sys.exit(0)


def deny(reason):
    print(json.dumps({"hookSpecificOutput": {
        "hookEventName": "PreToolUse",
        "permissionDecision": "deny",
        "permissionDecisionReason": reason,
    }}))
    sys.exit(0)


def _edited_text(tool_input):
    """All text this edit touches: Write content, Edit old/new strings, and
    every MultiEdit edit's strings. Detection scans the pre-edit text so a
    contract removal (present in old_string, gone from new) is still caught."""
    parts = []
    for key in ("content", "old_string", "new_string"):
        v = tool_input.get(key)
        if isinstance(v, str):
            parts.append(v)
    for edit in tool_input.get("edits") or []:
        if isinstance(edit, dict):
            for key in ("old_string", "new_string"):
                v = edit.get(key)
                if isinstance(v, str):
                    parts.append(v)
    return "\n".join(parts)


def _current_branch(project_dir):
    try:
        r = subprocess.run(
            ["git", "rev-parse", "--abbrev-ref", "HEAD"],
            cwd=project_dir, capture_output=True, text=True, timeout=4,
        )
    except (OSError, subprocess.TimeoutExpired):
        return None
    if r.returncode != 0:
        return None
    branch = r.stdout.strip() or None
    # Detached HEAD: not a real branch, and `git branch --show-current` (the
    # command the deny message tells the user to run) prints empty here, not
    # "HEAD" — treat as unresolvable so the two never diverge.
    return None if branch == "HEAD" else branch


def _marker_satisfied(project_dir, branch):
    """True iff the marker exists and names the current branch."""
    marker = Path(project_dir) / MARKER_RELPATH
    try:
        if not marker.is_file():
            return False
        recorded = marker.read_text(encoding="utf-8").strip()
    except OSError:
        return False
    return recorded == branch


def _classify(file_path, text):
    """Return (kind, subject) where kind is 'controller' | 'dto' | None."""
    normalized = file_path.replace("\\", "/")
    # Test sources are never the shipped API contract — a controller/DTO-shaped
    # test fixture (e.g. src/test/.../FooResourceTest.java) must not gate the
    # branch (MXTS-79455).
    if "/src/test/" in normalized or normalized.startswith("src/test/"):
        return None, None
    name = Path(file_path).name
    lower_path = normalized.lower()

    if name.endswith("Controller.java") and _HTTP_ANNOTATION.search(text):
        verb = _VERB.search(text)
        path = _PATH.search(text)
        verb_str = verb.group(1).upper() if verb else "HTTP"
        path_str = path.group(1) if path else "<path>"
        subject = f"{verb_str} {path_str}"
        return "controller", subject

    if name.endswith(".java"):
        is_model = (
            any(seg in lower_path for seg in _MODEL_PATH_SEGMENTS)
            or _MODEL_NAME_SUFFIX.search(Path(file_path).stem)
            or _SERIALIZATION_ANNOTATION.search(text)
        )
        if is_model:
            return "dto", Path(file_path).stem

    return None, None


def _deny_message(kind, subject):
    if kind == "controller":
        head = (
            f"Endpoint contract change detected in a controller "
            f"({subject}). Run a cross-layer impact analysis with the Maxxton "
            f"Knowledge MCP before editing."
        )
        discover = ""
        path_kw = subject
    else:
        head = (
            f"Change to DTO/model `{subject}` may alter an API contract. Run a "
            f"cross-layer impact analysis with the Maxxton Knowledge MCP before "
            f"editing."
        )
        discover = (
            f"  0. query_openapi(\"{subject}\")  +  "
            f"search_technical_graph(\"{subject}\", node_type=\"ControllerMethod\")  "
            f"# which endpoints declare this type; then run 1-4 per endpoint\n"
        )
        path_kw = subject

    return (
        head + "\n\n"
        + discover
        + f"  1. search_technical_graph(\"{path_kw}\", node_type=\"ControllerMethod\")  # the endpoint node\n"
        + "  2. get_call_chain(node_id=<id from 1>, direction=\"inbound\")  # Feign callers in other services\n"
        + f"  3. search_technical_graph(\"{path_kw}\", node_type=\"AngularServiceMethod\")  "
          "# frontend consumers — SEPARATE query; RESOLVES_TO is not auto-traversed\n"
        + "  4. get_call_chain(node_id=<angular id from 3>, direction=\"inbound\")  # component / store blast radius\n\n"
        + "An empty MCP result is valid \"no consumers\" evidence; an un-queried "
          "\"no consumers\" is not. After the analysis, record it on this branch:\n\n"
        + "    git branch --show-current > .claude/.endpoint-impact-ok\n\n"
        + "(Add `.claude/.endpoint-impact-ok` to .gitignore.) The marker clears "
          "this gate for every edit on the current branch."
    )


def main():
    try:
        payload = json.load(sys.stdin)
    except (json.JSONDecodeError, ValueError):
        allow()

    tool_input = payload.get("tool_input") or {}
    file_path = tool_input.get("file_path") or tool_input.get("notebook_path")
    if not isinstance(file_path, str) or not file_path:
        allow()

    text = _edited_text(tool_input)
    kind, subject = _classify(file_path, text)
    if kind is None:
        allow()

    project_dir = os.environ.get("CLAUDE_PROJECT_DIR") or os.getcwd()
    branch = _current_branch(project_dir)
    if branch is None:
        # Can't verify the branch (not a git repo, no git binary, timeout) —
        # fail open rather than block on an environment issue.
        allow()
    if _marker_satisfied(project_dir, branch):
        allow()

    deny(_deny_message(kind, subject))


if __name__ == "__main__":
    try:
        main()
    except SystemExit:
        raise
    except Exception as exc:  # noqa: BLE001 — fail open, never block on a hook bug
        sys.stderr.write(f"endpoint-change-guard: unexpected error: {exc}\n")
        sys.exit(0)
