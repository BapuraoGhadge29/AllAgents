#!/usr/bin/env python3

# Pre-PR AI code review hook.
#
# Wired as PreToolUse on `gh pr create` and the GitHub MCP create_pull_request
# tool. For a MaxxtonGroup repository (or one whose owner can't be told), validates
# the PR title contains a Jira ticket number, then enforces that a pre-PR review has
# passed for the exact commit being proposed. Other owners' repositories pass untouched.
#
# Two-phase by design. This hook does not perform the review. It used to shell out
# to `claude -p`, which meant a hard wall-clock budget on a PreToolUse hook: a
# review thorough enough to be worth running outlasts any budget a developer will
# wait through, and when it was cut short the PR sailed through looking reviewed.
# So the review moved in-session to /developer:reviewing-pre-pr, which records its
# pass in the git directory; this hook only looks for that record and denies with
# instructions when it is absent. No subprocess, no model pin, no timeout.
#
# Intentionally narrow: only reviews code quality. Compile/lint/test gates
# are the responsibility of the repo's own CI pipeline.
#
# The hook process is launched by Claude Code in the session's main project
# directory. A `cd <dir> && gh pr create` inside the Bash tool_input only
# affects the spawned shell, NOT this hook — so all git commands must be
# explicitly scoped to the directory the PR actually targets (parsed from the
# command), otherwise the review runs against the wrong repo's diff. The base
# branch is likewise resolved per-repo rather than hardcoded to `main`.

import json
import os
import re
import hashlib
import shlex
import subprocess
import sys
import time


# How long a hand-off stays usable. Long enough for a thorough review to be
# started, short enough that yesterday's abandoned PR attempt is not mistaken for
# this one.
REQUEST_TTL_SECONDS = 1800


def request_dir():
    """Where the resolved target is handed to the review. Deliberately not inside
    the reviewed repository: the review's problem is that it does not yet know
    which repository that is."""
    return os.environ.get('CLAUDE_PRE_PR_REVIEW_DIR') or os.path.join(
        os.path.expanduser('~'), '.claude', 'pre-pr-review')


def request_name(token, repo):
    """Filename for one session's request about one repository.

    Keying on the session alone was not enough: a session that opens PRs in two
    repositories within the TTL — a sequenced multi-repo pair, which is routine
    here — produced the same filename twice, so the second silently replaced the
    first and only one file remained. The review's "more than one live request
    means stop" rule then never fired, and a review for the first repository
    could bind the second.

    Including the repository means two repositories leave two files, which does
    trip that rule, while a second attempt on the *same* repository still
    overwrites — there the newer request genuinely supersedes the older.
    """
    digest = hashlib.sha256(os.path.realpath(repo).encode('utf-8')).hexdigest()[:12]
    return 'request-' + token + '-' + digest + '.json'


def request_token(session_id):
    """Filename-safe session token, or None when the event carried no session.

    No session means no way to tell this request apart from another session's. A
    shared fallback filename would let two sessions overwrite each other and hand
    one review the other's repository, so such a request is never written at all
    — the review falls back to its arguments instead.
    """
    token = re.sub(r'[^A-Za-z0-9_-]', '', str(session_id or ''))[:64]
    return token or None


def toplevel_of(git):
    """Repository root for an already-scoped git prefix, or None."""
    top = try_exec(list(git) + ['rev-parse', '--show-toplevel'])
    return top['out'] if top['ok'] and top['out'] else None


def prune_requests(directory, now):
    """Drop expired requests.

    Called on every gate decision, not only when one is written. A request left
    by an abandoned PR attempt is exactly what makes a later review see a
    plausible but wrong target: it is the only live request, and its recorded
    HEAD still matches because that repository never moved. Pruning only when
    something new is written would leave that request alive indefinitely, since
    an abandoned attempt is followed by no write at all.
    """
    try:
        names = os.listdir(directory)
    except OSError:
        return
    for name in names:
        # Match only what this hook writes. An earlier version filtered on the
        # extension alone, which made an expiring sweep of every *.json in the
        # directory — and the directory is env-overridable, one segment from the
        # settings files. A pruner must never be able to delete a file it did
        # not create.
        if not name.startswith('request-'):
            continue
        if not (name.endswith('.json') or name.endswith('.json.tmp')):
            continue
        stale = os.path.join(directory, name)
        try:
            if now - os.path.getmtime(stale) > REQUEST_TTL_SECONDS:
                os.remove(stale)
        except OSError:
            pass


def clear_session_requests(session_id):
    """Drop every hand-off this session has left, whatever repository it names.

    Used on the one deny path that cannot resolve a repository: an MCP
    create_pull_request whose owner/repo does not match the checkout the session
    sits in. That deny writes no hand-off, and if an earlier one is still live
    the review finds exactly one candidate, sees a HEAD that still matches
    because that repository never moved, and reviews and passes the wrong
    repository — while the retry's marker check, made against the cwd, then
    allows. Clearing here keeps "cannot name a target" meaning exactly that.
    """
    token = request_token(session_id)
    if not token:
        return
    directory = request_dir()
    try:
        names = os.listdir(directory)
    except OSError:
        return
    prefix = 'request-' + token + '-'
    for name in names:
        if not name.startswith(prefix):
            continue
        # Same allowlist as prune_requests, for the same reason: the directory is
        # env-overridable, so never remove a file this hook did not write.
        if not (name.endswith('.json') or name.endswith('.json.tmp')):
            continue
        try:
            os.remove(os.path.join(directory, name))
        except OSError:
            pass


def clear_request(session_id, repo):
    """Remove this session's request for this repository once it is moot.

    A request outlives its purpose the moment the gate opens: the review has
    passed and the PR is going out. Leaving the file on disk is what allows the
    MXTS-80544 failure to come back through a different door — a later review
    with no usable argument finds exactly one live request, sees a HEAD that
    still matches because that repository never moved, and confidently reviews
    a repository nobody asked about.
    """
    token = request_token(session_id)
    if not token or not repo:
        return
    try:
        os.remove(os.path.join(request_dir(), request_name(token, repo)))
    except OSError:
        pass


def write_review_request(session_id, repo, base, head_sha):
    """Hand the resolved target to the review directly instead of relying on it
    surviving a positional argument.

    The hook already knows the repository and the base — it just checked them.
    The lossy step is the hand-off to a forked review, where a caller may reorder
    the two tokens, bury the path in prose, or pass a branch name where a path
    belongs; a third of real invocations did one of those (MXTS-80544). Writing
    the pair here takes that channel off the critical path.

    Keyed by session *and* repository, so two developers, and one session with
    PRs open in two repositories, each leave their own request. The review treats
    more than one live request as ambiguous and stops, rather than picking one
    and reviewing the wrong repository. A second attempt on the same repository
    reuses the filename, which is correct: there the newer request supersedes.
    """
    token = request_token(session_id)
    if not token or not repo or not head_sha:
        return
    try:
        directory = request_dir()
        os.makedirs(directory, exist_ok=True)
        now = time.time()
        prune_requests(directory, now)
        payload = {
            # Absolute: the review runs forked with a working directory it does
            # not control, so a relative `cd` target would resolve elsewhere.
            'repo': os.path.realpath(repo),
            'base': base,
            'head': head_sha,
            'session_id': token,
            'written_at': int(now),
        }
        final = os.path.join(directory, request_name(token, repo))
        tmp = final + '.tmp'
        with open(tmp, 'w') as handle:
            json.dump(payload, handle)
        os.replace(tmp, final)  # atomic: a reader never sees a partial file
    except OSError:
        # A hand-off that cannot be written is not a reason to block the PR. The
        # review still has its positional arguments to fall back on.
        pass


def try_exec(args, cwd=None):
    try:
        r = subprocess.run(args, capture_output=True, text=True, cwd=cwd)
        return {'out': r.stdout.strip(), 'ok': r.returncode == 0}
    except (FileNotFoundError, NotADirectoryError):
        return {'out': '', 'ok': False}


def log(msg: str) -> None:
    print(msg, file=sys.stderr, flush=True)


def allow() -> None:
    sys.exit(0)


def deny(reason: str) -> None:
    payload = {
        'hookSpecificOutput': {
            'hookEventName': 'PreToolUse',
            'permissionDecision': 'deny',
            'permissionDecisionReason': reason,
        }
    }
    print(json.dumps(payload))
    sys.exit(0)


def _split_segments(command: str):
    """Split a compound shell command into its sequential segments. Newlines
    separate commands too, so treat them like `&&`/`||`/`;`.

    A backslash immediately before a newline is a shell line-continuation: the
    command continues on the next physical line as one logical command. Collapse
    those to a space first, otherwise a multi-line `gh pr create … \\<newline>
    --title …` would be torn into separate segments (and the segment ending in a
    bare `\\` would fail to tokenize). `\\\r\n` handled for CRLF-authored input."""
    command = command.replace('\\\r\n', ' ').replace('\\\n', ' ')
    return re.split(r'&&|\|\||;|\n', command)


def _tokenize(segment: str):
    try:
        return shlex.split(segment)
    except ValueError:
        return []


def _is_gh_pr_create(tokens):
    """Does this segment invoke `gh pr create`? Detected regardless of leading
    prefixes (`GH_TOKEN=… gh pr create`, `env … gh pr create`, `command gh …`)
    by looking for the `gh pr create` token sequence anywhere in the list.
    Requiring `create` (not just `gh pr`) means earlier subcommands like
    `gh pr view` don't falsely match and short-circuit the scan."""
    for i in range(len(tokens) - 2):
        if tokens[i] == 'gh' and tokens[i + 1] == 'pr' and tokens[i + 2] == 'create':
            return True
    return False


def extract_workdir(command: str):
    """Parse a leading `cd <dir>` out of a compound shell command. Scanning
    stops at the `gh pr create` segment so a `cd` *after* it can't mislead us
    into reviewing the wrong repo. Returns the directory or None.

    Only `cd` is honoured: it persistently changes the directory the later
    `gh pr create` runs in. `git -C <dir>` is deliberately ignored — it scopes
    a single git invocation and does NOT change cwd for the subsequent `gh`."""
    workdir = None
    for segment in _split_segments(command):
        tokens = _tokenize(segment)
        if not tokens:
            continue
        if _is_gh_pr_create(tokens):
            break
        if tokens[0] == 'cd' and len(tokens) >= 2:
            workdir = tokens[1]
    return os.path.expanduser(workdir) if workdir else None


def shell_workdir(cd_dir, cwd):
    """The directory `gh pr create` runs in: a leading `cd` resolved against the
    shell's cwd from the event, else that cwd, else None (this process's cwd).

    The hook process's own cwd is not the shell's: Claude Code Desktop ran it in
    the main checkout while the session's shell sat in its worktree (MXTS-83500).
    """
    if cd_dir and cwd:
        return os.path.join(cwd, cd_dir)  # an absolute cd_dir wins
    return cd_dir or cwd or None


def gh_create_tokens(command: str):
    """Return the tokens of the `gh pr create` segment, or [] if not found.
    Flag parsing is restricted to this segment so flags from other commands in
    a compound invocation can't corrupt the resolved base/head."""
    for segment in _split_segments(command):
        tokens = _tokenize(segment)
        if _is_gh_pr_create(tokens):
            return tokens
    return []


def extract_flag(tokens, names):
    """Return the value of the first matching `--flag value` / `--flag=value`
    among the given tokens, or None. A shorthand also takes its value glued on
    (`-Rowner/repo`), as gh accepts it."""
    for i, tok in enumerate(tokens):
        following = tokens[i + 1] if i + 1 < len(tokens) else None
        for name in names:
            value = flag_value(tok, following, name)
            if value is not None:
                return value
    return None


def flag_value(tok, following, name):
    """The value `tok` gives the flag `name` (taken from `following` when `tok`
    is the bare flag), or None when `tok` isn't that flag."""
    if tok == name:
        return following
    if tok.startswith(name + '='):
        return tok[len(name) + 1:]
    if is_shorthand(name) and tok.startswith(name):
        return tok[len(name):]
    return None


def is_shorthand(name):
    """True for a one-letter flag such as `-R`, not a long one such as `--repo`."""
    return len(name) == 2 and name[0] == '-' and name[1] != '-'


def wants_help(tokens):
    """True when the invocation only asks gh for usage text.

    `gh pr create --help` prints help and creates nothing, but it still carries
    the `gh pr create` token sequence, so without this it is denied for missing
    a ticket number — a confusing refusal of a read-only command.
    """
    return any(tok in ('--help', '-h') for tok in tokens)


def draft_requested(tokens):
    """True when the create invocation asks for a draft pull request.

    gh accepts `--draft` and the `-d` shorthand. It also accepts an explicit
    `--draft=false`, which asks for the opposite, so match on the value rather
    than on the flag name alone.
    """
    for tok in tokens:
        if tok in ('--draft', '-d'):
            return True
        if tok.startswith('--draft='):
            return tok.split('=', 1)[1].strip().lower() in ('1', 't', 'true', 'y', 'yes')
    return False


DRAFT_REQUIRED = (
    'Open pull requests as drafts: add --draft (see the `pr-creation-required` rule). '
    'A ready-for-review PR notifies CODEOWNERS before CI has run and before Copilot '
    'has posted its review, so people review work that is still moving. '
    'Mark it ready with `gh pr ready <n>` once CI is green and Copilot\'s comments '
    'are addressed.'
)


def git_args(workdir):
    """Build the `git [-C <workdir>]` prefix so every git call is scoped to the
    PR's repo rather than the hook process's cwd."""
    return ['git', '-C', workdir] if workdir else ['git']


# The GitHub owners whose repositories follow Maxxton's PR rules (ticket key,
# draft, pre-PR review). Lowercase: GitHub owner names are case-insensitive.
MAXXTON_OWNERS = {'maxxtongroup'}


def repository_owner(text):
    """The lowercased owner in a remote URL or an `owner/repo` slug, e.g. both
    `git@github.com:MaxxtonGroup/x.git` and `MaxxtonGroup/x` give `maxxtongroup`;
    None when `text` names no owner."""
    parts = [p for p in re.split(r'[/:]', re.sub(r'\.git/?$', '', text.strip().rstrip('/'))) if p]
    return parts[-2].lower() if len(parts) >= 2 else None


def remote_owners(git):
    """The owners of all the checkout's remotes; empty when git can't list them."""
    remotes = try_exec(git + ['remote', '-v'])
    if not remotes['ok']:
        return set()
    fields = [line.split() for line in remotes['out'].splitlines()]
    return {repository_owner(f[1]) for f in fields if len(f) >= 2} - {None}


def bash_pr_owners(gh_tokens, git):
    """Every owner `gh pr create` might target: its --repo/-R, else every remote's.
    Without --repo, gh picks the default or `upstream` remote before `origin`, so a
    fork's MaxxtonGroup upstream must count. Empty when unknown."""
    named = extract_flag(gh_tokens, ['--repo', '-R'])
    if named is None:
        return remote_owners(git)
    # The hook sees the command before the shell expands it: `$OWNER/x` could be
    # MaxxtonGroup, so a target still holding shell syntax has no known owner.
    if any(ch in named for ch in '$`'):
        return set()
    return {repository_owner(named)} - {None}


def mcp_pr_owners(tool_input):
    """The owner the GitHub MCP create_pull_request call names; empty when it names none."""
    return {(tool_input.get('owner') or '').strip('/').lower()} - {''}


def review_marker_path(workdir, sha):
    """Absolute path of the marker recording that the review passed for `sha`.

    Lives inside the git directory so it is per-repo, never committed, and cleaned
    up with the checkout. Returns None when the git directory cannot be resolved.
    """
    git_dir = try_exec(git_args(workdir) + ['rev-parse', '--absolute-git-dir'])
    if not git_dir['ok'] or not git_dir['out']:
        return None
    return os.path.join(git_dir['out'], 'pre-pr-review-' + sha)


def worktrees(git):
    """(path, branch) for every checkout of this repository; branch is None when
    the checkout is detached. Empty when git cannot list them."""
    listing = try_exec(git + ['worktree', 'list', '--porcelain'])
    if not listing['ok']:
        return []
    found = []
    # One block per checkout, separated by a blank line, of "<key> <value>" lines.
    for block in listing['out'].split('\n\n'):
        fields = dict(line.partition(' ')[::2] for line in block.splitlines())
        ref = fields.get('branch', '')
        # Slicing, not str.removeprefix: run-python.sh accepts Pythons older than 3.9.
        branch = ref[len('refs/heads/'):] if ref.startswith('refs/heads/') else None
        found.append((fields.get('worktree'), branch))
    return found


def at_tip_of(git, branch):
    """True when HEAD is the commit `branch` points at, locally or on origin. CI
    jobs check out that commit detached, without the branch name."""
    here = try_exec(git + ['rev-parse', 'HEAD'])
    tips = (try_exec(git + ['rev-parse', '--verify', '--quiet', ref + '^{commit}'])
            for ref in (branch, 'origin/' + branch))
    return here['ok'] and any(tip['ok'] and tip['out'] == here['out'] for tip in tips)


def checkout_of(git, branch):
    """Path of the worktree that has `branch` checked out, or None."""
    return next((path for path, name in worktrees(git) if name == branch), None)


HEAD_NOT_CHECKED_OUT = (
    'The pull request is for branch {head}, which no local worktree has checked out, '
    'so the pre-PR review cannot run on it. Check it out in a worktree '
    '(/developer:starting-ticket-branch picks up an existing branch), run the pre-PR '
    'review there, then retry `gh pr create`.'
)


def review_passed(path):
    """True when the checkout at `path` has a passed review for its HEAD."""
    sha = try_exec(git_args(path) + ['rev-parse', 'HEAD'])
    marker = review_marker_path(path, sha['out']) if sha['ok'] and sha['out'] else None
    return bool(marker and os.path.isfile(marker))


def reviewed_elsewhere(git, here):
    """(path, branch) of the other checkouts whose HEAD has a passed review.

    In a worktree outside the project folder (starting-ticket-branch made those
    before MXTS-83500), Claude Code undoes a `cd` after each command, so
    `gh pr create` and this hook run in the main checkout while the review passed
    in the worktree.
    """
    here = os.path.realpath(here)
    return [(path, branch) for path, branch in worktrees(git)
            if branch and os.path.realpath(path) != here and review_passed(path)]


def resolve_base(workdir, override):
    """Resolve the PR's base branch. Prefer an explicit override (--base or the
    MCP `base` field), then origin/HEAD, then the first of the common default
    names that exists locally. Falls back to 'main'."""
    if override:
        return override
    git = git_args(workdir)
    head_ref = try_exec(git + ['symbolic-ref', '--short', 'refs/remotes/origin/HEAD'])
    if head_ref['ok'] and head_ref['out']:
        # Keep the full remote ref (e.g. `origin/main`). The default branch may
        # only exist as a remote ref — stripping to `main` would leave the
        # later merge-base/diff with an unresolvable base.
        return head_ref['out']
    for candidate in ('main', 'master', 'develop'):
        if try_exec(git + ['rev-parse', '--verify', '--quiet', candidate + '^{commit}'])['ok']:
            return candidate
    return 'main'


def main() -> None:
    # Read the PreToolUse event. The `if: "Bash(*gh pr create*)"` condition
    # filters most cases, but Claude Code fires unconditionally for Bash
    # commands it considers "too complex to parse" (pipes, heredocs, etc.).
    # Guard here so the full review never runs for non-PR Bash commands.
    if sys.stdin.isatty():
        event = {}
    else:
        try:
            event = json.load(sys.stdin)
        except (json.JSONDecodeError, EOFError, ValueError):
            event = {}

    # Expire abandoned requests before any decision below can return early.
    # write_review_request also prunes, but it runs only on the deny path, so on
    # its own it never expires a request from an attempt that was simply dropped.
    prune_requests(request_dir(), time.time())

    tool_name = event.get("tool_name")
    tool_input = event.get("tool_input") or {}
    command = tool_input.get("command", "") if tool_name == "Bash" else ""

    # Detect PR creation by tokens, not the raw substring. Claude Code fires
    # this hook for any Bash command whose text contains `gh pr create` —
    # including one that only *mentions* it inside a quoted arg (e.g.
    # `grep "gh pr create" …`) or splits the real invocation across
    # backslash-continued lines. gh_create_tokens returns the actual create
    # segment's tokens, or [] when none parses — the single source of truth for
    # both the "is this a PR create" decision and the flag lookups below.
    gh_tokens = gh_create_tokens(command) if tool_name == "Bash" else []

    if tool_name == "Bash" and not gh_tokens:
        # No create segment parsed: either not a PR create, or an invocation we
        # couldn't parse. Fail open — a hook must never deny a legitimate
        # command it failed to understand.
        allow()

    # `gh pr create --help` creates nothing; let it through before any check.
    if tool_name == "Bash" and wants_help(gh_tokens):
        allow()

    # Determine the directory the PR targets. For Bash, parse a leading
    # `cd`/`git -C`; for the GitHub MCP tool there's no local checkout to scope
    # to, so we fall back to the hook's cwd.
    workdir = None
    if tool_name == "Bash":
        workdir = shell_workdir(extract_workdir(command), event.get('cwd'))
    if workdir and not os.path.isdir(workdir):
        # Can't confidently scope the review — fall back to cwd, but surface the
        # discrepancy so a review against the wrong repo isn't silent.
        log(f"⚠️  Parsed PR directory '{workdir}' does not exist — "
            "falling back to the current directory for the review.")
        workdir = None
    git = git_args(workdir)

    # Every rule below is Maxxton's. A PR that provably can't reach a MaxxtonGroup
    # repository (a developer's own project) passes untouched; one whose owner can't
    # be told is still held to them, so an unreadable checkout never bypasses the gate.
    owners = bash_pr_owners(gh_tokens, git) if tool_name == "Bash" else mcp_pr_owners(tool_input)
    if owners and not owners & MAXXTON_OWNERS:
        log(f"ℹ️  PR targets a repository owned by {', '.join(sorted(owners))}, not MaxxtonGroup — "
            "skipping Maxxton's PR rules.")
        allow()

    # Validate PR title contains a ticket number before the expensive review.
    if tool_name == "Bash":
        _title = extract_flag(gh_tokens, ['--title', '-t'])
        if _title is None:
            # No --title/-t at all: gh would fall back to its interactive prompt
            # or commit-derived text, neither of which this hook can validate —
            # deny rather than silently let an unverifiable title through.
            deny(
                '`gh pr create` must pass --title explicitly with a ticket number, '
                'e.g. --title "MXTS-1234: ...". Omitting --title relies on gh\'s '
                'interactive prompt or commit-derived text, which this hook cannot '
                'validate. Add --title and retry.'
            )
        if not re.search(r'[A-Z]{2,4}-[0-9]+', _title):
            deny(
                'PR title is missing a ticket number. '
                'It must include the ticket key, e.g. MXTS-1234 or MCMS-1234. '
                'Rename the PR title and retry.'
            )
    else:
        _title = tool_input.get('title') or ''
        if not re.search(r'[A-Z]{2,4}-[0-9]+', _title):
            deny(
                'PR title is missing a ticket number. '
                'It must include the ticket key, e.g. MXTS-1234 or MCMS-1234. '
                'Rename the PR title and retry.'
            )

    # Require a draft. The `pr-creation-required` rule has said `gh pr create
    # --draft` since MXTS-80541, and PR #374 was still opened ready-for-review
    # with that rule active — guidance alone does not hold. A PreToolUse hook
    # cannot rewrite the command (there is no updatedInput for it), so refusing
    # is the only enforcement available.
    if not (draft_requested(gh_tokens) if tool_name == "Bash"
            else bool(tool_input.get('draft'))):
        deny(DRAFT_REQUIRED)

    # Skip if not inside a git repo.
    if not try_exec(git + ['rev-parse', '--is-inside-work-tree'])['ok']:
        allow()

    # Flag parsing is restricted to the create segment (gh_tokens, resolved
    # above) so flags belonging to other commands in a compound invocation
    # can't corrupt base/head.
    base_override = (
        extract_flag(gh_tokens, ['--base', '-B']) if tool_name == "Bash"
        else tool_input.get('base')
    )
    base = resolve_base(workdir, base_override)

    # A head branch other than the one checked out here is gated on the worktree
    # that has it checked out. With no such worktree there is no diff to review,
    # and allowing it would let any PR skip the review by naming its branch.
    head = (
        extract_flag(gh_tokens, ['--head', '-H']) if tool_name == "Bash"
        else tool_input.get('head')
    )
    if head:
        head = head.split(':', 1)[-1]  # strip any `owner:` prefix
        current = try_exec(git + ['rev-parse', '--abbrev-ref', 'HEAD'])
        other_branch = current['ok'] and current['out'] and current['out'] != head
        if other_branch and not at_tip_of(git, head):
            checkout = checkout_of(git, head)
            if not checkout:
                deny(HEAD_NOT_CHECKED_OUT.format(head=head))
            log(f"ℹ️  PR head '{head}' is checked out in {checkout} — checking that worktree.")
            workdir = checkout
            git = git_args(workdir)

    # Skip if no commits ahead of the base branch — nothing to review.
    if try_exec(git + ['merge-base', '--is-ancestor', 'HEAD', base])['ok']:
        allow()

    # Two-phase gate. This hook does not run the review itself: a review long
    # enough to be useful outlasts any tolerable PreToolUse budget, and killing it
    # mid-flight left the PR looking reviewed. Instead the review runs in-session
    # via /developer:reviewing-pre-pr, which records its pass for the exact commit
    # it reviewed. This hook only checks for that record.
    # Deliberately not named `head`: that already holds the PR's --head branch above.
    head_sha = try_exec(git + ['rev-parse', 'HEAD'])
    if not head_sha['ok'] or not head_sha['out']:
        # Cannot identify the commit, so cannot check or demand a review for it.
        # Fail open rather than block a PR on an unreadable repo.
        log('⚠️  could not resolve HEAD — skipping the pre-PR review gate')
        allow()

    marker = review_marker_path(workdir, head_sha['out'])
    if marker is None:
        log('⚠️  could not locate the git directory — skipping the pre-PR review gate')
        allow()

    if os.path.isfile(marker):
        log('✅ pre-PR review already passed for this commit')
        # The gate is open, so this session's hand-off has served its purpose.
        # Left behind, it becomes a plausible wrong target for the next review.
        clear_request(event.get('session_id'), workdir or toplevel_of(git))
        allow()

    # Name a concrete repository whenever we can prove which one it is. The review
    # refuses to guess a target, so a message naming no repository is strictly
    # better than one naming the wrong repository: the first stops, the second
    # reviews unrelated code and marks it passed.
    repo_path = workdir
    if not repo_path:
        toplevel = try_exec(git + ['rev-parse', '--show-toplevel'])
        candidate = toplevel['out'] if toplevel['ok'] and toplevel['out'] else None
        # On the Bash path this hook already ran every check against that directory,
        # so it is by definition the repo whose marker was looked for. The MCP path
        # is different: there is no `cd` to parse, and the request names a *remote*
        # owner/repo that need not be the checkout this session happens to sit in.
        # Only trust cwd there when its origin actually matches what was requested.
        if candidate and tool_name != "Bash":
            owner = (tool_input.get('owner') or '').strip('/')
            name = (tool_input.get('repo') or '').strip('/')
            origin = try_exec(git + ['remote', 'get-url', 'origin'])
            slug = ''
            if origin['ok'] and origin['out']:
                slug = re.sub(r'\.git$', '', origin['out']).lower()
            if not (owner and name and slug.endswith(f'{owner}/{name}'.lower())):
                candidate = None
        repo_path = candidate

    # Quote the path. `extract_workdir` deliberately supports directories
    # containing whitespace, and the review's arguments are positional — an
    # unquoted path with a space arrives as two tokens and truncates $repo.
    if repo_path:
        # Absolute: a relative `cd` target printed verbatim is not `/`-rooted, so
        # the review's argument scan discards it and recovery falls back to the
        # hand-off unnecessarily. abspath, not realpath — resolving symlinks
        # would rewrite the very path the developer typed, and `git -C` accepts
        # either form.
        repo_path = os.path.abspath(repo_path)
        invocation = f'`/developer:reviewing-pre-pr {base} "{repo_path}"`'
        target_note = (
            'Pass exactly those two arguments and nothing else — they are '
            'positional, so a sentence of prose silently replaces them and the '
            'review lands on the wrong repository. '
        )
    else:
        # This deny cannot say which repository the PR targets, so no earlier
        # hand-off of ours may stand in for one. See clear_session_requests.
        clear_session_requests(event.get('session_id'))
        invocation = f'`/developer:reviewing-pre-pr {base} "<path to the repository>"`'
        target_note = (
            'This request does not identify which local checkout the pull request '
            'targets, so substitute its path yourself — the review stops rather '
            'than guessing one. Pass exactly those two arguments and nothing '
            'else; they are positional, so prose silently replaces them. '
        )
    write_review_request(event.get('session_id'), repo_path, base, head_sha['out'])

    # Only without --head: with it, the developer already named the branch.
    hintable = repo_path and tool_name == "Bash" and not head
    elsewhere = reviewed_elsewhere(git, repo_path) if hintable else []
    hint = ''.join(
        f'The review passed for branch {branch} in "{path}", but `gh pr create` runs in '
        f'"{repo_path}" and would open the pull request for that checkout\'s own branch. '
        f'If the pull request is for {branch}, add `--head {branch}` and retry. '
        for path, branch in elsewhere)
    deny(
        hint + 'Pre-PR review has not passed for this commit. Run '
        f'{invocation} now, address anything it '
        f'reports, then retry `gh pr create`. {target_note}If it stalls '
        'asking what to do, re-invoke it with the same two arguments rather than '
        'answering in prose. The '
        'review records its pass against the current commit, so new commits need a '
        'fresh review. If the review has already passed and this still blocks, say '
        'so instead of re-running it — the record could not be written.'
    )


if __name__ == '__main__':
    main()
