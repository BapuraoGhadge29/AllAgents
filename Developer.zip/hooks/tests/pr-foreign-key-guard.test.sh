#!/usr/bin/env bash
# Tests for pr-foreign-key-guard.py
# Usage: bash tests/pr-foreign-key-guard.test.sh
#
# `gh` is stubbed on PATH so the `gh pr edit` path (which reads the existing PR's
# title and branch) runs without a live PR. The bodies below are taken from real
# MaxxtonGroup PRs: maxxton-workspace#224 got linked to MXTS-78693 through the
# first one, and the others are typical of the 263 of 818 workspace PRs that
# mention another ticket's key.
set -uo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SCRIPT="$SCRIPT_DIR/../pr-foreign-key-guard.py"

resolve_python() {
  local _cand
  for _cand in python3 python "py -3"; do
    if $_cand -c 'import sys; sys.exit(0 if sys.version_info[0] == 3 else 1)' >/dev/null 2>&1; then
      printf '%s\n' "$_cand"; return 0
    fi
  done
  return 1
}
PY=$(resolve_python) || { echo "no Python 3 found (tried python3, python, py -3)" >&2; exit 1; }
read -r -a PY_CMD <<< "$PY"

RED='\033[0;31m'; GREEN='\033[0;32m'; NC='\033[0m'
pass=0; fail=0

STUB_DIR=$(mktemp -d)
trap 'rm -rf "$STUB_DIR"' EXIT

# A `gh` that answers `gh pr view` from view.json, fails when view.rc holds an
# exit code, and records its argv.
cat > "$STUB_DIR/gh" <<'STUB'
#!/usr/bin/env bash
printf '%s\n' "$*" >> "$GH_STUB_DIR/argv.log"
[ -s "$GH_STUB_DIR/view.rc" ] && { echo "stub: view failed" >&2; exit "$(cat "$GH_STUB_DIR/view.rc")"; }
cat "$GH_STUB_DIR/view.json"; exit 0
STUB
chmod +x "$STUB_DIR/gh"
export GH_STUB_DIR="$STUB_DIR"

reset_stub() { # <title> <headRefName>
  : > "$STUB_DIR/argv.log"
  : > "$STUB_DIR/view.rc"
  printf '{"title":"%s","headRefName":"%s"}\n' "$1" "$2" > "$STUB_DIR/view.json"
}

json_str() { "${PY_CMD[@]}" -c 'import json,sys;print(json.dumps(sys.argv[1]))' "$1"; }

# run_bash <command> [cwd] -> prints stdout of the hook
run_bash() {
  printf '{"tool_name":"Bash","cwd":%s,"tool_input":{"command":%s}}' \
    "$(json_str "${2:-$STUB_DIR}")" "$(json_str "$1")" \
    | PATH="$STUB_DIR:$PATH" "${PY_CMD[@]}" "$SCRIPT" 2>/dev/null
}

# run_mcp <tool_name> <tool_input-json> -> prints stdout of the hook
run_mcp() {
  printf '{"tool_name":%s,"cwd":%s,"tool_input":%s}' "$(json_str "$1")" "$(json_str "$STUB_DIR")" "$2" \
    | PATH="$STUB_DIR:$PATH" "${PY_CMD[@]}" "$SCRIPT" 2>/dev/null
}

is_deny() {
  printf '%s' "$1" | "${PY_CMD[@]}" -c "
import json,sys
try: d=json.load(sys.stdin)
except Exception: sys.exit(2)
sys.exit(0 if (d.get('hookSpecificOutput') or {}).get('permissionDecision')=='deny' else 1)
" 2>/dev/null
}
reason() {
  printf '%s' "$1" | "${PY_CMD[@]}" -c "
import json,sys
try: d=json.load(sys.stdin)
except Exception: sys.exit(0)
print((d.get('hookSpecificOutput') or {}).get('permissionDecisionReason',''))
" 2>/dev/null
}

expect_allow() { # <label> <stdout>
  if [ -z "$2" ]; then printf "  ${GREEN}PASS${NC} %s\n" "$1"; pass=$((pass+1));
  else printf "  ${RED}FAIL${NC} %s (expected allow, got %s)\n" "$1" "$2"; fail=$((fail+1)); fi
}
expect_deny() { # <label> <stdout> <substring>
  if is_deny "$2" && reason "$2" | grep -Fq -- "$3"; then
    printf "  ${GREEN}PASS${NC} %s\n" "$1"; pass=$((pass+1))
  else printf "  ${RED}FAIL${NC} %s (got %s)\n" "$1" "$2"; fail=$((fail+1)); fi
}
expect_not_named() { # <label> <stdout> <substring>
  if is_deny "$2" && ! reason "$2" | grep -Fq -- "$3"; then
    printf "  ${GREEN}PASS${NC} %s\n" "$1"; pass=$((pass+1))
  else printf "  ${RED}FAIL${NC} %s (got %s)\n" "$1" "$2"; fail=$((fail+1)); fi
}

PR224='The MXTS-78693 post in this item (Git-Bash /d/... paths in is_gate_exempt_checkout) is a separate Windows issue and is not covered here.'
CREATE='gh pr create --draft --repo MaxxtonGroup/maxxton-workspace --base main --head bugfix/MXTS-76388-per-repo-guards'
NBH=$'‑'

echo "another ticket's key in the body is refused"
expect_deny "the PR #224 sentence → deny naming MXTS-78693" \
  "$(run_bash "$CREATE --title 'fix(hooks): MXTS-76388: document per-repo guards' --body '$PR224'")" "MXTS-78693"

expect_deny "epic and out-of-scope references → deny naming both" \
  "$(run_bash "$CREATE --title 'MXTS-76388: list view' --body 'Part of epic MXTS-78286. Out of scope: Overview embed (MXTS-79602).'")" "MXTS-79602"

expect_not_named "the PR's own key is never named" \
  "$(run_bash "$CREATE --title 'MXTS-76388: x' --body 'MXTS-76388 fixes what MXTS-78693 reported'")" "MXTS-76388,"

heredoc_cmd="$CREATE --title 'MXTS-76388: x' --body \"\$(cat <<'EOF'
## Why

$PR224
EOF
)\""
expect_deny "heredoc body → deny" "$(run_bash "$heredoc_cmd")" "MXTS-78693"

printf '%s\n' "$PR224" > "$STUB_DIR/body.md"
expect_deny "--body-file → deny" \
  "$(run_bash "$CREATE --title 'MXTS-76388: x' --body-file body.md")" "MXTS-78693"
expect_deny "-F shorthand, absolute path → deny" \
  "$(run_bash "$CREATE --title 'MXTS-76388: x' -F $STUB_DIR/body.md")" "MXTS-78693"

expect_deny "body written by an earlier heredoc in the same command → deny" \
  "$(run_bash "cat > /tmp/never-written.md <<'EOF'
$PR224
EOF
$CREATE --title 'MXTS-76388: x' --body-file /tmp/never-written.md")" "MXTS-78693"

expect_deny "the deny message offers the non-breaking hyphen" \
  "$(run_bash "$CREATE --title 'MXTS-76388: x' --body '$PR224'")" "MXTS${NBH}78693"

REPO="$STUB_DIR/repo"
git init -q -b bugfix/MXTS-76388-x "$REPO" 2>/dev/null || { git init -q "$REPO"; git -C "$REPO" checkout -q -b bugfix/MXTS-76388-x; }
git -C "$REPO" remote add origin git@github.com:MaxxtonGroup/maxxton-workspace.git
expect_deny "cd into the checkout, branch and owner from git → deny" \
  "$(run_bash "cd repo && gh pr create --draft --title 'fix: x' --body '$PR224'")" "MXTS-78693"

echo ""
echo "text that cannot link to another ticket passes"
expect_allow "a key in the title too → allow (the PR really covers both)" \
  "$(run_bash "$CREATE --title 'MXTS-76388 / MXTS-78693: x' --body '$PR224'")"

expect_allow "key written with a non-breaking hyphen → allow" \
  "$(run_bash "$CREATE --title 'MXTS-76388: x' --body 'The MXTS${NBH}78693 post is not covered.'")"

expect_allow "UTF-8, SHA-256, ISO-8601 are not Jira projects → allow" \
  "$(run_bash "$CREATE --title 'MXTS-76388: x' --body 'Reads UTF-8, hashes with SHA-256, dates as ISO-8601.'")"

expect_allow "stacked PR: the base branch's key is not PR text → allow" \
  "$(run_bash "gh pr create --draft --repo MaxxtonGroup/x --base feature/MXTS-80001-parent --head feature/MXTS-80002-child --title 'MXTS-80002: child' --body 'Builds on the parent branch.'")"

expect_deny "stacked PR: a key in the body still counts → deny" \
  "$(run_bash "gh pr create --draft --repo MaxxtonGroup/x -B feature/MXTS-80001-parent --head feature/MXTS-80002-child --title 'MXTS-80002: child' --body 'Builds on MXTS-80001.'")" "MXTS-80001"

expect_deny "stacked PR: the base branch named in the body still counts → deny" \
  "$(run_bash "gh pr create --draft --repo MaxxtonGroup/x --base feature/MXTS-80001-parent --head feature/MXTS-80002-child --title 'MXTS-80002: child' --body 'Stacked on feature/MXTS-80001-parent.'")" "MXTS-80001"

expect_allow "stacked PR: --base=value form → allow" \
  "$(run_bash "gh pr create --draft --repo MaxxtonGroup/x --base=feature/MXTS-80001-parent --head feature/MXTS-80002-child --title 'MXTS-80002: child' --body 'Child work.'")"

expect_deny "stacked PR: a body quoting '--base <branch>' still counts → deny" \
  "$(run_bash "gh pr create --draft --repo MaxxtonGroup/x --base feature/MXTS-80001-parent --head feature/MXTS-80002-child --title 'MXTS-80002: child' --body 'Opened with --base feature/MXTS-80001-parent.'")" "MXTS-80001"

expect_allow "stacked PR: --base continued onto the next line → allow" \
  "$(run_bash "gh pr create --draft --repo MaxxtonGroup/x --base \\
  feature/MXTS-80001-parent --head feature/MXTS-80002-child --title 'MXTS-80002: child' --body 'Child work.'")"

expect_deny "compound: --help first, then a real create → deny" \
  "$(run_bash "gh pr create --help; $CREATE --title 'MXTS-76388: x' --body '$PR224'")" "MXTS-78693"

expect_deny "compound: another owner first, then a MaxxtonGroup create → deny" \
  "$(run_bash "gh pr create --draft --repo AcmeOrg/acme --head bugfix/MXTS-1 --title 'MXTS-1: x' --body 'ok' && $CREATE --title 'MXTS-76388: x' --body '$PR224'")" "MXTS-78693"

expect_allow "only the own key → allow" \
  "$(run_bash "$CREATE --title 'MXTS-76388: x' --body 'Implements MXTS-76388.'")"

expect_allow "a repo outside MaxxtonGroup → allow" \
  "$(run_bash "gh pr create --draft --repo AcmeOrg/acme --head bugfix/MXTS-1 --title 'MXTS-1: x' --body '$PR224'")"

expect_allow "a command that only mentions gh pr create → allow" \
  "$(run_bash "grep -n 'gh pr create --body MXTS-78693' notes.md")"

expect_allow "gh pr create --help → allow" "$(run_bash "gh pr create --help")"

expect_allow "unparseable command → allow (fail open)" \
  "$(run_bash "$CREATE --title 'MXTS-76388: x' --body 'unterminated $PR224")"

expect_allow "no own key anywhere → allow (pre-pr-review asks for the ticket)" \
  "$(run_bash "gh pr create --draft --repo MaxxtonGroup/x --head my-branch --title 'no ticket' --body '$PR224'")"

echo ""
echo "gh pr edit reads the PR's own keys from the PR"
reset_stub "fix(hooks): MXTS-76388: document per-repo guards" "bugfix/MXTS-76388-per-repo-guards"
expect_deny "edit body with another key → deny" \
  "$(run_bash "gh pr edit 224 --repo MaxxtonGroup/maxxton-workspace --body '$PR224'")" "MXTS-78693"
if grep -q -- 'pr view 224 --repo MaxxtonGroup/maxxton-workspace --json title,headRefName' "$STUB_DIR/argv.log"; then
  printf "  ${GREEN}PASS${NC} edit passes the selector and --repo to gh pr view\n"; pass=$((pass+1))
else printf "  ${RED}FAIL${NC} gh pr view argv (log=%s)\n" "$(cat "$STUB_DIR/argv.log")"; fail=$((fail+1)); fi

reset_stub "MXTS-76388 / MXTS-78693: both" "bugfix/MXTS-76388-x"
expect_allow "edit of a PR whose title already has that key → allow" \
  "$(run_bash "gh pr edit 224 --repo MaxxtonGroup/maxxton-workspace --body '$PR224'")"

reset_stub "MXTS-76388: x" "bugfix/MXTS-76388-x"
expect_allow "edit of labels only → allow" \
  "$(run_bash "gh pr edit 224 --repo MaxxtonGroup/maxxton-workspace --add-label foo")"

reset_stub "MXTS-76388: x" "bugfix/MXTS-76388-x"
printf '1\n' > "$STUB_DIR/view.rc"
expect_allow "gh pr view fails → allow (fail open)" \
  "$(run_bash "gh pr edit 224 --repo MaxxtonGroup/maxxton-workspace --body '$PR224'")"

echo ""
echo "the GitHub MCP tools are checked too"
mcp_body=$(json_str "$PR224")
# Payloads are built in variables: inside "$(...)" bash brace-expands a JSON literal on its commas.
create_mxt='{"owner":"MaxxtonGroup","repo":"maxxton-workspace","title":"MXTS-76388: x","head":"bugfix/MXTS-76388-x","base":"main","body":'"$mcp_body"'}'
create_acme='{"owner":"AcmeOrg","repo":"acme","title":"MXTS-1: x","head":"bugfix/MXTS-1","body":'"$mcp_body"'}'
update_mxt='{"owner":"MaxxtonGroup","repo":"maxxton-workspace","pullNumber":224,"body":'"$mcp_body"'}'

expect_deny "MCP create with another key → deny" \
  "$(run_mcp mcp__claude_ai_GitHub__create_pull_request "$create_mxt")" "MXTS-78693"

expect_allow "MCP create, other owner → allow" \
  "$(run_mcp mcp__plugin_github_github__create_pull_request "$create_acme")"

reset_stub "MXTS-76388: x" "bugfix/MXTS-76388-x"
expect_deny "MCP update body with another key → deny" \
  "$(run_mcp mcp__claude_ai_GitHub__update_pull_request "$update_mxt")" "MXTS-78693"

echo ""
echo "the hook payload itself"
bad_payload_out=$(printf 'not json at all' | PATH="$STUB_DIR:$PATH" "${PY_CMD[@]}" "$SCRIPT" 2>/dev/null)
expect_allow "unreadable hook payload → allow (fail open)" "$bad_payload_out"

echo ""
total=$((pass + fail))
echo "Results: ${pass}/${total} passed"
[ "$fail" -eq 0 ]
