#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SCRIPT="$SCRIPT_DIR/../subagent-recovery.py"

RED='\033[0;31m'
GREEN='\033[0;32m'
NC='\033[0m'
pass=0
fail=0

assert_exit_zero() {
  local description="$1"
  local input="$2"
  local actual_exit=0
  echo "$input" | python3 "$SCRIPT" >/dev/null 2>&1 || actual_exit=$?
  if [ "$actual_exit" -eq 0 ]; then
    printf "  ${GREEN}PASS${NC} %s\n" "$description"
    pass=$((pass + 1))
  else
    printf "  ${RED}FAIL${NC} %s (exit=%d)\n" "$description" "$actual_exit"
    fail=$((fail + 1))
  fi
}

# Parses stdout as JSON and asserts the PostToolUse envelope carries a
# non-empty hookSpecificOutput.additionalContext string. Fail-closed: any
# parse error, missing key, or wrong shape is a test FAIL (PR #196 — grep on a
# JSON-shaped substring passes on broken JSON, so we parse instead).
assert_emits_context() {
  local description="$1"
  local input="$2"
  local output
  output=$(echo "$input" | python3 "$SCRIPT" 2>/dev/null || true)
  if printf '%s' "$output" | python3 -c "
import sys, json
d = json.load(sys.stdin)
ctx = d['hookSpecificOutput']['additionalContext']
sys.exit(0 if isinstance(ctx, str) and ctx else 1)
" 2>/dev/null; then
    printf "  ${GREEN}PASS${NC} %s\n" "$description"
    pass=$((pass + 1))
  else
    printf "  ${RED}FAIL${NC} %s (output: %s)\n" "$description" "$output"
    fail=$((fail + 1))
  fi
}

assert_output_empty() {
  local description="$1"
  local input="$2"
  local output
  output=$(echo "$input" | python3 "$SCRIPT" 2>/dev/null || true)
  if [ -z "$output" ]; then
    printf "  ${GREEN}PASS${NC} %s\n" "$description"
    pass=$((pass + 1))
  else
    printf "  ${RED}FAIL${NC} %s (expected empty, got: %s)\n" "$description" "$output"
    fail=$((fail + 1))
  fi
}

echo "subagent-recovery.py test suite"
echo "================================"

echo ""
echo "Non-Task tool — should be silent (exit 0, no output)"
assert_output_empty \
  "non-Task tool is silent" \
  '{"tool_name": "Bash", "tool_response": "error: something failed"}'

echo ""
echo "Task tool with happy-path response — should be silent"
assert_output_empty \
  "Task success is silent" \
  '{"tool_name": "Task", "tool_response": "All steps completed successfully."}'

echo ""
echo "Task tool with failure signals — should emit reminder"
assert_emits_context \
  "Task with 'failed' emits additionalContext" \
  '{"tool_name": "Task", "tool_response": "The subtask failed to complete."}'

assert_emits_context \
  "Task with 'error:' emits additionalContext" \
  '{"tool_name": "Task", "tool_response": "error: could not connect"}'

assert_emits_context \
  "Task with 'timed out' emits additionalContext" \
  '{"tool_name": "Task", "tool_response": "The operation timed out after 30s."}'

assert_emits_context \
  "Task with 'unable to' emits additionalContext" \
  '{"tool_name": "Task", "tool_response": "Agent was unable to read the file."}'

echo ""
echo "Invalid JSON — should exit 0 silently (fail-closed)"
assert_exit_zero \
  "invalid JSON exits 0" \
  "not-json"

assert_exit_zero \
  "empty stdin exits 0" \
  ""

echo ""
total=$((pass + fail))
echo "Results: ${pass}/${total} passed"
[ "$fail" -eq 0 ]
