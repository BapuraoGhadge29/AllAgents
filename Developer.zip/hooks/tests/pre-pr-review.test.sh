#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SCRIPT="$SCRIPT_DIR/../pre-pr-review.py"
FIXTURES="$SCRIPT_DIR/fixtures"

# Resolve a Python 3 interpreter (python3 → python → py -3) by execution so the
# Windows Store-alias stub is rejected; run via "${PY_CMD[@]}" (Windows Git Bash).
resolve_python() {
  local _cand
  for _cand in python3 python "py -3"; do
    if $_cand -c 'import sys; sys.exit(0 if sys.version_info[0] == 3 else 1)' >/dev/null 2>&1; then
      printf '%s\n' "$_cand"; return 0
    fi
  done
  return 1
}
PY=$(resolve_python) || { echo "no Python 3 found (tried python3, python, py -3)" >&2; exit 1; }
read -r -a PY_CMD <<< "$PY"

# Keep the hook's hand-off out of the developer's real ~/.claude while
# testing. Created after the interpreter check so an early exit there
# cannot leak the directory.
CLAUDE_PRE_PR_REVIEW_DIR=$(mktemp -d)
export CLAUDE_PRE_PR_REVIEW_DIR
cleanup_handoff() { rm -rf "$CLAUDE_PRE_PR_REVIEW_DIR"; }
trap cleanup_handoff EXIT

RED='\033[0;31m'
GREEN='\033[0;32m'
NC='\033[0m'
pass=0
fail=0

# Helper: does $1 contain a permissionDecision: "deny" envelope (parsed as JSON)?
is_deny() {
  printf '%s' "$1" | "${PY_CMD[@]}" -c "
import json, sys
try:
    d = json.load(sys.stdin)
except Exception:
    sys.exit(2)
out = d.get('hookSpecificOutput') or {}
sys.exit(0 if out.get('permissionDecision') == 'deny' else 1)
" 2>/dev/null
}

# Print the decoded deny reason. The raw stdout is JSON, so a repository path is
# emitted with its surrounding quotes escaped as \" — grepping the raw string for
# a quoted path would need double-escaping and silently stops matching when the
# encoding changes. Assert against the decoded text instead.
deny_reason() {
  printf '%s' "$1" | "${PY_CMD[@]}" -c "
import json, sys
try:
    d = json.load(sys.stdin)
except Exception:
    sys.exit(0)
out = d.get('hookSpecificOutput') or {}
sys.stdout.write(out.get('permissionDecisionReason') or '')
" 2>/dev/null
}

echo "pre-pr-review.py test suite"
echo "==========================="

echo ""
echo "Outside a git repo — should allow (no deny envelope)"
NON_GIT_DIR=$(mktemp -d)
cleanup() { rm -rf "$NON_GIT_DIR"; cleanup_handoff; }
trap cleanup EXIT

payload="$(cat "$FIXTURES/clean-pr-create.json")"
actual_exit=0
actual_stdout=$(cd "$NON_GIT_DIR" && printf '%s' "$payload" | "${PY_CMD[@]}" "$SCRIPT" 2>/dev/null) || actual_exit=$?

if [ "$actual_exit" -eq 0 ] && ! is_deny "$actual_stdout"; then
  printf "  ${GREEN}PASS${NC} outside git repo → allow (no envelope)\n"
  pass=$((pass + 1))
else
  printf "  ${RED}FAIL${NC} outside git repo should allow (exit=%d stdout=%s)\n" "$actual_exit" "$actual_stdout"
  fail=$((fail + 1))
fi

echo ""
echo "py_compile on script — should succeed"
if "${PY_CMD[@]}" -m py_compile "$SCRIPT" 2>/dev/null; then
  printf "  ${GREEN}PASS${NC} py_compile passes\n"
  pass=$((pass + 1))
else
  printf "  ${RED}FAIL${NC} py_compile failed\n"
  fail=$((fail + 1))
fi

echo ""
echo "Bash non-PR command — should exit immediately (no deny envelope)"
payload="$(cat "$FIXTURES/bash-non-pr.json")"
actual_exit=0
actual_stdout=$(printf '%s' "$payload" | "${PY_CMD[@]}" "$SCRIPT" 2>/dev/null) || actual_exit=$?

if [ "$actual_exit" -eq 0 ] && ! is_deny "$actual_stdout"; then
  printf "  ${GREEN}PASS${NC} Bash non-PR → exit 0 (no envelope)\n"
  pass=$((pass + 1))
else
  printf "  ${RED}FAIL${NC} Bash non-PR should exit 0 without deny (exit=%d stdout=%s)\n" "$actual_exit" "$actual_stdout"
  fail=$((fail + 1))
fi

echo ""
echo "Bash gh pr create with no --title flag — should deny (unvalidatable title)"
payload="$(cat "$FIXTURES/bash-pr-create-no-title.json")"
actual_stdout=$(cd "$NON_GIT_DIR" && printf '%s' "$payload" | "${PY_CMD[@]}" "$SCRIPT" 2>/dev/null)
if is_deny "$actual_stdout"; then
  printf "  ${GREEN}PASS${NC} Bash no --title → deny\n"
  pass=$((pass + 1))
else
  printf "  ${RED}FAIL${NC} expected deny, got: %s\n" "$actual_stdout"
  fail=$((fail + 1))
fi

echo ""
echo "Bash PR-create split across lines with a backslash + valid --title — should allow"
payload="$(cat "$FIXTURES/bash-pr-create-multiline-title.json")"
actual_exit=0
actual_stdout=$(cd "$NON_GIT_DIR" && printf '%s' "$payload" | "${PY_CMD[@]}" "$SCRIPT" 2>/dev/null) || actual_exit=$?
if [ "$actual_exit" -eq 0 ] && ! is_deny "$actual_stdout"; then
  printf "  ${GREEN}PASS${NC} multi-line create with title → allow\n"
  pass=$((pass + 1))
else
  printf "  ${RED}FAIL${NC} title must be detected across the backslash-continuation (exit=%d stdout=%s)\n" "$actual_exit" "$actual_stdout"
  fail=$((fail + 1))
fi

echo ""
echo "Bash command only mentioning the create phrase inside a quoted arg (grep) — should allow"
payload="$(cat "$FIXTURES/bash-grep-mentions-pr-create.json")"
actual_exit=0
actual_stdout=$(cd "$NON_GIT_DIR" && printf '%s' "$payload" | "${PY_CMD[@]}" "$SCRIPT" 2>/dev/null) || actual_exit=$?
if [ "$actual_exit" -eq 0 ] && ! is_deny "$actual_stdout"; then
  printf "  ${GREEN}PASS${NC} quoted-arg mention → not a PR-create → allow\n"
  pass=$((pass + 1))
else
  printf "  ${RED}FAIL${NC} a phrase inside a quoted arg must not be treated as a PR-create (exit=%d stdout=%s)\n" "$actual_exit" "$actual_stdout"
  fail=$((fail + 1))
fi

echo ""
echo "Bash PR-create --title lacking a ticket key — should deny"
payload="$(cat "$FIXTURES/bash-pr-create-title-no-ticket.json")"
actual_stdout=$(cd "$NON_GIT_DIR" && printf '%s' "$payload" | "${PY_CMD[@]}" "$SCRIPT" 2>/dev/null)
if is_deny "$actual_stdout"; then
  printf "  ${GREEN}PASS${NC} title missing ticket → deny\n"
  pass=$((pass + 1))
else
  printf "  ${RED}FAIL${NC} expected deny, got: %s\n" "$actual_stdout"
  fail=$((fail + 1))
fi

echo ""
echo "Bash multi-line PR-create with NO --title — should deny (continuation must not fail open)"
# Guards that normalization keeps the genuine title check alive across a
# backslash-continuation: without it the torn segments make gh_create_tokens
# return [] and the command would wrongly fall through the fail-open allow().
payload="$(cat "$FIXTURES/bash-pr-create-multiline-no-title.json")"
actual_stdout=$(cd "$NON_GIT_DIR" && printf '%s' "$payload" | "${PY_CMD[@]}" "$SCRIPT" 2>/dev/null)
if is_deny "$actual_stdout"; then
  printf "  ${GREEN}PASS${NC} multi-line, no title → deny\n"
  pass=$((pass + 1))
else
  printf "  ${RED}FAIL${NC} expected deny (guard must survive the continuation), got: %s\n" "$actual_stdout"
  fail=$((fail + 1))
fi

echo ""
echo "Parsing helpers (extract_workdir / extract_flag) — unit checks"
if "${PY_CMD[@]}" - "$SCRIPT" <<'PY'
import importlib.util, sys

spec = importlib.util.spec_from_file_location("prepr", sys.argv[1])
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)  # safe: main() is guarded by __name__ == '__main__'

def flag(command, names):
    return mod.extract_flag(mod.gh_create_tokens(command), names)

cases = [
    # leading `cd <dir>` before gh is picked up
    (mod.extract_workdir("cd /other/repo && gh pr create --draft --title x"), "/other/repo"),
    # a `cd` *after* the gh invocation must not win
    (mod.extract_workdir("gh pr create && cd /elsewhere"), None),
    # quoted path with spaces
    (mod.extract_workdir("cd '/two words/repo' && gh pr create"), "/two words/repo"),
    # plain command, no cd
    (mod.extract_workdir("gh pr create --fill"), None),
    # `git -C` is NOT honoured — it doesn't change cwd for the later gh
    (mod.extract_workdir("git -C /svc status && cd /repo && gh pr create"), "/repo"),
    # an earlier `gh pr view` must not short-circuit the scan; the cd after it
    # (before `gh pr create`) still wins
    (mod.extract_workdir("gh pr view 1 && cd /repo && gh pr create --base develop"), "/repo"),
    # env-var / `env` / `command` prefixes before gh are still detected, so a
    # trailing cd cannot override the workdir
    (mod.extract_workdir("cd /a && GH_TOKEN=x gh pr create && cd /b"), "/a"),
    (mod.extract_workdir("cd /a && env GH_TOKEN=x gh pr create && cd /b"), "/a"),
    (mod.extract_workdir("GH_TOKEN=x gh pr create && cd /b"), None),
    # newlines separate commands like `&&`
    (mod.extract_workdir("cd /a &&\n gh pr create"), "/a"),
    # --base flag, spaced and = forms (parsed only from the gh segment)
    (flag("gh pr create --base develop", ["--base", "-B"]), "develop"),
    (flag("gh pr create --base=release/1.2", ["--base", "-B"]), "release/1.2"),
    (flag("gh pr create --fill", ["--base", "-B"]), None),
    (flag("gh pr create --head feature/x", ["--head", "-H"]), "feature/x"),
    # a --base belonging to a *different* command must NOT be picked up
    (flag("gh pr create --fill && git config core.x --base hijack", ["--base", "-B"]), None),
    (flag("cd /a && gh pr create --base develop", ["--base", "-B"]), "develop"),
    # an earlier `gh pr view` segment must not capture the flags
    (flag("gh pr view 1 && gh pr create --base develop", ["--base", "-B"]), "develop"),
    # a backslash-newline line-continuation is collapsed, so a --title on the
    # next physical line is still parsed from the same create segment
    (flag('gh pr create --draft --title "MXTS-1: x" \\\n--body y', ["--title", "-t"]), "MXTS-1: x"),
    # the phrase inside a quoted arg is a single token, not the bare gh/pr/create
    # sequence — so it is NOT detected as a create segment
    (mod.gh_create_tokens('grep -rn "gh pr create" .claude/'), []),
]
ok = True
for got, want in cases:
    if got != want:
        print(f"  mismatch: got {got!r} want {want!r}", file=sys.stderr)
        ok = False
sys.exit(0 if ok else 1)
PY
then
  printf "  ${GREEN}PASS${NC} parsing helpers behave as expected\n"
  pass=$((pass + 1))
else
  printf "  ${RED}FAIL${NC} parsing helpers returned unexpected values\n"
  fail=$((fail + 1))
fi

echo ""
echo "MCP create_pull_request with valid ticket — should allow"
actual_exit=0
actual_stdout=$(cd "$NON_GIT_DIR" && "${PY_CMD[@]}" "$SCRIPT" < "$FIXTURES/pr-create-with-ticket.json" 2>/dev/null) || actual_exit=$?
if [ "$actual_exit" -eq 0 ] && ! is_deny "$actual_stdout"; then
  printf "  ${GREEN}PASS${NC} MCP MXTS ticket → allow\n"
  pass=$((pass + 1))
else
  printf "  ${RED}FAIL${NC} expected allow, got exit=%d stdout=%s\n" "$actual_exit" "$actual_stdout"
  fail=$((fail + 1))
fi

echo ""
echo "MCP create_pull_request missing ticket — should deny"
actual_stdout=$("${PY_CMD[@]}" "$SCRIPT" < "$FIXTURES/pr-create-without-ticket.json" 2>/dev/null)
if is_deny "$actual_stdout"; then
  printf "  ${GREEN}PASS${NC} MCP no ticket → deny\n"
  pass=$((pass + 1))
else
  printf "  ${RED}FAIL${NC} expected deny, got: %s\n" "$actual_stdout"
  fail=$((fail + 1))
fi

echo ""
echo "No review marker for HEAD — should deny with instructions"
REVIEW_DIR=$(mktemp -d)
cleanup_review() { rm -rf "$REVIEW_DIR"; }
trap 'cleanup; cleanup_review' EXIT

git -C "$REVIEW_DIR" init -q
git -C "$REVIEW_DIR" config user.email test@example.com
git -C "$REVIEW_DIR" config user.name Test
git -C "$REVIEW_DIR" commit -q --allow-empty -m base
git -C "$REVIEW_DIR" branch -M main
git -C "$REVIEW_DIR" checkout -q -b feature/probe
git -C "$REVIEW_DIR" commit -q --allow-empty -m ahead

payload='{"tool_name":"Bash","session_id":"test-session","tool_input":{"command":"gh pr create --draft --title \"MXTS-1234: probe\" --base main"}}'
actual_stdout=$(cd "$REVIEW_DIR" && printf '%s' "$payload" | "${PY_CMD[@]}" "$SCRIPT" 2>/dev/null)

if is_deny "$actual_stdout" && printf '%s' "$actual_stdout" | grep -q 'reviewing-pre-pr'; then
  printf "  ${GREEN}PASS${NC} no marker → deny naming the review skill\\n"
  pass=$((pass + 1))
else
  printf "  ${RED}FAIL${NC} missing marker must deny with instructions (stdout=%s)\\n" "$actual_stdout"
  fail=$((fail + 1))
fi

echo ""
echo "Deny message names the target directory — the review must be scopable to it"
# Run from a directory that is NOT the PR's repo, exactly as a real session does
# when the PR targets a worktree. Without the directory in the message the review
# reviews the session's repo instead and records a pass for the wrong commit.
payload_cd="{\"tool_name\":\"Bash\",\"tool_input\":{\"command\":\"cd $REVIEW_DIR && gh pr create --draft --title \\\"MXTS-1234: probe\\\" --base main\"}}"
actual_stdout=$(cd / && printf '%s' "$payload_cd" | "${PY_CMD[@]}" "$SCRIPT" 2>/dev/null)

# -F: $REVIEW_DIR comes from mktemp and routinely contains dots, which a regex
# would treat as wildcards — match the deny message literally. The path is quoted
# in the message, so assert the quotes too: they are what keeps a directory
# containing whitespace from arriving as two positional tokens.
if is_deny "$actual_stdout" && deny_reason "$actual_stdout" | grep -Fq "reviewing-pre-pr main \"$REVIEW_DIR\""; then
  printf "  ${GREEN}PASS${NC} deny names both base and target dir, quoted\\n"
  pass=$((pass + 1))
else
  printf "  ${RED}FAIL${NC} deny must name the target dir (stdout=%s)\\n" "$actual_stdout"
  fail=$((fail + 1))
fi

echo ""
echo "Deny names a repo even with no cd in the command — the review refuses to guess a target"
# No `cd` to parse, so the hook checked its own cwd. The review now treats an
# absent repo argument as a hard stop rather than defaulting to the session's
# directory, so the message must still carry a concrete path or the developer is
# handed an invocation that cannot run.
actual_stdout=$(cd "$REVIEW_DIR" && printf '%s' "$payload" | "${PY_CMD[@]}" "$SCRIPT" 2>/dev/null)
REVIEW_TOPLEVEL=$(git -C "$REVIEW_DIR" rev-parse --show-toplevel)

if is_deny "$actual_stdout" && deny_reason "$actual_stdout" | grep -Fq "reviewing-pre-pr main \"$REVIEW_TOPLEVEL\""; then
  printf "  ${GREEN}PASS${NC} no cd → deny still names a concrete repo path\\n"
  pass=$((pass + 1))
else
  printf "  ${RED}FAIL${NC} deny must name a repo path even without a cd (stdout=%s)\\n" "$actual_stdout"
  fail=$((fail + 1))
fi

echo ""
echo "Deny does not advise answering the fork in prose — that is what breaks the positional args"
# Paired assertions: the old advice must be gone AND the replacement must be
# present. The absence check alone would also pass on an empty deny message.
if printf '%s' "$actual_stdout" | grep -Fq 'reply with the task'; then
  printf "  ${RED}FAIL${NC} deny still tells the caller to reply with the task (stdout=%s)\\n" "$actual_stdout"
  fail=$((fail + 1))
elif printf '%s' "$actual_stdout" | grep -Fq 'nothing else'; then
  printf "  ${GREEN}PASS${NC} deny warns the two arguments are positional instead\\n"
  pass=$((pass + 1))
else
  printf "  ${RED}FAIL${NC} deny must warn the arguments are positional (stdout=%s)\\n" "$actual_stdout"
  fail=$((fail + 1))
fi

echo ""
echo "Deny quotes a target containing whitespace — unquoted it would split into two positional tokens"
# extract_workdir tokenizes with shlex and so deliberately supports paths with
# spaces. The review's arguments are positional, so an unquoted path arrives as
# two tokens and $repo is truncated at the space.
SPACE_PARENT=$(mktemp -d)
SPACE_DIR="$SPACE_PARENT/my repo"
mkdir -p "$SPACE_DIR"
git -C "$SPACE_DIR" init -q
git -C "$SPACE_DIR" config user.email test@example.com
git -C "$SPACE_DIR" config user.name Test
git -C "$SPACE_DIR" commit -q --allow-empty -m base
git -C "$SPACE_DIR" branch -M main
git -C "$SPACE_DIR" checkout -q -b feature/spaced
git -C "$SPACE_DIR" commit -q --allow-empty -m ahead

payload_space="{\"tool_name\":\"Bash\",\"tool_input\":{\"command\":\"cd '$SPACE_DIR' && gh pr create --draft --title \\\"MXTS-1234: probe\\\" --base main\"}}"
actual_stdout=$(cd / && printf '%s' "$payload_space" | "${PY_CMD[@]}" "$SCRIPT" 2>/dev/null)

if is_deny "$actual_stdout" && deny_reason "$actual_stdout" | grep -Fq "reviewing-pre-pr main \"$SPACE_DIR\""; then
  printf "  ${GREEN}PASS${NC} whitespace path is quoted in the deny message\\n"
  pass=$((pass + 1))
else
  printf "  ${RED}FAIL${NC} whitespace path must be quoted (stdout=%s)\\n" "$actual_stdout"
  fail=$((fail + 1))
fi

# The MCP path carries a *remote* owner/repo and has no `cd` to parse, so the
# session's checkout is not necessarily the repo the PR targets. Naming it anyway
# would point the review at unrelated code and mark it passed.
MCP_DIR=$(mktemp -d)
git -C "$MCP_DIR" init -q
git -C "$MCP_DIR" config user.email test@example.com
git -C "$MCP_DIR" config user.name Test
git -C "$MCP_DIR" commit -q --allow-empty -m base
git -C "$MCP_DIR" branch -M main
git -C "$MCP_DIR" checkout -q -b feature/mcp
git -C "$MCP_DIR" commit -q --allow-empty -m ahead
git -C "$MCP_DIR" remote add origin https://github.com/MaxxtonGroup/acme-repo.git
MCP_TOPLEVEL=$(git -C "$MCP_DIR" rev-parse --show-toplevel)

echo ""
echo "MCP request matching the cwd checkout — deny names that checkout"
payload_match='{"tool_name":"mcp__claude_ai_GitHub__create_pull_request","tool_input":{"title":"MXTS-1234: probe","draft":true,"base":"main","owner":"MaxxtonGroup","repo":"acme-repo"}}'
actual_stdout=$(cd "$MCP_DIR" && printf '%s' "$payload_match" | "${PY_CMD[@]}" "$SCRIPT" 2>/dev/null)

if is_deny "$actual_stdout" && deny_reason "$actual_stdout" | grep -Fq "\"$MCP_TOPLEVEL\""; then
  printf "  ${GREEN}PASS${NC} matching owner/repo → deny names the cwd checkout\\n"
  pass=$((pass + 1))
else
  printf "  ${RED}FAIL${NC} matching owner/repo must name the checkout (stdout=%s)\\n" "$actual_stdout"
  fail=$((fail + 1))
fi

echo ""
echo "MCP request for a different repo than the cwd checkout — deny must NOT name the cwd"
# Paired assertions: the wrong path must be absent AND the placeholder present.
# The absence check alone would pass on any unrelated deny message.
payload_mismatch='{"tool_name":"mcp__claude_ai_GitHub__create_pull_request","tool_input":{"title":"MXTS-1234: probe","draft":true,"base":"main","owner":"MaxxtonGroup","repo":"some-other-repo"}}'
actual_stdout=$(cd "$MCP_DIR" && printf '%s' "$payload_mismatch" | "${PY_CMD[@]}" "$SCRIPT" 2>/dev/null)
mismatch_reason=$(deny_reason "$actual_stdout")

if is_deny "$actual_stdout" \
  && ! printf '%s' "$mismatch_reason" | grep -Fq "$MCP_TOPLEVEL" \
  && printf '%s' "$mismatch_reason" | grep -Fq '<path to the repository>'; then
  printf "  ${GREEN}PASS${NC} mismatched owner/repo → deny refuses to name the cwd\\n"
  pass=$((pass + 1))
else
  printf "  ${RED}FAIL${NC} mismatched owner/repo must not name the cwd (stdout=%s)\\n" "$actual_stdout"
  fail=$((fail + 1))
fi

echo ""
echo "Marker present for HEAD — should allow"
HEAD_SHA=$(git -C "$REVIEW_DIR" rev-parse HEAD)
GIT_DIR_ABS=$(git -C "$REVIEW_DIR" rev-parse --absolute-git-dir)
touch "$GIT_DIR_ABS/pre-pr-review-$HEAD_SHA"

actual_exit=0
actual_stdout=$(cd "$REVIEW_DIR" && printf '%s' "$payload" | "${PY_CMD[@]}" "$SCRIPT" 2>/dev/null) || actual_exit=$?

if [ "$actual_exit" -eq 0 ] && ! is_deny "$actual_stdout"; then
  printf "  ${GREEN}PASS${NC} marker for HEAD → allow\\n"
  pass=$((pass + 1))
else
  printf "  ${RED}FAIL${NC} marker for HEAD must allow (exit=%d stdout=%s)\\n" "$actual_exit" "$actual_stdout"
  fail=$((fail + 1))
fi

echo ""
echo "Marker is stale (HEAD moved) — should deny again"
git -C "$REVIEW_DIR" commit -q --allow-empty -m "new work"
actual_stdout=$(cd "$REVIEW_DIR" && printf '%s' "$payload" | "${PY_CMD[@]}" "$SCRIPT" 2>/dev/null)

if is_deny "$actual_stdout"; then
  printf "  ${GREEN}PASS${NC} stale marker → deny (fresh commit needs fresh review)\\n"
  pass=$((pass + 1))
else
  printf "  ${RED}FAIL${NC} stale marker must deny (stdout=%s)\\n" "$actual_stdout"
  fail=$((fail + 1))
fi

echo ""
echo "Deny writes a hand-off naming the reviewed repo and HEAD"
# Regression cover for MXTS-80544: a third of real invocations never carried a
# usable repo path, so the hook hands the resolved target over directly rather
# than relying on the positional argument surviving the trip to a forked review.
rm -f "$CLAUDE_PRE_PR_REVIEW_DIR"/request-*.json
git -C "$REVIEW_DIR" commit -q --allow-empty -m "work needing review"
EXPECT_HEAD=$(git -C "$REVIEW_DIR" rev-parse HEAD)
EXPECT_TOP=$(git -C "$REVIEW_DIR" rev-parse --show-toplevel)
actual_stdout=$(cd "$REVIEW_DIR" && printf '%s' "$payload" | "${PY_CMD[@]}" "$SCRIPT" 2>/dev/null)

handoff_ok=$("${PY_CMD[@]}" - "$CLAUDE_PRE_PR_REVIEW_DIR" "$EXPECT_TOP" "$EXPECT_HEAD" <<'PYEOF'
import glob, json, os, sys
directory, want_repo, want_head = sys.argv[1], sys.argv[2], sys.argv[3]
files = glob.glob(os.path.join(directory, 'request-*.json'))
if len(files) != 1:
    print('files=%d' % len(files)); sys.exit(1)
d = json.load(open(files[0]))
if os.path.realpath(d.get('repo') or '') != os.path.realpath(want_repo):
    print('repo=%r' % d.get('repo')); sys.exit(1)
if d.get('head') != want_head:
    print('head=%r' % d.get('head')); sys.exit(1)
if not d.get('base'):
    print('base missing'); sys.exit(1)
print('ok')
PYEOF
) || true

if is_deny "$actual_stdout" && [ "$handoff_ok" = "ok" ]; then
  printf "  ${GREEN}PASS${NC} deny → hand-off written with repo, base and HEAD\\n"
  pass=$((pass + 1))
else
  printf "  ${RED}FAIL${NC} deny must write one hand-off for the reviewed repo (got=%s)\\n" "$handoff_ok"
  fail=$((fail + 1))
fi

echo ""
echo "Opening the gate clears this session's hand-off"
# A request that outlives its PR is the MXTS-80544 failure through another door:
# a later review with no usable argument finds exactly one live request, sees a
# HEAD that still matches because that repo never moved, and reviews it.
# Seed a request via a real deny, then let the marker open the gate.
rm -f "$CLAUDE_PRE_PR_REVIEW_DIR"/request-*.json
actual_stdout=$(cd "$REVIEW_DIR" && printf '%s' "$payload" | "${PY_CMD[@]}" "$SCRIPT" 2>/dev/null)
seeded=$(find "$CLAUDE_PRE_PR_REVIEW_DIR" -name 'request-*.json' 2>/dev/null | wc -l | tr -d ' ')
ALLOW_HEAD=$(git -C "$REVIEW_DIR" rev-parse HEAD)
ALLOW_GIT_DIR=$(git -C "$REVIEW_DIR" rev-parse --absolute-git-dir)
touch "$ALLOW_GIT_DIR/pre-pr-review-$ALLOW_HEAD"
actual_stdout=$(cd "$REVIEW_DIR" && printf '%s' "$payload" | "${PY_CMD[@]}" "$SCRIPT" 2>/dev/null)
leftover=$(find "$CLAUDE_PRE_PR_REVIEW_DIR" -name 'request-*.json' 2>/dev/null | wc -l | tr -d ' ')
rm -f "$ALLOW_GIT_DIR/pre-pr-review-$ALLOW_HEAD"

if ! is_deny "$actual_stdout" && [ "$seeded" = "1" ] && [ "$leftover" = "0" ]; then
  printf "  ${GREEN}PASS${NC} allow → the seeded hand-off is cleared\\n"
  pass=$((pass + 1))
else
  printf "  ${RED}FAIL${NC} allow must clear the hand-off (seeded=%s leftover=%s)\\n" "$seeded" "$leftover"
  fail=$((fail + 1))
fi

echo ""
echo "An expired hand-off is pruned rather than left to look ambiguous"
# Two live requests make the review stop, so a stale file from a PR attempt
# nobody finished must not count as one.
rm -f "$CLAUDE_PRE_PR_REVIEW_DIR"/request-*.json
printf '%s' '{"repo":"/nonexistent","base":"main","head":"deadbeef","written_at":0}' \
  > "$CLAUDE_PRE_PR_REVIEW_DIR/request-ancient.json"
"${PY_CMD[@]}" -c "import os,sys,time; p=sys.argv[1]; os.utime(p,(0,time.time()-99999))" \
  "$CLAUDE_PRE_PR_REVIEW_DIR/request-ancient.json"
actual_stdout=$(cd "$REVIEW_DIR" && printf '%s' "$payload" | "${PY_CMD[@]}" "$SCRIPT" 2>/dev/null)
remaining=$(find "$CLAUDE_PRE_PR_REVIEW_DIR" -name 'request-*.json' 2>/dev/null | wc -l | tr -d ' ')

if is_deny "$actual_stdout" && [ "$remaining" = "1" ] \
  && [ ! -f "$CLAUDE_PRE_PR_REVIEW_DIR/request-ancient.json" ]; then
  printf "  ${GREEN}PASS${NC} expired hand-off pruned, only the fresh one remains\\n"
  pass=$((pass + 1))
else
  printf "  ${RED}FAIL${NC} expired hand-off must be pruned (remaining=%s)\\n" "$remaining"
  fail=$((fail + 1))
fi

echo ""
echo "Hand-off records an absolute path — a relative cd target would resolve elsewhere"
# The review runs forked with a working directory it does not control, so a
# relative path handed over here would send it somewhere else entirely.
rm -f "$CLAUDE_PRE_PR_REVIEW_DIR"/request-*.json
REL_PARENT=$(dirname "$REVIEW_DIR")
REL_NAME=$(basename "$REVIEW_DIR")
rel_payload=$("${PY_CMD[@]}" - "$REL_NAME" <<'PYEOF'
import json, sys
print(json.dumps({"tool_name": "Bash", "session_id": "test-session-rel",
      "tool_input": {"command":
      "cd %s && gh pr create --draft --title \"MXTS-1234: probe\" --base main" % sys.argv[1]}}))
PYEOF
)
actual_stdout=$(cd "$REL_PARENT" && printf '%s' "$rel_payload" | "${PY_CMD[@]}" "$SCRIPT" 2>/dev/null)

abs_ok=$("${PY_CMD[@]}" - "$CLAUDE_PRE_PR_REVIEW_DIR" <<'PYEOF'
import glob, json, os, sys
files = glob.glob(os.path.join(sys.argv[1], 'request-*.json'))
if len(files) != 1:
    print('files=%d' % len(files)); sys.exit(0)
repo = json.load(open(files[0])).get('repo') or ''
print('ok' if os.path.isabs(repo) else 'relative:%s' % repo)
PYEOF
)

if is_deny "$actual_stdout" && [ "$abs_ok" = "ok" ]; then
  printf "  ${GREEN}PASS${NC} relative cd target → hand-off records an absolute path\\n"
  pass=$((pass + 1))
else
  printf "  ${RED}FAIL${NC} hand-off must record an absolute path (got=%s)\\n" "$abs_ok"
  fail=$((fail + 1))
fi

echo ""
echo "An event with no session writes no hand-off — a shared filename would cross sessions"
rm -f "$CLAUDE_PRE_PR_REVIEW_DIR"/request-*.json
nosession_payload='{"tool_name":"Bash","tool_input":{"command":"gh pr create --draft --title \"MXTS-1234: probe\" --base main"}}'
actual_stdout=$(cd "$REVIEW_DIR" && printf '%s' "$nosession_payload" | "${PY_CMD[@]}" "$SCRIPT" 2>/dev/null)
nosession_files=$(find "$CLAUDE_PRE_PR_REVIEW_DIR" -name 'request-*.json' 2>/dev/null | wc -l | tr -d ' ')

if is_deny "$actual_stdout" && [ "$nosession_files" = "0" ]; then
  printf "  ${GREEN}PASS${NC} no session → deny with no hand-off written\\n"
  pass=$((pass + 1))
else
  printf "  ${RED}FAIL${NC} no session must write no hand-off (files=%s)\\n" "$nosession_files"
  fail=$((fail + 1))
fi

echo ""
echo "An abandoned request expires even though nothing new is written"
# The discriminating case for the TTL. The earlier prune test also writes a
# request, so it passes even if pruning only ever runs on the write path. Here
# the run ALLOWS (marker present), so no request is written and no clear_request
# matches the seeded token — only unconditional pruning can remove it.
rm -f "$CLAUDE_PRE_PR_REVIEW_DIR"/request-*.json
printf '%s' '{"repo":"/nonexistent","base":"main","head":"deadbeef","session_id":"other-session","written_at":0}' \
  > "$CLAUDE_PRE_PR_REVIEW_DIR/request-other-session.json"
"${PY_CMD[@]}" -c "import os,sys,time; os.utime(sys.argv[1],(0,time.time()-99999))" \
  "$CLAUDE_PRE_PR_REVIEW_DIR/request-other-session.json"

ABANDON_HEAD=$(git -C "$REVIEW_DIR" rev-parse HEAD)
ABANDON_GIT_DIR=$(git -C "$REVIEW_DIR" rev-parse --absolute-git-dir)
touch "$ABANDON_GIT_DIR/pre-pr-review-$ABANDON_HEAD"
actual_stdout=$(cd "$REVIEW_DIR" && printf '%s' "$payload" | "${PY_CMD[@]}" "$SCRIPT" 2>/dev/null)
rm -f "$ABANDON_GIT_DIR/pre-pr-review-$ABANDON_HEAD"
abandoned=$(find "$CLAUDE_PRE_PR_REVIEW_DIR" -name 'request-other-session.json' 2>/dev/null | wc -l | tr -d ' ')

if ! is_deny "$actual_stdout" && [ "$abandoned" = "0" ]; then
  printf "  ${GREEN}PASS${NC} abandoned request expired on an allow, with no write\\n"
  pass=$((pass + 1))
else
  printf "  ${RED}FAIL${NC} abandoned request must expire without a write (left=%s)\\n" "$abandoned"
  fail=$((fail + 1))
fi

echo ""
echo "Two repos in one session leave two hand-offs — so the review stops instead of guessing"
# Keying the filename on the session alone collapsed a sequenced multi-repo pair
# into one file, so the review's "more than one live request ⇒ stop" rule never
# fired and a review for the first repo could bind the second.
rm -f "$CLAUDE_PRE_PR_REVIEW_DIR"/request-*.json
SECOND_DIR=$(mktemp -d)
cleanup_second() { rm -rf "$SECOND_DIR"; }
git -C "$SECOND_DIR" init -q
git -C "$SECOND_DIR" config user.email test@example.com
git -C "$SECOND_DIR" config user.name test
git -C "$SECOND_DIR" commit -q --allow-empty -m "base"
git -C "$SECOND_DIR" branch -M main
git -C "$SECOND_DIR" checkout -q -b feature/probe
git -C "$SECOND_DIR" commit -q --allow-empty -m "work"

out_a=$(cd "$REVIEW_DIR" && printf '%s' "$payload" | "${PY_CMD[@]}" "$SCRIPT" 2>/dev/null)
out_b=$(cd "$SECOND_DIR" && printf '%s' "$payload" | "${PY_CMD[@]}" "$SCRIPT" 2>/dev/null)
both=$(find "$CLAUDE_PRE_PR_REVIEW_DIR" -name 'request-*.json' 2>/dev/null | wc -l | tr -d ' ')
cleanup_second

if is_deny "$out_a" && is_deny "$out_b" && [ "$both" = "2" ]; then
  printf "  ${GREEN}PASS${NC} two repos, one session → two live hand-offs\\n"
  pass=$((pass + 1))
else
  printf "  ${RED}FAIL${NC} two repos must leave two hand-offs (count=%s)\\n" "$both"
  fail=$((fail + 1))
fi

echo ""
echo "A retry on the same repo supersedes rather than accumulating"
rm -f "$CLAUDE_PRE_PR_REVIEW_DIR"/request-*.json
out_1=$(cd "$REVIEW_DIR" && printf '%s' "$payload" | "${PY_CMD[@]}" "$SCRIPT" 2>/dev/null)
out_2=$(cd "$REVIEW_DIR" && printf '%s' "$payload" | "${PY_CMD[@]}" "$SCRIPT" 2>/dev/null)
again=$(find "$CLAUDE_PRE_PR_REVIEW_DIR" -name 'request-*.json' 2>/dev/null | wc -l | tr -d ' ')

if is_deny "$out_1" && is_deny "$out_2" && [ "$again" = "1" ]; then
  printf "  ${GREEN}PASS${NC} same repo retried → still one hand-off\\n"
  pass=$((pass + 1))
else
  printf "  ${RED}FAIL${NC} same repo must not accumulate hand-offs (count=%s)\\n" "$again"
  fail=$((fail + 1))
fi

echo ""
echo "Pruning touches only its own request files — never an unrelated *.json"
# The hand-off directory is env-overridable and the default sits one segment from
# ~/.claude, where the settings files live. An expiry sweep that matched on the
# extension alone deleted every stale *.json it found.
rm -f "$CLAUDE_PRE_PR_REVIEW_DIR"/request-*.json
PRUNE_PROBE=$(mktemp -d)
cleanup_probe() { rm -rf "$PRUNE_PROBE"; }
printf '{}' > "$PRUNE_PROBE/settings.json"
printf '{}' > "$PRUNE_PROBE/settings.local.json"
printf '%s' '{"repo":"/nonexistent","base":"main","head":"deadbeef","written_at":0}' \
  > "$PRUNE_PROBE/request-stale-abcdef123456.json"
printf 'keep' > "$PRUNE_PROBE/notes.txt"
for f in settings.json settings.local.json request-stale-abcdef123456.json notes.txt; do
  "${PY_CMD[@]}" -c "import os,sys,time; os.utime(sys.argv[1],(0,time.time()-99999))" "$PRUNE_PROBE/$f"
done

"${PY_CMD[@]}" - "$SCRIPT" "$PRUNE_PROBE" <<'PYEOF'
import importlib.util, sys, time
spec = importlib.util.spec_from_file_location('prepr', sys.argv[1])
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)
mod.prune_requests(sys.argv[2], time.time())
PYEOF

survived=0
[ -f "$PRUNE_PROBE/settings.json" ] && [ -f "$PRUNE_PROBE/settings.local.json" ] \
  && [ -f "$PRUNE_PROBE/notes.txt" ] && survived=1
pruned=0
[ ! -f "$PRUNE_PROBE/request-stale-abcdef123456.json" ] && pruned=1
cleanup_probe

if [ "$survived" = "1" ] && [ "$pruned" = "1" ]; then
  printf "  ${GREEN}PASS${NC} stale request pruned, unrelated files untouched\\n"
  pass=$((pass + 1))
else
  printf "  ${RED}FAIL${NC} prune must spare unrelated files (survived=%s pruned=%s)\\n" "$survived" "$pruned"
  fail=$((fail + 1))
fi

echo ""
echo "A deny that cannot name a repository clears this session's earlier hand-off"
# Otherwise the review finds exactly one live hand-off, binds the repo it names
# rather than the one the PR targets, and passes it — while the retry's marker
# check, made against the cwd, then allows. MXTS-80544's shape, new door.
rm -f "$CLAUDE_PRE_PR_REVIEW_DIR"/request-*.json
seeded_out=$(cd "$REVIEW_DIR" && printf '%s' "$payload" | "${PY_CMD[@]}" "$SCRIPT" 2>/dev/null)
before=$(find "$CLAUDE_PRE_PR_REVIEW_DIR" -name 'request-*.json' 2>/dev/null | wc -l | tr -d ' ')

# MCP request naming a repo that is not this checkout: the hook refuses to guess.
mcp_mismatch='{"tool_name":"mcp__claude_ai_GitHub__create_pull_request","session_id":"test-session","tool_input":{"title":"MXTS-1234: probe","draft":true,"base":"main","owner":"MaxxtonGroup","repo":"some-other-repo"}}'
mismatch_out=$(cd "$REVIEW_DIR" && printf '%s' "$mcp_mismatch" | "${PY_CMD[@]}" "$SCRIPT" 2>/dev/null)
after=$(find "$CLAUDE_PRE_PR_REVIEW_DIR" -name 'request-*.json' 2>/dev/null | wc -l | tr -d ' ')

if is_deny "$seeded_out" && is_deny "$mismatch_out" \
  && [ "$before" = "1" ] && [ "$after" = "0" ]; then
  printf "  ${GREEN}PASS${NC} unnameable deny → earlier hand-off cleared\\n"
  pass=$((pass + 1))
else
  printf "  ${RED}FAIL${NC} unnameable deny must clear the hand-off (before=%s after=%s)\\n" "$before" "$after"
  fail=$((fail + 1))
fi

echo ""
echo "The deny message names an absolute path, matching what the hand-off records"
# Step 0.3 of the review only accepts /- or ~-rooted candidates, so a relative
# cd target printed verbatim is discarded and recovery leans on the hand-off.
rm -f "$CLAUDE_PRE_PR_REVIEW_DIR"/request-*.json
REL_PARENT2=$(dirname "$REVIEW_DIR")
REL_NAME2=$(basename "$REVIEW_DIR")
rel_payload2=$("${PY_CMD[@]}" - "$REL_NAME2" <<'PYEOF'
import json, sys
print(json.dumps({"tool_name": "Bash", "session_id": "test-session-rel2",
      "tool_input": {"command":
      "cd %s && gh pr create --draft --title \"MXTS-1234: probe\" --base main" % sys.argv[1]}}))
PYEOF
)
rel_out=$(cd "$REL_PARENT2" && printf '%s' "$rel_payload2" | "${PY_CMD[@]}" "$SCRIPT" 2>/dev/null)
rel_reason=$(deny_reason "$rel_out")

# Assert the named target is absolute, not any particular resolved spelling:
# realpath would rewrite the developer's own path on any symlinked prefix.
rel_named=$(printf '%s' "$rel_reason" | sed -n 's/.*reviewing-pre-pr main "\([^"]*\)".*/\1/p')
case "$rel_named" in /*) rel_abs=1 ;; *) rel_abs=0 ;; esac

if is_deny "$rel_out" && [ "$rel_abs" = "1" ] \
  && [ "$(basename "$rel_named")" = "$REL_NAME2" ]; then
  printf "  ${GREEN}PASS${NC} relative cd target → deny names the absolute path\\n"
  pass=$((pass + 1))
else
  printf "  ${RED}FAIL${NC} deny must name an absolute path (named=%s)\\n" "$rel_named"
  fail=$((fail + 1))
fi

echo ""
echo "Clearing a session's hand-offs spares files this hook did not write"
# Same exposure as the pruner: the directory is env-overridable, so a sweep that
# matched the session prefix alone would delete a same-prefixed file of any
# extension. The .txt below carries the prefix and is the discriminating case.
CLEAR_PROBE=$(mktemp -d)
printf '%s' '{"repo":"/nonexistent","base":"main","head":"deadbeef","written_at":0}' \
  > "$CLEAR_PROBE/request-test-session-abcdef123456.json"
printf 'keep' > "$CLEAR_PROBE/request-test-session-notes.txt"
printf '{}' > "$CLEAR_PROBE/settings.json"

CLAUDE_PRE_PR_REVIEW_DIR="$CLEAR_PROBE" "${PY_CMD[@]}" - "$SCRIPT" <<'PYEOF'
import importlib.util, sys
spec = importlib.util.spec_from_file_location('prepr', sys.argv[1])
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)
mod.clear_session_requests('test-session')
PYEOF

cleared=0
[ ! -f "$CLEAR_PROBE/request-test-session-abcdef123456.json" ] && cleared=1
spared=0
[ -f "$CLEAR_PROBE/request-test-session-notes.txt" ] && [ -f "$CLEAR_PROBE/settings.json" ] && spared=1
rm -rf "$CLEAR_PROBE"

if [ "$cleared" = "1" ] && [ "$spared" = "1" ]; then
  printf "  ${GREEN}PASS${NC} session hand-off cleared, same-prefix foreign files spared\\n"
  pass=$((pass + 1))
else
  printf "  ${RED}FAIL${NC} clear must spare files it did not write (cleared=%s spared=%s)\\n" "$cleared" "$spared"
  fail=$((fail + 1))
fi

echo ""
echo "Draft enforcement — a ready-for-review create is refused, in both tool shapes"
# `pr-creation-required` has said `gh pr create --draft` since MXTS-80541, and a
# PR was still opened ready-for-review with the rule active. These pin the
# enforcement that replaces the honour system (MXTS-81194).

# Each case: <label> <payload> <expect: deny|pass-gate>. "pass-gate" means the
# draft check let it through — a later gate may still deny, so assert only that
# the reason is NOT the draft one.
draft_case() {
  local label="$1" payload="$2" expect="$3"
  local out reason
  out=$(cd "$NON_GIT_DIR" && printf '%s' "$payload" | "${PY_CMD[@]}" "$SCRIPT" 2>/dev/null) || true
  reason=$(deny_reason "$out")
  if [ "$expect" = "deny" ]; then
    if is_deny "$out" && printf '%s' "$reason" | grep -Fq -- 'add --draft'; then
      printf "  ${GREEN}PASS${NC} %s\\n" "$label"; pass=$((pass + 1)); return
    fi
  else
    if ! printf '%s' "$reason" | grep -Fq -- 'add --draft'; then
      printf "  ${GREEN}PASS${NC} %s\\n" "$label"; pass=$((pass + 1)); return
    fi
  fi
  printf "  ${RED}FAIL${NC} %s (stdout=%s)\\n" "$label" "$out"; fail=$((fail + 1))
}

_bash_create() { printf '{"tool_name":"Bash","tool_input":{"command":"gh pr create --title \\"MXTS-1: x\\" %s"}}' "$1"; }

draft_case "no --draft → deny naming the flag"        "$(_bash_create '')"              deny
draft_case "--draft → passes the draft gate"          "$(_bash_create '--draft')"       pass-gate
draft_case "-d shorthand → passes the draft gate"     "$(_bash_create '-d')"            pass-gate
draft_case "--draft=true → passes the draft gate"     "$(_bash_create '--draft=true')"  pass-gate
# gh accepts --draft=false, which asks for the opposite. Matching on the flag
# name alone would read it as a draft request and wave a ready PR through.
draft_case "--draft=false → deny (asks for the opposite)" "$(_bash_create '--draft=false')" deny
draft_case "MCP without draft → deny" \
  '{"tool_name":"mcp__claude_ai_GitHub__create_pull_request","tool_input":{"title":"MXTS-1: x","base":"main"}}' deny
draft_case "MCP draft:true → passes the draft gate" \
  '{"tool_name":"mcp__claude_ai_GitHub__create_pull_request","tool_input":{"title":"MXTS-1: x","base":"main","draft":true}}' pass-gate
draft_case "MCP draft:false → deny" \
  '{"tool_name":"mcp__claude_ai_GitHub__create_pull_request","tool_input":{"title":"MXTS-1: x","base":"main","draft":false}}' deny

echo ""
echo "gh pr create --help creates nothing — must not be denied for a missing title"
help_exit=0
help_out=$(cd "$NON_GIT_DIR" && printf '{"tool_name":"Bash","tool_input":{"command":"gh pr create --help"}}' \
  | "${PY_CMD[@]}" "$SCRIPT" 2>/dev/null) || help_exit=$?
if [ "$help_exit" -eq 0 ] && ! is_deny "$help_out"; then
  printf "  ${GREEN}PASS${NC} --help → allow\\n"
  pass=$((pass + 1))
else
  printf "  ${RED}FAIL${NC} --help must be allowed (exit=%d stdout=%s)\\n" "$help_exit" "$help_out"
  fail=$((fail + 1))
fi

echo ""
echo "MXTS-82934: Maxxton's PR rules apply to MaxxtonGroup repositories only"
# A developer's own repository gets none of the ticket/draft/review rules; a
# MaxxtonGroup repository, or one whose owner can't be told, keeps all of them.
PERSONAL_DIR=$(mktemp -d)
MAXXTON_DIR=$(mktemp -d)
git -C "$PERSONAL_DIR" init -q && git -C "$PERSONAL_DIR" remote add origin https://github.com/someone/personal.git
git -C "$MAXXTON_DIR" init -q && git -C "$MAXXTON_DIR" remote add origin git@github.com:MaxxtonGroup/some-service.git
untagged='{"tool_name":"Bash","tool_input":{"command":"gh pr create --title \"feat: x\" --body y"}}'

# Each case: <label> <directory> <payload> <expect: allow|deny>.
owner_case() {
  local label="$1" dir="$2" payload="$3" expect="$4"
  local out exit_code=0
  out=$(cd "$dir" && printf '%s' "$payload" | "${PY_CMD[@]}" "$SCRIPT" 2>/dev/null) || exit_code=$?
  if { [ "$expect" = "allow" ] && [ "$exit_code" -eq 0 ] && ! is_deny "$out"; } \
    || { [ "$expect" = "deny" ] && is_deny "$out"; }; then
    printf "  ${GREEN}PASS${NC} %s\\n" "$label"; pass=$((pass + 1)); return
  fi
  printf "  ${RED}FAIL${NC} %s (exit=%d stdout=%s)\\n" "$label" "$exit_code" "$out"; fail=$((fail + 1))
}

owner_case "personal origin, no ticket or draft → allow" "$PERSONAL_DIR" "$untagged" allow
owner_case "MaxxtonGroup origin (ssh), no ticket → deny" "$MAXXTON_DIR" "$untagged" deny
owner_case "no repository to read an owner from → deny (fails closed)" "$NON_GIT_DIR" "$untagged" deny
# A fork checkout: gh without --repo targets the upstream remote before origin, so
# one MaxxtonGroup remote anywhere keeps the rules on.
FORK_DIR=$(mktemp -d)
git -C "$FORK_DIR" init -q && git -C "$FORK_DIR" remote add origin https://github.com/someone/fork.git
git -C "$FORK_DIR" remote add upstream https://github.com/MaxxtonGroup/some-service.git
owner_case "fork: personal origin, MaxxtonGroup upstream → deny" "$FORK_DIR" "$untagged" deny
rm -rf "$FORK_DIR"
owner_case "--repo names a personal repo → allow" "$NON_GIT_DIR" \
  '{"tool_name":"Bash","tool_input":{"command":"gh pr create --repo someone/personal --title \"feat: x\" --body y"}}' allow
owner_case "--repo names a MaxxtonGroup repo from a personal checkout → deny" "$PERSONAL_DIR" \
  '{"tool_name":"Bash","tool_input":{"command":"gh pr create -R MaxxtonGroup/some-service --title \"feat: x\" --body y"}}' deny
owner_case "MCP owner is someone else → allow" "$NON_GIT_DIR" \
  '{"tool_name":"mcp__claude_ai_GitHub__create_pull_request","tool_input":{"title":"feat: x","base":"main","owner":"someone","repo":"personal"}}' allow
owner_case "MCP owner is MaxxtonGroup → deny" "$NON_GIT_DIR" \
  '{"tool_name":"mcp__claude_ai_GitHub__create_pull_request","tool_input":{"title":"feat: x","base":"main","owner":"maxxtongroup","repo":"x"}}' deny
# gh also takes the value glued to the shorthand (-Rowner/repo); missing it would
# fall back to the checkout's remotes and judge the wrong repository.
owner_case "-R glued to a MaxxtonGroup repo from a personal checkout → deny" "$PERSONAL_DIR" \
  '{"tool_name":"Bash","tool_input":{"command":"gh pr create -RMaxxtonGroup/some-service --title \"feat: x\" --body y"}}' deny
owner_case "-R glued to a personal repo from a MaxxtonGroup checkout → allow" "$MAXXTON_DIR" \
  '{"tool_name":"Bash","tool_input":{"command":"gh pr create -Rsomeone/personal --title \"feat: x\" --body y"}}' allow
# The hook sees the command before the shell expands it, so a variable may hold
# MaxxtonGroup: its owner is unknown and the rules stay on.
owner_case "--repo from shell variables → deny (fails closed)" "$PERSONAL_DIR" \
  '{"tool_name":"Bash","tool_input":{"command":"OWNER=MaxxtonGroup REPO=x; gh pr create --repo \"$OWNER/$REPO\" --title \"feat: x\" --body y"}}' deny
owner_case "--repo from a command substitution → deny (fails closed)" "$PERSONAL_DIR" \
  '{"tool_name":"Bash","tool_input":{"command":"gh pr create -R `cat target` --title \"feat: x\" --body y"}}' deny
rm -rf "$PERSONAL_DIR" "$MAXXTON_DIR"

if "${PY_CMD[@]}" - "$SCRIPT" <<'PY'
import importlib.util, sys

spec = importlib.util.spec_from_file_location("prepr", sys.argv[1])
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)

cases = [
    ("https://github.com/Someone/Personal.git", "someone"),
    ("git@github.com:MaxxtonGroup/some-service.git", "maxxtongroup"),
    ("ssh://git@github.com/MaxxtonGroup/x", "maxxtongroup"),
    ("MaxxtonGroup/x", "maxxtongroup"),
    ("github.com/someone/personal/", "someone"),
    ("personal", None),
    ("", None),
]
bad = [(text, mod.repository_owner(text), want) for text, want in cases if mod.repository_owner(text) != want]

flag_cases = [
    (["-R", "o/r"], ["--repo", "-R"], "o/r"),
    (["--repo=o/r"], ["--repo", "-R"], "o/r"),
    (["-Ro/r"], ["--repo", "-R"], "o/r"),
    (["-R=o/r"], ["--repo", "-R"], "o/r"),
    (["-tMXTS-1: x"], ["--title", "-t"], "MXTS-1: x"),
    (["--repository", "o/r"], ["--repo", "-R"], None),
]
bad += [(tokens, mod.extract_flag(tokens, names), want)
        for tokens, names, want in flag_cases if mod.extract_flag(tokens, names) != want]
for text, got, want in bad:
    print(f"  mismatch: {text!r} → {got!r}, want {want!r}", file=sys.stderr)
sys.exit(1 if bad else 0)
PY
then
  printf "  ${GREEN}PASS${NC} repository_owner and extract_flag read every form gh accepts\\n"
  pass=$((pass + 1))
else
  printf "  ${RED}FAIL${NC} repository_owner or extract_flag returned unexpected values\\n"
  fail=$((fail + 1))
fi

echo ""
echo "PR branch checked out in a worktree outside the session's checkout"
# starting-ticket-branch put worktrees at ../worktrees/<branch> before MXTS-83500,
# outside the project folder, so Claude Code undoes a `cd` there after each
# command: the hook then runs in the main checkout while the review passed there.
WT_PARENT=$(mktemp -d)
trap 'cleanup; cleanup_review; rm -rf "$SPACE_PARENT" "$WT_PARENT"' EXIT
WT_MAIN="$WT_PARENT/repo"
WT_DIR="$WT_PARENT/worktrees/feature-probe"
git init -q "$WT_MAIN"
git -C "$WT_MAIN" config user.email test@example.com
git -C "$WT_MAIN" config user.name Test
git -C "$WT_MAIN" commit -q --allow-empty -m base
git -C "$WT_MAIN" branch -M main
git -C "$WT_MAIN" checkout -q -b feature/other
git -C "$WT_MAIN" commit -q --allow-empty -m other
git -C "$WT_MAIN" worktree add -q -b feature/probe "$WT_DIR" main
git -C "$WT_DIR" commit -q --allow-empty -m ahead
WT_DIR=$(git -C "$WT_DIR" rev-parse --show-toplevel)
WT_MARKER="$(git -C "$WT_DIR" rev-parse --absolute-git-dir)/pre-pr-review-$(git -C "$WT_DIR" rev-parse HEAD)"

payload_head='{"tool_name":"Bash","tool_input":{"command":"gh pr create --draft --title \"MXTS-1234: probe\" --base main --head feature/probe"}}'
actual_stdout=$(cd "$WT_MAIN" && printf '%s' "$payload_head" | "${PY_CMD[@]}" "$SCRIPT" 2>/dev/null)
if is_deny "$actual_stdout" && deny_reason "$actual_stdout" | grep -Fq "reviewing-pre-pr main \"$WT_DIR\""; then
  printf "  ${GREEN}PASS${NC} --head of an unreviewed worktree → deny naming that worktree\\n"
  pass=$((pass + 1))
else
  printf "  ${RED}FAIL${NC} --head of a worktree must be gated on that worktree (stdout=%s)\\n" "$actual_stdout"
  fail=$((fail + 1))
fi

# --head already names the branch, so the deny must not suggest another one.
MAIN_MARKER="$(git -C "$WT_MAIN" rev-parse --absolute-git-dir)/pre-pr-review-$(git -C "$WT_MAIN" rev-parse HEAD)"
: > "$MAIN_MARKER"
actual_stdout=$(cd "$WT_MAIN" && printf '%s' "$payload_head" | "${PY_CMD[@]}" "$SCRIPT" 2>/dev/null)
rm -f "$MAIN_MARKER"
if is_deny "$actual_stdout" && ! deny_reason "$actual_stdout" | grep -Fq -- "--head feature/other"; then
  printf "  ${GREEN}PASS${NC} --head given → deny suggests no other branch\\n"
  pass=$((pass + 1))
else
  printf "  ${RED}FAIL${NC} --head deny must not suggest another --head (stdout=%s)\\n" "$actual_stdout"
  fail=$((fail + 1))
fi

: > "$WT_MARKER"
actual_stdout=$(cd "$WT_MAIN" && printf '%s' "$payload_head" | "${PY_CMD[@]}" "$SCRIPT" 2>/dev/null)
if ! is_deny "$actual_stdout"; then
  printf "  ${GREEN}PASS${NC} --head of a reviewed worktree → allow\\n"
  pass=$((pass + 1))
else
  printf "  ${RED}FAIL${NC} --head of a reviewed worktree must allow (stdout=%s)\\n" "$actual_stdout"
  fail=$((fail + 1))
fi

# No checkout of the --head branch means no local diff to review; allowing it
# would let any PR skip the review by naming its branch.
payload_gone='{"tool_name":"Bash","tool_input":{"command":"gh pr create --draft --title \"MXTS-1234: probe\" --base main --head feature/gone"}}'
actual_stdout=$(cd "$WT_MAIN" && printf '%s' "$payload_gone" | "${PY_CMD[@]}" "$SCRIPT" 2>/dev/null)
if is_deny "$actual_stdout" && deny_reason "$actual_stdout" | grep -Fq "feature/gone"; then
  printf "  ${GREEN}PASS${NC} --head of a branch no worktree has → deny naming the branch\\n"
  pass=$((pass + 1))
else
  printf "  ${RED}FAIL${NC} --head without a local checkout must deny (stdout=%s)\\n" "$actual_stdout"
  fail=$((fail + 1))
fi

# CI jobs check out a commit, not a branch. A detached checkout at the --head
# branch's commit is that branch's checkout.
git -C "$WT_MAIN" branch -q feature/ci feature/other
git -C "$WT_MAIN" checkout -q --detach feature/ci
payload_ci='{"tool_name":"Bash","tool_input":{"command":"gh pr create --draft --title \"MXTS-1234: probe\" --base main --head feature/ci"}}'
actual_stdout=$(cd "$WT_MAIN" && printf '%s' "$payload_ci" | "${PY_CMD[@]}" "$SCRIPT" 2>/dev/null)
if is_deny "$actual_stdout" && deny_reason "$actual_stdout" | grep -Fq "reviewing-pre-pr main \"$(git -C "$WT_MAIN" rev-parse --show-toplevel)\""; then
  printf "  ${GREEN}PASS${NC} detached at the --head commit, unreviewed → deny naming this checkout\\n"
  pass=$((pass + 1))
else
  printf "  ${RED}FAIL${NC} detached --head checkout must be reviewed here (stdout=%s)\\n" "$actual_stdout"
  fail=$((fail + 1))
fi
CI_MARKER="$(git -C "$WT_MAIN" rev-parse --absolute-git-dir)/pre-pr-review-$(git -C "$WT_MAIN" rev-parse HEAD)"
: > "$CI_MARKER"
actual_stdout=$(cd "$WT_MAIN" && printf '%s' "$payload_ci" | "${PY_CMD[@]}" "$SCRIPT" 2>/dev/null)
rm -f "$CI_MARKER"
git -C "$WT_MAIN" checkout -q feature/other
if ! is_deny "$actual_stdout"; then
  printf "  ${GREEN}PASS${NC} detached at the --head commit, reviewed → allow\\n"
  pass=$((pass + 1))
else
  printf "  ${RED}FAIL${NC} detached reviewed --head checkout must allow (stdout=%s)\\n" "$actual_stdout"
  fail=$((fail + 1))
fi

# Claude Code Desktop ran the hook in the main checkout while Claude's shell, and
# so `gh pr create`, ran in the session's worktree; the event's cwd says which.
payload_cwd="{\"tool_name\":\"Bash\",\"cwd\":\"$WT_DIR\",\"tool_input\":{\"command\":\"gh pr create --draft --title \\\"MXTS-1234: probe\\\" --base main\"}}"
actual_stdout=$(cd "$WT_MAIN" && printf '%s' "$payload_cwd" | "${PY_CMD[@]}" "$SCRIPT" 2>/dev/null)
if ! is_deny "$actual_stdout"; then
  printf "  ${GREEN}PASS${NC} hook in main checkout, event cwd = reviewed worktree → allow\\n"
  pass=$((pass + 1))
else
  printf "  ${RED}FAIL${NC} the event's cwd must decide the checkout (stdout=%s)\\n" "$actual_stdout"
  fail=$((fail + 1))
fi

# A relative `cd` is relative to the shell's cwd, not the hook process's.
payload_rel="{\"tool_name\":\"Bash\",\"cwd\":\"$WT_PARENT\",\"tool_input\":{\"command\":\"cd worktrees/feature-probe && gh pr create --draft --title \\\"MXTS-1234: probe\\\" --base main\"}}"
actual_stdout=$(cd "$WT_MAIN" && printf '%s' "$payload_rel" | "${PY_CMD[@]}" "$SCRIPT" 2>/dev/null)
if ! is_deny "$actual_stdout"; then
  printf "  ${GREEN}PASS${NC} relative cd resolved against the event cwd → allow\\n"
  pass=$((pass + 1))
else
  printf "  ${RED}FAIL${NC} relative cd must resolve against the event cwd (stdout=%s)\\n" "$actual_stdout"
  fail=$((fail + 1))
fi

# Without --head, gh opens the PR for the main checkout's own branch, so the deny
# stands; it must say where the review passed and how to target that branch.
payload_nohead='{"tool_name":"Bash","tool_input":{"command":"gh pr create --draft --title \"MXTS-1234: probe\" --base main"}}'
actual_stdout=$(cd "$WT_MAIN" && printf '%s' "$payload_nohead" | "${PY_CMD[@]}" "$SCRIPT" 2>/dev/null)
reason=$(deny_reason "$actual_stdout")
if is_deny "$actual_stdout" && printf '%s' "$reason" | grep -Fq "$WT_DIR" \
    && printf '%s' "$reason" | grep -Fq -- "--head feature/probe"; then
  printf "  ${GREEN}PASS${NC} no --head → deny points at the reviewed worktree and --head\\n"
  pass=$((pass + 1))
else
  printf "  ${RED}FAIL${NC} deny must name the reviewed worktree and --head (stdout=%s)\\n" "$actual_stdout"
  fail=$((fail + 1))
fi

echo ""
total=$((pass + fail))
echo "Results: ${pass}/${total} passed"
[ "$fail" -eq 0 ]
