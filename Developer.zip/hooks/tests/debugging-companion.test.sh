#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SCRIPT="$SCRIPT_DIR/../debugging-companion.py"

# Resolve a working Python 3 interpreter across macOS/Linux/Windows (Git Bash).
# Order: python3 → python → "py -3". Each candidate is *run*, not just
# `command -v`-checked, so the Windows Store alias stub is rejected.
resolve_python() {
  local _cand
  for _cand in python3 python "py -3"; do
    if $_cand -c 'import sys; sys.exit(0 if sys.version_info[0] == 3 else 1)' >/dev/null 2>&1; then
      printf '%s\n' "$_cand"; return 0
    fi
  done
  return 1
}

PY=$(resolve_python) || { echo "no Python 3 found (tried python3, python, py -3)" >&2; exit 1; }
read -r -a PY_CMD <<< "$PY"      # split "py -3" into argv; quote on use

RED='\033[0;31m'
GREEN='\033[0;32m'
NC='\033[0m'
pass=0
fail=0

# Parses stdout as JSON instead of grepping, so broken JSON fails the test.
assert_emits_context() {
  local description="$1"
  local input="$2"
  local output
  output=$(echo "$input" | "${PY_CMD[@]}" "$SCRIPT" 2>/dev/null || true)
  if printf '%s' "$output" | "${PY_CMD[@]}" -c "
import sys, json
d = json.load(sys.stdin)['hookSpecificOutput']
ok = d['hookEventName'] == 'PostToolUse' and 'developer:debugging-maxxton-workloads' in d['additionalContext']
sys.exit(0 if ok else 1)
" 2>/dev/null; then
    printf "  ${GREEN}PASS${NC} %s\n" "$description"
    pass=$((pass + 1))
  else
    printf "  ${RED}FAIL${NC} %s (output: %s)\n" "$description" "$output"
    fail=$((fail + 1))
  fi
}

assert_silent() {
  local description="$1"
  local input="$2"
  local output
  local actual_exit=0
  output=$(echo "$input" | "${PY_CMD[@]}" "$SCRIPT" 2>/dev/null) || actual_exit=$?
  if [ "$actual_exit" -eq 0 ] && [ -z "$output" ]; then
    printf "  ${GREEN}PASS${NC} %s\n" "$description"
    pass=$((pass + 1))
  else
    printf "  ${RED}FAIL${NC} %s (exit=%d, output: %s)\n" "$description" "$actual_exit" "$output"
    fail=$((fail + 1))
  fi
}

echo "debugging-companion.py test suite"
echo "================================="

echo ""
echo "systematic-debugging loaded — should point at the companion skill"
assert_emits_context \
  "plugin-prefixed skill name" \
  '{"tool_name": "Skill", "tool_input": {"skill": "superpowers:systematic-debugging"}}'
assert_emits_context \
  "bare skill name" \
  '{"tool_name": "Skill", "tool_input": {"skill": "systematic-debugging", "args": "pods crashlooping"}}'

echo ""
echo "Anything else — should be silent"
assert_silent "other skill" '{"tool_name": "Skill", "tool_input": {"skill": "superpowers:brainstorming"}}'
assert_silent "suffix lookalike" '{"tool_name": "Skill", "tool_input": {"skill": "foo:not-systematic-debugging"}}'
assert_silent "non-Skill tool mentioning it" '{"tool_name": "Bash", "tool_input": {"command": "echo systematic-debugging"}}'
assert_silent "missing tool_input" '{"tool_name": "Skill"}'
assert_silent "non-string skill" '{"tool_name": "Skill", "tool_input": {"skill": 42}}'
assert_silent "malformed JSON" 'not json'
assert_silent "empty input" ''

echo ""
echo "Results: $pass passed, $fail failed"
[ "$fail" -eq 0 ]
