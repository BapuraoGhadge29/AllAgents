#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SCRIPT="$SCRIPT_DIR/../session-start.sh"

# The self-hosted runner sets it; it would skip the MaxxtonGroup-origin check under test.
unset MAXXTON_FORCE_GIT_HOOKS

RED='\033[0;31m'
GREEN='\033[0;32m'
NC='\033[0m'
pass=0
fail=0

assert_exit_zero() {
  local description="$1"
  local actual_exit=0
  bash "$SCRIPT" >/dev/null 2>&1 || actual_exit=$?
  if [ "$actual_exit" -eq 0 ]; then
    printf "  ${GREEN}PASS${NC} %s\n" "$description"
    pass=$((pass + 1))
  else
    printf "  ${RED}FAIL${NC} %s (exit=%d)\n" "$description" "$actual_exit"
    fail=$((fail + 1))
  fi
}

echo "session-start.sh test suite"
echo "==========================="

echo ""
echo "Non-git working directory — should exit 0 (no-op)"
NON_GIT_DIR=$(mktemp -d)
trap 'rm -rf "$NON_GIT_DIR"' EXIT
(
  cd "$NON_GIT_DIR"
  bash "$SCRIPT" >/dev/null 2>&1
) && {
  printf "  ${GREEN}PASS${NC} non-git dir → exit 0\n"
  pass=$((pass + 1))
} || {
  printf "  ${RED}FAIL${NC} non-git dir should exit 0\n"
  fail=$((fail + 1))
}

echo ""
echo "Missing template dir — should exit 0 without touching git config"
NO_TPL_DIR=$(mktemp -d)
trap 'rm -rf "$NON_GIT_DIR" "$NO_TPL_DIR"' EXIT
(
  cd "$NO_TPL_DIR"
  git init -q
  # Move template dir away by pointing SCRIPT to a path with no template sibling.
  # Use a wrapper script that copies session-start.sh to a temp dir.
  TMP_SCRIPT="$NO_TPL_DIR/session-start.sh"
  cp "$SCRIPT" "$TMP_SCRIPT"
  bash "$TMP_SCRIPT" >/dev/null 2>&1
) && {
  printf "  ${GREEN}PASS${NC} missing template dir → exit 0\n"
  pass=$((pass + 1))
} || {
  printf "  ${RED}FAIL${NC} missing template dir should exit 0\n"
  fail=$((fail + 1))
}

echo ""
echo "init.templateDir self-heal (isolated HOME → isolated global git config)"

# Stale maxxton tmp/cache value (now-deleted dir) → repaired to canonical path
_HOME1=$(mktemp -d)
_CANON1="$_HOME1/.claude/plugins/marketplaces/maxxton-marketplace/plugins/developer/git-template"
mkdir -p "$_CANON1/hooks"
_REPO1=$(mktemp -d)
( cd "$_REPO1" && git init -q )
HOME="$_HOME1" git config --global init.templateDir "$_HOME1/.cache/maxxton-marketplace/old/git-template"
( cd "$_REPO1" && HOME="$_HOME1" bash "$SCRIPT" >/dev/null 2>&1 ) || true
_VAL1=$(HOME="$_HOME1" git config --global init.templateDir 2>/dev/null || true)
if [ "$_VAL1" = "$_CANON1" ]; then
  printf "  ${GREEN}PASS${NC} stale init.templateDir repaired to canonical path\n"
  pass=$((pass + 1))
else
  printf "  ${RED}FAIL${NC} stale init.templateDir not repaired (got: %s)\n" "$_VAL1"
  fail=$((fail + 1))
fi
rm -rf "$_HOME1" "$_REPO1"

# A legitimate non-maxxton custom template is left untouched
_HOME2=$(mktemp -d)
_CANON2="$_HOME2/.claude/plugins/marketplaces/maxxton-marketplace/plugins/developer/git-template"
mkdir -p "$_CANON2/hooks"
_CUSTOM2="$_HOME2/my-template"
mkdir -p "$_CUSTOM2/hooks"
_REPO2=$(mktemp -d)
( cd "$_REPO2" && git init -q )
HOME="$_HOME2" git config --global init.templateDir "$_CUSTOM2"
( cd "$_REPO2" && HOME="$_HOME2" bash "$SCRIPT" >/dev/null 2>&1 ) || true
_VAL2=$(HOME="$_HOME2" git config --global init.templateDir 2>/dev/null || true)
if [ "$_VAL2" = "$_CUSTOM2" ]; then
  printf "  ${GREEN}PASS${NC} non-maxxton custom template left untouched\n"
  pass=$((pass + 1))
else
  printf "  ${RED}FAIL${NC} non-maxxton custom template was overwritten (got: %s)\n" "$_VAL2"
  fail=$((fail + 1))
fi
rm -rf "$_HOME2" "$_REPO2"

# A broken non-maxxton template (hooks dir missing) is still the user's config —
# never overwritten.
_HOME3=$(mktemp -d)
_CANON3="$_HOME3/.claude/plugins/marketplaces/maxxton-marketplace/plugins/developer/git-template"
mkdir -p "$_CANON3/hooks"
_BROKEN3="$_HOME3/user-template-gone"
_REPO3=$(mktemp -d)
( cd "$_REPO3" && git init -q )
HOME="$_HOME3" git config --global init.templateDir "$_BROKEN3"
( cd "$_REPO3" && HOME="$_HOME3" bash "$SCRIPT" >/dev/null 2>&1 ) || true
_VAL3=$(HOME="$_HOME3" git config --global init.templateDir 2>/dev/null || true)
if [ "$_VAL3" = "$_BROKEN3" ]; then
  printf "  ${GREEN}PASS${NC} broken non-maxxton template left untouched\n"
  pass=$((pass + 1))
else
  printf "  ${RED}FAIL${NC} broken non-maxxton template was overwritten (got: %s)\n" "$_VAL3"
  fail=$((fail + 1))
fi
rm -rf "$_HOME3" "$_REPO3"

echo ""
echo "Rule copies refreshed at session start (MaxxtonGroup repos only)"

# $1 = origin URL; prints the repo dir after session-start ran with a fake marketplace
_session_start_in_repo() {
  local _home="$1" _origin="$2" _repo
  _repo=$(mktemp -d)
  mkdir -p "$_home/.claude/plugins/marketplaces/maxxton-marketplace/plugins/developer/git-template/hooks"
  mkdir -p "$_home/.claude/plugins/marketplaces/maxxton-marketplace/plugins/developer/rules"
  echo "# rule" > "$_home/.claude/plugins/marketplaces/maxxton-marketplace/plugins/developer/rules/example.md"
  ( cd "$_repo" && git init -q && git remote add origin "$_origin" )
  ( cd "$_repo" && HOME="$_home" bash "$SCRIPT" >/dev/null 2>&1 ) || true
  printf '%s' "$_repo"
}

_HOME7=$(mktemp -d)
_REPO7=$(_session_start_in_repo "$_HOME7" "git@github.com:MaxxtonGroup/some-service.git")
if [ -f "$_REPO7/.claude/rules/developer/example.md" ] && [ ! -L "$_REPO7/.claude/rules/developer" ]; then
  printf "  ${GREEN}PASS${NC} MaxxtonGroup repo gets a rule copy at session start\n"
  pass=$((pass + 1))
else
  printf "  ${RED}FAIL${NC} MaxxtonGroup repo has no rule copy after session start\n"
  fail=$((fail + 1))
fi
rm -rf "$_HOME7" "$_REPO7"


_HOME8=$(mktemp -d)
_REPO8=$(_session_start_in_repo "$_HOME8" "git@github.com:someone/personal.git")
if [ ! -e "$_REPO8/.claude/rules/developer" ] && [ ! -e "$_REPO8/.gitignore" ]; then
  printf "  ${GREEN}PASS${NC} personal repo is left alone at session start\n"
  pass=$((pass + 1))
else
  printf "  ${RED}FAIL${NC} personal repo was changed at session start\n"
  fail=$((fail + 1))
fi
rm -rf "$_HOME8" "$_REPO8"

echo ""
echo "Running from the claude.ai org marketplace cache"

# The plugin runs from cache/<org marketplace>/developer/<rev>; a stale GitHub
# clone is still on disk. The template must follow the running plugin, and a
# repo's outdated _run-hooks.sh copy must be refreshed.
_HOME4=$(mktemp -d)
_PLUGIN4="$_HOME4/.claude/plugins/cache/claudeai-maxxtongroup-claude-marketplace/developer/0060"
mkdir -p "$_PLUGIN4/hooks"
cp "$SCRIPT" "$_PLUGIN4/hooks/session-start.sh"
cp -R "$SCRIPT_DIR/../../git-template" "$_PLUGIN4/git-template"
_CLONE4="$_HOME4/.claude/plugins/marketplaces/maxxton-marketplace/plugins/developer/git-template"
mkdir -p "$_CLONE4/hooks"
_REPO4=$(mktemp -d)
( cd "$_REPO4" && git init -q )
for _h in _run-hooks.sh pre-commit commit-msg pre-push post-checkout; do
  printf '#!/usr/bin/env bash\n# stale copy\n' > "$_REPO4/.git/hooks/$_h"
  chmod +x "$_REPO4/.git/hooks/$_h"
done
HOME="$_HOME4" git config --global init.templateDir "$_CLONE4"
( cd "$_REPO4" && HOME="$_HOME4" bash "$_PLUGIN4/hooks/session-start.sh" >/dev/null 2>&1 ) || true
_VAL4=$(HOME="$_HOME4" git config --global init.templateDir 2>/dev/null || true)
if [ "$_VAL4" = "$_PLUGIN4/git-template" ]; then
  printf "  ${GREEN}PASS${NC} init.templateDir follows the org-marketplace plugin, not the stale clone\n"
  pass=$((pass + 1))
else
  printf "  ${RED}FAIL${NC} init.templateDir should follow the org-marketplace plugin (got: %s)\n" "$_VAL4"
  fail=$((fail + 1))
fi
if cmp -s "$_REPO4/.git/hooks/_run-hooks.sh" "$_PLUGIN4/git-template/hooks/_run-hooks.sh"; then
  printf "  ${GREEN}PASS${NC} outdated .git/hooks/_run-hooks.sh refreshed from the template\n"
  pass=$((pass + 1))
else
  printf "  ${RED}FAIL${NC} outdated .git/hooks/_run-hooks.sh was not refreshed\n"
  fail=$((fail + 1))
fi

# A later plugin update leaves templateDir on a deleted revision; it must be repaired.
HOME="$_HOME4" git config --global init.templateDir \
  "$_HOME4/.claude/plugins/cache/claudeai-maxxtongroup-claude-marketplace/developer/0059/git-template"
( cd "$_REPO4" && HOME="$_HOME4" bash "$_PLUGIN4/hooks/session-start.sh" >/dev/null 2>&1 ) || true
_VAL5=$(HOME="$_HOME4" git config --global init.templateDir 2>/dev/null || true)
if [ "$_VAL5" = "$_PLUGIN4/git-template" ]; then
  printf "  ${GREEN}PASS${NC} templateDir on a removed org-marketplace revision repaired\n"
  pass=$((pass + 1))
else
  printf "  ${RED}FAIL${NC} templateDir on a removed org-marketplace revision not repaired (got: %s)\n" "$_VAL5"
  fail=$((fail + 1))
fi
rm -rf "$_HOME4" "$_REPO4"


# After a plugin update the old revision's folder can be removed; the repo's rule
# link into it must be repaired at session start, not only on the next checkout.
_HOME6=$(mktemp -d)
_PLUGIN6="$_HOME6/.claude/plugins/cache/claudeai-maxxtongroup-claude-marketplace/developer/0061"
mkdir -p "$_PLUGIN6/hooks" "$_PLUGIN6/rules"
cp "$SCRIPT" "$_PLUGIN6/hooks/session-start.sh"
cp -R "$SCRIPT_DIR/../../git-template" "$_PLUGIN6/git-template"
cp -R "$SCRIPT_DIR/../../git-hooks" "$_PLUGIN6/git-hooks"
echo "# rule" > "$_PLUGIN6/rules/example.md"
printf '{ "version": 2, "plugins": { "developer@claudeai-maxxtongroup-claude-marketplace": [ { "scope": "user", "installPath": "%s" } ] } }\n' \
  "$_PLUGIN6" > "$_HOME6/.claude/plugins/installed_plugins.json"
_REPO6=$(mktemp -d)
( cd "$_REPO6" && git init -q && git remote add origin git@github.com:MaxxtonGroup/some-repo.git )
mkdir -p "$_REPO6/.claude/rules"
ln -s "$_HOME6/.claude/plugins/cache/claudeai-maxxtongroup-claude-marketplace/developer/0060/rules" "$_REPO6/.claude/rules/developer"
( cd "$_REPO6" && HOME="$_HOME6" bash "$_PLUGIN6/hooks/session-start.sh" >/dev/null 2>&1 ) || true
if [ -f "$_REPO6/.claude/rules/developer/example.md" ]; then
  printf "  ${GREEN}PASS${NC} rule link into a removed revision replaced by a copy at session start\n"
  pass=$((pass + 1))
else
  printf "  ${RED}FAIL${NC} rule link still broken after session start (-> %s)\n" "$(readlink "$_REPO6/.claude/rules/developer")"
  fail=$((fail + 1))
fi
rm -rf "$_HOME6" "$_REPO6"

echo ""
total=$((pass + fail))
echo "Results: ${pass}/${total} passed"
[ "$fail" -eq 0 ]
