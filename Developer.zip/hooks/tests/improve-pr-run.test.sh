#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SCRIPT="$SCRIPT_DIR/../improve-pr-run.sh"
WORK="$(mktemp -d)"
trap 'rm -rf "$WORK"' EXIT

BIN="$WORK/bin"
mkdir -p "$BIN"
cat > "$BIN/claude" << 'CLAUDE'
#!/usr/bin/env bash
printf '%s\n' "$@" > "$_ARGS_LOG"
CLAUDE
cat > "$BIN/gh" << 'GH'
#!/usr/bin/env bash
printf '%s' "${_GH_BODY:-}"
GH
chmod +x "$BIN/claude" "$BIN/gh"

ARGS_LOG="$WORK/args.log"
HASH_FILE="$WORK/body.hash"

assert_model_haiku() {
  local path="$1"
  if awk 'previous == "--model" && $0 == "haiku" { found=1 } { previous=$0 } END { exit !found }' "$ARGS_LOG"; then
    printf 'PASS %s path passes --model haiku\n' "$path"
  else
    printf 'FAIL %s path must pass --model haiku\n' "$path" >&2
    return 1
  fi
}

> "$ARGS_LOG"
(
  cd "$WORK"
  PATH="$BIN:$PATH" _ARGS_LOG="$ARGS_LOG" _GH_BODY="a hand-written description that is long enough to keep" \
    bash "$SCRIPT" create common title-tail keep-title body-tail from-person from-commits keep-body "$HASH_FILE"
)
assert_model_haiku preserve

> "$ARGS_LOG"
(
  cd "$WORK"
  PATH="$BIN:$PATH" _ARGS_LOG="$ARGS_LOG" _GH_BODY="" \
    bash "$SCRIPT" push common title-tail keep-title body-tail from-person from-commits keep-body "$HASH_FILE"
)
assert_model_haiku regenerate
