#!/usr/bin/env bash
# Tests for dockerfile-pin-guard.py.
#
# The hook is PostToolUse on Write|Edit|MultiEdit. It reads the Dockerfile from
# disk and always exits 0; the decision travels in stdout (empty = allow,
# {"decision": "block"} = block). These tests assert on that stdout by PARSING
# it with a resolved Python 3 interpreter (never grep on a JSON-key substring —
# a broken envelope would pass a grep).
set -euo pipefail

# Resolve a Python 3 interpreter (python3 → python → py -3) by execution so the
# Windows Store-alias stub is rejected; run via "${PY_CMD[@]}" (Windows Git Bash).
resolve_python() {
  local _cand
  for _cand in python3 python "py -3"; do
    if $_cand -c 'import sys; sys.exit(0 if sys.version_info[0] == 3 else 1)' >/dev/null 2>&1; then
      printf '%s\n' "$_cand"; return 0
    fi
  done
  return 1
}
PY=$(resolve_python) || { echo "no Python 3 found (tried python3, python, py -3)" >&2; exit 1; }
read -r -a PY_CMD <<< "$PY"

HOOK="$(cd "$(dirname "$0")/.." && pwd)/dockerfile-pin-guard.py"
WORK="$(mktemp -d)"
trap 'rm -rf "$WORK"' EXIT

run() {  # reads stdin json on fd0, echoes hook stdout
  "${PY_CMD[@]}" "$HOOK"
}

payload() {  # payload <tool> <file_path>
  "${PY_CMD[@]}" -c '
import json, sys
print(json.dumps({"tool_name": sys.argv[1], "tool_input": {"file_path": sys.argv[2]}}))
' "$1" "$2"
}

assert_block() {  # assert_block <file_path> <expected-substring-in-reason>
  local out
  out="$(payload Edit "$1" | run)"
  "${PY_CMD[@]}" -c '
import json, sys
d = json.loads(sys.argv[1])
assert d["decision"] == "block", "expected block, got %r" % d["decision"]
assert sys.argv[2] in d["reason"], "reason lacks %r: %r" % (sys.argv[2], d["reason"])
' "$out" "$2"
}

assert_allow() {  # assert_allow <file_path> ; stdout must be empty
  local out
  out="$(payload Write "$1" | run)"
  "${PY_CMD[@]}" -c '
import sys
assert sys.argv[1].strip() == "", "expected allow (empty stdout), got: %r" % sys.argv[1]
' "$out"
}

DF="$WORK/Dockerfile"

# 1. Full patch pins with suffixes, digests, scratch and stage refs -> allow.
cat > "$DF" <<'EOF'
# syntax=docker/dockerfile:1
FROM --platform=linux/amd64 node:22.11.0-alpine AS build
FROM eclipse-temurin:21.0.5_11-jre AS jre
FROM gcr.io/distroless/java21-debian12@sha256:0123456789abcdef
FROM localhost:5000/team/base:v1.2.3
FROM gcr.io/distroless/static-debian12:nonroot@sha256:0123456789abcdef
FROM example/tool:1.2.3.4
FROM --platform=amd64 apache/airflow:slim-3.2.2-python3.10 AS airflow
FROM build AS test
FROM scratch
COPY --from=build /app /app
EOF
assert_allow "$DF"

# 2. Major-only tag -> block, names the tag.
printf 'FROM node:22\n' > "$DF"
assert_block "$DF" "tag '22' is not a full MAJOR.MINOR.PATCH version"

# 3. Major.minor with suffix -> block.
printf 'FROM python:3.12-slim\n' > "$DF"
assert_block "$DF" "tag '3.12-slim'"

# 4. Codename-only tag -> block.
printf 'FROM debian:bookworm-slim\n' > "$DF"
assert_block "$DF" "tag 'bookworm-slim'"

# 5. No tag and latest -> block.
printf 'FROM nginx\n' > "$DF"
assert_block "$DF" "has no tag"
printf 'FROM nginx:latest\n' > "$DF"
assert_block "$DF" "latest tag"

# 5b. A digest does not excuse a floating latest tag.
printf 'FROM nginx:latest@sha256:0123456789abcdef\n' > "$DF"
assert_block "$DF" "latest tag"

# 5c. The patch number must end the version: 1.2.3garbage is not a pin.
printf 'FROM example/tool:1.2.3garbage\n' > "$DF"
assert_block "$DF" "tag '1.2.3garbage'"

# 6. ARG in FROM -> block, even when the ARG default is fully pinned.
printf 'ARG NODE_VERSION=22.11.0\nFROM node:${NODE_VERSION}-alpine\n' > "$DF"
assert_block "$DF" "uses a variable"

# 6b. The whole image as one build arg (injected by the pipeline) -> allow,
#     in both ${VAR} and $VAR form.
printf 'ARG DBT_CONFIG_IMAGE\nFROM ${DBT_CONFIG_IMAGE} AS dbt_config\nFROM $BASE_IMAGE\n' > "$DF"
assert_allow "$DF"

# 6c. A word prefix without a full version is still not a pin.
printf 'FROM apache/airflow:slim-3.2-python3.10\n' > "$DF"
assert_block "$DF" "tag 'slim-3.2-python3.10'"

# 7. A partial pin in a later stage is still caught, with its line number.
printf 'FROM node:22.11.0 AS build\n\nFROM nginx:1.27\n' > "$DF"
assert_block "$DF" "line 3: FROM nginx:1.27"

# 8. FROM split by a line continuation is parsed.
printf 'FROM \\\n  node:22\n' > "$DF"
assert_block "$DF" "tag '22'"

# 9. Variant names: Dockerfile.prod, api.dockerfile and Containerfile are checked.
printf 'FROM node:22\n' > "$WORK/Dockerfile.prod"
assert_block "$WORK/Dockerfile.prod" "tag '22'"
printf 'FROM node:22\n' > "$WORK/api.dockerfile"
assert_block "$WORK/api.dockerfile" "tag '22'"
printf 'FROM node:22\n' > "$WORK/Containerfile"
assert_block "$WORK/Containerfile" "tag '22'"

# 9b. Heredoc bodies are not instructions: an embedded `from x import y` is
#     ignored, and a real FROM after the heredoc is still checked.
cat > "$DF" <<'OUTER'
FROM python:3.12.7-slim
COPY <<EOF /app/main.py
from flask import Flask
EOF
RUN <<-"SCRIPT" bash
	from=1
	SCRIPT
OUTER
assert_allow "$DF"
printf 'FROM python:3.12.7-slim\nCOPY <<EOF /a.py\nfrom os import path\nEOF\nFROM node:22\n' > "$DF"
assert_block "$DF" "line 5: FROM node:22"

# 9c. Shell arithmetic is not a heredoc: a later FROM is still checked.
printf 'FROM node:22.11.0\nRUN echo $((1<<2))\nFROM nginx:1.27\n' > "$DF"
assert_block "$DF" "line 3: FROM nginx:1.27"

# 12. Tool-version ARGs: a Renovate comment directly above -> allow; a
#     *_VERSION without a default (pipeline-provided) -> allow.
cat > "$DF" <<'EOF'
FROM node:22.11.0-alpine
# renovate: datasource=npm depName=@anthropic-ai/claude-code
ARG CLAUDE_CODE_VERSION=2.1.292
# renovate: datasource=github-release-attachments depName=cli/cli
ARG GH_VERSION=v2.101.0
ARG GH_SHA256=9bca2d1c16825f109907a23307628a2f0698fbf99662b73a5cf0b020293072b8
# renovate: ignore pinned to the server's protocol version
ARG PROTOC_VERSION=3.21.12
ARG BUILD_VERSION
ARG APP_VERSION=${BUILD_VERSION}
EOF
assert_allow "$DF"

# 12b. A *_VERSION ARG without the comment -> block, with its line number.
printf 'FROM node:22.11.0-alpine\nARG YQ_VERSION=4.54.1\n' > "$DF"
assert_block "$DF" "line 2: ARG YQ_VERSION=4.54.1"

# 12c. The comment must sit directly above, not one line further up.
printf 'FROM node:22.11.0-alpine\n# renovate: datasource=github-releases depName=mikefarah/yq\n\nARG YQ_VERSION=4.54.1\n' > "$DF"
assert_block "$DF" "no '# renovate: datasource"

# 12d. A comment without depName does not count.
printf 'FROM node:22.11.0-alpine\n# renovate: datasource=github-releases\nARG YQ_VERSION=4.54.1\n' > "$DF"
assert_block "$DF" "ARG YQ_VERSION"

# 12e. Several *_VERSION ARGs on one line -> block, asks to split them.
printf 'FROM node:22.11.0-alpine\nARG YQ_VERSION=4.54.1 JQ_VERSION=1.7.1\n' > "$DF"
assert_block "$DF" "on its own line"

# 12e2. An ignore without a reason does not opt out.
printf 'FROM node:22.11.0-alpine\n# renovate: ignore\nARG YQ_VERSION=4.54.1\n' > "$DF"
assert_block "$DF" "ARG YQ_VERSION"

# 12f. FROM and ARG problems are reported together.
printf 'FROM node:22\nARG YQ_VERSION=4.54.1\n' > "$DF"
assert_block "$DF" "Renovate cannot keep patched"

# 10. Non-Dockerfiles are ignored, even when named like one or holding
#     `from x import y` lines.
for f in notes.md Dockerfile.md Dockerfile.dockerignore dockerfile_utils.py; do
  printf 'from pathlib import Path\nFROM node:22\n' > "$WORK/$f"
  assert_allow "$WORK/$f"
done

# 11. Missing file and malformed stdin -> fail open.
assert_allow "$WORK/missing/Dockerfile"
out="$(printf 'not json' | run)"
[ -z "$out" ] || { echo "expected empty stdout on malformed stdin, got: $out" >&2; exit 1; }

echo "PASS"
