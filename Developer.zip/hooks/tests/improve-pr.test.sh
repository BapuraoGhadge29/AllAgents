#!/usr/bin/env bash
# Tests for hooks/improve-pr.sh — the PR improvement launcher.
set -uo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SCRIPT="$SCRIPT_DIR/../improve-pr.sh"

RED='\033[0;31m'
GREEN='\033[0;32m'
NC='\033[0m'
pass=0
fail=0

ok()  { printf "  ${GREEN}PASS${NC} %s\n" "$1"; pass=$((pass + 1)); }
bad() { printf "  ${RED}FAIL${NC} %s\n" "$1"; fail=$((fail + 1)); }

WORK="$(mktemp -d)"
CALLS_LOG="$WORK/calls.log"
# One argument per line, so a flag assertion matches a whole line rather than
# grepping a flattened argv that also contains the entire -p prompt.
ARGS_LOG="$WORK/args.log"
trap 'rm -rf "$WORK"' EXIT

# Run every case in a throwaway repo: the launcher's dedup lock lives in $GIT_DIR
# and survives for 60s, so sharing a repo makes each case skip the one before it.
REPO="$WORK/repo"
mkdir -p "$REPO"
git -C "$REPO" init --quiet --initial-branch=bugfix/test-branch
git -C "$REPO" config user.email t@t.t
git -C "$REPO" config user.name t
git -C "$REPO" commit --quiet --allow-empty -m init

# Stub claude: log the -p prompt to _CALLS_LOG (passed via env), then exit 0.
# Using a single-quoted heredoc so ${_CALLS_LOG} is evaluated at runtime.
STUB_DIR="$WORK/bin"
mkdir -p "$STUB_DIR"
cat > "$STUB_DIR/claude" << 'STUB'
#!/usr/bin/env bash
printf '%s\n' "$@" >> "${_ARGS_LOG:-/dev/null}"
[ -n "${_PWD_LOG:-}" ] && pwd -P >> "$_PWD_LOG"
while [ $# -gt 0 ]; do
  if [ "$1" = "-p" ] && [ $# -gt 1 ]; then
    printf '%s\n' "$2" >> "${_CALLS_LOG:-/dev/null}"
    break
  fi
  shift
done
exit 0
STUB
chmod +x "$STUB_DIR/claude"

# Slow stub: same logging, but takes _SLOW_SECS to finish. Models the real nested
# `claude -p` run (~21s median in real sessions) so blocking is observable here.
SLOW_DIR="$WORK/slowbin"
mkdir -p "$SLOW_DIR"
cat > "$SLOW_DIR/claude" << 'SLOWSTUB'
#!/usr/bin/env bash
printf '%s\n' "$@" >> "${_ARGS_LOG:-/dev/null}"
sleep "${_SLOW_SECS:-3}"
while [ $# -gt 0 ]; do
  if [ "$1" = "-p" ] && [ $# -gt 1 ]; then
    printf '%s\n' "$2" >> "${_CALLS_LOG:-/dev/null}"
    break
  fi
  shift
done
exit 0
SLOWSTUB
chmod +x "$SLOW_DIR/claude"

# run_hook <bin_dir> [trigger...] — fresh lock state, cwd inside the throwaway repo.
run_hook() {
  local bin="$1"; shift
  rm -rf "$REPO/.git"/improve-pr-*.lock
  ( cd "$REPO" && _CALLS_LOG="$CALLS_LOG" _ARGS_LOG="$ARGS_LOG" _SLOW_SECS="${_SLOW_SECS:-3}" \
      PATH="$bin:$PATH" bash "$SCRIPT" "$@" 2>/dev/null )
}

# wait_for_log <timeout_secs> — the launcher detaches the claude run, so the
# prompt lands in CALLS_LOG after the script has already returned.
wait_for_log() {
  local deadline=$(( $(date +%s) + $1 ))
  while [ "$(date +%s)" -lt "$deadline" ]; do
    [ -s "$CALLS_LOG" ] && return 0
    sleep 0.2
  done
  return 1
}

# --- who owns the body decides whether it survives ---
# The rule used to be a "PRESERVATION RULE" sentence in the prompt. A nested run
# ignored it and replaced a hand-written description carrying four accepted pre-PR
# review findings (MXTS-81222). The decision is now made in improve-pr-run.sh, and
# on push it turns on ownership: regenerate only a body this hook wrote and nobody
# has edited since, recognised by a recorded git hash.

GH_DIR="$WORK/ghbin"
mkdir -p "$GH_DIR"
cp "$STUB_DIR/claude" "$GH_DIR/claude"
cat > "$GH_DIR/gh" << 'GHSTUB'
#!/usr/bin/env bash
case "$*" in
  *"--json body"*) ;;
  *"--json title"*)
    # Unset _GH_TITLE models an unreadable title.
    [ -n "${_GH_TITLE:-}" ] || exit 1
    printf '%s' "$_GH_TITLE"; exit 0 ;;
  *) exit 1 ;;
esac
[ "${_GH_FAIL:-0}" = "1" ] && exit 1
[ -n "${_GH_SLOW:-}" ] && sleep "$_GH_SLOW"
# The child reads twice on the regenerate path: once to decide, once afterwards to
# record what landed. _GH_BODY_AFTER models the body the nested run just wrote.
if [ -n "${_GH_COUNT_FILE:-}" ]; then
  _n=$(cat "$_GH_COUNT_FILE" 2>/dev/null || echo 0); _n=$((_n + 1))
  printf '%s' "$_n" > "$_GH_COUNT_FILE"
  if [ "$_n" -ge 2 ] && [ -n "${_GH_BODY_AFTER:-}" ]; then
    printf '%s' "$_GH_BODY_AFTER"; exit 0
  fi
fi
printf '%s' "${_GH_BODY:-}"
GHSTUB
chmod +x "$GH_DIR/gh"

HASH_FILE="$REPO/.git/improve-pr-body-bugfix-test-branch.sha"

# run_gh <trigger> — fresh lock and stub PATH, inheriting _GH_* from the caller.
run_gh() {
  rm -rf "$REPO/.git"/improve-pr-*.lock
  ( cd "$REPO" && _CALLS_LOG="$CALLS_LOG" _ARGS_LOG="$ARGS_LOG" PATH="$GH_DIR:$PATH" \
      bash "$SCRIPT" "$1" 2>/dev/null )
}
preserved() { grep -q "NEVER pass \-\-body" "$CALLS_LOG" 2>/dev/null \
              && ! grep -q "write the PR body" "$CALLS_LOG" 2>/dev/null; }
# A rewritten body keeps the template's Default Reviewers text: Buddy invites the reviewers it names.
regenerated() { grep -q "write the PR body" "$CALLS_LOG" 2>/dev/null \
                && grep -q "## Why section.*## How section.*## Verified section.*## Risk section" "$CALLS_LOG" 2>/dev/null \
                && grep -q "### Default Reviewers section.*word for word" "$CALLS_LOG" 2>/dev/null; }
retitled() { grep -q "write a PR title" "$CALLS_LOG" 2>/dev/null \
             && ! grep -q "NEVER pass \-\-title" "$CALLS_LOG" 2>/dev/null; }
from_person() { grep -q "written by a person" "$CALLS_LOG" 2>/dev/null \
                && ! grep -q "from the commits and the diff only" "$CALLS_LOG" 2>/dev/null; }
from_commits() { grep -q "from the commits and the diff only" "$CALLS_LOG" 2>/dev/null \
                 && ! grep -q "written by a person" "$CALLS_LOG" 2>/dev/null; }
title_kept() { grep -q "NEVER pass \-\-title" "$CALLS_LOG" 2>/dev/null \
               && ! grep -q "write a PR title" "$CALLS_LOG" 2>/dev/null; }

echo "improve-pr.sh test suite"
echo "========================"

# 1. push trigger — prompt contains the push-specific preservation rule
echo ""
echo "push with gh absent — preserves, and still delivers the prompt"
> "$CALLS_LOG"
run_hook "$STUB_DIR" push; rc=$?
wait_for_log 10
if [ "$rc" -eq 0 ] && grep -q "NEVER pass \-\-body" "$CALLS_LOG" 2>/dev/null \
   && grep -q "gh pr view --json" "$CALLS_LOG" 2>/dev/null; then
  ok "push with no gh preserves and delivers the prompt"
else
  bad "push with no gh preserves and delivers the prompt (rc=$rc)"
fi

# 2. create trigger — prompt contains the create-specific preservation rule
echo ""
echo "create trigger, gh unreadable — fails safe to title-only and delivers the prompt"
> "$CALLS_LOG"
run_hook "$STUB_DIR" create; rc=$?
wait_for_log 10
if [ "$rc" -eq 0 ] && grep -q "NEVER pass \-\-body" "$CALLS_LOG" 2>/dev/null \
   && ! grep -q "regenerate the body" "$CALLS_LOG" 2>/dev/null \
   && grep -q "gh pr view --json" "$CALLS_LOG" 2>/dev/null; then
  ok "create with an unreadable body fails safe to title-only"
else
  bad "create with an unreadable body fails safe to title-only (rc=$rc)"
fi

# 3. push and create produce distinct prompts
echo ""
echo "the trigger still matters — same body, opposite outcomes"
# Given a body this hook wrote, push refreshes it and create never touches it.
# Not distinguishable without gh any more: with no readable body both preserve,
# which is the point of the fail-safe.
BODY_MINE="## Why
A description written by an earlier run of this hook."
printf '%s' "$BODY_MINE" | git -C "$REPO" hash-object --stdin > "$HASH_FILE"
> "$CALLS_LOG"
_GH_BODY="$BODY_MINE" run_gh push
wait_for_log 10
_push_regen=0; regenerated && _push_regen=1
printf '%s' "$BODY_MINE" | git -C "$REPO" hash-object --stdin > "$HASH_FILE"
> "$CALLS_LOG"
_GH_BODY="$BODY_MINE" run_gh create
wait_for_log 10
_create_preserved=0; preserved && _create_preserved=1
if [ "$_push_regen" -eq 1 ] && [ "$_create_preserved" -eq 1 ]; then
  ok "push refreshes its own body while create preserves it"
else
  bad "push/create differ on an owned body (push_regen=$_push_regen create_preserved=$_create_preserved)"
fi

# 4. default (no argument) falls back to push — shown by refreshing an owned
# body, which is the one thing create never does.
echo ""
echo "default (no argument) falls back to push"
printf '%s' "$BODY_MINE" | git -C "$REPO" hash-object --stdin > "$HASH_FILE"
> "$CALLS_LOG"
rm -rf "$REPO/.git"/improve-pr-*.lock
( cd "$REPO" && _CALLS_LOG="$CALLS_LOG" _GH_BODY="$BODY_MINE" PATH="$GH_DIR:$PATH" \
    bash "$SCRIPT" 2>/dev/null ); rc=$?
wait_for_log 10
if [ "$rc" -eq 0 ] && regenerated; then
  ok "default (no arg) behaves as push, not as create"
else
  bad "default (no arg) behaves as push, not as create (rc=$rc)"
fi

# 5. the dedup lock still suppresses a second run in the same window
echo ""
echo "dedup lock suppresses a second run within the TTL"
> "$CALLS_LOG"
run_hook "$STUB_DIR" push
wait_for_log 10
first_lines=$(wc -l < "$CALLS_LOG")
( cd "$REPO" && _CALLS_LOG="$CALLS_LOG" PATH="$STUB_DIR:$PATH" bash "$SCRIPT" create 2>/dev/null )
sleep 1
second_lines=$(wc -l < "$CALLS_LOG")
if [ "$first_lines" -eq 1 ] && [ "$second_lines" -eq 1 ]; then
  ok "second run within the TTL was suppressed"
else
  bad "second run within the TTL was not suppressed (first=$first_lines second=$second_lines)"
fi

# 6. the launcher must not block on the nested claude run
# PostToolUse fires on every git push; a synchronous nested run stalls the parent
# session for as long as the model takes (~21s median observed in real sessions).
echo ""
echo "launcher returns promptly while the nested claude run is slow"
> "$CALLS_LOG"
export _SLOW_SECS=3
started=$(date +%s)
run_hook "$SLOW_DIR" push; rc=$?
elapsed=$(( $(date +%s) - started ))
if [ "$rc" -eq 0 ] && [ "$elapsed" -lt 2 ]; then
  ok "launcher returned in ${elapsed}s while the nested run takes ${_SLOW_SECS}s"
else
  bad "launcher blocked for ${elapsed}s on a ${_SLOW_SECS}s nested run (rc=$rc)"
fi

# 7. detaching must not drop the work: the prompt still reaches claude
echo ""
echo "detached run still delivers the prompt"
if wait_for_log 15 && grep -q "gh pr view --json" "$CALLS_LOG" 2>/dev/null; then
  ok "detached run delivered the prompt to claude"
else
  bad "detached run never delivered the prompt to claude"
fi

# 7b. the hook requests no reviewers: CODEOWNERS does that when a PR leaves draft, and the
# template's teams requested on every push pulled whole teams onto work in progress.
echo ""
echo "the prompt carries no reviewer step"
if grep -q "gh pr view --json" "$CALLS_LOG" 2>/dev/null && ! grep -q -- "--add-reviewer" "$CALLS_LOG" 2>/dev/null; then
  ok "no --add-reviewer in the prompt"
else
  bad "the prompt must not request reviewers"
fi

# 8. an oversized log is trimmed, and the run still launches
# The trim block runs before the launch under `set -euo pipefail`, so a failure
# there would abort the hook and silently suppress the PR update entirely.
echo ""
echo "oversized log is trimmed and the run still launches"
> "$CALLS_LOG"
rm -rf "$REPO/.git"/improve-pr-*.lock
LOG="$REPO/.git/improve-pr.log"
head -c 300000 /dev/zero | tr '\000' x > "$LOG"
before_bytes=$(wc -c < "$LOG" | tr -d ' ')
run_hook "$STUB_DIR" push; rc=$?
wait_for_log 10
after_bytes=$(wc -c < "$LOG" | tr -d ' ')
if [ "$rc" -eq 0 ] && [ "$before_bytes" -gt 262144 ] && [ "$after_bytes" -lt 262144 ] \
   && grep -q "gh pr view --json" "$CALLS_LOG" 2>/dev/null; then
  ok "oversized log trimmed (${before_bytes}b -> ${after_bytes}b) and the run still launched"
else
  bad "oversized log must trim without suppressing the run (rc=$rc before=$before_bytes after=$after_bytes)"
fi

# 9. a run still in flight holds the lock past the TTL
# Detached, a push returns instantly, so an expired TTL alone would let the next
# push start a second `claude -p` and race `gh pr edit` against the same PR.
echo ""
echo "an in-flight run holds the lock past the TTL"
> "$CALLS_LOG"
rm -rf "$REPO/.git"/improve-pr-*.lock
LOCK="$REPO/.git/improve-pr-bugfix-test-branch.lock"
mkdir -p "$LOCK"
sleep 30 & held_pid=$!
printf '%s' "$held_pid" > "$LOCK/pid"
printf '%s' "$(( $(date +%s) - 120 ))" > "$LOCK/ts"   # TTL long expired
( cd "$REPO" && _CALLS_LOG="$CALLS_LOG" PATH="$STUB_DIR:$PATH" bash "$SCRIPT" push 2>/dev/null )
sleep 1
blocked=0
[ ! -s "$CALLS_LOG" ] && blocked=1
kill "$held_pid" 2>/dev/null; wait "$held_pid" 2>/dev/null
if [ "$blocked" -eq 1 ]; then
  ok "expired TTL + live pid → second run suppressed"
else
  bad "a live in-flight run must still hold the lock (calls=$(wc -l < "$CALLS_LOG"))"
fi

# 10. a dead pid past the TTL does not hold the lock for ever
echo ""
echo "a dead pid past the TTL releases the lock"
> "$CALLS_LOG"
rm -rf "$REPO/.git"/improve-pr-*.lock
mkdir -p "$LOCK"
sleep 0 & dead_pid=$!
wait "$dead_pid" 2>/dev/null
printf '%s' "$dead_pid" > "$LOCK/pid"
printf '%s' "$(( $(date +%s) - 120 ))" > "$LOCK/ts"
( cd "$REPO" && _CALLS_LOG="$CALLS_LOG" PATH="$STUB_DIR:$PATH" bash "$SCRIPT" push 2>/dev/null )
wait_for_log 10
if grep -q "gh pr view --json" "$CALLS_LOG" 2>/dev/null; then
  ok "expired TTL + dead pid → lock released and the run proceeded"
else
  bad "a dead pid must not hold the lock past the TTL"
fi

# 11. the watchdog caps a hung run where `timeout` is unavailable
# macOS ships no `timeout`, so without the watchdog a hung child never dies.
echo ""
echo "watchdog kills a hung run when timeout is unavailable"
> "$CALLS_LOG"
rm -rf "$REPO/.git"/improve-pr-*.lock
HANG_DIR="$WORK/hangbin"
mkdir -p "$HANG_DIR"
cat > "$HANG_DIR/claude" << 'HANGSTUB'
#!/usr/bin/env bash
sleep 60
HANGSTUB
chmod +x "$HANG_DIR/claude"
# A PATH that genuinely has no `timeout`. Listing /usr/bin here would keep
# /usr/bin/timeout reachable on Linux, so `_capped=1` and the watchdog under test
# never runs — while `timeout` reaps the child and the case still reports PASS.
SAFE_BIN="$WORK/safebin"
mkdir -p "$SAFE_BIN"
for _b in bash sh nohup sleep cat date mkdir rm rmdir tail wc git env head tr ls dirname basename; do
  _src=$(command -v "$_b" 2>/dev/null) && ln -sf "$_src" "$SAFE_BIN/$_b"
done
ln -sf "$HANG_DIR/claude" "$SAFE_BIN/claude"
if PATH="$SAFE_BIN" command -v timeout >/dev/null 2>&1; then
  bad "test 11 setup: 'timeout' is still reachable, so the watchdog branch is not under test"
else
( cd "$REPO" && IMPROVE_PR_RUN_TIMEOUT=2 _CALLS_LOG="$CALLS_LOG" PATH="$SAFE_BIN" \
    bash "$SCRIPT" push 2>/dev/null )
hung_pid=$(cat "$REPO/.git"/improve-pr-*.lock/pid 2>/dev/null || echo '')
alive_before=0
[ -n "$hung_pid" ] && kill -0 "$hung_pid" 2>/dev/null && alive_before=1
sleep 6
alive_after=1
{ [ -z "$hung_pid" ] || ! kill -0 "$hung_pid" 2>/dev/null; } && alive_after=0
[ -n "$hung_pid" ] && kill "$hung_pid" 2>/dev/null
if [ "$alive_before" -eq 1 ] && [ "$alive_after" -eq 0 ]; then
  ok "hung run was alive, then reaped by the watchdog (pid=$hung_pid)"
else
  bad "watchdog must reap a hung run (alive_before=$alive_before alive_after=$alive_after pid=$hung_pid)"
fi
fi

echo ""
echo "create with a non-empty body — preserved"
> "$CALLS_LOG"; rm -f "$HASH_FILE"
_GH_BODY="a deliberate description with enough detail to keep" run_gh create; rc=$?
wait_for_log 10
if [ "$rc" -eq 0 ] && preserved; then ok "create preserves a non-empty body"
else bad "create preserves a non-empty body (rc=$rc)"; fi

echo ""
echo "create with a whitespace-only body — regenerated"
> "$CALLS_LOG"; rm -f "$HASH_FILE"
_GH_BODY="   " run_gh create; rc=$?
wait_for_log 10
if [ "$rc" -eq 0 ] && regenerated; then ok "create still generates an empty body"
else bad "create still generates an empty body (rc=$rc)"; fi
# Other tickets' keys would link the PR to them (pr-foreign-key-guard denies the edit).
if grep -q "non-breaking hyphen (U+2011)" "$CALLS_LOG" 2>/dev/null; then
  ok "a generated body keeps other tickets' keys unlinkable"
else bad "a generated body keeps other tickets' keys unlinkable"; fi

echo ""
echo "push with a body of unknown origin — preserved"
> "$CALLS_LOG"; rm -f "$HASH_FILE"
_GH_BODY="hand-written, no hash on record, long enough to count" run_gh push; rc=$?
wait_for_log 10
if [ "$rc" -eq 0 ] && preserved; then ok "push preserves a body it has no record of writing"
else bad "push preserves a body it has no record of writing (rc=$rc)"; fi

echo ""
echo "push with a body this hook wrote and nobody touched — regenerated"
> "$CALLS_LOG"
BODY_OURS="## Summary
- generated earlier"
printf '%s' "$BODY_OURS" | git -C "$REPO" hash-object --stdin > "$HASH_FILE"
_GH_BODY="$BODY_OURS" run_gh push; rc=$?
wait_for_log 10
if [ "$rc" -eq 0 ] && regenerated; then ok "push refreshes its own untouched body"
else bad "push refreshes its own untouched body (rc=$rc)"; fi

echo ""
echo "push with a body edited since this hook wrote it — preserved"
> "$CALLS_LOG"
printf '%s' "$BODY_OURS" | git -C "$REPO" hash-object --stdin > "$HASH_FILE"
_GH_BODY="$BODY_OURS
plus a human note that must survive" run_gh push; rc=$?
wait_for_log 10
if [ "$rc" -eq 0 ] && preserved; then ok "push preserves a body edited after it was generated"
else bad "push preserves a body edited after it was generated (rc=$rc)"; fi

echo ""
echo "regenerating records the hash of what landed"
> "$CALLS_LOG"; rm -f "$HASH_FILE"
# Empty body before, so the child regenerates; the stub then returns the body the
# nested run "wrote", which is what must be hashed for the next push to recognise.
COUNT_FILE="$WORK/ghcount"; : > "$COUNT_FILE"
_GH_COUNT_FILE="$COUNT_FILE" _GH_BODY="" _GH_BODY_AFTER="## Summary
- what the run wrote" run_gh push
wait_for_log 10
for _ in 1 2 3 4 5 6 7 8 9 10; do [ -s "$HASH_FILE" ] && break; sleep 0.5; done
recorded=$(cat "$HASH_FILE" 2>/dev/null || echo '')
expected=$(printf '%s' "## Summary
- what the run wrote" | git -C "$REPO" hash-object --stdin)
if [ -n "$recorded" ] && [ "$recorded" = "$expected" ]; then
  ok "the hash of the generated body is recorded"
else
  bad "the hash of the generated body is recorded (recorded=${recorded:-none} expected=$expected)"
fi

echo ""
echo "a body preserved on create records nothing"
> "$CALLS_LOG"; rm -f "$HASH_FILE"
_GH_BODY="a deliberate description with enough detail to keep" run_gh create
wait_for_log 10
sleep 1
if [ ! -s "$HASH_FILE" ]; then
  ok "the preserve path writes no hash, so a later push keeps preserving"
else
  bad "the preserve path must not record a hash (got $(cat "$HASH_FILE"))"
fi

echo ""
echo "an unreadable body is never regenerated, on either trigger"
# A failed read looks exactly like an empty body. On push, treating it as empty
# handed the run a regenerate instruction while the PR still held a hand-written
# description — the MXTS-81222 loss this file prevents.
for _trigger in push create; do
  > "$CALLS_LOG"; rm -f "$HASH_FILE"
  _GH_FAIL=1 run_gh "$_trigger"; rc=$?
  wait_for_log 10
  if [ "$rc" -eq 0 ] && preserved; then
    ok "$_trigger preserves when gh cannot be read"
  else
    bad "$_trigger preserves when gh cannot be read (rc=$rc)"
  fi
done

echo ""
echo "a slow gh must not block the launcher"
> "$CALLS_LOG"; rm -f "$HASH_FILE"
# hooks.json caps this hook at 10s, which is why every read moved into the child.
_t0=$(date +%s)
_GH_SLOW=5 _GH_BODY="x" run_gh create; rc=$?
_elapsed=$(( $(date +%s) - _t0 ))
if [ "$rc" -eq 0 ] && [ "$_elapsed" -lt 3 ]; then
  ok "launcher returned in ${_elapsed}s despite a 5s gh"
else
  bad "launcher must not wait on gh (rc=$rc elapsed=${_elapsed}s)"
fi

echo ""
echo "a short body: rewritten on create, never on push"
# 39 non-whitespace characters, one under the threshold. On create it was just
# typed by whoever opened the PR, so it is rewritten around its facts. On push its
# author is unknown, and a body someone wrote is never touched, whatever its length.
BODY_39="Closes ABC-1234 after the hotfix, tests okay."
> "$CALLS_LOG"; rm -f "$HASH_FILE"
_GH_BODY="$BODY_39" run_gh create; rc=$?
wait_for_log 10
if [ "$rc" -eq 0 ] && regenerated && from_person; then
  ok "create rewrites a 39-char body and keeps its facts"
else
  bad "create rewrites a 39-char body and keeps its facts (rc=$rc)"
fi
> "$CALLS_LOG"; rm -f "$HASH_FILE"
_GH_BODY="$BODY_39" run_gh push; rc=$?
wait_for_log 10
if [ "$rc" -eq 0 ] && preserved; then
  ok "push keeps a 39-char body someone wrote"
else
  bad "push keeps a 39-char body someone wrote (rc=$rc)"
fi

echo ""
echo "the short-body threshold counts characters, not bytes"
# 19 characters, 57 UTF-8 bytes: a byte count would call it long and keep it.
> "$CALLS_LOG"; rm -f "$HASH_FILE"
_GH_BODY="ログイン後のリダイレクトを修正しました" run_gh create; rc=$?
wait_for_log 10
if [ "$rc" -eq 0 ] && regenerated; then
  ok "a 19-character non-ASCII body counts as short"
else
  bad "a 19-character non-ASCII body counts as short (rc=$rc)"
fi

echo ""
echo "refreshing its own body rebuilds from the commits"
# Keeping every fact of the hook's own earlier body would carry its old Verified
# bullets forward to commits they never covered.
> "$CALLS_LOG"
printf '%s' "$BODY_OURS" | git -C "$REPO" hash-object --stdin > "$HASH_FILE"
_GH_BODY="$BODY_OURS" run_gh push; rc=$?
wait_for_log 10
if [ "$rc" -eq 0 ] && regenerated && from_commits; then
  ok "own body refreshed from the commits, not carried forward"
else
  bad "own body refreshed from the commits, not carried forward (rc=$rc)"
fi

echo ""
echo "a title someone wrote is never changed"
for _trigger in push create; do
  > "$CALLS_LOG"; rm -f "$HASH_FILE"
  _GH_TITLE="ABC-1234: Fix the login redirect" _GH_BODY="" run_gh "$_trigger"; rc=$?
  wait_for_log 10
  if [ "$rc" -eq 0 ] && title_kept; then
    ok "$_trigger keeps a hand-written title"
  else
    bad "$_trigger keeps a hand-written title (rc=$rc)"
  fi
done

echo ""
echo "a title gh filled in from the branch name is rewritten"
for _title in "Bugfix/test branch" "Test branch"; do
  > "$CALLS_LOG"; rm -f "$HASH_FILE"
  _GH_TITLE="$_title" _GH_BODY="a deliberate description with enough detail to keep" run_gh create; rc=$?
  wait_for_log 10
  if [ "$rc" -eq 0 ] && retitled && preserved; then
    ok "placeholder title '$_title' is rewritten, the body is kept"
  else
    bad "placeholder title '$_title' is rewritten, the body is kept (rc=$rc)"
  fi
done

echo ""
echo "an unreadable title is kept"
> "$CALLS_LOG"; rm -f "$HASH_FILE"
_GH_BODY="" run_gh create; rc=$?
wait_for_log 10
if [ "$rc" -eq 0 ] && title_kept && regenerated; then
  ok "unreadable title kept while the empty body is written"
else
  bad "unreadable title kept while the empty body is written (rc=$rc)"
fi

echo ""
echo "the nested run carries no MCP servers and no skills"
# It reads a PR and rewrites the title with `gh`; left alone it loaded 24 MCP servers
# (Playwright and SQLcl each a local process) and 77 skills, ~12k cache-write tokens
# per push. Asserted on both paths because each exec's claude separately.
for _case in preserve regenerate; do
  > "$CALLS_LOG"; > "$ARGS_LOG"; rm -f "$HASH_FILE"
  if [ "$_case" = "preserve" ]; then
    _GH_BODY="a hand-written description that is long enough to keep" run_gh create >/dev/null
  else
    _GH_BODY="" run_gh push >/dev/null
  fi
  wait_for_log 10
  _deadline=$(( $(date +%s) + 10 ))
  while [ "$(date +%s)" -lt "$_deadline" ] && [ ! -s "$ARGS_LOG" ]; do sleep 0.2; done
  if grep -qxF -- "--strict-mcp-config" "$ARGS_LOG" 2>/dev/null \
     && grep -qxF -- "--disable-slash-commands" "$ARGS_LOG" 2>/dev/null; then
    ok "$_case path passes --strict-mcp-config and --disable-slash-commands"
  else
    bad "$_case path must slim the nested run (flags: $(grep '^--' "$ARGS_LOG" 2>/dev/null | tr '\n' ' '))"
  fi
done

echo ""
echo "the nested run keeps OAuth-capable auth"
# --bare would also drop hooks and CLAUDE.md, but reads auth strictly from
# ANTHROPIC_API_KEY or an apiKeyHelper -- never OAuth or the keychain -- so on a
# subscription login it would silently stop working.
> "$ARGS_LOG"; rm -f "$HASH_FILE"
_GH_BODY="a hand-written description that is long enough to keep" run_gh create >/dev/null
_deadline=$(( $(date +%s) + 10 ))
while [ "$(date +%s)" -lt "$_deadline" ] && [ ! -s "$ARGS_LOG" ]; do sleep 0.2; done
if [ -s "$ARGS_LOG" ] && ! grep -qxF -- "--bare" "$ARGS_LOG" 2>/dev/null; then
  ok "nested run does not pass --bare"
else
  bad "nested run must not pass --bare"
fi

echo ""
echo "the run follows the command's cd into another checkout"
# PostToolUse runs in the session's directory. `cd other-repo && gh pr create` used to
# make the hook check the session's own branch, find no PR there and stop.
REPO2="$WORK/repo2"
mkdir -p "$REPO2" "$WORK/elsewhere"
git -C "$REPO2" init --quiet --initial-branch=feature/other-repo
git -C "$REPO2" commit --quiet --allow-empty -m init
REPO_REAL=$(cd "$REPO" && pwd -P)
REPO2_REAL=$(cd "$REPO2" && pwd -P)
PWD_LOG="$WORK/pwd.log"

# run_json <trigger> <hook-cwd> <json-cwd> <command> [bash] — feeds hook input on stdin.
run_json() {
  local bash_bin="${5:-bash}"
  rm -rf "$WORK"/*/.git/improve-pr-*.lock
  > "$PWD_LOG"
  jq -n --arg d "$3" --arg c "$4" '{cwd: $d, tool_input: {command: $c}}' \
    | ( cd "$2" && _PWD_LOG="$PWD_LOG" PATH="$STUB_DIR:$PATH" "$bash_bin" "$SCRIPT" "$1" 2>/dev/null )
  local deadline=$(( $(date +%s) + 10 ))
  while [ "$(date +%s)" -lt "$deadline" ] && [ ! -s "$PWD_LOG" ]; do sleep 0.2; done
  cat "$PWD_LOG" 2>/dev/null | head -1
}
expect_dir() {
  if [ "$1" = "$2" ]; then ok "$3"; else bad "$3 (ran in '${1:-nowhere}', want '$2')"; fi
}

expect_dir "$(run_json create "$REPO" "$WORK/elsewhere" "cd \"$REPO2\" && gh pr create --draft --title x")" \
  "$REPO2_REAL" "absolute cd before gh pr create"
expect_dir "$(run_json push "$REPO" "$WORK" "cd repo2 && git push -u origin HEAD")" \
  "$REPO2_REAL" "relative cd resolved against the input cwd"
expect_dir "$(run_json push "$WORK/elsewhere" "$REPO" "git -C \"$REPO2\" push")" \
  "$REPO2_REAL" "git -C on the push itself"
REPO3="$WORK/repo with space"
mkdir -p "$REPO3"
git -C "$REPO3" init --quiet --initial-branch=feature/spaced
git -C "$REPO3" commit --quiet --allow-empty -m init
REPO3_REAL=$(cd "$REPO3" && pwd -P)
expect_dir "$(run_json push "$WORK/elsewhere" "$REPO" "git -C \"$REPO3\" push")" \
  "$REPO3_REAL" "quoted git -C path with a space"
expect_dir "$(run_json create "$WORK/elsewhere" "$WORK" "cd 'repo with space' && gh pr create")" \
  "$REPO3_REAL" "quoted cd path with a space"
expect_dir "$(run_json create "$WORK/elsewhere" "$WORK" "cd repo2 && cd .. && cd 'repo2' && gh pr create")" \
  "$REPO2_REAL" "chained cds replay in order"
expect_dir "$(run_json create "$WORK/elsewhere" "$REPO" "gh pr create --fill && cd \"$REPO2\"")" \
  "$REPO_REAL" "a cd after the trigger is ignored"
expect_dir "$(run_json create "$WORK/elsewhere" "$REPO" "gh pr create --fill")" \
  "$REPO_REAL" "no cd runs in the input cwd"
expect_dir "$(run_json create "$REPO" "$WORK/elsewhere" 'cd "$X" && gh pr create')" \
  "$REPO_REAL" "an unresolvable cd leaves the hook where it started"
if [ -x /bin/bash ]; then
  expect_dir "$(run_json create "$REPO" "$WORK/elsewhere" "cd \"$REPO2\" && gh pr create" /bin/bash)" \
    "$REPO2_REAL" "works under the system bash ($(/bin/bash -c 'echo $BASH_VERSION'))"
fi

echo ""
echo "Results: ${pass}/$((pass + fail)) passed"
[ "$fail" -eq 0 ]
