#!/usr/bin/env bash
# Tests for endpoint-change-guard.py.
#
# The hook is PreToolUse on Edit|Write|MultiEdit. It always exits 0; the
# allow/deny decision travels in stdout (empty = allow, JSON envelope = deny).
# These tests assert on that stdout by PARSING it with a resolved Python 3
# interpreter (never grep on a JSON-key substring — a broken envelope would
# pass a grep).
set -euo pipefail

# Resolve a Python 3 interpreter (python3 → python → py -3) by execution so the
# Windows Store-alias stub is rejected; run via "${PY_CMD[@]}" (Windows Git Bash).
resolve_python() {
  local _cand
  for _cand in python3 python "py -3"; do
    if $_cand -c 'import sys; sys.exit(0 if sys.version_info[0] == 3 else 1)' >/dev/null 2>&1; then
      printf '%s\n' "$_cand"; return 0
    fi
  done
  return 1
}
PY=$(resolve_python) || { echo "no Python 3 found (tried python3, python, py -3)" >&2; exit 1; }
read -r -a PY_CMD <<< "$PY"

HOOK="$(cd "$(dirname "$0")/.." && pwd)/endpoint-change-guard.py"
WORK="$(mktemp -d)"
trap 'rm -rf "$WORK"' EXIT

# A throwaway git repo on a known branch, used as CLAUDE_PROJECT_DIR. An empty
# commit gives the branch a resolvable HEAD (an unborn branch makes
# `git rev-parse --abbrev-ref HEAD` ambiguous, which the hook fail-opens on).
git -C "$WORK" init -q
git -C "$WORK" config user.email "test@example.com"
git -C "$WORK" config user.name "test"
git -C "$WORK" commit -q --allow-empty -m init
git -C "$WORK" branch -M feature/MXTS-1
mkdir -p "$WORK/.claude"

run() {  # reads stdin json on fd0, echoes hook stdout
  CLAUDE_PROJECT_DIR="$WORK" "${PY_CMD[@]}" "$HOOK"
}

assert_deny() {  # assert_deny <json-payload>
  local out
  out="$(printf '%s' "$1" | run)"
  printf '%s' "$out" | "${PY_CMD[@]}" -c '
import json, sys
d = json.load(sys.stdin)
dec = d["hookSpecificOutput"]["permissionDecision"]
assert dec == "deny", "expected deny, got %r" % dec
assert d["hookSpecificOutput"]["permissionDecisionReason"].strip(), "empty reason"
'
}

assert_allow() {  # assert_allow <json-payload> ; stdout must be empty
  local out
  out="$(printf '%s' "$1" | run)"
  "${PY_CMD[@]}" -c '
import sys
data = sys.argv[1]
assert data.strip() == "", "expected allow (empty stdout), got: %r" % data
' "$out"
}

mkpayload() {  # mkpayload <tool> <file_path> <old_or_content_text>
  "${PY_CMD[@]}" -c '
import json, sys
tool, fp, txt = sys.argv[1], sys.argv[2], sys.argv[3]
key = "content" if tool == "Write" else "old_string"
print(json.dumps({"tool_name": tool, "tool_input": {"file_path": fp, key: txt}}))
' "$1" "$2" "$3"
}

CONTROLLER="$WORK/src/main/java/com/x/ReservationController.java"
DTO="$WORK/src/main/java/com/x/dto/ReservationRequest.java"
PLAIN="$WORK/src/main/java/com/x/ReservationService.java"

# 1. Controller with @GetMapping, no marker -> deny.
assert_deny "$(mkpayload Edit "$CONTROLLER" '@GetMapping("/reservations/{id}")
  public Reservation get(')"

# 2. DTO under /dto/ with @JsonProperty -> deny.
assert_deny "$(mkpayload Write "$DTO" 'public class ReservationRequest { @JsonProperty String guestId; }')"

# 3. Plain service file, no annotation -> allow.
assert_allow "$(mkpayload Edit "$PLAIN" 'int total = a + b;')"

# 4. Controller body edit, no mapping/param annotation in old_string -> allow.
assert_allow "$(mkpayload Edit "$CONTROLLER" 'log.info("hello");')"

# 5. Marker matching the current branch -> allow.
printf 'feature/MXTS-1' > "$WORK/.claude/.endpoint-impact-ok"
assert_allow "$(mkpayload Edit "$CONTROLLER" '@GetMapping("/reservations/{id}")')"

# 6. Stale marker (different branch) -> deny.
printf 'feature/MXTS-999' > "$WORK/.claude/.endpoint-impact-ok"
assert_deny "$(mkpayload Edit "$CONTROLLER" '@GetMapping("/reservations/{id}")')"
rm -f "$WORK/.claude/.endpoint-impact-ok"

# --- MXTS-79455: /resource/ over-match + src/test/** exemption ---------------
RES_PLAIN="$WORK/src/main/java/com/x/resource/ReservationHelper.java"
RES_SUFFIX="$WORK/src/main/java/com/x/resource/ReservationResource.java"
TEST_DTO="$WORK/src/test/java/com/x/dto/ReservationRequest.java"

# 6a. Plain file under a /resource/ package, no Resource/Dto name suffix and no
#     serialization annotation -> allow (the /resource/ path segment no longer
#     classifies on its own).
assert_allow "$(mkpayload Edit "$RES_PLAIN" 'int total = a + b;')"

# 6b. But a *Resource.java under /resource/ still classifies by NAME suffix -> deny.
assert_deny "$(mkpayload Write "$RES_SUFFIX" 'public class ReservationResource { String id; }')"

# 6c. A contract-shaped fixture under src/test/** is never the shipped contract
#     -> allow, even under /dto/ with @JsonProperty.
assert_allow "$(mkpayload Write "$TEST_DTO" 'public class ReservationRequest { @JsonProperty String guestId; }')"

# 7. Malformed stdin -> fail open (allow, exit 0).
printf 'not json' | run >/dev/null

# 8. Detached HEAD, no marker -> fail open (allow), since it's not a real branch.
git -C "$WORK" checkout -q --detach
assert_allow "$(mkpayload Edit "$CONTROLLER" '@GetMapping("/reservations/{id}")')"
git -C "$WORK" checkout -q feature/MXTS-1

echo "PASS"
