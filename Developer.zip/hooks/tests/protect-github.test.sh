#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SCRIPT="$SCRIPT_DIR/../protect-github.sh"
FIXTURES="$SCRIPT_DIR/fixtures"

RED='\033[0;31m'
GREEN='\033[0;32m'
NC='\033[0m'
pass=0
fail=0

is_deny() {
  printf '%s' "$1" | python3 -c "
import json, sys
try:
    d = json.load(sys.stdin)
except Exception:
    sys.exit(2)
out = d.get('hookSpecificOutput') or {}
sys.exit(0 if out.get('permissionDecision') == 'deny' else 1)
" 2>/dev/null
}

echo "protect-github.sh test suite"
echo "============================="

echo ""
echo "shellcheck on script"
if ! command -v shellcheck >/dev/null 2>&1; then
  printf "  SKIP shellcheck not installed\n"
elif shellcheck "$SCRIPT" 2>/dev/null; then
  printf "  ${GREEN}PASS${NC} shellcheck passes\n"
  pass=$((pass + 1))
else
  printf "  ${RED}FAIL${NC} shellcheck reported issues\n"
  fail=$((fail + 1))
fi

echo ""
echo "Write to .github/CODEOWNERS — should deny"
actual=$(bash "$SCRIPT" < "$FIXTURES/write-github-codeowners.json" 2>/dev/null)
if is_deny "$actual"; then
  printf "  ${GREEN}PASS${NC} Write CODEOWNERS → deny\n"
  pass=$((pass + 1))
else
  printf "  ${RED}FAIL${NC} expected deny, got: %s\n" "$actual"
  fail=$((fail + 1))
fi

echo ""
echo "Edit to .github/pull_request_template.md — should deny"
actual=$(bash "$SCRIPT" < "$FIXTURES/edit-github-pr-template.json" 2>/dev/null)
if is_deny "$actual"; then
  printf "  ${GREEN}PASS${NC} Edit pull_request_template.md → deny\n"
  pass=$((pass + 1))
else
  printf "  ${RED}FAIL${NC} expected deny, got: %s\n" "$actual"
  fail=$((fail + 1))
fi

echo ""
echo "Write to .github/workflows/auto-assign-labels.yml — should deny"
actual=$(bash "$SCRIPT" < "$FIXTURES/write-github-workflow.json" 2>/dev/null)
if is_deny "$actual"; then
  printf "  ${GREEN}PASS${NC} Write auto-assign-labels.yml → deny\n"
  pass=$((pass + 1))
else
  printf "  ${RED}FAIL${NC} expected deny, got: %s\n" "$actual"
  fail=$((fail + 1))
fi

echo ""
echo "Write to src/Main.java — should allow (no deny)"
actual=$(bash "$SCRIPT" < "$FIXTURES/write-src-file.json" 2>/dev/null)
if ! is_deny "$actual"; then
  printf "  ${GREEN}PASS${NC} Write src/Main.java → allow\n"
  pass=$((pass + 1))
else
  printf "  ${RED}FAIL${NC} Write to unrelated file should not be denied\n"
  fail=$((fail + 1))
fi

echo ""
echo "Read tool on .github/CODEOWNERS — should allow (only Write/Edit blocked)"
actual=$(printf '{"tool_name":"Read","tool_input":{"file_path":"/repo/.github/CODEOWNERS"}}' \
  | bash "$SCRIPT" 2>/dev/null)
if ! is_deny "$actual"; then
  printf "  ${GREEN}PASS${NC} Read CODEOWNERS → allow\n"
  pass=$((pass + 1))
else
  printf "  ${RED}FAIL${NC} Read tool should not be denied\n"
  fail=$((fail + 1))
fi

echo ""
echo "MultiEdit to .github/CODEOWNERS — should deny (MultiEdit bypass prevention)"
actual=$(bash "$SCRIPT" < "$FIXTURES/multiedit-github-codeowners.json" 2>/dev/null)
if is_deny "$actual"; then
  printf "  ${GREEN}PASS${NC} MultiEdit CODEOWNERS → deny\n"
  pass=$((pass + 1))
else
  printf "  ${RED}FAIL${NC} expected deny, got: %s\n" "$actual"
  fail=$((fail + 1))
fi

echo ""
echo "Write to /repo/not-a-github/CODEOWNERS — should allow (not inside .github/)"
actual=$(printf '{"tool_name":"Write","tool_input":{"file_path":"/repo/not-a-github/CODEOWNERS","content":"x"}}' \
  | bash "$SCRIPT" 2>/dev/null)
if ! is_deny "$actual"; then
  printf "  ${GREEN}PASS${NC} Write not-a-github/CODEOWNERS → allow\n"
  pass=$((pass + 1))
else
  printf "  ${RED}FAIL${NC} Should not deny files outside .github/\n"
  fail=$((fail + 1))
fi

echo ""
total=$((pass + fail))
echo "Results: ${pass}/${total} passed"
[ "$fail" -eq 0 ]
