#!/usr/bin/env bash
# Tests for pr-ready-gate.py
# Usage: bash tests/pr-ready-gate.test.sh
#
# `gh` is stubbed on PATH so every branch is reachable without a live PR. The
# allow path was additionally verified against real PRs (#371, #374, both green
# with Copilot's threads resolved) and the fail-closed path against a
# nonexistent PR number.
set -uo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SCRIPT="$SCRIPT_DIR/../pr-ready-gate.py"

resolve_python() {
  local _cand
  for _cand in python3 python "py -3"; do
    if $_cand -c 'import sys; sys.exit(0 if sys.version_info[0] == 3 else 1)' >/dev/null 2>&1; then
      printf '%s\n' "$_cand"; return 0
    fi
  done
  return 1
}
PY=$(resolve_python) || { echo "no Python 3 found (tried python3, python, py -3)" >&2; exit 1; }
read -r -a PY_CMD <<< "$PY"

RED='\033[0;31m'; GREEN='\033[0;32m'; NC='\033[0m'
pass=0; fail=0

STUB_DIR=$(mktemp -d)
trap 'rm -rf "$STUB_DIR"' EXIT

# A `gh` that answers from files the cases write, and records its argv so the
# pass-through of the caller's selector and --repo can be asserted.
cat > "$STUB_DIR/gh" <<'STUB'
#!/usr/bin/env bash
printf '%s\n' "$*" >> "$GH_STUB_DIR/argv.log"
for a in "$@"; do
  if [ "$a" = "graphql" ]; then
    [ -s "$GH_STUB_DIR/gql.rc" ] && exit "$(cat "$GH_STUB_DIR/gql.rc")"
    cat "$GH_STUB_DIR/gql.json"; exit 0
  fi
done
[ -s "$GH_STUB_DIR/view.rc" ] && { echo "stub: view failed" >&2; exit "$(cat "$GH_STUB_DIR/view.rc")"; }
cat "$GH_STUB_DIR/view.json"; exit 0
STUB
chmod +x "$STUB_DIR/gh"
export GH_STUB_DIR="$STUB_DIR"

reset_stub() {
  : > "$STUB_DIR/argv.log"
  : > "$STUB_DIR/view.rc"
  : > "$STUB_DIR/gql.rc"
  printf '{"number":42,"url":"https://github.com/AcmeOrg/acme-repo/pull/42"}\n' > "$STUB_DIR/view.json"
  printf '%s\n' "$(build_pr "$@")" > "$STUB_DIR/gql.json"
}

# build_pr <checks-json> <reviews-json> <threads-json>
build_pr() {
  "${PY_CMD[@]}" -c "
import json, sys
checks, reviews, threads = sys.argv[1], sys.argv[2], sys.argv[3]
pr = {
  'isDraft': True,
  'reviews': {'nodes': json.loads(reviews)},
  'reviewThreads': {'nodes': json.loads(threads)},
  'commits': {'nodes': [{'commit': {'statusCheckRollup':
      ({'contexts': {'nodes': json.loads(checks)}} if checks != 'null' else None)}}]},
}
print(json.dumps({'data': {'repository': {'pullRequest': pr}}}))
" "$1" "$2" "$3"
}

GREEN_CHECKS='[{"__typename":"CheckRun","name":"build","status":"COMPLETED","conclusion":"SUCCESS"}]'
COPILOT_REVIEW='[{"author":{"login":"copilot-pull-request-reviewer"}}]'
NO_THREADS='[]'
RESOLVED_THREAD='[{"isResolved":true,"comments":{"nodes":[{"author":{"login":"copilot-pull-request-reviewer"}}]}}]'
OPEN_THREAD='[{"isResolved":false,"comments":{"nodes":[{"author":{"login":"copilot-pull-request-reviewer"}}]}}]'

# run_gate <command> -> prints stdout of the hook
run_gate() {
  printf '{"tool_name":"Bash","tool_input":{"command":%s}}' "$("${PY_CMD[@]}" -c 'import json,sys;print(json.dumps(sys.argv[1]))' "$1")" \
    | PATH="$STUB_DIR:$PATH" "${PY_CMD[@]}" "$SCRIPT" 2>/dev/null
}

is_deny() {
  printf '%s' "$1" | "${PY_CMD[@]}" -c "
import json,sys
try: d=json.load(sys.stdin)
except Exception: sys.exit(2)
sys.exit(0 if (d.get('hookSpecificOutput') or {}).get('permissionDecision')=='deny' else 1)
" 2>/dev/null
}
reason() {
  printf '%s' "$1" | "${PY_CMD[@]}" -c "
import json,sys
try: d=json.load(sys.stdin)
except Exception: sys.exit(0)
print((d.get('hookSpecificOutput') or {}).get('permissionDecisionReason',''))
" 2>/dev/null
}

expect_allow() { # <label> <stdout>
  if [ -z "$2" ]; then printf "  ${GREEN}PASS${NC} %s\n" "$1"; pass=$((pass+1));
  else printf "  ${RED}FAIL${NC} %s (expected allow, got %s)\n" "$1" "$2"; fail=$((fail+1)); fi
}
expect_deny() { # <label> <stdout> <substring>
  if is_deny "$2" && reason "$2" | grep -Fq -- "$3"; then
    printf "  ${GREEN}PASS${NC} %s\n" "$1"; pass=$((pass+1))
  else printf "  ${RED}FAIL${NC} %s (got %s)\n" "$1" "$2"; fail=$((fail+1)); fi
}

echo "the gate lets settled work through"
reset_stub "$GREEN_CHECKS" "$COPILOT_REVIEW" "$RESOLVED_THREAD"
expect_allow "green CI + Copilot reviewed + threads resolved → allow" "$(run_gate 'gh pr ready 42')"

reset_stub "$GREEN_CHECKS" "$COPILOT_REVIEW" "$NO_THREADS"
expect_allow "Copilot reviewed with no findings → allow" "$(run_gate 'gh pr ready 42')"

echo ""
echo "the gate blocks work that has not settled"
reset_stub "$GREEN_CHECKS" "$COPILOT_REVIEW" "$OPEN_THREAD"
expect_deny "unresolved Copilot thread → deny naming the count" \
  "$(run_gate 'gh pr ready 42')" "1 unresolved Copilot thread"

reset_stub "$GREEN_CHECKS" '[]' "$NO_THREADS"
expect_deny "no Copilot review → deny" "$(run_gate 'gh pr ready 42')" "Copilot has not reviewed"

reset_stub "$GREEN_CHECKS" '[{"author":{"login":"some-human"}}]' "$NO_THREADS"
expect_deny "only a human review → deny (Copilot is the required signal)" \
  "$(run_gate 'gh pr ready 42')" "Copilot has not reviewed"

reset_stub 'null' "$COPILOT_REVIEW" "$NO_THREADS"
expect_deny "no check runs at all → deny" "$(run_gate 'gh pr ready 42')" "no check runs"

reset_stub '[]' "$COPILOT_REVIEW" "$NO_THREADS"
expect_deny "empty check context list → deny" "$(run_gate 'gh pr ready 42')" "no check runs"

reset_stub '[{"__typename":"CheckRun","name":"build","status":"COMPLETED","conclusion":"FAILURE"}]' \
  "$COPILOT_REVIEW" "$NO_THREADS"
expect_deny "failing check → deny naming it" "$(run_gate 'gh pr ready 42')" "build (FAILURE)"

# A run still in progress is not green. Treating IN_PROGRESS as success would
# open the gate in the window the gate exists for.
reset_stub '[{"__typename":"CheckRun","name":"build","status":"IN_PROGRESS","conclusion":null}]' \
  "$COPILOT_REVIEW" "$NO_THREADS"
expect_deny "still-running check → deny" "$(run_gate 'gh pr ready 42')" "build (IN_PROGRESS)"

reset_stub '[{"__typename":"StatusContext","context":"legacy/ci","state":"FAILURE"}]' \
  "$COPILOT_REVIEW" "$NO_THREADS"
expect_deny "legacy status context failure → deny" "$(run_gate 'gh pr ready 42')" "legacy/ci (FAILURE)"

# A human's unresolved thread is somebody else's conversation, not this gate's.
reset_stub "$GREEN_CHECKS" "$COPILOT_REVIEW" \
  '[{"isResolved":false,"comments":{"nodes":[{"author":{"login":"some-human"}}]}}]'
expect_allow "unresolved HUMAN thread → allow (only Copilot threads gate)" "$(run_gate 'gh pr ready 42')"

echo ""
echo "the gate stays out of the way where nothing is exposed"
reset_stub "$GREEN_CHECKS" '[]' "$NO_THREADS"
expect_allow "--undo converts to draft → allow without consulting gh" "$(run_gate 'gh pr ready 42 --undo')"
if [ ! -s "$STUB_DIR/argv.log" ]; then
  printf "  ${GREEN}PASS${NC} --undo makes no gh call at all\n"; pass=$((pass+1))
else printf "  ${RED}FAIL${NC} --undo must not call gh (log=%s)\n" "$(cat "$STUB_DIR/argv.log")"; fail=$((fail+1)); fi

reset_stub "$GREEN_CHECKS" '[]' "$NO_THREADS"
expect_allow "--help → allow" "$(run_gate 'gh pr ready --help')"

reset_stub "$GREEN_CHECKS" '[]' "$NO_THREADS"
expect_allow "a command merely mentioning the phrase → allow" \
  "$(run_gate 'grep -rn "gh pr ready" plugins/')"

reset_stub "$GREEN_CHECKS" '[]' "$NO_THREADS"
out=$(printf '{"tool_name":"Read","tool_input":{"file_path":"/tmp/x"}}' \
  | PATH="$STUB_DIR:$PATH" "${PY_CMD[@]}" "$SCRIPT" 2>/dev/null)
expect_allow "non-Bash tool → allow" "$out"

echo ""
echo "the gate fails closed when it cannot see"
reset_stub "$GREEN_CHECKS" "$COPILOT_REVIEW" "$NO_THREADS"
echo 1 > "$STUB_DIR/view.rc"
expect_deny "gh pr view fails → deny" "$(run_gate 'gh pr ready 42')" "fails closed"

reset_stub "$GREEN_CHECKS" "$COPILOT_REVIEW" "$NO_THREADS"
echo 1 > "$STUB_DIR/gql.rc"
expect_deny "GraphQL call fails → deny" "$(run_gate 'gh pr ready 42')" "fails closed"

reset_stub "$GREEN_CHECKS" "$COPILOT_REVIEW" "$NO_THREADS"
printf 'not json\n' > "$STUB_DIR/gql.json"
expect_deny "unparseable API response → deny" "$(run_gate 'gh pr ready 42')" "fails closed"

reset_stub "$GREEN_CHECKS" "$COPILOT_REVIEW" "$NO_THREADS"
printf '{"number":42}\n' > "$STUB_DIR/view.json"
expect_deny "pull request identity missing a url → deny" "$(run_gate 'gh pr ready 42')" "fails closed"

# The harness only fires this hook for a `gh pr ready` command, so a payload the
# hook cannot read is most likely one of those. Allowing would have been the one
# bypass in an otherwise closed gate. Found by Copilot on PR #377.
reset_stub "$GREEN_CHECKS" "$COPILOT_REVIEW" "$NO_THREADS"
bad_payload_out=$(printf 'not json at all' | PATH="$STUB_DIR:$PATH" "${PY_CMD[@]}" "$SCRIPT" 2>/dev/null)
expect_deny "unreadable hook payload → deny" "$bad_payload_out" "fails closed"

reset_stub "$GREEN_CHECKS" "$COPILOT_REVIEW" "$NO_THREADS"
empty_payload_out=$(printf '' | PATH="$STUB_DIR:$PATH" "${PY_CMD[@]}" "$SCRIPT" 2>/dev/null)
expect_deny "empty hook payload → deny" "$empty_payload_out" "fails closed"

# No gh on PATH at all. The interpreter is invoked by absolute path, because an
# empty PATH would otherwise stop `python3` itself from resolving — the hook
# would never run and the empty output would read as an allow.
reset_stub "$GREEN_CHECKS" "$COPILOT_REVIEW" "$NO_THREADS"
EMPTY_BIN=$(mktemp -d)
PY_ABS=$("${PY_CMD[@]}" -c 'import sys; print(sys.executable)')
nogh_out=$(printf '{"tool_name":"Bash","tool_input":{"command":"gh pr ready 42"}}' \
  | PATH="$EMPTY_BIN" "$PY_ABS" "$SCRIPT" 2>/dev/null)
rm -rf "$EMPTY_BIN"
expect_deny "gh missing from PATH → deny" "$nogh_out" "fails closed"

echo ""
echo "the caller's own target is what gets checked"
reset_stub "$GREEN_CHECKS" "$COPILOT_REVIEW" "$NO_THREADS"
run_gate 'gh pr ready 77 --repo AcmeOrg/other' >/dev/null
if grep -q -- 'pr view 77 --repo AcmeOrg/other' "$STUB_DIR/argv.log"; then
  printf "  ${GREEN}PASS${NC} selector and --repo passed through to gh pr view\n"; pass=$((pass+1))
else printf "  ${RED}FAIL${NC} passthrough missing (log=%s)\n" "$(cat "$STUB_DIR/argv.log")"; fail=$((fail+1)); fi

# gh also accepts the attached forms. Both start with `-`, so a loop matching
# only the separated pair drops them and gh resolves a PR from the hook's own
# cwd instead — an unrelated PR's green CI would open the gate. Found in the
# pre-PR review of this branch.
reset_stub "$GREEN_CHECKS" "$COPILOT_REVIEW" "$NO_THREADS"
run_gate 'gh pr ready 77 --repo=AcmeOrg/other' >/dev/null
if grep -q -- 'pr view 77 --repo AcmeOrg/other' "$STUB_DIR/argv.log"; then
  printf "  ${GREEN}PASS${NC} --repo=owner/name attached form passed through\n"; pass=$((pass+1))
else printf "  ${RED}FAIL${NC} --repo= form dropped (log=%s)\n" "$(cat "$STUB_DIR/argv.log")"; fail=$((fail+1)); fi

reset_stub "$GREEN_CHECKS" "$COPILOT_REVIEW" "$NO_THREADS"
run_gate 'gh pr ready 77 -RAcmeOrg/other' >/dev/null
if grep -q -- 'pr view 77 --repo AcmeOrg/other' "$STUB_DIR/argv.log"; then
  printf "  ${GREEN}PASS${NC} -Rowner/name attached form passed through\n"; pass=$((pass+1))
else printf "  ${RED}FAIL${NC} -R attached form dropped (log=%s)\n" "$(cat "$STUB_DIR/argv.log")"; fail=$((fail+1)); fi

reset_stub "$GREEN_CHECKS" "$COPILOT_REVIEW" "$NO_THREADS"
run_gate 'gh pr ready' >/dev/null
if grep -q -- 'pr view --json' "$STUB_DIR/argv.log"; then
  printf "  ${GREEN}PASS${NC} no selector → gh resolves the current branch's PR\n"; pass=$((pass+1))
else printf "  ${RED}FAIL${NC} bare invocation must still call view (log=%s)\n" "$(cat "$STUB_DIR/argv.log")"; fail=$((fail+1)); fi

echo ""
total=$((pass + fail))
echo "Results: ${pass}/${total} passed"
[ "$fail" -eq 0 ]
