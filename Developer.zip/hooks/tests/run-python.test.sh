#!/usr/bin/env bash
# Tests for hooks/run-python.sh — the reusable Python 3 launcher.
set -uo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
LAUNCHER="$SCRIPT_DIR/../run-python.sh"

RED='\033[0;31m'
GREEN='\033[0;32m'
NC='\033[0m'
pass=0
fail=0

# A real Python 3, captured before we start mangling PATH in individual tests.
REAL_PY="$(command -v python3 || true)"

ok()   { printf "  ${GREEN}PASS${NC} %s\n" "$1"; pass=$((pass + 1)); }
bad()  { printf "  ${RED}FAIL${NC} %s\n" "$1"; fail=$((fail + 1)); }

WORK="$(mktemp -d)"
trap 'rm -rf "$WORK"' EXIT
printf 'import sys\nprint("args:" + ",".join(sys.argv[1:]))\n' > "$WORK/echo.py"

echo "run-python.sh test suite"
echo "========================"

# 1. Resolves a Python 3 and runs the script, forwarding arguments.
echo ""
echo "Resolves Python 3 and forwards arguments"
out="$(bash "$LAUNCHER" "$WORK/echo.py" alpha beta 2>/dev/null)"; rc=$?
if [ "$rc" -eq 0 ] && [ "$out" = "args:alpha,beta" ]; then
  ok "runs script and forwards args"
else
  bad "runs script and forwards args (rc=$rc out=$out)"
fi

# 2. No interpreter on PATH → exit 127 with a clear message.
echo ""
echo "No Python on PATH → fails closed with exit 127"
NO_PY="$(mktemp -d)"
err="$(PATH="$NO_PY" /bin/bash "$LAUNCHER" "$WORK/echo.py" 2>&1)"; rc=$?
rm -rf "$NO_PY"
if [ "$rc" -eq 127 ] && printf '%s' "$err" | grep -q "no Python 3 interpreter found"; then
  ok "missing interpreter exits 127 with message"
else
  bad "missing interpreter exits 127 with message (rc=$rc err=$err)"
fi

# 3. Windows Store-alias simulation: a no-op `python3` stub that the probe must
#    reject, falling through to a working `python`. This is the core fix.
echo ""
echo "Skips a non-functional python3 (Store-alias) and uses python"
if [ -n "$REAL_PY" ]; then
  STUB="$(mktemp -d)"
  # `python3` mimics the Store alias: prints nothing, exits non-zero.
  printf '#!/usr/bin/env bash\nexit 9\n' > "$STUB/python3"
  # `python` delegates to the real interpreter.
  printf '#!/usr/bin/env bash\nexec "%s" "$@"\n' "$REAL_PY" > "$STUB/python"
  chmod +x "$STUB/python3" "$STUB/python"
  out="$(PATH="$STUB:$PATH" bash "$LAUNCHER" "$WORK/echo.py" gamma 2>/dev/null)"; rc=$?
  rm -rf "$STUB"
  if [ "$rc" -eq 0 ] && [ "$out" = "args:gamma" ]; then
    ok "rejects no-op python3 stub, falls through to python"
  else
    bad "rejects no-op python3 stub, falls through to python (rc=$rc out=$out)"
  fi
else
  printf "  SKIP no real python3 available to back the 'python' fallback\n"
fi

echo ""
echo "Results: ${pass}/$((pass + fail)) passed"
[ "$fail" -eq 0 ]
