#!/usr/bin/env python3

# PreToolUse guard: a MaxxtonGroup pull request's text names no Jira ticket
# other than its own.
#
# The GitHub for Jira app links a PR to every ticket key it finds in the title,
# branch, commits and description, and has no setting to limit that
# (JRACLOUD-98420). A key quoted as context ("part of epic …", "out of scope …",
# "the earlier fix …") therefore puts the PR in that unrelated ticket's
# development panel: maxxton-workspace#224 showed up in MXTS-78693's this way,
# and on 2026-10-19 263 of the 818 workspace-labelled PRs carried such a key.
# Editing the key out of the description removes the link again.
#
# The PR's own keys are those in its title and head branch; a PR that really
# covers a second ticket puts that key in the title. Every other key must be
# written so Jira cannot match it: with a non-breaking hyphen (U+2011), which
# reads the same, or in words.
#
# Wired on `gh pr create`, `gh pr edit` (improve-pr's nested run rewrites the
# description with it) and the GitHub MCP create/update tools. The whole Bash
# command is scanned, plus any --body-file, so --body, heredocs, pipes and a
# body file written earlier in the same command are all covered without
# modelling each shell form.
#
# Fail open: this is link hygiene, not a safety gate. Anything the hook cannot
# parse or resolve is allowed.

from __future__ import annotations

import json
import os
import re
import shlex
import subprocess
import sys

# Jira projects on maxxton.atlassian.net (listJiraProjects, 2026-10-19). Only
# these prefixes count, so UTF-8, SHA-256 or ISO-8601 never match. A project
# added later is simply not checked until it is listed here.
JIRA_PROJECTS = frozenset({
    'ACSI', 'AFS', 'ALB', 'ATS', 'BHP', 'CAM', 'CFS', 'CHANGEREQ', 'CMS', 'CS',
    'CSF', 'CSR', 'CSS', 'ENS', 'ERS', 'EST', 'FCS', 'FOV', 'ITT', 'JIP', 'KS',
    'LBS', 'LDM', 'LGP', 'LGS', 'LSH', 'MCMS', 'MDP', 'MOL', 'MXT', 'MXTS',
    'MYS', 'NRS', 'NWS', 'OOS', 'OSS', 'QA', 'RCS', 'RP', 'SAN', 'SAQ', 'SBL',
    'SNS', 'VTS', 'WR', 'ZS',
})
KEY_RE = re.compile(r'\b([A-Z][A-Z0-9]+)-(\d+)\b')
NON_BREAKING_HYPHEN = '‑'
MAXXTON_OWNERS = {'maxxtongroup'}
# hooks.json gives this hook 10s; one `gh pr view` at most runs.
GH_TIMEOUT = 6
MAX_BODY_FILE_BYTES = 1_000_000

# A heredoc opener through its terminator line. The body (group 4) is dropped
# before tokenizing and scanned on its own; the rest of the opener line is kept,
# e.g. the closing `)"` of `--body "$(cat <<'EOF'`.
_HEREDOC_RE = re.compile(
    r"<<-?[ \t]*(['\"]?)([A-Za-z_]\w*)\1([^\n]*)\n((?:.*?\n)??)[ \t]*\2[ \t]*(?=\n|$)",
    re.DOTALL,
)
_OPERATOR_CHARS = ';&|\n'
_EDIT_FLAGS_WITHOUT_VALUE = {'--remove-milestone', '--help', '-h'}


def allow() -> None:
    sys.exit(0)


def deny(reason: str) -> None:
    print(json.dumps({
        'hookSpecificOutput': {
            'hookEventName': 'PreToolUse',
            'permissionDecision': 'deny',
            'permissionDecisionReason': reason,
        }
    }))
    sys.exit(0)


def jira_keys(text: str) -> set[str]:
    return {m.group(0) for m in KEY_RE.finditer(text or '') if m.group(1) in JIRA_PROJECTS}


def run(args, cwd=None):
    """(ok, stdout) of a command; never raises."""
    try:
        proc = subprocess.run(args, cwd=cwd, capture_output=True, text=True, timeout=GH_TIMEOUT)
    except (OSError, subprocess.SubprocessError):
        return False, ''
    return proc.returncode == 0, proc.stdout.strip()


def tokenize(command: str):
    """Shell tokens with control operators as their own tokens; None when the
    command cannot be tokenized."""
    text = _HEREDOC_RE.sub(lambda m: m.group(3), command)
    text = text.replace('\\\r\n', ' ').replace('\\\n', ' ')
    lexer = shlex.shlex(text, posix=True, punctuation_chars=_OPERATOR_CHARS)
    lexer.whitespace = ' \t\r'
    lexer.whitespace_split = True
    try:
        return list(lexer)
    except ValueError:
        return None


def segments(tokens):
    result = [[]]
    for tok in tokens:
        if tok and all(c in _OPERATOR_CHARS for c in tok):
            result.append([])
        else:
            result[-1].append(tok)
    return [s for s in result if s]


def pr_commands(segs):
    """(verb, args after the verb, workdir) of every `gh pr create|edit` segment.
    workdir is the last `cd` target before it."""
    found = []
    workdir = None
    for seg in segs:
        for i in range(len(seg) - 2):
            if seg[i] == 'gh' and seg[i + 1] == 'pr' and seg[i + 2] in ('create', 'edit'):
                found.append((seg[i + 2], seg[i + 3:], workdir))
                break
        if seg[0] == 'cd' and len(seg) >= 2:
            workdir = os.path.expanduser(seg[1])
    return found


def without_base(args):
    """args minus the `--base`/`-B` flag and its value. A stacked PR's base branch
    carries its parent's key, but it is not PR text and Jira does not link
    through it; the same branch named in the body still counts."""
    kept = []
    skip = False
    for tok in args:
        if skip:
            skip = False
        elif tok in ('--base', '-B'):
            skip = True
        elif not (tok.startswith('--base=') or (tok.startswith('-B') and len(tok) > 2)):
            kept.append(tok)
    return kept


def scan_text(command, segs):
    """What the PR text check reads: every parsed token (quoted bodies stay whole,
    a continued line is already joined) minus each PR command's base, plus the
    heredoc bodies the tokenizer dropped."""
    parts = []
    for seg in segs:
        is_pr = any(seg[i:i + 2] == ['gh', 'pr'] and seg[i + 2] in ('create', 'edit')
                    for i in range(len(seg) - 2))
        parts.extend(without_base(seg) if is_pr else seg)
    heredocs = [m.group(4) for m in _HEREDOC_RE.finditer(command)]
    return ' '.join(parts) + '\n' + '\n'.join(heredocs)


def flag(args, names):
    """Value of the first `--flag value` / `--flag=value` / `-Fvalue`, or None."""
    for i, tok in enumerate(args):
        for name in names:
            if tok == name:
                return args[i + 1] if i + 1 < len(args) else None
            if tok.startswith(name + '='):
                return tok[len(name) + 1:]
            if len(name) == 2 and tok.startswith(name) and len(tok) > 2:
                return tok[2:]
    return None


def edit_selector(args):
    """The PR number, URL or branch `gh pr edit` was given, or None."""
    i = 0
    while i < len(args):
        tok = args[i]
        if not tok.startswith('-'):
            return tok
        glued = '=' in tok or (len(tok) > 2 and not tok.startswith('--'))
        i += 1 if (glued or tok in _EDIT_FLAGS_WITHOUT_VALUE) else 2
    return None


def owner_of(slug: str):
    parts = [p for p in re.split(r'[/:]', re.sub(r'\.git/?$', '', slug.strip().rstrip('/'))) if p]
    return parts[-2].lower() if len(parts) >= 2 else None


def bash_owners(repo, workdir):
    """Every owner the command may target: its --repo, else the checkout's remotes."""
    if repo is not None:
        if any(ch in repo for ch in '$`'):
            return set()
        return {owner_of(repo)} - {None}
    ok, out = run(['git', 'remote', '-v'], cwd=workdir)
    if not ok:
        return set()
    return {owner_of(f[1]) for f in (line.split() for line in out.splitlines()) if len(f) >= 2} - {None}


def outside_maxxton(owners) -> bool:
    return bool(owners) and not owners & MAXXTON_OWNERS


def existing_pr_keys(selector, repo, workdir):
    """Keys in an existing PR's title and head branch; None when gh cannot tell."""
    args = ['gh', 'pr', 'view'] + ([str(selector)] if selector else []) + (['--repo', repo] if repo else [])
    ok, out = run(args + ['--json', 'title,headRefName'], cwd=workdir)
    if not ok:
        return None
    try:
        pr = json.loads(out)
    except ValueError:
        return None
    return jira_keys(pr.get('title', '')) | jira_keys(pr.get('headRefName', ''))


def read_body_file(path, workdir) -> str:
    if not path or path == '-':
        return ''
    full = os.path.join(workdir, os.path.expanduser(path)) if workdir else os.path.expanduser(path)
    try:
        with open(full, encoding='utf-8', errors='replace') as fh:
            return fh.read(MAX_BODY_FILE_BYTES)
    except OSError:
        return ''


def pr_command_keys(verb, args, cd_dir, cwd):
    """(own keys, body-file text) of one `gh pr create|edit`, or None when it
    needs no check: help, another owner, an edit that leaves the body alone, or
    a PR whose own keys cannot be told."""
    if '--help' in args or '-h' in args:
        return None
    workdir = os.path.join(cwd, cd_dir) if (cwd and cd_dir) else (cd_dir or cwd)
    repo = flag(args, ['--repo', '-R'])
    if outside_maxxton(bash_owners(repo, workdir)):
        return None

    body_file = flag(args, ['--body-file', '-F'])
    title = flag(args, ['--title', '-t']) or ''
    if verb == 'edit':
        if flag(args, ['--body', '-b']) is None and body_file is None:
            return None
        own = existing_pr_keys(edit_selector(args), repo, workdir)
        if own is None:
            return None
        own |= jira_keys(title)
    else:
        head = flag(args, ['--head', '-H'])
        if head is None:
            _, head = run(['git', 'symbolic-ref', '--short', 'HEAD'], cwd=workdir)
        own = jira_keys(title) | jira_keys(head)
    return own, read_body_file(body_file, workdir)


def check_bash(command: str, cwd):
    """(own, text) for every PR command in the Bash command that needs a check.
    Each is checked, so an early `--help` or another owner's PR in a compound
    command cannot hide a later one."""
    tokens = tokenize(command)
    if not tokens:
        return []
    segs = segments(tokens)
    text = scan_text(command, segs)
    results = []
    for verb, args, cd_dir in pr_commands(segs):
        keys = pr_command_keys(verb, args, cd_dir, cwd)
        if keys is not None:
            own, body_file_text = keys
            results.append((own, text + '\n' + body_file_text))
    return results


def check_mcp(tool_name: str, tool_input: dict):
    owner = (tool_input.get('owner') or '').strip('/').lower()
    if outside_maxxton({owner} - {''}):
        allow()
    body = tool_input.get('body') or ''
    title = tool_input.get('title') or ''
    if tool_name.endswith('create_pull_request'):
        return jira_keys(title) | jira_keys(tool_input.get('head') or ''), body
    if not body:
        allow()
    repo = f"{tool_input.get('owner')}/{tool_input.get('repo')}"
    own = existing_pr_keys(tool_input.get('pullNumber'), repo, None)
    if own is None:
        allow()
    return own | jira_keys(title), body


def main() -> None:
    try:
        event = json.load(sys.stdin)
    except (json.JSONDecodeError, EOFError, ValueError):
        allow()
    if not isinstance(event, dict):
        allow()
    tool_name = event.get('tool_name') or ''
    tool_input = event.get('tool_input') or {}

    if tool_name == 'Bash':
        checks = check_bash(tool_input.get('command') or '', event.get('cwd'))
    elif tool_name.endswith(('create_pull_request', 'update_pull_request')):
        checks = [check_mcp(tool_name, tool_input)]
    else:
        allow()

    for own, text in checks:
        # Without a ticket of its own the PR has nothing to compare against; the
        # pre-pr-review hook already asks for one on create.
        foreign = sorted(jira_keys(text) - own) if own else []
        if foreign:
            deny_foreign(own, foreign)
    allow()


def deny_foreign(own, foreign) -> None:
    example = foreign[0].replace('-', NON_BREAKING_HYPHEN, 1)
    deny(
        f'This pull request text names Jira tickets other than its own ({", ".join(sorted(own))}): '
        f'{", ".join(foreign)}. The GitHub for Jira app links a PR to every ticket key in its '
        'title, branch, commits and description, so this PR would appear in those tickets\' '
        'development panels. For each key, write it with a non-breaking hyphen '
        f'(U+2011, e.g. {example}), which reads the same but Jira does not match, or refer to '
        'the ticket in words. If this PR really implements that ticket too, put its key in the '
        'title instead. Then retry.'
    )


if __name__ == '__main__':
    try:
        main()
    except SystemExit:
        raise
    except Exception:  # fail open: link hygiene must never block a PR on a hook bug
        sys.exit(0)
