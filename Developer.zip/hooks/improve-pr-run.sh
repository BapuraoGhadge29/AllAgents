#!/usr/bin/env bash
# The detached half of improve-pr. Decides whether the existing PR title and body
# survive, runs the nested `claude -p`, and records what it wrote.
#
# Split out of improve-pr.sh so every network call sits on this side of the
# detach: hooks.json caps that hook at 10s, and a slow `gh` in the launcher kills
# it before it starts anything (silently, with the dedup lock already stamped).
#
# Usage: improve-pr-run.sh <trigger> <common> <title-tail> <keep-title> <body-tail>
#                          <from-person> <from-commits> <keep-body> <hash-file>
set -uo pipefail

# This run reads a PR and edits it with `gh`, so it needs Bash and nothing
# else. Left to itself it loads the whole interactive environment: measured on a
# one-command probe, 24 MCP servers (Playwright and SQLcl among them, each a local
# process) and 77 skills, re-created as ~12k cache-write tokens on every push. The two
# flags below take that to 0 and 0, and the run from ~$0.032 to ~$0.011.
#
# Deliberately not --bare, which would also drop the hooks and CLAUDE.md: it reads auth
# strictly from ANTHROPIC_API_KEY or an apiKeyHelper, never OAuth or the keychain, so on
# a subscription login the nested run would simply stop working. Settings still load, so
# the permissions that let this run use `gh` are untouched.
_SLIM=(--strict-mcp-config --disable-slash-commands)

TRIGGER="${1:-push}"
COMMON="${2:-}"
TITLE_TAIL="${3:-}"
KEEP_TITLE="${4:-}"
BODY_TAIL="${5:-}"
FROM_PERSON="${6:-}"
FROM_COMMITS="${7:-}"
KEEP_BODY="${8:-}"
HASH_FILE="${9:-}"

# A body shorter than this (non-whitespace characters) says nothing a reviewer can
# use, e.g. "wip" or a lone "Closes ABC-1234". Only on create is it replaced like
# an empty one, keeping its facts; on push a body someone wrote is never touched.
_SHORT_BODY_CHARS=40

# git is already a hard dependency of the launcher, so use it as the hash rather
# than picking between shasum and sha256sum across macOS and Linux.
_hash() { printf '%s' "$1" | git hash-object --stdin 2>/dev/null || printf ''; }
_blank() { [ -z "$(printf '%s' "${1:-}" | tr -d '[:space:]')" ]; }
# Characters, not bytes: under a UTF-8 locale bash's ${#var} counts characters, so
# a 20-character Japanese body is 20, not 60. Without one it falls back to bytes,
# which only over-counts and so leans towards keeping the body.
_UTF8_LOCALE=""
for _l in C.UTF-8 en_US.UTF-8; do
  if [ "$(LC_ALL="$_l" bash -c 'printf %s "${#1}"' _ $'\xc3\xa9' 2>/dev/null)" = 1 ]; then
    _UTF8_LOCALE="$_l"; break
  fi
done
_short() {
  local _n
  _n=$(LC_ALL="${_UTF8_LOCALE:-C}" bash -c 's="${1//[[:space:]]/}"; printf %s "${#s}"' _ "${1:-}" 2>/dev/null)
  [ "${_n:-0}" -lt "$_SHORT_BODY_CHARS" ]
}
_norm() { printf '%s' "${1:-}" | tr '[:upper:]' '[:lower:]' | tr -cd '[:alnum:]'; }

_read_body() { gh pr view --json body --jq .body 2>/dev/null; }
_read_title() { gh pr view --json title --jq .title 2>/dev/null; }

BODY=""
READ_OK=0
TITLE=""
TITLE_OK=0
if command -v gh >/dev/null 2>&1; then
  if BODY=$(_read_body); then READ_OK=1; fi
  if TITLE=$(_read_title); then TITLE_OK=1; fi
fi

# The title is rewritten only while it is still a placeholder: what `gh pr create`
# fills in from the branch name (e.g. "Feature/abc 1234 fix login"). A title
# someone wrote stays, ticket key and all. An unreadable title is kept.
RETITLE=0
if [ "$TITLE_OK" -eq 1 ]; then
  _branch=$(git rev-parse --abbrev-ref HEAD 2>/dev/null || printf '')
  _t=$(_norm "$TITLE")
  if [ -z "$_t" ] || { [ -n "$_branch" ] && { [ "$_t" = "$(_norm "$_branch")" ] \
       || [ "$_t" = "$(_norm "${_branch#*/}")" ]; }; }; then
    RETITLE=1
  fi
fi
if [ "$RETITLE" -eq 1 ]; then _TITLE_PART="$TITLE_TAIL"; else _TITLE_PART="$KEEP_TITLE"; fi

PRESERVE=0
_SOURCE="$FROM_COMMITS"
if [ "$READ_OK" -eq 0 ]; then
  # A failed read is indistinguishable from an empty body, and on push that
  # difference decides everything: treated as empty it would hand the nested run a
  # regenerate instruction while the PR still holds a hand-written description --
  # the MXTS-81222 loss this file exists to prevent. So an unreadable body is never
  # regenerated. It costs nothing: gh is how the nested run edits the PR, so if gh
  # is failing there was no body to generate either.
  PRESERVE=1
elif _blank "$BODY"; then
  # Nothing to lose, on either trigger.
  PRESERVE=0
elif [ "$TRIGGER" = "create" ]; then
  # The body was written by whoever just opened the PR. Kept, unless it is too
  # short to help a reviewer; then it is rewritten around the facts it holds.
  if _short "$BODY"; then _SOURCE="$FROM_PERSON"; else PRESERVE=1; fi
else
  # Regenerate only a body this hook wrote and nobody has edited since. Ownership
  # is the question, not age: a description someone shaped by hand may carry
  # decisions recorded nowhere else, and that does not become less true as commits
  # accumulate. Our own untouched body is fair game, so a branch that has since
  # deviated from what it first described still gets refreshed -- from the commits,
  # so its old Verified bullets are not carried forward. Length plays no part here.
  _prev=$(cat "$HASH_FILE" 2>/dev/null || printf '')
  if [ -z "$_prev" ] || [ "$(_hash "$BODY")" != "$_prev" ]; then PRESERVE=1; fi
fi

if [ "$PRESERVE" -eq 1 ]; then
  # Nothing to record: this path never writes a body. exec keeps the pid the
  # launcher's watchdog signals.
  exec env -u CLAUDECODE claude "${_SLIM[@]}" \
    --model haiku --effort medium --max-turns 8 \
    --output-format text -p "$COMMON $_TITLE_PART $KEEP_BODY"
fi

# Regenerating, so the run has to be waited on to record the result. Backgrounded
# with a TERM trap rather than exec'd: the watchdog signals this script, and
# without the trap the nested run would be orphaned and keep editing the PR.
env -u CLAUDECODE claude "${_SLIM[@]}" \
  --model haiku --effort medium --max-turns 8 \
  --output-format text -p "$COMMON $_TITLE_PART $BODY_TAIL $_SOURCE" &
_child=$!
trap 'kill "$_child" 2>/dev/null || true' TERM INT
wait "$_child" || true
trap - TERM INT

# Record what landed, so the next push can tell this hook's body from a human's.
# Best-effort: a missing hash just means the next push preserves, which is safe.
if [ -n "$HASH_FILE" ] && command -v gh >/dev/null 2>&1; then
  _new=$(_read_body) || _new=""
  if ! _blank "$_new"; then
    _hash "$_new" > "$HASH_FILE" 2>/dev/null || true
  fi
fi
exit 0
