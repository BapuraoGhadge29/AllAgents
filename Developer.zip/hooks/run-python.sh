#!/usr/bin/env bash
# Reusable launcher: resolve a working Python 3 interpreter, then exec the given
# script with its arguments. Used by hooks.json command strings so hooks run on
# Windows (Git Bash) too — there the interpreter is `python` / `py -3`, and a
# bare `python3`/`python` on PATH is usually the no-op Microsoft Store alias.
# Each candidate is *executed* (not just `command -v`-checked) so that alias is
# rejected. See CLAUDE.md "Invoking Python from shell scripts".
#
# Usage: run-python.sh <script.py> [args...]
set -euo pipefail

for _cand in python3 python "py -3"; do
  # shellcheck disable=SC2086  # $_cand may be "py -3" and must word-split
  if $_cand -c 'import sys; sys.exit(0 if sys.version_info[0] == 3 else 1)' >/dev/null 2>&1; then
    # shellcheck disable=SC2086
    exec $_cand "$@"
  fi
done

echo "[run-python] no Python 3 interpreter found (tried python3, python, py -3)" >&2
exit 127
