#!/usr/bin/env python3

# Dockerfile base-image pin guard.
#
# Wired as PostToolUse on Write | Edit | MultiEdit for Dockerfiles. Reads the
# file from disk after the edit (an Edit payload only carries the replaced
# fragment) and checks every FROM line. Dependabot bumps an image tag only at
# the precision it already has: `node:22` never gets a patch PR, and
# `node:${NODE_VERSION}` or `node:latest` get no PR at all. So every external
# base image must carry a full MAJOR.MINOR.PATCH tag, or a digest for images
# that publish no semver tags.
#
# Allowed:  node:22.11.0-alpine, eclipse-temurin:21.0.5_11-jre,
#           apache/airflow:slim-3.2.2-python3.10, img:1.2.3@sha256:...,
#           img@sha256:..., scratch, earlier stage names, and a FROM whose
#           whole image is one build arg (${IMAGE}, injected by the pipeline)
# Blocked:  no tag, latest, partial versions (22, 22.11, lts, bookworm), and
#           a variable inside the image reference (node:${NODE_VERSION}).
#
# Tool versions in ARGs (ARG GH_VERSION=v2.101.0) are invisible to Dependabot;
# self-hosted Renovate updates them when a `# renovate: datasource=... depName=...`
# comment sits on the line directly above. An ARG named *_VERSION with a literal
# default and no such comment is blocked too. `# renovate: ignore <reason>` above
# the ARG opts it out on purpose; a bare ignore does not count. A *_VERSION
# without a default comes from the pipeline.
#
# A violation returns {"decision": "block"} so Claude fixes the file in the
# same turn. Fail-open: malformed input, unreadable files and hook bugs allow
# the edit. A hook bug must never block real work.

import json
import re
import sys
from pathlib import Path

# The patch number must end the version: the tag ends there or a separator
# follows (-alpine, _11, +build, or a 4th component such as 1.2.3.4, which is
# more precise and still bumped by Dependabot). Rejects 1.2.3garbage.
# A word prefix is allowed (slim-3.2.2-python3.10, jdk-21.0.5); Dependabot
# keeps it when bumping.
_FULL_SEMVER = re.compile(r"^(?:[A-Za-z][A-Za-z0-9]*[-_])*v?\d+\.\d+\.\d+(?=$|[._+-])")
# The whole image is one build arg (FROM ${IMAGE}): the pipeline passing it
# owns the pin, and there is nothing in the file for Dependabot to track.
_WHOLE_IMAGE_ARG = re.compile(r"^\$(?:[A-Za-z_]\w*|\{[A-Za-z_]\w*\})$")
# BuildKit heredoc opener: <<EOF, <<-EOF, <<"EOF", <<'EOF'. It must start a
# word, so shell arithmetic ($((x<<2))) and here-strings (<<<) do not match.
_HEREDOC = re.compile(r"(?:^|\s)<<-?[\"']?([A-Za-z_][A-Za-z0-9_]*)[\"']?")
_VERSION_ARG = re.compile(r"^ARG\s+([A-Za-z_][A-Za-z0-9_]*_VERSION)=(\S+)\s*$", re.IGNORECASE)
_MULTI_VERSION_ARG = re.compile(r"^ARG\s+.*\b[A-Za-z0-9_]*_VERSION=\S+\s+\S", re.IGNORECASE)
# The same shape the Renovate custom.regex manager matches (MaxxtonGroup/renovate).
_RENOVATE_COMMENT = re.compile(r"^#\s*renovate:\s+datasource=\S+\s+depName=\S+")
_RENOVATE_IGNORE = re.compile(r"^#\s*renovate:\s*ignore\s+\S")
# Dockerfile.<variant> names that are really docs, scripts or config.
_NON_DOCKER_EXT = {
    "md", "txt", "rst", "adoc", "py", "sh", "js", "ts", "go", "java", "json",
    "yml", "yaml", "toml", "dockerignore", "bak", "orig", "swp",
}


def allow():
    sys.exit(0)


def block(reason):
    print(json.dumps({"decision": "block", "reason": reason}))
    sys.exit(0)


def _is_dockerfile(file_path):
    """Dockerfile, Containerfile, Dockerfile.<variant> or <name>.dockerfile —
    not dockerfile_utils.py, Dockerfile.md or Dockerfile.dockerignore."""
    name = Path(file_path).name.lower()
    if name in ("dockerfile", "containerfile") or name.endswith(".dockerfile"):
        return True
    if name.startswith(("dockerfile.", "containerfile.")):
        return name.rsplit(".", 1)[1] not in _NON_DOCKER_EXT
    return False


def _instructions(text):
    """Yield (line_no, instruction) with backslash continuations joined and
    comment lines and heredoc bodies dropped. line_no is where the
    instruction starts."""
    buf, start, heredocs = [], None, []
    for i, raw in enumerate(text.splitlines(), 1):
        line = raw.strip()
        if heredocs:
            # Inside a RUN/COPY heredoc body: skip until its delimiter line, so
            # embedded code such as `from flask import Flask` is not a FROM.
            if line == heredocs[0]:
                heredocs.pop(0)
            continue
        if not buf and (not line or line.startswith("#")):
            continue
        if buf and line.startswith("#"):
            continue  # comments inside a continued instruction are ignored
        if start is None:
            start = i
        if line.endswith("\\"):
            buf.append(line[:-1])
            continue
        buf.append(line)
        instr = " ".join(buf)
        heredocs = _HEREDOC.findall(instr)
        yield start, instr
        buf, start = [], None
    if buf:
        yield start, " ".join(buf)


def _check_image(ref, stages):
    """Return a problem string for this FROM image reference, or None."""
    if _WHOLE_IMAGE_ARG.match(ref):
        return None
    if "$" in ref:
        return "uses a variable; Dependabot does not resolve ARG values in FROM"
    lower = ref.lower()
    if lower == "scratch" or lower in stages:
        return None
    name, _, digest = ref.partition("@")
    last = name.rsplit("/", 1)[-1]
    tag = last.split(":", 1)[1] if ":" in last else None
    # Checked before the digest pass: a digest must not dress up a floating tag.
    if tag is not None and tag.lower() == "latest":
        return "uses the latest tag"
    if digest:
        return None
    if tag is None:
        return "has no tag (implicit latest)"
    if not _FULL_SEMVER.match(tag):
        return f"tag '{tag}' is not a full MAJOR.MINOR.PATCH version"
    return None


def _version_arg_violations(text):
    """ARGs holding a tool version need a Renovate comment on the line above."""
    violations, previous = [], ""
    for i, raw in enumerate(text.splitlines(), 1):
        line = raw.strip()
        if _MULTI_VERSION_ARG.match(line):
            violations.append(f"  line {i}: {line} — put each *_VERSION ARG on its own line under its own # renovate: comment")
        else:
            m = _VERSION_ARG.match(line)
            if m and "$" not in m.group(2) and not (_RENOVATE_COMMENT.match(previous) or _RENOVATE_IGNORE.match(previous)):
                violations.append(f"  line {i}: ARG {m.group(1)}={m.group(2)} — no '# renovate: datasource=... depName=...' comment directly above")
        previous = line
    return violations


def find_violations(text):
    violations, stages = [], set()
    for line_no, instr in _instructions(text):
        tokens = instr.split()
        if not tokens or tokens[0].upper() != "FROM":
            continue
        args = [t for t in tokens[1:] if not t.startswith("--")]
        if not args:
            continue
        ref = args[0]
        problem = _check_image(ref, stages)
        if problem:
            violations.append(f"  line {line_no}: FROM {ref} — {problem}")
        if len(args) >= 3 and args[1].upper() == "AS":
            stages.add(args[2].lower())
    return violations


def _reason(file_path, violations):
    return (
        f"{file_path} has base images Dependabot cannot keep patched:\n"
        + "\n".join(violations)
        + "\n\nPin each external FROM to a full MAJOR.MINOR.PATCH tag and keep "
        "the variant suffix, kept generic (e.g. node:22.11.0-alpine, not node:22-alpine "
        "or node:22.11.0-alpine3.20: Dependabot only moves to tags with the exact "
        "same suffix). "
        "Write the tag literally — no ARG in FROM. For images without semver "
        "tags (e.g. distroless), pin a digest: image:tag@sha256:<digest>.\n"
        "Look up a tag that exists (docker manifest inspect <image>:<tag>, or "
        "the registry's tag list) — never guess a version number. If you "
        "cannot verify one, ask the user which version to pin."
    )


def _arg_reason(file_path, violations):
    return (
        f"{file_path} has tool-version ARGs Renovate cannot keep patched:\n"
        + "\n".join(violations)
        + "\n\nPut a Renovate comment directly above each one, naming where the "
        "version comes from, e.g.\n"
        "  # renovate: datasource=npm depName=@anthropic-ai/claude-code\n"
        "  # renovate: datasource=github-releases depName=cli/cli\n"
        "  # renovate: datasource=github-release-attachments depName=cli/cli  "
        "(then ARG <NAME>_SHA256 directly below the version ARG)\n"
        "Pick the datasource that really publishes this tool (npm, pypi, "
        "github-releases, github-tags, docker, ...); do not guess the depName. "
        "Optional fields, in this order: versioning= and extractVersion=. "
        "Use '# renovate: ignore' only for a version that must not move, and "
        "say why on the same line."
    )


def main():
    try:
        payload = json.load(sys.stdin)
    except (json.JSONDecodeError, ValueError):
        allow()

    tool_input = payload.get("tool_input") or {}
    file_path = tool_input.get("file_path")
    if not isinstance(file_path, str) or not _is_dockerfile(file_path):
        allow()

    try:
        text = Path(file_path).read_text(encoding="utf-8")
    except (OSError, UnicodeDecodeError):
        allow()

    violations = find_violations(text)
    arg_violations = _version_arg_violations(text)
    if violations or arg_violations:
        reasons = []
        if violations:
            reasons.append(_reason(file_path, violations))
        if arg_violations:
            reasons.append(_arg_reason(file_path, arg_violations))
        block("\n\n".join(reasons))
    allow()


if __name__ == "__main__":
    try:
        main()
    except SystemExit:
        raise
    except Exception as exc:  # noqa: BLE001 — fail open, never block on a hook bug
        sys.stderr.write(f"dockerfile-pin-guard: unexpected error: {exc}\n")
        sys.exit(0)
