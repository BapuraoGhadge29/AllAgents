#!/usr/bin/env python3
"""Reinforces the subagent-failure-recovery rule when a Task tool response
shows failure signals. Silent on the happy path so successful Task calls
add no token noise. The rule itself (loaded every session) carries the
always-verify default; this hook is the failure-detection safety net.

Side effects: none. Reads stdin, writes stdout. Silent on any error.
"""

import json
import re
import sys

FAILURE_SIGNALS = [
    r"\bfailed\b",
    r"error[: ]",
    r"\bcould not\b",
    r"\bunable to\b",
    r"\btimed out\b",
    r"\bexception\b",
    r"\bunsuccessful\b",
    r"\bdid not complete\b",
]


def extract_text(resp):
    if not resp:
        return ""
    if isinstance(resp, str):
        return resp
    if isinstance(resp, list):
        return "\n".join(
            b if isinstance(b, str) else b.get("text", "") for b in resp
        )
    if isinstance(resp, dict):
        if "content" in resp:
            return extract_text(resp["content"])
        if "text" in resp:
            return resp["text"]
        return json.dumps(resp)
    return str(resp)


try:
    data = json.load(sys.stdin)

    if data.get("tool_name") != "Task":
        sys.exit(0)

    text = extract_text(data.get("tool_response"))

    if not any(re.search(p, text, re.IGNORECASE) for p in FAILURE_SIGNALS):
        sys.exit(0)

    reminder = (
        "Failure signal detected in the subagent response. Follow the "
        "subagent-failure-recovery rule: (1) capture the failure context, "
        "(2) diagnose before retrying — do not resend the same prompt, "
        "(3) change something on retry — smaller scope, different agent, "
        "clearer prompt, or a manual workaround, (4) hard stop at 2 failed "
        "attempts on the same subtask and escalate with what was tried and "
        "where you are stuck. Verify the actual artefact the subagent claims "
        "to have produced before declaring this task complete."
    )

    print(json.dumps({
        "hookSpecificOutput": {
            "hookEventName": "PostToolUse",
            "additionalContext": reminder,
        }
    }))
except Exception:
    sys.exit(0)
