#!/usr/bin/env bash
# Sourced by git hook entry points — never executed directly.
# Caller must set: HOOK_NAME, HOOK_ARGS (array)

[ -n "${HOOK_NAME:-}" ] || { echo "_run-hooks.sh: must be sourced with HOOK_NAME set" >&2; exit 1; }

# Skip if not a MaxxtonGroup repo.
#
# MAXXTON_FORCE_GIT_HOOKS=1 bypasses the remote test. It exists for Claude Code
# self-hosted runners, which clone through the Anthropic git proxy: the proxy
# rewrites origin to api.anthropic.com, so the check below would skip every hook
# on what is still a MaxxtonGroup checkout -- and skip it silently, since exit 0
# is indistinguishable from "hooks ran and passed". Only set it where the
# checkout is known to be ours.
if [ "${MAXXTON_FORCE_GIT_HOOKS:-}" != "1" ]; then
  _origin_url=$(git remote get-url origin 2>/dev/null) || exit 0
  case "$_origin_url" in
    *MaxxtonGroup*) ;;
    *) exit 0 ;;
  esac
fi

_overall_exit=0
_repo_root=$(git rev-parse --show-toplevel 2>/dev/null) || _repo_root=""

# Drain stdin once into a temp file so every hook script gets a fresh read of
# the original data (critical for pre-push, which receives refspecs on stdin).
# For hooks with no stdin the file is empty, which is harmless.
_stdin_file=$(mktemp)
cat > "$_stdin_file"
trap 'rm -f "$_stdin_file"' EXIT

# Returns enabled Maxxton plugin names, one per line.
# developer is always included. Uses bash 3 / POSIX grep+sed only.
_enabled_plugins() {
  printf 'developer\n'
  local _settings="${_repo_root}/.claude/settings.json"
  [ -f "$_settings" ] || return 0
  # Legacy keys tolerated in memory ("<name>@maxxton.com" suffix; "developers"
  # alias of "developer"); the tracked file is never rewritten. Keep in step with
  # _plugins_with_rules in plugins/developer/git-hooks/post-checkout.sh.
  grep -oE '"[A-Za-z0-9_-]+@(maxxton\.com|maxxton-marketplace|claudeai-maxxtongroup-claude-marketplace)"[[:space:]]*:[[:space:]]*true' "$_settings" 2>/dev/null |
    sed 's/@[^"]*".*$//; s/^"//; s/^developers$/developer/' |
    LC_ALL=C sort -u |
    grep -v '^developer$'
}

# Resolve a working Python 3 interpreter across macOS/Linux/Windows (Git Bash).
# Order: python3 → python → "py -3". Each candidate is *run*, not just
# `command -v`-checked, so the Windows Store alias stub is rejected.
resolve_python() {
  local _cand
  for _cand in python3 python "py -3"; do
    if $_cand -c 'import sys; sys.exit(0 if sys.version_info[0] == 3 else 1)' >/dev/null 2>&1; then
      printf '%s\n' "$_cand"; return 0
    fi
  done
  return 1
}

# Prints "<name><TAB><installPath>" per plugin installed from the claude.ai org
# marketplace. It has no clone under marketplaces/, so installed_plugins.json is
# the only record of the installed revision. Keep in step with post-checkout.sh.
_org_plugin_dirs() {
  local _ledger="${HOME}/.claude/plugins/installed_plugins.json" _py
  [ -f "$_ledger" ] || return 0
  _py=$(resolve_python) || return 0
  local -a _py_cmd
  read -r -a _py_cmd <<< "$_py"
  "${_py_cmd[@]}" - "$_ledger" "$_repo_root" 2>/dev/null <<'PY' || true
import json, os, sys
suffix = "@claudeai-maxxtongroup-claude-marketplace"
repo = os.path.realpath(sys.argv[2]) if sys.argv[2] else ""

def live(entry):
    return isinstance(entry, dict) and os.path.isdir(entry.get("installPath") or "")

def for_this_repo(entry):
    """A project install applies to its own folder and the folders inside it."""
    if entry.get("scope") not in ("project", "local") or not repo:
        return False
    root = os.path.realpath(entry.get("projectPath") or "/nonexistent")
    return repo == root or repo.startswith(root.rstrip(os.sep) + os.sep)

def pick(entries):
    """The nearest project install for this repo, else the user install. Ledgers keep
    old project installs for other folders, so the first entry can be any revision."""
    installed = [e for e in entries if live(e)]
    project = [e for e in installed if for_this_repo(e)]
    if project:
        return max(project, key=lambda e: len(e["projectPath"]))
    return next((e for e in installed if e.get("scope") == "user"), None)

try:
    with open(sys.argv[1], encoding="utf-8") as f:
        plugins = json.load(f).get("plugins") or {}
except (OSError, ValueError, AttributeError):
    sys.exit(0)
for key, entries in plugins.items():
    chosen = pick(entries or []) if key.endswith(suffix) else None
    if chosen:
        print(key[: -len(suffix)] + "\t" + chosen["installPath"])
PY
}

_org_dirs=$(_org_plugin_dirs)

# The org install wins: when both exist, the GitHub clone is the one Claude Code
# no longer updates (it stays on disk after its marketplace is removed).
_plugin_dir() {
  local _dir
  _dir=$(printf '%s\n' "$_org_dirs" | awk -F'\t' -v n="$1" '$1 == n { print $2; exit }')
  # On Windows installPath is native (C:\...); Git Bash tests need its POSIX form.
  if [ -n "$_dir" ] && command -v cygpath >/dev/null 2>&1; then
    _dir=$(cygpath -u "$_dir")
  fi
  printf '%s\n' "${_dir:-${HOME}/.claude/plugins/marketplaces/maxxton-marketplace/plugins/$1}"
}

# Run marketplace plugin hooks for each enabled plugin.
# Plugin list is read via process substitution so stdin (fd 0) stays bound to
# the temp file; each hook script receives the original stdin via redirection.
while IFS= read -r _plugin; do
  [ -n "$_plugin" ] || continue
  _hook_script="$(_plugin_dir "$_plugin")/git-hooks/${HOOK_NAME}.sh"
  [ -x "$_hook_script" ] || continue
  _hook_exit=0
  "$_hook_script" "${HOOK_ARGS[@]+"${HOOK_ARGS[@]}"}" < "$_stdin_file" || _hook_exit=$?
  [ "$_hook_exit" -gt "$_overall_exit" ] && _overall_exit=$_hook_exit
done < <(_enabled_plugins)

# Run local repo hook if present
if [ -n "$_repo_root" ]; then
  _local_hook="${_repo_root}/.git-hooks/${HOOK_NAME}.sh"
  if [ -x "$_local_hook" ]; then
    _hook_exit=0
    "$_local_hook" "${HOOK_ARGS[@]+"${HOOK_ARGS[@]}"}" < "$_stdin_file" || _hook_exit=$?
    [ "$_hook_exit" -gt "$_overall_exit" ] && _overall_exit=$_hook_exit
  fi
fi

exit "$_overall_exit"
