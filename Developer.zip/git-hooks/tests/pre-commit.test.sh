#!/usr/bin/env bash
# Tests for pre-commit.sh — runs on macOS, Linux, and Windows (Git Bash).
# Usage: bash tests/pre-commit.test.sh

set -uo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
HOOK="$SCRIPT_DIR/../pre-commit.sh"
FIXTURES="$SCRIPT_DIR/fixtures"
_ORIG_DIR="$PWD"
_REPO=""

PASS=0; FAIL=0; SKIP=0

pass()      { echo "  PASS  $1"; PASS=$((PASS+1)); }
fail()      { echo "  FAIL  $1"; FAIL=$((FAIL+1)); }
skip_test() { echo "  SKIP  $1 ($2)"; SKIP=$((SKIP+1)); }

_setup_repo() {
  _REPO=$(mktemp -d)
  cd "$_REPO"
  git init -q
  git config user.email "test@example.com"
  git config user.name "Test User"
  # Commit so we can create a branch, then switch to a valid feature branch
  git commit -q --allow-empty -m "init"
  git checkout -q -b feature/MXTS-1 2>/dev/null || git switch -q -c feature/MXTS-1 2>/dev/null
}

_cleanup() {
  cd "$_ORIG_DIR"
  rm -rf "${_REPO}"
}

# ── Test 1: clean staged file → exit 0 ─────────────────────────────────────

test_clean_file_passes() {
  if ! command -v gitleaks >/dev/null 2>&1; then
    skip_test "clean staged file → exit 0" "gitleaks not installed"; return
  fi
  _setup_repo
  cp "$FIXTURES/clean.txt" .
  git add clean.txt
  if bash "$HOOK" >/dev/null 2>&1; then
    pass "clean staged file → exit 0"
  else
    fail "clean staged file → expected exit 0, got non-zero"
  fi
  _cleanup
}

# ── Test 2: staged secret → exit 1 ─────────────────────────────────────────

test_secret_detected() {
  if ! command -v gitleaks >/dev/null 2>&1; then
    skip_test "staged secret → exit 1" "gitleaks not installed"; return
  fi
  _setup_repo
  cp "$FIXTURES/aws-key.env" .
  git add aws-key.env
  if bash "$HOOK" >/dev/null 2>&1; then
    fail "staged secret → expected exit 1 (leak found), got exit 0"
  else
    pass "staged secret → exit 1"
  fi
  _cleanup
}

# ── Test 3: gitleaks absent + no package manager → exit 1 + error msg ──────

test_missing_gitleaks_exits_1() {
  local _stub_dir _safe_path _dir _output _exit
  _stub_dir=$(mktemp -d)

  # Stub every package manager to fail immediately (non-interactive)
  for _cmd in brew apt-get pacman winget choco scoop; do
    printf '#!/bin/sh\nexit 127\n' > "$_stub_dir/$_cmd"
    chmod +x "$_stub_dir/$_cmd"
  done

  # Build a PATH that excludes every directory containing a gitleaks binary.
  # If gitleaks lives alongside essential tools (e.g. /usr/bin on some Linux
  # distros), we cannot safely exclude it — skip instead of breaking the shell.
  _safe_path="$_stub_dir"
  while IFS= read -r _dir; do
    [ -x "${_dir}/gitleaks" ] && continue
    _safe_path="${_safe_path}:${_dir}"
  done < <(printf '%s\n' "$PATH" | tr ':' '\n' | grep -v '^$')

  if PATH="$_safe_path" command -v gitleaks >/dev/null 2>&1; then
    skip_test "gitleaks absent → exit 1 + error message" \
      "gitleaks shares a PATH dir with essential tools; cannot isolate"
    rm -rf "$_stub_dir"; return
  fi

  _setup_repo
  echo "hello" > file.txt
  git add file.txt

  _output=$(PATH="$_safe_path" bash "$HOOK" 2>&1) && _exit=0 || _exit=$?

  if [ "$_exit" -eq 1 ] && printf '%s' "$_output" | grep -q "Could not install gitleaks"; then
    pass "gitleaks absent → exit 1 + error message"
  else
    fail "gitleaks absent → expected exit 1 with error message; got exit $_exit"
    printf '%s\n' "$_output" | sed 's/^/    /'
  fi

  _cleanup
  rm -rf "$_stub_dir"
}

# ── Branch protection helpers ───────────────────────────────────────────────

_setup_branch_repo() {
  local _branch="$1"
  _REPO=$(mktemp -d)
  cd "$_REPO"
  git init -q
  git config user.email "test@example.com"
  git config user.name "Test User"
  # Need at least one commit so we can create/switch branches
  git commit -q --allow-empty -m "init"
  if [ "$_branch" != "master" ] && [ "$_branch" != "main" ]; then
    git checkout -q -b "$_branch" 2>/dev/null || git switch -q -c "$_branch" 2>/dev/null
  else
    # Rename initial branch to target name
    git branch -q -m "$_branch" 2>/dev/null || true
  fi
}

_assert_branch_exit() {
  local _desc="$1" _branch="$2" _expected="$3"
  _setup_branch_repo "$_branch"
  local _exit=0
  bash "$HOOK" >/dev/null 2>&1 || _exit=$?
  if [ "$_exit" -eq "$_expected" ]; then
    pass "$_desc"
  else
    fail "$_desc (expected exit $_expected, got $_exit)"
  fi
  _cleanup
}

# ── Branch protection tests ─────────────────────────────────────────────────

test_protected_main()    { _assert_branch_exit "protected branch: main → exit 1"        main           1; }
test_protected_master()  { _assert_branch_exit "protected branch: master → exit 1"      master         1; }
test_protected_develop() { _assert_branch_exit "protected branch: develop → exit 1"     develop        1; }
test_protected_release() { _assert_branch_exit "protected branch: release/1.0 → exit 1" release/1.0.0  1; }
test_feature_allowed()   { _assert_branch_exit "feature branch allowed → exit 0"        feature/MXTS-1 0; }

# ── Branch naming convention tests ─────────────────────────────────────────

test_naming_feature_ticket()      { _assert_branch_exit "naming: feature/<ticket> → exit 0"             feature/MXTS-1234          0; }
test_naming_bugfix_ticket()       { _assert_branch_exit "naming: bugfix/<ticket> → exit 0"              bugfix/MCMS-42             0; }
test_naming_hotfix_ticket()       { _assert_branch_exit "naming: hotfix/<ticket> → exit 0"              hotfix/MXTS-99             0; }
test_naming_feature_with_desc()   { _assert_branch_exit "naming: feature/<ticket>-desc → exit 0"        feature/MXTS-1234-fix-login 0; }
test_naming_bugfix_with_desc()    { _assert_branch_exit "naming: bugfix/<ticket>-desc → exit 0"         bugfix/MXTS-5-null-ptr     0; }
test_naming_no_prefix()           { _assert_branch_exit "naming: no type prefix → exit 1"               my-feature                 1; }
test_naming_no_ticket()           { _assert_branch_exit "naming: missing ticket number → exit 1"        feature/no-ticket          1; }
test_naming_zero_ticket()         { _assert_branch_exit "naming: zero ticket not allowed → exit 1"      feature/MXTS-0             1; }
test_naming_lowercase_ticket()    { _assert_branch_exit "naming: lowercase ticket not allowed → exit 1" feature/mxts-1234          1; }
test_naming_unknown_type()        { _assert_branch_exit "naming: unknown type chore → exit 1"           chore/MXTS-1234            1; }
test_naming_combined_prs()        { _assert_branch_exit "naming: combined-prs-branch exempt → exit 0"   combined-prs-branch        0; }
test_naming_dependabot_branch()   { _assert_branch_exit "naming: dependabot/* not exempt → exit 1"      dependabot/npm_and_yarn/foo-1.2.3 1; }

test_detached_head() {
  _REPO=$(mktemp -d)
  cd "$_REPO"
  git init -q
  git config user.email "test@example.com"
  git config user.name "Test User"
  git commit -q --allow-empty -m "init"
  git checkout -q --detach HEAD 2>/dev/null
  local _output _exit=0
  _output=$(bash "$HOOK" 2>&1) || _exit=$?
  # The branch protection must NOT trigger — "not allowed" must not appear
  if printf '%s' "$_output" | grep -q "not allowed"; then
    fail "detached HEAD → branch protection should not trigger"
  else
    pass "detached HEAD → branch protection not triggered"
  fi
  _cleanup
}

# ── Runner ──────────────────────────────────────────────────────────────────

echo "pre-commit.sh"
echo ""
echo "secrets scanning"
test_clean_file_passes
test_secret_detected
test_missing_gitleaks_exits_1
echo ""
echo "branch protection"
test_protected_main
test_protected_master
test_protected_develop
test_protected_release
test_feature_allowed
test_detached_head
echo ""
echo "branch naming convention"
test_naming_feature_ticket
test_naming_bugfix_ticket
test_naming_hotfix_ticket
test_naming_feature_with_desc
test_naming_bugfix_with_desc
test_naming_no_prefix
test_naming_no_ticket
test_naming_zero_ticket
test_naming_lowercase_ticket
test_naming_unknown_type
test_naming_combined_prs
test_naming_dependabot_branch
echo ""
echo "Results: $PASS passed, $FAIL failed, $SKIP skipped"
[ "$FAIL" -eq 0 ]
