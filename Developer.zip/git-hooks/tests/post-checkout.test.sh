#!/usr/bin/env bash
# Tests for post-checkout.sh — runs on macOS, Linux, and Windows (Git Bash).
# Usage: bash tests/post-checkout.test.sh

set -uo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
HOOK="$SCRIPT_DIR/../post-checkout.sh"
_ORIG_DIR="$PWD"
_REPO=""

PASS=0; FAIL=0; SKIP=0

pass()      { echo "  PASS  $1"; PASS=$((PASS+1)); }
fail()      { echo "  FAIL  $1"; FAIL=$((FAIL+1)); }
skip()      { echo "  SKIP  $1"; SKIP=$((SKIP+1)); }

_ON_WINDOWS=false
case "$(uname -s 2>/dev/null || true)" in MINGW*|MSYS*|CYGWIN*) _ON_WINDOWS=true ;; esac

# Make a directory link the way the hook does: a symlink, or on Windows a
# junction. A symlink there needs a privilege most accounts lack, and MSYS
# `ln -s` without it silently copies instead — the defect the hook migrates.
_make_link() {  # $1 = source dir, $2 = link path
  if [ "$_ON_WINDOWS" = "true" ]; then
    MSYS2_ARG_CONV_EXCL='/J' cmd //c mklink /J "$(cygpath -w "$2")" "$(cygpath -w "$1")" >/dev/null 2>&1 || true
  else
    ln -sfn "$1" "$2"
  fi
}

# Probe once so the link tests report SKIP on a platform that cannot make a
# directory link at all, rather than a spurious FAIL.
_LINKS_SUPPORTED=""
_links_supported() {
  if [ -z "$_LINKS_SUPPORTED" ]; then
    local _probe; _probe=$(mktemp -d)
    mkdir "$_probe/real"
    _make_link "$_probe/real" "$_probe/link"
    if [ -L "$_probe/link" ]; then _LINKS_SUPPORTED=yes; else _LINKS_SUPPORTED=no; fi
    rm -rf "$_probe"
  fi
  [ "$_LINKS_SUPPORTED" = "yes" ]
}

_setup_repo() {
  _REPO=$(mktemp -d)
  cd "$_REPO"
  git init -q
  git config user.email "test@example.com"
  git config user.name "Test User"
  git commit -q --allow-empty -m "init"
}

_cleanup() {
  cd "$_ORIG_DIR"
  rm -rf "${_REPO}"
}

_clone_args() {
  printf '%s' "0000000000000000000000000000000000000000 $(git rev-parse HEAD) 1"
}

# ── Test 1: required entries added on clone ───────────────────────────────────

test_gitignore_entries_on_clone() {
  _setup_repo
  # shellcheck disable=SC2046
  bash "$HOOK" $(_clone_args) >/dev/null 2>&1 || true

  local _any_fail=0
  for _entry in '.claude/rules/*' '!.claude/rules/*.md' '.claude/.rules-synced' \
                '.claude/worktrees/' '.claude/settings.local.json' 'CLAUDE.local.md'; do
    if ! grep -qxF "$_entry" .gitignore 2>/dev/null; then
      fail "gitignore entry missing after clone: $_entry"
      _any_fail=1
    fi
  done
  [ "$_any_fail" -eq 0 ] && pass "required gitignore entries added on clone"
  _cleanup
}

# ── Test 2: old two-level pattern is not added ────────────────────────────────

test_old_pattern_absent() {
  _setup_repo
  # shellcheck disable=SC2046
  bash "$HOOK" $(_clone_args) >/dev/null 2>&1 || true

  if grep -qxF '.claude/rules/*/*.md' .gitignore 2>/dev/null; then
    fail "old pattern .claude/rules/*/*.md must not appear in .gitignore"
  else
    pass "old pattern .claude/rules/*/*.md not added"
  fi
  _cleanup
}

# ── Test 3: running hook twice does not duplicate entries ─────────────────────

test_gitignore_idempotent() {
  _setup_repo
  local _args
  _args=$(_clone_args)
  # shellcheck disable=SC2086
  bash "$HOOK" $(_clone_args) >/dev/null 2>&1 || true
  # shellcheck disable=SC2086
  bash "$HOOK" $(_clone_args) >/dev/null 2>&1 || true

  local _count
  _count=$(grep -cxF '.claude/rules/*' .gitignore 2>/dev/null || true)
  if [ "$_count" -eq 1 ]; then
    pass ".claude/rules/* appears exactly once (no duplication)"
  else
    fail ".claude/rules/* appears $_count times in .gitignore (expected 1)"
  fi
  _cleanup
}

# ── Test 4: section header appears exactly once ───────────────────────────────

test_section_header_once() {
  _setup_repo
  # shellcheck disable=SC2046
  bash "$HOOK" $(_clone_args) >/dev/null 2>&1 || true

  local _count
  _count=$(grep -cxF '# maxxton-marketplace' .gitignore 2>/dev/null || true)
  if [ "$_count" -eq 1 ]; then
    pass "section header '# maxxton-marketplace' added exactly once"
  else
    fail "section header appears $_count times (expected 1)"
  fi
  _cleanup
}

# ── Test 5: ordinary branch checkout DOES populate .gitignore ─────────────────
# The hook no longer gates rule-linking / .gitignore behind a first-run marker —
# both run on every branch checkout (idempotently).

test_gitignore_updated_on_ordinary_checkout() {
  _setup_repo
  local _prev
  _prev=$(git rev-parse HEAD)
  git commit -q --allow-empty -m "second"
  local _new
  _new=$(git rev-parse HEAD)

  bash "$HOOK" "$_prev" "$_new" "1" >/dev/null 2>&1 || true

  if [ -f .gitignore ] && grep -qxF '# maxxton-marketplace' .gitignore 2>/dev/null; then
    pass ".gitignore populated on ordinary branch checkout"
  else
    fail ".gitignore should be populated on ordinary branch checkout"
  fi
  _cleanup
}

# ── Rule copies ───────────────────────────────────────────────────────────────
# Copies, not links: Claude Code never loads a `paths:` rule through a link out
# of the repo. Each checkout refreshes the copy from the marketplace clone.

_fake_rules() {  # $1 = fake HOME, $2 = plugin (default developer); prints the rules dir
  local _mp="$1/.claude/plugins/marketplaces/maxxton-marketplace/plugins/${2:-developer}/rules"
  mkdir -p "$_mp/evals"; echo "# rule" > "$_mp/example.md"; echo "{}" > "$_mp/evals/example.json"
  printf '%s' "$_mp"
}

_branch_checkout() {  # $1 = fake HOME
  local _prev; _prev=$(git rev-parse HEAD)
  git commit -q --allow-empty -m "second"
  HOME="$1" bash "$HOOK" "$_prev" "$(git rev-parse HEAD)" 1 >/dev/null 2>&1 || true
}

# A real directory (not a link) holding the marketplace's current rule files.
_is_copy_of() {  # $1 = target, $2 = marketplace rules dir
  [ -d "$1" ] && [ ! -L "$1" ] && cmp -s "$1/example.md" "$2/example.md"
}

test_copy_created_on_ordinary_checkout() {
  _setup_repo
  local _fake_home; _fake_home=$(mktemp -d)
  local _mp; _mp=$(_fake_rules "$_fake_home")

  _branch_checkout "$_fake_home"

  if _is_copy_of .claude/rules/developer "$_mp" && [ ! -e .claude/rules/developer/evals ]; then
    pass "rules copied (without evals/) on ordinary branch checkout"
  else
    fail "rules not copied on ordinary checkout"
  fi
  rm -rf "$_fake_home"
  _cleanup
}

# The claude.ai org marketplace has no clone; installed_plugins.json records the
# revision, and a GitHub clone left on disk is no longer updated.
test_copy_from_org_install() {
  _setup_repo
  local _fake_home; _fake_home=$(mktemp -d)
  local _clone="$_fake_home/.claude/plugins/marketplaces/maxxton-marketplace/plugins/developer/rules"
  mkdir -p "$_clone"; echo "# stale" > "$_clone/example.md"
  local _org="$_fake_home/.claude/plugins/cache/claudeai-maxxtongroup-claude-marketplace/developer/0060"
  mkdir -p "$_org/rules"; echo "# rule" > "$_org/rules/example.md"
  printf '{ "version": 2, "plugins": { "developer@claudeai-maxxtongroup-claude-marketplace": [ { "scope": "user", "installPath": "%s" } ] } }\n' \
    "$_org" > "$_fake_home/.claude/plugins/installed_plugins.json"

  _branch_checkout "$_fake_home"

  if _is_copy_of .claude/rules/developer "$_org/rules"; then
    pass "rules copied from the org-marketplace install, not the stale clone"
  else
    fail "rules not copied from the org install (example.md: $(cat .claude/rules/developer/example.md 2>/dev/null))"
  fi
  rm -rf "$_fake_home"
  _cleanup
}

test_link_replaced_by_copy() {
  _links_supported || { skip "link replaced by a copy (platform cannot create directory links)"; return 0; }
  _setup_repo
  local _fake_home; _fake_home=$(mktemp -d)
  local _mp; _mp=$(_fake_rules "$_fake_home")
  mkdir -p .claude/rules
  _make_link "$_mp" .claude/rules/developer

  _branch_checkout "$_fake_home"

  if _is_copy_of .claude/rules/developer "$_mp" && [ -f "$_mp/example.md" ]; then
    pass "link from an earlier version replaced by a copy, target intact"
  else
    fail "link not replaced by a copy (is link: $([ -L .claude/rules/developer ] && echo yes || echo no))"
  fi
  rm -rf "$_fake_home"
  _cleanup
}

test_copy_refreshed_after_marketplace_update() {
  _setup_repo
  local _fake_home; _fake_home=$(mktemp -d)
  local _mp; _mp=$(_fake_rules "$_fake_home")
  echo "# gone upstream" > "$_mp/removed.md"
  _branch_checkout "$_fake_home"
  echo "# rule v2" > "$_mp/example.md"; rm "$_mp/removed.md"

  _branch_checkout "$_fake_home"

  if _is_copy_of .claude/rules/developer "$_mp" && [ ! -e .claude/rules/developer/removed.md ]; then
    pass "copy refreshed: changed rule updated, removed rule gone"
  else
    fail "copy not refreshed (example.md: $(cat .claude/rules/developer/example.md 2>/dev/null))"
  fi
  rm -rf "$_fake_home"
  _cleanup
}

# Session start runs the hook too; an unchanged copy must not be rebuilt, since
# another session in the same checkout could load rules mid-rebuild.
test_current_copy_left_in_place() {
  _setup_repo
  local _fake_home; _fake_home=$(mktemp -d)
  _fake_rules "$_fake_home" >/dev/null
  _branch_checkout "$_fake_home"
  echo "kept" > .claude/rules/developer/sentinel   # gone if the copy is rebuilt

  _branch_checkout "$_fake_home"

  if [ -f .claude/rules/developer/sentinel ]; then
    pass "an up-to-date copy is left in place"
  else
    fail "an up-to-date copy was rebuilt"
  fi
  rm -rf "$_fake_home"
  _cleanup
}

# What a privilege-less MSYS `ln -s` left before copies were marked: a real
# directory holding a stale subset of the marketplace files.
test_unmarked_marketplace_copy_refreshed() {
  _setup_repo
  local _fake_home; _fake_home=$(mktemp -d)
  local _mp; _mp=$(_fake_rules "$_fake_home")
  echo "# added later" > "$_mp/added-later.md"
  mkdir -p .claude/rules/developer/evals
  echo "# rule v1" > .claude/rules/developer/example.md
  echo "{}" > .claude/rules/developer/evals/example.json

  _branch_checkout "$_fake_home"

  if _is_copy_of .claude/rules/developer "$_mp" && [ -f .claude/rules/developer/added-later.md ]; then
    pass "unmarked stale marketplace copy refreshed"
  else
    fail "unmarked stale copy not refreshed (example.md: $(cat .claude/rules/developer/example.md 2>/dev/null))"
  fi
  rm -rf "$_fake_home"
  _cleanup
}

test_user_dir_with_own_file_preserved() {
  _setup_repo
  local _fake_home; _fake_home=$(mktemp -d)
  _fake_rules "$_fake_home" >/dev/null
  mkdir -p .claude/rules/developer
  echo "# mine" > .claude/rules/developer/example.md
  printf 'mine\n' > .claude/rules/developer/custom.md   # unknown to the marketplace

  _branch_checkout "$_fake_home"

  if [ "$(cat .claude/rules/developer/custom.md)" = "mine" ] && [ "$(cat .claude/rules/developer/example.md)" = "# mine" ]; then
    pass "directory holding a file unknown to the marketplace left untouched"
  else
    fail "user directory replaced or modified"
  fi
  rm -rf "$_fake_home"
  _cleanup
}

# A copy whose plugin no longer has rules here must go, or Claude keeps loading them.
test_copy_removed_after_plugin_disabled() {
  _setup_repo
  local _fake_home; _fake_home=$(mktemp -d)
  _fake_rules "$_fake_home" >/dev/null
  _fake_rules "$_fake_home" security >/dev/null
  printf '{ "enabledPlugins": { "security@maxxton-marketplace": true } }\n' | _write_settings
  _branch_checkout "$_fake_home"
  printf '{ "enabledPlugins": { "security@maxxton-marketplace": false } }\n' | _write_settings

  _branch_checkout "$_fake_home"

  if [ ! -e .claude/rules/security ] && [ -d .claude/rules/developer ]; then
    pass "copy removed once its plugin is disabled; enabled plugins kept"
  else
    fail "disabled plugin's copy left (security: $([ -e .claude/rules/security ] && echo present || echo gone); developer: $([ -d .claude/rules/developer ] && echo present || echo gone))"
  fi
  rm -rf "$_fake_home"
  _cleanup
}

# ── Parent copies (maxxton-workspace layout) ─────────────────────────────────
# Claude Code also loads .claude/rules from parent folders, so a repo inside a
# folder that already holds a copy of the same plugin's rules must not add its own:
# every extra copy loads the same rules again.

_setup_nested_repo() {  # sets _WS (the parent folder) and _REPO (a repo inside it)
  _WS=$(mktemp -d)
  _REPO="$_WS/repositories/svc"
  mkdir -p "$_REPO"; cd "$_REPO"
  git init -q
  git config user.email "test@example.com"
  git config user.name "Test User"
  git commit -q --allow-empty -m "init"
}

_marked_copy() {  # $1 = folder holding .claude/rules, $2 = plugin, $3 = example.md content
  mkdir -p "$1/.claude/rules/$2"
  echo "$3" > "$1/.claude/rules/$2/example.md"
  : > "$1/.claude/rules/$2/.copied-from-maxxton-marketplace"
}

_cleanup_nested() { cd "$_ORIG_DIR"; rm -rf "$_WS"; }

test_parent_copy_skips_nested_copy() {
  _setup_nested_repo
  local _fake_home; _fake_home=$(mktemp -d)
  _fake_rules "$_fake_home" >/dev/null
  _marked_copy "$_WS" developer "# rule"

  _branch_checkout "$_fake_home"

  if [ ! -e .claude/rules/developer ]; then pass "parent folder holds the copy → repo makes none"
  else fail "repo made its own copy although its parent folder holds one"; fi
  rm -rf "$_fake_home"; _cleanup_nested
}

test_nested_copy_removed_when_parent_has_one() {
  _setup_nested_repo
  local _fake_home; _fake_home=$(mktemp -d)
  _fake_rules "$_fake_home" >/dev/null
  _marked_copy "$_WS" developer "# rule"
  _marked_copy "$_REPO" developer "# rule"

  _branch_checkout "$_fake_home"

  if [ ! -e .claude/rules/developer ]; then pass "repo's own copy removed once its parent folder holds one"
  else fail "repo's own copy left next to the parent's"; fi
  rm -rf "$_fake_home"; _cleanup_nested
}

# A developer who only starts sessions inside the repo must still get updates.
test_stale_parent_copy_refreshed() {
  _setup_nested_repo
  local _fake_home; _fake_home=$(mktemp -d)
  local _mp; _mp=$(_fake_rules "$_fake_home")
  _marked_copy "$_WS" developer "# old rule"

  _branch_checkout "$_fake_home"

  if _is_copy_of "$_WS/.claude/rules/developer" "$_mp"; then pass "stale parent copy refreshed from the repo"
  else fail "parent copy not refreshed (example.md: $(cat "$_WS/.claude/rules/developer/example.md"))"; fi
  rm -rf "$_fake_home"; _cleanup_nested
}

test_plugin_missing_in_parent_copied_in_repo() {
  _setup_nested_repo
  local _fake_home; _fake_home=$(mktemp -d)
  _fake_rules "$_fake_home" >/dev/null
  local _sec; _sec=$(_fake_rules "$_fake_home" security)
  _marked_copy "$_WS" developer "# rule"
  printf '{ "enabledPlugins": { "security@maxxton-marketplace": true } }\n' | _write_settings

  _branch_checkout "$_fake_home"

  if _is_copy_of .claude/rules/security "$_sec" && [ ! -e .claude/rules/developer ]; then
    pass "per plugin: repo copies only what its parent folder lacks"
  else
    fail "per-plugin decision wrong (security: $([ -d .claude/rules/security ] && echo present || echo gone); developer: $([ -e .claude/rules/developer ] && echo present || echo gone))"
  fi
  rm -rf "$_fake_home"; _cleanup_nested
}

test_unmarked_parent_dir_ignored() {
  _setup_nested_repo
  local _fake_home; _fake_home=$(mktemp -d)
  local _mp; _mp=$(_fake_rules "$_fake_home")
  mkdir -p "$_WS/.claude/rules/developer"; echo "# mine" > "$_WS/.claude/rules/developer/mine.md"

  _branch_checkout "$_fake_home"

  if _is_copy_of .claude/rules/developer "$_mp" && [ "$(cat "$_WS/.claude/rules/developer/mine.md")" = "# mine" ] \
     && [ ! -e "$_WS/.claude/rules/developer/example.md" ]; then
    pass "a parent folder without our marker is a user's: untouched, repo copies its own"
  else
    fail "unmarked parent folder was used or changed"
  fi
  rm -rf "$_fake_home"; _cleanup_nested
}

test_copy_removed_after_rules_dropped_upstream() {
  _setup_repo
  local _fake_home; _fake_home=$(mktemp -d)
  local _mp; _mp=$(_fake_rules "$_fake_home")
  _branch_checkout "$_fake_home"
  rm -rf "$_mp"

  _branch_checkout "$_fake_home"

  if [ ! -e .claude/rules/developer ]; then
    pass "copy removed once the plugin ships no rules/ folder"
  else
    fail "copy left in place after the plugin dropped its rules/ folder"
  fi
  rm -rf "$_fake_home"
  _cleanup
}

test_unmarked_dir_of_other_name_preserved() {
  _setup_repo
  local _fake_home; _fake_home=$(mktemp -d)
  _fake_rules "$_fake_home" >/dev/null
  mkdir -p .claude/rules/team-standards
  printf 'mine\n' > .claude/rules/team-standards/style.md

  _branch_checkout "$_fake_home"

  if [ "$(cat .claude/rules/team-standards/style.md 2>/dev/null)" = "mine" ]; then
    pass "a user's own rules directory without the marker is kept"
  else
    fail "a user's own rules directory was removed"
  fi
  rm -rf "$_fake_home"
  _cleanup
}

test_regular_file_target_preserved() {
  _setup_repo
  local _fake_home; _fake_home=$(mktemp -d)
  _fake_rules "$_fake_home" >/dev/null
  mkdir -p .claude/rules
  printf 'user content\n' > .claude/rules/developer

  _branch_checkout "$_fake_home"

  if [ -f .claude/rules/developer ] && [ "$(cat .claude/rules/developer)" = "user content" ]; then
    pass "user-created regular file at target preserved"
  else
    fail "regular file target was modified"
  fi
  rm -rf "$_fake_home"
  _cleanup
}

# ── settings.json legacy plugin keys ──────────────────────────────────────────

_write_settings() {
  mkdir -p .claude
  cat > .claude/settings.json
}

# Hash the tracked settings file so a test can prove the hook left it
# byte-identical. `cksum` is POSIX and present on macOS, Linux and Git Bash.
_settings_sum() { cksum < .claude/settings.json; }

# Run the hook and assert .claude/settings.json is untouched. $1 = test label.
_assert_settings_untouched() {
  local _before; _before=$(_settings_sum)
  # shellcheck disable=SC2046
  bash "$HOOK" $(_clone_args) >/dev/null 2>&1 || true
  if [ "$(_settings_sum)" = "$_before" ]; then
    pass "$1"
  else
    fail "$1 — settings.json was rewritten: $(tr -d '\n ' < .claude/settings.json)"
  fi
}

test_legacy_suffix_keys_left_untouched() {
  _setup_repo
  # The pre-marketplace template's keys. They are wrong, and the toolchain check
  # says so with the corrected key — but the hook must never rewrite a TRACKED
  # file: every checkout re-dirtied the tree and `git rebase` refused to start
  # (MXTS-76871 item 3). Legacy keys are tolerated in memory instead.
  _write_settings <<'JSON'
{
  "enabledPlugins": {
    "developers@maxxton.com": true,
    "security@maxxton.com": true,
    "qa-engineer@maxxton-marketplace": true
  }
}
JSON
  _assert_settings_untouched "legacy @maxxton.com keys are left in the tracked file"
  _cleanup
}

test_plural_marketplace_key_left_untouched() {
  _setup_repo
  # The state the 2.27.2 suffix-only heal left behind on many working trees.
  _write_settings <<'JSON'
{
  "enabledPlugins": {
    "developers@maxxton-marketplace": true,
    "security@maxxton-marketplace": true
  }
}
JSON
  _assert_settings_untouched "plural developers@maxxton-marketplace key is left in the tracked file"
  _cleanup
}

test_mixed_legacy_and_canonical_left_untouched() {
  _setup_repo
  _write_settings <<'JSON'
{
  "enabledPlugins": {
    "developer@maxxton.com": true,
    "developers@maxxton.com": false,
    "developer@maxxton-marketplace": true,
    "security@maxxton.com": true
  }
}
JSON
  _assert_settings_untouched "mixed legacy + canonical keys are left in the tracked file"
  _cleanup
}

test_healthy_marketplace_keys_left_unchanged() {
  _setup_repo
  _write_settings <<'JSON'
{
  "enabledPlugins": {
    "developer@maxxton-marketplace": true,
    "security@maxxton-marketplace": false,
    "qa-engineer@maxxton-marketplace": true
  }
}
JSON
  _assert_settings_untouched "canonical keys are left byte-identical"
  _cleanup
}

test_crlf_settings_left_untouched() {
  _setup_repo
  mkdir -p .claude
  # CRLF is what Windows checkouts produce under core.autocrlf; a rewrite that
  # dropped the CRs would be a second way to dirty the tree.
  printf '{\r\n  "enabledPlugins": {\r\n    "security@maxxton.com": true\r\n  }\r\n}\r\n' > .claude/settings.json
  _assert_settings_untouched "CRLF settings.json is left byte-identical"
  _cleanup
}

test_unrelated_maxxton_com_untouched() {
  _setup_repo
  _write_settings <<'JSON'
{
  "env": { "SUPPORT_EMAIL": "developer@maxxton.com" },
  "enabledPlugins": {
    "developer@maxxton.com": true
  }
}
JSON
  _assert_settings_untouched "unrelated @maxxton.com strings and keys alike are untouched"
  _cleanup
}

test_no_settings_file_is_noop() {
  _setup_repo
  # shellcheck disable=SC2046
  bash "$HOOK" $(_clone_args) >/dev/null 2>&1 || true
  if [ ! -e .claude/settings.json ] && grep -qxF '# maxxton-marketplace' .gitignore 2>/dev/null; then
    pass "no settings.json: nothing created, rest of the hook still runs"
  else
    fail "no-settings run created a file or skipped .gitignore"
  fi
  _cleanup
}

test_readonly_settings_does_not_abort_hook() {
  _setup_repo
  mkdir -p .claude
  printf '{\n  "enabledPlugins": {\n    "security@maxxton.com": true\n  }\n}\n' > .claude/settings.json
  chmod 444 .claude/settings.json
  # shellcheck disable=SC2046
  bash "$HOOK" $(_clone_args) >/dev/null 2>&1 || true
  if grep -qxF '# maxxton-marketplace' .gitignore 2>/dev/null; then
    pass "read-only settings.json does not abort the rest of the hook"
  else
    fail ".gitignore work skipped — hook aborted on unwritable settings.json"
  fi
  chmod 644 .claude/settings.json 2>/dev/null || true
  _cleanup
}

# ── Legacy keys are still HONOURED for rule copies, just never rewritten ─────

test_legacy_suffix_key_drives_copy() {
  _setup_repo
  local _fake_home; _fake_home=$(mktemp -d)
  local _mp; _mp=$(_fake_rules "$_fake_home" security)
  _write_settings <<'JSON'
{
  "enabledPlugins": {
    "security@maxxton.com": true
  }
}
JSON
  # shellcheck disable=SC2046
  HOME="$_fake_home" bash "$HOOK" $(_clone_args) >/dev/null 2>&1 || true
  if _is_copy_of .claude/rules/security "$_mp"; then
    pass "legacy security@maxxton.com key still drives the security rules copy"
  else
    fail "legacy key did not drive the copy"
  fi
  rm -rf "$_fake_home"
  _cleanup
}

test_plural_developers_key_resolves_to_developer_once() {
  _setup_repo
  local _fake_home; _fake_home=$(mktemp -d)
  _fake_rules "$_fake_home" >/dev/null
  _write_settings <<'JSON'
{
  "enabledPlugins": {
    "developers@maxxton-marketplace": true,
    "developers@maxxton.com": true
  }
}
JSON
  # shellcheck disable=SC2046
  HOME="$_fake_home" bash "$HOOK" $(_clone_args) >/dev/null 2>&1 || true
  if [ -d .claude/rules/developer ] && [ ! -e .claude/rules/developers ]; then
    pass "plural developers keys resolve to developer; no bogus developers copy"
  else
    fail "plural alias mishandled"
  fi
  rm -rf "$_fake_home"
  _cleanup
}

test_legacy_key_false_does_not_drive_copy() {
  _setup_repo
  local _fake_home; _fake_home=$(mktemp -d)
  _fake_rules "$_fake_home" security >/dev/null
  _write_settings <<'JSON'
{
  "enabledPlugins": {
    "security@maxxton.com": false
  }
}
JSON
  # shellcheck disable=SC2046
  HOME="$_fake_home" bash "$HOOK" $(_clone_args) >/dev/null 2>&1 || true
  if [ ! -e .claude/rules/security ]; then
    pass "a legacy key set to false does not drive a rules copy"
  else
    fail "disabled legacy key drove a rules copy"
  fi
  rm -rf "$_fake_home"
  _cleanup
}

# ── Runner ────────────────────────────────────────────────────────────────────

echo "post-checkout.sh"
echo ""
echo "gitignore management"
test_gitignore_entries_on_clone
test_old_pattern_absent
test_gitignore_idempotent
test_section_header_once
test_gitignore_updated_on_ordinary_checkout
echo ""
echo "rule copies"
test_copy_created_on_ordinary_checkout
test_copy_from_org_install
test_link_replaced_by_copy
test_copy_refreshed_after_marketplace_update
test_current_copy_left_in_place
test_copy_removed_after_plugin_disabled
test_copy_removed_after_rules_dropped_upstream
test_unmarked_dir_of_other_name_preserved
test_unmarked_marketplace_copy_refreshed
test_user_dir_with_own_file_preserved
test_regular_file_target_preserved
echo ""
echo "parent copies (maxxton-workspace layout)"
test_parent_copy_skips_nested_copy
test_nested_copy_removed_when_parent_has_one
test_stale_parent_copy_refreshed
test_plugin_missing_in_parent_copied_in_repo
test_unmarked_parent_dir_ignored
echo ""
echo "settings.json legacy plugin keys (tolerated, never rewritten)"
test_legacy_suffix_keys_left_untouched
test_plural_marketplace_key_left_untouched
test_mixed_legacy_and_canonical_left_untouched
test_healthy_marketplace_keys_left_unchanged
test_crlf_settings_left_untouched
test_unrelated_maxxton_com_untouched
test_no_settings_file_is_noop
test_readonly_settings_does_not_abort_hook
test_legacy_suffix_key_drives_copy
test_plural_developers_key_resolves_to_developer_once
test_legacy_key_false_does_not_drive_copy
echo ""
echo "Results: $PASS passed, $FAIL failed, $SKIP skipped"
[ "$FAIL" -eq 0 ]
