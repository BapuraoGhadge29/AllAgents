#!/usr/bin/env bash
# Tests for git-template/hooks/_run-hooks.sh — the remote guard that decides
# whether any plugin hook runs at all. Runs on macOS, Linux, and Windows (Git Bash).
# Usage: bash tests/run-hooks.test.sh

set -uo pipefail

# The suite asserts on the guard SKIPPING, so it must not inherit the override
# from its environment. A Claude Code self-hosted runner exports
# MAXXTON_FORCE_GIT_HOOKS=1 -- the one machine where this feature is used is the
# one where an un-isolated suite would fail. Tests that need it set it per-call.
unset MAXXTON_FORCE_GIT_HOOKS

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
RUN_HOOKS="$SCRIPT_DIR/../../git-template/hooks/_run-hooks.sh"
_ORIG_DIR="$PWD"
_REPO=""

PASS=0; FAIL=0; SKIP=0

pass()      { echo "  PASS  $1"; PASS=$((PASS+1)); }
fail()      { echo "  FAIL  $1"; FAIL=$((FAIL+1)); }
skip_test() { echo "  SKIP  $1 ($2)"; SKIP=$((SKIP+1)); }

# Builds a repo whose origin is $1, plus a local .git-hooks/<name>.sh that writes
# a marker file when it runs. The marker is how we tell "the guard let us through"
# apart from "the guard exited 0 early" — which is the whole point of these tests,
# since both look identical from the exit code alone.
_setup_repo() {
  _REPO=$(mktemp -d)
  cd "$_REPO"
  git init -q
  git config user.email "test@example.com"
  git config user.name "Test User"
  git remote add origin "$1"
  mkdir -p .git-hooks
  cat > .git-hooks/pre-commit.sh <<'EOF'
#!/usr/bin/env bash
touch "$PWD/HOOK_RAN"
EOF
  chmod +x .git-hooks/pre-commit.sh
}

_cleanup() {
  cd "$_ORIG_DIR"
  rm -rf "${_REPO}"
}

# Sources _run-hooks.sh the way a real hook entry point does, in a subshell so
# its `exit` does not take the test runner with it.
_invoke() {
  ( HOOK_NAME=pre-commit; HOOK_ARGS=(); . "$RUN_HOOKS" ) </dev/null >/dev/null 2>&1
}

_ran() { [ -f "$_REPO/HOOK_RAN" ]; }

# ── Test 1: MaxxtonGroup remote → hooks run ───────────────────────────────────

test_maxxton_remote_runs() {
  _setup_repo "git@github.com:MaxxtonGroup/some-repo.git"
  _invoke
  if _ran; then pass "MaxxtonGroup remote → hooks run"
  else fail "MaxxtonGroup remote → hooks run"; fi
  _cleanup
}

# ── Test 2: foreign remote → hooks skipped ────────────────────────────────────

test_foreign_remote_skips() {
  _setup_repo "git@github.com:SomeoneElse/some-repo.git"
  _invoke
  if _ran; then fail "foreign remote → hooks skipped"
  else pass "foreign remote → hooks skipped"; fi
  _cleanup
}

# ── Test 3: the Anthropic git proxy rewrites origin, so the guard would skip ───
# This is the regression the MAXXTON_FORCE_GIT_HOOKS override exists for. Claude
# Code self-hosted runners clone through api.anthropic.com, and without the
# override every hook silently no-ops on a genuine MaxxtonGroup checkout.

test_git_proxy_remote_skips_without_override() {
  _setup_repo "https://api.anthropic.com/v1/code/git/some-session"
  _invoke
  if _ran; then fail "git-proxy remote without override → hooks skipped"
  else pass "git-proxy remote without override → hooks skipped"; fi
  _cleanup
}

test_git_proxy_remote_runs_with_override() {
  _setup_repo "https://api.anthropic.com/v1/code/git/some-session"
  MAXXTON_FORCE_GIT_HOOKS=1 _invoke
  if _ran; then pass "git-proxy remote with MAXXTON_FORCE_GIT_HOOKS=1 → hooks run"
  else fail "git-proxy remote with MAXXTON_FORCE_GIT_HOOKS=1 → hooks run"; fi
  _cleanup
}

# ── Test 4: the override is opt-in, not truthy-ish ────────────────────────────

test_override_requires_exactly_one() {
  _setup_repo "git@github.com:SomeoneElse/some-repo.git"
  MAXXTON_FORCE_GIT_HOOKS=true _invoke
  if _ran; then fail "MAXXTON_FORCE_GIT_HOOKS=true → still skipped"
  else pass "MAXXTON_FORCE_GIT_HOOKS=true → still skipped"; fi
  _cleanup
}

# ── Test 5: no origin at all → skipped, not an error ──────────────────────────

test_no_remote_skips() {
  _REPO=$(mktemp -d); cd "$_REPO"; git init -q
  mkdir -p .git-hooks
  printf '#!/usr/bin/env bash\ntouch "$PWD/HOOK_RAN"\n' > .git-hooks/pre-commit.sh
  chmod +x .git-hooks/pre-commit.sh
  _invoke
  if _ran; then fail "no origin → hooks skipped"
  else pass "no origin → hooks skipped"; fi
  _cleanup
}

# ── Plugin resolution: claude.ai org marketplace vs the GitHub clone ─────────
# A fake HOME holds a stale GitHub clone and, optionally, a claude.ai org
# install recorded in installed_plugins.json. Each copy of the plugin's
# pre-commit hook writes its own name, so the test sees which one ran.

_ORG_MP="claudeai-maxxtongroup-claude-marketplace"

# $1 = where the hook lives, $2 = the marker it writes into the repo
_fake_plugin_hook() {
  mkdir -p "$1/git-hooks"
  printf '#!/usr/bin/env bash\necho %s > "$PWD/PLUGIN_RAN"\n' "$2" > "$1/git-hooks/pre-commit.sh"
  chmod +x "$1/git-hooks/pre-commit.sh"
}

# $1 = settings key enabling the plugin, $2 = "ledger" to record an org install
_setup_plugin_home() {
  _setup_repo "git@github.com:MaxxtonGroup/some-repo.git"
  mkdir -p .claude
  printf '{ "enabledPlugins": { "%s": true } }\n' "$1" > .claude/settings.json
  _HOME=$(mktemp -d)
  _fake_plugin_hook "$_HOME/.claude/plugins/marketplaces/maxxton-marketplace/plugins/fakeplug" clone
  if [ "${2:-}" = "ledger" ]; then
    local _org="$_HOME/.claude/plugins/cache/$_ORG_MP/fakeplug/0007"
    _fake_plugin_hook "$_org" org
    printf '{ "version": 2, "plugins": { "fakeplug@%s": [ { "scope": "user", "installPath": "%s", "version": "0007" } ] } }\n' \
      "$_ORG_MP" "$_org" > "$_HOME/.claude/plugins/installed_plugins.json"
  fi
}

_plugin_ran() { cat "$_REPO/PLUGIN_RAN" 2>/dev/null || echo none; }

test_org_install_wins_over_stale_clone() {
  _setup_plugin_home "fakeplug@$_ORG_MP" ledger
  HOME="$_HOME" _invoke
  if [ "$(_plugin_ran)" = org ]; then pass "org-marketplace key → installed org version runs, not the clone"
  else fail "org-marketplace key → installed org version runs, not the clone (ran: $(_plugin_ran))"; fi
  rm -rf "$_HOME"; _cleanup
}

# Service repos still enable plugins as "<name>@maxxton-marketplace".
test_legacy_key_resolves_to_org_install() {
  _setup_plugin_home "fakeplug@maxxton-marketplace" ledger
  HOME="$_HOME" _invoke
  if [ "$(_plugin_ran)" = org ]; then pass "@maxxton-marketplace key → installed org version runs"
  else fail "@maxxton-marketplace key → installed org version runs (ran: $(_plugin_ran))"; fi
  rm -rf "$_HOME"; _cleanup
}

test_no_ledger_falls_back_to_clone() {
  _setup_plugin_home "fakeplug@maxxton-marketplace"
  HOME="$_HOME" _invoke
  if [ "$(_plugin_ran)" = clone ]; then pass "no installed_plugins.json → GitHub clone runs as before"
  else fail "no installed_plugins.json → GitHub clone runs as before (ran: $(_plugin_ran))"; fi
  rm -rf "$_HOME"; _cleanup
}

test_unreadable_ledger_falls_back_to_clone() {
  _setup_plugin_home "fakeplug@maxxton-marketplace" ledger
  echo 'not json' > "$_HOME/.claude/plugins/installed_plugins.json"
  HOME="$_HOME" _invoke
  if [ "$(_plugin_ran)" = clone ]; then pass "unreadable installed_plugins.json → GitHub clone runs"
  else fail "unreadable installed_plugins.json → GitHub clone runs (ran: $(_plugin_ran))"; fi
  rm -rf "$_HOME"; _cleanup
}

# Real ledgers hold many entries per plugin: project installs for unrelated
# folders, old revisions still on disk, and one user-scope install.
# $1 = JSON array of entries for fakeplug@<org marketplace>
_write_ledger_entries() {
  printf '{ "version": 2, "plugins": { "fakeplug@%s": %s } }\n' "$_ORG_MP" "$1" \
    > "$_HOME/.claude/plugins/installed_plugins.json"
}

_org_rev() {  # $1 = revision, $2 = marker its hook writes; prints its installPath
  local _dir="$_HOME/.claude/plugins/cache/$_ORG_MP/fakeplug/$1"
  _fake_plugin_hook "$_dir" "$2"
  printf '%s' "$_dir"
}

test_user_scope_wins_over_unrelated_project_entry() {
  _setup_plugin_home "fakeplug@maxxton-marketplace"
  local _old _user
  _old=$(_org_rev 0001 old); _user=$(_org_rev 0007 user)
  _write_ledger_entries "[ { \"scope\": \"project\", \"projectPath\": \"/elsewhere/other-repo\", \"installPath\": \"$_old\" },
                           { \"scope\": \"user\", \"installPath\": \"$_user\" } ]"
  HOME="$_HOME" _invoke
  if [ "$(_plugin_ran)" = user ]; then pass "user-scope entry wins over an unrelated project entry listed first"
  else fail "user-scope entry wins over an unrelated project entry listed first (ran: $(_plugin_ran))"; fi
  rm -rf "$_HOME"; _cleanup
}

test_project_entry_for_this_repo_wins() {
  _setup_plugin_home "fakeplug@maxxton-marketplace"
  local _user _proj
  _user=$(_org_rev 0007 user); _proj=$(_org_rev 0006 project)
  _write_ledger_entries "[ { \"scope\": \"user\", \"installPath\": \"$_user\" },
                           { \"scope\": \"project\", \"projectPath\": \"$_REPO\", \"installPath\": \"$_proj\" } ]"
  HOME="$_HOME" _invoke
  if [ "$(_plugin_ran)" = project ]; then pass "project entry for this repo wins over the user-scope one"
  else fail "project entry for this repo wins over the user-scope one (ran: $(_plugin_ran))"; fi
  rm -rf "$_HOME"; _cleanup
}

test_plugin_missing_from_ledger_uses_clone() {
  _setup_plugin_home "fakeplug@maxxton-marketplace" ledger
  printf '{ "version": 2, "plugins": { "otherplug@%s": [] } }\n' "$_ORG_MP" > "$_HOME/.claude/plugins/installed_plugins.json"
  HOME="$_HOME" _invoke
  if [ "$(_plugin_ran)" = clone ]; then pass "plugin missing from installed_plugins.json → GitHub clone runs"
  else fail "plugin missing from installed_plugins.json → GitHub clone runs (ran: $(_plugin_ran))"; fi
  rm -rf "$_HOME"; _cleanup
}

test_no_python_uses_clone() {
  _setup_plugin_home "fakeplug@maxxton-marketplace" ledger
  local _stubs; _stubs=$(mktemp -d)
  for _p in python3 python py; do printf '#!/bin/sh\nexit 1\n' > "$_stubs/$_p"; chmod +x "$_stubs/$_p"; done
  HOME="$_HOME" PATH="$_stubs:$PATH" _invoke
  if [ "$(_plugin_ran)" = clone ]; then pass "no working Python 3 → GitHub clone runs, hook does not fail"
  else fail "no working Python 3 → GitHub clone runs (ran: $(_plugin_ran))"; fi
  rm -rf "$_HOME" "$_stubs"; _cleanup
}

echo ""
echo "_run-hooks.sh remote guard"
test_maxxton_remote_runs
test_foreign_remote_skips
test_git_proxy_remote_skips_without_override
test_git_proxy_remote_runs_with_override
test_override_requires_exactly_one
test_no_remote_skips
echo ""
echo "_run-hooks.sh plugin resolution"
test_org_install_wins_over_stale_clone
test_legacy_key_resolves_to_org_install
test_no_ledger_falls_back_to_clone
test_unreadable_ledger_falls_back_to_clone
test_user_scope_wins_over_unrelated_project_entry
test_project_entry_for_this_repo_wins
test_plugin_missing_from_ledger_uses_clone
test_no_python_uses_clone
echo ""
echo "Results: $PASS passed, $FAIL failed, $SKIP skipped"
[ "$FAIL" -eq 0 ]
