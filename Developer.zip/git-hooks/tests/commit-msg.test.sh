#!/usr/bin/env bash
# Tests for git-hooks/commit-msg.sh
# Usage: bash tests/commit-msg.test.sh
set -uo pipefail

HOOK="$(cd "$(dirname "$0")/.." && pwd)/commit-msg.sh"
FIXTURES="$(dirname "$0")/fixtures"

pass=0
fail=0

assert_exit() {
  local description="$1"
  local fixture="$2"
  local expected="$3"   # 0 = should pass, 1 = should fail

  actual_exit=0
  bash "$HOOK" "${FIXTURES}/${fixture}" > /dev/null 2>&1 || actual_exit=$?

  if [ "$actual_exit" -eq "$expected" ]; then
    echo "  PASS  $description"
    pass=$((pass + 1))
  else
    echo "  FAIL  $description (expected exit $expected, got $actual_exit)"
    fail=$((fail + 1))
  fi
}

assert_exit_raw() {
  local description="$1"
  local path="$2"
  local expected="$3"

  actual_exit=0
  bash "$HOOK" "$path" > /dev/null 2>&1 || actual_exit=$?

  if [ "$actual_exit" -eq "$expected" ]; then
    echo "  PASS  $description"
    pass=$((pass + 1))
  else
    echo "  FAIL  $description (expected exit $expected, got $actual_exit)"
    fail=$((fail + 1))
  fi
}

echo "commit-msg.sh"
echo ""
echo "valid commit messages"
assert_exit "direct Jira ticket (MXTS-1234: ...)"        valid-direct.txt            0
assert_exit "other project key (MCMS-42: ...)"            valid-mcms.txt              0
assert_exit "conventional prefix (feat: MXTS-1234: ...)"  valid-conventional.txt      0
assert_exit "scoped prefix (feat(cli): MXTS-99: ...)"     valid-conventional-scope.txt 0
assert_exit "subject with git comment lines stripped"      valid-with-comments.txt     0

echo ""
echo "file access errors"
assert_exit_raw "non-existent file"  "/tmp/no-such-file-$$"  1
assert_exit_raw "no argument given"  ""                       1

echo ""
echo "invalid commit messages"
assert_exit "no ticket reference at all"   invalid-no-ticket.txt    1
assert_exit "zero ticket MXTS-0"           invalid-zero-single.txt  1
assert_exit "zero ticket MXTS-00"          invalid-zero-double.txt  1
assert_exit "zero ticket MXTS-0000"        invalid-zero-quad.txt    1
assert_exit "zero ticket MCMS-0000"        invalid-zero-mcms.txt    1
assert_exit "only comment lines"           invalid-only-comments.txt 1

assert_exit_on_branch() {
  local description="$1" branch="$2" fixture="$3" expected="$4"
  local repo fixture_path
  fixture_path="$(cd "$FIXTURES" && pwd)/${fixture}"
  repo=$(mktemp -d)
  git -C "$repo" init -q
  git -C "$repo" checkout -q -b "$branch" 2>/dev/null || git -C "$repo" switch -q -c "$branch"

  actual_exit=0
  (cd "$repo" && bash "$HOOK" "$fixture_path") > /dev/null 2>&1 || actual_exit=$?
  rm -rf "$repo"

  if [ "$actual_exit" -eq "$expected" ]; then
    echo "  PASS  $description"
    pass=$((pass + 1))
  else
    echo "  FAIL  $description (expected exit $expected, got $actual_exit)"
    fail=$((fail + 1))
  fi
}

echo ""
echo "branch exemptions"
assert_exit_on_branch "combined-prs-branch needs no ticket"   combined-prs-branch          invalid-no-ticket.txt 0
assert_exit_on_branch "other bot branch still needs a ticket" dependabot/npm_and_yarn/foo   invalid-no-ticket.txt 1

echo ""
total=$((pass + fail))
echo "$pass/$total tests passed"
[ "$fail" -eq 0 ]
