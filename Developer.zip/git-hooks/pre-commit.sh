#!/usr/bin/env bash
set -euo pipefail

# Reject direct commits on protected branches
_current_branch=$(git symbolic-ref --short HEAD 2>/dev/null || echo "")
case "$_current_branch" in
  main|master|develop)
    echo "[pre-commit] ERROR: Direct commits to '$_current_branch' are not allowed." >&2
    echo "" >&2
    echo "[CLAUDE:INFO] Do NOT use --no-verify to bypass this check." >&2
    echo "[CLAUDE:INFO] Use /starting-ticket-branch to create an appropriate branch and continue." >&2
    exit 1
    ;;
  release/*)
    echo "[pre-commit] ERROR: Direct commits to release branch '$_current_branch' are not allowed." >&2
    echo "" >&2
    echo "[CLAUDE:INFO] Do NOT use --no-verify to bypass this check." >&2
    echo "[CLAUDE:INFO] Use /starting-ticket-branch to create an appropriate branch and continue." >&2
    exit 1
    ;;
esac

# Validate branch naming convention (only for named, non-protected branches)
# Allowed: (feature|bugfix|hotfix)/<TICKET> or (feature|bugfix|hotfix)/<TICKET>-description
# combined-prs-branch is the bot-owned Dependabot combined PR; /reviewing-dependabot-pr commits there unattended.
if [ -n "$_current_branch" ] && [ "$_current_branch" != "combined-prs-branch" ]; then
  if ! echo "$_current_branch" | grep -qE '^(feature|bugfix|hotfix)/[A-Z]{2,}-[1-9][0-9]*(-.+)?$'; then
    echo "[pre-commit] ERROR: Branch name '$_current_branch' does not follow naming conventions." >&2
    echo "" >&2
    echo "  Expected formats:" >&2
    echo "    feature/<ticket>               e.g. feature/MXTS-1234" >&2
    echo "    bugfix/<ticket>                e.g. bugfix/MXTS-1234" >&2
    echo "    hotfix/<ticket>                e.g. hotfix/MXTS-1234" >&2
    echo "    feature/<ticket>-description   e.g. feature/MXTS-1234-fix-login" >&2
    echo "" >&2
    echo "[CLAUDE:INFO] Do NOT use --no-verify to bypass this check." >&2
    if echo "$_current_branch" | grep -qE '[A-Z]{2,}-[1-9][0-9]+'; then
      echo "[CLAUDE:INFO] A ticket number is present but the branch name is not correctly formatted." >&2
      echo "[CLAUDE:INFO] Use /starting-ticket-branch to rename/recreate the branch with the correct format." >&2
    else
      echo "[CLAUDE:INFO] No Jira ticket number found in the branch name." >&2
      echo "[CLAUDE:ASK] Do you have a Jira ticket number for this work? If yes, provide it so I can create a correctly named branch with /starting-ticket-branch. If not, I can create one first with /global:creating-jira-tickets." >&2
    fi
    exit 1
  fi
fi

_GITLEAKS_VERSION="8.30.1"
_GITLEAKS_DIR="${HOME}/.gitleaks"
case "$(uname -s 2>/dev/null)" in
  MINGW*|MSYS*|CYGWIN*) _GITLEAKS_BIN="${_GITLEAKS_DIR}/gitleaks.exe" ;;
  *)                     _GITLEAKS_BIN="${_GITLEAKS_DIR}/gitleaks"     ;;
esac

_install_gitleaks() {
  local _os _arch _os_tag _arch_tag _ext _url _checksums_url _tmpdir _expected _actual

  _os=$(uname -s 2>/dev/null || echo "")
  _arch=$(uname -m 2>/dev/null || echo "")

  case "$_arch" in
    x86_64|amd64)    _arch_tag="x64"   ;;
    aarch64|arm64)   _arch_tag="arm64" ;;
    armv*|arm)       _arch_tag="arm32" ;;
    i*86)            _arch_tag="x32"   ;;
    *) echo "[pre-commit] Unsupported architecture: ${_arch}" >&2; return 1 ;;
  esac

  case "$_os" in
    Darwin)               _os_tag="darwin";  _ext="tar.gz" ;;
    Linux)                _os_tag="linux";   _ext="tar.gz" ;;
    MINGW*|MSYS*|CYGWIN*) _os_tag="windows"; _ext="zip"   ;;
    *) echo "[pre-commit] Unsupported OS: ${_os}" >&2; return 1 ;;
  esac

  _url="https://github.com/gitleaks/gitleaks/releases/download/v${_GITLEAKS_VERSION}/gitleaks_${_GITLEAKS_VERSION}_${_os_tag}_${_arch_tag}.${_ext}"
  _checksums_url="https://github.com/gitleaks/gitleaks/releases/download/v${_GITLEAKS_VERSION}/gitleaks_${_GITLEAKS_VERSION}_checksums.txt"

  _tmpdir=$(mktemp -d)
  # shellcheck disable=SC2064
  trap "rm -rf '${_tmpdir}'" RETURN

  echo "[pre-commit] Downloading gitleaks v${_GITLEAKS_VERSION} (${_os_tag}/${_arch_tag})..."
  if ! curl -fsSL "${_url}" -o "${_tmpdir}/archive.${_ext}"; then
    echo "[pre-commit] ERROR: Download failed: ${_url}" >&2
    return 1
  fi

  # Verify checksum before extracting
  if ! curl -fsSL "${_checksums_url}" -o "${_tmpdir}/checksums.txt"; then
    echo "[pre-commit] ERROR: Failed to download checksums: ${_checksums_url}" >&2
    return 1
  fi
  _expected=$(grep "gitleaks_${_GITLEAKS_VERSION}_${_os_tag}_${_arch_tag}.${_ext}" "${_tmpdir}/checksums.txt" | awk '{print $1}')
  if [ -z "${_expected}" ]; then
    echo "[pre-commit] ERROR: Could not find expected checksum in checksums.txt" >&2
    return 1
  fi
  if command -v sha256sum >/dev/null 2>&1; then
    _actual=$(sha256sum "${_tmpdir}/archive.${_ext}" | awk '{print $1}')
  elif command -v shasum >/dev/null 2>&1; then
    _actual=$(shasum -a 256 "${_tmpdir}/archive.${_ext}" | awk '{print $1}')
  else
    echo "[pre-commit] ERROR: No SHA256 tool found (need sha256sum or shasum)" >&2
    return 1
  fi
  if [ "${_actual}" != "${_expected}" ]; then
    echo "[pre-commit] ERROR: Checksum mismatch — binary may be tampered with." >&2
    echo "[pre-commit]   expected: ${_expected}" >&2
    echo "[pre-commit]   actual:   ${_actual}" >&2
    return 1
  fi

  if ! mkdir -p "${_GITLEAKS_DIR}"; then
    echo "[pre-commit] ERROR: Could not create ${_GITLEAKS_DIR}" >&2
    return 1
  fi
  if [ "${_ext}" = "tar.gz" ]; then
    if ! tar -xzf "${_tmpdir}/archive.${_ext}" -C "${_GITLEAKS_DIR}" gitleaks; then
      echo "[pre-commit] ERROR: Extraction failed" >&2
      return 1
    fi
  else
    if ! unzip -q "${_tmpdir}/archive.${_ext}" "gitleaks.exe" -d "${_GITLEAKS_DIR}"; then
      echo "[pre-commit] ERROR: Extraction failed" >&2
      return 1
    fi
  fi
  if ! chmod +x "${_GITLEAKS_BIN}"; then
    echo "[pre-commit] ERROR: chmod failed on ${_GITLEAKS_BIN}" >&2
    return 1
  fi
}

if [ ! -x "${_GITLEAKS_BIN}" ]; then
  echo "[pre-commit] gitleaks not found — attempting installation..."
  if ! _install_gitleaks; then
    echo "[pre-commit] ERROR: Could not install gitleaks automatically." >&2
    echo "[pre-commit] Download manually: https://github.com/gitleaks/gitleaks/releases/tag/v${_GITLEAKS_VERSION}" >&2
    exit 1
  fi
  echo "[pre-commit] gitleaks v${_GITLEAKS_VERSION} installed to ${_GITLEAKS_DIR}."
fi

"${_GITLEAKS_BIN}" protect --staged --exit-code 1
