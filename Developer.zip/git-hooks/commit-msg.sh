#!/usr/bin/env bash
# Validates that the commit subject contains a Jira ticket number.
# Called via _run-hooks.sh; $1 = path to temporary commit message file.
set -euo pipefail

COMMIT_MSG_FILE="${1:-}"
[ -n "$COMMIT_MSG_FILE" ] || { echo "commit-msg.sh: no commit message file provided" >&2; exit 1; }
[ -f "$COMMIT_MSG_FILE" ] || { echo "commit-msg.sh: commit message file not found: $COMMIT_MSG_FILE" >&2; exit 1; }
[ -r "$COMMIT_MSG_FILE" ] || { echo "commit-msg.sh: commit message file not readable: $COMMIT_MSG_FILE" >&2; exit 1; }

# First non-empty, non-comment line = subject
subject=$(grep -v '^#' "$COMMIT_MSG_FILE" | grep -m1 '.' || true)

# The Dependabot combined PR has no ticket; see the matching exemption in pre-commit.sh.
if [ "$(git symbolic-ref --short HEAD 2>/dev/null || true)" = "combined-prs-branch" ]; then
  exit 0
fi

# Require a Jira ticket with a non-zero number: PROJECT-<1-9><digits>
# Handles: MXTS-1234: ..., feat: MXTS-1234: ..., feat(cli): MXTS-1234: ...
if echo "$subject" | grep -qE '[A-Z]{2,}-[1-9][0-9]*'; then
  exit 0
fi

echo "commit message must include a Jira ticket number (e.g. MXTS-1234 or MCMS-42)." >&2
echo "" >&2
echo "  Allowed formats:" >&2
echo "    MXTS-1234: your message" >&2
echo "    feat: MXTS-1234: your message" >&2
echo "    feat(cli): MXTS-1234: your message" >&2
echo "" >&2
echo "  Zero ticket numbers (MXTS-0, MXTS-000, MXTS-0000) are not allowed." >&2
echo "" >&2
echo "  Got: $subject" >&2
echo "" >&2
echo "[CLAUDE:INFO] Do NOT generate, invent, or fabricate a Jira ticket number." >&2
echo "[CLAUDE:ASK] A Jira ticket is required for this commit. Do you have a ticket number? If not, I can create one via /global:creating-jira-tickets." >&2
echo "[CLAUDE:INFO] If a plan file exists at ~/.claude/plans/, offer to use it as the ticket title/description." >&2
echo "[CLAUDE:INFO] After the ticket is created, prepend the ticket number to the commit message and retry." >&2
exit 1
