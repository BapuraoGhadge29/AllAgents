#!/usr/bin/env bash
set -euo pipefail

_prev_head="${1:-}"
_repo_root=$(git rev-parse --show-toplevel 2>/dev/null) || exit 0

# Rule copies and required .gitignore entries are refreshed on every branch
# checkout (the entry point already skips file checkouts via $3 == 0), and the
# developer SessionStart hook runs this script too, so a plugin update reaches
# the copies without a checkout. All of the work below is idempotent, and
# .gitignore entries are guarded by grep -qxF.
#
# This hook never writes to .claude/settings.json. That file is TRACKED in every
# service repo, so the former "heal" that rewrote legacy enabledPlugins keys in it
# re-dirtied the working tree on every checkout and made `git rebase` refuse to
# start (MXTS-76871, item 3). Legacy keys ("<name>@maxxton.com", or the plural
# "developers") are instead tolerated in memory by _plugins_with_rules below and
# by _enabled_plugins in git-template/hooks/_run-hooks.sh; the repo-side rename to
# the canonical "<name>@maxxton-marketplace" is a normal PR, and the workspace's
# gate6-toolchain-check.py prints the corrected key.
_rules_dir="${_repo_root}/.claude/rules"

# Resolve a working Python 3 interpreter across macOS/Linux/Windows (Git Bash).
# Order: python3 → python → "py -3". Each candidate is *run*, not just
# `command -v`-checked, so the Windows Store alias stub is rejected.
resolve_python() {
  local _cand
  for _cand in python3 python "py -3"; do
    if $_cand -c 'import sys; sys.exit(0 if sys.version_info[0] == 3 else 1)' >/dev/null 2>&1; then
      printf '%s\n' "$_cand"; return 0
    fi
  done
  return 1
}

# Prints "<name><TAB><installPath>" per plugin installed from the claude.ai org
# marketplace. It has no clone under marketplaces/, so installed_plugins.json is
# the only record of the installed revision. Keep in step with
# git-template/hooks/_run-hooks.sh.
_org_plugin_dirs() {
  local _ledger="${HOME}/.claude/plugins/installed_plugins.json" _py
  [ -f "$_ledger" ] || return 0
  _py=$(resolve_python) || return 0
  local -a _py_cmd
  read -r -a _py_cmd <<< "$_py"
  "${_py_cmd[@]}" - "$_ledger" "$_repo_root" 2>/dev/null <<'PY' || true
import json, os, sys
suffix = "@claudeai-maxxtongroup-claude-marketplace"
repo = os.path.realpath(sys.argv[2]) if sys.argv[2] else ""

def live(entry):
    return isinstance(entry, dict) and os.path.isdir(entry.get("installPath") or "")

def for_this_repo(entry):
    """A project install applies to its own folder and the folders inside it."""
    if entry.get("scope") not in ("project", "local") or not repo:
        return False
    root = os.path.realpath(entry.get("projectPath") or "/nonexistent")
    return repo == root or repo.startswith(root.rstrip(os.sep) + os.sep)

def pick(entries):
    """The nearest project install for this repo, else the user install. Ledgers keep
    old project installs for other folders, so the first entry can be any revision."""
    installed = [e for e in entries if live(e)]
    project = [e for e in installed if for_this_repo(e)]
    if project:
        return max(project, key=lambda e: len(e["projectPath"]))
    return next((e for e in installed if e.get("scope") == "user"), None)

try:
    with open(sys.argv[1], encoding="utf-8") as f:
        plugins = json.load(f).get("plugins") or {}
except (OSError, ValueError, AttributeError):
    sys.exit(0)
for key, entries in plugins.items():
    chosen = pick(entries or []) if key.endswith(suffix) else None
    if chosen:
        print(key[: -len(suffix)] + "\t" + chosen["installPath"])
PY
}

_org_dirs=$(_org_plugin_dirs)

# The org install wins: when both exist, the GitHub clone is the one Claude Code
# no longer updates (it stays on disk after its marketplace is removed).
_plugin_dir() {
  local _dir
  _dir=$(printf '%s\n' "$_org_dirs" | awk -F'\t' -v n="$1" '$1 == n { print $2; exit }')
  # On Windows installPath is native (C:\...); Git Bash file tests need its POSIX form.
  if [ -n "$_dir" ] && command -v cygpath >/dev/null 2>&1; then
    _dir=$(cygpath -u "$_dir")
  fi
  printf '%s\n' "${_dir:-${HOME}/.claude/plugins/marketplaces/maxxton-marketplace/plugins/$1}"
}

# Returns plugin names to copy rules for, one per line.
# developer is always included; other plugins only if explicitly enabled (`true`).
# Legacy keys are tolerated in memory: the pre-marketplace "<name>@maxxton.com"
# suffix counts like "@maxxton-marketplace", and the alias "developers" (one legacy
# template's plural) resolves to "developer". The settings file itself is never
# modified — see the header. Uses bash 3 / POSIX grep+sed only (no jq). Keep this
# in step with _enabled_plugins in git-template/hooks/_run-hooks.sh.
_plugins_with_rules() {
  printf 'developer\n'
  local _settings="${_repo_root}/.claude/settings.json"
  [ -f "$_settings" ] || return 0
  grep -oE '"[A-Za-z0-9_-]+@(maxxton\.com|maxxton-marketplace|claudeai-maxxtongroup-claude-marketplace)"[[:space:]]*:[[:space:]]*true' "$_settings" 2>/dev/null |
    sed 's/@[^"]*".*$//; s/^"//; s/^developers$/developer/' |
    LC_ALL=C sort -u |
    grep -v '^developer$'
}

# Copies, not links: Claude Code treats a link out of the repo as an external
# import, which loads nothing until approved and never loads a `paths:` rule.
# Earlier versions linked (a junction on Windows); those links are replaced.
_marker=".copied-from-maxxton-marketplace"

# True when $1 is a real directory whose every file also exists by name under
# $2 — the signature of a copy left by a privilege-less MSYS `ln -s` before the
# marker existed (a stale one still qualifies: outdated or missing files, never
# extra ones). A directory holding anything the marketplace does not know is a
# user's and is never touched.
_is_marketplace_copy() {
  { [ -d "$1" ] && [ ! -L "$1" ]; } || return 1
  local _f
  while IFS= read -r _f; do
    [ -n "$_f" ] || continue
    [ -e "$2/$_f" ] || return 1
  done < <(cd "$1" && find . -type f 2>/dev/null)
  return 0
}

# True when our copy $1 holds exactly the rule files of $2. Session start runs
# this hook too, and a rebuild would leave another session in this checkout
# without rules for a moment.
_copy_is_current() {
  [ -f "$1/$_marker" ] || return 1
  local _rule
  for _rule in "$2"/*.md; do
    [ -f "$_rule" ] || continue
    cmp -s "$_rule" "$1/${_rule##*/}" || return 1
  done
  for _rule in "$1"/*.md; do
    [ -f "$_rule" ] || continue
    [ -f "$2/${_rule##*/}" ] || return 1
  done
  return 0
}

# Makes $1 a current copy of the rules in $2. Fails, touching nothing, when $1
# is a user's: a regular file, or a directory that is not our copy.
_refresh_copy() {
  local _target="$1" _source="$2" _rule
  if [ ! -L "$_target" ] && _copy_is_current "$_target" "$_source"; then
    return 0
  elif [ -L "$_target" ]; then
    # `rm -f` on a junction unlinks it without touching the target.
    rm -f "$_target"
  elif [ -e "$_target" ]; then
    [ -f "$_target/$_marker" ] || _is_marketplace_copy "$_target" "$_source" || return 1
    rm -rf "$_target"
  fi
  mkdir -p "$_target"
  # Only the rule files: evals/ and other folders are not rules.
  for _rule in "$_source"/*.md; do
    [ -f "$_rule" ] && cp "$_rule" "$_target/"
  done
  : > "$_target/$_marker"
}

# Prints our copy of plugin $1's rules in the nearest folder above the repo.
# Claude Code loads .claude/rules from parent folders too, so in a workspace
# that holds repos (maxxton-workspace) a copy per repo loads the rules again.
_parent_copy() {
  local _dir _up
  _dir=$(dirname "$_repo_root")
  while :; do
    if [ -f "$_dir/.claude/rules/$1/$_marker" ] && [ ! -L "$_dir/.claude/rules/$1" ]; then
      printf '%s\n' "$_dir/.claude/rules/$1"
      return 0
    fi
    _up=$(dirname "$_dir")
    [ "$_up" != "$_dir" ] || return 1
    _dir=$_up
  done
}

# Plugins whose copy is current after the loop, space-separated (bash 3: no maps).
_kept=" "

while IFS= read -r _plugin; do
  [ -n "$_plugin" ] || continue
  _plugin_rules="$(_plugin_dir "$_plugin")/rules"
  [ -d "$_plugin_rules" ] || continue
  # Covered by a parent copy: refresh that one, so sessions started only inside
  # this repo still get updates; the repo's own copy, if any, goes below.
  if _parent=$(_parent_copy "$_plugin"); then
    _refresh_copy "$_parent" "$_plugin_rules" || true
    continue
  fi
  _refresh_copy "${_rules_dir}/${_plugin}" "$_plugin_rules" || continue
  _kept="${_kept}${_plugin} "
done < <(_plugins_with_rules)

# A marked copy the loop did not keep belongs to a plugin that is now disabled
# or ships no rules/ any more; left in place, Claude would keep loading it.
if [ -d "$_rules_dir" ]; then
  for _copy in "$_rules_dir"/*/; do
    _copy="${_copy%/}"
    { [ ! -L "$_copy" ] && [ -f "$_copy/$_marker" ]; } || continue
    case "$_kept" in
      *" ${_copy##*/} "*) ;;
      *) rm -rf "$_copy" ;;
    esac
  done
fi

# Ensure required .gitignore entries are present, appending any that are missing.
_gitignore="${_repo_root}/.gitignore"
_required_entries=(
  '!.omc/'
  '.omc/*'
  '!.omc/skills/'
  '!.omc/skills/**'
  '.claude/rules/*'
  '!.claude/rules/*.md'
  # .rules-synced is no longer written (the first-run gate that created it was
  # removed in 2.11.0) — kept here so the leftover file stays ignored in repos
  # that were set up by an earlier version.
  '.claude/.rules-synced'
  '.claude/worktrees/'
  '.claude/settings.local.json'
  'CLAUDE.local.md'
)
_section_header='# maxxton-marketplace'
_need_header=true
for _entry in "${_required_entries[@]}"; do
  grep -qxF "$_entry" "$_gitignore" 2>/dev/null && continue
  if [ "$_need_header" = "true" ]; then
    if ! grep -qxF "$_section_header" "$_gitignore" 2>/dev/null; then
      # Only prepend a blank separator line when the file already has content
      [ -s "$_gitignore" ] && printf '\n' >> "$_gitignore"
      printf '%s\n' "$_section_header" >> "$_gitignore"
    fi
    _need_header=false
  fi
  printf '%s\n' "$_entry" >> "$_gitignore"
done

# Dependency installation (npm/pnpm/python) is intentionally NOT done here.
# It is handled lazily and scoped by the post-edit hooks
# (plugins/{typescript,python}/hooks/format-on-write.sh) and the pre-commit hooks
# (plugins/{typescript,python}/git-hooks/pre-commit.sh), which install deps for the
# package/module of the file being edited or staged rather than scanning the whole
# repo on every checkout.
