#!/usr/bin/env bash
# Resolves the local SQLcl install (Oracle SQL Developer VS Code extension,
# a native/Homebrew install, or SQLCL_HOME) and execs it in MCP mode.
# Called by .mcp.json via bare $CLAUDE_PLUGIN_ROOT so the launch command stays
# a fixed literal string across machines — see CLAUDE.md's allowedMcpServers
# section for why that matters for the managed-settings allowlist.
set -euo pipefail

is_sqlcl() {
  "$1" -V 2>&1 | grep -qi "SQLcl"
}

resolve_sql() {
  if [ -n "${SQLCL_HOME:-}" ] && [ -x "$SQLCL_HOME/bin/sql" ] && is_sqlcl "$SQLCL_HOME/bin/sql"; then
    printf '%s\n' "$SQLCL_HOME/bin/sql"; return 0
  fi

  local _on_path
  _on_path=$(command -v sql 2>/dev/null || true)
  if [ -n "$_on_path" ] && is_sqlcl "$_on_path"; then
    printf '%s\n' "$_on_path"; return 0
  fi

  # Compare by the extension directory's version segment (e.g. 26.2.0), not
  # lexicographically by path — otherwise a future "3.0.0" would sort ahead
  # of "26.2.0" as a string even though 26.2.0 is the newer release.
  local _ext _dir _ver _best="" _best_ver=""
  for _ext in "$HOME"/.vscode/extensions/oracle.sql-developer-*/dbtools/sqlcl/bin/sql \
              "$HOME"/.vscode-server/extensions/oracle.sql-developer-*/dbtools/sqlcl/bin/sql; do
    [ -x "$_ext" ] || continue
    _dir=$(basename "$(dirname "$(dirname "$(dirname "$_ext")")")")  # oracle.sql-developer-26.2.0-darwin-arm64
    _ver="${_dir#oracle.sql-developer-}"                            # 26.2.0-darwin-arm64
    _ver="${_ver%%-*}"                                               # 26.2.0
    if [ -z "$_best_ver" ] || [ "$(printf '%s\n%s\n' "$_best_ver" "$_ver" | sort -V | tail -1)" = "$_ver" ]; then
      _best_ver="$_ver"
      _best="$_ext"
    fi
  done
  if [ -n "$_best" ]; then
    printf '%s\n' "$_best"; return 0
  fi

  return 1
}

SQL_BIN=$(resolve_sql) || {
  printf '{"jsonrpc":"2.0","id":null,"error":{"code":-32000,"message":"sqlcl: no SQLcl install found (tried SQLCL_HOME, PATH, oracle.sql-developer VS Code extension)"}}\n' >&2
  exit 1
}
exec "$SQL_BIN" -mcp
