# developer

The `developer` plugin distributes git hooks and Claude rules to every MaxxtonGroup repo automatically. Plugin contributors can extend both by dropping files into their own plugin directory — no per-repo changes needed.

Git hooks are installed automatically when a developer runs `git clone` on any MaxxtonGroup repo — no manual setup needed per repo. The developer plugin's `SessionStart` hook configures `git config --global init.templateDir` automatically and self-heals it if it ever points at a stale or transient path. Rules are copied into `.claude/rules/<plugin>/` and refreshed on every checkout and session start. The dispatcher that runs all hooks silently skips non-MaxxtonGroup repos, so personal forks and local-only repos are unaffected.

## Adding a rule to your plugin

Drop a `.md` file under `plugins/<your-plugin>/rules/`. It is copied into `.claude/rules/<your-plugin>/` in every repo where your plugin is enabled — on the next checkout, worktree creation or Claude Code session start.

## Adding a git hook to your plugin

Drop an executable shell script at `plugins/<your-plugin>/git-hooks/<event>.sh`, where `<event>` is one of: `pre-commit`, `commit-msg`, `pre-push`, `post-checkout`. It runs in every enabled repo automatically.

Plugin hook scripts are loaded from the live install path at hook time, so they update automatically. The dispatcher entry points (`_run-hooks.sh` and the four hooks) are copied into a repo's `.git/hooks/` on clone; the `SessionStart` hook reinstalls them into the current repo if any are missing, and replaces an outdated `_run-hooks.sh`.

## Adding a Claude Code hook to your plugin

Drop a `hooks/hooks.json` in your plugin directory following the [Claude Code hooks spec](https://code.claude.com/docs/en/hooks). Claude Code loads it automatically when the plugin is enabled.

## References

- [ADR-001](docs/adr/ADR-001-git-hook-distribution.md) — rationale for the hook distribution model
