---
name: writing-okrs
description: "Author, review, score, or improve OKRs (objectives & key results) in Maxxton's house format. Use when someone says \"write our OKRs\", \"review these OKRs\", or \"are these good key results?\".\n"
allowed-tools:
- Read
- mcp__claude_ai_Atlassian_MCP__getAccessibleAtlassianResources
- mcp__claude_ai_Atlassian_MCP__searchConfluence
- mcp__claude_ai_Atlassian_MCP__getConfluenceContent
- mcp__claude_ai_Atlassian_MCP__createConfluenceContent
- mcp__claude_ai_Atlassian_MCP__updateConfluenceContent
- mcp__claude_ai_Atlassian_MCP__discover
- mcp__claude_ai_Atlassian_MCP__executeRead
disable-model-invocation: true
---

# Writing OKRs

Author and validate OKRs in Maxxton's house format using modern OKR rules.
This file is the procedure. Load reference files only where a step says to.

## Step 1 — Pick the mode
- User pasted, or points to, a draft → **Validate**.
- Nothing yet → **Author**.
- Ambiguous → ask once: "Do you have a draft, or are we starting fresh?"

## Step 2 — Load the playbook
Read `references/okr-playbook.md` once. It holds the rubric, the house table
format, and the scoring scale — everything a normal run needs.

## The judgment that matters most: outcome vs output
Test every Key Result: **"If I fully completed this and the business metric
didn't move, did I still succeed?"** If yes, it's an *output* → it is an
**Initiative**, not a KR. The metric goes in Key Results; the work goes in
Current status as Initiative 1 / 2 / 3. Most bad KRs fail this test.

## Validate
1. Grade each Objective and Key Result **pass / weak / fail** against the
   rubric, with a one-line reason each.
2. List the top 3 fixes, most impactful first.
3. Emit a rewritten version in the house table.

When the draft is missing a baseline, target, owner, or theme, do **not** invent
real values. Use a clearly marked placeholder (`_TBD_`, `X → Y`) and flag it for
the user to confirm. If no theme is present, suggest a likely current-quarter
one and mark it "confirm" — don't block on it.

Output = scorecard + top fixes + rewritten table.

## Author
Ask one question at a time, in order:
1. Team/guild, and which **current-quarter company theme** the objective
   ladders to. Themes rotate each quarter — ask, don't assume a fixed list.
2. The 1–3 outcomes that define a successful quarter → Objectives.
3. Per objective: how is progress measured? → Key Results (baseline → target).
4. Owner per KR; committed or aspirational.

Draft, run the draft back through the rubric, then present.
Output = the house table.

## Rewriting a failing item
When any Key Result fails the outcome-vs-output test, or you are about to rewrite
a failed item, read `references/examples.md` for the before→after pattern.

## Publish to Confluence (optional — last step only)
Run only after the table is final AND the user asks to publish or update the
page. Read `references/confluence-publish.md` and follow it: it finds the target
page (guessing it from the team + quarter already in this conversation),
decides update vs create, formats the table, and gates on confirmation.
Never write to a shared space without explicit user approval.

The publish flow uses these tools:
`mcp__claude_ai_Atlassian_MCP__getAccessibleAtlassianResources` (resolve cloudId),
`mcp__claude_ai_Atlassian_MCP__searchConfluence` and
`mcp__claude_ai_Atlassian_MCP__executeRead` (`name: listConfluenceSpaces`) (find the page/space),
`mcp__claude_ai_Atlassian_MCP__getConfluenceContent` (read body + version when updating),
`mcp__claude_ai_Atlassian_MCP__createConfluenceContent` /
`mcp__claude_ai_Atlassian_MCP__updateConfluenceContent` (write), and
`mcp__claude_ai_Atlassian_MCP__executeRead` (`name: lookupJiraAccountId`) (owner mentions). Operation names come from `mcp__claude_ai_Atlassian_MCP__discover` if unsure.

## Examples
- User says: "Review these OKRs" (with a pasted draft) → Validate: scorecard, top
  3 fixes, and a rewritten house table.
- User says: "Help me write Q4 OKRs for the CS team" → Author: one question at a
  time, then the house table.
- User says: "Publish it to our OKR page" (after the table is final) → optional
  Confluence publish, behind a confirmation gate.

## Troubleshooting
| Symptom | Fix |
| --- | --- |
| A KR reads like a task ("launch X", "migrate Y") | Apply the outcome-vs-output test; move the task to an Initiative and put the metric in Key Results. |
| Every KR is scored 1.0 | Sandbagging — differentiate scores; mark stretch KRs aspirational (~0.7). |
| Can't find the team's Confluence page | Title formats vary; search the OKRs space broad on the team token, match "Q<n>" or "Quarter <n>", then confirm. See `references/confluence-publish.md`. |
| Confluence table renders as plain text | Don't use markdown; use HTML (`<table>` + `<span data-type="status">`). See `references/confluence-publish.md`. |
