# OKR playbook — rubric + format + scale

Maxxton deltas and decision rules only. Don't restate general OKR theory.

## Rubric — grade each item pass / weak / fail

### Objective
- Qualitative and inspirational, not a metric. (A number means it's a KR.)
- Ladders to a current-quarter company theme.
- 1–3 per team; more than 3 = lost focus → flag.

### Key Result (most failures live here)
- **Outcome, not output** — apply the test in SKILL.md. Tasks like
  "Launch X", "Migrate Y", "Create Z" are Initiatives, not KRs.
- **Baseline → target + unit + deadline.** "Improve coverage" fails;
  "cms-web coverage 16% → 24% by EoQ" passes.
- **One named owner.**
- **Committed vs aspirational.** Committed = must hit 100% (score 1.0);
  aspirational/stretch = 0.7 is success. A mismatch (stretch marked 1.0, or a
  must-hit marked aspirational) → flag.
- 2–5 per objective.
- Measurable from a real source (Grafana / Mixpanel / Jira). If it can't be
  measured, it isn't a KR.

### Set level
- Focus: too many objectives or KRs dilutes effort → trim.
- Score spread: every KR expected at 1.0 = sandbagging → differentiate.
- KR / Initiative separation respected (the measurable vs the how).

## House table — Confluence paste-ready
Columns: `Objectives | Key Results | Expected EoQ score | Owner | Partner with | Current status`

- One objective per block; its Key Results occupy the following rows.
- **Key Results** column = the measurable only.
- **Current status** column = progress + the how, as "Initiative 1 / 2 / 3".
- **Partner with** = the team(s) you depend on or collaborate with to hit the KR.
- **Expected EoQ score** = 0.0–1.0 (committed → 1.0; aspirational → ~0.7).
- Tag each objective with its current-quarter theme label. Labels rotate; recent
  ones were Enterprise, Stability, AI First, Technology, QA — use the live ones.

## Scoring scale
0.0–0.3 at risk · 0.4–0.6 progressing · 0.7–1.0 achieved ·
consistently hitting 1.0 = not ambitious enough.
