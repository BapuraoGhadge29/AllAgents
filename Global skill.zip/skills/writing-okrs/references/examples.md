# OKR rewrite examples (before → after)

## Task masquerading as a KR
- Before (fail): "Migrate 100% of Katalon regression cases to Playwright."
- After (pass): KR — "Regression pass-rate 78% → 95%, suite run-time < 20 min";
  Initiative — "Migrate Katalon cases to Playwright."
  The migration is the work; the fast, stable suite is the outcome.

## No baseline / target
- Before (weak): "Increase test coverage."
- After (pass): "cms-web unit coverage 16% → 24% by end of quarter."

## Output-shaped objective
- Before (fail): objective "Ship the Sandaya DC group card."
- After (pass): objective "Sandaya goes live seamlessly" `Enterprise`;
  KR — "0 blocking_sales / blocking_onpark defects open at go-live."

## Sandbagging
- Before: all 6 KRs expected at 1.0.
- After: committed KRs at 1.0, stretch KRs designed for ~0.7. If everything is
  comfortably 1.0, the targets are too low — raise them.
