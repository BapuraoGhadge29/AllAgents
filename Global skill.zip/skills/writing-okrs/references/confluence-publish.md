# Publish OKRs to Confluence

Follow the Maxxton house convention. Writing to a shared space is gated on
explicit user confirmation — never write on inferred approval.

## Step 1 — Resolve the cloud
Call `mcp__claude_ai_Atlassian_MCP__getAccessibleAtlassianResources`, capture the `id` (UUID) of the Maxxton
site, and reuse it as `cloudId` for every call below. Never hardcode
`maxxton.atlassian.net`.

## Step 2 — Find the target page (the guess)
OKR pages live in the Confluence space with key **`OKRs`**. Title formats are
NOT consistent across teams or years — e.g. "Channel Manager Team OKRs Q2'2026",
"Customer Success - OKR's - Quarter 2 2025", "Customer care Manager: Team-level
guild OKRs Q4'2024". So search broad, then let the user pick — never assume a
single format or that the team name matches the page title.

1. From this conversation, take the **team/guild** and **quarter + year**. Team
   names drift: the "CS team" is titled **Customer Success**; "Owner"/"Finance"
   etc. may differ too. Pick the most likely token; if unsure, ask.
2. Search broad on the team token only, most-recent first:
   `mcp__claude_ai_Atlassian_MCP__searchConfluence` (CQL) → `space = "OKRs" AND title ~ "<team token>" ORDER BY lastmodified DESC`.
   If empty, retry with a shorter/looser token (e.g. "Customer").
3. In the results, find the right quarter by matching **either** notation —
   "Q<n>" **or** "Quarter <n>" — plus the year. Ignore "DRAFT"/trailing suffixes.
4. Resolve:
   - One clear candidate → show title + URL, ask "Update this page?" Proceed on yes.
   - Several plausible → list the top few (title, last modified, URL), ask which.
   - None for that quarter → tell the user; offer to **create** a new page (Step 4),
     reusing the team's most recent page as the title/format template.
Never guess silently — always show the page you intend to write and confirm.

## Step 3 — Update an existing page
1. `mcp__claude_ai_Atlassian_MCP__getConfluenceContent` (`content_id`, `cloudId`,
   `content_format: "html"`, `detail: "full"`) — capture the body **and the
   current version/snapshot** the update needs.
2. Locate the OKR table; update the affected rows in place, or append the new
   objective block. Leave unrelated content untouched.
3. Call `mcp__claude_ai_Atlassian_MCP__executeRead` with `name: getContentFormatGuide`
   (`inputs: {toolName: "updateConfluenceContent"}`), then write back with
   `mcp__claude_ai_Atlassian_MCP__updateConfluenceContent` (`content_id`, the version
   from the read, `body: {format: "html", value: …}`).

## Step 4 — Create a new page (only if none exists)
1. Resolve the **numeric space ID** via `mcp__claude_ai_Atlassian_MCP__executeRead` with `name: listConfluenceSpaces` (filter key `OKRs`)
   — the create tool needs the numeric `spaceId`, not the key.
2. Find the parent: search the `OKRs` space for the team's landing/parent page
   via `mcp__claude_ai_Atlassian_MCP__searchConfluence`. If no clear parent, **ask** — don't guess one.
3. Call `mcp__claude_ai_Atlassian_MCP__executeRead` `name: getContentFormatGuide` (`inputs: {toolName: "createConfluenceContent"}`),
   then `mcp__claude_ai_Atlassian_MCP__createConfluenceContent` with `spaceId`, `parentId`,
   title `<Team> OKRs Q<n>'<year>`, and `body: {format: "html", value: <table>}`.

## Step 5 — Formatting (important)
Do **not** use markdown — markdown tables don't render in Confluence (missing
header cells, wrong widths, separators show as text). Prefer **HTML**
(`body: {format: "html", value}`): it round-trips correctly and is the simplest — a
`<table>` plus the inline lozenges/mentions below. The v2 connector has no ADF
format; follow the `getContentFormatGuide` output for lozenge and mention markup.

The OKR table is the 6 house columns:
`Objectives | Key Results | Expected EoQ score | Owner | Partner with | Current status`
- **Score** (0.0–1.0) and the **theme label** render as Confluence chips — use a
  `status` lozenge (`<span data-type="status" data-color="…">` in HTML), not plain text.
- **Owner** uses a user mention (markup per the format guide) — resolve the account ID with
  `mcp__claude_ai_Atlassian_MCP__executeRead` `name: lookupJiraAccountId`; never guess an ID. If it can't be resolved, write the
  name as plain text rather than a broken mention.
- One objective per block; its KRs occupy the following rows (empty leading
  cells), matching existing pages.

## Step 6 — Confirm, then write
Before the create/update call, show the user: the target page (title + URL or
parent location) and a short summary of what will change. Wait for explicit
go-ahead. After writing, return the page link.
