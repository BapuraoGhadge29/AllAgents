# Overrides

## disable-model-invocation omitted

The skill is read-only: it downloads a video into a temporary directory, reads frames and
reports. Nothing is written to Jira or Confluence. Its side effects, installing ffmpeg and,
when the user picks Transcribe, installing whisper.cpp and downloading its model, each sit
behind an explicit `AskUserQuestion` consent gate (Instructions, steps 1 and 5). Sudo
commands are run by the user, never by Claude. Downloads are pinned to a release tag and a
SHA-256 and kept only when the hash matches.

## Agent subagents instead of `context: fork`

Step 4 hands frame reading to `Explore` subagents, one per part of at most 45 frames,
rather than forking the whole skill. A forked skill cannot ask the user anything, and steps
1, 2 and 5 need `AskUserQuestion`. Only the frame reading (about 1.5k tokens per frame)
moves out of the session.

## Auto-invocation

Auto-invocation is required for the chain to work: `customer-service:investigating-tickets`
and `scrum-team:refinement-buddy` hand ticket videos to this skill, and users ask "what does
the video on MXTS-1234 show?" without knowing a command name.
