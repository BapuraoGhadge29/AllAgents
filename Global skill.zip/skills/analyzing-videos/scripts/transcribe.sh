#!/usr/bin/env bash
# Transcribes a recording's speech on this machine with whisper.cpp; audio never leaves it.
#
# Usage: transcribe.sh <video> <workdir> <cache-dir>
#
# First use installs whisper-cli (brew on macOS, a pinned and hash-checked build on Linux and
# Windows x64) and a model into the cache dir: large-v3-turbo with 16 GB RAM or more, else small.
# The skill passes the plugin's data dir, so uninstalling the plugin removes the cache. Prints
# whisper's "[hh:mm:ss.mmm --> hh:mm:ss.mmm]  text" line per spoken segment; none means no speech.
# Exit codes: 1 failure (message on stderr), 7 no whisper.cpp build for this platform.
set -euo pipefail
export LC_ALL=C

# whisper.cpp publishes binaries under build tags and releases/latest has none, so pin tag and hash.
RELEASES=https://github.com/ggml-org/whisper.cpp/releases/download/b5454
MODELS=https://huggingface.co/ggerganov/whisper.cpp/resolve/main
VAD=ggml-silero-v6.2.0.bin VAD_SHA=2aa269b785eeb53a82983a20501ddf7c1d9c48e33ab63a41391ac6c9f7fb6987

die() { echo "transcribe: $2" >&2; exit "$1"; }

[ $# -eq 3 ] || { sed -n '4p' "$0" | sed 's/^# //' >&2; exit 1; }
VIDEO="$1" WORK="$2" DIR="$3"
PATH="$DIR/bin:$PATH"

# Turbo took 1.8x the clip length on slow CPU cores; a 16 GB machine (15.x usable) copes with it.
case "$(uname -s)" in
  Darwin) GB=$(( $(sysctl -n hw.memsize) / 1073741824 )) ;;
  *) GB=$(awk '/^MemTotal:/ { print int($2 / 1048576) }' /proc/meminfo 2>/dev/null || echo 0) ;;
esac
if [ "${GB:-0}" -ge 15 ]; then
  MODEL=ggml-large-v3-turbo-q5_0.bin MODEL_SHA=394221709cd5ad1f40c46e6031ca61bce88931e6e088c188294c6d5a55ffa7e2
else
  MODEL=ggml-small-q5_1.bin MODEL_SHA=ae85e4a935d7a567bd102fe55afc16bb595bdb618e11b2fc7591bc08120411bb
fi

# Keeps a download only when its SHA-256 matches.
fetch() {
  [ -f "$2" ] && return 0
  mkdir -p "$(dirname "$2")"
  curl -fsSL --retry 2 -o "$2.part" "$1" || die 1 "download failed: $1"
  if [ "$({ sha256sum "$2.part" 2>/dev/null || shasum -a 256 "$2.part"; } | cut -d' ' -f1)" != "$3" ]; then
    rm -f "$2.part"; die 1 "checksum mismatch for $1"
  fi
  mv "$2.part" "$2"
}

if ! command -v whisper-cli >/dev/null; then
  case "$(uname -s):$(uname -m)" in
    Darwin:*) brew install whisper.cpp >&2 || die 1 "brew install whisper.cpp failed" ;;
    Linux:x86_64) fetch "$RELEASES/whisper-bin-ubuntu-x64.tar.gz" "$DIR/linux.tar.gz" \
                    a72becf15d7917f990f6313867a52638b82b7f9ef237fb0c980dac56a135781c
                  mkdir -p "$DIR/bin" && tar -xzf "$DIR/linux.tar.gz" -C "$DIR/bin" --strip-components=1 ;;
    MINGW*:x86_64) fetch "$RELEASES/whisper-bin-x64.zip" "$DIR/windows.zip" \
                    6ba69e3482d7826214f90a6a9c84ca07782aec1e1d0c6a7c30c994fd5d816ccb
                   mkdir -p "$DIR/bin" && unzip -qjo "$DIR/windows.zip" -d "$DIR/bin" ;;
    *) die 7 "no whisper.cpp build for $(uname -sm)" ;;
  esac
fi
# A missing library (Linux: libgomp.so.1) shows up here, named in the loader error. A
# whisper-cli found on PATH may predate --vad (1.7.6), which the run below needs.
HELP=$(whisper-cli --help 2>&1) || die 1 "whisper-cli does not start: $(printf '%s' "$HELP" | head -1)"
case "$HELP" in *--vad*) ;; *) die 1 "whisper-cli is too old (no --vad): run 'brew upgrade whisper.cpp' or remove it from PATH" ;; esac
fetch "$MODELS/$MODEL" "$DIR/models/$MODEL" "$MODEL_SHA"
fetch "https://huggingface.co/ggml-org/whisper-vad/resolve/main/$VAD" "$DIR/models/$VAD" "$VAD_SHA"

# whisper.cpp reads 16 kHz mono PCM.
ffmpeg -hide_banner -nostdin -loglevel error -y -i "$VIDEO" -vn -ac 1 -ar 16000 -c:a pcm_s16le "$WORK/audio.wav" \
  || die 1 "could not extract the audio track"
# VAD feeds only speech to Whisper: no invented text over silence, and -l auto hears speech.
whisper-cli -m "$DIR/models/$MODEL" -f "$WORK/audio.wav" -l auto --vad -vm "$DIR/models/$VAD" -np \
  -t "$(getconf _NPROCESSORS_ONLN 2>/dev/null || echo 4)" 2> "$WORK/whisper.log" | tr -d '\r' | sed -n '/^\[/p' \
  || { tail -5 "$WORK/whisper.log" >&2; die 1 "whisper-cli failed"; }
