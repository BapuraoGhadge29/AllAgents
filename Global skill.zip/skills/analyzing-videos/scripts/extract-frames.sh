#!/usr/bin/env bash
# Extracts the frames worth reading from a screen recording, plus a manifest.
#
# Usage: extract-frames.sh <video> <outdir> [--from S] [--to S] [--interval S] [--max N]
#
# Needs a current ffmpeg (uses -fps_mode); older builds are not supported.
# Keeps a frame on every scene change and at least one per interval, then
# drops near-duplicates of the frame kept before. Prints a manifest on stdout:
#   duration=… resolution=… audio=none|silent|short-sounds|present|unknown
#   sound_from=<s> range=… frames=N
#   capped=yes|no candidates=N parts=N, then one "<file> <seconds> <part>" line
#   per frame. Each part holds at most 45 frames: one reader subagent per part.
# Exit codes: 2 usage, 3 ffmpeg missing, 4 not a video, 5 extraction failed.
# Bash 3.2 compatible (stock macOS), no Python needed (Git Bash on Windows).
set -euo pipefail
# Comma-decimal locales (nl_NL, de_DE) make awk/printf write 6,000, which ffmpeg rejects.
export LC_ALL=C

FFMPEG="${FFMPEG:-ffmpeg}"
FFPROBE="${FFPROBE:-ffprobe}"

VIDEO=""; OUTDIR=""
FROM=0; TO=""
INTERVAL=3
# 0.02 also fires on cursor moves and typing; 0.05 keeps page and dialog changes.
SCENE=0.05
# 45 frames (~70k tokens) fit one reader comfortably; 6 parts run in parallel.
PART_SIZE=45
MAX=270
WIDTH=1400
# Quieter than -40 dB is a muted microphone's noise floor, not sound.
SILENCE_DB=-40

usage() {
  sed -n '4p' "$0" | sed 's/^# //' >&2
  exit 2
}

die() {
  echo "extract-frames: $2" >&2
  exit "$1"
}

parse_args() {
  [ $# -ge 2 ] || usage
  VIDEO="$1"; OUTDIR="$2"; shift 2
  while [ $# -gt 0 ]; do
    [ $# -ge 2 ] || usage
    case "$1" in
      --from) FROM="$2" ;;
      --to) TO="$2" ;;
      --interval) INTERVAL="$2" ;;
      --max) MAX="$2" ;;
      *) usage ;;
    esac
    shift 2
  done
  [ -f "$VIDEO" ] || die 2 "video not found: $VIDEO"
  if [ -d "$OUTDIR" ] && [ -n "$(ls -A "$OUTDIR")" ]; then
    die 2 "output directory is not empty: $OUTDIR"
  fi
}

require_ffmpeg() {
  command -v "$FFMPEG" >/dev/null 2>&1 || die 3 "ffmpeg not found ($FFMPEG) — install ffmpeg first"
  command -v "$FFPROBE" >/dev/null 2>&1 || die 3 "ffprobe not found ($FFPROBE) — install ffmpeg first"
}

# ffprobe on Windows ends lines with \r; strip it so comparisons work.
probe() {
  "$FFPROBE" -v error "$@" "$VIDEO" 2>/dev/null | tr -d '\r' || true
}

probe_video() {
  RESOLUTION=$(probe -select_streams v:0 -show_entries stream=width,height -of csv=s=x:p=0 | head -1)
  [ -n "$RESOLUTION" ] || die 4 "no video stream in $VIDEO"
  DURATION=$(probe -show_entries format=duration -of default=nw=1:nk=1 | head -1)
  case "$DURATION" in ''|N/A) die 4 "cannot read the duration of $VIDEO" ;; esac
  awk -v f="$FROM" -v d="$DURATION" 'BEGIN { exit !(f < d) }' \
    || die 2 "--from $FROM is after the end of the video (${DURATION}s)"
  [ -n "$TO" ] || TO="$DURATION"
  SPAN=$(awk -v a="$FROM" -v b="$TO" 'BEGIN { printf "%.3f", b - a }')
  awk -v s="$SPAN" 'BEGIN { exit !(s > 0) }' || die 2 "--to must be after --from"
}

# From silencedetect's log: the audio class and where the sound starts. Sound is the span
# minus every silence; a silence still open at the end runs to the end of the span. Mouse
# clicks alone are short sounds; speech needs min(10 s, 10% of the span) of sound.
classify_sound() {
  tr -d '\r' | awk -v span="$SPAN" -v from="$FROM" '
    /silence_start:/ { start = $NF + 0; open = 1; if (!seen++ && start > 0.5) first = 0 }
    /silence_duration:/ { quiet += $NF; open = 0; if (first == "") first = $(NF - 3) }
    END {
      if (open) quiet += span - start
      s = span - quiet; speech = (span * 0.1 < 10 ? span * 0.1 : 10)
      print (s < 0.05 ? "silent" : (s >= speech ? "present" : "short-sounds")), from + first
    }'
}

# Silent tracks are common: screen recorders capture a muted microphone.
detect_audio() {
  local has_audio log
  SOUND_FROM=0
  has_audio=$(probe -select_streams a:0 -show_entries stream=index -of csv=p=0 | head -1)
  if [ -z "$has_audio" ]; then
    AUDIO=none
    return
  fi
  # The audio check is extra information: a decode failure must not stop the frames.
  if ! log=$("$FFMPEG" -hide_banner -nostdin -ss "$FROM" -t "$SPAN" -i "$VIDEO" -map 0:a:0 \
    -af "silencedetect=n=${SILENCE_DB}dB:d=1" -f null - 2>&1); then
    echo "extract-frames: could not read the audio track; reporting audio=unknown" >&2
    AUDIO=unknown
    return
  fi
  read -r AUDIO SOUND_FROM < <(printf '%s\n' "$log" | classify_sound)
}

# Writes raw/NNNN.png plus raw/times.txt (one time per frame, seconds from
# the start of the full video, so --from/--to keep the original timeline).
extract_candidates() {
  local raw="$OUTDIR/raw" select log
  mkdir -p "$raw"
  select="isnan(prev_selected_t)+gt(scene\\,$SCENE)+gte(t-prev_selected_t\\,$INTERVAL)"
  log="$raw/ffmpeg.log"
  # Scene scores need the raw stream (they compare against the previous
  # frame's change), so de-duplicate only after selecting.
  if ! "$FFMPEG" -hide_banner -nostdin -loglevel info -ss "$FROM" -t "$SPAN" -i "$VIDEO" \
    -vf "select='$select',mpdecimate,scale='min($WIDTH\\,iw)':-2,showinfo" \
    -fps_mode vfr "$raw/%04d.png" 2> "$log"; then
    tail -5 "$log" >&2
    die 5 "ffmpeg could not extract frames"
  fi
  # No matches is valid here: publish_frames reports "no frames" with a clear exit code.
  { tr -d '\r' < "$log" | grep 'Parsed_showinfo' | grep -o 'pts_time:[0-9.]*' || true; } \
    | awk -F: -v off="$FROM" '{ printf "%.2f\n", $2 + off }' > "$raw/times.txt"
}

# Keeps an evenly spread subset when there are more candidates than --max.
select_indices() {
  awk -v n="$CANDIDATES" -v m="$MAX" 'BEGIN {
    if (n <= m) { for (i = 1; i <= n; i++) print i; exit }
    if (m == 1) { print 1; exit }
    for (i = 0; i < m; i++) print 1 + int(i * (n - 1) / (m - 1) + 0.5)
  }'
}

publish_frames() {
  local raw="$OUTDIR/raw" k=0 idx t name
  CANDIDATES=$(wc -l < "$raw/times.txt" | tr -d ' ')
  [ "$CANDIDATES" -gt 0 ] || die 5 "ffmpeg produced no frames"
  CAPPED=no
  [ "$CANDIDATES" -le "$MAX" ] || CAPPED=yes
  FRAME_LINES=""
  for idx in $(select_indices); do
    k=$((k + 1))
    t=$(sed -n "${idx}p" "$raw/times.txt")
    name=$(printf 'frame_%03d_t%07.2fs.png' "$k" "$t")
    mv "$raw/$(printf '%04d' "$idx").png" "$OUTDIR/$name"
    FRAME_LINES="$FRAME_LINES$name $t $(( (k - 1) / PART_SIZE + 1 ))
"
  done
  FRAMES=$k
  PARTS=$(( (k - 1) / PART_SIZE + 1 ))
  rm -rf "$raw"
}

print_manifest() {
  echo "duration=$DURATION"
  echo "resolution=$RESOLUTION"
  echo "audio=$AUDIO"
  echo "sound_from=$SOUND_FROM"
  echo "range=$FROM-$TO"
  echo "interval=$INTERVAL"
  echo "frames=$FRAMES"
  echo "capped=$CAPPED"
  echo "candidates=$CANDIDATES"
  echo "parts=$PARTS"
  printf '%s' "$FRAME_LINES"
}

main() {
  parse_args "$@"
  require_ffmpeg
  probe_video
  detect_audio
  mkdir -p "$OUTDIR"
  extract_candidates
  publish_frames
  print_manifest
}

main "$@"
