#!/usr/bin/env bash
# Tests for scripts/extract-frames.sh and scripts/transcribe.sh — needs ffmpeg + ffprobe on PATH.
# Usage: bash tests/extract-frames.test.sh
set -uo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SCRIPT="$SCRIPT_DIR/../scripts/extract-frames.sh"
WORK=$(mktemp -d)
trap 'rm -rf "$WORK"' EXIT

PASS=0; FAIL=0
pass() { echo "  PASS  $1"; PASS=$((PASS+1)); }
fail() { echo "  FAIL  $1"; FAIL=$((FAIL+1)); }

# ── fixtures ─────────────────────────────────────────────────────────────────

# 9 s: red 0-3, blue 3-6, green 6-9, plus a silent audio track.
_make_cuts_video() {
  ffmpeg -v error -y \
    -f lavfi -i "color=c=red:s=320x240:d=3:r=10" \
    -f lavfi -i "color=c=blue:s=320x240:d=3:r=10" \
    -f lavfi -i "color=c=green:s=320x240:d=3:r=10" \
    -f lavfi -i "anullsrc=r=44100:cl=mono" \
    -filter_complex "[0:v][1:v][2:v]concat=n=3:v=1:a=0[v]" \
    -map "[v]" -map 3:a -t 9 -c:v libx264 -pix_fmt yuv420p -c:a aac "$WORK/cuts.mp4"
}

_make_tone_video() {
  ffmpeg -v error -y \
    -f lavfi -i "color=c=gray:s=320x240:d=3:r=10" \
    -f lavfi -i "sine=frequency=440:duration=3" \
    -c:v libx264 -pix_fmt yuv420p -c:a aac -shortest "$WORK/tone.mp4"
}

# 30 s with one 0.3 s click at 10 s: what a silent screen recording with mouse clicks sounds like.
_make_click_video() {
  ffmpeg -v error -y -f lavfi -i "color=c=gray:s=320x240:d=30:r=5" \
    -f lavfi -i "sine=frequency=1000:duration=30" \
    -af "volume=enable='not(between(t,10,10.3))':volume=0" \
    -c:v libx264 -pix_fmt yuv420p -c:a aac -shortest "$WORK/click.mp4"
}

_make_mute_video() {
  ffmpeg -v error -y -f lavfi -i "color=c=gray:s=320x240:d=3:r=10" \
    -c:v libx264 -pix_fmt yuv420p "$WORK/mute.mp4"
}

# 60 s of constantly changing content: every interval yields a frame.
_make_long_video() {
  ffmpeg -v error -y -f lavfi -i "testsrc=s=320x240:d=60:r=5" \
    -c:v libx264 -pix_fmt yuv420p "$WORK/long.mp4"
}

_value() { grep -E "^$1=" "$2" | head -1 | cut -d= -f2; }
_frame_times() { grep -E '^frame_' "$1" | awk '{print $2}'; }

# True when some frame time lies within ±0.3 s of $1.
_has_frame_near() {
  _frame_times "$2" | awk -v t="$1" '{ d = $1 - t; if (d < 0) d = -d; if (d <= 0.3) found = 1 } END { exit !found }'
}

# ── tests ────────────────────────────────────────────────────────────────────

test_scene_cuts_found_at_known_times() {
  local out="$WORK/cuts-out" manifest="$WORK/cuts.txt"
  bash "$SCRIPT" "$WORK/cuts.mp4" "$out" --interval 100 > "$manifest" 2>&1
  if _has_frame_near 0 "$manifest" && _has_frame_near 3 "$manifest" && _has_frame_near 6 "$manifest"; then
    pass "scene cuts at 0/3/6 s are captured"
  else
    fail "scene cuts at 0/3/6 s are captured — manifest: $(tr '\n' ' ' < "$manifest")"
  fi
}

test_manifest_lists_existing_files() {
  local out="$WORK/cuts-out2" manifest="$WORK/cuts2.txt" missing=0 count
  bash "$SCRIPT" "$WORK/cuts.mp4" "$out" > "$manifest" 2>&1
  while read -r name _; do
    [ -f "$out/$name" ] || missing=1
  done < <(grep -E '^frame_' "$manifest")
  count=$(grep -cE '^frame_' "$manifest")
  if [ "$missing" -eq 0 ] && [ "$count" -gt 0 ] && [ "$count" = "$(_value frames "$manifest")" ]; then
    pass "manifest lists $count frames that exist on disk"
  else
    fail "manifest lists frames that exist on disk — manifest: $(tr '\n' ' ' < "$manifest")"
  fi
}

test_silent_audio_detected() {
  local manifest="$WORK/silent.txt"
  bash "$SCRIPT" "$WORK/cuts.mp4" "$WORK/silent-out" > "$manifest" 2>&1
  [ "$(_value audio "$manifest")" = "silent" ] && pass "silent track → audio=silent" \
    || fail "silent track → audio=silent (got '$(_value audio "$manifest")')"
}

test_tone_audio_detected() {
  local manifest="$WORK/tone.txt"
  bash "$SCRIPT" "$WORK/tone.mp4" "$WORK/tone-out" > "$manifest" 2>&1
  [ "$(_value audio "$manifest")" = "present" ] && pass "sine track → audio=present" \
    || fail "sine track → audio=present (got '$(_value audio "$manifest")')"
}

test_click_only_audio_is_short_sounds() {
  local manifest="$WORK/click.txt"
  bash "$SCRIPT" "$WORK/click.mp4" "$WORK/click-out" > "$manifest" 2>&1
  if [ "$(_value audio "$manifest")" = "short-sounds" ] \
    && awk -v f="$(_value sound_from "$manifest")" 'BEGIN { exit !(f > 9.5 && f < 10.5) }'; then
    pass "one click at 10 s of 30 s → audio=short-sounds, sound_from≈10"
  else
    fail "one click at 10 s → short-sounds, sound_from≈10 (got '$(_value audio "$manifest")', sound_from=$(_value sound_from "$manifest"))"
  fi
}

# whisper-cli is stubbed: this checks install detection and that only segment lines come out.
test_transcribe_prints_whisper_segments() {
  local home="$WORK/home" out="$WORK/transcript.txt" dir
  dir="$home/whisper"
  mkdir -p "$dir/bin" "$dir/models" "$WORK/tr"
  printf '#!/usr/bin/env bash\ncase "$*" in *--help*) echo "  --vad  enable VAD"; exit 0 ;; esac\necho ""\necho "[00:00:04.000 --> 00:00:06.500]   Ik klik op opslaan."\n' > "$dir/bin/whisper-cli"
  chmod +x "$dir/bin/whisper-cli"
  touch "$dir/models/ggml-large-v3-turbo-q5_0.bin" "$dir/models/ggml-small-q5_1.bin" "$dir/models/ggml-silero-v6.2.0.bin"
  bash "$SCRIPT_DIR/../scripts/transcribe.sh" "$WORK/tone.mp4" "$WORK/tr" "$dir" > "$out" 2>&1
  if [ "$(cat "$out")" = "[00:00:04.000 --> 00:00:06.500]   Ik klik op opslaan." ]; then
    pass "transcribe.sh with whisper installed → only the segment line"
  else
    fail "transcribe.sh → only the segment line (output: $(tr '\n' ' ' < "$out"))"
  fi
}

test_missing_audio_stream_detected() {
  local manifest="$WORK/mute.txt"
  bash "$SCRIPT" "$WORK/mute.mp4" "$WORK/mute-out" > "$manifest" 2>&1
  [ "$(_value audio "$manifest")" = "none" ] && pass "no audio stream → audio=none" \
    || fail "no audio stream → audio=none (got '$(_value audio "$manifest")')"
}

test_long_video_is_capped_and_split() {
  local manifest="$WORK/long.txt"
  bash "$SCRIPT" "$WORK/long.mp4" "$WORK/long-out" --interval 1 --max 50 > "$manifest" 2>&1
  local count; count=$(grep -cE '^frame_' "$manifest")
  if [ "$count" -eq 50 ] && [ "$(_value capped "$manifest")" = "yes" ] && [ "$(_value parts "$manifest")" = "2" ] \
    && [ "$(grep -cE ' 1$' "$manifest")" -eq 45 ] && [ "$(ls "$WORK/long-out" | wc -l | tr -d ' ')" -eq 50 ]; then
    pass "60 s video with --max 50 → 50 frames, capped=yes, parts of 45 + 5"
  else
    fail "60 s video with --max 50 → 50 frames in parts of 45 + 5 (got $count, capped=$(_value capped "$manifest"), parts=$(_value parts "$manifest"))"
  fi
}

test_from_to_keeps_original_timestamps() {
  local manifest="$WORK/range.txt" outside
  bash "$SCRIPT" "$WORK/cuts.mp4" "$WORK/range-out" --from 2.5 --to 7 --interval 100 > "$manifest" 2>&1
  outside=$(_frame_times "$manifest" | awk '$1 < 2.4 || $1 > 7.1' | wc -l | tr -d ' ')
  if [ "$outside" -eq 0 ] && _has_frame_near 3 "$manifest" && _has_frame_near 6 "$manifest"; then
    pass "--from 2.5 --to 7 → frames only in range, times relative to the full video"
  else
    fail "--from 2.5 --to 7 → frames in range with original times — manifest: $(tr '\n' ' ' < "$manifest")"
  fi
}

# Dutch and German locales print 6,000 instead of 6.000, which ffmpeg rejects.
test_comma_decimal_locale_works() {
  local manifest="$WORK/locale.txt" rc=0
  LC_ALL=nl_NL.UTF-8 LANG=nl_NL.UTF-8 bash "$SCRIPT" "$WORK/cuts.mp4" "$WORK/locale-out" \
    --from 2.5 > "$manifest" 2>&1 || rc=$?
  if [ "$rc" -eq 0 ] && _has_frame_near 3 "$manifest"; then
    pass "nl_NL locale → frames extracted with dot decimals"
  else
    fail "nl_NL locale → frames extracted (rc=$rc, output: $(tr '\n' ' ' < "$manifest"))"
  fi
}

test_from_beyond_end_fails_clearly() {
  local err rc=0
  err=$(bash "$SCRIPT" "$WORK/cuts.mp4" "$WORK/beyond-out" --from 10 --to 20 2>&1 >/dev/null) || rc=$?
  if [ "$rc" -eq 2 ] && printf '%s' "$err" | grep -qi "after the end"; then
    pass "--from beyond the video end → exit 2 + message"
  else
    fail "--from beyond the video end → exit 2 + message (rc=$rc, stderr: $err)"
  fi
}

# An unreadable audio track must not stop frame extraction.
test_audio_failure_reports_unknown() {
  local stub="$WORK/ffmpeg-no-audio" manifest="$WORK/noaudio.txt" rc=0
  cat > "$stub" <<'STUB'
#!/usr/bin/env bash
case "$*" in *silencedetect*) echo "audio decode error" >&2; exit 1 ;; esac
exec ffmpeg "$@"
STUB
  chmod +x "$stub"
  FFMPEG="$stub" bash "$SCRIPT" "$WORK/cuts.mp4" "$WORK/noaudio-out" > "$manifest" 2>&1 || rc=$?
  if [ "$rc" -eq 0 ] && [ "$(_value audio "$manifest")" = "unknown" ] && _has_frame_near 3 "$manifest"; then
    pass "audio check fails → audio=unknown, frames still extracted"
  else
    fail "audio check fails → audio=unknown, frames still extracted (rc=$rc, output: $(tr '\n' ' ' < "$manifest"))"
  fi
}

test_non_video_fails_cleanly() {
  local err rc=0
  echo "not a video" > "$WORK/notes.txt"
  err=$(bash "$SCRIPT" "$WORK/notes.txt" "$WORK/notes-out" 2>&1 >/dev/null) || rc=$?
  if [ "$rc" -eq 4 ] && printf '%s' "$err" | grep -qi "no video stream"; then
    pass "text file → exit 4 + 'no video stream'"
  else
    fail "text file → exit 4 + 'no video stream' (rc=$rc, stderr: $err)"
  fi
}

test_missing_ffmpeg_fails_clearly() {
  local err rc=0
  err=$(FFMPEG=/nonexistent/ffmpeg bash "$SCRIPT" "$WORK/cuts.mp4" "$WORK/noff-out" 2>&1 >/dev/null) || rc=$?
  if [ "$rc" -eq 3 ] && printf '%s' "$err" | grep -qi "ffmpeg not found"; then
    pass "missing ffmpeg → exit 3 + 'ffmpeg not found'"
  else
    fail "missing ffmpeg → exit 3 + 'ffmpeg not found' (rc=$rc, stderr: $err)"
  fi
}

test_missing_args_show_usage() {
  local err rc=0
  err=$(bash "$SCRIPT" 2>&1 >/dev/null) || rc=$?
  if [ "$rc" -eq 2 ] && printf '%s' "$err" | grep -qi "usage"; then
    pass "no arguments → exit 2 + usage"
  else
    fail "no arguments → exit 2 + usage (rc=$rc)"
  fi
}

test_non_empty_outdir_refused() {
  local err rc=0
  mkdir -p "$WORK/busy-out" && touch "$WORK/busy-out/keep.txt"
  err=$(bash "$SCRIPT" "$WORK/cuts.mp4" "$WORK/busy-out" 2>&1 >/dev/null) || rc=$?
  if [ "$rc" -eq 2 ] && [ -f "$WORK/busy-out/keep.txt" ]; then
    pass "non-empty output dir → exit 2, files untouched"
  else
    fail "non-empty output dir → exit 2, files untouched (rc=$rc, stderr: $err)"
  fi
}

# ── runner ───────────────────────────────────────────────────────────────────

if ! command -v ffmpeg >/dev/null 2>&1 || ! command -v ffprobe >/dev/null 2>&1; then
  echo "SKIP: ffmpeg/ffprobe not on PATH — install ffmpeg to run these tests" >&2
  exit 1
fi

_make_cuts_video && _make_tone_video && _make_click_video && _make_mute_video && _make_long_video || {
  echo "could not generate fixture videos" >&2; exit 1; }

echo "extract-frames.sh"
echo ""
echo "frames"
test_scene_cuts_found_at_known_times
test_manifest_lists_existing_files
test_long_video_is_capped_and_split
test_from_to_keeps_original_timestamps
test_comma_decimal_locale_works
echo ""
echo "audio"
test_silent_audio_detected
test_tone_audio_detected
test_click_only_audio_is_short_sounds
test_transcribe_prints_whisper_segments
test_missing_audio_stream_detected
test_audio_failure_reports_unknown
echo ""
echo "guards"
test_non_video_fails_cleanly
test_from_beyond_end_fails_clearly
test_missing_ffmpeg_fails_clearly
test_missing_args_show_usage
test_non_empty_outdir_refused
echo ""
echo "Results: $PASS passed, $FAIL failed"
[ "$FAIL" -eq 0 ]
