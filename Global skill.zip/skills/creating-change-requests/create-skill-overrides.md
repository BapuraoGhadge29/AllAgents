# Overrides

## disable-model-invocation omitted

This skill is the canonical entry point for raising a Change Request. Its audience is Maxxton employees outside Product (Customer Success, Support, Professional Services) who express intent naturally ("raise a CR", "create a change request") and do not know a slash command name. Auto-invocation is how the skill becomes findable on intent.

The only side effect is creating one Jira issue in CHANGEREQ. It sits behind an explicit confirmation gate: the full ticket is shown and nothing is created before the user says yes (Instructions, step 3). Duplicate creation is blocked in step 4.
