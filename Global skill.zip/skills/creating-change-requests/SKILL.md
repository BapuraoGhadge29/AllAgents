---
name: creating-change-requests
description: Creates an internal Change Request ticket in the Jira CHANGEREQ space at Maxxton. Use when someone outside a product team says "create a change request", "raise a CR", or wants to request a change from Product.
allowed-tools:
- mcp__claude_ai_Atlassian_MCP__getAccessibleAtlassianResources
- mcp__claude_ai_Atlassian_MCP__atlassianUserInfo
- mcp__claude_ai_Atlassian_MCP__createJiraIssue
- mcp__claude_ai_Atlassian_MCP__discover
- mcp__claude_ai_Atlassian_MCP__executeRead
---

# Creating Change Requests

This skill turns a request from a Maxxton employee (Customer Success, Support, Professional Services or any other non-product team) into a Change Request ticket in the Jira space **Change Request** (project key `CHANGEREQ`). The PM or product team of the selected Maxxton team reviews it from their support dashboard and either declines it with a comment or converts it into an MXTS ticket. In both cases the Change Request is closed.

## Core principle: the user supplies every mandatory field

Never invent, infer or prefill a mandatory field value. If the user's input already contains a value, you may map it to the right field, but you show the mapping back to them for confirmation. If a value is missing or ambiguous, ask for it. A Change Request with guessed values wastes the PM's time and defeats the purpose of the flow.

You may help with wording (tightening a summary, structuring a description), but the facts must come from the user.

## Jira facts

- Cloud: `maxxton.atlassian.net`. Call `mcp__claude_ai_Atlassian_MCP__getAccessibleAtlassianResources` once to get the cloudId, then pass it explicitly as `cloudId` on every Atlassian call in this flow (create, discover, executeRead).
- Project: `CHANGEREQ` (Change Request, id 11448)
- Issue types for change requests: **Improvement** (id 10047) and **New Feature** (id 10034)
- The space also contains Bug and Incident. Those are not change requests: point the user to the regular bug or incident route unless they explicitly insist.
- Reporter: the current user. Get the accountId with `mcp__claude_ai_Atlassian_MCP__atlassianUserInfo`; never ask the user for it.

## Mandatory fields (Improvement and New Feature)

| Field | Field id | Type | What to ask the user |
| --- | --- | --- | --- |
| Summary | `summary` | text | One line describing the change |
| Issue type | `issuetype` | Improvement / New Feature | Is this improving something that exists, or something new? |
| Maxxton Team | `customfield_10049` | single select | Which product team owns the module? |
| Product category | `customfield_11612` | Assets object | Which module or product area? |
| Location(s) / park(s) | `customfield_13056` | text | Which clients, parks or locations are affected, or "All" |
| Change reason | `customfield_13057` | text | What problem do you or the client run into today, and why does it matter? |
| Existing bookings impacted? | `customfield_13058` | Yes / No / Unknown | Does the change affect existing bookings? |
| Description | `description` | text | The full request: current situation, desired situation, examples |

Allowed values for **Maxxton Team** (offer these, the user picks): Customer Service, CSTA - Third Parties API, CSTA - Third Parties Connections, CSTA - Third Parties Payments, CSTA - Reservations/FOM, Consultants, Web Manager - Projects & Support, Channel Manager, Configuration Scripts, Content & Back Office, AI, Database, Design Guild, DevSecOps, Email Notifications, Finance / Owner / Compliance, Frontend Core, FrontOps, Maxxton Academy, MXTS Finance - Sandaya, Oracle Migration, Platform Core, Product Guild, Core QA, Reporting & BI, Reservations/CCM/NM, Revenue & Availability, Revenue & Channel, Third Parties - API, Third Parties - Connections, Third Parties - Payments, UX / Analytics, Web Manager - Development.

Allowed values are configured in Jira and can change. If a create is refused because a value isn't allowed, fetch the current list: call `mcp__claude_ai_Atlassian_MCP__executeRead` with `name: getJiraIssueTypeMetaWithFields` (project `CHANGEREQ`, the issue type id, plus the `cloudId`). Reach it through `mcp__claude_ai_Atlassian_MCP__discover` if the name is rejected. Then let the user choose again.

## Instructions

### 1. Collect

Ask the user to share everything they have in one go: free text, a pasted Slack thread, client email or notes all work. Then map what they gave you onto the eight fields.

### 2. Fill the gaps

List the fields that are still missing or unclear and ask for them together in one message, not one question per turn. Offer the allowed values as a list where the field has fixed values (issue type, Maxxton Team, Existing bookings impacted?).

Push back on a weak change reason. "Add a filter" is a solution, not a reason. Ask what problem it solves and for whom. Push back on a description that only restates the summary.

### 3. Draft and confirm

Show the complete ticket as a table with every field and its value, plus the description. Ask the user to confirm or correct. Do not create anything before an explicit yes.

Description structure (use the user's content, do not add facts):

```
**Current situation**
<what happens today>

**Desired situation**
<what should happen>

**Example**
<client, reservation number, screenshot reference or steps, if given>

**Requested by**
<user's name and team; client name if it originates from a client>
```

Omit a section the user has no content for rather than filling it with placeholders.

### 4. Create

Create the issue with `mcp__claude_ai_Atlassian_MCP__createJiraIssue`:

- `cloudId`: the value resolved in the Jira facts
- `projectKey`: `CHANGEREQ`
- `issueType`: `Improvement` or `New Feature`
- `summary`, `description`
- `additional_fields` for the custom fields. Keys may be the field name (`Maxxton Team`, `Product category`, `Location(s) / park(s)`, `Change reason`, `Existing bookings impacted?`), which the tool resolves to Jira's format and values automatically, or the raw `customfield_*` id from the table with the value in Jira's own shape. Use field names unless a create is refused on a field, then retry that field by id.

**Product category** is an Assets (CMDB) object field. Pass the module name the user gave. If the create is refused on this field, use the repairHint or allowed values it returns to find the matching object and confirm the choice with the user before retrying. If it still cannot be resolved, do not guess an object id: give the user the confirmed draft and a link to create it in Jira themselves (Create > space Change Request), with only Product category left for them to pick.

If a create is refused, retry once with the corrected input from the repairHint. Never create the same ticket twice: if the response contains an issue key, the ticket exists.

### 5. Hand off

Reply with the ticket key as a link, one line on what happens next, and nothing more. If the user mentioned a PM, scrum master or team lead they already spoke to, suggest they share the link with that person. That's optional, not a requirement.

## Examples

User says:

> Raise a CR: Support keeps getting asked by Landal whether the discount shows on the invoice. Can we show it?

Expected flow: map what is given (summary, a client, a hint of the problem), then ask in one message for the missing fields: Improvement or New Feature, Maxxton Team, Product category, locations or parks affected, why it matters today, and whether existing bookings are impacted. Show the full draft table, wait for an explicit yes, then create.

Weak change reason, push back:

> "Add a filter on the arrivals list" is the solution. What can the client not do today, and how often does it come up?

Hand off reply:

> Created CHANGEREQ-123. It's now on the Revenue & Availability support dashboard. The PM will either convert it into an MXTS ticket or decline it with a comment, and the Change Request is closed in both cases.

## Troubleshooting

- **Create refused on Maxxton Team or Product category:** the allowed values changed in Jira. Fetch the current list as described above and let the user pick again.
- **User reports a bug or incident:** not a change request. Point them to the regular bug or incident route.
- **Issue key already returned:** the ticket exists. Do not retry the create.

## What not to do

- Don't create tickets directly on a product backlog (MXTS) from this skill. That route is only for product team members, or for requests already agreed with the PM or product team.
- Don't fill a mandatory field the user hasn't supplied, not even with "TBD" or "Unknown". The exception is "Existing bookings impacted?", where Unknown is a legitimate answer, but only if the user chooses it.
- Don't promise a delivery date or say the request will be accepted. The PM decides, based on the team's Definition of Ready and whether it fits the roadmap.
