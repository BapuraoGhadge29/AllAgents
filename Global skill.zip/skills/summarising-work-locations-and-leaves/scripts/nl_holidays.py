#!/usr/bin/env python3
"""Compute Dutch (NL) national public holidays for one or more years.

Most NL holidays are fixed dates, but several are tied to Easter, which moves
each year. This script computes Easter with the Gregorian (Anschluss/Meeus)
algorithm and derives the movable feasts from it, so the result is correct for
any year without a hard-coded table.

Usage:
    python nl_holidays.py 2026            # one year
    python nl_holidays.py 2025 2026 2027  # several years

Output: JSON mapping "YYYY-MM-DD" -> holiday name (English / Dutch).
"""
import json
import sys
from datetime import date, timedelta


def easter_sunday(year: int) -> date:
    """Gregorian Easter Sunday (Meeus/Jones/Butcher algorithm)."""
    a = year % 19
    b = year // 100
    c = year % 100
    d = b // 4
    e = b % 4
    f = (b + 8) // 25
    g = (b - f + 1) // 3
    h = (19 * a + b - d - g + 15) % 30
    i = c // 4
    k = c % 4
    ell = (32 + 2 * e + 2 * i - h - k) % 7
    m = (a + 11 * h + 22 * ell) // 451
    month = (h + ell - 7 * m + 114) // 31
    day = ((h + ell - 7 * m + 114) % 31) + 1
    return date(year, month, day)


def nl_holidays(year: int) -> dict:
    easter = easter_sunday(year)

    # King's Day: 27 April, but moved to 26 April when the 27th is a Sunday.
    kings_day = date(year, 4, 27)
    if kings_day.weekday() == 6:  # Sunday
        kings_day = date(year, 4, 26)

    # Liberation Day is a national commemoration every year, but for most CAOs it is only a
    # *paid day off* in lustrum years (every 5th year). Flag it outside lustrum years so the
    # skill doesn't silently classify a May 5 day off as a guaranteed holiday.
    liberation_day = "Liberation Day (Bevrijdingsdag)"
    if year % 5 != 0:
        liberation_day += " [employer/CAO-dependent: a paid day off only in lustrum years]"

    holidays = {
        date(year, 1, 1): "New Year's Day (Nieuwjaarsdag)",
        # Good Friday is a paid day off only at some employers, not nationally guaranteed.
        easter - timedelta(days=2): "Good Friday (Goede Vrijdag) [employer/CAO-dependent]",
        easter: "Easter Sunday (Eerste Paasdag)",
        easter + timedelta(days=1): "Easter Monday (Tweede Paasdag)",
        kings_day: "King's Day (Koningsdag)",
        date(year, 5, 5): liberation_day,
        easter + timedelta(days=39): "Ascension Day (Hemelvaartsdag)",
        easter + timedelta(days=49): "Whit Sunday (Eerste Pinksterdag)",
        easter + timedelta(days=50): "Whit Monday (Tweede Pinksterdag)",
        date(year, 12, 25): "Christmas Day (Eerste Kerstdag)",
        date(year, 12, 26): "Boxing Day (Tweede Kerstdag)",
    }
    return {d.isoformat(): name for d, name in sorted(holidays.items())}


def main(argv):
    years = [int(a) for a in argv[1:]] or [date.today().year]
    out = {}
    for y in years:
        out.update(nl_holidays(y))
    print(json.dumps(out, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main(sys.argv)
