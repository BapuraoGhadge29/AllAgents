---
name: summarising-work-locations-and-leaves
description: "Summarises where the user worked from Google Calendar working-location events (office vs. home, with ratio), counts days off from out-of-office events, and splits Dutch national holidays from personal leave. Use when the user says \"summarise my work locations\" or asks how many days off they took.\n"
disable-model-invocation: true
allowed-tools:
- mcp__claude_ai_Google_Calendar__list_events
- Bash
---

# Summarising Work Locations And Leaves

This skill turns the user's Google Calendar into a quick report of where they worked and how
many days off they took. Google Calendar stores this as two special event types that are easy
to read reliably:

- **Working-location events** (`eventType: WORKING_LOCATION`) — one all-day entry per day with a
  `summary` like "Oostperkweg (Office)" or "Home". These are the source of truth for office vs.
  home, *not* regular meetings.
- **Out-of-office events** (`eventType: OUT_OF_OFFICE`) — used here as the source of truth for
  days off / time away.

Reading these typed events directly is far more accurate than guessing from meeting titles, so
always query by `eventType` rather than scanning the whole calendar.

## Step 1 — Resolve the period

Work out the date window before querying:

- If the user named a month ("June", "last month", "May 2026"), use that whole calendar month.
- If they gave an explicit range, use it as-is.
- **If they said nothing, default to the last completed calendar month.** This is the common
  case at month-end reporting time. State the period you chose in your answer so the user can
  correct it.

Express the window as `startTime` = first day 00:00 and `endTime` = first day of the *next*
month 00:00 (exclusive). Working-location and OOO events are all-day events whose `end.date` is
exclusive, so a day "belongs" to the date in its `start.date`.

## Step 2 — Fetch the typed events

Make these calls (they can run in parallel):

1. Working locations:
   `mcp__claude_ai_Google_Calendar__list_events(startTime, endTime, eventType=["WORKING_LOCATION"], orderBy="startTime", pageSize=100)`
2. Days off:
   `mcp__claude_ai_Google_Calendar__list_events(startTime, endTime, eventType=["OUT_OF_OFFICE"], orderBy="startTime", pageSize=100)`

If `nextPageToken` is returned, page through until exhausted — a month can exceed one page only
rarely, but long ranges will.

Do **not** fetch `DEFAULT` events for this summary. They are large, noisy, and not needed — the
location and OOO data live entirely in the typed events above.

## Step 3 — Classify each working-location day

For each `WORKING_LOCATION` event, read its `summary` and bucket it:

- **Office** — summaries naming a physical office site. At Maxxton this is typically
  "Oostperkweg (Office)", but treat any summary containing "office" or a known site name as
  office.
- **Home** — summaries of "Home" or "Working from home".
- **Other** — anything else (e.g. a client site, a city name); list these explicitly rather
  than forcing them into office/home.

Note: the underlying `workingLocationProperties.type` is often a generic `HOME_OFFICE` even for
office entries, so classify on the human-readable `summary`, not on that type field.

Count the distinct working days in the period (Mon–Fri within the window, excluding any that are
days off — see Step 4). A weekday in the period that has **no** working-location event is an
**unset** day — collect these, they are useful signal (the user may have forgotten to log, or
been off without an OOO entry).

## Step 4 — Count days off

Treat **every** out-of-office event as a day off (the user's chosen definition). To keep the
report honest, split them:

- **Full-day** OOO events (all-day, or effectively covering the working day) — these are the
  headline "days off" count.
- **Partial** OOO events (a few hours, e.g. a 09:15–10:35 "Away") — count them but list them
  separately as partial, since they aren't a full day off.

If an OOO day overlaps a working-location day, the day off takes precedence in the working-day
denominator (don't double-count it as a working day).

### Step 4b — Separate national holidays from personal leave

A day off that lands on a public holiday didn't come out of the user's leave balance, so the
summary is much more useful when it splits the two. The user is based in the Netherlands, so
check each full-day day-off date against the **Dutch national holidays**.

Don't hand-compute these — several (Easter, Ascension, Whitsun) move each year. Run the bundled
script (run it from anywhere — `${CLAUDE_SKILL_DIR}` resolves to this skill's folder), which
computes them correctly for any year:

```
python3 "${CLAUDE_SKILL_DIR}/scripts/nl_holidays.py" <year>          # e.g. 2026
python3 "${CLAUDE_SKILL_DIR}/scripts/nl_holidays.py" 2025 2026        # several years for a cross-year range
```

It prints JSON mapping `YYYY-MM-DD` → holiday name. For each full-day day off:

- If its date is in the holiday map → label it a **national holiday** (with the name).
- Otherwise → it's **personal leave**.

**Whether a holiday is a paid day off can depend on the employer/CAO.** Good Friday is a paid
day off only at some employers, and Liberation Day (May 5) is typically a paid day off only in
lustrum years (every 5th year) for most CAOs. The script flags these CAO-dependent entries in
their holiday name. When a day off matches such an entry, don't assert the split — say it's
employer-dependent and ask the user whether it was a paid holiday or came out of their leave
balance.

Report the two groups separately and give the personal-leave count prominence, since that's the
number the user usually cares about (what they actually took off). Note that a holiday falling on
a weekend, or a holiday the user worked through, won't appear as a day off at all — only classify
dates that are actually OOO.

## Step 5 — Present the summary

Keep it concise and skimmable — this is a chat answer, not a document. Lead with the period and
the headline counts, then the breakdown. Use a compact structure like:

```
Work locations — [Month Year]

Office — N days
[list dates or ranges]

Home — N days
[list dates]

Days off — N total
  Personal leave — N: [list dates]
  National holidays — N: [list dates with names]
  (Partial — N: [list], if any)

Unset (weekdays with no location) — N
[list dates]
```

Close with the office/home ratio (e.g. "≈84% office, 16% home across logged days") and, if there
are unset days or partial OOO entries, a one-line note so the user can decide whether to fix
them. Offer to fill gaps or to set up a recurring monthly summary if it seems useful.

## Examples

**Example 1**
User says: "Summarise my work locations for June"
Output: June window resolved, working-location and OOO events fetched, days bucketed into
office / home / unset, OOO days counted, and a concise per-bucket summary with the office/home
ratio.

**Example 2**
User says: "How many days did I work from home last month?"
Output: Defaults to the last completed month, counts the "Home" working-location days, and
reports the number alongside the office count for context.

**Example 3**
User says: "How many days off did I take in Q2?"
Output: Uses the explicit Apr 1–Jun 30 range, counts all OOO events as days off, runs
`nl_holidays.py 2026` to split national holidays from personal leave, separates full-day from
partial, and lists the dates with holiday names where applicable.

## Troubleshooting

- **No working-location events at all**: tell the user plainly — they may not use Google's
  working-location feature. Offer to summarise from out-of-office and all-day events instead.
- **Multiple calendars**: working locations live on the user's primary calendar by default; only
  pass a different `calendarId` if the user asks.
- **Timezone**: all-day events are date-based and timezone-independent; report dates as-is.
- **Definition of a day off** is intentionally broad here (any OOO event). If the user prefers
  full-day-only, drop the partial entries from the headline count — keep that toggle in mind.
