---
name: logging-jira-work-hours
description: "Reconstruct a developer's workday from connected tools - Slack, Jira, GitHub PRs, and Google Calendar, estimate time per Jira ticket, and prepare Jira work logs for user confirmation. Use when logging work hours for today or any past date, e.g. \"log my hours for today\".\n"
disable-model-invocation: true
allowed-tools:
- mcp__claude_ai_Atlassian_MCP__getAccessibleAtlassianResources
- mcp__claude_ai_Atlassian_MCP__atlassianUserInfo
- mcp__claude_ai_Atlassian_MCP__searchJiraIssuesUsingJql
- mcp__claude_ai_Atlassian_MCP__getJiraIssue
- mcp__claude_ai_Slack__slack_search_users
- mcp__claude_ai_Slack__slack_search_public_and_private
- mcp__claude_ai_GitHub__search_pull_requests
- mcp__claude_ai_Google_Calendar__list_events
- mcp__claude_ai_Atlassian_MCP__discover
- mcp__claude_ai_Atlassian_MCP__executeWrite
---

# Logging Jira Work Hours

## Step 1 - Collect account details
Confirm who you're acting as:
- Use user name, Jira, Slack, and GitHub account details from your memory if present.
- If Jira account is not found, call `mcp__claude_ai_Atlassian_MCP__atlassianUserInfo` to get the current user's
  Jira account ID, display name, and email.
- If Slack ID is not found, use the user's email to search for their Slack user ID
  via `mcp__claude_ai_Slack__slack_search_users`.
- If GitHub username is not in memory, ask the user for it before running Step 2c.
- Store all resolved details (Jira account ID, display name, email, Slack ID, GitHub username) in memory.
- Resolve TARGET_DATE: if the user specified a date (e.g. "yesterday", "last Monday", "09-05-2026"), parse it to DD-MM-YYYY. Default to today if not specified. Use TARGET_DATE for all queries below.

## Step 2 - Collect data in parallel
Collect conversations from Slack, calendar entries, comments from Jira tickets 
and PRs from GitHub, all in parallel.

### Step 2a - Collect conversations from Slack
Use `mcp__claude_ai_Slack__slack_search_public_and_private` to fetch Slack messages sent by the current user on TARGET_DATE.
Extract Jira ticket IDs from message texts.

### Step 2b - Collect Jira tickets commented on TARGET_DATE
Search for Jira tickets where the current user has added comments on TARGET_DATE.
Note: `issueFunction in commented(...)` requires ScriptRunner which is not available on this instance.

commentedBy = currentUser() AND commentedOn >= "TARGET_DATE" AND commentedOn <= "TARGET_DATE"
⚠️ Use this JQL exactly as written — do not add clauses. Follow this strictly.
When calling `mcp__claude_ai_Atlassian_MCP__searchJiraIssuesUsingJql`, request only `["key", "summary"]` — do NOT include `comment`.
The `comment` field returns all historical comments and causes oversized responses (100KB+).
Trust the JQL match as sufficient evidence that the user commented on TARGET_DATE. No per-ticket comment validation needed.

### Step 2c - Collect GitHub PRs opened or updated on TARGET_DATE
Use `mcp__claude_ai_GitHub__search_pull_requests` to find PRs authored by the GitHub username (resolved in Step 1) that were created or had commits pushed on TARGET_DATE.
Extract ticket IDs from PR titles and branch names.

### Step 2d - Collect calendar entries
Use `mcp__claude_ai_Google_Calendar__list_events` to fetch events for TARGET_DATE from the user's calendar.
For each event: extract title, start time, end time, and any description.
Map meeting titles to Jira tickets where obvious.

For events that are not obviously mapped, use the standard Internal Task Tracking mappings below. If an event doesn't clearly fit a row, ask the user which ITT activity to use (do not guess).
| Ticket | Actvitity type                           |
|--------|------------------------------------------|
| ITT-1  | Internal meeting                         |
| ITT-2  | Sick leave / Doctors appointment         |
| ITT-3  | Internal Training given or coordinated   |
| ITT-4  | Internal Training attended               |
| ITT-5  | Documentation                            |
| ITT-6  | 1:1 Meetings                             |
| ITT-7  | Study                                    |
| ITT-8  | Other Leave                              |
| ITT-9  | Parental leave                           |
| ITT-10 | Product Demo attended                    |
| ITT-11 | Holiday                                  |
| ITT-12 | Onboarding (for new team members)        |
| ITT-14 | Reviews and appraisals                   |
| ITT-15 | Resource planning                        |
| ITT-19 | Product Backlog Refinement               |
| ITT-16 | Product Demo given or coordinated        |
| ITT-20 | Sprint Planning                          |
| ITT-21 | Sprint Retrospective                     |
| ITT-22 | Daily Scrum                              |
| ITT-23 | Sprint Review / Demo                     |
| ITT-24 | Management tasks                         |
| ITT-25 | Employee Review                          |
| ITT-28 | Deployment tasks                         |
| ITT-26 | Code Review                              |
| ITT-27 | System administration                    |
| ITT-29 | Slack messages and Emails                |

## Step 3 — Reconcile, deduplicate, and estimate

### Merge signals per ticket
Consolidate all evidence into a single row per ticket. A single activity usually surfaces in
multiple sources (a PR opened, then linked in Slack, then commented on in Jira). Count the
underlying work once, not once per signal — the sources column should list all the evidence,
but the time estimate reflects the real work, not the signal count.

### Baseline estimates
Use these as a starting point, then adjust with judgement based on the specifics you see.
The goal is consistency across days, not false precision.

| Signal                                | Baseline time               |
|---------------------------------------|-----------------------------|
| Calendar entry                        | Entry duration (direct)     |
| PR small (<50 LOC changed)            | 0h 30m                      |
| PR medium (50–200 LOC)                | 2h 00m                      |
| PR large (200+ LOC)                   | 4h 00m                      |
| PR review given (not authored)        | 0h 15m per PR               |
| Jira comment (short)                  | 0h 15m                      |
| Jira comment (detailed investigation) | 1h 00m                      |
| Slack thread on a ticket              | 0h 15m baseline             |

Combine signals on the same ticket additively. Cap the day at 8h — if the sum exceeds
that, compress proportionally and surface the compression in the summary so the user
sees it before confirming.

Never invent time for a ticket that has no evidence.

### Edge cases
- **Ticket appears in multiple sources**: one row, merge sources in the "Source(s)" column.
- **Already logged on TARGET_DATE**: before proposing worklogs, run a single JQL check across all
  proposed tickets at once:
  `issue in (TICKET-A, TICKET-B, ...) AND worklogDate = "TARGET_DATE" AND worklogAuthor = currentUser()`
  with fields `["key", "summary"]` only. Any ticket returned already has a worklog from you
  on TARGET_DATE — surface it in the "Logged" column and ask whether to add or skip.
  ⚠️ Never use `mcp__claude_ai_Atlassian_MCP__getJiraIssue` with the `worklog` field for this check — recurring tickets like
  MXTS-1739 or MXT-5573 have thousands of worklogs and always produce oversized responses.
- **Day with no signals**: present an empty summary and ask the user if they worked on TARGET_DATE.
  Do not fabricate entries.
- **PR touches multiple tickets**: if a branch name or PR title references multiple
  tickets, split the PR estimate evenly across them unless the user directs otherwise.
- **Meeting not obviously mapped**: apply Worklog Pro default mappings (fetched in Step 2d).
  If still unmapped, ask the user rather than guessing.

## Step 4 — Show the summary and confirm
Present a clear, editable summary **before logging anything**. 
Use unicode box-drawing with light (single-line) style. The width of each column is fixed, 
so wrap the content if it's too long. Make sure the lines are not distorted.

```
📋 Daily Work Log — [TARGET_DATE]

● ┌────┬─────────────┬────────────────────────────────┬──────────────────────────┬────────┬────────┐
  │ #  │ Ticket      │ Title                          │ Source(s)                │ Time   │ Logged │
  ├────┼─────────────┼────────────────────────────────┼──────────────────────────┼────────┼────────┤
  │ 1  │ PROJ-123    │ [Module] Short ticket title    │ PR 456 merged +          │ 1h 30m │    Y   │
  │    │             │ that wraps if it is too long   │ Jira comment             │        │        │
  ├────┼─────────────┼────────────────────────────────┼──────────────────────────┼────────┼────────┤
  │ 2  │ PROJ-456    │ Another ticket title           │ Calendar: meeting title  │ 0h 30m │    N   │
  │    │             │                                │ (HH:MM–HH:MM)            │        │        │
  ├────┼─────────────┼────────────────────────────────┼──────────────────────────┼────────┼────────┤
  │ 3  │ PROJ-789    │ Yet another ticket title       │ Slack thread             │ 0h 15m │    N   │
  └────┴─────────────┴────────────────────────────────┴──────────────────────────┴────────┴────────┘

Total estimated:          Xh Ym
Total already logged:     Xh Ym
New time to log:          Xh Ym
```
## Step 5 — Get user confirmation
In case you have any doubts about your findings, share it with the user.

After that, say exactly as below as it is:
> Does this look right? You can tell me to:
  - Adjust any time (e.g., "Change Row 2 to 3 hours")
  - Skip any row (e.g., "Skip Row 4")
  - Add something I missed (e.g., "Add MXTS-XXXXX — 1h")
  - "Log all" to proceed as-is

## Step 6 — Log to Jira
After user does final adjustments and confirms, show the final adjusted proposed work log hours.
Only after user's confirmation, proceed to log the hours to Jira:
- First call `mcp__claude_ai_Atlassian_MCP__getAccessibleAtlassianResources` to resolve the `cloudId` for your Jira instance.
- Then call `mcp__claude_ai_Atlassian_MCP__executeWrite` (`name: addOrEditJiraIssueWorklog`) for each confirmed entry. If the operation name is rejected, look it up with `mcp__claude_ai_Atlassian_MCP__discover`.
- `timeSpent`: use Jira's time format, e.g. `1h 30m`
- `started`: noon on TARGET_DATE in ISO 8601 (e.g. `[YYYY-MM-DD]T12:00:00.000+0000`)

### If a worklog call fails
Do not stop the batch on a single failure — the user already confirmed the whole set.
- Continue with the remaining entries.
- Collect failures: ticket ID, the `timeSpent` that was attempted, and the error message.
- After the batch, report which worklogs posted and which failed, and offer to retry
  the failed ones (e.g. after the user checks permissions or fixes a closed sprint).

Show confirmation message as below:

```
📋 All N worklogs posted successfully. Here's the final confirmed log:

  ● ┌────┬─────────────┬────────────────────────────────┬──────────────────────────┬────────┬────────┐
    │ #  │ Ticket      │ Title                          │ Source(s)                │ Time   │ Logged │
    ├────┼─────────────┼────────────────────────────────┼──────────────────────────┼────────┼────────┤
    │ 1  │ PROJ-123    │ [Module] Short ticket title    │ PR 456 merged (HH:MM) +  │ 1h 00m │    Y   │
    │    │             │ that wraps if it is too long   │ Jira comment             │        │        │
    ├────┼─────────────┼────────────────────────────────┼──────────────────────────┼────────┼────────┤
    │ 2  │ PROJ-456    │ Another ticket title           │ PR 789 draft (repo,      │ 0h 30m │    Y   │
    │    │             │                                │ updated HH:MM)           │        │        │
    ├────┼─────────────┼────────────────────────────────┼──────────────────────────┼────────┼────────┤
    │ 3  │ PROJ-789    │ Yet another ticket title       │ Calendar: meeting title  │ 1h 00m │    Y   │
    │    │             │                                │ (HH:MM–HH:MM)            │        │        │
    └────┴─────────────┴────────────────────────────────┴──────────────────────────┴────────┴────────┘

    Total logged:   Xh Ym

  Done for [TARGET_DATE].
```


## Rules
1. Request only the fields needed from APIs — oversized responses cause failures.
2. `mcp__claude_ai_Atlassian_MCP__getJiraIssue` requires the parameter named `issueIdOrKey` (not `issueKey`). Using the wrong
   name causes silent validation failures — always use `issueIdOrKey`.
3. When calling `mcp__claude_ai_Atlassian_MCP__getJiraIssue` to fetch ticket details for IDs found in Slack or GitHub, request only `["summary"]`
   — omitting the fields parameter returns all fields, which can produce very large responses.

## Examples

User says: "Log my hours for today"
→ Resolves TARGET_DATE to today, collects activity from Slack, Jira, GitHub, and the calendar connector,
  then presents the summary table (Step 4) for review before logging anything. Once confirmed, posts worklogs to Jira.

User says: "Log my hours for yesterday" / "Log my hours for [YYYY-MM-DD]" / "Log my hours for last Monday"
→ Parses the date to YYYY-MM-DD and runs the same flow scoped to that date.

User says: "Change Row 2 to 1h 30m, skip Row 4, then log all"
→ Applies the adjustments and proceeds to log.

User says: "Add MXTS-9999 — 1h, then log all"
→ Appends the manual entry to the confirmed list before logging.

## Troubleshooting

**GitHub username not found**
The skill pauses at Step 1 and asks for your GitHub username. Provide it once and it is stored
in memory for future sessions.

**No Slack messages found**
The Slack search returns empty if you sent no messages on that date or if your connector lacks
private-channel access. The skill continues using Jira and GitHub signals — the summary will
still be accurate for what was found.

**`commentedBy` JQL returns no results**
Some Jira Cloud instances do not support `commentedBy` as a JQL field without ScriptRunner.
If this step returns nothing, Slack and GitHub signals still populate the summary. You can
add missed Jira ticket entries manually during Step 5.

**`mcp__claude_ai_Atlassian_MCP__executeWrite` (`name: addOrEditJiraIssueWorklog`) fails for one or more tickets**
The skill logs the rest of the batch and reports failures at the end. Common causes: closed
sprint, missing project permission, or invalid `timeSpent` format. Retry after resolving — the
skill will re-attempt only the failed entries.
