# Skill Override Justifications

## `name` — gerund form SHOULD FIX

Override accepted. `investigate-error` is the established name from PR #269 (authored by m.alting@maxxton.com). Renaming would break user muscle memory and invalidate an open PR. Action-oriented form is acceptable per `best-practices.md` strong-override criteria: "action-oriented form used consistently across skills in the plugin."

## `## Examples` — body section SHOULD FIX

Override accepted. The skill is a multi-step workflow with branching modes (Investigate / Record) and per-audience output. Inline examples would either be trivially short or balloon the body size. Concrete examples belong in a future `references/examples.md` once usage patterns stabilise.

## `## Troubleshooting` — body section SHOULD FIX

Override accepted. Troubleshooting guidance is embedded inline where errors occur (gcloud auth failure at Step 5.5, permission denied, no logs found). A separate top-level section would duplicate that content.
