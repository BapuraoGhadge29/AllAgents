# Investigate Error Guidelines

## Audience rules

- **Role prefix skips Step 2 entirely** — if the user starts with a role declaration, set `$AUDIENCE` immediately and go to Step 3. No question needed.
- **Always ask or detect when no prefix is given** — tailor the entire output to who will read it. A QA engineer does not need Oracle error codes; a DevOps engineer does not need the plain English summary; customer success needs neither.
- **Auto-detect is a suggestion, not a lock** — always offer the user a way to override before producing output.
- **`$AUDIENCE = All`** produces all three templates A → B → C. Use it when escalating across multiple teams at once.

## Report rules

- **"Who to contact" is mandatory in every template** — populate from the knowledge graph when an endpoint is available. Fall back to `search_repo_info` for CODEOWNERS, or `Team owning [service-name] — check CODEOWNERS or the internal team registry`. Never leave it blank.
- **Never guess the owner** without evidence — acceptable sources: knowledge graph, CODEOWNERS, repo metadata. If ambiguous, say so and name what would resolve it.
- **Always show your reasoning** — the "Why not [other owner]?" section in Template B prevents the ticket bouncing.
- **Generic toasts** ("Something went wrong") almost always have an underlying HTTP error — ask the user to open DevTools → Network tab and look for a red request.
- **Low-confidence verdicts** must include a suggested next step (e.g. "Ask BE to check service logs for this timestamp").
- **Stop if confused** — if the error is unclear, name what's confusing and ask. Don't produce a speculative investigation.
- **Be concise** — users come with a problem; get to the answer fast.

## Jira prompt rules (audience-driven)

Ticket creation is always delegated to the **jira-ticket-creator** skill. The rules below govern *when* to trigger that handoff.

- **QA / PO / Customer Success — Proactive (opt-out):** assume they want a ticket. Prompt: "I'll create a Jira bug ticket — just confirm: project key, priority (default P3), sprint (optional). Or reply 'skip'."
- **Developer — Optional (opt-in):** prompt: "Should I create a Jira ticket? Reply 'yes [project key]' or 'no'."
- **DevOps — Skip by default:** close with the investigation checklist. Only create on explicit request: "create ticket [project key]".

## GCP trace rules

- **Always run Step 5.5** when a GCP Trace URL or raw traceId is present. A `GEN-903 Feign client exception` means the real bug is one hop deeper — never assign to the surface service without identifying the downstream failure.
- **`gcloud` not authenticated:** tell the user to run `! gcloud auth login` in the Claude Code prompt and re-run. Do not skip silently.
- **Trace with no logs:** the log sink may not be tagging entries with the traceId. Ask DevOps to share a direct log export or check that the service emits structured logs with `logging.googleapis.com/trace`.
- **Permission denied:** "Ask DevOps to grant `roles/logging.viewer` on project `PROJECT_ID`."

## Runbook write rules

- **Always confirm before writing** — show the user the full row content before calling `updateConfluenceContent`. Never update Confluence without explicit confirmation.
- **Check for existing rows first** — fetch the current page before writing. Update in place if a row for this error signature already exists; append only if it's new.
- **Error signature format:** `{ExceptionType} in {Service}.{method} when {condition}` — short and searchable.

### HTML table template (use when creating the table from scratch)

```html
<table>
  <thead>
    <tr>
      <th>Error Signature</th>
      <th>Error Type</th>
      <th>Root Cause</th>
      <th>Solution</th>
      <th>Affected Service</th>
      <th>Owning Team</th>
      <th>Related Jira</th>
      <th>Date Added</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>{error_signature}</td>
      <td>{error_type}</td>
      <td>{root_cause}</td>
      <td>{solution}</td>
      <td>{affected_service}</td>
      <td>{owning_team}</td>
      <td>{jira_links}</td>
      <td>{date_iso}</td>
    </tr>
  </tbody>
</table>
```

When appending a row to an existing table, insert before `</tbody>`:
```html
<tr>
  <td>{error_signature}</td>
  <td>{error_type}</td>
  <td>{root_cause}</td>
  <td>{solution}</td>
  <td>{affected_service}</td>
  <td>{owning_team}</td>
  <td>{jira_links}</td>
  <td>{date_iso}</td>
</tr>
```

For `{jira_links}`, use Confluence anchor tags:
```html
<a href="https://maxxton.atlassian.net/browse/{TICKET-ID}">{TICKET-ID}</a>
```
