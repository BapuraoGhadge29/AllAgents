# Bug Report Templates

Use the template that matches `$AUDIENCE`. For **All**, output A → B → C in order.

---

## Template A — QA / PO / Customer Success

> Use when `$AUDIENCE` is **QA/PO** or **All**.
> Plain language only. No error codes, class names, HTTP status codes, or acronyms without explanation. Max 5 sentences in "What happened".

```
## What happened

[3–5 sentences:
  - What the user was trying to do
  - What they saw (the error or broken behaviour)
  - What caused it in everyday language
  - Who needs to fix it and what they need to do]

---

## Steps to reproduce

1. [Step 1]
2. [Step 2]
3. [Observe the error]

**Expected:** [What should have happened]
**Actual:**   [What happened instead — no raw error codes]

**Environment:**      [env — ask if unknown]
**Assign to:**        [plain team description, e.g. "Backend – Reservation team"]
**Who to contact:**   [team name in plain language — e.g. "The Reservation team handles this. Ping them with the error reference below."]
**Error reference:**  [traceId if available — do not call it "traceId" for non-technical readers]
**Attachments:**      [screenshots or logs provided]

---

## Known solution (if found in runbook or Jira)

[Solution text, or "No known solution found — this is a new issue."]
```

---

## Template B — Developer

> Use when `$AUDIENCE` is **Developer** or **All**.
> Technical detail, service ownership, evidence chain, Jira-ready description.

```
## Triage Verdict

Owner:            [FE / BE / Infra / Ambiguous]
Confidence:       [High / Medium / Low]
Service:          [surface service name — or "unknown"]
Root cause:       [downstream service name if GCP lookup was performed — or "see evidence"]
Team:             [$TEAM — or "check service overview"]

## Who to contact

Team:    [$TEAM]
For:     [what to ask them]
How:     [Slack channel or alias — or "check internal team registry"]
Bring:   traceId · timestamp · endpoint path · verbatim error message

## Evidence

- [Signal 1 — e.g. "HTTP 500 returned by POST /api/v1/reservations"]
- [Signal 2 — e.g. "ORA-02291: FK violation"]
- [Signal 3 — e.g. "Knowledge graph confirms reservation-service owns this endpoint"]

## GCP Trace Analysis   ← include only when Step 5.5 was executed

traceId:          <value>
Root-cause span:  <span name>
Failing service:  <service name>
Error message:    "<verbatim log error text>"
Log timestamp:    <ISO timestamp>
Call chain:       FE → [surface service] → [failing service] ✖

## Why not [the other owner]?

[One sentence ruling out the alternative — prevents the ticket bouncing.]

---

## Bug Description (ready to paste into Jira)

**Summary:** [Concise one-line title]

**Environment:** [QA / DEV / PROD / acs-test — ask if unknown]

**Steps to reproduce:**
1. [Step 1]
2. [Step 2]
3. [Observe the error]

**Expected behaviour:**
[What should have happened]

**Actual behaviour:**
[What happened — include error message verbatim]

**TraceId:** [if available]
**SpanId:**  [if available]
**Timestamp:** [ISO timestamp]

**Assign to:** [FE team / BE – [service] / Infra]

**Attachments:** [screenshots or logs provided]

---

## Known solution (if found in runbook or Jira)

[Solution text and source, or "No known solution found."]
```

---

## Template C — DevOps

> Use when `$AUDIENCE` is **DevOps** or **All**.
> Infrastructure focus: trace waterfall, failing span, log evidence, infra signals.

```
## Infrastructure Triage

Owner:               [BE / Infra]
Surface service:     [service that returned the error to the FE]
Root-cause service:  [downstream service identified from trace / logs — or "unknown"]

## GCP Trace Analysis

traceId:          <value>
spanId:           <value if available>
Project:          <GCP project searched>
Root-cause span:  <span name>
Failing service:  <service name from log resource labels>
Error message:    "<verbatim log text>"
Log timestamp:    <ISO timestamp>
Severity:         ERROR / CRITICAL

Call chain:
  FE → [surface service] → [failing service] ✖ <error>

## Infra Signals

- [Signal 1 — e.g. "Pod OOMKilled" / "CrashLoopBackOff" / "CORS missing headers"]
- [Signal 2 — e.g. "No logs found for traceId — log sink may not tag entries"]

## Recommended next steps

- [ ] [Action 1]
- [ ] [Action 2]
- [ ] [Action 3]

## Who to contact

Team:    [$TEAM — or "team owning [service-name]"]
For:     [what to escalate]
How:     [Slack channel or alias — or "check internal team registry"]
Bring:   traceId · timestamp · GCP project · failing span name

**Environment:** [env]
**TraceId:** [value]
**Timestamp:** [ISO timestamp]
```
