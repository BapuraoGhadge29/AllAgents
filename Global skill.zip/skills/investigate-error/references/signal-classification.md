# Error Signal Classification Table

Use this table to assign an **initial owner** based on signals in the input.

| Signal | Initial owner | Confidence |
|---|---|---|
| HTTP 5xx (500, 502, 503, 504) from a BE endpoint | BE | High |
| HTTP 4xx (400, 422, 404) from a BE endpoint | BE (bad request / missing resource) | Medium |
| HTTP 4xx (401, 403) | BE / Auth layer | High |
| JavaScript runtime error (`TypeError`, `Cannot read properties of undefined`, etc.) | FE | High |
| Angular rendering error (`ExpressionChangedAfterItHasBeenChecked`, `NullInjectorError`) | FE | High |
| Template render failure — failed/empty HTML output | Ambiguous — check knowledge graph | Low |
| CORS error | BE / Infra (missing headers) | High |
| Network timeout / no response | BE / Infra | Medium |
| Toast/callout with a generic message ("Something went wrong") | Ambiguous — check knowledge graph | Low |
| UI layout broken, wrong data displayed, missing element | FE | Medium |
| Data saved incorrectly / wrong values persisted | BE | Medium |
| GCP Trace URL or raw traceId shared (DevOps report) | BE / Infra — proceed to Step 5.5 | High |
| `GEN-903` / "Feign client exception" in error body | BE downstream dependency failure | High |
| Pod crash / OOMKilled / CrashLoopBackOff mentioned | Infra | High |
| Java exception (`NullPointerException`, `IllegalArgumentException`, etc.) | BE | High |
| Oracle error code (`ORA-XXXXX`) | BE / DB | High |

## Ambiguous cases

For **template render failures** and **generic toasts** ("Something went wrong"): do not guess. Proceed to Step 5 to resolve via the knowledge graph. For toasts, ask the user to open DevTools → Network tab and look for a red request.

For **GCP trace inputs**: proceed directly to Step 5.5 after completing Step 5.

## Confidence levels

| Level | Meaning |
|---|---|
| **High** | Unambiguous signal — e.g. DB error code from a BE endpoint, 401/403 from auth layer |
| **Medium** | Most likely owner but alternative is possible |
| **Low** | Unclear — state what additional info would resolve the ambiguity |

Low-confidence verdicts must include a suggested next step (e.g. "Ask BE to check service logs for this timestamp").
