---
name: investigate-error
description: Use when investigating any Maxxton error — console log, screenshot, stack trace, Oracle error, or GCP trace — to check for known solutions, classify FE/BE/Infra, and produce an audience-tailored report. Also use when someone says "we figured it out" to record the fix in the Error runbook.
argument-hint: "[optional: I'm a developer / QA / DevOps] [paste error, screenshot, stack trace, or describe what you see]"
allowed-tools:
- Bash
- Read
- WebFetch
- AskUserQuestion
- mcp__claude_ai_Maxxton_Knowledge__search_technical_graph
- mcp__claude_ai_Maxxton_Knowledge__query_openapi
- mcp__claude_ai_Maxxton_Knowledge__get_service_overview
- mcp__claude_ai_Maxxton_Knowledge__search_repo_info
- mcp__claude_ai_Atlassian_MCP__getConfluenceContent
- mcp__claude_ai_Atlassian_MCP__updateConfluenceContent
- mcp__claude_ai_Atlassian_MCP__getAccessibleAtlassianResources
- mcp__claude_ai_Atlassian_MCP__searchJiraIssuesUsingJql
disable-model-invocation: true
---

# Investigate Error

Investigates any Maxxton platform error for any audience — QA, developers, DevOps, and customer success. Checks the Error runbook for known solutions first, then classifies FE/BE/Infra, identifies the responsible service, and produces an audience-tailored report. Also records resolved errors to the runbook so future investigations find answers immediately.

**Two modes:**
- **Investigate** — determine what the error is, who owns it, whether a solution exists, and produce a report
- **Record** — given a resolved error, write the fix to the Error runbook

Trigger **Mode 2** with: "resolved", "here's the fix", "we figured it out" + the solution.

---

## Constants

| Key | Value |
|---|---|
| Error runbook page ID | `2985099267` |
| Confluence space | `POL` |
| Runbook URL | https://maxxton.atlassian.net/wiki/spaces/POL/pages/2985099267/Error+runbook |
| `$CLOUD_ID` | Resolved at runtime via `mcp__claude_ai_Atlassian_MCP__getAccessibleAtlassianResources` — call once in Step 3 and reuse |

---

## Instructions

### Mode 1: Investigate

#### Step 1 — Parse input and detect audience

**1a — Role prefix**

| The user wrote | Set `$AUDIENCE` |
|---|---|
| "I'm a developer" / "developer here" | Developer |
| "I'm a QA" / "QA here" / "I'm a tester" | QA / PO |
| "I'm a PO" / "I'm a product owner" | QA / PO |
| "I'm DevOps" / "infra here" | DevOps |
| "I'm customer success" / "CS here" | QA / PO |

If found: set `$AUDIENCE`, skip Step 2. Otherwise proceed to Step 2.

**1b — Accept the error input**

Accept any of:
- Error message, browser console output, or stack trace
- Network request/response — HTTP method, endpoint, status code, body
- Screenshot — extract visible error text, status codes, UI state
- Failed rendered HTML
- GCP Trace URL — extract `traceId` and `project`
- Raw traceId / spanId
- Java exception, Oracle `ORA-XXXXX`, Angular/TypeScript exception
- Free-text description

If a GCP Trace URL or traceId is present, flag it immediately:
```
GCP trace detected — I'll drill into logs to find the root-cause span (Step 5.5).
traceId: <value>
project:  <value or "ask user">
```

If no input: ask for at least one of — error message, HTTP endpoint + status code, screenshot, or GCP Trace URL.

---

#### Step 2 — Detect or ask audience

> Skip if `$AUDIENCE` was set in Step 1.

| Signal | Likely audience |
|---|---|
| Informal message, screenshot, "I'm seeing X" | QA / PO |
| GCP Trace URL, traceId, pod crash, OOMKilled | DevOps |
| Stack trace, class names, HTTP method + endpoint | Developer |

If auto-detected, state it and offer to override. If unclear, ask:
```
Who needs this report?
  1. QA / PO / Customer Success  — plain language, steps to reproduce, who to assign
  2. Developer                    — service ownership, error codes, trace IDs, technical fix
  3. DevOps                       — GCP trace deep-dive, infra signals, log investigation
  4. All                          — full report for all audiences
```

---

#### Step 3 — Check the Error runbook

Before any investigation, check if this error has been solved before.

Call `mcp__claude_ai_Atlassian_MCP__getAccessibleAtlassianResources` to resolve `$CLOUD_ID` (cache this value — reuse it in Mode 2). Then call `mcp__claude_ai_Atlassian_MCP__getConfluenceContent` with `content_id: "2985099267"`, `cloudId: $CLOUD_ID`, `content_format: "html"`, `detail: "full"`. Scan for rows where Error Signature, Root Cause, or Affected Service matches your extracted signals.

**If a match is found:** surface the solution immediately and ask if it resolves the issue. Only proceed to Step 4 if there is no match or the solution didn't work.

---

#### Step 4 — Classify the error

Read `references/signal-classification.md` for the signal → owner → confidence table and ambiguous-case rules. Assign an initial owner (`$OWNER`) and confidence level.

State what you think the error is before searching — use hedging that matches actual confidence ("this looks like", "this is likely", "this is").

If the input is too ambiguous (no signals identifiable): name what's missing and ask. Do not proceed speculatively.

---

#### Step 5 — Look up the responsible service

Run steps 5a–5c and the Jira search in parallel.

**5a** — If an HTTP endpoint is available: use `mcp__claude_ai_Maxxton_Knowledge__search_technical_graph` with the endpoint path and `node_type: ControllerMethod`. Extract the service name and team.

**5b** — Use `mcp__claude_ai_Maxxton_Knowledge__get_service_overview` with the service name for ownership and dependencies.

**5c** — Use `mcp__claude_ai_Maxxton_Knowledge__query_openapi` with the endpoint to check expected responses and required parameters.

**5d** — Store the owning team as `$TEAM`. Populate the Who to contact block:
```
Who to contact:  $TEAM
For:             [what to ask them]
How:             [Slack channel or alias — or "check internal team registry"]
Bring:           traceId · timestamp · endpoint · verbatim error message
```

If the knowledge graph returns nothing: use `mcp__claude_ai_Maxxton_Knowledge__search_repo_info` to locate CODEOWNERS. If that also returns nothing: `Team owning [service-name] — check CODEOWNERS or the internal team registry`.

**Jira search (parallel):** call `mcp__claude_ai_Atlassian_MCP__searchJiraIssuesUsingJql` with a query targeting key signals:
```
text ~ "[key signal from Step 4]" ORDER BY created DESC
```
Separate open from resolved tickets — resolved ones may contain the fix.

**If no endpoint available** (pure JS error or screenshot only): skip to Step 5.5 if a traceId is present; otherwise go to Step 6.

---

#### Step 5.5 — GCP Trace & Log Lookup (DevOps path)

**Trigger:** GCP Trace URL, raw traceId, or traceId/spanId in the error body. A `GEN-903 Feign client exception` at the surface means the real bug is one hop deeper — always run this step before assigning to the surface service.

**a** — Extract: `traceId` (32-char hex), `spanId` (16-char hex, optional), `project` (from URL or ask).

**b** — Check gcloud auth:
```bash
gcloud auth list --filter="status=ACTIVE" --format="value(account)"
```
If no active account: tell user to run `! gcloud auth login` and re-run. Continue to Step 6 with a note.

**c** — Fetch structured logs:
```bash
gcloud logging read \
  'trace="projects/PROJECT_ID/traces/TRACE_ID"' \
  --project=PROJECT_ID --limit=100 --order=asc --format=json
```
Find the earliest ERROR-severity entry NOT from the surface service — that is the root cause.

**d** — Fetch trace waterfall (latency issues only):
```bash
gcloud trace traces describe TRACE_ID --project=PROJECT_ID --format=json
```
Find the span with `status.code != 0` or the longest duration.

Report findings using the GCP Trace Analysis block in `references/report-templates.md`.

---

#### Step 6 — Produce the report

Read `references/report-templates.md`. Produce the template matching `$AUDIENCE`. For **All**: output A → B → C in order.

---

#### Step 7 — Jira ticket

Read `references/guidelines.md` (Jira prompt rules) for the audience-driven trigger behaviour (QA/PO opt-out, Developer opt-in, DevOps explicit only).

Ticket creation is delegated to the **jira-ticket-creator** skill. Pre-fill from triage context:

| Field | Value |
|---|---|
| Issue type | Bug |
| Summary | `[PREFIX]: <action-oriented title>` — ask user for prefix if none fits |
| Description | Business Context, Expected/Actual Behaviour, Steps to Reproduce, Technical Details (endpoint, error code verbatim, service, traceId, timestamp), Dependencies (`$TEAM`), Impact/Risk |
| Acceptance Criteria | Gherkin Given/When/Then covering the failing scenario |
| Labels | `Refinement` + `Backend` (BE owner) and/or `FrontEnd` (FE owner) |
| Priority | P3 default, or what user stated |
| Security | `All employees` (id: `10058`) |

Duplicate check before creating (call `mcp__claude_ai_Atlassian_MCP__searchJiraIssuesUsingJql`):
```
project = MXTS AND issuetype = Bug AND summary ~ "[key error phrase]" ORDER BY created DESC
```
If a match exists, show it and ask whether to create new or link to existing.

---

### Mode 2: Record Resolution

**Triggered when:** user says "resolved", "here's the fix", "we figured it out", or provides a solution.

#### Step 1 — Collect details

| Field | How to get |
|---|---|
| Error signature | `{ExceptionType} in {Service}.{method} when {condition}` |
| Error type | Java / Oracle / Angular / Client |
| Root cause | What actually caused it |
| Solution | Step-by-step fix — ask for detail if vague |
| Affected service | From investigation context, or ask |
| Owning team | From investigation context, or ask |
| Related Jira | Ticket numbers (optional) |

Use everything gathered in Mode 1. Only ask for what's missing.

#### Step 2 — Confirm before writing

Show the user the row you intend to add before touching Confluence:

> I'll add this to the Error runbook — does this look right?
> - **Error signature**: ...
> - **Root cause**: ...
> - **Solution**: ...
> - **Team**: ...

Only proceed after confirmation.

#### Step 3 — Update the runbook

1. If `$CLOUD_ID` not yet resolved, call `mcp__claude_ai_Atlassian_MCP__getAccessibleAtlassianResources`
2. Fetch current page: `mcp__claude_ai_Atlassian_MCP__getConfluenceContent` (`content_id: "2985099267"`, `cloudId: $CLOUD_ID`, `content_format: "html"`, `detail: "full"`) — get content and version number
3. Check if a row exists for this error signature — update in place or append
4. If no table exists, create from scratch (see template in `references/guidelines.md`)
5. Write back with `mcp__claude_ai_Atlassian_MCP__updateConfluenceContent`

---

## Guidelines

Read `references/guidelines.md` for the full set of rules covering audience handling, report quality, Jira prompting, GCP trace behaviour, and runbook write rules.
