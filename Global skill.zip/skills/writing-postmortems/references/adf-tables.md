# ADF Table Formatting for Postmortems

This reference covers the exact ADF (Atlassian Document Format) structures needed for postmortem tables on Confluence. Using markdown for tables will result in broken formatting — always use ADF when creating or updating postmortem pages.

## Table of Contents
1. [Statistics Table](#statistics-table)
2. [Timeline Table](#timeline-table)
3. [Follow-up Checklist](#follow-up-checklist)
4. [Mentions](#mentions)
5. [Full ADF Document Skeleton](#full-adf-document-skeleton)

---

## Statistics Table

The Statistics table has **no header row**. The left column uses `tableHeader` cells (grey background) and the right column uses regular `tableCell`. Column widths are set to ~190px left and ~570px right.

```json
{
  "type": "table",
  "attrs": {
    "isNumberColumnEnabled": false,
    "layout": "default",
    "localId": "statistics-table"
  },
  "content": [
    {
      "type": "tableRow",
      "content": [
        {
          "type": "tableHeader",
          "attrs": { "colwidth": [190] },
          "content": [
            {
              "type": "paragraph",
              "content": [{ "type": "text", "text": "Client impact" }]
            }
          ]
        },
        {
          "type": "tableCell",
          "attrs": { "colwidth": [570] },
          "content": [
            {
              "type": "paragraph",
              "content": [{ "type": "text", "text": "All clients." }]
            }
          ]
        }
      ]
    },
    {
      "type": "tableRow",
      "content": [
        {
          "type": "tableHeader",
          "attrs": { "colwidth": [190] },
          "content": [
            {
              "type": "paragraph",
              "content": [{ "type": "text", "text": "Client impacted time" }]
            }
          ]
        },
        {
          "type": "tableCell",
          "attrs": { "colwidth": [570] },
          "content": [
            {
              "type": "paragraph",
              "content": [{ "type": "text", "text": "16:45, 2026-02-27 – 02:24, 2026-02-28 (9h 39m)" }]
            }
          ]
        }
      ]
    }
  ]
}
```

Repeat the `tableRow` pattern for each field: Client impact, Client impacted time, Impacted component(s), Incident starts, Incident resolved, Mean time to detect (MTTD), Mean time to resolution (MTTR), Technical responder(s).

The key points:
- Left cell is always `tableHeader` (not `tableCell`) — this gives the grey background
- Right cell is always `tableCell`
- Both cells include `"colwidth"` in attrs
- Every cell wraps its text in a `paragraph` node

## Timeline Table

The Timeline table **does** have a header row. Same column widths (190px / 570px).

```json
{
  "type": "table",
  "attrs": {
    "isNumberColumnEnabled": false,
    "layout": "default",
    "localId": "timeline-table"
  },
  "content": [
    {
      "type": "tableRow",
      "content": [
        {
          "type": "tableHeader",
          "attrs": { "colwidth": [190] },
          "content": [
            {
              "type": "paragraph",
              "content": [{ "type": "text", "text": "Time" }]
            }
          ]
        },
        {
          "type": "tableHeader",
          "attrs": { "colwidth": [570] },
          "content": [
            {
              "type": "paragraph",
              "content": [{ "type": "text", "text": "Description" }]
            }
          ]
        }
      ]
    },
    {
      "type": "tableRow",
      "content": [
        {
          "type": "tableCell",
          "attrs": { "colwidth": [190] },
          "content": [
            {
              "type": "paragraph",
              "content": [{ "type": "text", "text": "16:45, 2026-02-27" }]
            }
          ]
        },
        {
          "type": "tableCell",
          "attrs": { "colwidth": [570] },
          "content": [
            {
              "type": "paragraph",
              "content": [{ "type": "text", "text": "Automated monitoring detects pending database threads..." }]
            }
          ]
        }
      ]
    }
  ]
}
```

## Follow-up Checklist

Use `taskList` and `taskItem` for the follow-up section. Each item has a `localId` and a `state` of either `"TODO"` or `"DONE"`.

```json
{
  "type": "taskList",
  "attrs": { "localId": "followup-list" },
  "content": [
    {
      "type": "taskItem",
      "attrs": {
        "localId": "task-1",
        "state": "TODO"
      },
      "content": [
        {
          "type": "text",
          "text": "Disaster Recovery review ",
          "marks": [{ "type": "strong" }]
        },
        {
          "type": "mention",
          "attrs": {
            "id": "<atlassian-account-id>",
            "text": "@Firstname Lastname",
            "accessLevel": ""
          }
        },
        { "type": "hardBreak" },
        {
          "type": "text",
          "text": "Evaluate the current DR strategy and execution procedures."
        }
      ]
    }
  ]
}
```

## Mentions

To @mention someone in ADF, use the `mention` node type with their Atlassian account ID. Always look the account ID up with `lookupJiraAccountId` using the person's name — never guess or reuse an ID from an example.

```json
{
  "type": "mention",
  "attrs": {
    "id": "<atlassian-account-id>",
    "text": "@Firstname Lastname",
    "accessLevel": ""
  }
}
```

## Full ADF Document Skeleton

The top-level ADF structure for a postmortem page. Note: the `// ...` comment lines below are illustrative placeholders (hence the `jsonc` fence) — real ADF is strict JSON and must not contain comments, so replace them with the actual nodes before sending:

```jsonc
{
  "version": 1,
  "type": "doc",
  "content": [
    {
      "type": "heading",
      "attrs": { "level": 1 },
      "content": [{ "type": "text", "text": "Summary" }]
    },
    {
      "type": "paragraph",
      "content": [{ "type": "text", "text": "Summary text here..." }]
    },
    {
      "type": "heading",
      "attrs": { "level": 1 },
      "content": [{ "type": "text", "text": "Statistics" }]
    },
    // ... Statistics table (see above)
    {
      "type": "heading",
      "attrs": { "level": 1 },
      "content": [{ "type": "text", "text": "Timeline" }]
    },
    // ... Timeline table (see above)
    {
      "type": "heading",
      "attrs": { "level": 1 },
      "content": [{ "type": "text", "text": "Leadup" }]
    },
    // ... paragraphs
    {
      "type": "heading",
      "attrs": { "level": 1 },
      "content": [{ "type": "text", "text": "Failure" }]
    },
    // ... paragraphs, possibly bullet lists
    {
      "type": "heading",
      "attrs": { "level": 1 },
      "content": [{ "type": "text", "text": "Impact" }]
    },
    // ... paragraphs
    {
      "type": "heading",
      "attrs": { "level": 1 },
      "content": [{ "type": "text", "text": "Detection" }]
    },
    // ... paragraphs
    {
      "type": "heading",
      "attrs": { "level": 1 },
      "content": [{ "type": "text", "text": "Root cause" }]
    },
    // ... paragraphs
    {
      "type": "heading",
      "attrs": { "level": 1 },
      "content": [{ "type": "text", "text": "Discussion points" }]
    },
    // ... bullet list or headed subsections
    {
      "type": "heading",
      "attrs": { "level": 1 },
      "content": [{ "type": "text", "text": "Lessons learned" }]
    },
    {
      "type": "heading",
      "attrs": { "level": 2 },
      "content": [{ "type": "text", "text": "What went well" }]
    },
    // ... bullet list
    {
      "type": "heading",
      "attrs": { "level": 2 },
      "content": [{ "type": "text", "text": "Things that went poorly" }]
    },
    // ... bullet list
    {
      "type": "heading",
      "attrs": { "level": 2 },
      "content": [{ "type": "text", "text": "Where we got lucky" }]
    },
    // ... bullet list
    {
      "type": "heading",
      "attrs": { "level": 1 },
      "content": [{ "type": "text", "text": "Follow up" }]
    }
    // ... taskList (see above)
  ]
}
```

### Bullet Lists in ADF

For sections like Discussion points and Lessons learned subsections, use:

```json
{
  "type": "bulletList",
  "content": [
    {
      "type": "listItem",
      "content": [
        {
          "type": "paragraph",
          "content": [{ "type": "text", "text": "Item text here" }]
        }
      ]
    }
  ]
}
```

### Bold Text

Wrap text in a `strong` mark:

```json
{
  "type": "text",
  "text": "Important text",
  "marks": [{ "type": "strong" }]
}
```

### Links

Use the `link` mark:

```json
{
  "type": "text",
  "text": "MXTS-74846",
  "marks": [
    {
      "type": "link",
      "attrs": {
        "href": "https://maxxton.atlassian.net/browse/MXTS-74846"
      }
    }
  ]
}
```