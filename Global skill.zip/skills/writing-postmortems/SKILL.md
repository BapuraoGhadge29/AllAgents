---
name: writing-postmortems
description: "Use when a production incident or outage needs a formal postmortem — drafting one from scratch, updating a draft, or producing a client-facing external version. Trigger phrases: \"write a postmortem for SAN-2113\", \"document this outage\", \"prepare the postmortem meeting\".\n"
argument-hint: "[incident-ticket-key]"
disable-model-invocation: true
allowed-tools:
- Bash
- Read
- AskUserQuestion
- mcp__claude_ai_Atlassian_MCP__getAccessibleAtlassianResources
- mcp__claude_ai_Atlassian_MCP__getJiraIssue
- mcp__claude_ai_Atlassian_MCP__searchJiraIssuesUsingJql
- mcp__claude_ai_Atlassian_MCP__searchConfluence
- mcp__claude_ai_Atlassian_MCP__getConfluenceContent
- mcp__claude_ai_Atlassian_MCP__createConfluenceContent
- mcp__claude_ai_Atlassian_MCP__updateConfluenceContent
- mcp__claude_ai_Atlassian_MCP__discover
- mcp__claude_ai_Atlassian_MCP__executeRead
- mcp__claude_ai_Maxxton_Knowledge__get_service_overview
- mcp__claude_ai_Maxxton_Knowledge__get_call_chain
- mcp__claude_ai_Maxxton_Knowledge__search_technical_graph
- mcp__claude_ai_Slack__slack_search_public
- mcp__claude_ai_Slack__slack_search_public_and_private
- mcp__claude_ai_Slack__slack_read_thread
---

# Writing Postmortems

You help Maxxton engineers draft blameless postmortem documents and publish them to Confluence. Postmortems at Maxxton are not about blame — they're about shared learning. Your job is to gather evidence from every available source, structure it into the standard template, and produce a draft that the team can refine together.

## Workflow Overview

1. **Identify the incident** — get the Jira ticket key and understand the scope
2. **Gather sources** — pull data from Jira, Slack, and GCP logs in parallel
3. **Draft the postmortem** — fill in the template with facts from the sources
4. **Create a Confluence draft** — publish as an unpublished draft under the correct yearly Postmortems page
5. **Iterate** — incorporate feedback from the user until they're ready to publish

## Step 1: Identify the Incident

Ask the user for:
- The **Jira ticket key** (e.g., SAN-2113, MXTS-74846). If they mention an incident without a ticket, help them find it.
- The **resolution date** — the page title and yearly parent page use the date the incident was resolved (not when it was first reported; a slow-burn issue reported in November may be resolved — and filed — the following year). If unclear, you'll extract it from the ticket/Slack later.
- Any **specific Slack channels** where the incident was discussed (often there's a dedicated channel like `#san-2113`, or it was discussed in team/guild channels).

If the user gives you a ticket key upfront, proceed directly to gathering sources.

## Step 2: Gather Sources (Do This in Parallel)

Speed matters here — launch these searches simultaneously rather than one at a time.

### Jira
- Fetch the full ticket with `mcp__claude_ai_Atlassian_MCP__getJiraIssue` (use `responseContentFormat: markdown` for readability)
- Read **all comments** (`mcp__claude_ai_Atlassian_MCP__executeRead` with `name: listJiraIssueComments`; `getJiraIssue` only reports a count) — these often contain the richest timeline data, root cause analysis, and script details
- Check for **linked issues** — related P1s, follow-up tickets, sub-tasks, and "caused by" / "blocks" links all provide context about the incident scope and follow-up work
- Fetch **sub-tickets** (find them with `mcp__claude_ai_Atlassian_MCP__searchJiraIssuesUsingJql` on `parent = <key>`) — they may contain parallel investigations, specific fixes, or verification steps done by different team members
- Check for **related PRs** — if the incident was caused by a code change (hotfix, deployment) or fixed by one, find the relevant GitHub pull requests. Look for PR links in Jira comments, or search GitHub for the ticket key (e.g., `gh pr list --search "SAN-2113"`). PRs tell you exactly what changed, which is invaluable for the Root Cause and Failure sections.
- Note any **file attachments** mentioned in comments (you can see metadata but typically can't download the files directly — flag these to the user)

### Slack
Search across multiple channels — incident discussions at Maxxton tend to span several places:
- **Dedicated incident channel** (e.g., `#san-2113`) — the primary source for timeline and real-time decisions
- **Team channels** (e.g., `#proj-hypercare-sandaya`) — customer impact discussions
- **Guild channels** (e.g., `#guild-backend`, `#guild-development`) — technical deep-dives
- **General incident channels** if they exist

Use both `mcp__claude_ai_Slack__slack_search_public` and `mcp__claude_ai_Slack__slack_search_public_and_private` with the ticket key as the search term. When you find relevant threads, read the full thread with `mcp__claude_ai_Slack__slack_read_thread` to get the complete conversation.

### GCP Logs (when relevant)
For infrastructure or service incidents, use `gcloud` CLI via bash to query Cloud Logging:
- Search for error logs around the incident timeframe
- Look for specific trace IDs mentioned in the Jira ticket or Slack
- Check service restart events, deployment logs, or database connection issues

Not every postmortem needs GCP data — data quality issues or process incidents may not have relevant logs.

### Maxxton Knowledge Base
Use the Maxxton Knowledge MCP tools to enrich the postmortem with architectural context:
- `get_service_overview` — understand what the affected service does and its role in the platform
- `get_call_chain` — map upstream and downstream dependencies to explain the blast radius (why did a failure in service X also break services Y and Z?)
- `search_technical_graph` — find related services, entities, or endpoints

This context is especially helpful for the Impact and Failure sections, where readers who aren't familiar with the affected service need to understand the bigger picture.

### GitHub
Beyond PRs linked in Jira, check recent deployment history around the incident timeframe:
- `gh pr list --search "ticket-key"` — find PRs referencing the incident ticket
- Recent merges to main/master in the affected service's repo around the incident start time
- Release tags or deployment workflows that may have triggered the incident

If the incident was caused by a code change, the diff tells you exactly what went wrong. If it was fixed by a code change, the fix PR documents the resolution.

### Confluence
- Check if a draft or related page already exists under the Postmortems section — this is also a **mandatory gate** before page creation in Step 4, so doing it now saves a surprise later
- Look for any referenced documentation (architecture docs, runbooks) that provide context

### Pre-investigation with existing skills
If the incident hasn't been fully investigated yet, consider using the `developer:investigate-alert` skill first. It correlates GCP logs, recent commits, Slack threads, and Jira tickets into a structured investigation — its output can feed directly into the postmortem draft. Similarly, `developer:trace-investigate` can dig into specific trace IDs found during the investigation.

### When sources disagree
Jira comments, Slack threads, and logs frequently disagree on exact times and sequence — Jira comments are often written hours later from memory, while Slack messages and log entries carry real timestamps. Resolve conflicts in this order:

1. **Log entries and monitoring alerts** — machine timestamps, most reliable
2. **Slack message timestamps** — written in the moment
3. **Jira comments and descriptions** — often retrospective recollections

Normalize everything to one timezone before comparing (Slack shows times in the reader's local timezone; logs are usually UTC). If a discrepancy can't be resolved from the evidence, don't silently pick one — note both versions in the draft and flag the conflict to the user.

## Step 3: Draft the Postmortem

Use the template structure below. Fill in every section with facts gathered from your sources. Be specific — include timestamps, names (using Confluence @mentions where possible), ticket numbers, and exact error messages.

### Template Structure

The page title follows the format: `YYYY-MM-DD: Short description of incident`, where the date is the **resolution date** of the incident.

#### Summary
A concise 2-3 paragraph overview of what happened, when, what caused it, how it was resolved, and whether there was data loss or lasting impact. This should be readable by someone who won't read the rest of the document.

#### Statistics
A two-column table (no header row) with these fields:

| Client impact | Which clients were affected |
| Client impacted time | Start datetime – End datetime (duration) |
| Impacted component(s) | Which services/systems were affected |
| Incident starts | Datetime |
| Incident resolved | Datetime |
| Mean time to detect (MTTD) | Duration |
| Mean time to resolution (MTTR) | Duration |
| Technical responder(s) | @mentions of people who worked on it |

For incidents that aren't classic infrastructure outages (e.g., data quality issues, slow-burn bugs), adapt the fields sensibly. MTTD for a data issue might be "time from introduction to first customer report."

#### Timeline
A two-column table with **Time** and **Description** columns. Include every significant event with timestamps. Source these from Jira comments, Slack messages, and log timestamps. Use the timezone that makes most sense for the incident (CET for European incidents, IST for India-based response, etc.) and state which timezone at the top.

#### Leadup
What was happening before the incident? Any deployments, hotfixes, configuration changes, or maintenance windows that set the stage?

#### Failure
What specifically broke and why? Be technical but clear. If there were multiple contributing factors, list them.

#### Impact
What was the business impact? Which clients, which functionality, how many users affected? Was there data loss?

#### Detection
How was the incident discovered? Automated alerting, customer report, internal observation? Note the detection time and whether monitoring worked as expected.

#### Root cause
The deep technical explanation. If there was an external root cause analysis (e.g., from Google), quote or reference it. This section should be thorough enough that an engineer unfamiliar with the system can understand what went wrong.

#### Discussion points
Questions for the postmortem meeting. Frame these as open questions that encourage discussion, not as accusations. Focus on systemic improvements rather than individual actions.

#### Lessons learned
Three subsections:
- **What went well** — what worked as expected or better than expected in the response
- **Things that went poorly** — what didn't work, what was harder than it should have been
- **Where we got lucky** — things that could have made it worse but didn't

#### Follow up
A checklist of action items with:
- Team or person responsible (use @mentions)
- Clear description of what needs to happen
- Link to Jira ticket if one exists (create follow-up tickets if the user wants)

When drafting or discussing in chat, `- [ ]` / `- [x]` checkboxes are fine shorthand — but the published Confluence page must represent these as native Confluence tasks (see Step 4 and the format guide fetched via `mcp__claude_ai_Atlassian_MCP__executeRead` `getContentFormatGuide`); never publish markdown checkboxes.

## Step 4: Create a Confluence Draft

Publish the postmortem as an **unpublished draft** on Confluence.

### First: check for an existing postmortem (mandatory)

Before creating anything, search the POL space for an existing postmortem that references this ticket via `mcp__claude_ai_Atlassian_MCP__searchConfluence` (CQL: `text ~ "SAN-2113" and space = POL`, plus a title search on the incident description). Incidents that took weeks to resolve often already have a postmortem started by someone else — creating a second page splits the audit trail and the team ends up reviewing the wrong one. If a page exists, show it to the user and ask whether to **update it** or genuinely start a new one. Only proceed to create when you're sure none exists or the user explicitly chose a new page.

### Location

Resolve the location dynamically — yearly page IDs go stale, so never hardcode them:

1. **Space**: key `POL` on the Maxxton cloud (cloud ID: `f4860c06-4133-40c9-be0a-a7e88cb8404f`; if that ID is ever rejected, re-resolve it with `mcp__claude_ai_Atlassian_MCP__getAccessibleAtlassianResources`). `mcp__claude_ai_Atlassian_MCP__createConfluenceContent` needs the **numeric space ID**, not the key — resolve it once via `mcp__claude_ai_Atlassian_MCP__executeRead` (`name: listConfluenceSpaces`) filtered on key `POL`. Use `mcp__claude_ai_Atlassian_MCP__discover` if an operation name is rejected.
2. **Parent page**: search for the page titled `Postmortems - <resolution year>` in the POL space with `mcp__claude_ai_Atlassian_MCP__searchConfluence` (CQL: `title = "Postmortems - 2026" and space = POL`). Use the year the incident was **resolved** — same date as the page title — not the year it was reported. If the yearly page doesn't exist yet (e.g., the first incident of a new year), tell the user instead of guessing a parent.
3. **Status**: create as `draft` (not `current`) so it's not visible until the user publishes.

### Confluence Formatting (HTML)

This is important — use HTML (`body: {format: html, value}`), not markdown, when creating or updating Confluence pages; the v2 connector has no ADF format. Call `mcp__claude_ai_Atlassian_MCP__executeRead` (`name: getContentFormatGuide`, `inputs: {toolName: "createConfluenceContent"}`) first. Markdown tables don't render correctly in Confluence (missing grey header cells, wrong column widths, separator lines showing as content).

Read `references/adf-tables.md` for the intended table layout (it is written in ADF terms; express the same layout in the HTML the format guide describes). The key formatting requirements are:

- **Statistics table**: Left column cells are header cells (`th`, grey background). No header row at the top. Column widths: ~190px left, ~570px right.
- **Timeline table**: Has a header row with "Time" and "Description". Column widths: ~190px left, ~570px right.
- **Follow-up items**: Use native Confluence tasks for the checklist.
- **@mentions**: Use user mentions with the person's Atlassian account ID (look IDs up with `mcp__claude_ai_Atlassian_MCP__executeRead` (`name: lookupJiraAccountId`) — never guess them).

### Creating the Page

**Confirmation gate (required):** creating a page is a write to a shared space. Before calling the tool, show the user the proposed title, the resolved parent location, and a short summary of the content, and wait for their explicit go-ahead. Do not create the page on inferred approval.

Once confirmed, use the `mcp__claude_ai_Atlassian_MCP__createConfluenceContent` tool with:
- `spaceId`: the numeric POL space ID resolved above
- `parentId`: the yearly postmortems page ID resolved above
- `title`: formatted as `YYYY-MM-DD: Short description`
- `status`: `draft`
- `body`: `{format: html, value: <the full page HTML>}`

After creation, provide the user with the edit link: `https://maxxton.atlassian.net/wiki/spaces/POL/pages/edit-v2/{pageId}`

## Step 5: Iterate

After creating the draft:
1. Tell the user what sources you used and any gaps (e.g., file attachments you couldn't read)
2. Flag any sections where you had to infer or where you're uncertain — including unresolved timeline conflicts between sources
3. Ask if they want to adjust the framing (e.g., for data quality incidents, the "Detection" and "MTTR" sections may need a different tone than infrastructure incidents)
4. Apply their feedback and update the page directly with `mcp__claude_ai_Atlassian_MCP__updateConfluenceContent`

## Step 6: Generate External (Client-Facing) Version

After the internal postmortem is reviewed and finalized, the user may ask for a client-facing version. This is triggered by phrases like "make the client version", "create the external version", "prepare this for clients", or "we need to share this with [client name]".

The external version starts from the internal postmortem and applies these transformations:

### What to remove
- **Individual engineer names** — replace @mentions with team names or roles (e.g., "the engineering team" instead of a personal @mention)
- **Internal discussion points** — these are for the internal meeting, not for clients
- **"Where we got lucky"** subsection — clients don't need to know how close it got
- **Internal tooling details** — specific monitoring tool names, internal Slack channel references, internal processes
- **Internal follow-up items** that are purely about internal process improvements

### What to rewrite
- **Root cause** — keep it factual and thorough, but reframe in terms clients understand. If the root cause came from an external provider (like Google), their official statement can be quoted. Internal code-level details ("missing validation check in the SELECT query") should be abstracted to the appropriate level ("a software defect in the data processing logic").
- **Summary** — rewrite for a client audience. Focus on: what happened, how long it lasted, what was impacted, that it's resolved, and whether there was data loss.
- **Failure section** — simplify technical details. Clients care about *what* failed, not the internal mechanics of *how*.
- **Lessons learned** — keep "What went well" and rephrase "Things that went poorly" as "Areas for improvement" with a forward-looking tone.
- **Follow-up items** — only include actions that are relevant to clients (e.g., DR improvements, communication improvements). Frame them as commitments.

### Naming and location
- Title format: `(EXTERNAL VERSION) YYYY-MM-DD: Short description`
- Same parent page as the internal version (same yearly Postmortems page)
- Create as a draft so the user can review before publishing

### Tone shift
The internal postmortem is candid and technical. The external version should be professional, confident, and reassuring — while remaining honest. The client should come away feeling that Maxxton understands what happened, has it under control, and is taking concrete steps to prevent recurrence.

## Examples

**Example 1 — fresh postmortem:**
User says: "Write a postmortem for SAN-2113"
Output: sources gathered from Jira (all comments), the dedicated Slack channel, and the Knowledge MCP; full template drafted as HTML; existing-postmortem check finds none; draft page created under the yearly Postmortems page with the edit link returned.

**Example 2 — existing page found:**
User says: "Write a postmortem for SAN-2113" (a postmortem page already exists)
Output: the mandatory pre-create check finds the existing page; the user is shown it and asked update-vs-new before anything is created.

**Example 3 — external version:**
User says: "Create the client version for the SAN-2113 postmortem"
Output: a `(EXTERNAL VERSION) [YYYY-MM-DD]: …` draft next to the internal page — engineer names replaced with roles, "Where we got lucky" removed, root cause reframed for a client audience.

## Troubleshooting

| Symptom | Fix |
|---|---|
| `mcp__claude_ai_Atlassian_MCP__createConfluenceContent` rejects the body | The HTML must match the format guide (`getContentFormatGuide`) — remove any placeholder comments and unclosed tags from the skeleton. |
| Tables render without grey header cells | Markdown was used instead of HTML, or the left column uses `td` — re-read `references/adf-tables.md` and rebuild with `th` cells. |
| `spaceId` not accepted | The space *key* (`POL`) was passed instead of the numeric ID — resolve via `mcp__claude_ai_Atlassian_MCP__executeRead` (`name: listConfluenceSpaces`). |
| Yearly parent page not found | Check the **resolution** year, not the report year; if the year's page genuinely doesn't exist yet, ask the user rather than guessing. |
| @mention renders as plain text | The account ID was guessed or malformed — look it up with `mcp__claude_ai_Atlassian_MCP__executeRead` (`name: lookupJiraAccountId`). |
| Timeline times disagree between sources | Apply the precedence in "When sources disagree" (logs > Slack > Jira) and flag what can't be reconciled. |

## Important Notes

### Tone
Postmortems are blameless. Never frame actions as someone's fault. Use passive voice for failures ("validation checks were missing") rather than attributive voice ("developer X forgot to add validation"). The goal is systemic improvement, not individual blame.

### File Attachments
The Jira and Slack APIs expose file metadata but typically can't download file content directly. When you encounter important attachments (scripts, documentation, verification queries), tell the user which files you found and ask them to upload the content if it should be integrated into the postmortem.

### Adapt the Template
Not every incident fits the template perfectly. Infrastructure outages map cleanly to all sections. Data quality issues, process failures, or security incidents may need sections renamed or reframed. Use your judgment — the template is a guide, not a straitjacket. The key sections (Summary, Timeline, Root cause, Lessons learned, Follow up) should always be present.

### Reference Real Examples
If you need to check how something was formatted in a previous postmortem, fetch a recently **published** postmortem from the current yearly Postmortems page with `mcp__claude_ai_Atlassian_MCP__getConfluenceContent` and use it as a formatting reference — published pages reflect the format the team actually reviews and approves.
