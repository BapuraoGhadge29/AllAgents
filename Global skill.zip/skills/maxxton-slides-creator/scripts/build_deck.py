#!/usr/bin/env python3
"""
build_deck.py — Assemble a branded Maxxton slide deck from a bundled template.

Self-contained: only uses the Python standard library. It unpacks the bundled
template (assets/<theme>.pptx), locates the layout slides it needs by their
*marker text* (which is identical in the light and dark templates even though
the slide numbers differ), duplicates/reorders them per a JSON content spec,
removes the unused template slides, injects your content into the placeholders,
and writes a finished .pptx.

Usage:
    python build_deck.py --theme dark --spec spec.json --out deck.pptx

Layout detection (theme-independent):
    title      -> slide containing "Presentation title"
    divider    -> slide containing "Section title"
    two_col    -> slide containing "FINALISE REQUIREMENTS" exactly twice
    contrast   -> slide containing "Name of step" exactly twice
    statement  -> slide containing "This is a statement,"
    closing    -> reuses the title layout

Filling is keyed on placeholder structure (ph type / idx / x-offset), which is
byte-identical between the two templates, so the same code fills either theme.
Text runs inherit their colour/font from the template, so content stays readable
on both the dark and the light background.
"""
import argparse, json, os, re, shutil, tempfile, zipfile, sys

SKILL_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SLIDE_CT = "application/vnd.openxmlformats-officedocument.presentationml.slide+xml"
REL_SLIDE = "http://schemas.openxmlformats.org/officeDocument/2006/relationships/slide"
REL_NOTES = "http://schemas.openxmlformats.org/officeDocument/2006/relationships/notesSlide"

# ----------------------------------------------------------------------------- xml text helpers
def esc(t):
    return (t.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
             .replace("“", "&#x201C;").replace("”", "&#x201D;")
             .replace("’", "&#x2019;").replace("‘", "&#x2018;")
             .replace("—", "&#x2014;").replace("–", "&#x2013;")
             .replace("·", "&#xB7;"))

def run(text, sz=None, bold=False):
    """A run that INHERITS colour/font from the placeholder (theme-correct)."""
    rpr = '<a:rPr lang="en-GB"' + (f' sz="{sz}"' if sz else "") + (' b="1"' if bold else "") + "/>"
    return f"<a:r>{rpr}<a:t>{esc(text)}</a:t></a:r>"

def para(runs, bullet=False, spc_aft=600, line=100000):
    bu = ('<a:buFont typeface="Arial"/><a:buChar char="&#8226;"/>' if bullet else "<a:buNone/>")
    marL = ' marL="171450" indent="-171450"' if bullet else ' marL="0" indent="0"'
    return (f'<a:p><a:pPr{marL} lvl="0" rtl="0" algn="l">'
            f'<a:lnSpc><a:spcPct val="{line}"/></a:lnSpc>'
            f'<a:spcBef><a:spcPts val="0"/></a:spcBef>'
            f'<a:spcAft><a:spcPts val="{spc_aft}"/></a:spcAft>{bu}</a:pPr>'
            + "".join(runs) + "</a:p>")

# ----------------------------------------------------------------------------- pptx pack / unpack
def extract(src, d):
    with zipfile.ZipFile(src) as z:
        z.extractall(d)

def repack(d, out):
    if os.path.exists(out):
        os.remove(out)
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
        ct = os.path.join(d, "[Content_Types].xml")
        z.write(ct, "[Content_Types].xml")
        for root, _, files in os.walk(d):
            for f in files:
                full = os.path.join(root, f)
                arc = os.path.relpath(full, d)
                if arc == "[Content_Types].xml":
                    continue
                z.write(full, arc)

# ----------------------------------------------------------------------------- package paths
def slides_dir(d):  return os.path.join(d, "ppt", "slides")
def read(p):  return open(p, encoding="utf-8").read()
def write(p, s):  open(p, "w", encoding="utf-8").write(s)

def slide_basenames(d):
    return sorted([f for f in os.listdir(slides_dir(d)) if re.match(r"slide\d+\.xml$", f)],
                  key=lambda x: int(re.search(r"\d+", x).group()))

def rels_map(d):
    """basename(slideN.xml) -> rId from presentation.xml.rels"""
    p = os.path.join(d, "ppt", "_rels", "presentation.xml.rels")
    s = read(p)
    m = {}
    for rid, tgt in re.findall(r'Id="(rId\d+)"[^>]*Target="slides/(slide\d+\.xml)"', s):
        m[tgt] = rid
    return m

# ----------------------------------------------------------------------------- layout detection
def detect_layouts(d):
    counts = {}
    for b in slide_basenames(d):
        s = read(os.path.join(slides_dir(d), b))
        counts[b] = s
    def find(pred):
        for b in slide_basenames(d):
            if pred(counts[b]):
                return b
        return None
    layouts = {
        "title":     find(lambda s: "Presentation title" in s),
        "divider":   find(lambda s: "Section title" in s),
        "two_col":   find(lambda s: s.count("FINALISE REQUIREMENTS") == 2),
        "contrast":  find(lambda s: s.count("Name of step") == 2),
        "statement": find(lambda s: "This is a statement," in s),
    }
    layouts["closing"] = layouts["title"]
    missing = [k for k, v in layouts.items() if not v]
    if missing:
        raise SystemExit(f"Could not locate layouts in template: {missing}")
    return layouts

# ----------------------------------------------------------------------------- slide duplication
def next_index(d):
    return max(int(re.search(r"\d+", b).group()) for b in slide_basenames(d)) + 1

def next_rid(d):
    p = os.path.join(d, "ppt", "_rels", "presentation.xml.rels")
    s = read(p)
    n = max(int(x) for x in re.findall(r'Id="rId(\d+)"', s)) + 1
    return f"rId{n}"

def duplicate(d, src_basename):
    """Clone a slide; register Content_Types + presentation rel; strip notes rel. Returns (basename, rId)."""
    idx = next_index(d)
    new_b = f"slide{idx}.xml"
    sd = slides_dir(d)
    shutil.copy(os.path.join(sd, src_basename), os.path.join(sd, new_b))
    # copy slide rels, but drop notesSlide relationship so duplicates don't share notes
    src_rels = os.path.join(sd, "_rels", src_basename + ".rels")
    if os.path.exists(src_rels):
        rs = read(src_rels)
        rs = re.sub(r'<Relationship[^>]*Type="' + re.escape(REL_NOTES) + r'"[^>]*/>', "", rs)
        write(os.path.join(sd, "_rels", new_b + ".rels"), rs)
    # Content_Types override
    ctp = os.path.join(d, "[Content_Types].xml")
    ct = read(ctp)
    ov = f'<Override PartName="/ppt/slides/{new_b}" ContentType="{SLIDE_CT}"/>'
    if ov not in ct:
        ct = ct.replace("</Types>", ov + "</Types>")
        write(ctp, ct)
    # presentation rel
    rid = next_rid(d)
    rp = os.path.join(d, "ppt", "_rels", "presentation.xml.rels")
    rs = read(rp)
    rel = f'<Relationship Id="{rid}" Type="{REL_SLIDE}" Target="slides/{new_b}"/>'
    rs = rs.replace("</Relationships>", rel + "</Relationships>")
    write(rp, rs)
    return new_b, rid

# ----------------------------------------------------------------------------- ordering / cleaning
def set_order(d, rid_seq):
    p = os.path.join(d, "ppt", "presentation.xml")
    s = read(p)
    ids = "".join(f'<p:sldId id="{256+i}" r:id="{rid}"/>' for i, rid in enumerate(rid_seq))
    s = re.sub(r"<p:sldIdLst>.*?</p:sldIdLst>", f"<p:sldIdLst>{ids}</p:sldIdLst>", s, flags=re.S)
    write(p, s)

def keep_only(d, keep_basenames):
    keep = set(keep_basenames)
    sd = slides_dir(d)
    # remove slide files + their rels
    for b in slide_basenames(d):
        if b not in keep:
            os.remove(os.path.join(sd, b))
            r = os.path.join(sd, "_rels", b + ".rels")
            if os.path.exists(r):
                os.remove(r)
    # prune Content_Types overrides
    ctp = os.path.join(d, "[Content_Types].xml")
    ct = read(ctp)
    def keep_ov(m):
        b = m.group(1)
        return m.group(0) if b in keep else ""
    ct = re.sub(r'<Override PartName="/ppt/slides/(slide\d+\.xml)"[^>]*/>', keep_ov, ct)
    write(ctp, ct)
    # prune presentation rels for removed slides
    rp = os.path.join(d, "ppt", "_rels", "presentation.xml.rels")
    rs = read(rp)
    rs = re.sub(r'<Relationship[^>]*Target="slides/(slide\d+\.xml)"[^>]*/>',
                lambda m: m.group(0) if m.group(1) in keep else "", rs)
    write(rp, rs)

# ----------------------------------------------------------------------------- shape-level fill
def classify(sp):
    ph = re.search(r"<p:ph([^/]*)/>", sp)
    a = ph.group(1) if ph else ""
    typ = re.search(r'type="(\w+)"', a).group(1) if re.search(r'type="(\w+)"', a) else ""
    idx = re.search(r'idx="(\d+)"', a).group(1) if re.search(r'idx="(\d+)"', a) else ""
    off = re.search(r'<a:off x="(\d+)" y="(\d+)"', sp)
    x = int(off.group(1)) if off else -1
    y = int(off.group(2)) if off else -1
    return typ, idx, x, y

def set_texts(sp, texts):
    """Replace successive <a:t...>...</a:t> contents with the given list (in order)."""
    it = iter(texts)
    done = []
    def repl(m):
        try:
            t = next(it)
        except StopIteration:
            return m.group(0)
        return m.group(1) + esc(t) + "</a:t>"
    return re.sub(r"(<a:t[^>]*>).*?</a:t>", repl, sp, flags=re.S)

def set_body(sp, paras):
    return re.sub(r"<a:p>.*</a:p>", "".join(paras), sp, flags=re.S)

def set_ext(sp, cy):
    return re.sub(r'(<a:ext cx="\d+" cy=")\d+(")', r"\g<1>%d\g<2>" % cy, sp, count=1)

def transform(path, fn):
    s = read(path)
    out, last = [], 0
    for m in re.finditer(r"<p:sp>.*?</p:sp>", s, re.S):
        out.append(s[last:m.start()]); out.append(fn(m.group(0))); last = m.end()
    out.append(s[last:])
    write(path, "".join(out))

def col_paragraphs(items):
    """items: list of str (bulleted) OR {'b': bold, 's': sub} (name + role)."""
    paras = []
    for it in items:
        if isinstance(it, dict):
            paras.append(para([run(it["b"], sz=1100, bold=True)], spc_aft=0))
            if it.get("s"):
                paras.append(para([run(it["s"], sz=900)], spc_aft=500))
        else:
            paras.append(para([run(it, sz=1000)], bullet=True, spc_aft=500))
    return paras

# ----------------------------------------------------------------------------- per-type fillers
def fill_title(path, title, subtitle, kicker, presenter):
    def fn(sp):
        typ, idx, x, y = classify(sp)
        if typ == "ctrTitle":
            return set_texts(sp, [title, subtitle])
        if typ == "subTitle" and idx == "1":
            return set_texts(sp, [kicker, "  ", presenter])
        return sp
    transform(path, fn)

def fill_divider(path, num, label):
    def fn(sp):
        typ, idx, x, y = classify(sp)
        if typ == "ctrTitle":
            return set_texts(sp, [label])
        if typ == "subTitle" and idx == "1":
            return set_texts(sp, [f"CHAPTER {num}"])
        return sp
    transform(path, fn)

def fill_two_col(path, title, kicker, left_head, left, right_head, right):
    def fn(sp):
        typ, idx, x, y = classify(sp)
        if typ == "title":
            return set_texts(sp, [title])
        if typ == "subTitle" and idx == "1" and x == 344700:   # top kicker
            return set_texts(sp, [kicker])
        if typ == "subTitle" and idx == "1" and x != 344700:   # left column head
            return set_texts(sp, [left_head])
        if typ == "subTitle" and idx == "3":                   # right column head
            return set_texts(sp, [right_head])
        if typ == "body" and idx == "2":                       # left body
            return set_body(set_ext(sp, 2300000), col_paragraphs(left))
        if typ == "body" and idx == "4":                       # right body
            return set_body(set_ext(sp, 2300000), col_paragraphs(right))
        return sp
    transform(path, fn)

def fill_contrast(path, title, kicker, left_head, left, right_head, right):
    def fn(sp):
        typ, idx, x, y = classify(sp)
        if typ == "title":
            return set_texts(sp, [title])
        if typ == "subTitle" and idx == "2" and x == 344700:   # top kicker
            return set_texts(sp, [kicker])
        if typ == "subTitle" and idx == "2" and x != 344700:   # left card head
            return set_texts(sp, [left_head])
        if typ == "subTitle" and idx == "4":                   # right card head
            return set_texts(sp, [right_head])
        if typ == "body" and idx == "1":
            return set_body(sp, [para([run(t, sz=1000)], bullet=True, spc_aft=600, line=105000) for t in left])
        if typ == "body" and idx == "3":
            return set_body(sp, [para([run(t, sz=1000)], bullet=True, spc_aft=600, line=105000) for t in right])
        return sp
    transform(path, fn)

def fill_statement(path, parts):
    """parts: 3 strings, one per line. Mapped per PARAGRAPH (line), not per run,
    because the light and dark templates split the lines into a different number
    of runs. Within a line, the first run takes the text and any extra runs are
    blanked (keeps the template's per-line styling, incl. the orange middle line)."""
    def fn(sp):
        if "This is a statement" not in sp:
            return sp
        idx = [0]
        def fix_para(pm):
            block = pm.group(0)
            ats = list(re.finditer(r"(<a:t[^>]*>)(.*?)(</a:t>)", block, re.S))
            if not ats:
                return block
            newt = parts[idx[0]] if idx[0] < len(parts) else ""
            idx[0] += 1
            out = block
            for j in range(len(ats) - 1, -1, -1):
                a = ats[j]
                t = newt if j == 0 else ""
                out = out[:a.start()] + a.group(1) + esc(t) + a.group(3) + out[a.end():]
            return out
        out, last = "", 0
        for pm in re.finditer(r"<a:p>.*?</a:p>", sp, re.S):
            out += sp[last:pm.start()] + fix_para(pm)
            last = pm.end()
        out += sp[last:]
        return out
    transform(path, fn)

def set_footer(d, text):
    """Replace the master footer text 'PRESENTATION TITLE'."""
    for root, _, files in os.walk(os.path.join(d, "ppt", "slideMasters")):
        for f in files:
            if f.endswith(".xml"):
                p = os.path.join(root, f)
                s = read(p)
                if "PRESENTATION TITLE" in s:
                    write(p, s.replace("PRESENTATION TITLE", esc(text).upper()))

# ----------------------------------------------------------------------------- main
def build(theme, spec, out):
    tpl = os.path.join(SKILL_DIR, "assets", f"{theme}.pptx")
    if not os.path.exists(tpl):
        raise SystemExit(f"Template not found: {tpl}")
    work = tempfile.mkdtemp(prefix="mxdeck_")
    try:
        extract(tpl, work)
        layouts = detect_layouts(work)
        existing_rids = rels_map(work)

        # Plan: for each spec slide, pick a concrete slide file + rId.
        # First use of a layout reuses the original; further uses are duplicates.
        used_once = set()
        plan = []  # (basename, rid, slide_spec)

        title_spec = spec["title"]
        ordered = [("title", title_spec)]
        for sl in spec["slides"]:
            ordered.append((sl["type"], sl))
        ordered.append(("closing", spec.get("closing", {})))

        for typ, data in ordered:
            src = layouts[typ]
            if src not in used_once:
                base, rid = src, existing_rids[src]
                used_once.add(src)
            else:
                base, rid = duplicate(work, src)
            plan.append((base, rid, typ, data))

        set_order(work, [rid for _, rid, _, _ in plan])
        keep_only(work, [base for base, _, _, _ in plan])

        # Fill each slide
        for base, rid, typ, data in plan:
            path = os.path.join(slides_dir(work), base)
            if typ == "title":
                fill_title(path, data["title"], data.get("subtitle", ""),
                           data.get("kicker", ""), data.get("presenter", ""))
            elif typ == "closing":
                fill_title(path, data.get("title", "Thank you"), data.get("subtitle", ""),
                           data.get("kicker", ""), data.get("presenter", ""))
            elif typ == "divider":
                fill_divider(path, data["num"], data["label"])
            elif typ == "two_col":
                fill_two_col(path, data["title"], data.get("kicker", ""),
                             data.get("left_head", ""), data.get("left", []),
                             data.get("right_head", ""), data.get("right", []))
            elif typ == "contrast":
                fill_contrast(path, data["title"], data.get("kicker", ""),
                              data.get("left_head", ""), data.get("left", []),
                              data.get("right_head", ""), data.get("right", []))
            elif typ == "statement":
                fill_statement(path, data["parts"])

        if spec.get("footer"):
            set_footer(work, spec["footer"])

        repack(work, out)
        print(f"Wrote {out} ({len(plan)} slides, theme={theme})")
    finally:
        shutil.rmtree(work, ignore_errors=True)

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--theme", choices=["dark", "light"], default="dark")
    ap.add_argument("--spec", required=True)
    ap.add_argument("--out", required=True)
    a = ap.parse_args()
    with open(a.spec) as f:
        spec = json.load(f)
    build(a.theme, spec, a.out)
