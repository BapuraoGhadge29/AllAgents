# Layout Detection & Map

The two bundled templates share the same design system but number their slides
differently (dark = 45 slides, light = 46). So `build_deck.py` does **not** hardcode slide
numbers — it locates each layout by a **marker text** that is identical in both templates.

## Detection rules (theme-independent)

| Slide type | Marker rule |
|------------|-------------|
| `title` / `closing` | slide contains `Presentation title` |
| `divider` | slide contains `Section title` |
| `two_col` | slide contains `FINALISE REQUIREMENTS` exactly **twice** |
| `contrast` | slide contains `Name of step` exactly **twice** |
| `statement` | slide contains `This is a statement,` |

## Resolved slide numbers (reference only — the builder computes these at run time)

| Type | Dark | Light |
|------|------|-------|
| title / closing | slide1 | slide1 |
| divider (Section title) | slide4 | slide4 |
| two_col (FINALISE REQUIREMENTS ×2) | slide7 | slide32 |
| contrast (Name of step ×2) | slide11 | slide10 |
| statement | slide37 | slide38 |

## Why filling is shared across themes

The placeholder structure of each layout is byte-identical between the templates
(same `type` / `idx` / x-offset), so the fill code keys on placeholder identity rather
than slide number:

- **two_col / contrast** — title; top kicker (`subTitle idx=1` or `idx=2` at x=344700);
  left column head (same idx at x≠344700); right column head (`subTitle idx=3` or `idx=4`);
  left body (`body idx=1/2`); right body (`body idx=3/4`).
- **divider** — `ctrTitle` = label, `subTitle idx=1` = "CHAPTER N".
- **title / closing** — `ctrTitle` = title + subtitle lines, `subTitle idx=1` = kicker +
  presenter.
- **statement** — filled per paragraph (line), because the light template splits the
  middle line into several runs; the first run of each line takes the text, extras are
  blanked, preserving the orange middle line.

If a future template revision changes a marker string or placeholder layout, update the
rules above and the fillers in `build_deck.py`.
