# Maxxton Template Source IDs

The skill builds on local template files at `assets/dark.pptx` and `assets/light.pptx`.
Those binaries are **not** shipped in the registry submission (they are ~25 MB each). Use
the Google Drive sources below to provision them.

| Theme | Google Drive file ID | URL |
|-------|----------------------|-----|
| Light | `1BedG9gZ9ZScxKG1rIoRj7zJbseekda9qL6XmCI08Tr4` | https://docs.google.com/presentation/d/1BedG9gZ9ZScxKG1rIoRj7zJbseekda9qL6XmCI08Tr4 |
| Dark  | `18w37TDp4Uc4UlBldM81c0_iWhWEStGcf1DUQPqS71jw` | https://docs.google.com/presentation/d/18w37TDp4Uc4UlBldM81c0_iWhWEStGcf1DUQPqS71jw |

## How to provision the local templates

These are Google Slides files. Export them to PowerPoint **from the browser** (there is no
size limit there), then place them in `assets/`:

1. Open each URL above in Google Slides.
2. **File → Download → Microsoft PowerPoint (.pptx)**.
3. Save them as `assets/dark.pptx` and `assets/light.pptx` next to this skill.

> Do **not** rely on fetching these at runtime through the Drive connector: they are native
> Google Slides files and the connector's Slides→pptx export exceeds its 10 MB limit, so the
> fetch fails. The browser download avoids that limit. This is why the skill expects the
> templates to be present locally rather than pulling them on demand.

If the brand templates are updated, replace the files in `assets/` (and update the IDs above
if the Drive sources change). No code changes are needed — the builder detects layouts by
marker text, not by slide number.
