# Maxxton Slide Type Catalogue

The bundled templates (light and dark) contain the same set of layouts. Below is the full
catalogue, with the layouts the builder **currently supports** marked ✅ and the rest
marked ⬜ (available to wire up — the full templates are bundled, nothing was trimmed).

| Layout | In builder | Best used for |
|--------|:----------:|---------------|
| Title | ✅ `title` | First slide |
| Section / chapter divider ("Section title") | ✅ `divider` | Between major sections |
| Two-column content ("FINALISE REQUIREMENTS") | ✅ `two_col` | Scope + team, or any 2-column list |
| Two-card comparison ("Name of step", 2 cards) | ✅ `contrast` | Side-by-side comparison |
| Big statement | ✅ `statement` | Memorable closing point |
| Closing / Thank you (title layout) | ✅ `closing` | Final slide |
| Agenda (numbered list, 6 rows) | ⬜ | Talk roadmap |
| 1-column bullets + image | ⬜ | Standard content with one focus |
| 3-column / 3-card | ⬜ | Three parallel points |
| Quote | ⬜ | Testimonial / key quote |
| Meet the team (2 or 4 people, photos) | ⬜ | Team intro with portraits |
| Problem statement (+ image variants) | ⬜ | Challenge / context |
| Stats / metrics (3 big numbers) | ⬜ | KPIs |
| Timeline (Q1–Q4) | ⬜ | Roadmap, milestones |
| Feature grid (4 features) | ⬜ | Capability overview |
| Key highlights (6-item grid) | ⬜ | Summary / overview |
| Market projections (3 segments) | ⬜ | Market sizing |
| Financials table | ⬜ | Financial detail |
| Applications / icon grid | ⬜ | Logo or icon walls |

## Content guidelines

- Slides support the speaker — keep bodies concise (4–6 short bullets per column max).
- `two_col` list items can be plain strings (rendered as bullets) or `{ "b": ..., "s": ... }`
  for a bold line plus a muted sub-line (e.g. a person's name and role).
- `statement.parts` is exactly three lines; the middle line is the orange highlight.
- Keep decks ≤ ~20 slides; split longer content into two decks.

## Extending the builder

To support a ⬜ layout: (1) add a marker rule for it in `detect_layouts()` in
`scripts/build_deck.py`, (2) add a `fill_<type>()` that targets its placeholders by
`type`/`idx`/x-offset (inspect a fresh unpack of `assets/dark.pptx` to find them), and
(3) handle the new `type` in `build()`. Verify the placeholder structure matches in
`assets/light.pptx` so both themes stay supported.
