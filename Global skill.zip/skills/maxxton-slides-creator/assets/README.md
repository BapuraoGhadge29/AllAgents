# assets/

Place the two Maxxton template files here before first use:

- `assets/dark.pptx`
- `assets/light.pptx`

They are not shipped in the code-only registry submission because each is ~25 MB. Get them
from the Google Drive sources and download steps in `../references/template-ids.md`
(browser download → Microsoft PowerPoint).

The builder (`scripts/build_deck.py`) reads whichever theme you pass via `--theme`, so both
should be present for full functionality.
