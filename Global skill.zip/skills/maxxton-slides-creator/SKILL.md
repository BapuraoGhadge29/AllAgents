---
name: maxxton-slides-creator
description: "Generates a branded Maxxton slide deck as a .pptx from the official Maxxton templates, downloaded once into the skill's assets folder. Use when a slide deck or presentation is needed, e.g. \"create a presentation\", \"make a slide deck\", \"build a deck about X\".\n"
disable-model-invocation: true
argument-hint: "[topic or Confluence/Drive URL]"
allowed-tools:
- mcp__claude_ai_Atlassian_MCP__getConfluenceContent
- mcp__claude_ai_Atlassian_MCP__discover
- mcp__claude_ai_Atlassian_MCP__executeRead
---

# Creating a Maxxton Deck

Produces a finished, on-brand `.pptx` built directly on the Maxxton template. The two
template files (`dark.pptx`, `light.pptx`) live in the skill's `assets/` folder, so every
run uses the real branded layouts, logo, and footer.

> **Hard rule — settled by design, do not re-litigate at runtime:**
> The deliverable is **always a `.pptx` assembled from the bundled template**. Never copy
> the template to Google Drive, never try to export Slides→pptx (it exceeds the connector's
> 10 MB limit), and never design a deck from scratch. These were dead-ends in the original
> build; the bundled-template path exists specifically to avoid them.

> **Setup (one-time):** the two template files, `dark.pptx` and `light.pptx`, must be in the
> skill's `assets/` folder. If they're missing (this skill may be distributed code-only because
> the templates are large binaries), obtain the official Maxxton templates and drop them
> there before first use — see `assets/README.md`. Everything else works out of the box.

The assembly is handled by `scripts/build_deck.py`, which unpacks the bundled template,
finds the layouts it needs by **marker text** (identical across both templates even though
the slide numbers differ), duplicates/reorders/trims slides, injects content into the
placeholders (text inherits theme colours so it stays readable on light or dark), and packs
a valid `.pptx`. See `references/layout-map.md` and `references/slide-types.md`.

---

## Step 0 — Confirm the deliverable (before any work)

State plainly, and get a yes:

> I'll build this as a PowerPoint (.pptx) on the official Maxxton template. Sound right?

This single upfront confirmation prevents the format rework that happened originally. Do not
start intake until confirmed.

---

## Step 1 — Intake (one question at a time)

Ask these **one at a time**, waiting for each answer before the next — do not dump them all
in one message:

1. **Title** — what is the deck called?
2. **Audience** — who will see it?
3. **Goal** — inform / persuade / train / pitch?
4. **Length** — roughly how many slides, or how long is the talk?
5. **Theme** — light or dark?
6. **Presenter** — whose name goes on the title/closing slides?
7. **Footer** — what short text should sit in the slide footer? (often the deck title)
8. **Source material** *(optional)* — paste text, or give a Confluence/Drive URL.

Always ask for presenter and footer explicitly (steps 6–7); do not assume them.

---

## Step 2 — Gather source material

| Input | Action |
|-------|--------|
| Confluence URL | Page ID = numeric segment after `/pages/`. Call `mcp__claude_ai_Atlassian_MCP__getConfluenceContent` (`content_id`, `detail: full`). **If the page is a parent/landing page, call `mcp__claude_ai_Atlassian_MCP__executeRead` with `name: getConfluenceContentDescendants` (`contentId`; use `mcp__claude_ai_Atlassian_MCP__discover` if the name is rejected), list the child pages, and ask the user which ones to include** — then fetch the chosen ones. |
| Google Drive URL | File ID = segment between `/d/` and the next `/`. Call `read_file_content`. |
| Pasted text | Use as-is. |
| Nothing | Generate from the intake answers. |

If the source is long, summarise to the key points and tell the user what was left out.

---

## Step 3 — Propose the outline and get approval

Output a numbered slide-by-slide outline, each line mapped to a supported slide type from
`references/slide-types.md`. **Wait for the user to confirm or adjust before building.**
Keep decks ≤ ~20 slides; offer to split if longer.

---

## Step 4 — Write the content spec

Translate the approved outline into a JSON spec (see `example/platform_teams_spec.json`).
Top-level keys: `footer`, `title` `{title, subtitle, kicker, presenter}`, `closing` (same
shape), and `slides` (ordered). Supported slide `type`s:

| `type` | Fields | Use for |
|--------|--------|---------|
| `divider` | `num`, `label` | Section breaks |
| `contrast` | `title`, `kicker`, `left_head`, `left[]`, `right_head`, `right[]` | Two-card comparison |
| `two_col` | `title`, `kicker`, `left_head`, `left[]`, `right_head`, `right[]` | Scope + team / any two-column list. Items are strings (bullets) or `{ "b": bold, "s": subtext }` |
| `statement` | `parts` (3 strings) | Big statement; middle line is the orange highlight |

Fill `presenter`/`footer` from the intake answers (Step 1.6–1.7).

---

## Step 5 — Build, QA, deliver

Work in a temp area and keep the user's folder clean.

1. **Save the spec** next to where the deck will go (e.g. `<deck-name>.spec.json`) so the
   user can tweak and rebuild without redoing intake.
2. **Build:**
   ```bash
   python scripts/build_deck.py --theme <dark|light> --spec <spec>.json --out "<Deck>.pptx"
   ```
3. **Always QA** (this caught real bugs in the original build):
   - Content: `python -m markitdown "<Deck>.pptx"` and grep for leftover placeholders
     (`lorem`, `FINALISE REQUIREMENTS`, `Name of step`, `This is a header`,
     `Presentation title`, `Section title`, `Chapter Slide`).
   - Visual: render slides to images **into a `qa/` subfolder** and inspect with fresh eyes
     (a subagent is ideal) for overflow, collisions, low contrast, leftover placeholders.
     Fix and re-verify.
   - **All scratch/render artifacts go in `qa/`** — never scatter preview images in the
     user's main folder.
4. **Deliver** only the finished `.pptx` (and the saved `.spec.json`). Point the user at
   `qa/` if they want to see the render previews.

---

## Notes & limits

- **Both themes supported and tested.** Layouts are auto-detected per theme by marker text,
  so the skill does not depend on slide numbering (dark = 45 slides, light = 46).
- Body text **inherits** colour from the template (readable on either background); the
  Maxxton-orange accent is preserved on statement highlights.
- The bundled templates are the full catalogues (not trimmed), so other layouts (stats,
  timeline, quote, team-with-photos, feature grid, key highlights, agenda) remain available
  to wire up — see "Extending the builder" in `references/slide-types.md`.
- Standard library only. QA image rendering uses LibreOffice (`soffice`) + `pdftoppm` if
  available.
- This skill is **command-only** (`disable-model-invocation: true`); invoke it deliberately.
