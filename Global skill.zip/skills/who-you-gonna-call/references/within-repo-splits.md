# Within-repo splits

Some repos are owned by one team slug in `maxxton-github/values.yaml` but their features
are actually divided between teams. Repo granularity simply can't express this, which is
why it has to be written down. When the resolved repo appears below, use the split rather
than the repo owner.

Treat these as deliberately fluid. The Front Office Manager division in particular is
described by its own authors as a work in progress, so the goal is to route sensibly, not
to enforce a boundary.

## `frontoffice-manager-client` — FrontOps vs Reservations/CCM/NM

The repo belongs to `frontops`, but Front Office Manager leans heavily on reservation
services, so the screens were divided to reduce cross-team dependency. Source of truth is
the "Division of work with RM/CCM Team" table on the FrontOps Confluence page in space
POL — check it if you need the current version.

| FrontOps | Reservations/CCM/NM |
|---|---|
| Activity Planner | Dashboard |
| Planning Chart | Check-in / Check-out |
| Allotment functionality in Planning Chart | Reallocation |
| Cash Clearance / Accounts / Register | Gap & Implied Units |
| Workorders | Partner Portal |
| Facility Management | |
| Barriers | |
| Printing Cards | |
| CSE Portal | |
| Room Planner | |

FrontOps also owns the Operations Manager side outright, which the table above doesn't
list: housekeeping and cleaning, work schedules, inspections, periodical tasks,
maintenance, employee assignment and planning generation, and the Operations mobile app.

**When a Front Office area appears in neither column** — deposits, key cards, POS,
tickets and passes, meter readings are all currently unlisted — don't default to FrontOps
just because it owns the repo. Say the area isn't covered by the division and suggest
confirming with the two POs. Defaulting here has produced confident wrong answers.

## `content-manager-client` and `resource-service` — Content & Back Office vs Revenue & Channel

Both belong to `content`, but revenue-shaped features inside them belong to Revenue &
Channel:

- **Revenue & Channel**: representations and channel filters on an accommodation page,
  rentability rules on an accommodation type, anything about how a unit is offered to a
  distribution channel.
- **Content & Back Office**: the accommodation type itself, amenities, media, capacity,
  release and archive status, bulk content updates.

The distinction is roughly *what the thing is* versus *how and where it's sold*.

## `integration-manager-client` — Third Parties - Connections vs Third Parties - API

The repo belongs to `connections`, but the API-facing screens belong to the API team:

- **Third Parties - API**: API credentials and client secrets, API documentation,
  anything a partner integrating against the public API would see.
- **Third Parties - Connections**: supplier and reseller feeds, imports and exports,
  connection status and task dashboards, fiscal and payment provider integrations.

## Notification symptoms — a boundary worth care

Mail problems split by *what failed*, and the two directions look similar:

- **A mail that never went out** → Email Notifications owns delivery, usually with the
  triggering domain as helper.
- **A mail that went out too often, or at the wrong moment** → the triggering domain
  owns it (a duplicated booking confirmation is Reservations/CCM/NM), with Email
  Notifications as helper.

This is a genuine judgement call rather than a hard rule, so state your reasoning and
keep confidence at medium unless the description is explicit about which side failed.

## Adding to this file

When someone corrects a routing decision, that correction is usually a split like the
ones above — one repo, two teams, divided by feature. Offer to record it here. These
splits are the only routing knowledge that can't be derived from Git, so they're the
highest-value thing to capture and the easiest to lose.
