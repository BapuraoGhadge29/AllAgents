# Team map: slugs, corrections, and valid Jira values

## Corrections to apply to the live files

`metrics-service/values.yaml` is the source of truth for slug → Jira team, but a few
entries don't match the actual Jira option list, and a few slugs are missing a
`jiraTeam` entirely. Apply these on read. Some are being fixed in git, so treat the file
as correct where it already agrees and only override where listed here.

| slug | what the file says | use instead | why |
|---|---|---|---|
| `content` | `Content Manager` | **Content & Back Office** | Jira option was renamed |
| `mcms` | `Web - Development` | **Web Manager - Development** | Jira option is longer |
| `templates` | `Templates` | **Email Notifications** | no `Templates` option exists |
| `cms` | `Internet - CMS` | *(ignore)* | dead entry, no such team |
| `bi` | *(missing)* | **Reporting & BI** | owns `mxts-cognos-reports`, co-owns `dbt-config` |
| `qa` | *(missing)* | **Core QA** | co-owns the `katalon-*` / `*-qa-automation` repos |
| `developers` | *(missing)* | see below | owns `core` and ~20 shared libraries |
| `pci`, `students`, `koole`, `flexi-app` | *(missing)* | *(no MXTS team)* | own no MXTS-routable code |

**`developers`** spans both disciplines, so one team name can't be right. Use the repo's
own `discipline:` field in `maxxton-github/values.yaml`: `frontend` → **Frontend Core**,
`backend` → **Platform Core**. Confirm with the asker if it matters, since this mapping
is a working assumption rather than a documented decision.

## Never output these

- **`MXTS Finance - Sandaya`** — team retired. Historical tickets still carry it; the
  work now sits with **Finance / Owner / Compliance**.
- **`Channel Manager`** — folded into **Revenue & Channel** in the June 2026 reorg. Old
  tickets still use it.

Seeing either on a similar historical ticket is a signal that the ticket predates the
reorg, not that the team exists.

## Valid Jira values (`customfield_10049`, "Maxxton Team")

AI · Configuration Scripts · Consultants · Content & Back Office · Core QA ·
CS Technical Analysts - Reservations/FOM · CS Technical Analysts - Third Parties API ·
CS Technical Analysts - Third Parties Connections ·
CS Technical Analysts - Third Parties Payments · Customer Service · Database ·
Design Guild · DevSecOps · Email Notifications · Finance / Owner / Compliance ·
Frontend Core · FrontOps · Maxxton Academy · Oracle Migration · Platform Core ·
Price & Availability · Product Guild · Reporting & BI · Reservations/CCM/NM ·
Revenue & Channel · Third Parties - API · Third Parties - Connections ·
Third Parties - Payments · UX / Analytics · Web Manager - Development ·
Web Manager - Projects & Support

## Teams that are almost never the answer

Six teams do work with no customer-visible symptom — refactors, Terraform, pipelines,
flaky tests, design systems. Their entire recent backlogs contain nothing a person would
report as a problem:

**Frontend Core · Platform Core · DevSecOps · Oracle Migration · Core QA · Design Guild**

If your reasoning lands on one of these from a user-reported symptom, that's a strong
signal the resolution went wrong — most likely you hit a shared repo like `core` and
stopped there. Re-query filtered to the product repo you actually suspect.

The exception is when the description is explicitly infrastructural: a pipeline failure,
a cluster or namespace problem, a dependency upgrade, a database migration. Then these
teams are exactly right.

Customer Service, the CS Technical Analyst teams and Consultants are the *entry point*
to triage rather than destinations for engineering work. If the asker is a CS agent,
they've already decided this needs engineering — so don't route it back to them.

## Value streams, for context

The June 2026 reorg groups the product teams into value streams. Useful when you need to
reason about adjacency — teams in the same stream coordinate closely, so naming a helper
from the same stream is low-friction.

| Value stream | Teams |
|---|---|
| Revenue & marketing set-up | Revenue & Channel |
| Content & back office | Content & Back Office |
| On-park operations | FrontOps |
| Guest services | Reservations/CCM/NM |
| Finance & compliance | Finance / Owner / Compliance |
| Digital guest experience | Web Manager - Development |
| Email notifications | Email Notifications |
| Integrations & API | Third Parties - Connections, Third Parties - API |

Enabling teams (Core QA, AI) support every stream rather than owning a product area.
