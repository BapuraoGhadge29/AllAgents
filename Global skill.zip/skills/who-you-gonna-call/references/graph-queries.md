# Querying the Maxxton Knowledge graph for ownership

Read this when a search isn't landing. The graph is good, but it rewards a specific
querying style and has a few real blind spots.

## Worked examples

| Description says | Query that worked | Result |
|---|---|---|
| turnover not recalculated on cancellation | `turnover recalculate` | `revenue-service` |
| planning chart pop-up shows stale dates | `planning chart` | `frontoffice-manager-client` |
| lock reason doesn't update the chart line | `resource lock update` | `frontoffice-manager-client` |
| inspection list sorting is wrong | `inspection dashboard list sort` + `repository=operations-manager-client` | 8 precise hits |
| reservation search defaults to the wrong column | `search reservation sort column` | `reservation-manager-client` |
| Unified Inbox / Outlook mailbox rejected | `communication channel` | `inbox-service` |
| Spanish invoice flow needs revising | `SII Spain invoice` | `nf525-service` |
| ledger detail consolidation | `consolidate ledger mutation details` | `mutation-service` |
| nightly reindex is stuck | `reindex` + `repository=maxxton-indexer` | `maxxton-indexer` |

## Queries that returned nothing, and the fix

| Failed | Why | Fix |
|---|---|---|
| `rentability rule deviation blocks reservation creation` | full sentence | `rentability deviation gap` |
| `refreshAccessToken` | camelCase identifier | `refresh access token` |
| `gap deviation available units` | too many terms | `rentability deviation gap` |
| `template generator AI generate MJML` | too many terms | `MJML template` |
| `bundle` | ambiguous word | add a domain verb, or filter by repository |

The pattern: failure is nearly always *too long* or *too literal*, and the fix is to
shorten or de-camelCase. Adding words to a failing query almost never helps.

## Blind spots

The graph has essentially no coverage of these, so don't keep searching — reason from the
product domain and mark confidence lower:

- **Authorisation and permissions.** No rights or role nodes exist. A "read-only user can
  still edit X" symptom won't resolve; route by the screen where X lives.
- **Scheduler and cron wiring.** Which job triggers which mail is not modelled.
  `get_service_overview` on the service sometimes shows the outbound Feign edge, which is
  the next best evidence.
- **PDF and document layout.** Template rendering isn't in the graph. Use the document-type
  rule in SKILL.md instead.
- **Batch and cron repos rank poorly.** `maxxton-indexer` and `datascience-library` have no
  controllers and no HTTP paths, so they lose to frontend repos on shared vocabulary — a
  search for `marker` returns `cms-web` and `core` and never the indexer, even though the
  indexer is what handles markers. If the description sounds like a nightly job, import,
  sync or reindex, set `repository=` explicitly or go to `search_repo_docs`.

## Tools beyond search_technical_graph

- **`get_service_overview <repo>`** — cheapest way to understand a whole service: controller
  endpoints, outbound Feign calls, events. One call on `notification-service` reveals both
  its task endpoints and its edge to `email-service`, which can settle a routing question
  outright. Also confirms whether a repo is in the graph at all.
- **`search_repo_docs`** — READMEs and design docs. The right move for batch jobs,
  infrastructure and anything the graph doesn't model. A repo-ish phrase works well here,
  unlike in the graph.
- **`search_repo_info`** — repository-level summaries; good for "what does this repo even
  do".
- **`query_openapi`** — answers "does field X exist, and on whose model", which sometimes
  identifies the owning service faster than the graph.
- **`get_call_chain`** — follows the call path. Useful for finding the upstream cause once
  you have the surface, which is exactly what you need to name the helper team. Note it
  never crosses the client→backend boundary; match on HTTP method and path to make that
  hop manually.

## Feedback

When a search returns nothing that clearly should exist, `submit_feedback` reports the gap
to the team maintaining the graph. It's how coverage improves, so it's worth offering.

`submit_feedback` writes to an external channel, so never call it unprompted. Show the
asker what you would send — the query that came back empty and the one-line description
of what should have matched — and wait for them to say yes. If they don't answer, or the
conversation moves on, leave it unsent; a missed feedback report costs nothing, whereas
posting someone's half-formed problem statement to a shared channel on their behalf is
not yours to do.
