---
name: does-mxts-have-issues
description: "Check Slack channels guild-development and maxxtos-global for MXTS issue reports. Fetches the last 24h of messages from both channels in two requests, then analyses locally. Reports per-environment (dev/acc/prod) and flags issues that were active earlier but appear resolved now. Use when something seems broken and you want to know if others are reporting MXTS problems before debugging locally. Trigger phrases: \"does mxts have issues\", \"is mxts down\", \"mxts status\".\n"
user-invocable: true
disable-model-invocation: true
argument-hint: "[hours — default: 4]"
allowed-tools:
- mcp__claude_ai_Slack__slack_read_channel
- ToolSearch
---

# Does MXTS Have Issues?

## How to invoke

```
/global:does-mxts-have-issues [hours]
```

- `hours` — optional, human reports window. Default: `4`. Bot alerts always use 24h.

---

## Steps

### 0. Load tool schema (skip if already loaded)

**If `mcp__claude_ai_Slack__slack_read_channel` is already available as a callable tool in the current session, skip this step entirely and go straight to Step 1.**

Otherwise, run exactly **one** ToolSearch and wait for it before proceeding:

```
ToolSearch: select:mcp__claude_ai_Slack__slack_read_channel
```

### 1. Fetch messages — 2 requests total

**⛔ Channel IDs are hardcoded below. NEVER call slack_search_channels. Doing so wastes a full round trip.**
- `guild-development` → `C06LVM1HKLJ`
- `maxxtos-global` → `C02U60K59`

Make exactly **2 parallel Slack requests** using `slack_read_channel`:

1. `slack_read_channel` channel_id=`C06LVM1HKLJ` — fetch last **24 hours** of messages (limit: 2000)
2. `slack_read_channel` channel_id=`C02U60K59` — fetch last **24 hours** of messages (limit: 2000)

Do not run any searches. All analysis is done on these two result sets.

### 2. Analyse locally

From the fetched messages, split into two groups:

**Bot alerts** (guild-development only, full 24h window):
- Keep messages from `airflow bot` or `oracle bot`

**Human reports** (both channels, last `{hours}` hours window):
- Keep messages from non-bot users that contain any of: `mxts`, `503`, `down`, `broken`, `timeout`, `not working`, `unavailable`, `error`, `issue`
- Exclude bot messages

### 3. Classify each issue by environment

For every matched message, extract the affected environment:

| Keyword(s) | Environment |
|---|---|
| `dev`, `development`, `develop` | **dev** |
| `acc`, `acceptance`, `staging` | **acc** |
| `prod`, `production`, `live` | **prod** |
| none of the above | **unknown** |

A message may match multiple environments — list it under each.

### 4. Classify active vs resolved

For each environment with matches, look at its **most recent message timestamp**:

- **Active** — most recent message ≤ 30 min ago, no resolution signal
- **Resolved?** — most recent message > 30 min ago, OR contains: `fixed`, `resolved`, `back up`, `working again`, `all good`

### 5. Output

Print in this exact order — details first, summary last, so the verdict is the last thing visible in the terminal:

```
## MXTS Status Check

### 🤖 Bot Alerts (last 24h — airflow bot & oracle bot)
[List: timestamp · bot name · environment · message excerpt]
[If none: "No alerts from airflow bot or oracle bot in the last 24h."]

---

### 👥 Human Reports (last {N}h — guild-development + maxxtos-global)
[List: channel · timestamp · author · environment · message excerpt]
[If none: "No human-reported MXTS issues in the last {N}h."]

---

### Environment Summary

| Environment | Status | Last activity |
|---|---|---|
| prod | ⚠️ ACTIVE | 12 min ago |
| acc  | ✅ OK | — |
| dev  | 🔶 RESOLVED? | 2h ago (last: "seems fixed now") |

**Overall verdict:** ⚠️ ACTIVE ISSUES  /  🔶 RECENTLY RESOLVED  /  ✅ ALL CLEAR
```

**Verdict rules:**

| Verdict | Condition |
|---|---|
| `⚠️ ACTIVE ISSUES` | Any environment active (last mention ≤ 30 min, no resolution signal) |
| `🔶 RECENTLY RESOLVED` | Issues found in window, but all last mentions >30 min ago or resolved |
| `✅ ALL CLEAR` | No matching messages in either channel |

> **Tips:**
> - Bot alerts are strong infrastructure signals even without human reports.
> - `unknown` environment likely means all environments — treat as worst-case.
