#!/usr/bin/env bash
# Resolves the Jira team name for the current repo via CODEOWNERS + Cloud Monitoring.
# Prints the jiraTeam name to stdout on success; exits non-zero with a message on stderr on failure.
set -euo pipefail

if ! git rev-parse --is-inside-work-tree > /dev/null 2>&1; then
  echo "Not inside a git repository" >&2
  exit 1
fi

REPO_ROOT=$(git rev-parse --show-toplevel)
CODEOWNERS="$REPO_ROOT/.github/CODEOWNERS"

if [[ ! -f "$CODEOWNERS" ]]; then
  echo "No .github/CODEOWNERS found at $REPO_ROOT" >&2
  exit 1
fi

# Extract base team from wildcard line: * @MaxxtonGroup/<team>[-senior|-specialist]
RAW=$(grep -E '^\* @MaxxtonGroup/' "$CODEOWNERS" | head -1 \
      | grep -oE '@MaxxtonGroup/[^ ]+' | sed 's|@MaxxtonGroup/||' || true)

if [[ -z "$RAW" ]]; then
  echo "No MaxxtonGroup team found on wildcard line in CODEOWNERS" >&2
  exit 1
fi

TEAM=$(echo "$RAW" | sed 's/-senior$//; s/-specialist$//')
[[ "$TEAM" == "devops" ]] && TEAM="core"

if [[ ! "$TEAM" =~ ^[a-z0-9-]+$ ]]; then
  echo "Extracted team slug '${TEAM}' is not a valid slug (expected lowercase letters, digits, hyphens)" >&2
  exit 1
fi

python3 - "$TEAM" "google-mpf-718335495247" <<'PYEOF'
import sys

team, project_id = sys.argv[1], sys.argv[2]

try:
    import google.auth
    import google.auth.transport.requests
    import requests
except ImportError as e:
    print(f"Missing Python dependency: {e}", file=sys.stderr)
    sys.exit(1)

try:
    creds, _ = google.auth.default(scopes=["https://www.googleapis.com/auth/monitoring.read"])
    creds.refresh(google.auth.transport.requests.Request())
except Exception as e:
    print(f"GCP auth failed: {e}", file=sys.stderr)
    sys.exit(1)

query = f'sum by ("jiraTeam")({{"__name__"="team_mapping",team="{team}"}})'
url = f"https://monitoring.googleapis.com/v1/projects/{project_id}/location/global/prometheus/api/v1/query"

try:
    r = requests.get(
        url,
        headers={"Authorization": f"Bearer {creds.token}"},
        params={"query": query},
        timeout=10,
    )
    r.raise_for_status()
    results = r.json().get("data", {}).get("result", [])
    if not results:
        print(f"No team mapping found for '{team}'", file=sys.stderr)
        sys.exit(1)
    print(results[0]["metric"]["jiraTeam"])
except Exception as e:
    print(f"Cloud Monitoring query failed: {e}", file=sys.stderr)
    sys.exit(1)
PYEOF
