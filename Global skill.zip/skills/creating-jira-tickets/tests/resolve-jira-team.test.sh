#!/usr/bin/env bash
# Tests for scripts/resolve-jira-team.sh
# Usage: bash tests/resolve-jira-team.test.sh
set -uo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SCRIPT="$SCRIPT_DIR/../scripts/resolve-jira-team.sh"
_ORIG_DIR="$PWD"
_REPO=""
_STUB_DIR=""

PASS=0; FAIL=0

pass() { echo "  PASS  $1"; PASS=$((PASS+1)); }
fail() { echo "  FAIL  $1"; FAIL=$((FAIL+1)); }

_setup_repo() {
  _REPO=$(mktemp -d)
  cd "$_REPO"
  git init -q
  git config user.email "test@example.com"
  git config user.name "Test"
}

_write_codeowners() {
  mkdir -p .github
  printf '%s\n' "$1" > .github/CODEOWNERS
}

# Creates a python3 stub that consumes stdin (the heredoc), captures the
# team arg to <stub_dir>/captured_team, prints <output>, and exits <code>.
_stub_python3() {
  local exit_code="$1" output="$2"
  _STUB_DIR=$(mktemp -d)
  cat > "$_STUB_DIR/python3" <<STUB
#!/usr/bin/env bash
cat > /dev/null
echo "\$2" > "$_STUB_DIR/captured_team"
[ "$exit_code" -eq 0 ] && printf '%s\n' "$output"
exit $exit_code
STUB
  chmod +x "$_STUB_DIR/python3"
}

_cleanup() {
  cd "$_ORIG_DIR"
  [[ -n "$_REPO" ]] && rm -rf "$_REPO"; _REPO=""
  [[ -n "$_STUB_DIR" ]] && rm -rf "$_STUB_DIR"; _STUB_DIR=""
}

# ── 1: not a git repo ────────────────────────────────────────────────────────

test_not_in_git_repo() {
  local _tmpdir _stderr _exit=0
  _tmpdir=$(mktemp -d)
  _stderr=$(cd "$_tmpdir" && bash "$SCRIPT" 2>&1 >/dev/null) || _exit=$?
  rm -rf "$_tmpdir"
  if [[ "$_exit" -ne 0 ]] && printf '%s' "$_stderr" | grep -q "Not inside a git"; then
    pass "not a git repo → exit non-zero + message"
  else
    fail "not a git repo → expected exit non-zero with message; got exit $_exit: $_stderr"
  fi
}

# ── 2: no CODEOWNERS file ────────────────────────────────────────────────────

test_no_codeowners() {
  _setup_repo
  local _stderr _exit=0
  _stderr=$(bash "$SCRIPT" 2>&1 >/dev/null) || _exit=$?
  if [[ "$_exit" -ne 0 ]] && printf '%s' "$_stderr" | grep -q "CODEOWNERS"; then
    pass "no CODEOWNERS → exit non-zero + message"
  else
    fail "no CODEOWNERS → expected exit non-zero with message; got exit $_exit: $_stderr"
  fi
  _cleanup
}

# ── 3: CODEOWNERS without MaxxtonGroup wildcard line ────────────────────────

test_no_maxxton_wildcard() {
  _setup_repo
  _write_codeowners "# no ownership line"
  local _stderr _exit=0
  _stderr=$(bash "$SCRIPT" 2>&1 >/dev/null) || _exit=$?
  if [[ "$_exit" -ne 0 ]] && printf '%s' "$_stderr" | grep -q "No MaxxtonGroup team"; then
    pass "no wildcard line → exit non-zero + message"
  else
    fail "no wildcard line → expected exit non-zero with message; got exit $_exit: $_stderr"
  fi
  _cleanup
}

# ── 4: success — prints jiraTeam to stdout ───────────────────────────────────

test_success_prints_team() {
  _setup_repo
  _write_codeowners "* @MaxxtonGroup/price-senior"
  _stub_python3 0 "Pricing & Availability"
  local _stdout _exit=0
  _stdout=$(PATH="$_STUB_DIR:$PATH" bash "$SCRIPT" 2>/dev/null) || _exit=$?
  if [[ "$_exit" -eq 0 ]] && [[ "$_stdout" == "Pricing & Availability" ]]; then
    pass "success → exit 0, stdout = jiraTeam name"
  else
    fail "success → expected 'Pricing & Availability'; got exit $_exit, stdout='$_stdout'"
  fi
  _cleanup
}

# ── 5: devops → core substitution ───────────────────────────────────────────

test_devops_mapped_to_core() {
  _setup_repo
  _write_codeowners "* @MaxxtonGroup/devops-senior"
  _stub_python3 0 "DevOps / Core"
  PATH="$_STUB_DIR:$PATH" bash "$SCRIPT" > /dev/null 2>&1 || true
  local _captured
  _captured=$(cat "$_STUB_DIR/captured_team" 2>/dev/null || echo "")
  if [[ "$_captured" == "core" ]]; then
    pass "devops team → mapped to 'core' before API call"
  else
    fail "devops team → expected 'core', got '$_captured'"
  fi
  _cleanup
}

# ── 6: -senior suffix stripped ───────────────────────────────────────────────

test_senior_suffix_stripped() {
  _setup_repo
  _write_codeowners "* @MaxxtonGroup/price-senior"
  _stub_python3 0 "Pricing & Availability"
  PATH="$_STUB_DIR:$PATH" bash "$SCRIPT" > /dev/null 2>&1 || true
  local _captured
  _captured=$(cat "$_STUB_DIR/captured_team" 2>/dev/null || echo "")
  if [[ "$_captured" == "price" ]]; then
    pass "-senior suffix stripped → 'price' passed to API"
  else
    fail "-senior suffix stripped → expected 'price', got '$_captured'"
  fi
  _cleanup
}

# ── 7: -specialist suffix stripped ───────────────────────────────────────────

test_specialist_suffix_stripped() {
  _setup_repo
  _write_codeowners "* @MaxxtonGroup/foo-specialist"
  _stub_python3 0 "Foo Team"
  PATH="$_STUB_DIR:$PATH" bash "$SCRIPT" > /dev/null 2>&1 || true
  local _captured
  _captured=$(cat "$_STUB_DIR/captured_team" 2>/dev/null || echo "")
  if [[ "$_captured" == "foo" ]]; then
    pass "-specialist suffix stripped → 'foo' passed to API"
  else
    fail "-specialist suffix stripped → expected 'foo', got '$_captured'"
  fi
  _cleanup
}

# ── 8: invalid team slug rejected ───────────────────────────────────────────

test_invalid_slug_rejected() {
  _setup_repo
  _write_codeowners '* @MaxxtonGroup/foo"bar-senior'
  local _stderr _exit=0
  _stderr=$(bash "$SCRIPT" 2>&1 >/dev/null) || _exit=$?
  if [[ "$_exit" -ne 0 ]] && printf '%s' "$_stderr" | grep -q "not a valid slug"; then
    pass "invalid slug → exit non-zero + message"
  else
    fail "invalid slug → expected exit non-zero with message; got exit $_exit: $_stderr"
  fi
  _cleanup
}

# ── 9: python3 / API failure propagated ─────────────────────────────────────

test_api_failure_exits_nonzero() {
  _setup_repo
  _write_codeowners "* @MaxxtonGroup/price-senior"
  _stub_python3 1 ""
  local _exit=0
  PATH="$_STUB_DIR:$PATH" bash "$SCRIPT" > /dev/null 2>&1 || _exit=$?
  if [[ "$_exit" -ne 0 ]]; then
    pass "API failure → script exits non-zero"
  else
    fail "API failure → expected non-zero exit, got 0"
  fi
  _cleanup
}

# ── runner ───────────────────────────────────────────────────────────────────

echo "resolve-jira-team.sh"
echo ""
echo "guards"
test_not_in_git_repo
test_no_codeowners
test_no_maxxton_wildcard
echo ""
echo "team name extraction"
test_senior_suffix_stripped
test_specialist_suffix_stripped
test_devops_mapped_to_core
echo ""
echo "API integration"
test_success_prints_team
test_api_failure_exits_nonzero
test_invalid_slug_rejected
echo ""
echo "Results: $PASS passed, $FAIL failed"
[ "$FAIL" -eq 0 ]
