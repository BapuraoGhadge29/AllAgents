# Media HTML Blocks

Blocks for Step 6.5. Insert one block per file at the end of its target section, with a `<p>` describing the file directly before it. Copy `{fileId}` (`data.id` from the upload command's output) and `{collection}` (from the `uploadAttachmentToJiraIssue` response); never invent them.

## Images and videos

```html
<figure data-type="media-single" data-layout="center" data-width="60" data-width-type="percentage">
  <div data-type="media" data-media-type="file" data-id="{fileId}" data-collection="{collection}" data-alt="{file name}"></div>
</figure>
```

- `data-width="60"` for screenshots, `"80"` for recordings and diagrams.
- Always pair `data-width` with `data-width-type="percentage"`. Without it Jira reads the number as pixels and the image renders tiny.
- Do not add `<figcaption>`: Jira's issue view does not show it.

## Any other file type (PDF, spreadsheet, log, HAR)

A clickable file card. Put several files of the same section in one group by repeating the inner `<div>`:

```html
<div data-type="media-group">
  <div data-type="media" data-media-type="file" data-id="{fileId}" data-collection="{collection}" data-alt="{file name}"></div>
</div>
```

## Panels

Info or warning panel, e.g. the test-ticket notice:

```html
<div data-type="panel-warning"><p>Test ticket — safe to delete.</p></div>
```

Use `panel-info` for an important note.
