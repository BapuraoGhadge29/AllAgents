---
name: creating-jira-tickets
description: "Creates and refines Jira tickets using Maxxton DoR templates. Use when a user says \"create a ticket\" or \"spar with me on a ticket\". Quick mode for fast creation; spar mode shapes the ticket first. Auto-checks duplicate bugs, enriches Stories and Features with Knowledge Base context, and confirms before creating.\n"
allowed-tools:
- Bash
- Read
- mcp__claude_ai_Atlassian_MCP__getAccessibleAtlassianResources
- mcp__claude_ai_Atlassian_MCP__createJiraIssue
- mcp__claude_ai_Atlassian_MCP__editJiraIssue
- mcp__claude_ai_Atlassian_MCP__getJiraIssue
- mcp__claude_ai_Atlassian_MCP__searchJiraIssuesUsingJql
- mcp__claude_ai_Atlassian_MCP__getConfluenceContent
- mcp__claude_ai_Atlassian_MCP__addOrEditJiraIssueComment
- mcp__claude_ai_Atlassian_MCP__discover
- mcp__claude_ai_Atlassian_MCP__executeRead
- mcp__claude_ai_Atlassian_MCP__executeWrite
- mcp__claude_ai_Maxxton_Knowledge__search_help_centre
---

# Jira Ticket Creator

A sparring partner and ticket creator for Product Owners and Product Managers. This skill ensures every Jira ticket
is structured, context-rich, and immediately actionable — whether created in 30 seconds or after a 10-minute
collaborative thinking session.

Use **British English** throughout all ticket content (e.g. "behaviour" not "behavior", "colour" not "color").
 
---

## Runtime Setup

**Resolve cloudId once, before the first Atlassian call** (the duplicate check in Step 1 already needs it):
```
Tool: mcp__claude_ai_Atlassian_MCP__getAccessibleAtlassianResources
```
Use the returned cloudId for all subsequent Jira/Confluence calls. Never hardcode it.
 
---

## Team Autodiscovery

Before asking the user for their team, try to detect it from the current repository:

```bash
bash "${CLAUDE_SKILL_DIR}/scripts/resolve-jira-team.sh" 2>/dev/null
```

- **Success** (exit 0, non-empty stdout): use the printed team name to pre-select the Maxxton Team field. Do not announce the detection — silently use it and continue.
- **Failure** (non-zero exit or empty output): fall back to the team the user named, then to inferring it from context, then to asking.
- **A name that matches more than one team** (e.g. "Reservations" matches Reservations/CCM/NM and CSTA - Reservations/FOM): pick the development team unless the user says CSTA, FOM or technical analysts.
---

## Teams And Preferences

**Shared defaults (same for all Maxxton teams):**
- Field: `customfield_10049` (Maxxton Team) — an option field; pass `{"id": "{team id}"}`
- Workspace: `maxxton.atlassian.net`
- Default project: `MXTS`
- Security Level: "All employees" (id: `10058`) — always applied
- Default Priority: P3
- General DoR source page ID: `1423802371`
- Design DoR source page ID: `2802286595`
### All Teams

Names match the Jira option values exactly (checked October 2026). If a create rejects a team, re-read the options (Step 4).

| ID | Team name |
|----|-----------|
| 10127 | AI |
| 10267 | Channel Manager |
| 10313 | Configuration Scripts |
| 10102 | Content & Back Office |
| 10117 | Core QA |
| 12846 | Customer Service |
| 12847 | CSTA - Third Parties API |
| 12848 | CSTA - Third Parties Connections |
| 12883 | CSTA - Third Parties Payments |
| 12849 | CSTA - Reservations/FOM |
| 12850 | Consultants |
| 10106 | Database |
| 10268 | Design Guild |
| 10107 | DevSecOps |
| 10265 | Email Notifications |
| 10108 | Finance / Owner / Compliance |
| 11512 | Frontend Core |
| 10116 | FrontOps |
| 10412 | Maxxton Academy |
| 10280 | MXTS Finance - Sandaya |
| 13147 | Oracle Migration |
| 13148 | Platform Core |
| 10379 | Revenue & Availability |
| 12813 | Product Guild |
| 10119 | Reporting & BI |
| 10115 | Reservations/CCM/NM |
| 10269 | Revenue & Channel |
| 10122 | Third Parties - API |
| 10123 | Third Parties - Connections |
| 10124 | Third Parties - Payments |
| 10266 | UX / Analytics |
| 10113 | Web Manager - Projects & Support |
| 10112 | Web Manager - Development |

---

## Step 0: Detect Mode and Ticket Type

### Mode Detection

**Quick Mode**
**Triggers:** Short, directive language — "Make a ticket for X", "Log this as a bug", "Create a task for Y"
**Behaviour:** Minimal questions, auto-fill everything, create fast. No label suggestions. No sprint questions. Missing DoR details are not asked for: write "Not yet provided" in that section and list the missing items in the draft (Step 6.1) so the user can add them before confirming.

**Sparring Mode**
**Triggers:** Exploratory phrasing — "I have an idea for...", "Can you help me shape this?", "Let's think through a ticket"
**Behaviour:** Think partner, challenge weak context, ask for missing DoR details, suggest labels, confirm epic and linked tickets.

**Override:** "Just create it quickly" → quick | "Spar with me" → sparring

**Test tickets:** when the user says the ticket is a test, start the summary with `[Test]`, put a warning panel holding `<p>Test ticket — safe to delete.</p>` above the first DoR section (panel markup: see the HTML table in Step 3), and send no labels (no `Refinement`, `QA`, `FrontEnd` or `Backend`) so it stays out of refinement queues and team filters. The global plugin's hook still adds `claude-ai` to every created ticket; that is expected.

### Ticket Type Inference

Infer the ticket type from the user's description. Ask once only if genuinely ambiguous. Pass the **Jira issue type** column as `issueType` at create — MXTS has no type called "Feature", so a create with that name is rejected.

| Type | Jira issue type | Inference signals |
|------|-----------------|-------------------|
| **Bug** | `Bug` | "broken", "error", "not working", "exception", "failing", "crash", trace IDs, stack traces, GCP log output |
| **Story** | `Story` | "as a user", "user story", "from the user's perspective", product feature written in first person |
| **Feature** | `New Feature` | "new feature", "build", "add support for", "we don't currently have" |
| **Improvement** | `Improvement` | "slow", "refactor", "performance", "technical debt", "enhance existing" |
 
---

## Step 1: Bug Duplicate Check (Bugs only — skip for all other types)

Before creating a Bug ticket, search for existing tickets to avoid duplicates.

**Search terms**, in this order of preference: (1) exception class name, (2) 3–5 distinctive words from the error message, (3) for UI bugs without an exception or message: the screen or area plus the action and symptom (e.g. `\"arrival date\" save reservation` — escape inner quotes inside the JQL string), (4) affected service name. Avoid generic terms like "error" or "failed".

Run both searches with `maxResults: 10` and `fields: ["summary", "status", "created"]`; full issues overflow the tool output.

**Primary search:**
```jql
project = "MXTS" AND issuetype = Bug AND summary ~ "{terms}" ORDER BY created DESC
```
**Broaden when there are no results or none of them is relevant:**
```jql
project = "MXTS" AND issuetype = Bug AND text ~ "{terms}" ORDER BY created DESC
```
Do not run more than two duplicate-check searches.

**Match evaluation** — Summary and Description decide duplicate or related; Status and Recency only rank the hits you show:

| Signal | Strong match | Weak match |
|--------|-------------|------------|
| Summary | Same exception + same service, or same screen + same action + same symptom | Same exception or screen, different service or action |
| Status | Open or In Progress | Closed/Done more than 30 days ago |
| Description | Same stack trace, endpoint or reproduction steps | Similar but different context |
| Recency | Within 90 days | Older than 6 months |

Treat as **duplicate** if: same exception class AND same service, or same screen AND same action AND same symptom — regardless of status.
Treat as **related** (not duplicate) if: same exception class or screen, but a different service, endpoint or action.

**Present findings and wait for user decision:**
```
## Possible duplicate tickets found
 
- **[MXTS-123]** NullPointerException in booking-service — *Open* (3 days ago)
  https://maxxton.atlassian.net/browse/MXTS-123
 
Do you want to:
1. Create a new ticket anyway
2. Add a comment to the existing ticket with the new details (trace ID, steps, media)
3. Skip ticket creation
```

If the user picks option 2, add the comment via `mcp__claude_ai_Atlassian_MCP__addOrEditJiraIssueComment` with `contentFormat: html`.

List **related** hits in the draft (at most 3) and offer to link them as "relates to" in Step 6.7.

If no duplicates found, state briefly and continue:
> No existing bug tickets found for this error. Proceeding to create a new ticket.
 
---

## Step 2: Story and Feature Enrichment (Stories and Features only — skip for Bug and Improvement)

**2a. Check existing story format** — Fetch 3–5 recent issues from the project:
```jql
project = MXTS AND status NOT IN (Done, Cancelled) ORDER BY created DESC
```
Observe summary prefix style, persona language, and AC depth. Match these conventions in the new ticket.

**2b. Query the Maxxton Knowledge Base** — Use `mcp__claude_ai_Maxxton_Knowledge__search_help_centre` to find domain context:
- Business rules that constrain the feature
- Integration requirements
- Performance or compliance constraints
  Include any discovered constraints in the Acceptance Criteria or Description.

---

## Step 3: 17-Field Walkthrough

**First, fetch the DoR template** — the description follows its sections, so fetch it before drafting. Use `mcp__claude_ai_Atlassian_MCP__getConfluenceContent` with `content_id`, `detail: full` and `content_format: markdown` (macros and images drop out; only the section names, their order and the per-section guidance are needed):
- General DoR (page ID `1423802371`) for standard tickets
- Design DoR (page ID `2802286595`) for design-related tickets (trigger when user mentions "design" or "UX")
- Always fetch fresh — never use a cached version

| Field | Default                                                                             | Ask? |
|---|-------------------------------------------------------------------------------------|---|
| Project | `MXTS` for Maxxton Software  + `MCMS` for Web Manager                               | Never |
| Issue Type | Story (infer from language)                                                         | If unclear |
| Summary | [action-oriented title]                                                             | Sparring: propose & confirm |
| Description | DoR template per type, written as HTML (`contentFormat: html`) at create (see below) | Quick: never; Sparring: ask for missing DoR details |
| Media | Local files shown in the description: screenshots, screen recordings, PDFs and other documents (see below) | User gave files: never. Bug without files: ask once, inside the Step 6.1 draft (not as a separate question). Other types: never |
| Acceptance Criteria | customfield_10057, Gherkin format                                                   | Never |
| Epic | Auto-search JQL (see below), set via `parent`                                       | Quick: auto-link on strong match; Sparring: confirm |
| Maxxton Team | Autodiscover via script; else the team the user named; else infer; see the tie-break rule | Ask if not confident |
| Labels | `Refinement` always + `FrontEnd`/`Backend` reasoned from content + `QA` for testing work; none sent for test tickets (the hook's `claude-ai` is added to every ticket) | Sparring: suggest extras |
| Evidence | Optional section, only when the request carries evidence (see below) | Never |
| Priority | P3                                                                                  | Never — never infer from context |
| Sprint | Unassigned                                                                          | Quick: skip; Sparring: ask |
| Assignee | Unassigned                                                                          | Never |
| Linked Issues | Auto-detect keys (MXTS: auto-link; non-MXTS: ask first)                             | Per type |
| Components | Empty                                                                               | Never |
| Fix Version | Skip                                                                                | Never |
| Reporter | Auto (Jira)                                                                         | Never |
| Security Level | All employees (10058)                                                               | Never |

**Label rules:**
- `Refinement` — every ticket except test tickets
- `QA` — add for tickets whose work is testing (test plans, test automation); not for test tickets
- `Tech-debt` — always add for tech debt issue types
- `FrontEnd` / `Backend` — reason from content; add both when in doubt
- Never create new labels; only use existing ones

**Summary format by type** (a `[Test]` prefix goes before everything else):
- **Bug**: `[ServiceName or Area] What fails` — name the exception when there is one
  - e.g. `[booking-service] NullPointerException on POST /api/reservations`
  - e.g. `[Reservation overview] Arrival date change is not saved`
- **Story/Feature/Improvement**: `[Area] Short imperative description`
  - e.g. `[FM] Add a currency filter to the invoice overview`

**Epic search** — for every ticket type, via `mcp__claude_ai_Atlassian_MCP__searchJiraIssuesUsingJql`. Use 1–3 distinctive words for the area or feature as `{keywords}` (e.g. `reservation overview`):
```
project = {project_key} AND issuetype = Epic AND statusCategory != Done
AND "Maxxton Team" = "{team_name}" AND summary ~ "{keywords}"
```
No results: search once more without the `"Maxxton Team"` filter. A **strong match** is an open epic whose summary names the same area or feature as the ticket. No match, or only weak ones: leave the epic empty and say so in the draft. The JQL already limits results to Epics; validate the type with `mcp__claude_ai_Atlassian_MCP__getJiraIssue` only for an epic key the user typed.

**Acceptance Criteria minimum requirements:**
- Minimum 3 ACs: (1) happy path, (2) edge case / boundary condition, (3) error handling / graceful failure
- Each AC must test one specific behaviour — split complex ACs into separate criteria
- Use Gherkin syntax (Given / When / Then) for all ACs
- For Bugs: include an AC confirming no regression occurs after the fix
  **AC field placement:** `customfield_10057` is the dedicated Acceptance Criteria field and must always be used when it exists on the screen. **This field only accepts ADF (Atlassian Document Format) — never pass plain text, Markdown or Gherkin strings directly.** Create the ticket first (without `customfield_10057`), then immediately call `mcp__claude_ai_Atlassian_MCP__editJiraIssue` to set it as an ADF document object under `fields`. The only exception is Bug tickets — `customfield_10057` is not on the Bug screen, so Acceptance Criteria go into the HTML description instead.

**Writing the description as HTML:** the description is always HTML — at create and in every later edit. Markdown cannot hold inline media, so a single Markdown edit silently deletes every embedded screenshot and video. Pass the full DoR description to `createJiraIssue` and `editJiraIssue` with `contentFormat: html`. Use the section names and order of the fetched DoR template. Include optional DoR sections (e.g. Data Correction Requirements, Impact and Risk Analysis) only when there is content for them. Map each element to HTML:

| DoR template element | HTML |
|---|---|
| Section title | `<h3>` |
| Section divider | `<hr>` |
| Body paragraph | `<p>` |
| Emphasis | `<strong>` / `<em>` |
| Endpoint, class/method name, error code | `<code>` |
| Stack trace / log block | `<pre><code>…</code></pre>` |
| Steps to Reproduce, Dependencies | `<ol>` / `<ul>` with `<li>` |
| Important note or known risk | a `<div>` whose `data-type` attribute is `panel-info` (or `panel-warning`), with a `<p>` inside |

Write an HTML body fragment only — no `<html>`, `<body>` or Markdown fences. This table covers what DoR tickets need; only for an element not in it, get the format guide via `mcp__claude_ai_Atlassian_MCP__executeRead` with `name: getContentFormatGuide`, `inputs: {toolName: "editJiraIssue"}`.

Put an `<hr>` between DoR sections. When a section is only partly known, add "Not yet provided" inline for the missing part (e.g. "Error toast text: Not yet provided.").

**Evidence (optional):** when the request says where and how often the need came up (a meeting, a Slack thread, a client, an interview), add an `<h3>Evidence</h3>` section directly after Business Context, with a `<ul>` holding one `<li>` per occurrence: `date · source · who or where · link · quote`. The quote is the speaker's own words, at most 25 words; a translated quote ends with "(translated)". No personal identifiers (guest names, email addresses, reservation numbers); client account names are fine. Never invent an occurrence, and leave the section out when the request gives no evidence. Later occurrences of the same need are appended to this section, not filed as a new ticket.

For Bug tickets (no `customfield_10057` on screen), write Acceptance Criteria as their own `<h3>` section at the position the DoR Bug template gives it, with a `<ul>` holding one `<li>` per Given/When/Then scenario.

**Media (screenshots, recordings and documents):**
- **Placement:** record each file's path and the DoR section it belongs in, using the template's own section names. Bugs: screenshot → *Actual Behaviour*; recording → *Steps to Reproduce*; logs, HAR files and documents → *Technical Details and Analysis*. Other types: the section that discusses the file; if none fits, the last section before Acceptance Criteria.
- **Look before describing:** open each image and document with `Read` and describe only what is visible. Describe videos from the user's words; when they give none, use a neutral line such as "Screen recording of the reproduction, supplied by the reporter." Never invent content. If a file does not show what the user describes (e.g. no error in the screenshot), say so in the draft and ask whether it is the right file.
- **Personal data:** if a file holds, or by its name or the user's words is likely to hold, personal or customer data (booking exports, guest lists, payment data, screenshots with guest names), flag it in the draft and ask the user to confirm it may go into Jira or to supply a redacted version. The DoR forbids sensitive information in Jira tickets. Without an explicit yes for that file, leave it out — a general "yes, create it" does not cover it.
- **Display:** images and videos are shown in full; any other file type (PDF, spreadsheet, log, HAR) becomes a clickable file card. Media cannot be embedded at create — files upload to an existing issue — so Step 6.5 uploads and places them after the ticket exists.
- **Video links** (Loom, YouTube, Google Drive) need no upload: put `<a href="{url}" data-card-appearance="embed"></a>` in the description at create so the video plays inline.

---

## Step 4: Field IDs

Use the known IDs below. Read the field metadata only when a create is rejected or a field is in doubt: `mcp__claude_ai_Atlassian_MCP__executeRead` with `name: getJiraIssueTypeMetaWithFields` and `inputs: {projectIdOrKey: "MXTS", issueTypeId: "{id}", requiredFieldsOnly: false}`. Take the issue type ID from the list below; only for a type not listed, get it with `mcp__claude_ai_Atlassian_MCP__executeRead` and `name: listJiraProjectIssueTypesMetadata`. Without `requiredFieldsOnly: false` only the required fields come back. If an operation name is rejected, find the current one with `mcp__claude_ai_Atlassian_MCP__discover`.

**Known Maxxton field IDs (MXTS, checked October 2026):**
- **Issue types** (name = ID): Bug = `10004`, Story = `10001`, New Feature = `10034`, Improvement = `10047`, Task = `10002`, Tech Debt = `10189`, Sub-task = `10003`, Epic = `10000`
- **Epic**: `parent` (Epic Link `customfield_10014` is the fallback)
- **Maxxton Team**: `customfield_10049` — option value `{"id": "{team id}"}`
- **Acceptance Criteria**: `customfield_10057` (not on the Bug screen)
- **Security Level**: `10058` (All employees)
---

## Subtask Duplicate Prevention

- Create subtasks **sequentially**, never in parallel
- If a creation call returns no key: search before retrying via `mcp__claude_ai_Atlassian_MCP__searchJiraIssuesUsingJql` (`project = MXTS AND summary ~ "{title}" AND issuetype = Sub-task ORDER BY created DESC`)
- Confirm each returned key before continuing
- On mid-sequence errors: check parent's subtask list before resuming
---

## Step 5: Quality Checklist

Before presenting the draft to the user, verify:

- [ ] Confluence DoR page fetched fresh in Step 3 — not using a cached or hardcoded version
- [ ] Every required DoR section is filled, or marked "Not yet provided" and listed in the draft
- [ ] Description is written as HTML (`<h3>`, `<hr>`, `<code>`, `<pre>`, lists) following the DoR section names and order, ready to pass with `contentFormat: html` in Step 6
- [ ] Every media file path exists on disk, has a target section, and was checked for personal data
- [ ] Acceptance Criteria uses Gherkin format with at least 3 scenarios
- [ ] British English is used throughout
- [ ] Summary follows the correct format for the ticket type
- [ ] For Bugs: duplicate check was performed
- [ ] For Stories/Features: Maxxton Knowledge Base was queried for domain context
- [ ] Maxxton Team confirmed (via script, user, context, or the tie-break rule)
- [ ] Epic search was run, and a user-typed epic key was validated as an Epic
- [ ] Security level `10058` is in `additional_fields`
- [ ] `Refinement` label is included (test tickets: no labels sent)
- [ ] Evidence section only when the request gave evidence, directly after Business Context, every line in the `date · source · who or where · link · quote` format
---

## Step 6: Build and Create

1. **Present the complete draft to the user for confirmation:**
    - Issue type, project, summary, description preview — show the description as readable text, not raw HTML tags
    - Bugs: the duplicate-check result, including hits judged not to be duplicates
    - Epic to be linked, or the candidates found and why none was linked; any planned issue links
    - Media files: the section each one goes in, the `<p>` text that will describe it, any file that does not match the user's description, and any personal-data warning with its own yes/no question. Bugs without files: "Do you have a screenshot or recording to add? Give the file path and I'll embed it."
    - DoR details marked "Not yet provided"
    - Evidence lines, when the request gave any
    - Labels, priority, sprint (if applicable)
    - Team (say "inferred" when it came from context or the tie-break rule), security level
    - Ask: "Does this look right? Shall I create this ticket?"
2. After explicit user confirmation, create via `mcp__claude_ai_Atlassian_MCP__createJiraIssue`, passing the full DoR description as HTML:
   ```
   cloudId: <from Runtime Setup>
   projectKey: "MXTS"
   issueType: "{Bug | Story | New Feature | Improvement | ...}"   # the Jira issue type from Step 0, never "Feature"
   summary: "{summary}"
   description: <full DoR description as HTML>
   contentFormat: html
   labels: ["Refinement", ...]          # leave out for test tickets; the global hook adds claude-ai either way
   priority: "P3"
   parent: "{epic key}"                 # only when an epic is linked
   assignToSprint: "{sprint id}"        # only when a sprint is chosen
   additional_fields:
     security: {"id": "10058"}
     customfield_10049: {"id": "{team id}"}
   ```
   Do **not** include `customfield_10057` here — it requires ADF and is set in Step 6.4. If `parent` is rejected for the epic, retry with `additional_fields: {customfield_10014: "{epic key}"}`.
3. If creation fails due to a missing or invalid field, read the field metadata as described in Step 4 and retry once with the corrected field.
4. **Non-Bug tickets only — immediately after successful creation**, call `mcp__claude_ai_Atlassian_MCP__editJiraIssue` once to set only the Acceptance Criteria. Bugs skip this step: `customfield_10057` is not on the Bug screen, so their AC is already in the HTML description.

   Payload shape — `customfield_10057` is an ADF document object under `fields`, never a serialised string, and no `contentFormat` is sent:
   ```
   cloudId: <same as above>
   issueIdOrKey: "{ticket key from creation}"
   fields:
     customfield_10057: <ADF document object for the Acceptance Criteria — a JSON object, NOT a string>
   ```
    - **If this call fails** (bad ADF, permissions, transient error), retry it once. If it still fails, the ticket exists without its Acceptance Criteria — do not report it as fully created. Tell the user the ticket key was created but the AC could not be set, show the error, and offer to retry `editJiraIssue` once they have reviewed it.
5. **Media only — embed the files inline.** Skip this step when the draft has no local media files.
    1. Upload the files one at a time, and run each `uploadCommand` right away — its token expires after about 20 minutes. Ignore the `nextSteps` in the upload response; this step replaces them. For each file, call `mcp__claude_ai_Atlassian_MCP__executeWrite` with `name: uploadAttachmentToJiraIssue` and `inputs: {issueIdOrKey: "{key}", filePath: "{absolute path}"}`. Keep the `collection` from that response, run the returned `uploadCommand` with Bash, and keep `data.id` from its JSON output as the `fileId`. Do not echo the command's bearer token. Do **not** call `uploadAttachmentToJiraIssue` a second time with the `fileId` — embedding the file already adds it to the Attachments list, so a second call shows it twice. (Only the Markdown fallback in Troubleshooting makes that second call, because it embeds nothing.)
    2. Take the HTML description sent in Step 6.2 and insert one block per file at the end of its target section, then send the whole description once via `mcp__claude_ai_Atlassian_MCP__editJiraIssue` with `fields: {description: "<html>"}` and `contentFormat: html`. Do not use `inlineFileId` — it appends every file at the end of the description instead of in its section. Read `${CLAUDE_SKILL_DIR}/references/media-html.md` now for the two blocks: a `<figure>` for images and videos (60% wide for screenshots, 80% for recordings and diagrams) and a file card for any other file type (PDF, spreadsheet, log, HAR). Jira's issue view does not show `<figcaption>`, so describe what the file shows in a `<p>` directly before the block. Never invent `data-id` or `data-collection`; copy them from the upload output.
    - **If an upload fails** (file too large, file not found), embed the files that did upload, then tell the user which file failed and why. The ticket itself is fine — do not recreate it.
    3. **Verify the writes** with one `mcp__claude_ai_Atlassian_MCP__getJiraIssue` call with `fields: ["security", "customfield_10049", "labels", "attachment"]`: security is `10058`, the team is set, the labels are the draft's labels plus `claude-ai` (added by the global plugin's hook to every created ticket), and the attachment count equals the number of embedded files (each file once). The description in that read-back comes back as Markdown with `blob:` links — that is expected and not a failure; do not judge the media from it.
6. If the description or AC doesn't look right after these edits, re-run `editJiraIssue` to correct it. Every description edit uses `contentFormat: html`. Never send the description as Markdown. Start the correction from the HTML you sent in Step 6.5 (or Step 6.2 without media), not from a `getJiraIssue` read-back: once media is embedded, the read-back can come back as Markdown with `blob:` image links and `descriptionEditable: false`, and writing that back breaks the media.
7. After explicit user confirmation, link issues via `mcp__claude_ai_Atlassian_MCP__executeWrite` with `name: createJiraIssueLink`
8. Confirm to user only once the Step 6.4 edit (not needed for Bugs) and the Step 6.5 media edit (only with media) have succeeded: `Ticket created: [{key}](https://maxxton.atlassian.net/browse/{key})`, epic, links, sprint, number of media files embedded. With media, ask the user to open the ticket and check how the files look — the API cannot show the rendering, and a new recording can show "Creating preview…" for a few minutes. For a test ticket, remind the user to delete it in Jira when done; this skill does not delete tickets.
---

## Step 7: Post-Creation Offers

Briefly offer (one line each):
- "Want me to link it to any other tickets?" — via `mcp__claude_ai_Atlassian_MCP__executeWrite` with `name: createJiraIssueLink` (`linkType`, `inwardIssue`, `outwardIssue`)
- "Should I add it to a sprint?" — via `mcp__claude_ai_Atlassian_MCP__editJiraIssue`
- "Want me to break this into sub-tasks?"
---

## Step 8: Iteration Loop

> "Anything about how this ticket came out that you'd want me to handle differently next time?"

Feedback → propose changes → generate updated SKILL.md as downloadable file.
 
---

## Examples

**Quick mode** — directive, fast creation:

User says: "Create a ticket: FM export fails when a customer has no bookings"

→ Infers Bug (fails = error), skips sparring, performs duplicate check, creates after single confirmation.

**Sparring mode** — collaborative thinking before creating:

User says: "I have an idea to improve the CCM billing overview — can you help me shape a ticket?"

→ Asks clarifying questions, queries Knowledge Base for billing domain context, suggests labels and epic, proposes a draft before creating.

**Bug with a screenshot and a recording:**

User says: "Log a bug: booking overview crashes on save, see ~/Desktop/error.png and ~/Desktop/repro.mov"

→ Infers Bug, checks duplicates, looks at `error.png`, places it under *Actual Behaviour* and `repro.mov` under *Steps to Reproduce* in the draft, creates after one confirmation, then uploads both files and embeds them inline with one HTML description edit.

**DoR refresh:**

User says: "refresh DoR"

→ Fetches the Confluence DoR page fresh and applies the latest template structure.
 
---

## Troubleshooting

**Epic not auto-linked** — Verify the team name used in the JQL matches the All Teams table exactly (case-sensitive). Run the epic JQL manually to verify results. If `parent` is rejected, retry with Epic Link `customfield_10014`.

**Wrong team field** — Re-confirm the user's team from the All Teams table and retry with the correct id. If the id is rejected, the team list changed: read the current options with `getJiraIssueTypeMetaWithFields` (Step 4) and use the matching one.

**Ticket created without security level** — Ensure `security: {"id": "10058"}` is passed in `additional_fields`. This ID is the "All employees" level in `maxxton.atlassian.net` and should not change.

**Description shows literal `<h3>`, `<p>` or other tags instead of formatting** — the description was sent without `contentFormat: html`. Always send the description with `contentFormat: html`. If a ticket already has this problem, fix it with `mcp__claude_ai_Atlassian_MCP__editJiraIssue` and `contentFormat: html`.

**Screenshot, video or file card disappeared from the description** — an edit sent the description as Markdown, which drops inline media without an error. Re-insert the `<figure>` and `media-group` blocks with the original `fileId`s and send the description with `contentFormat: html`. If the `fileId`s are gone, upload the files again (Step 6.5).

**HTML create or edit rejected because the HTML content format is disabled** — the call is refused rather than downgraded. Tell the user, create the ticket with the same content as Markdown (`contentFormat: markdown`) and without inline media, and offer to add the files as plain attachments: upload each file as in Step 6.5, then call `uploadAttachmentToJiraIssue` again with its `fileId` to attach it.

**Media upload fails** — usually the file is larger than the Jira attachment limit. Suggest trimming or compressing the recording, then upload again and redo the Step 6.5 description edit.

**Acceptance Criteria field rejected on Bug tickets** — `customfield_10057` is not on the Bug screen. For Bug issue types, include Acceptance Criteria as a section in the description instead.

**Acceptance Criteria field rejects Markdown or plain text (ADF error)** — `customfield_10057` requires an Atlassian Document object; passing a plain string or Gherkin text fails with "Operation value must be an Atlassian Document". Set this field only via the follow-up `mcp__claude_ai_Atlassian_MCP__editJiraIssue` call, as an ADF document object under `fields` (no `contentFormat`): `{"type": "doc", "version": 1, "content": [{"type": "paragraph", "content": [{"type": "text", "text": "Given ..."}]}, ...]}`.

**Field ID mismatch** — Read the current field IDs via `mcp__claude_ai_Atlassian_MCP__executeRead` with `name: getJiraIssueTypeMetaWithFields` and `requiredFieldsOnly: false` (Step 4). The known IDs in this skill are defaults only.
