---
type: llm
---

PASS if the reply says the recording shows a red screen, then a blue screen, then a green
screen, in that order, roughly 3 seconds each, and gives times for them.
FAIL if it gets the colours or their order wrong, invents UI, text, clicks or values that a
plain coloured screen cannot show, or does not describe the video at all.
