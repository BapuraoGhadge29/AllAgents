---
type: regex
pattern: 'claims vs\.? video'
flags: i
---
