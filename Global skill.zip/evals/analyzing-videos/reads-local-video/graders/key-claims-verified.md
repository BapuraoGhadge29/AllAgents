---
# demo.mp4 always yields 3 frames, which the reader subagents Read; a 4th Read means the
# main session re-read a key frame itself (step 6), which a run without the skill never does.
type: tool_used
tool: Read
input_match: 'frame_\d{3}_t[\d.]+s\.png'
min: 4
---
