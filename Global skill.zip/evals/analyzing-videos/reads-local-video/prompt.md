---
description: A local recording is read through the skill; its screens and order come out right.
max_turns: 40
timeout_seconds: 600
allowed_tools: [Read, Glob, Grep, Skill, Agent, AskUserQuestion]
---

What does the screen recording demo.mp4 in this folder show?
