#!/usr/bin/env bash
# Scaffold for the analyzing-videos eval cases: writes demo.mp4 into the run's workspace.
# Run the cases from plugins/global (needs ffmpeg; each case links this file):
#   claude plugin eval . --tag analyzing-videos --scaffold --allow-tools Bash Write
# 9 s: a red, then a blue, then a green screen (3 s each), plus one 0.2 s click at 4 s, so
# the audio is "short sounds" and the skill must not offer transcription.
set -euo pipefail
ffmpeg -v error -y \
  -f lavfi -i "color=c=red:s=640x360:d=3:r=10" \
  -f lavfi -i "color=c=blue:s=640x360:d=3:r=10" \
  -f lavfi -i "color=c=green:s=640x360:d=3:r=10" \
  -f lavfi -i "sine=frequency=1000:duration=9" \
  -filter_complex "[0:v][1:v][2:v]concat=n=3:v=1:a=0[v];[3:a]volume=enable='not(between(t,4,4.2))':volume=0[a]" \
  -map "[v]" -map "[a]" -c:v libx264 -pix_fmt yuv420p -c:a aac demo.mp4
