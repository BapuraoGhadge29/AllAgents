---
type: llm
focus: { source: file, path: findings.md }
---

PASS if the file is the skill's fixed report on the recording: it has a Source part, a
Timeline that names a red, a blue and a green screen in that order with times, and a
"Claims vs video" part.
FAIL if the file is missing or empty, describes something else, or lacks any of those parts.
