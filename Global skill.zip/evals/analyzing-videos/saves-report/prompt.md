---
description: With an output path, the report is also written to that file; the frames are not.
max_turns: 40
timeout_seconds: 600
allowed_tools: [Read, Glob, Grep, Skill, Agent, AskUserQuestion]
---

Analyse the recording demo.mp4 in this folder and save the report to findings.md.
