---
description: Meeting notes involve no recording, so the skill must stay out.
tags: [analyzing-videos]
allowed_tools: [Read, Glob, Grep, Skill]
---

Write meeting notes for yesterday's sprint review.
