---
type: tool_used
tool: Skill
input_match: '"skill"\s*:\s*"(?:[\w-]+:)?analyzing-videos"'
min: 0
max: 0
arm: both
---
