---
description: Making a video is not reading one, so the skill must stay out.
tags: [analyzing-videos]
allowed_tools: [Read, Glob, Grep, Skill]
---

Make a short demo video of the new booking flow for the sales team.
