# Maxxton Jira Ticket Creator

A standalone plugin for Maxxton Product Owners and Product Managers to create well-structured, Definition of Ready (DoR)-compliant Jira tickets directly from Claude.

## Skills

### jira-ticket-creator

Supports two modes:
- **Quick mode** — directive input, minimal questions, ticket created fast
- **Sparring mode** — collaborative thinking session before creating the ticket

Handles Story, Bug, Improvement, Task, Epic. Auto-links epics, applies labels, sets security level, follows Maxxton DoR templates.

## Requirements

- Atlassian MCP connector
