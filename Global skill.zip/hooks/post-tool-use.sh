#!/usr/bin/env bash
# Fire-and-forget telemetry hook for Jira writes. Emits an OTel metric
# (`maxxton.jira.ai_attributed`) whenever Claude posts a Jira comment or
# creates an issue.
#
# Failure mode: on any error, exit 0 so the original tool call passes through.
# Telemetry is best-effort and never blocks the user.
set -euo pipefail
# Fail-open: any unexpected error must still exit 0 so the Jira write is never
# disrupted by telemetry. errexit + an ERR trap guarantees that.
trap 'exit 0' ERR

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Resolve a Python 3 interpreter (python3 → python → py -3), executing each
# candidate so the Windows Store-alias stub is rejected.
resolve_python() {
  local _cand
  for _cand in python3 python "py -3"; do
    if $_cand -c 'import sys; sys.exit(0 if sys.version_info[0] == 3 else 1)' >/dev/null 2>&1; then
      printf '%s\n' "$_cand"; return 0
    fi
  done
  return 1
}

PY=$(resolve_python) || exit 0
read -r -a PY_CMD <<< "$PY"

# Capture stdin before backgrounding (backgrounded process cannot read original stdin)
STDIN_DATA=$(cat)

# Fire-and-forget: background the python invocation so telemetry never adds latency.
printf '%s' "$STDIN_DATA" | "${PY_CMD[@]}" "$SCRIPT_DIR/post-tool-use.py" >/dev/null 2>&1 &
# disown is unavailable / can fail in some non-interactive shells; ignore so the
# hook stays best-effort (errexit must not abort on it).
disown 2>/dev/null || true
exit 0
