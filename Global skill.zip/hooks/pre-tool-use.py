#!/usr/bin/env python3
"""PreToolUse hook payload mutator for Atlassian Jira writes (Atlassian MCP v2 connector).

Reads the hook event payload from stdin and, when the tool is a Claude-
performed Jira write, mutates `tool_input` to attribute it:

* createJiraIssue           — adds `claude-ai` to the top-level `labels`
* addOrEditJiraIssueComment — appends an "ai-assisted" footer, internal projects only

The comment footer is gated to internal projects (MXTS, MCMS): customer-facing
tickets must not carry it (it reads as unprofessional toward customers). The
`claude-ai` issue label and the PostToolUse OTel metric are NOT gated — they
attribute every Claude write regardless of project.

Returns hookSpecificOutput.updatedInput as a full replacement of tool_input
(the harness does not merge — partial diffs would drop required fields).

Failure mode: on any error, prints nothing and exits 0 so the original tool
call passes through unchanged.
"""
import json
import sys

FOOTER_TEXT = "ai-assisted"
FOOTER_MD = f"_{FOOTER_TEXT}_"
FOOTER_HTML = f"<p><em>{FOOTER_TEXT}</em></p>"
LABEL = "claude-ai"
INTERNAL_PROJECTS = {"MXTS", "MCMS"}  # comment footer appended only for these


def _is_internal_issue(issue_key) -> bool:
    """True only for issue keys in an internal project (e.g. MXTS-123).

    Allowlist by design: an unparseable or numeric id returns False, so we
    never risk footering a customer-facing comment.
    """
    if not isinstance(issue_key, str) or "-" not in issue_key:
        return False
    return issue_key.split("-", 1)[0].strip().upper() in INTERNAL_PROJECTS


def _merged_labels(tool_input: dict) -> list:
    labels = list(tool_input.get("labels") or [])
    misplaced = (tool_input.get("additional_fields") or {}).get("labels") or []
    return labels + [label for label in misplaced + [LABEL] if label not in labels]


def _label_issue(tool_input: dict):
    # Labels must live only in the top-level `labels` input: when the connector also
    # receives additional_fields.labels, that list wins and the top-level labels are lost.
    additional = dict(tool_input.get("additional_fields") or {})
    labels = _merged_labels(tool_input)
    if labels == tool_input.get("labels") and "labels" not in additional:
        return None
    additional.pop("labels", None)
    updated = {key: value for key, value in tool_input.items() if key != "additional_fields"}
    updated["labels"] = labels
    if additional:
        updated["additional_fields"] = additional
    return updated


def _with_footer(body: str, content_format: str):
    if content_format == "html":
        footer, separator = FOOTER_HTML, ""
    else:
        footer, separator = FOOTER_MD, "\n\n"
    if body.rstrip().endswith(footer):
        return None
    return body.rstrip() + separator + footer


def _footer_comment(tool_input: dict):
    if not _is_internal_issue(tool_input.get("issueIdOrKey", "")):
        return None  # customer-facing comment: no footer
    body = tool_input.get("commentBody")
    if not isinstance(body, str):
        return None
    content_format = (tool_input.get("contentFormat") or "markdown").lower()
    footered = _with_footer(body, content_format)
    if footered is None:
        return None
    updated = dict(tool_input)
    updated["commentBody"] = footered
    return updated


def mutate(tool_name: str, tool_input: dict):
    if tool_name.endswith("__createJiraIssue"):
        return _label_issue(tool_input)
    if tool_name.endswith("__addOrEditJiraIssueComment"):
        return _footer_comment(tool_input)
    return None


def main():
    try:
        payload = json.load(sys.stdin)
    except Exception:
        return

    tool_name = payload.get("tool_name", "")
    tool_input = payload.get("tool_input") or {}

    try:
        updated = mutate(tool_name, tool_input)
    except Exception:
        return

    if updated is None:
        return

    print(json.dumps({
        "hookSpecificOutput": {
            "hookEventName": "PreToolUse",
            "permissionDecision": "allow",
            "updatedInput": updated,
        }
    }))


if __name__ == "__main__":
    main()
