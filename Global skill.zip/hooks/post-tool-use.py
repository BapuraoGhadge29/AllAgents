#!/usr/bin/env python3
"""PostToolUse telemetry hook for Atlassian Jira writes.

Emits two signals per Jira write: a counter metric (maxxton.jira.ai_attributed)
and a log event (maxxton.jira.ai_write) carrying Jira-specific attributes plus
session.id. No email/PII is emitted; identity is recovered downstream by joining
on session.id to claude_otel_events.

Reads the hook event payload from stdin. Builds OTLP/JSON bodies and POSTs them
to the OTEL collector endpoint. Configuration via env vars:
- OTEL_EXPORTER_OTLP_{METRICS,LOGS}_ENDPOINT: per-signal endpoint (else base + /v1/<signal>)
- OTEL_EXPORTER_OTLP_ENDPOINT: base endpoint (fallback)
- OTEL_EXPORTER_OTLP_{METRICS,LOGS}_HEADERS / OTEL_EXPORTER_OTLP_HEADERS: auth headers
- OTEL_EXPORTER_OTLP_{METRICS,LOGS}_PROTOCOL / OTEL_EXPORTER_OTLP_PROTOCOL: must be http/json
- OTEL_RESOURCE_ATTRIBUTES: k=v,k=v list added to resource attrs
- HOOK_OTLP_DRY_RUN: if "1", print {"metric":..,"log":..} to stdout instead of POSTing

Failure mode: on any error, exit 0 silently (telemetry is best-effort).
"""
import json
import os
import ssl
import sys
import time
import urllib.request


def _project_prefix(issue_key) -> str | None:
    """Project prefix from a Jira issue key (MXTS-123 → MXTS), or None.

    Guards against non-string / numeric ids so telemetry is never skipped by a
    TypeError; normalizes casing/whitespace for consistent metric attributes.
    """
    if not isinstance(issue_key, str) or "-" not in issue_key:
        return None
    prefix = issue_key.split("-", 1)[0].strip().upper()
    return prefix or None


def _classify_jira_tool(tool_name: str, tool_input: dict):
    """Return (tool_attr, project, format_attr) for a Jira write, or None.

    project is None when unparseable; format_attr is None for issue creation.
    Pure — no I/O, no env reads.
    """
    if tool_name.endswith("__addOrEditJiraIssueComment"):
        # The metric keeps tool=addComment so existing dashboards survive the v2 connector rename.
        # _project_prefix guards non-string/numeric ids and normalizes casing.
        project = _project_prefix(tool_input.get("issueIdOrKey"))
        format_attr = _normalized(tool_input.get("contentFormat"), str.lower)
        return "addComment", project, format_attr
    if tool_name.endswith("__createJiraIssue"):
        return "createJiraIssue", _normalized(tool_input.get("projectKey"), str.upper), None
    return None


def _normalized(value, case) -> str | None:
    """Stripped, case-normalized string, or None for non-strings and blanks."""
    if not isinstance(value, str) or not value.strip():
        return None
    return case(value.strip())


def build_metric(cls, resource_attrs: list) -> dict:
    """Build an OTLP/JSON metrics body from an already-computed classification.

    Pure function — no I/O, no env reads. Caller classifies once via
    _classify_jira_tool and shares the result with build_log_event.
    """
    tool_attr, project, format_attr = cls

    # Build datapoint attributes: tool, project (if present), format (if present, addComment only)
    dp_attrs = [{"key": "tool", "value": {"stringValue": tool_attr}}]
    if project:
        dp_attrs.append({"key": "project", "value": {"stringValue": project}})
    if format_attr and tool_attr == "addComment":
        dp_attrs.append({"key": "format", "value": {"stringValue": format_attr}})

    now_ns = str(time.time_ns())

    return {
        "resourceMetrics": [{
            "resource": {
                "attributes": resource_attrs
            },
            "scopeMetrics": [{
                "scope": {"name": "maxxton.jira.hook"},
                "metrics": [{
                    "name": "maxxton.jira.ai_attributed",
                    "sum": {
                        "aggregationTemporality": 1,
                        "isMonotonic": True,
                        "dataPoints": [{
                            "attributes": dp_attrs,
                            "startTimeUnixNano": now_ns,
                            "timeUnixNano": now_ns,
                            "asInt": "1"
                        }]
                    }
                }]
            }]
        }]
    }


# Mirror of pre-tool-use.py's footer-decision gate (kept in sync by hand; the
# two hooks ship independently, so we duplicate rather than couple).
#
# PostToolUse's tool_input is always the PRE-mutation original — Claude Code
# does not surface a PreToolUse hook's updatedInput to PostToolUse — so this
# cannot detect the footer by inspecting tool_input for it. Instead it
# recomputes whether pre-tool-use.py's mutate() would leave the footer present
# in the body actually sent to Jira, mirroring its addOrEditJiraIssueComment
# branch exactly: gated on internal project, then on a string body (markdown and
# html both get a footer). Whether the exact footer shape was already present or
# gets freshly appended doesn't matter — either way the footer ends up in the body.
_INTERNAL_PROJECTS = {"MXTS", "MCMS"}


def _footer_applied(project, tool_input: dict) -> bool:
    """True iff pre-tool-use.py's mutate() leaves the footer present for this write."""
    if project not in _INTERNAL_PROJECTS:
        return False
    return isinstance(tool_input.get("commentBody"), str)


def build_log_event(cls, tool_input: dict, payload: dict, resource_attrs: list) -> dict:
    """Build an OTLP/JSON logs body for one Jira write from an already-computed
    classification.

    Pure — no I/O, no env reads. Carries Jira-specific deltas + session.id only;
    user_email / terminal_type are recovered downstream by joining on session.id.
    """
    tool_attr, project, format_attr = cls

    attrs = [
        {"key": "event.name", "value": {"stringValue": "maxxton.jira.ai_write"}},
        {"key": "tool", "value": {"stringValue": tool_attr}},
    ]
    if project:
        attrs.append({"key": "project", "value": {"stringValue": project}})

    pmode = payload.get("permission_mode")
    if pmode:
        attrs.append({"key": "permission_mode", "value": {"stringValue": str(pmode)}})

    sid = payload.get("session_id")
    if sid:
        attrs.append({"key": "session.id", "value": {"stringValue": str(sid)}})

    agent_type = payload.get("agent_type")
    if agent_type:
        attrs.append({"key": "agent_type", "value": {"stringValue": str(agent_type)}})

    if tool_attr == "addComment":
        body = tool_input.get("commentBody", "")
        if isinstance(body, str):
            attrs.append({"key": "comment_size_bytes", "value": {"intValue": str(len(body.encode("utf-8")))}})
            attrs.append({"key": "footer_applied", "value": {"boolValue": _footer_applied(project, tool_input)}})
        if format_attr:
            attrs.append({"key": "content_format", "value": {"stringValue": format_attr}})

    now_ns = str(time.time_ns())
    return {
        "resourceLogs": [{
            "resource": {"attributes": resource_attrs},
            "scopeLogs": [{
                "scope": {"name": "maxxton.jira.hook"},
                "logRecords": [{
                    "timeUnixNano": now_ns,
                    "observedTimeUnixNano": now_ns,
                    "severityNumber": 9,
                    "severityText": "INFO",
                    "body": {"stringValue": "maxxton.jira.ai_write"},
                    "attributes": attrs,
                }],
            }],
        }],
    }


def _ssl_context() -> ssl.SSLContext:
    """A verifying TLS context with a usable CA bundle.

    The python.org macOS framework build (and some minimal Windows installs)
    ship no discoverable CA bundle — its default verify paths are empty, so
    every HTTPS POST fails CERTIFICATE_VERIFY_FAILED and the metric silently
    never sends. When the default paths are empty, fall back to certifi's
    bundle. Verification is never disabled: the API key rides this connection.
    """
    ctx = ssl.create_default_context()
    paths = ssl.get_default_verify_paths()
    has_ca = bool(
        (paths.cafile and os.path.exists(paths.cafile))
        or (paths.capath and os.path.isdir(paths.capath))
    )
    if not has_ca:
        try:
            import certifi
            ctx.load_verify_locations(certifi.where())
        except Exception:
            pass
    return ctx


def post(signal: str, body: dict) -> None:
    """POST an OTLP/JSON body for the given signal ('metrics' or 'logs').

    Resolves endpoint/headers/protocol from per-signal env vars, falling back
    to the shared OTEL_EXPORTER_OTLP_* vars. Reads env only; never hardcodes
    URL or key. Swallows all exceptions; never prints the API key or body.
    """
    sig = signal.upper()  # METRICS | LOGS

    endpoint = os.environ.get(f"OTEL_EXPORTER_OTLP_{sig}_ENDPOINT", "").strip()
    if not endpoint:
        base = os.environ.get("OTEL_EXPORTER_OTLP_ENDPOINT", "").strip().rstrip("/")
        if base:
            endpoint = base + "/v1/" + signal
    if not endpoint:
        return

    protocol = os.environ.get(f"OTEL_EXPORTER_OTLP_{sig}_PROTOCOL", "").strip().lower()
    if not protocol:
        protocol = os.environ.get("OTEL_EXPORTER_OTLP_PROTOCOL", "").strip().lower()
    if protocol and protocol != "http/json":
        return

    headers = {"Content-Type": "application/json"}
    header_str = os.environ.get(f"OTEL_EXPORTER_OTLP_{sig}_HEADERS", "").strip()
    if not header_str:
        header_str = os.environ.get("OTEL_EXPORTER_OTLP_HEADERS", "").strip()
    if header_str:
        for pair in header_str.split(","):
            if "=" in pair:
                k, v = pair.split("=", 1)
                headers[k.strip()] = v.strip()

    try:
        req = urllib.request.Request(
            endpoint,
            data=json.dumps(body).encode("utf-8"),
            headers=headers,
        )
        urllib.request.urlopen(req, timeout=3, context=_ssl_context())
    except Exception:
        pass


def _inject_remote_settings_env() -> None:
    """Backfill OTEL vars from ~/.claude/remote-settings.json into os.environ.

    Claude Code's remote-settings.json .env block sets vars in its own Node.js
    process but does not pass them to hook subprocesses, so post() sees an empty
    endpoint and silently never sends. Read the file directly and fill any OTEL_*
    var that is missing from the environment (per-var, so a partial shell env still
    gets its gaps filled). Only string values are injected — os.environ rejects
    non-strings, and skipping them keeps one bad value from aborting the rest.
    Fail-open: any read/parse error is silently ignored.
    """
    try:
        settings_path = os.path.join(os.path.expanduser("~"), ".claude", "remote-settings.json")
        with open(settings_path) as f:
            settings = json.load(f)
        for k, v in settings.get("env", {}).items():
            if k.startswith("OTEL_") and isinstance(v, str) and k not in os.environ:
                os.environ[k] = v
    except Exception:
        pass


def main():
    """Main entry point. Wraps everything in try/except, exits 0 on any error."""
    _inject_remote_settings_env()
    try:
        payload = json.load(sys.stdin)
        tool_name = payload.get("tool_name", "")
        tool_input = payload.get("tool_input") or {}
        tool_response = payload.get("tool_response")

        resource_attrs = [{"key": "service.name", "value": {"stringValue": "maxxton.jira.hook"}}]
        otel_resource_attrs = os.environ.get("OTEL_RESOURCE_ATTRIBUTES", "")
        if otel_resource_attrs:
            for pair in otel_resource_attrs.split(","):
                if "=" in pair:
                    k, v = pair.split("=", 1)
                    resource_attrs.append({"key": k.strip(), "value": {"stringValue": v.strip()}})

        cls = _classify_jira_tool(tool_name, tool_input)
        if cls is None:
            return  # non-matching tool

        # Success gate: skip emission if tool_response indicates failure
        if isinstance(tool_response, dict) and (
            tool_response.get("error") is True or
            tool_response.get("isError") is True
        ):
            return

        metric_body = build_metric(cls, resource_attrs)
        log_body = build_log_event(cls, tool_input, payload, resource_attrs)

        if os.environ.get("HOOK_OTLP_DRY_RUN") == "1":
            print(json.dumps({"metric": metric_body, "log": log_body}))
            return

        post("metrics", metric_body)
        post("logs", log_body)
    except Exception:
        return


if __name__ == "__main__":
    main()
