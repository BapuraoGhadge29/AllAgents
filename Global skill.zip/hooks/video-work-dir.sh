#!/usr/bin/env bash
# Owns the analyzing-videos work folders (downloaded recordings, frames, audio) at
# ${TMPDIR:-/tmp}/analyzing-videos/<session-id>: the temp dir exists on every OS and stays
# writable inside Claude Code's Bash sandbox, where ~/.claude/plugins/data is not.
#
# Usage: video-work-dir.sh create <session-id>   creates the folder and prints its path
#        video-work-dir.sh clean [session-id]    deletes it, plus any folder untouched for a
#                                                day (a killed session's); without an id it
#                                                reads session_id from the hook payload on stdin
# clean is fail-open: it never blocks a session and always exits 0.
set -euo pipefail

ROOT="${TMPDIR:-/tmp}"
ROOT="${ROOT%/}/analyzing-videos"

# Session ids are UUIDs; anything else could escape the work folder.
is_session_id() {
  case "$1" in ''|*[!A-Za-z0-9_-]*) return 1 ;; esac
}

create() {
  is_session_id "${1:-}" || { echo "video-work-dir: not a session id: '${1:-}'" >&2; exit 2; }
  mkdir -p "$ROOT/$1"
  echo "$ROOT/$1"
}

clean() {
  local session="${1:-}"
  [ -n "$session" ] || session=$(sed -n 's/.*"session_id"[[:space:]]*:[[:space:]]*"\([^"]*\)".*/\1/p' | head -1) || session=""
  [ -d "$ROOT" ] || return 0
  if is_session_id "$session"; then rm -rf "${ROOT:?}/$session" || true; fi
  find "$ROOT" -mindepth 1 -maxdepth 1 -type d -mtime +0 -exec rm -rf {} + 2>/dev/null || true
}

case "${1:-}" in
  create) create "${2:-}" ;;
  clean) clean "${2:-}" ;;
  *) echo "usage: video-work-dir.sh create <session-id> | clean [session-id]" >&2; exit 2 ;;
esac
