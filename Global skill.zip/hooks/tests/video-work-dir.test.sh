#!/usr/bin/env bash
# Tests for hooks/video-work-dir.sh. Usage: bash hooks/tests/video-work-dir.test.sh
set -uo pipefail

SCRIPT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/../video-work-dir.sh"
TMP=$(mktemp -d)
trap 'rm -rf "$TMP"' EXIT
export TMPDIR="$TMP/"
ROOT="$TMP/analyzing-videos"
pass=0; fail=0
check() {
  if [ "$2" = 0 ]; then echo "  PASS  $1"; pass=$((pass+1)); else echo "  FAIL  $1"; fail=$((fail+1)); fi
}

reset() {
  rm -rf "$ROOT"
  mkdir -p "$ROOT/sess-a/v1" "$ROOT/sess-b" "$ROOT/stale-c"
  touch -t 202001010000 "$ROOT/stale-c"
}

out=$(bash "$SCRIPT" create sess-new)
[ "$out" = "$ROOT/sess-new" ] && [ -d "$ROOT/sess-new" ]; check "create → folder under \$TMPDIR/analyzing-videos, path printed" $?

rc=0; bash "$SCRIPT" create "../../etc" 2>/dev/null || rc=$?
[ "$rc" -eq 2 ] && [ ! -e "$TMP/etc" ]; check "create with a path as session id → exit 2, nothing made" $?

reset
echo '{"session_id":"sess-a","hook_event_name":"SessionEnd"}' | bash "$SCRIPT" clean
[ ! -e "$ROOT/sess-a" ] && [ -d "$ROOT/sess-b" ] && [ ! -e "$ROOT/stale-c" ]
check "SessionEnd payload → own and day-old folders deleted, other live session kept" $?

reset
bash "$SCRIPT" clean sess-b </dev/null
[ ! -e "$ROOT/sess-b" ] && [ -d "$ROOT/sess-a" ]; check "clean with an id argument → that folder deleted" $?

reset
echo '{"session_id":"../.."}' | bash "$SCRIPT" clean
[ -d "$ROOT/sess-a" ] && [ -d "$ROOT/sess-b" ] && [ -d "$TMP" ]; check "clean with a path as session id → live folders kept" $?

rm -rf "$ROOT"
rc=0; echo '{"session_id":"x"}' | bash "$SCRIPT" clean || rc=$?
[ "$rc" -eq 0 ]; check "clean before any folder exists → exit 0" $?

echo "Results: $pass passed, $fail failed"
[ "$fail" -eq 0 ]
