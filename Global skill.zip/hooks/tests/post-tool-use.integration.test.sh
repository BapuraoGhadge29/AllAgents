#!/usr/bin/env bash
# Integration test: point post-tool-use.py at a local one-shot HTTP server and
# assert the real POST it emits for each signal. Offline; needs jq and a
# Python 3 interpreter (resolved from python3 / python / py -3).
set -uo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
HOOK="$SCRIPT_DIR/../post-tool-use.py"
RED='\033[0;31m'; GREEN='\033[0;32m'; NC='\033[0m'
pass=0; fail=0

# Resolve a Python 3 interpreter (python3 → python → py -3) by execution so the
# Windows Store-alias stub is rejected; run via "${PY_CMD[@]}" (Windows Git Bash).
resolve_python() {
  local _cand
  for _cand in python3 python "py -3"; do
    if $_cand -c 'import sys; sys.exit(0 if sys.version_info[0] == 3 else 1)' >/dev/null 2>&1; then
      printf '%s\n' "$_cand"; return 0
    fi
  done
  return 1
}
PY=$(resolve_python) || { echo "no Python 3 found (tried python3, python, py -3)" >&2; exit 1; }
read -r -a PY_CMD <<< "$PY"

run_probe() { # <env_json_overrides_as_KEY=VAL...> piped payload on stdin -> prints captured JSON
  PROBE_HOOK="$HOOK" "${PY_CMD[@]}" "$SCRIPT_DIR/_probe.py" "$@"
}

# Write the probe helper next to the test on first run.
cat > "$SCRIPT_DIR/_probe.py" <<'PYEOF'
import json, os, subprocess, sys, threading
from http.server import BaseHTTPRequestHandler, HTTPServer
HOOK = os.environ["PROBE_HOOK"]
cap = {"posts": []}
class H(BaseHTTPRequestHandler):
    def do_POST(self):
        n = int(self.headers.get("Content-Length", 0))
        cap["posts"].append({"path": self.path,
                              "ctype": self.headers.get("Content-Type"),
                              "has_key": ("X-Api-Key" in self.headers or "X-API-Key" in self.headers),
                              "body": self.rfile.read(n).decode("utf-8")})
        self.send_response(200); self.end_headers(); self.wfile.write(b"{}")
    def log_message(self, *a): pass
payload = sys.stdin.read()
extra = dict(p.split("=", 1) for p in sys.argv[1:])
srv = HTTPServer(("127.0.0.1", 0), H); srv.timeout = 0.25; port = srv.server_address[1]
# Serve in a stoppable loop: srv.timeout makes handle_request() return even with
# no request, so the thread never blocks waiting for a POST that won't come (e.g.
# the grpc case emits zero) and exits cleanly once `stop` is set.
stop = threading.Event()
def _serve():
    while not stop.is_set():
        srv.handle_request()
t = threading.Thread(target=_serve, daemon=True); t.start()
env = dict(os.environ)
env["OTEL_EXPORTER_OTLP_ENDPOINT"] = f"http://127.0.0.1:{port}"
env["OTEL_EXPORTER_OTLP_HEADERS"] = "X-API-Key=THROWAWAY"
env.pop("OTEL_EXPORTER_OTLP_METRICS_ENDPOINT", None)
env.pop("OTEL_EXPORTER_OTLP_LOGS_ENDPOINT", None)
env.pop("HOOK_OTLP_DRY_RUN", None)
env.update(extra)
# The hook POSTs synchronously, so all requests are captured before this returns.
subprocess.run([sys.executable, HOOK], input=payload.encode(), env=env, timeout=10)
stop.set(); t.join(timeout=2); srv.server_close()
print(json.dumps(cap))
PYEOF

ADD_PAYLOAD='{"tool_name":"mcp__claude_ai_Atlassian_MCP__addOrEditJiraIssueComment","session_id":"s1","permission_mode":"default","tool_input":{"issueIdOrKey":"MXTS-1","contentFormat":"markdown","commentBody":"hi"},"tool_response":{"id":"1"}}'

OUT=$(printf '%s' "$ADD_PAYLOAD" | run_probe)
paths=$(printf '%s' "$OUT" | jq -r '[.posts[].path] | sort | join(",")')
if [ "$paths" = "/v1/logs,/v1/metrics" ]; then
  printf "  ${GREEN}PASS${NC} both /v1/metrics and /v1/logs received a POST\n"; pass=$((pass+1))
else
  printf "  ${RED}FAIL${NC} expected both signal paths, got: %s\n" "$paths"; fail=$((fail+1))
fi

ctype_ok=$(printf '%s' "$OUT" | jq -r '[.posts[] | select(.ctype=="application/json" and .has_key)] | length')
if [ "$ctype_ok" = "2" ]; then
  printf "  ${GREEN}PASS${NC} both POSTs carry Content-Type json + X-API-Key\n"; pass=$((pass+1))
else
  printf "  ${RED}FAIL${NC} content-type/header check, matched=%s\n" "$ctype_ok"; fail=$((fail+1))
fi

logname=$(printf '%s' "$OUT" | jq -r '.posts[] | select(.path=="/v1/logs") | .body | fromjson | .resourceLogs[0].scopeLogs[0].logRecords[0].body.stringValue')
if [ "$logname" = "maxxton.jira.ai_write" ]; then
  printf "  ${GREEN}PASS${NC} /v1/logs body is maxxton.jira.ai_write\n"; pass=$((pass+1))
else
  printf "  ${RED}FAIL${NC} log body name: %s\n" "$logname"; fail=$((fail+1))
fi

# Protocol gate: grpc -> no POST at all
OUT2=$(printf '%s' "$ADD_PAYLOAD" | run_probe "OTEL_EXPORTER_OTLP_PROTOCOL=grpc")
n2=$(printf '%s' "$OUT2" | jq -r '.posts | length')
if [ "$n2" = "0" ]; then
  printf "  ${GREEN}PASS${NC} protocol=grpc suppresses both POSTs\n"; pass=$((pass+1))
else
  printf "  ${RED}FAIL${NC} expected 0 POSTs with grpc, got %s\n" "$n2"; fail=$((fail+1))
fi

rm -f "$SCRIPT_DIR/_probe.py"
echo ""
echo "Result: $pass passed, $fail failed"
[ "$fail" -eq 0 ]
