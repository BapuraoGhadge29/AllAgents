#!/usr/bin/env bash
set -uo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SCRIPT="$SCRIPT_DIR/../post-tool-use.py"

# Resolve a Python 3 interpreter (python3 → python → py -3) by execution so the
# Windows Store-alias stub is rejected; run via "${PY_CMD[@]}" (Windows Git Bash).
resolve_python() {
  local _cand
  for _cand in python3 python "py -3"; do
    if $_cand -c 'import sys; sys.exit(0 if sys.version_info[0] == 3 else 1)' >/dev/null 2>&1; then
      printf '%s\n' "$_cand"; return 0
    fi
  done
  return 1
}
PY=$(resolve_python) || { echo "no Python 3 found (tried python3, python, py -3)" >&2; exit 1; }
read -r -a PY_CMD <<< "$PY"

RED='\033[0;31m'
GREEN='\033[0;32m'
NC='\033[0m'
pass=0
fail=0

# assert_eq <desc> <actual> <expected>
# Generic assertion helper for comparing strings.
assert_eq() {
  local description="$1" actual="$2" expected="$3"
  if [ "$actual" = "$expected" ]; then
    printf "  ${GREEN}PASS${NC} %s\n" "$description"
    pass=$((pass + 1))
  else
    printf "  ${RED}FAIL${NC} %s\n    expected: %s\n    actual:   %s\n" "$description" "$expected" "$actual"
    fail=$((fail + 1))
  fi
}

# assert_metric_field <desc> <payload_json> <jq_filter> <expected>
# Runs with HOOK_OTLP_DRY_RUN=1 to capture JSON output without network calls.
assert_metric_field() {
  local description="$1" payload="$2" filter="$3" expected="$4"
  local stdout exit_code actual
  stdout=$(printf '%s' "$payload" | HOOK_OTLP_DRY_RUN=1 "${PY_CMD[@]}" "$SCRIPT" 2>/dev/null)
  exit_code=$?
  if [ "$exit_code" -ne 0 ]; then
    printf "  ${RED}FAIL${NC} %s (script exited %d, expected 0)\n" "$description" "$exit_code"
    fail=$((fail + 1))
    return
  fi
  if [ -z "$stdout" ]; then
    printf "  ${RED}FAIL${NC} %s (no output; expected metric JSON)\n" "$description"
    fail=$((fail + 1))
    return
  fi
  actual=$(printf '%s' "$stdout" | jq -c ".metric$filter" 2>/dev/null) || actual="<extract-failed>"
  if [ "$actual" = "$expected" ]; then
    printf "  ${GREEN}PASS${NC} %s\n" "$description"
    pass=$((pass + 1))
  else
    printf "  ${RED}FAIL${NC} %s\n    expected: %s\n    actual:   %s\n" "$description" "$expected" "$actual"
    fail=$((fail + 1))
  fi
}

# assert_no_output <desc> <payload_json>
# Verifies no stdout and exit 0.
assert_no_output() {
  local description="$1" payload="$2"
  local stdout exit_code
  stdout=$(printf '%s' "$payload" | "${PY_CMD[@]}" "$SCRIPT" 2>/dev/null)
  exit_code=$?
  if [ "$exit_code" -ne 0 ]; then
    printf "  ${RED}FAIL${NC} %s (script exited %d, expected 0)\n" "$description" "$exit_code"
    fail=$((fail + 1))
    return
  fi
  if [ -z "$stdout" ]; then
    printf "  ${GREEN}PASS${NC} %s\n" "$description"
    pass=$((pass + 1))
  else
    printf "  ${RED}FAIL${NC} %s (expected no output, got: %s)\n" "$description" "$stdout"
    fail=$((fail + 1))
  fi
}

echo "post-tool-use.py test suite"
echo "==========================="

echo ""
echo "addComment ADF → metric attributes"
assert_metric_field "metric name is maxxton.jira.ai_attributed" \
  '{"tool_name":"mcp__claude_ai_Atlassian_MCP__addOrEditJiraIssueComment","tool_input":{"cloudId":"x","issueIdOrKey":"MXTS-123","contentFormat":"html","commentBody":"..."},"tool_response":{"id":"12345"}}' \
  '.resourceMetrics[0].scopeMetrics[0].metrics[0].name' '"maxxton.jira.ai_attributed"'

assert_metric_field "tool attribute is addComment" \
  '{"tool_name":"mcp__claude_ai_Atlassian_MCP__addOrEditJiraIssueComment","tool_input":{"cloudId":"x","issueIdOrKey":"MXTS-123","contentFormat":"html","commentBody":"..."},"tool_response":{"id":"12345"}}' \
  '.resourceMetrics[0].scopeMetrics[0].metrics[0].sum.dataPoints[0].attributes[] | select(.key=="tool") | .value.stringValue' '"addComment"'

assert_metric_field "project attribute is MXTS (extracted from MXTS-123)" \
  '{"tool_name":"mcp__claude_ai_Atlassian_MCP__addOrEditJiraIssueComment","tool_input":{"cloudId":"x","issueIdOrKey":"MXTS-123","contentFormat":"html","commentBody":"..."},"tool_response":{"id":"12345"}}' \
  '.resourceMetrics[0].scopeMetrics[0].metrics[0].sum.dataPoints[0].attributes[] | select(.key=="project") | .value.stringValue' '"MXTS"'

assert_metric_field "format attribute is adf" \
  '{"tool_name":"mcp__claude_ai_Atlassian_MCP__addOrEditJiraIssueComment","tool_input":{"cloudId":"x","issueIdOrKey":"MXTS-123","contentFormat":"html","commentBody":"..."},"tool_response":{"id":"12345"}}' \
  '.resourceMetrics[0].scopeMetrics[0].metrics[0].sum.dataPoints[0].attributes[] | select(.key=="format") | .value.stringValue' '"html"'

echo ""
echo "createJiraIssue → metric attributes"
assert_metric_field "tool attribute is createJiraIssue" \
  '{"tool_name":"mcp__claude_ai_Atlassian_MCP__createJiraIssue","tool_input":{"cloudId":"x","projectKey":"MXTS","issueTypeName":"Task","summary":"t"},"tool_response":{"id":"xyz"}}' \
  '.resourceMetrics[0].scopeMetrics[0].metrics[0].sum.dataPoints[0].attributes[] | select(.key=="tool") | .value.stringValue' '"createJiraIssue"'

assert_metric_field "project attribute is MXTS (from projectKey)" \
  '{"tool_name":"mcp__claude_ai_Atlassian_MCP__createJiraIssue","tool_input":{"cloudId":"x","projectKey":"MXTS","issueTypeName":"Task","summary":"t"},"tool_response":{"id":"xyz"}}' \
  '.resourceMetrics[0].scopeMetrics[0].metrics[0].sum.dataPoints[0].attributes[] | select(.key=="project") | .value.stringValue' '"MXTS"'

echo ""
echo "Non-matching tools → no output"
assert_no_output "getJiraIssue (read tool) ignored" \
  '{"tool_name":"mcp__claude_ai_Atlassian_MCP__getJiraIssue","tool_input":{"cloudId":"x","issueIdOrKey":"MXTS-1"},"tool_response":{"id":"1"}}'

assert_no_output "unrelated tool ignored" \
  '{"tool_name":"Bash","tool_input":{"command":"ls"},"tool_response":""}'

echo ""
echo "Failed tool_response → no output"
assert_no_output "error=true suppresses metric" \
  '{"tool_name":"mcp__claude_ai_Atlassian_MCP__addOrEditJiraIssueComment","tool_input":{"cloudId":"x","issueIdOrKey":"MXTS-1","commentBody":"hi"},"tool_response":{"error":true,"message":"Not found"}}'

assert_no_output "isError=true suppresses metric" \
  '{"tool_name":"mcp__claude_ai_Atlassian_MCP__createJiraIssue","tool_input":{"cloudId":"x","projectKey":"MXTS","issueTypeName":"Task","summary":"t"},"tool_response":{"isError":true,"message":"Unauthorized"}}'

echo ""
echo "Malformed / empty stdin → exit 0"
assert_no_output "non-JSON input does not crash" "not-json"
assert_no_output "empty input does not crash" ""

echo ""
echo "Missing OTEL endpoint (non-dry-run) → no crash, exit 0"
# Unset OTEL env vars and run without HOOK_OTLP_DRY_RUN
(
  unset OTEL_EXPORTER_OTLP_ENDPOINT OTEL_EXPORTER_OTLP_METRICS_ENDPOINT OTEL_EXPORTER_OTLP_LOGS_ENDPOINT 2>/dev/null || true
  stdout=$(printf '%s' '{"tool_name":"mcp__claude_ai_Atlassian_MCP__addOrEditJiraIssueComment","tool_input":{"cloudId":"x","issueIdOrKey":"MXTS-1","commentBody":"hi"},"tool_response":{"id":"1"}}' | "${PY_CMD[@]}" "$SCRIPT" 2>/dev/null)
  exit_code=$?
  if [ "$exit_code" -eq 0 ] && [ -z "$stdout" ]; then
    printf "  ${GREEN}PASS${NC} no endpoint, no crash, exit 0\n"
    pass=$((pass + 1))
  else
    printf "  ${RED}FAIL${NC} no endpoint handling (exit_code=%d, stdout=%s)\n" "$exit_code" "$stdout"
    fail=$((fail + 1))
  fi
)

echo ""
echo "log event — maxxton.jira.ai_write"

# addComment ADF (internal MXTS): log carries tool/project/permission_mode/size/format/session.id
LOG_OUT=$(printf '%s' '{"tool_name":"mcp__claude_ai_Atlassian_MCP__addOrEditJiraIssueComment","session_id":"sess-1","permission_mode":"acceptEdits","tool_input":{"issueIdOrKey":"MXTS-123","contentFormat":"html","commentBody":"{\"version\":1,\"type\":\"doc\",\"content\":[{\"type\":\"paragraph\",\"content\":[{\"type\":\"text\",\"text\":\"Hi.\"}]},{\"type\":\"paragraph\",\"content\":[{\"type\":\"text\",\"text\":\"ai-assisted\",\"marks\":[{\"type\":\"em\"}]}]}]}"},"tool_response":{"id":"9"}}' | HOOK_OTLP_DRY_RUN=1 "${PY_CMD[@]}" "$SCRIPT")

assert_eq "log: event name is maxxton.jira.ai_write" \
  "$(printf '%s' "$LOG_OUT" | jq -r '.log.resourceLogs[0].scopeLogs[0].logRecords[0].body.stringValue')" \
  "maxxton.jira.ai_write"

assert_eq "log: tool attr addComment" \
  "$(printf '%s' "$LOG_OUT" | jq -r '.log.resourceLogs[0].scopeLogs[0].logRecords[0].attributes[] | select(.key=="tool") | .value.stringValue')" \
  "addComment"

assert_eq "log: project MXTS" \
  "$(printf '%s' "$LOG_OUT" | jq -r '.log.resourceLogs[0].scopeLogs[0].logRecords[0].attributes[] | select(.key=="project") | .value.stringValue')" \
  "MXTS"

assert_eq "log: permission_mode acceptEdits" \
  "$(printf '%s' "$LOG_OUT" | jq -r '.log.resourceLogs[0].scopeLogs[0].logRecords[0].attributes[] | select(.key=="permission_mode") | .value.stringValue')" \
  "acceptEdits"

assert_eq "log: session.id passed through" \
  "$(printf '%s' "$LOG_OUT" | jq -r '.log.resourceLogs[0].scopeLogs[0].logRecords[0].attributes[] | select(.key=="session.id") | .value.stringValue')" \
  "sess-1"

assert_eq "log: footer_applied true (footer present in body)" \
  "$(printf '%s' "$LOG_OUT" | jq -r '.log.resourceLogs[0].scopeLogs[0].logRecords[0].attributes[] | select(.key=="footer_applied") | .value.boolValue')" \
  "true"

assert_eq "log: comment_size_bytes is the utf-8 byte length" \
  "$(printf '%s' "$LOG_OUT" | jq -r '.log.resourceLogs[0].scopeLogs[0].logRecords[0].attributes[] | select(.key=="comment_size_bytes") | .value.intValue')" \
  "194"

# createJiraIssue: log tool=createJiraIssue, project from projectKey, no comment_size_bytes
CREATE_OUT=$(printf '%s' '{"tool_name":"mcp__claude_ai_Atlassian_MCP__createJiraIssue","session_id":"sess-2","permission_mode":"default","tool_input":{"projectKey":"LDM","issueTypeName":"Task","summary":"t"},"tool_response":{"id":"x"}}' | HOOK_OTLP_DRY_RUN=1 "${PY_CMD[@]}" "$SCRIPT")

assert_eq "log(create): tool createJiraIssue" \
  "$(printf '%s' "$CREATE_OUT" | jq -r '.log.resourceLogs[0].scopeLogs[0].logRecords[0].attributes[] | select(.key=="tool") | .value.stringValue')" \
  "createJiraIssue"

assert_eq "log(create): project LDM" \
  "$(printf '%s' "$CREATE_OUT" | jq -r '.log.resourceLogs[0].scopeLogs[0].logRecords[0].attributes[] | select(.key=="project") | .value.stringValue')" \
  "LDM"

assert_eq "log(create): no comment_size_bytes attr" \
  "$(printf '%s' "$CREATE_OUT" | jq -r '[.log.resourceLogs[0].scopeLogs[0].logRecords[0].attributes[] | select(.key=="comment_size_bytes")] | length')" \
  "0"

echo ""
echo "footer_applied — gated on internal project, not on tool_input body shape"
# PostToolUse's tool_input is always pre-mutation (Claude Code does not surface
# PreToolUse's updatedInput to PostToolUse), so footer_applied cannot be computed
# by inspecting tool_input for the footer text. It must instead mirror
# pre-tool-use.py's own decision: internal project (MXTS/MCMS) -> footer ends up
# present; external project -> pre-tool-use.py's _is_internal_issue gate means the
# footer is NEVER added, regardless of what the body already contains.

# Internal project (MXTS), plain body with no pre-existing footer shape at all —
# this is the regression case for the actual bug: pre-tool-use.py WILL append the
# footer to what's sent to Jira even though (as always) tool_input here shows no
# footer yet. Must be true.
PLAIN_OUT=$(printf '%s' '{"tool_name":"mcp__claude_ai_Atlassian_MCP__addOrEditJiraIssueComment","session_id":"sess-3","permission_mode":"default","tool_input":{"issueIdOrKey":"MXTS-99","contentFormat":"html","commentBody":"{\"version\":1,\"type\":\"doc\",\"content\":[{\"type\":\"paragraph\",\"content\":[{\"type\":\"text\",\"text\":\"Just a plain comment.\"}]}]}"},"tool_response":{"id":"99"}}' | HOOK_OTLP_DRY_RUN=1 "${PY_CMD[@]}" "$SCRIPT")

assert_eq "log: footer_applied true for internal project even though tool_input (pre-mutation) has no footer yet" \
  "$(printf '%s' "$PLAIN_OUT" | jq -r '.log.resourceLogs[0].scopeLogs[0].logRecords[0].attributes[] | select(.key=="footer_applied") | .value.boolValue')" \
  "true"

# External project (LDM), body already shaped exactly like the footer — pre-tool-
# use.py never touches customer-facing comments, so this must still be false.
EXTERNAL_OUT=$(printf '%s' '{"tool_name":"mcp__claude_ai_Atlassian_MCP__addOrEditJiraIssueComment","session_id":"sess-4","permission_mode":"default","tool_input":{"issueIdOrKey":"LDM-7","contentFormat":"html","commentBody":"{\"version\":1,\"type\":\"doc\",\"content\":[{\"type\":\"paragraph\",\"content\":[{\"type\":\"text\",\"text\":\"ai-assisted\",\"marks\":[{\"type\":\"em\"}]}]}]}"},"tool_response":{"id":"7"}}' | HOOK_OTLP_DRY_RUN=1 "${PY_CMD[@]}" "$SCRIPT")

assert_eq "log: footer_applied false for external (LDM) project regardless of body shape" \
  "$(printf '%s' "$EXTERNAL_OUT" | jq -r '.log.resourceLogs[0].scopeLogs[0].logRecords[0].attributes[] | select(.key=="footer_applied") | .value.boolValue')" \
  "false"

# Internal project, HTML body (Atlassian MCP v2) — pre-tool-use.py's mutate()
# appends the HTML footer paragraph, so the real body is footered. Must be true.
HTML_OUT=$(printf '%s' '{"tool_name":"mcp__claude_ai_Atlassian_MCP__addOrEditJiraIssueComment","session_id":"sess-5","permission_mode":"default","tool_input":{"issueIdOrKey":"MXTS-8","contentFormat":"html","commentBody":"<p>Done.</p>"},"tool_response":{"id":"8"}}' | HOOK_OTLP_DRY_RUN=1 "${PY_CMD[@]}" "$SCRIPT")

assert_eq "log: footer_applied true for internal project with HTML body" \
  "$(printf '%s' "$HTML_OUT" | jq -r '.log.resourceLogs[0].scopeLogs[0].logRecords[0].attributes[] | select(.key=="footer_applied") | .value.boolValue')" \
  "true"

# Internal project, markdown format (non-ADF) — mutate()'s markdown branch always
# appends/already-has, so this must be true.
MARKDOWN_OUT=$(printf '%s' '{"tool_name":"mcp__claude_ai_Atlassian_MCP__addOrEditJiraIssueComment","session_id":"sess-6","permission_mode":"default","tool_input":{"issueIdOrKey":"MCMS-1","contentFormat":"markdown","commentBody":"Just a plain markdown comment."},"tool_response":{"id":"1"}}' | HOOK_OTLP_DRY_RUN=1 "${PY_CMD[@]}" "$SCRIPT")

assert_eq "log: footer_applied true for internal project, markdown format" \
  "$(printf '%s' "$MARKDOWN_OUT" | jq -r '.log.resourceLogs[0].scopeLogs[0].logRecords[0].attributes[] | select(.key=="footer_applied") | .value.boolValue')" \
  "true"

echo ""
echo "_inject_remote_settings_env — backfills missing OTEL_* per-var"
# Fallback for when Claude Code's remote-settings.json vars don't reach the hook
# subprocess. Must: (1) fill a var absent from env, (2) fill OTHER missing vars even
# when ENDPOINT is already present (no early return), (3) never overwrite a set var,
# (4) skip non-string values (os.environ rejects them) without aborting the rest.
INJECT_MODE=$(HOME=$(mktemp -d) "${PY_CMD[@]}" -c "
import importlib.util, json, os
os.makedirs(os.path.join(os.environ['HOME'], '.claude'), exist_ok=True)
with open(os.path.join(os.environ['HOME'], '.claude', 'remote-settings.json'), 'w') as f:
    json.dump({'env': {
        'OTEL_EXPORTER_OTLP_ENDPOINT': 'http://from-file',
        'OTEL_EXPORTER_OTLP_HEADERS': 'X-API-Key=k',
        'OTEL_LOG_USER_PROMPTS': True,
        'NOT_OTEL': 'x',
    }}, f)
os.environ['OTEL_EXPORTER_OTLP_ENDPOINT'] = 'http://already-set'
os.environ.pop('OTEL_EXPORTER_OTLP_HEADERS', None)
spec = importlib.util.spec_from_file_location('ph', '$SCRIPT')
ph = importlib.util.module_from_spec(spec); spec.loader.exec_module(ph)
ph._inject_remote_settings_env()
ok = (os.environ.get('OTEL_EXPORTER_OTLP_ENDPOINT') == 'http://already-set'   # not overwritten
      and os.environ.get('OTEL_EXPORTER_OTLP_HEADERS') == 'X-API-Key=k'        # gap filled despite ENDPOINT set
      and 'OTEL_LOG_USER_PROMPTS' not in os.environ                            # non-string skipped
      and 'NOT_OTEL' not in os.environ)                                        # non-OTEL ignored
print('OK' if ok else 'BAD')
" 2>/dev/null)
assert_eq "_inject_remote_settings_env backfills gaps, keeps set vars, skips non-strings" "$INJECT_MODE" "OK"

echo ""
echo "TLS context never disables verification"
# The API key travels on the POST connection — _ssl_context() must always
# verify. Guards against a future "fix" that swaps in an unverified context.
SSL_MODE=$(HOOK_OTLP_DRY_RUN=1 "${PY_CMD[@]}" -c "
import importlib.util, ssl
spec = importlib.util.spec_from_file_location('ph', '$SCRIPT')
ph = importlib.util.module_from_spec(spec); spec.loader.exec_module(ph)
ctx = ph._ssl_context()
print('OK' if ctx.verify_mode == ssl.CERT_REQUIRED and ctx.check_hostname else 'INSECURE')
" 2>/dev/null)
assert_eq "_ssl_context verifies certs + hostname" "$SSL_MODE" "OK"

echo ""
echo "Result: $pass passed, $fail failed"
[ "$fail" -eq 0 ]
