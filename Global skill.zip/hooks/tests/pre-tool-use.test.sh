#!/usr/bin/env bash
set -uo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SCRIPT="$SCRIPT_DIR/../pre-tool-use.sh"

RED='\033[0;31m'
GREEN='\033[0;32m'
NC='\033[0m'
pass=0
fail=0

# All assertions also verify the hook exits 0 — the script is fail-closed
# (`exit 0` on any error so the original call passes through), so a non-zero
# exit code is itself a regression even when stdout is empty.

# assert_mutates <description> <payload> <jq_filter_on_updatedInput> <expected_jq_compact_output>
assert_mutates() {
  local description="$1" payload="$2" filter="$3" expected="$4"
  local stdout exit_code actual
  stdout=$(printf '%s' "$payload" | bash "$SCRIPT" 2>/dev/null)
  exit_code=$?
  if [ "$exit_code" -ne 0 ]; then
    printf "  ${RED}FAIL${NC} %s (script exited %d, expected 0)\n" "$description" "$exit_code"
    fail=$((fail + 1))
    return
  fi
  if [ -z "$stdout" ]; then
    printf "  ${RED}FAIL${NC} %s (no output; expected mutation)\n" "$description"
    fail=$((fail + 1))
    return
  fi
  actual=$(printf '%s' "$stdout" | jq -c ".hookSpecificOutput.updatedInput | $filter" 2>/dev/null) || actual="<extract-failed>"
  if [ "$actual" = "$expected" ]; then
    printf "  ${GREEN}PASS${NC} %s\n" "$description"
    pass=$((pass + 1))
  else
    printf "  ${RED}FAIL${NC} %s\n    expected: %s\n    actual:   %s\n" "$description" "$expected" "$actual"
    fail=$((fail + 1))
  fi
}

# assert_no_output <description> <payload>
assert_no_output() {
  local description="$1" payload="$2"
  local stdout exit_code
  stdout=$(printf '%s' "$payload" | bash "$SCRIPT" 2>/dev/null)
  exit_code=$?
  if [ "$exit_code" -ne 0 ]; then
    printf "  ${RED}FAIL${NC} %s (script exited %d, expected 0)\n" "$description" "$exit_code"
    fail=$((fail + 1))
    return
  fi
  if [ -z "$stdout" ]; then
    printf "  ${GREEN}PASS${NC} %s\n" "$description"
    pass=$((pass + 1))
  else
    printf "  ${RED}FAIL${NC} %s (expected no output, got: %s)\n" "$description" "$stdout"
    fail=$((fail + 1))
  fi
}

echo "pre-tool-use.sh test suite"
echo "=========================="

echo ""
echo "createJiraIssue — label injection (top-level labels, Atlassian MCP v2)"
assert_mutates "adds claude-ai when labels missing" \
  '{"tool_name":"mcp__claude_ai_Atlassian_MCP__createJiraIssue","tool_input":{"cloudId":"x","projectKey":"MXTS","issueType":"Story","summary":"t"}}' \
  '.labels' '["claude-ai"]'

assert_mutates "appends to existing top-level labels, preserves order" \
  '{"tool_name":"mcp__claude_ai_Atlassian_MCP__createJiraIssue","tool_input":{"cloudId":"x","projectKey":"MXTS","issueType":"Story","summary":"t","labels":["Refinement","Backend"]}}' \
  '.labels' '["Refinement","Backend","claude-ai"]'

# Regression: writing claude-ai into additional_fields.labels made Jira drop the top-level labels (MXTS-82698, MXTS-82711).
assert_mutates "moves additional_fields.labels into top-level labels" \
  '{"tool_name":"mcp__claude_ai_Atlassian_MCP__createJiraIssue","tool_input":{"cloudId":"x","projectKey":"MXTS","issueType":"Story","summary":"t","labels":["Refinement"],"additional_fields":{"labels":["QA"],"priority":{"name":"P3"}}}}' \
  '[.labels, .additional_fields]' '[["Refinement","QA","claude-ai"],{"priority":{"name":"P3"}}]'

assert_mutates "drops additional_fields when labels was its only key" \
  '{"tool_name":"mcp__claude_ai_Atlassian_MCP__createJiraIssue","tool_input":{"cloudId":"x","projectKey":"MXTS","issueType":"Story","summary":"t","additional_fields":{"labels":["QA"]}}}' \
  '[.labels, has("additional_fields")]' '[["QA","claude-ai"],false]'

assert_no_output "idempotent when claude-ai already in top-level labels" \
  '{"tool_name":"mcp__claude_ai_Atlassian_MCP__createJiraIssue","tool_input":{"cloudId":"x","projectKey":"MXTS","issueType":"Story","summary":"t","labels":["Refinement","claude-ai"]}}'

# Regression: updatedInput is a full replacement, not a merge — required fields must be present.
assert_mutates "createJiraIssue: required fields present in updatedInput" \
  '{"tool_name":"mcp__claude_ai_Atlassian_MCP__createJiraIssue","tool_input":{"cloudId":"x","projectKey":"MXTS","issueType":"Task","summary":"t"}}' \
  '[.cloudId,.projectKey,.issueType,.summary]' '["x","MXTS","Task","t"]'

assert_mutates "createJiraIssue label is not project-gated (customer project still labelled)" \
  '{"tool_name":"mcp__claude_ai_Atlassian_MCP__createJiraIssue","tool_input":{"cloudId":"x","projectKey":"LDM","issueType":"Task","summary":"t"}}' \
  '.labels' '["claude-ai"]'

echo ""
echo "addOrEditJiraIssueComment — footer append"
assert_mutates "appends footer to plain string body" \
  '{"tool_name":"mcp__claude_ai_Atlassian_MCP__addOrEditJiraIssueComment","tool_input":{"cloudId":"x","issueIdOrKey":"MXTS-1","commentBody":"Looking into this."}}' \
  '.commentBody' '"Looking into this.\n\n_ai-assisted_"'

assert_mutates "appends footer when contentFormat=markdown" \
  '{"tool_name":"mcp__claude_ai_Atlassian_MCP__addOrEditJiraIssueComment","tool_input":{"cloudId":"x","issueIdOrKey":"MXTS-1","contentFormat":"markdown","commentBody":"Done."}}' \
  '.commentBody' '"Done.\n\n_ai-assisted_"'

assert_mutates "appends HTML footer when contentFormat=html" \
  '{"tool_name":"mcp__claude_ai_Atlassian_MCP__addOrEditJiraIssueComment","tool_input":{"cloudId":"x","issueIdOrKey":"MXTS-1","contentFormat":"html","commentBody":"<p>Done.</p>"}}' \
  '.commentBody' '"<p>Done.</p><p><em>ai-assisted</em></p>"'

assert_mutates "addOrEditJiraIssueComment: required fields present in updatedInput" \
  '{"tool_name":"mcp__claude_ai_Atlassian_MCP__addOrEditJiraIssueComment","tool_input":{"cloudId":"x","issueIdOrKey":"MXTS-1","commentBody":"Hello."}}' \
  '[.cloudId,.issueIdOrKey]' '["x","MXTS-1"]'

assert_no_output "idempotent when footer at end of markdown body" \
  '{"tool_name":"mcp__claude_ai_Atlassian_MCP__addOrEditJiraIssueComment","tool_input":{"cloudId":"x","issueIdOrKey":"MXTS-1","commentBody":"Fixed.\n\n_ai-assisted_"}}'

assert_no_output "idempotent when HTML footer is the last paragraph" \
  '{"tool_name":"mcp__claude_ai_Atlassian_MCP__addOrEditJiraIssueComment","tool_input":{"cloudId":"x","issueIdOrKey":"MXTS-1","contentFormat":"html","commentBody":"<p>Fixed.</p><p><em>ai-assisted</em></p>"}}'

# Tighter idempotency: footer text quoted mid-body should NOT suppress append.
assert_mutates "footer-string in mid-markdown body still gets a real footer appended" \
  '{"tool_name":"mcp__claude_ai_Atlassian_MCP__addOrEditJiraIssueComment","tool_input":{"cloudId":"x","issueIdOrKey":"MXTS-1","commentBody":"User said: \"_ai-assisted_\" was missing earlier. Adding it now."}}' \
  '.commentBody | endswith("\n\n_ai-assisted_")' 'true'

echo ""
echo "addOrEditJiraIssueComment — footer gated to internal projects"
# Internal projects (MXTS, MCMS) get the footer; everything else (customer-facing) does not.
assert_mutates "appends footer for MCMS (internal) comment" \
  '{"tool_name":"mcp__claude_ai_Atlassian_MCP__addOrEditJiraIssueComment","tool_input":{"cloudId":"x","issueIdOrKey":"MCMS-45","commentBody":"Internal note."}}' \
  '.commentBody' '"Internal note.\n\n_ai-assisted_"'

assert_no_output "no footer for LDM (customer) markdown comment" \
  '{"tool_name":"mcp__claude_ai_Atlassian_MCP__addOrEditJiraIssueComment","tool_input":{"cloudId":"x","issueIdOrKey":"LDM-1616","commentBody":"Meeting summary for the customer."}}'

assert_no_output "no footer for LDM (customer) HTML comment" \
  '{"tool_name":"mcp__claude_ai_Atlassian_MCP__addOrEditJiraIssueComment","tool_input":{"cloudId":"x","issueIdOrKey":"LDM-1616","contentFormat":"html","commentBody":"<p>Hi.</p>"}}'

# Allowlist by design: an unparseable / numeric issue id is treated as non-internal (no footer), so we never risk footering a customer comment.
assert_no_output "no footer when issueIdOrKey is unparseable (numeric id)" \
  '{"tool_name":"mcp__claude_ai_Atlassian_MCP__addOrEditJiraIssueComment","tool_input":{"cloudId":"x","issueIdOrKey":"100123","commentBody":"By numeric id."}}'

echo ""
echo "Non-matching tools — pass through silently"
assert_no_output "Bash tool call ignored" \
  '{"tool_name":"Bash","tool_input":{"command":"ls"}}'
assert_no_output "unrelated Atlassian tool ignored" \
  '{"tool_name":"mcp__claude_ai_Atlassian_MCP__getJiraIssue","tool_input":{"cloudId":"x","issueIdOrKey":"MXTS-1"}}'

echo ""
echo "Malformed input — does not crash"
assert_no_output "non-JSON input" "not-json-at-all"
assert_no_output "empty input" ""

echo ""
echo "Result: $pass passed, $fail failed"
[ "$fail" -eq 0 ]
