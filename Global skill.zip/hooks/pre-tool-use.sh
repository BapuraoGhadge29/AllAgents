#!/usr/bin/env bash
# Thin wrapper around pre-tool-use.py — pipes the hook stdin payload directly
# into Python so large Jira descriptions don't run into OS env var size limits.
# Failure mode: on any error, emit nothing and exit 0 (original call passes through).
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# Resolve a Python 3 interpreter (python3 → python → py -3), executing each
# candidate so the Windows Store-alias stub is rejected. See CLAUDE.md
# "Invoking Python from shell scripts".
resolve_python() {
  local _cand
  for _cand in python3 python "py -3"; do
    if $_cand -c 'import sys; sys.exit(0 if sys.version_info[0] == 3 else 1)' >/dev/null 2>&1; then
      printf '%s\n' "$_cand"; return 0
    fi
  done
  return 1
}
# `|| exit 0` / `|| true` keep the wrapper fail-open: if Python is missing or
# crashes, emit nothing and exit 0 so the original tool call passes through.
PY=$(resolve_python) || exit 0
$PY "$SCRIPT_DIR/pre-tool-use.py" || true
