---
name: sprint-insights
description: "Generates a sprint analysis report from live Jira data: completion, velocity trend, estimation accuracy, retrospective insights and next-sprint recommendations, saved as Markdown. Use when a scrum master or team lead asks for a sprint report or sprint insights.\n"
disable-model-invocation: true
allowed-tools:
- mcp__claude_ai_Atlassian_MCP__getAccessibleAtlassianResources
- mcp__claude_ai_Atlassian_MCP__searchJiraIssuesUsingJql
- mcp__claude_ai_Atlassian_MCP__getJiraIssue
- Write
argument-hint: "[project-key] [sprint-name] [output-folder]"
---

# Sprint Insights

Produces a comprehensive sprint analysis report with quantitative metrics, estimation accuracy diagnostics,
workload distribution, retrospective observations, and actionable recommendations. The final report is saved
as a Markdown file to a folder provided by the user.

---

## Report Structure

Every sprint report must contain all sections below, **ordered by importance** — the most actionable information comes first. **Keep the total report under 750 words** — use tables and bullet points, not paragraphs. Every section should be scannable in under 30 seconds.

```
# Sprint Report — {Sprint Name} — {Date}

## 1. Sprint Health Score            ← single composite score (0–100) at a glance
## 2. Retrospective                  ← most important: What Went Well / What to Improve
                                       max 5 bullets each — highest-impact only
## 3. Recommendations                ← immediate actions for next sprint (includes capacity forecast)
                                       max 5 — highest-impact only
## 4. Sprint Overview                ← key numbers at a glance (one table) + sprint goal status
## 5. Velocity Trend                 ← 5-sprint throughput table with Bug% + one-line trend summary
## 6. Completion Metrics             ← overall / dev / QA rates + issue type breakdown
## 7. Estimation Accuracy            ← outliers only (>±30%), not every ticket
## 8. Workload Distribution          ← per-person summary table
## 9. Carry-Over & Scope Creep       ← max 5 highest-impact items, flagging multi-sprint tickets
## 10. Bottlenecks & Blocked Work    ← max 5 highest-impact items only
## 11. Quality Signals               ← reopened tickets + multi-sprint chronic blockers
## 12. Next Sprint Forecast          ← data-driven scope recommendation for next sprint
```

---

## 12-Step Workflow

---

### Step 1: Collect Input

If the user has not provided all three inputs in the invocation arguments, ask for them now:

> To generate the sprint report I need three things:
>
> 1. **Jira project key** — e.g. `MXTS`
> 2. **Sprint name** — exact sprint name as it appears in Jira, e.g. `Sprint 42` (or type `current` for the active sprint)
> 3. **Output folder** — local folder path where the report Markdown file should be saved, e.g. `C:\Reports\sprints`

Wait for all three before proceeding. Do not guess or assume defaults.

---

### Step 2: Resolve Sprint Reference

**Tools:** `getAccessibleAtlassianResources`, `searchJiraIssuesUsingJql`

#### 2a. Obtain cloudId

Call `getAccessibleAtlassianResources` first. Use the `id` of the returned Jira resource as `cloudId` in every subsequent Atlassian tool call.

#### 2b. Define the minimal field list

Use this `fields` list for **every** JQL query in this skill. Never omit it — the default includes `description`, which inflates each response by 10–20× and makes results too large to read inline.

```
["summary", "status", "issuetype", "priority", "assignee",
 "timeoriginalestimate", "timespent", "timeestimate",
 "customfield_10016", "customfield_10028", "story_points",
 "created", "resolutiondate", "labels", "customfield_10020"]
```

For velocity trend queries (Step 3b) where you only need metrics, use this **slim field list** instead:
```
["summary", "status", "issuetype", "timeoriginalestimate", "timespent",
 "customfield_10016", "customfield_10028", "story_points", "customfield_10020"]
```

#### 2c. Fetch sprint issues

If the user typed `current`, query:
```jql
project = "{PROJECT_KEY}" AND sprint in openSprints() ORDER BY priority DESC
```

Otherwise, query:
```jql
project = "{PROJECT_KEY}" AND sprint = "{SPRINT_NAME}" ORDER BY priority DESC
```

Paginate through all results: set `maxResults` to 100. After each response, if it returns a `nextPageToken` (`isLast` is false), pass it as `nextPageToken` on the next call and repeat until all pages are fetched. Use the **full field list** from Step 2b. Combine all pages — this is the **sprint issue set**.

#### 2d. Sprint name fallback

If the query returns 0 results, the user likely provided a shortened name (e.g. `IM/CM 215` instead of `IM/CM - 215 (20/03 - 02/04)`). Do **not** ask the user to look it up. Instead:

1. Run: `project = "{PROJECT_KEY}" AND sprint in closedSprints() ORDER BY updated DESC` with `maxResults=10` and the slim field list.
2. Collect all distinct sprint names from `customfield_10020` across the returned issues.
3. Find the name that contains the sprint number the user provided (e.g. `"215"`).
4. Re-run the Step 2c query using the full matched sprint name.

If still no match is found after the fallback, tell the user:
> No sprint matching `{SPRINT_NAME}` found in project `{PROJECT_KEY}`. Sprints found: {list}. Please confirm the sprint name.

Stop here only if no match is found after the fallback.

#### 2e. Extract sprint metadata

From the results, note from `customfield_10020`:
- Sprint name (exact), start date, end date
- Sprint goal — store for Section 4. In Section 4, show: `**Sprint Goal:** {goal text} — **Met** ✓ / **Not met** ✗ / *Not defined*`. Determine "Met" if overall completion rate ≥ 80% **and** no P1/P2 issues are incomplete.

---

### Step 3: Fetch Velocity Trend — Last 5 Sprints

**Tool:** `searchJiraIssuesUsingJql`

**Purpose:** Calculate throughput-based velocity: number of issues completed per sprint over the last 5 sprints.

#### 3a. Identify the last 5 sprints

The sprint being analyzed is always **Sprint N** — whether it is the currently active sprint or a closed one. Never replace Sprint N with the active sprint when the user requested a specific closed sprint.

Run:
```jql
project = "{PROJECT_KEY}" AND sprint in closedSprints() ORDER BY updated DESC
```

Set `maxResults` to 100. Extract **distinct sprint names** from the sprint field of each issue. Deduplicate on exact sprint name string. Sort by sprint end date descending and take the **4 most recent closed sprints that ended before Sprint N** (Sprint N-4 through Sprint N-1). Combined with Sprint N these form the 5-sprint trend window.

If fewer than 4 closed sprints are available, use however many exist and note the limited sample size.

#### 3b. Query each previous sprint

For each of the 4 previous closed sprints, run:
```jql
project = "{PROJECT_KEY}" AND sprint = "{SPRINT_NAME}"
```

Paginate through all results (same technique as Step 2c: follow `nextPageToken` until `isLast` is true) and use the **slim field list** from Step 2b. For each sprint, collect:

| Data point | How to derive |
|------------|--------------|
| Sprint name | From sprint field |
| Total issues | Count of all returned issues |
| Dev-completed | Count where status ∈ Done, Resolved, Closed, "Checked by QA", "Cannot Test", "Ready for QA", "Pending Review" |
| QA-completed | Count where status ∈ Done, Resolved, Closed, "Checked by QA", "Cannot Test" |
| Overall completed | Same as QA-completed |
| Incomplete | Total − Dev-completed |
| Dev / QA / Overall % | `(count / Total) × 100` |
| Bug % | `(Bug issues / Total) × 100` |
| Hours estimated | Sum of `timeoriginalestimate / 3600` |
| Hours logged | Sum of `timespent / 3600` |

#### 3c. Build the velocity trend table

Combine the per-sprint results from 3b into one table:

```
| Sprint | Total | Dev Done | QA Done | Incomplete | Dev% | QA% | Bug% | Est h | Logged h |
|--------|------:|----------|---------|-----------|------|-----|------|------:|---------|
| Sprint N-4 | ... | ... | ... | ... | ...% | ...% | ...% | ... | ... |
| Sprint N-3 | ... | ... | ... | ... | ...% | ...% | ...% | ... | ... |
| Sprint N-2 | ... | ... | ... | ... | ...% | ...% | ...% | ... | ... |
| Sprint N-1 | ... | ... | ... | ... | ...% | ...% | ...% | ... | ... |
| Sprint N   | ... | ... | ... | ... | ...% | ...% | ...% | ... | ... |
| **Avg**    |     |          |         |            | **...%** | **...%** | **...%** | | |
```

#### 3d. Trend signals to flag

After building the table, evaluate and flag where applicable:
- **Declining trend:** Completion % falling sprint-over-sprint
- **Volatile trend:** Swings >20% between consecutive sprints — scope is unpredictable
- **Consistent overload:** Total issues consistently > completable capacity — planning is too optimistic
- **Rising Bug%:** Bug% risen >10pp over 5-sprint window — quality regression signal

Include a one-sentence trend summary below the table.

---

### Step 4: Verify Issue Data Completeness

**Tool:** None — data is already available from the Step 2 JQL response.

All fields needed for Sections 6–12 are returned by the Step 2c query. **Do not call `getJiraIssue` for every issue.** Only use it for a specific ticket when inspecting individual worklog timestamps (e.g., cycle time for a single slow-mover). Limit to at most 3–5 targeted calls.

If a field is missing from all issues (e.g., story points always null), note it in the report rather than re-fetching.

---

### Step 5: Calculate Quantitative Metrics

**Tool:** None — compute directly from fetched data.

**Zero-logging check:** Before computing any hour-based metrics, count how many issues have `timespent = 0`. If that count exceeds 80% of the sprint, skip only the **hour-based sub-metrics within Section 6** (Hours estimated, Hours logged, Hour burn rate %) and skip **Section 7 (Estimation Accuracy)** entirely. Replace the skipped content with:
> *Time tracking not in use — hour burn and estimation accuracy metrics are unavailable for this sprint.*

Do **not** skip completion rates (Dev%, QA%, Overall%) or issue type breakdowns — those are count-based and remain valid.

#### 5a. Completion Metrics

| Metric | Statuses included | Formula |
|--------|------------------|---------|
| **Dev-completed** | Done, Resolved, Closed, "Checked by QA", "Cannot Test", "Ready for QA", "Pending Review" | Count matching issues |
| **QA-completed** | Done, Resolved, Closed, "Checked by QA", "Cannot Test" | Count matching issues |
| **Overall completed** | Same as QA-completed | — |
| Dev / QA / Overall % | — | `(count / Total) × 100` |
| Story points planned / completed | — | Sum of `story_points` |
| SP velocity (%) | — | `(SP Completed / SP Planned) × 100` |
| Hours estimated / logged | — | Sum of `timeoriginalestimate / 3600`, `timespent / 3600` |
| Hour burn rate (%) | — | `(Hours Logged / Hours Estimated) × 100` |

#### 5b. Estimation Accuracy Per Ticket

For each issue where both `timeoriginalestimate > 0` and `timespent > 0`:
```
deviation (%) = ((timespent − timeoriginalestimate) / timeoriginalestimate) × 100
```

| Classification | Condition |
|----------------|-----------|
| Overestimated | deviation < −30% |
| Accurate | −30% to +30% |
| Underestimated | > +30% |
| Severely underestimated | > +100% |

Sort by deviation descending to surface the biggest misses.

#### 5c. Workload Distribution

Group issues by `assignee.displayName` and compute per person: tickets assigned, story points, hours estimated, hours logged, Dev%/QA%/Overall%. Flag if any single person carried >40% of sprint story points.

#### 5d. Issue Type Breakdown

| Issue Type | Count | % of Sprint | QA Done | QA% |
|------------|------:|------------|--------:|-----|
| Bug | ... | ...% | ... | ...% |
| Task | ... | ...% | ... | ...% |
| … | | | | |

Signals: **>40% Bugs** → reactive sprint; **Tech Debt QA% < 50%** → cleanup deprioritised; **any type with QA% < 50% while others >80%** → needs different planning treatment.

---

### Step 6: Identify Carry-Over and Scope Creep

**Tool:** None — derive from data collected.

**Report only the top 5 most impactful items** (highest estimated hours first). If more exist, note the total count.

#### Carry-Over Tickets
Issues not in the QA-completed set. Include a **Sprints** column from `customfield_10020` array length.

| Ticket | Summary | Status | Sprints | Est h | Logged h |
|--------|---------|--------|--------:|------:|--------:|

Flag tickets with **Sprints ≥ 3** as chronic blockers — alive across 3+ sprints, representing invisible accumulated scope.

#### Scope Creep (Mid-Sprint Additions)
If sprint start date is available, identify issues where `issue.created > sprint.startDate`. Flag if scope creep accounts for >15% of total sprint hours.

---

### Step 7: Identify Bottlenecks, Quality Signals and Blocked Work

**Tool:** None — derive from data.

**Report only the top 5 most impactful items** (highest hours at risk). If more exist, note the total count.

#### Blocked / Stalled Tickets
Issues where `status = "Blocked"`, labels contain `"blocked"` or `"impediment"`, or `timespent = 0` but issue has been in the sprint since the start.

#### Long Cycle Time
```
cycle_time (days) = resolutiondate − sprint_start_date
```
Flag tickets with cycle time > 75% of sprint duration.

#### Unlogged Work
Tickets marked Done but with `timespent = 0` — flag as they distort future estimates.

#### Quality Signals (Section 11 of the report)

**Reopened tickets:** Count issues where `status.name = "Reopened"` — each indicates a defect escaped review. List with key and summary.

**Chronic carry-overs:** From Step 6, tickets where `Sprints ≥ 3`. List with key, summary, sprint count.

If zero reopened and zero chronic carry-overs: *No quality regression signals detected this sprint.*

---

### Step 8: Calculate Next Sprint Capacity Forecast

**Tool:** None — derive from velocity data in Step 3.

Surface as **Section 12** in the report.

#### 8a. Calculate sustainable throughput

Use QA-done counts from all available sprints (up to 5). Let **K** = actual number of sprints available (1–5). If K < 5, note in the report that the forecast is based on a limited sample of K sprint(s) and interpret with caution.

If trend is **declining**, weight recent sprints more heavily. For the sprints available, assign weights 2, 2, 2, 1, 1 starting from the most recent (use only as many weights as there are sprints and normalise the denominator accordingly):

| K | Weights (newest → oldest) | Denominator |
|---|--------------------------|-------------|
| 5 | 2, 2, 2, 1, 1 | 8 |
| 4 | 2, 2, 2, 1 | 7 |
| 3 | 2, 2, 1 | 5 |
| 2 | 2, 1 | 3 |
| 1 | 1 | 1 |

```
weighted_avg = sum(weight_i × QA-done_i) / denominator
```

If **stable or improving**, simple average:
```
weighted_avg = sum(QA-done counts) / K
```

Round to nearest integer.

#### 8b. Derive scope recommendations

Turn the sustainable throughput from 8a into scope targets:

```
recommended_scope_80 = round(sustainable_throughput / 0.80)   ← target 80% completion
recommended_scope_75 = round(sustainable_throughput / 0.75)   ← conservative 75% target
```

#### 8c. Write the forecast section

```
**Sustainable throughput:** ~{weighted_avg} tickets/sprint ({K}-sprint weighted average)
**Current sprint size:** {total} tickets → {qaDone} completed ({qaPct}%)

| Target completion | Recommended sprint scope |
|-------------------|-------------------------|
| 80% (recommended) | ≤ {recommended_scope_80} tickets |
| 75% (conservative) | ≤ {recommended_scope_75} tickets |

> {one-line insight}
```

Include as **Recommendation #1** in Section 3, referencing the ceiling number directly.

---

### Step 9: Calculate Sprint Health Score

**Tool:** None — derive from all metrics above.

| Component | Weight | How to score |
|-----------|--------|-------------|
| Overall completion rate | 40 pts | `(overall% / 100) × 40` |
| Estimation accuracy | 20 pts | Start at 20; subtract 5 per ticket >+100% deviation, 2 per >+30% — floor at 0 |
| No blocked / stalled work | 20 pts | Start at 20; subtract 4 per blocked/stalled ticket — floor at 0 |
| Scope creep control | 10 pts | Start at 10; subtract 7 if creep >15% of hours; 10 if >30% |
| Quality signals | 10 pts | Start at 10; subtract 3 per reopened ticket, 2 per chronic carry-over — floor at 0 |

Round to nearest integer. Label:
- **85–100**: Healthy sprint
- **65–84**: Mostly on track — a few areas to watch
- **45–64**: Struggled — clear patterns to address
- **0–44**: Difficult sprint — significant process or planning gaps

Place as **Section 1** at the very top of the report.

---

### Step 10: Generate Retrospective Insights

**Tool:** None — synthesise from all metrics above.

Write as **short bullet points only**. **Maximum 5 bullets per sub-section**. Focus on **team patterns and process**, never on individual performance. Do not name individuals in a negative context.

#### What Went Well
3–5 bullets citing concrete data. Examples:
- "X of Y tickets completed within estimate — strong planning accuracy"
- "No blocked tickets — clean sprint flow"

#### What to Improve
3–5 bullets. Frame as process observations, not personal shortcomings:
- **Write:** "Oracle migration tickets consistently ran 60–80% over estimate — this area needs a buffer in planning" (not who caused it)

Consider: estimation gaps by ticket type, dependency delays, mid-sprint additions displacing committed work, zero-log done tickets, chronic carry-overs, sprint scope vs. sustainable throughput gap.

---

### Step 11: Write Recommendations for Next Sprint

**3–5 recommendations maximum — highest-impact only.** Each is one line: the action, not a retelling of the problem. Keep each under 25 words.

```
1. **[Short title]** — [One-line action]
```

Examples:
- **Estimation buffer for migrations** — Apply 1.5× estimate multiplier to all `oracle_migration` tickets at planning.
- **Sprint lock policy** — No new tickets after day 2 unless an existing ticket is removed.

---

### Step 12: Save the Report

**Tool:** Write (built-in)

**File name format:** `sprint-report-{sprint-name-slugified}-{YYYY-MM-DD}.md`

Save immediately to the folder provided in Step 1 — do not ask for confirmation.

After saving, output:
> ✓ Report saved to: `{output-folder}/sprint-report-{name}-{date}.md`
>
> **Quick summary:**
> - Health score: {score}/100 — {label}
> - Completion: {devPct}% dev done, {qaPct}% QA done
> - Hours: {estimated}h estimated → {logged}h logged ({burn-rate}%)
> - Carry-over: {N} tickets ({chronic} chronic, ≥3 sprints)
> - Quality: {reopened} reopened ticket(s)
> - Next sprint ceiling: ≤{recommended_scope_80} tickets for 80% target
> - Top issue: [one-line highlight of the biggest problem found]

---

## Tips

- **Keep it short**: Full report must stay under 750 words. Cut least impactful rows if sections grow long.
- **No individual blame**: Attribute problems to ticket areas, issue types, or team-wide process gaps.
- **Always specify `fields` in JQL calls**: Omitting `fields` causes Jira to include `description`, inflating responses 10–20× and preventing inline reading.
- **Sprint name fallback built-in**: If exact sprint name returns 0 results, use the Step 2d fallback — do not ask the user to look it up.
- **No external runtimes needed**: Compute all metrics in-context from JQL response data. Do not use Bash, Python, or Node.js scripts.
- **Story points field varies**: Try `customfield_10016`, `customfield_10028`, or `story_points` — use whichever returns a value.
- **Zero worklogs ≠ zero effort**: Flag unlogged tickets rather than treating them as 0h.
