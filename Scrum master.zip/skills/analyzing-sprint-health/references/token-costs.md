# Token Cost Reference

Approximate output HTML size and token usage per depth × focus combination.
Figures are measured against a real 32-ticket sprint (MXTS-Con 184, sprint 14783).
Token estimate = file size ÷ 4 (standard GPT/Claude tokenisation rule of thumb).

## Measured costs by mode

| Depth | Focus | Output size | ~Tokens |
|-------|-------|------------:|--------:|
| quick | any   | ~13,600 chars | **~3,400** |
| standard | workload | ~34,500 chars | **~8,600** |
| standard | health | ~45,100 chars | **~11,300** |
| standard | retro | ~61,400 chars | **~15,400** |
| standard | all | ~84,400 chars | **~21,100** |
| full | timeline | ~212,100 chars | **~53,000** |
| full | workload | ~222,600 chars | **~55,700** |
| full | health | ~233,300 chars | **~58,300** |
| full | health,workload | ~243,800 chars | **~60,900** |
| full | retro | ~249,600 chars | **~62,400** |
| full | workload,retro | ~260,100 chars | **~65,000** |
| full | health,retro | ~262,000 chars | **~65,500** |
| full | all | ~272,500 chars | **~68,100** |

> Note: `quick` ignores focus entirely — all four focus values produce identical output.

## What drives the cost

**quick** renders only the header, KPI tiles, and a text summary. Flat cost regardless
of focus (~3,400 tokens).

**standard** scales with the sections included. `workload` is cheapest (per-user chart
+ table only). `all` stacks every health, workload, and retro section, reaching ~21k
  tokens — still well within context limits but noticeably heavier.

**full** adds the entire timeline block: stacked daily burn, cumulative burn-up,
per-person heatmap, per-ticket heatmap, and Gantt chart. These embed inline worklog
arrays for every ticket and team member, which is inherently data-heavy. Surprisingly,
`full [timeline]` is the *cheapest* full mode (~53k) because it skips the large ticket
tables; `full [all]` at ~68k is the most expensive.

## Recommended defaults by use case

| Use case | Recommended mode | ~Tokens |
|----------|-----------------|--------:|
| Quick standup check | `quick` | ~3,400 |
| Mid-sprint health pulse | `standard health` | ~11,300 |
| Workload review with team | `standard workload` | ~8,600 |
| Retro prep | `standard retro` | ~15,400 |
| Full sprint debrief | `full all` | ~68,100 |
| Pre-planning (capacity + health) | `standard health,retro` | ~18,000 est. |
| Timeline deep-dive only | `full timeline` | ~53,000 |

## Cost vs. value rule of thumb

`standard [health]` or `standard [workload]` gives 90%+ of the actionable signal at
roughly 12–16% of the token cost of `full [all]`. Reserve `full [all]` for end-of-sprint
retros where every section is needed.
