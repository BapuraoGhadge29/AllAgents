---
name: analyzing-sprint-health
description: "Generates an interactive HTML sprint health dashboard from a Jira sprint URL or ID. Use when asked about sprint health, velocity, workload, burndown, or retro prep — e.g. \"sprint health for sprint 184\" or \"how did the team do?\" Covers 5-dimension health scores, per-person workload, burn heatmaps, and next-sprint capacity.\n"
disable-model-invocation: true
allowed-tools:
- Bash
- mcp__claude_ai_Atlassian_MCP__getAccessibleAtlassianResources
- mcp__claude_ai_Atlassian_MCP__searchJiraIssuesUsingJql
- mcp__claude_ai_Atlassian_MCP__getJiraIssue
- mcp__claude_ai_Atlassian_MCP__searchConfluence
- mcp__claude_ai_Atlassian_MCP__getConfluenceContent
- mcp__claude_ai_Atlassian_MCP__updateConfluenceContent
- mcp__claude_ai_Atlassian_MCP__createConfluenceContent
- mcp__claude_ai_Atlassian_MCP__discover
- mcp__claude_ai_Atlassian_MCP__executeRead
---

# Sprint Health Suite

Modes: depth (quick / standard / full) × focus (health / workload / timeline / retro). Combine freely.

## Bundled scripts

| Script                        | Purpose                                                                                                                                    |
|-------------------------------|--------------------------------------------------------------------------------------------------------------------------------------------|
| `scripts/process_sprint.py`   | Parse Jira JSON → metrics JSON. Auto-detects story points vs hours. Handles caching, scope creep, quality signals, sprint name extraction. |
| `scripts/build_dashboard.py`  | Render metrics JSON → self-contained HTML dashboard. Supports all depth/focus combinations.                                                |
| `scripts/build_wl_patches.py` | Build a worklog patches file when `getJiraIssue` results are saved to disk.                                                                |
| `scripts/patch_worklogs.py`   | Apply worklog patches to metrics JSON and recompute all daily arrays.                                                                      |

---

## Dashboard features

The generated HTML dashboard includes:

- **Sprint Health Score** — computed at the top of every standard/full dashboard. Five dimensions, each independently scored 0–100 with its formula shown inline. Weighted overall score and letter grade (A–F).

  | Dimension              | Weight | Formula                                                      |
  |------------------------|--------|--------------------------------------------------------------|
  | 🎯 Delivery            | 30%    | `(done ÷ committed) × 100`                                   |
  | 📐 Estimation Accuracy | 20%    | `100 − \|overrun%\|`                                         |
  | 📏 Scope Discipline    | 15%    | `100 − (scope_creep% × 2)`                                   |
  | 🔬 Quality             | 20%    | `100 − ((reopened×3 + chronic×2 + blocked×5) ÷ total × 100)` |
  | 🎪 Focus               | 15%    | `100 − (touched_spillover% × 3) − (untouched% × 5)`          |

- **Velocity Ratio** — displayed as a percentage (e.g. 87.5%) rather than a raw decimal.
- **Logged %** — the hours-logged-vs-estimated ratio column shows percentages (e.g. 1124%) instead of multipliers (11.24×), making it immediately readable.
- **Full Sprint Ticket List** — multi-status chip filter (click one or more status chips to filter; no chips = show all) plus sort-by-column. Filter and sort work together.
- **Ticket Status Breakdown tile** — layout adapts dynamically to any number of statuses; no hardcoded height that clips content.
- **Dynamic user colours** — each team member is assigned a colour deterministically from a 16-colour palette (hashed from their name). The same person always gets the same colour across sprints; any new team member is coloured automatically. No hardcoded names.
- **Dark/light theme toggle** with `localStorage` persistence (Maxxton design tokens).
- **Print-friendly CSS** — Ctrl+P exports as PDF.

---

## Step 0: Resolve sprint ID

Sprint URLs look like:
```
https://maxxton.atlassian.net/jira/software/c/projects/MXTS/boards/93/...?sprint=14783
```
Extract the number after `sprint=` — that is the sprint ID used in all subsequent steps.
If the user gives a sprint name instead (e.g. "Sprint 184"), search Jira first.

---

## Mode resolution

Decide depth and focus from the user's phrasing **before doing any Jira calls**, since depth
affects which fields to fetch.

**Depth** — how much to compute and render:

| Depth      | Triggers                                                      | Output                                                     |
|------------|---------------------------------------------------------------|------------------------------------------------------------|
| `quick`    | "quick", "summary", "tldr", "overview", "how did we do?"      | KPI text in-chat only, no HTML                             |
| `standard` | "standard", or any named focus area without a depth qualifier | All health/workload/retro sections, no daily timeline      |
| `full`     | "full", "everything", "deep dive", or no qualifier at all     | All sections including daily burn and interactive heatmaps |

**Focus** — which lens to apply:

| Focus      | Triggers                                                                 |
|------------|--------------------------------------------------------------------------|
| `health`   | "how did we go?", "velocity", "completion rate", "overrun", "burndown"   |
| `workload` | "who was overloaded?", "team capacity", "per person", "individual hours" |
| `timeline` | "when was work done?", "daily activity", "back-loading", "heatmap"       |
| `retro`    | "retro prep", "what went wrong?", "recommendations", "improvement"       |

**Examples:**
- "Full sprint health dashboard for sprint 14783" → `depth=full, focus=all`
- "Retro prep for last sprint" → `depth=standard, focus=retro`
- "Quick overview — how did we do?" → `depth=quick, focus=health`
- "Who was overloaded in sprint 184?" → `depth=standard, focus=workload`
- "Show me the daily activity for this sprint" → `depth=full, focus=timeline`

---

## Steps

### 1. Resolve cloud ID

Call `mcp__claude_ai_Atlassian_MCP__getAccessibleAtlassianResources` and note the `id` UUID. Every subsequent Jira MCP
call requires this as `cloudId`. Cache it for the session.

> The Jira agile REST endpoint (`/rest/agile/1.0/sprint/<id>`) is not accessible through
> the Atlassian MCP. Skip it — sprint name, dates and state are auto-extracted from ticket
> data in step 4.

### 2. Fetch sprint tickets

Call `mcp__claude_ai_Atlassian_MCP__searchJiraIssuesUsingJql` with the sprint ID.

For `standard` / `full` depth:
```
jql:        sprint = <sprint_id> ORDER BY status ASC
fields:     summary, status, issuetype, assignee, priority,
            timeoriginalestimate, timespent, timeestimate,
            worklog, labels, resolution, created, updated,
            customfield_10016, customfield_10020, customfield_10028,
            customfield_10049
maxResults: 100
view:       full
```
Pass `view: "full"` — the default compact view drops `timeoriginalestimate`, `timespent` and
`worklog`, which leaves the script with zero hours. The full view returns custom fields under
`fields.customFields` (e.g. `{"Sprint": {"id": "customfield_10020", "value": [...]}}`) and wraps
the result in `{"data": {...}}`; `process_sprint.py` unwraps and flattens both, so pass the saved
file as-is.

`customfield_10049` (Maxxton Team) is fetched only at these depths — it feeds the Step 7
Confluence persistence step, which does not run for `quick`.

For `quick` depth, fetch only the fields you need:
```
fields: summary, status, issuetype, assignee,
        timeoriginalestimate, timespent, customfield_10016, customfield_10020
view:   full
```

Fetching fewer fields for quick mode roughly halves the response size and keeps the
interaction fast. The result will likely be saved to a file automatically (too large for
context) — note the file path for step 3.

### 3. Process metrics

Run `process_sprint.py` on the raw Jira result to compute all sprint metrics.

First, resolve a working Python 3 interpreter (handles macOS/Linux/Windows Git Bash):

```bash
resolve_python() {
  local _cand
  for _cand in python3 python "py -3"; do
    if $_cand -c 'import sys; sys.exit(0 if sys.version_info[0] == 3 else 1)' >/dev/null 2>&1; then
      printf '%s\n' "$_cand"; return 0
    fi
  done
  return 1
}
PY=$(resolve_python) || { echo "no Python 3 found (tried python3, python, py -3)" >&2; exit 1; }
read -r -a PY_CMD <<< "$PY"
```

Then run the script using `"${PY_CMD[@]}"` — do not use `python3` directly:

```bash
"${PY_CMD[@]}" ${CLAUDE_SKILL_DIR}/scripts/process_sprint.py \
  --input      <path_to_raw_jira_result> \
  --output     <outputs>/sprint<ID>_metrics.json \
  --sprint-id  <id> \
  --mode       <quick|health|retro|workload|timeline|full> \
  [--force]
```

The script:
- Auto-extracts sprint name, dates and state from `customfield_10020`, and uses those
  **official dates as the sprint window** (worklog-based inference is only a fallback)
- Counts a ticket as **carried over, not done**, when its `customfield_10020` also lists a sprint
  that started after this one. Jira moves unfinished issues to the next sprint on close, so this
  is the reliable "done at sprint close" signal — today's status is not (a ticket finished two
  sprints later shows as done). The ticket's status becomes `Carried over`; its real status is kept
  in `currentStatus`, and reopened detection still uses it. Count is in `metrics.carriedOverCount`.
- Credits **app-synced worklogs** (author `accountType == "app"`, e.g. *Timesheets by Tempo*) to
  the ticket assignee. Tempo stores the real author in its own backend, never in Jira, so without
  this every Tempo hour lands on one fake "Tempo" user. Hours affected: `metrics.appAttributedH`.
- Auto-detects story points (`customfield_10016` / `customfield_10028`) vs hours
- Flags scope creep (tickets created after sprint start)
- Flags quality signals (reopened, blocked, chronic carry-over tickets)
- At `standard`/`full` depth, resolves the sprint's Maxxton Team by majority vote of
  `customfield_10049.id` against `references/team-ids.json`, writing `metrics.team =
  {"id", "name"}`. If no ticket has the field, or the majority ID isn't in the table,
  writes `metrics.team = null` and a `metrics.teamWarning` explaining why — never a
  default/guessed team. See Step 7.
- Caches metrics for completed sprints — skips re-processing if the file already exists
  and the sprint has ended. Pass `--force` to override.

Watch the output for the `⚠ Paginated:` line — if it appears, proceed to step 4.
Otherwise jump to step 5.

### 4. Patch paginated worklogs (only when flagged — never skip when flagged)

Jira caps worklogs at 20 entries per ticket in bulk search results. High-activity tickets
(long-running carry-overs, busy engineers) hit this cap regularly. Without patching, the
daily burn charts will show incomplete data for those tickets.

When `process_sprint.py` prints `⚠ Paginated:`, it also writes the affected
ticket keys to `metrics.paginatedTickets`. Fetch each one individually:

#### 4a. Fetch full worklogs per ticket

Page each ticket's worklogs directly — a single-issue `getJiraIssue` fetch is capped at 20
entries too, so it rarely helps:

```
Tool:           mcp__claude_ai_Atlassian_MCP__executeRead
cloudId:        <id>
name:           listJiraIssueWorklogs
inputs:         {"issueIdOrKey": "<TICKET-KEY>", "startAt": 0, "maxResults": 100}
responseFields: ["total", "worklogs.id", "worklogs.started", "worklogs.timeSpentSeconds",
                 "worklogs.author.displayName", "worklogs.author.accountType"]
```

The response is `{"data": {"total": N, "worklogs": [...]}}`. If `total` exceeds the entries
returned, repeat with the next `startAt`. Keep `id` (deduplication against the bulk result) and
`author.accountType` (Tempo attribution). Save the merged entries as
`{"key": "<KEY>", "fields": {"worklog": {"total": N, "worklogs": [...]}}}` — the shape
`build_wl_patches.py` reads.

Fetch all paginated tickets in a single message so they run in parallel. The
`listJiraIssueWorklogs` response carries no issue key, so save each result under the key you
requested it for, and check that its `total` matches that ticket's `wlTotal` in the metrics JSON.
On a mismatch, re-fetch that ticket on its own before proceeding to 4b.

> **Gotcha — persisted-output format**: When a result is too large for context, the MCP
> saves it as a JSON file wrapping the content:
> `[{"type": "text", "text": "<actual json string>"}]`
> `build_wl_patches.py` handles this automatically — just pass the saved file path as-is.

#### 4b. Build the patches file

Pass all saved ticket result files to `build_wl_patches.py`:

```bash
"${PY_CMD[@]}" ${CLAUDE_SKILL_DIR}/scripts/build_wl_patches.py \
  --ticket-files <TICKET1_file> <TICKET2_file> ... \
  --output       <outputs>/sprint<ID>_wl_patches.json
```

#### 4c. Apply patches and recompute

```bash
"${PY_CMD[@]}" ${CLAUDE_SKILL_DIR}/scripts/patch_worklogs.py \
  --metrics <outputs>/sprint<ID>_metrics.json \
  --patches <outputs>/sprint<ID>_wl_patches.json \
  --output  <outputs>/sprint<ID>_metrics.json
```

After patching, `patch_worklogs.py` prints any tickets still short of their true total
(capped even on the individual fetch — page them with `listJiraIssueWorklogs`, see 4a) and leaves those keys in
`paginatedTickets` rather than clearing them; daily arrays reflect whatever worklog history
could be recovered within the sprint window.

### 5. Generate output

**For `quick` depth** — print the KPI summary directly in chat:

```
Sprint <name> -- Quick Summary
================================
Completed:    25 / 32 tickets (78.1%)
Hours:        438.9h committed -> 680.8h logged (+55%)
Velocity:     78.1%
Spillover:    7 tickets
Untouched:    2 tickets (0h logged)
Worst ticket: MXTS-71637 -- 43.5h vs 8h estimate (431% of est)
```
If story points: replace the Hours line with `Points: 42 committed -> 33 completed (79%)`.

**For `standard` / `full` depth** — build the HTML dashboard:

```bash
"${PY_CMD[@]}" ${CLAUDE_SKILL_DIR}/scripts/build_dashboard.py \
  --metrics <outputs>/sprint<ID>_metrics.json \
  --depth   <standard|full> \
  --focus   <health,workload,timeline,retro> \
  --output  <outputs>/sprint<ID>_dashboard.html
```

The HTML file requires an internet connection to load Chart.js from
`cdnjs.cloudflare.com`. All other content (CSS, data, JS logic) is inlined —
the file is otherwise self-contained. Interactive filters work on heatmaps and
the full ticket list; Ctrl+P exports a print-friendly PDF.

### 6. Deliver

Share the dashboard via `computer://` link. Follow with 2-3 key findings relevant to the
active focus — for example, the top overloaded person for `workload`, or the worst-overrun
ticket for `retro`. Keep findings specific and data-backed (use numbers from the metrics).

Always state the two data adjustments when they apply, so the numbers are not misread:
- `metrics.carriedOverCount > 0` — "N tickets moved to a later sprint are counted as not done at
  sprint close."
- `metrics.appAttributedH > 0` — "Tempo-synced hours are credited to each ticket's assignee;
  Jira does not store who logged them."

### 7. Persist to Confluence (`standard` / `full` depth only — skip entirely for `quick`)

After delivering the dashboard, also append this sprint's key stats to the team's dedicated
Confluence page so history accumulates across sprints. Team pages live under
[`Q3 - 2026`](https://maxxton.atlassian.net/wiki/spaces/DEV/pages/3097919490/Q3+-+2026)
(space `DEV`, page ID `3097919490`).

1. **Check the team resolved.** If `metrics.team` is `null`, stop here — report
   `metrics.teamWarning` to the user as a clear error. Never create or write to a page when
   the team is unresolved (no default/fallback page).
2. **Look for the team's existing page:**
   ```
   Tool: mcp__claude_ai_Atlassian_MCP__searchConfluence
   cql: space = "DEV" AND ancestor = 3097919490 AND title = "<Team Name> Sprint Health"
   ```
   Use the exact team name from `metrics.team.name` — the title format is fixed, so this is
   an exact match, not a broad search.
3. **Build the new row** from `metrics.json` — one `<tr>` with: sprint name + dates, health
   score and letter grade, the 5 dimension scores (Delivery/Estimation/Scope/Quality/Focus),
   velocity ratio, and completed/committed counts.
4. **Confirm before writing.** Show the user the resolved target — the existing page's link,
   or "will create `<Team Name> Sprint Health` under Q3 - 2026" — plus the row about to be
   added. Proceed only on explicit go-ahead; this is a write to shared content.
5. **Found** → `mcp__claude_ai_Atlassian_MCP__getConfluenceContent` (`content_format: html`, `detail: full`) to
   capture the body and version, insert the new `<tr>` immediately before `</tbody>` (leave
   every prior row untouched), then `mcp__claude_ai_Atlassian_MCP__updateConfluenceContent` with the
   modified body as `{format: html, value}` (version auto-increments).
6. **Not found** → build the initial page: title `<Team Name> Sprint Health`, a short intro
   paragraph, and an HTML `<table>` with a header row (columns below) and the new sprint as
   the first body row. Call `mcp__claude_ai_Atlassian_MCP__executeRead` (find an unknown operation name first with `mcp__claude_ai_Atlassian_MCP__discover`) with `name: getContentFormatGuide` (inputs `{toolName: "createConfluenceContent"}`) first, then `mcp__claude_ai_Atlassian_MCP__createConfluenceContent` with body `{format: html, value}`, `spaceId: "DEV"`,
   `parentId: "3097919490"`.
7. Report the page link back to the user.

Table columns: `Sprint | Dates | Health Score (Grade) | Delivery | Estimation | Scope |
Quality | Focus | Velocity | Completed/Committed`.

---

## Examples

User says: "Sprint health for sprint 14783"
→ Fetches tickets, builds full HTML dashboard, shares via `computer://` link.

User says: "Quick overview — how did the team do?"
→ Prints KPI summary in chat (quick depth), no HTML file generated.

User says: "Retro prep for https://maxxton.atlassian.net/...?sprint=14783"
→ Standard depth, retro focus, HTML dashboard with recommendations and worst-ticket breakdown.

User says: "Full sprint health dashboard for sprint 14783" (team's first-ever run)
→ Fetches tickets, builds full HTML dashboard, resolves the team from `customfield_10049`,
confirms with the user, then creates `Reservations/CCM/NM Sprint Health` under Q3 - 2026 with
this sprint as the first row.

User says: "Sprint health for sprint 14820" (same team, later sprint)
→ Same as above, but the team page already exists — confirms with the user, then appends a
second row to the existing table without touching the first.

## Troubleshooting

- **Paginated worklogs warning not resolved**: ensure you ran steps 4a–4c for every key listed in `paginatedTickets`. If a ticket still remains after 4c, check `patch_worklogs.py`'s "Still capped after patching" message — its true worklog count exceeds what a single-issue fetch can return — page that ticket with `listJiraIssueWorklogs` (see 4a).
- **Completion looks too high for an old sprint**: the raw input was probably not flattened —
  check that `customfield_10020` reached the script (fetch with `view: "full"`). Without the
  Sprint field, carry-over detection cannot run and today's statuses are used.
- **A "Timesheets by Tempo" user appears in workload**: the worklog `author.accountType` was
  dropped — include it in `responseFields` when paging worklogs (step 4a).
- **Numbers differ from an earlier run of the same closed sprint**: the old metrics file is
  cached — re-run `process_sprint.py` with `--force` to apply the carry-over and Tempo rules.
- **Script not found**: confirm `${CLAUDE_SKILL_DIR}` resolves to the correct plugin path where `scripts/` lives.
- **Blank dashboard sections**: check that `--focus` matches the depth mode (timeline sections only render at `full` depth or with explicit `timeline` focus).
- **Maxxton Team unresolved**: check `metrics.teamWarning` — either no ticket in the sprint has `customfield_10049` set, or its ID isn't in `references/team-ids.json` (new/renamed team — update the table). Never falls back to a default page.

## References

- `references/token-costs.md` — token cost estimates by mode + recommended defaults
- `references/team-ids.json` — canonical Maxxton Team ID→name table, used by
  `process_sprint.py` to resolve `customfield_10049` for Step 7. Copied from
  `creating-jira-tickets`' "All Teams" table (global plugin) — keep in sync manually if that
  table changes; there is no cross-plugin shared-data mechanism in this repo.
