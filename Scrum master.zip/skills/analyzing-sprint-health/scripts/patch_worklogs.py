#!/usr/bin/env python3
"""
patch_worklogs.py — Backfill worklog entries for paginated tickets.

Jira returns at most 20 worklogs per ticket in a bulk search. For tickets
with more than 20 entries (e.g. long-running carry-overs), the coordinator
fetches additional pages via getJiraIssue and passes them here to patch
the metrics JSON with the complete worklog history.

Usage:
    python3 patch_worklogs.py \\
        --metrics  sprint<ID>_metrics.json \\
        --patches  sprint<ID>_wl_patches.json \\
        --output   sprint<ID>_metrics.json        (can overwrite in-place)

patches JSON schema (produced by the coordinator):
    {
      "MXTS-71637": [
        {"started": "2026-03-10T...", "timeSpentSeconds": 7200,
         "author": {"displayName": "Aditya Dongre"}},
        ...
      ],
      "MXTS-72341": [ ... ]
    }
"""

import argparse, json
from collections import defaultdict


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--metrics', required=True)
    parser.add_argument('--patches', required=True)
    parser.add_argument('--output',  required=True)
    args = parser.parse_args()

    with open(args.metrics) as f:
        metrics = json.load(f)
    with open(args.patches) as f:
        patches = json.load(f)   # dict: ticket_key → list of worklog entries

    # Index tickets for fast lookup
    ticket_index = {t['key']: t for t in metrics.get('tickets', [])}
    sprint_start = metrics.get('sprintWindow', {}).get('start', '')
    sprint_end   = metrics.get('sprintWindow', {}).get('end', '')

    def in_sprint(date):
        return bool(date) and sprint_start <= date <= sprint_end

    patched_keys = []
    app_added_h  = 0.0
    for key, new_worklogs in patches.items():
        if key not in ticket_index:
            print(f"  ⚠ {key} not found in metrics — skipping patch")
            continue

        t = ticket_index[key]

        # Build dedup set — prefer worklog id; fall back to (date, author, hours).
        # This correctly handles multiple entries by the same author on the same day.
        existing_keys: set = set()
        for wl in t.get('worklogs', []):
            if wl.get('id'):
                existing_keys.add(wl['id'])
            else:
                existing_keys.add((wl.get('date', ''), wl.get('author', ''), wl.get('hours', 0)))

        added = 0
        for wl in new_worklogs:
            wl_id   = wl.get('id', '')
            started = wl.get('started', '')
            date    = started[:10] if started else ''
            author_obj = wl.get('author') or {}
            is_app  = author_obj.get('accountType') == 'app'
            # App-synced worklogs (e.g. Tempo) carry the app account as author;
            # credit the ticket assignee, matching process_sprint.py.
            if is_app:
                author = t.get('assignee', 'Unassigned')
            else:
                author = author_obj.get('displayName', 'Unknown')
            secs    = wl.get('timeSpentSeconds', 0)
            hours   = round(secs / 3600, 2)

            dedup_key = wl_id if wl_id else (date, author, hours)
            if date and dedup_key not in existing_keys:
                t['worklogs'].append({
                    'id':    wl_id,
                    'date':  date,
                    'hours': hours,
                    'author': author,
                })
                existing_keys.add(dedup_key)
                added += 1
                if is_app:
                    app_added_h += secs / 3600

        if added:
            patched_keys.append(key)
            print(f"  ✓ {key}: added {added} worklog entries")

    # ── Detect tickets still short of their true total ───────────────────────
    # `wlTotal` was captured from the bulk search and reflects Jira's real worklog
    # count for the ticket regardless of fetch method. If a ticket's worklog list
    # is still shorter than that after patching, the individual getJiraIssue fetch
    # was itself capped (Jira's embedded worklog field has no pagination beyond a
    # fixed page size) — full history could not be recovered through this tool.
    still_incomplete_keys = set()
    still_incomplete_labels = []
    for key in patches:
        t = ticket_index.get(key)
        if t and len(t.get('worklogs', [])) < t.get('wlTotal', 0):
            still_incomplete_keys.add(key)
            still_incomplete_labels.append(f"{key} ({len(t['worklogs'])}/{t['wlTotal']})")
    if still_incomplete_labels:
        print(f"  ⚠ Still capped after patching — Jira's per-ticket worklog fetch also "
              f"has a page limit, full history unavailable via this tool: "
              f"{', '.join(still_incomplete_labels)}")

    if not patched_keys:
        print("  No new worklog entries added — patches already reflected in metrics.")
        with open(args.output, 'w') as f:
            json.dump(metrics, f, indent=2)
        return

    # Recompute daily arrays for patched tickets
    working_days = metrics.get('workingDays', [])
    day_set      = set(working_days)
    day_idx      = {d: i for i, d in enumerate(working_days)}  # O(1) lookups

    def recompute_daily(ticket):
        daily = [0.0] * len(working_days)
        for wl in ticket.get('worklogs', []):
            d = wl.get('date', '')
            if d in day_set:
                daily[day_idx[d]] = round(daily[day_idx[d]] + wl.get('hours', 0), 2)
        active = [i for i, h in enumerate(daily) if h > 0]
        ticket['dailyHours']  = daily
        ticket['sprintTotal'] = round(sum(daily), 1)
        ticket['firstDayIdx'] = active[0]  if active else None
        ticket['lastDayIdx']  = active[-1] if active else None

    for key in patched_keys:
        recompute_daily(ticket_index[key])

    # Recompute team-level daily totals and user daily arrays
    user_daily = defaultdict(lambda: [0.0] * len(working_days))
    total_daily = [0.0] * len(working_days)

    for t in metrics.get('tickets', []):
        for i, h in enumerate(t.get('dailyHours', [])):
            if i < len(working_days):
                total_daily[i] = round(total_daily[i] + h, 2)

    for t in metrics.get('tickets', []):
        for wl in t.get('worklogs', []):
            d = wl.get('date', '')
            if d in day_set:
                idx = day_idx[d]
                user_daily[wl['author']][idx] = round(
                    user_daily[wl['author']][idx] + wl.get('hours', 0), 2)

    metrics['dailyTotals']    = [round(h, 2) for h in total_daily]
    metrics['userDailyArrays'] = {u: v for u, v in user_daily.items()}

    # Recompute cumulative
    running, cum = 0, []
    for h in total_daily:
        running += h
        cum.append(round(running, 2))
    metrics['cumulative'] = cum

    # Recompute per-user logged hours over all worklogs (any date), matching
    # process_sprint.py — patched entries can add hours or a new author.
    user_logged = defaultdict(float)
    for t in metrics.get('tickets', []):
        for wl in t.get('worklogs', []):
            user_logged[wl['author']] += wl.get('hours', 0)
    per_user = metrics.setdefault('perUser', {})
    for u in user_logged:
        per_user.setdefault(u, {'origEstH': 0, 'timeSpentH': 0, 'loggedH': 0, 'tickets': 0})
    for u, row in per_user.items():
        row['loggedH'] = round(user_logged.get(u, 0), 2)
    metrics['allUsers'] = sorted(per_user)
    metrics['appAttributedH'] = round(metrics.get('appAttributedH', 0) + app_added_h, 1)

    # Remove patched tickets from paginatedTickets list — but only ones now
    # confirmed complete; still-capped tickets stay flagged rather than being
    # silently marked resolved.
    metrics['paginatedTickets'] = [k for k in metrics.get('paginatedTickets', [])
                                   if k not in patched_keys or k in still_incomplete_keys]

    with open(args.output, 'w') as f:
        json.dump(metrics, f, indent=2)

    print(f"✓ Patched {len(patched_keys)} ticket(s). "
          f"Remaining paginated: {metrics['paginatedTickets'] or 'none'}")
    print(f"✓ Saved to {args.output}")


if __name__ == '__main__':
    main()
