#!/usr/bin/env python3
"""
build_dashboard.py — Sprint Health Dashboard HTML generator.

Reads sprint_metrics.json (produced by process_sprint.py) and writes a
self-contained HTML file. All Chart.js charts, heatmaps and tables are
generated here — Claude never needs to write HTML output.

Usage:
    python3 build_dashboard.py \\
        --metrics sprint_metrics.json \\
        --output sprint185_full.html \\
        [--depth  quick|standard|full]   (default: full) \\
        [--focus  health,workload,timeline,retro]  (default: all)
"""

import argparse, json, hashlib
from collections import defaultdict

# ── Colour palette ────────────────────────────────────────────────────────────
PALETTE = dict(
    bg='#0f1117', card='#1a1d27', border='#2e3250', text='#e2e8f0',
    muted='#8892a4', accent='#6366f1', green='#22c55e', yellow='#f59e0b',
    red='#ef4444', orange='#f97316', blue='#3b82f6', purple='#a855f7',
    teal='#14b8a6',
)

# Visually distinct, accessible colour palette used for dynamic user assignment.
# Colours are assigned deterministically by hashing the user's name, so the same
# person always gets the same colour across sprints and teams.
USER_COLOR_PALETTE = [
    '#6366f1',  # indigo
    '#ef4444',  # red
    '#22c55e',  # green
    '#f59e0b',  # amber
    '#3b82f6',  # blue
    '#a855f7',  # purple
    '#14b8a6',  # teal
    '#f97316',  # orange
    '#0ea5e9',  # sky
    '#dc2626',  # dark red
    '#ec4899',  # pink
    '#84cc16',  # lime
    '#06b6d4',  # cyan
    '#8b5cf6',  # violet
    '#d97706',  # dark amber
    '#10b981',  # emerald
]

STATUS_COLORS = {
    'Checked by QA': '#22c55e', 'Cannot Test': '#14b8a6',
    'Closed':        '#6366f1', 'Resolved':    '#818cf8',
    'Testing':       '#3b82f6', 'In Progress': '#f59e0b',
    'Reopened':      '#ef4444', 'Open':        '#dc2626',
    'Done':          '#22c55e', 'Carried over': '#a855f7',
}

EST_COLORS = {
    'underestimated': '#ef4444',
    'overestimated':  '#3b82f6',
    'accurate':       '#22c55e',
    'untouched':      '#dc2626',
    'no_estimate':    '#8892a4',
}


def user_color(name: str) -> str:
    """Return a deterministic, visually distinct colour for any user name."""
    idx = int(hashlib.md5(name.encode()).hexdigest(), 16) % len(USER_COLOR_PALETTE)
    return USER_COLOR_PALETTE[idx]


def status_color(status: str) -> str:
    return STATUS_COLORS.get(status, '#8892a4')


def h(s) -> str:
    """HTML-escape."""
    return str(s).replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;').replace('"', '&quot;')


def hex_alpha(hex_color: str, alpha: float) -> str:
    hx = hex_color.lstrip('#')
    r, g, b = int(hx[0:2],16), int(hx[2:4],16), int(hx[4:6],16)
    return f'rgba({r},{g},{b},{alpha})'


# ── Section resolver ──────────────────────────────────────────────────────────
SECTION_ORDER = [
    'header', 'kpi', 'health_score', 'recommendations',
    'committed_completed', 'per_user_chart',
    'velocity_spillover',
    'estimation_accuracy', 'over_underest',
    'per_user_table',
    'quality_signals', 'scope_creep', 'next_sprint_forecast',
    'worst_tickets', 'full_ticket_list',
    'timeline_header', 'daily_burn', 'person_heatmap', 'ticket_heatmap',
]


def resolve_sections(depth: str, focus: list) -> list:
    all_foci = not focus or set(focus) >= {'health', 'workload', 'timeline', 'retro'}
    has = lambda f: all_foci or f in focus

    secs = ['header', 'kpi']

    if depth == 'quick':
        secs.append('text_summary')
        return secs

    secs.append('health_score')     # always shown in std/full
    secs.append('recommendations')  # always shown in std/full

    if has('health'):
        secs += ['committed_completed', 'velocity_spillover', 'estimation_accuracy', 'over_underest',
                 'quality_signals', 'scope_creep']
    if has('health') or has('retro'):
        secs += ['next_sprint_forecast']
    if has('workload'):
        secs += ['per_user_chart', 'per_user_table']
    if has('retro'):
        secs += ['estimation_accuracy', 'over_underest', 'worst_tickets', 'full_ticket_list']

    # Timeline only for full depth OR explicit timeline focus request
    if depth == 'full' or 'timeline' in focus:
        secs += ['timeline_header', 'daily_burn', 'person_heatmap', 'ticket_heatmap']

    # Preserve logical order, deduplicate
    seen, ordered = set(), []
    for s in SECTION_ORDER:
        if s in secs and s not in seen:
            ordered.append(s)
            seen.add(s)
    return ordered


# ── CSS ───────────────────────────────────────────────────────────────────────
CSS = """
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:'Segoe UI',-apple-system,sans-serif;background:#0f1117;color:#e2e8f0;padding:24px;min-height:100vh}
.hdr{display:flex;align-items:flex-start;justify-content:space-between;margin-bottom:24px;flex-wrap:wrap;gap:12px}
.hdr h1{font-size:1.8rem;font-weight:700;background:linear-gradient(135deg,#6366f1,#a855f7);-webkit-background-clip:text;-webkit-text-fill-color:transparent}
.hdr p{color:#8892a4;font-size:.85rem;margin-top:4px}
.jira-btn{background:#6366f1;color:#fff;border-radius:8px;padding:9px 16px;font-size:.82rem;font-weight:600;text-decoration:none;display:inline-block}
.goal{background:linear-gradient(135deg,#1e1b4b,#1e293b);border:1px solid #3730a3;border-left:4px solid #6366f1;border-radius:10px;padding:14px 18px;margin-bottom:22px;font-size:.9rem}
.goal .lbl{color:#6366f1;font-weight:600;font-size:.72rem;letter-spacing:1px;text-transform:uppercase;margin-bottom:6px}
.kpi-row{display:grid;grid-template-columns:repeat(auto-fit,minmax(155px,1fr));gap:14px;margin-bottom:22px;align-items:stretch}
.kpi{background:#1a1d27;border:1px solid #2e3250;border-radius:12px;padding:16px 18px;position:relative;overflow:hidden}
.kpi::before{content:'';position:absolute;top:0;left:0;right:0;height:3px}
.kpi.c-green::before{background:#22c55e}.kpi.c-red::before{background:#ef4444}
.kpi.c-yellow::before{background:#f59e0b}.kpi.c-blue::before{background:#3b82f6}
.kpi.c-purple::before{background:#a855f7}.kpi.c-orange::before{background:#f97316}
.kpi.c-teal::before{background:#14b8a6}
.kpi .val{font-size:2rem;font-weight:700;line-height:1;margin-bottom:4px}
.kpi.c-green .val{color:#22c55e}.kpi.c-red .val{color:#ef4444}.kpi.c-yellow .val{color:#f59e0b}
.kpi.c-blue .val{color:#3b82f6}.kpi.c-purple .val{color:#a855f7}.kpi.c-orange .val{color:#f97316}
.kpi.c-teal .val{color:#14b8a6}
.kpi .lbl{color:#8892a4;font-size:.72rem;font-weight:500;text-transform:uppercase;letter-spacing:.5px}
.kpi .sub{color:#8892a4;font-size:.78rem;margin-top:4px}
.g2{display:grid;grid-template-columns:1fr 1fr;gap:18px;margin-bottom:18px;align-items:stretch}
.g3{display:grid;grid-template-columns:1fr 1fr 1fr;gap:18px;margin-bottom:18px;align-items:stretch}
.gf{margin-bottom:18px}
.card{background:#1a1d27;border:1px solid #2e3250;border-radius:12px;padding:18px}
.card>.g2,.card>.g3{margin-bottom:0}
.stitle{font-size:1.05rem;font-weight:600;color:#e2e8f0;margin-bottom:14px;display:flex;align-items:center;gap:8px}
.chart-wrap{position:relative}
.donut-row{display:flex;gap:16px;align-items:flex-start}
.donut-wrap{flex:0 0 auto;width:190px;height:190px;position:relative}
.pb-wrap{margin-bottom:8px}
.pb-label{display:flex;justify-content:space-between;font-size:.78rem;margin-bottom:3px;color:#8892a4}
.pb-label strong{color:#e2e8f0}
.pb-bg{background:#2e3250;border-radius:5px;overflow:hidden}
.pb-fill{border-radius:5px;transition:width .5s ease}
table{width:100%;border-collapse:collapse;font-size:.82rem}
th{color:#8892a4;font-weight:600;text-align:left;padding:8px 10px;border-bottom:1px solid #2e3250;font-size:.72rem;text-transform:uppercase;letter-spacing:.5px}
td{padding:9px 10px;border-bottom:1px solid #1e2235;vertical-align:middle}
tr:last-child td{border-bottom:none}
tr:hover td{background:rgba(99,102,241,.05)}
.badge{display:inline-block;padding:2px 8px;border-radius:20px;font-size:.72rem;font-weight:600}
.tk{color:#6366f1;font-weight:600;font-size:.8rem;white-space:nowrap}
.tk a{color:inherit;text-decoration:none}.tk a:hover{text-decoration:underline}
.chip{display:inline-block;padding:2px 7px;border-radius:12px;font-size:.72rem;font-weight:700;min-width:44px;text-align:center}
.avatar{width:28px;height:28px;border-radius:50%;display:inline-flex;align-items:center;justify-content:center;font-size:.68rem;font-weight:700;color:#fff;margin-right:6px;flex-shrink:0}
.ucell{display:flex;align-items:center}
.ibar{display:flex;align-items:center;gap:8px}
.ibar-bg{flex:1;background:#2e3250;border-radius:4px;height:8px;overflow:hidden;min-width:60px}
.ibar-fill{height:100%;border-radius:4px}
.alert-box{background:rgba(239,68,68,.07);border:1px solid rgba(239,68,68,.3);border-left:3px solid #ef4444;border-radius:8px;padding:12px 14px;margin-bottom:10px;font-size:.83rem}
.alert-box .ah{font-weight:600;color:#ef4444;margin-bottom:4px}
.warn-box{background:rgba(245,158,11,.07);border:1px solid rgba(245,158,11,.3);border-left:3px solid #f59e0b;border-radius:8px;padding:12px 14px;margin-bottom:10px;font-size:.83rem}
.warn-box .wh{font-weight:600;color:#f59e0b;margin-bottom:4px}
.divider{border:none;border-top:2px solid #2e3250;margin:28px 0 22px}
.filter-bar{display:flex;align-items:center;gap:10px;margin-bottom:12px;flex-wrap:wrap}
.filter-select{background:#1f2235;border:1px solid #2e3250;border-radius:6px;color:#e2e8f0;
  padding:5px 10px;font-size:.8rem;cursor:pointer;outline:none}
.filter-select:focus{border-color:#6366f1}
.filter-reset{background:none;border:1px solid #2e3250;border-radius:6px;color:#8892a4;
  padding:5px 10px;font-size:.78rem;cursor:pointer}
.filter-reset:hover{border-color:#6366f1;color:#e2e8f0}
.hs-dim{margin-bottom:11px}.hs-dim:last-child{margin-bottom:0}
.hs-hd{display:flex;justify-content:space-between;align-items:baseline;margin-bottom:4px}
.hs-lbl{font-size:.82rem;font-weight:500;color:#e2e8f0}
.hs-wt{display:inline-block;font-size:.63rem;color:#8892a4;background:#2e3250;border-radius:3px;padding:1px 5px;margin-left:5px;vertical-align:middle}
.hs-score{font-size:.82rem;font-weight:700}
.hs-max{font-size:.7rem;font-weight:400;color:#8892a4}
.hs-bar-bg{background:#2e3250;border-radius:999px;height:8px;overflow:hidden;margin-bottom:3px}
.hs-bar{height:8px;border-radius:999px;width:0;transition:width 1.3s cubic-bezier(.4,0,.2,1)}
.hs-formula{font-size:.68rem;color:#8892a4;font-family:monospace}
.ftl-chip{display:inline-flex;align-items:center;padding:3px 10px;border-radius:999px;border:1.5px solid #2e3250;background:#1a1d2e;color:#8892a4;font-size:.73rem;cursor:pointer;user-select:none;transition:background .15s,border-color .15s,color .15s;white-space:nowrap}
.ftl-chip:hover{border-color:#6366f1;color:#e2e8f0}
.ftl-chip.active{background:#6366f1;border-color:#6366f1;color:#fff;font-weight:600}
.tl-intro{font-size:.83rem;color:#8892a4;margin-bottom:18px}
.paginated-note{background:rgba(239,68,68,.1);border:1px solid rgba(239,68,68,.25);border-radius:8px;padding:8px 12px;font-size:.78rem;color:#fca5a5;display:inline-block;margin-left:12px}
@media(max-width:900px){.g2,.g3{grid-template-columns:1fr}}
@media print{
  body{background:#fff;color:#000;padding:12px}
  .card{border:1px solid #ccc;background:#fff;break-inside:avoid;margin-bottom:12px}
  .kpi{background:#f9f9f9;border:1px solid #ddd}
  .kpi .val,.kpi .lbl,.kpi .sub{color:#000 !important}
  .stitle{color:#000}
  th{color:#666}
  td{color:#111;border-color:#ddd}
  .hdr h1{-webkit-text-fill-color:#333;background:none;color:#333}
  .jira-btn{display:none}
  .chart-wrap{break-inside:avoid}
}

/* ── Theme toggle ─────────────────────────────────────────────────────── */
.theme-btn{background:#1f2235;border:1px solid #2e3250;border-radius:8px;color:#8892a4;
  padding:9px 14px;font-size:.82rem;font-weight:500;cursor:pointer;white-space:nowrap}
.theme-btn:hover{border-color:#6366f1;color:#e2e8f0}
.hdr-actions{display:flex;align-items:center;gap:8px;flex-shrink:0}

/* ── Light theme ─────────────────────────────────────────────────────── */
body.light{background:#f0f2f9;color:#1e2235}
body.light .hdr h1{background:linear-gradient(135deg,#4f46e5,#7c3aed);-webkit-background-clip:text;-webkit-text-fill-color:transparent}
body.light .hdr p{color:#4b5675}
body.light .card{background:#ffffff;border-color:#d4d9ec}
body.light .kpi{background:#ffffff;border-color:#d4d9ec}
body.light .kpi .lbl{color:#4b5675}
body.light .kpi .sub{color:#4b5675}
body.light .stitle{color:#1e2235}
body.light .goal{background:linear-gradient(135deg,#eef0f9,#f0f4ff);border-color:#a5b4fc}
body.light .goal .lbl{color:#4f46e5}
body.light th{color:#4b5675;border-color:#d4d9ec}
body.light td{border-color:#e8ecf7}
body.light tr:hover td{background:rgba(99,102,241,.05)}
body.light .pb-bg{background:#d4d9ec}
body.light .hs-bar-bg{background:#d4d9ec}
body.light .hs-wt{background:#d4d9ec;color:#4b5675}
body.light .hs-lbl{color:#1e2235}
body.light .hs-formula{color:#4b5675}
body.light .hs-ring-track{stroke:#d4d9ec}
body.light .hs-calc-box{background:#eef0f9!important;color:#4b5675!important}
body.light .rec-title{color:#1e2235!important}
body.light .rec-evidence{color:#5a6480!important}
body.light .rec-action{color:#374161!important}
body.light .tl-intro{color:#4b5675}
body.light .filter-select{background:#f7f8fc;border-color:#d4d9ec;color:#1e2235}
body.light .filter-reset{border-color:#d4d9ec;color:#4b5675}
body.light .filter-reset:hover{border-color:#6366f1;color:#1e2235}
body.light .ftl-chip{background:#f0f2f9;border-color:#d4d9ec;color:#4b5675}
body.light .ftl-chip:hover{border-color:#6366f1;color:#1e2235}
body.light .ftl-chip.active{background:#6366f1;border-color:#6366f1;color:#fff}
body.light .divider{border-color:#d4d9ec}
body.light .theme-btn{background:#f0f2f9;border-color:#d4d9ec;color:#4b5675}
body.light .theme-btn:hover{border-color:#6366f1;color:#1e2235}
body.light [style*="color:#8892a4"]{color:#4b5675!important}
body.light [style*="color:#c4c9d4"]{color:#374161!important}
body.light [style*="color:#e2e8f0"]{color:#1e2235!important}
body.light [style*="background:#1a1d27"]{background:#ffffff!important}
body.light [style*="background:#1a1d2e"]{background:#eef0f9!important}
body.light [style*="background:#2e3250"]{background:#dde1ee!important}
body.light [style*="background:#1f2235"]{background:#eef0f9!important}
body.light [style*="border-color:#2e3250"]{border-color:#d4d9ec!important}
body.light [style*="border:1px solid #2e3250"]{border-color:#d4d9ec!important}
"""


# ── Builder class ─────────────────────────────────────────────────────────────
class DashboardBuilder:
    def __init__(self, m: dict, depth: str, focus: list, compare: dict = None):
        self.m = m
        self.depth = depth
        self.focus = focus
        self.compare = compare or {}
        self._js: list = []
        self._cid = 0

    def cid(self, name: str) -> str:
        self._cid += 1
        return f'{name}_{self._cid}'

    def js(self, code: str):
        self._js.append(code)

    # ── Page wrapper ───────────────────────────────────────────────────────
    def build(self) -> str:
        sections = resolve_sections(self.depth, self.focus)
        body_parts = []
        for sec in sections:
            fn = getattr(self, f'_sec_{sec}', None)
            if fn:
                body_parts.append(fn())

        mode_label = self.depth
        if self.focus:
            mode_label += f' ({",".join(self.focus)})'

        js_block = '\n'.join(self._js)
        theme_js = """
function toggleTheme(){
  var isDark = !document.body.classList.contains('light');
  document.body.classList.toggle('light', isDark);
  var btn = document.getElementById('themeToggleBtn');
  if(btn) btn.textContent = isDark ? '☀ Light' : '🌙 Dark';
  try{ localStorage.setItem('sprint_theme', isDark ? 'light' : 'dark'); }catch(e){}
}
(function(){
  var saved;
  try{ saved = localStorage.getItem('sprint_theme'); }catch(e){}
  if(saved === 'light'){
    document.body.classList.add('light');
    var btn = document.getElementById('themeToggleBtn');
    if(btn) btn.textContent = '☀ Light';
  }
})();"""
        return f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Sprint {h(self.m['sprintId'])} — Health Dashboard</title>
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.1/chart.umd.min.js"></script>
<style>{CSS}</style>
</head>
<body>
{''.join(body_parts)}
<script>
{js_block}
{theme_js}
</script>
</body>
</html>"""

    # ── §1 Header ──────────────────────────────────────────────────────────
    def _sec_header(self) -> str:
        m = self.m
        sid = h(m['sprintId'])
        date = h(m.get('generatedAt', ''))
        sw   = m.get('sprintWindow', {})
        jira_url = f"https://maxxton.atlassian.net/jira/software/c/projects/MXTS/boards/93/reports/sprint-retrospective?sprint={sid}"
        meta      = m.get('sprintMeta', {})
        goal      = h(meta.get('goal', ''))
        sname     = h(meta.get('name', f'Sprint {sid}'))
        state     = meta.get('state', '')
        state_badge = ''
        if state == 'active':
            state_badge = '<span style="background:rgba(34,197,94,.15);color:#22c55e;font-size:.72rem;font-weight:600;padding:2px 8px;border-radius:12px;margin-left:8px">🟢 Active</span>'
        elif state == 'closed':
            state_badge = '<span style="background:rgba(99,102,241,.15);color:#818cf8;font-size:.72rem;font-weight:600;padding:2px 8px;border-radius:12px;margin-left:8px">✓ Closed</span>'
        goal_html = f'<div style="margin-top:8px;padding:10px 14px;background:rgba(99,102,241,.07);border:1px solid rgba(99,102,241,.2);border-left:3px solid #6366f1;border-radius:8px;font-size:.85rem;color:#c4c9d4"><strong style="color:#8892a4;font-size:.72rem;text-transform:uppercase;letter-spacing:.5px">Sprint Goal</strong><div style="margin-top:4px">{goal}</div></div>' if goal else ''
        # Prefer official dates from sprintMeta, fall back to inferred window
        start_date = h(meta.get('startDate') or sw.get('start', '?'))
        end_date   = h(meta.get('endDate')   or sw.get('end',   '?'))

        return f"""
<div class="hdr">
  <div>
    <h1>🚀 {sname} — Health Dashboard{state_badge}</h1>
    <p>Sprint ID {sid} · Generated {date}
       · {start_date} → {end_date}</p>
  </div>
  <div class="hdr-actions">
    <button class="theme-btn" id="themeToggleBtn" onclick="toggleTheme()">🌙 Dark</button>
    <a class="jira-btn" href="{jira_url}" target="_blank">Open in Jira ↗</a>
  </div>
</div>
{goal_html}"""

    # ── §2 KPI tiles ───────────────────────────────────────────────────────
    def _sec_kpi(self) -> str:
        s = self.m['summary']
        overrun_val = s.get('overrunPct')
        if overrun_val is None:
            overrun = '?%'
        elif overrun_val > 0:
            overrun = f'+{overrun_val}%'
        else:
            overrun = f'{overrun_val}%'
        tiles = [
            ('c-blue',   s['totalTickets'],       'Total Tickets',    'Committed to sprint'),
            ('c-green',  s['completedCount'],      'Completed',        f"{s['completionPct']}% completion rate"),
            ('c-yellow', s['spilloverCount'],      'Spillover / WIP',  f"{s['wipCount']} in-progress + {s['totalTickets']-s['completedCount']-s['wipCount']} open"),
            ('c-teal',   f"{s['totalOrigEstH']}h", 'Committed (Est.)', 'Original estimates'),
            ('c-orange', f"{s['totalLoggedH']}h",  'Time Logged',      overrun + ' over estimate'),
            ('c-red',    s['untouchedCount'],       'Untouched',        '0h logged, no progress'),
            ('c-purple', f"{round(s['velocityRatio']*100,1)}%", 'Velocity Ratio',   'Completed / Committed'),
        ]
        inner = ''.join(
            f'<div class="kpi {cls}"><div class="val">{h(val)}</div>'
            f'<div class="lbl">{h(lbl)}</div><div class="sub">{h(sub)}</div></div>'
            for cls, val, lbl, sub in tiles
        )
        return f'<div class="kpi-row">{inner}</div>\n'


    # ── §2b Sprint Health Score ────────────────────────────────────────────
    def _sec_health_score(self) -> str:
        """
        Compute a 5-dimension sprint health score (each dimension 0-100)
        and render an animated gauge + dimension bars.

        Dimensions (weights):
          D1 Delivery          30% — (done / committed) × 100
          D2 Estimation Acc.   20% — 100 − |overrun%|
          D3 Scope Discipline  15% — 100 − (scope_creep% × 2)
          D4 Quality           20% — 100 − ((reopened×3 + chronic×2 + blocked×5) / total × 100)
          D5 Focus             15% — 100 − (touched_spillover% × 3) − (untouched% × 5)
        """
        import math as _math
        s  = self.m['summary']
        qs = self.m.get('qualitySignals', {})
        sc = self.m.get('scopeCreep', {})
        total = s['totalTickets']

        d1 = round(s['completionPct'])
        d2 = max(0, round(100 - abs(s.get('overrunPct') or 0)))
        d3 = max(0, round(100 - sc.get('pctOfEst', 0) * 2))
        weighted_q = (len(qs.get('reopenedTickets', [])) * 3 +
                      len(qs.get('chronicTickets', [])) * 2 +
                      len(qs.get('blockedTickets', [])) * 5)
        d4 = max(0, round(100 - (weighted_q / max(total, 1)) * 100))
        # Use touched spillover (excludes untouched) to avoid double-counting:
        # untouched tickets are already penalised by the untouched_pct term.
        touched_spill_count = s.get('touchedSpilloverCount', s['spilloverCount'])
        spill_pct     = touched_spill_count / max(total, 1) * 100
        untouched_pct = s['untouchedCount'] / max(total, 1) * 100
        d5 = max(0, round(100 - spill_pct * 3 - untouched_pct * 5))

        overall = round(d1*0.30 + d2*0.20 + d3*0.15 + d4*0.20 + d5*0.15)

        def grade(sc_):
            if sc_ >= 80: return 'A', 'Excellent', '#22c55e'
            if sc_ >= 65: return 'B', 'Good',      '#6366f1'
            if sc_ >= 50: return 'C', 'Fair',      '#f59e0b'
            if sc_ >= 35: return 'D', 'Poor',      '#ef4444'
            return 'F', 'Critical', '#ef4444'

        letter, label, col = grade(overall)
        # circumference of r=62 ring = 2*pi*62 ≈ 389.56
        circ = 389.56
        ring_id = self.cid('hsRing')

        def dim_row(icon, name, weight, score, formula, bar_col):
            w_pct = score  # bar width = score itself (already 0-100)
            return (
                f'<div class="hs-dim">'
                f'<div class="hs-hd"><span class="hs-lbl">{icon} {name}'
                f'<span class="hs-wt">{weight}</span></span>'
                f'<span class="hs-score" style="color:{bar_col}">{score}'
                f'<span class="hs-max"> / 100</span></span></div>'
                f'<div class="hs-bar-bg"><div class="hs-bar" data-w="{w_pct}%" style="background:{bar_col}"></div></div>'
                f'<div class="hs-formula">{formula}</div>'
                f'</div>'
            )

        rows = (
            dim_row('🎯','Delivery','30%',    d1,
                f'(done ÷ committed) × 100 = ({s["completedCount"]} ÷ {total}) × 100 = {d1}',
                '#22c55e' if d1>=70 else '#f59e0b' if d1>=50 else '#ef4444'),
            dim_row('📐','Estimation Accuracy','20%', d2,
                f'100 − |overrun%| = 100 − {abs(s.get("overrunPct") or 0)} = {d2}',
                '#22c55e' if d2>=70 else '#f59e0b' if d2>=50 else '#ef4444'),
            dim_row('📏','Scope Discipline','15%', d3,
                f'100 − (scope_creep% × 2) = 100 − ({sc.get("pctOfEst",0):.1f} × 2) = {d3}',
                '#22c55e' if d3>=70 else '#f59e0b' if d3>=50 else '#ef4444'),
            dim_row('🔬','Quality','20%', d4,
                f'100 − ((reopened×3 + chronic×2 + blocked×5) ÷ total × 100) = {d4}',
                '#22c55e' if d4>=70 else '#f59e0b' if d4>=50 else '#ef4444'),
            dim_row('🎯','Focus','15%', d5,
                f'100 − (touched_spillover% × 3) − (untouched% × 5) = 100 − {spill_pct:.1f}×3 − {untouched_pct:.1f}×5 = {d5}',
                '#22c55e' if d5>=70 else '#f59e0b' if d5>=50 else '#ef4444'),
        )

        self.js(f"""
(function(){{
  function animHS(){{
    var ring=document.getElementById('{ring_id}');
    if(ring) setTimeout(function(){{ring.style.strokeDashoffset={circ}*(1-{overall}/100);}},150);
    document.querySelectorAll('.hs-bar').forEach(function(el){{
      var w=el.getAttribute('data-w');
      if(w) setTimeout(function(){{el.style.width=w;}},250);
    }});
  }}
  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',animHS);
  else setTimeout(animHS,60);
}})();""")

        calc = (f"({d1}×0.30) + ({d2}×0.20) + ({d3}×0.15) + ({d4}×0.20) + ({d5}×0.15) "
                f"= {d1*0.30:.1f}+{d2*0.20:.1f}+{d3*0.15:.2f}+{d4*0.20:.1f}+{d5*0.15:.2f} = {overall}")

        return f"""
<div style="margin-bottom:20px">
  <div style="font-size:1rem;font-weight:700;color:#e2e8f0;margin-bottom:10px;display:flex;align-items:center;gap:8px">
    <span>🏥</span> Sprint Health Score
    <span style="font-size:.72rem;font-weight:400;color:#8892a4">— 5 dimensions, each scored 0–100</span>
  </div>
  <div class="card" style="padding:20px">
    <div style="display:flex;gap:24px;align-items:flex-start;flex-wrap:wrap">
      <div style="flex-shrink:0;display:flex;flex-direction:column;align-items:center;gap:12px">
        <div style="position:relative;width:150px;height:150px">
          <svg viewBox="0 0 150 150" width="150" height="150" style="transform:rotate(-90deg)">
            <circle class="hs-ring-track" cx="75" cy="75" r="62" fill="none" stroke="#2e3250" stroke-width="12"/>
            <circle id="{ring_id}" cx="75" cy="75" r="62" fill="none" stroke="{col}" stroke-width="12"
              stroke-dasharray="{circ:.2f}" stroke-dashoffset="{circ:.2f}" stroke-linecap="round"
              style="transition:stroke-dashoffset 1.5s cubic-bezier(.4,0,.2,1)"/>
          </svg>
          <div style="position:absolute;inset:0;display:flex;flex-direction:column;align-items:center;justify-content:center">
            <span style="font-size:2.5rem;font-weight:900;color:{col};line-height:1">{overall}</span>
            <span style="font-size:.68rem;color:#8892a4">/&nbsp;100</span>
          </div>
        </div>
        <div style="display:flex;align-items:center;gap:8px">
          <span style="font-size:2.8rem;font-weight:900;color:{col};line-height:1">{letter}</span>
          <div><div style="font-size:1rem;font-weight:700;color:{col}">{label}</div>
          <div style="font-size:.72rem;color:#8892a4">Sprint {h(self.m['sprintId'])}</div></div>
        </div>
        <div style="font-size:.68rem;color:#8892a4;text-align:center;line-height:1.6">
          Weights: 30% · 20% · 15% · 20% · 15%
        </div>
      </div>
      <div style="flex:1;min-width:260px">
        <div style="font-size:.7rem;font-weight:700;text-transform:uppercase;letter-spacing:.06em;color:#8892a4;margin-bottom:12px">Score Breakdown</div>
        {''.join(rows)}
        <div style="margin-top:12px;padding:9px 12px;background:#1a1d2e;border-radius:8px;font-size:.72rem;color:#8892a4;line-height:1.6">
          <strong style="color:#e2e8f0">Overall:</strong> {calc}
        </div>
      </div>
    </div>
  </div>
</div>\n"""


    # ── §3 Text summary (quick only) ───────────────────────────────────────
    def _sec_text_summary(self) -> str:
        s = self.m['summary']
        worst = self.m.get('worstOverruns', [{}])[0] if self.m.get('worstOverruns') else {}
        overloaded = max(
            self.m.get('perUser', {}).items(),
            key=lambda kv: kv[1].get('timeSpentH', 0) - kv[1].get('origEstH', 0),
            default=('—', {})
        )
        _op = s.get('overrunPct')
        _overrun = '?%' if _op is None else (f'+{_op}%' if _op >= 0 else f'{_op}%')
        return f"""
<div class="card gf" style="font-size:.92rem;line-height:1.7">
  <div class="stitle"><span>⚡</span> Quick Summary — Sprint {h(self.m['sprintId'])}</div>
  <div>✅ <strong>Completed:</strong> {s['completedCount']} / {s['totalTickets']} tickets ({s['completionPct']}%)</div>
  <div>⏱ <strong>Hours:</strong> {s['totalOrigEstH']}h committed → {s['totalLoggedH']}h logged ({_overrun})</div>
  <div>⚡ <strong>Velocity ratio:</strong> {round(s['velocityRatio']*100,1)}%</div>
  <div>🔴 <strong>Spillover:</strong> {s['spilloverCount']} tickets still in progress / open</div>
  <div>🚫 <strong>Untouched:</strong> {s['untouchedCount']} tickets (0h logged)</div>
  {f'<div>🔥 <strong>Worst ticket:</strong> <a href="https://maxxton.atlassian.net/browse/{h(worst["key"])}" target="_blank" style="color:#6366f1">{h(worst["key"])}</a> — {h(worst["summary"][:60])} · {worst.get("timeSpentH")}h vs {worst.get("origEstH")}h estimate ({worst.get("estRatio")}×)</div>' if worst else ''}
  <div>⚠ <strong>Most overloaded:</strong> {h(overloaded[0])} — {overloaded[1].get('timeSpentH',0)}h logged vs {overloaded[1].get('origEstH',0)}h estimated</div>
</div>\n"""


    # ── §R Recommendations ─────────────────────────────────────────────────

    # ── §R Recommendations ──────────────────────────────────────────────────
    def _sec_recommendations(self) -> str:
        m  = self.m
        s  = m['summary']
        pu = m.get('perUser', {})
        daily = m.get('dailyTotals', [])

        issues = []  # list of (severity, title, evidence, action)
        # severity: 'critical' | 'warning' | 'info'

        # R1: Severely underestimated tickets (ratio > 3×)
        bad = [t for t in m.get('underestimated', []) if (t.get('estRatio') or 0) > 3]
        if bad:
            names = ', '.join(
                '{} ({}%)'.format(t['key'], round((t.get('estRatio') or 0)*100))
                for t in bad[:3]
            )
            evidence = '{} ticket(s) spent 3x or more their estimate: {}'.format(len(bad), names)
            action = (
                'Break these ticket types into smaller sub-tasks before sprint planning. '
                'Consider requiring a spike/discovery ticket for any task with high '
                'uncertainty before committing to implementation.'
            )
            issues.append(('critical', 'Severely underestimated tickets', evidence, action))

        # R2: Overall hours overrun
        overrun = s.get('overrunPct') or 0
        if overrun > 40:
            sev = 'critical' if overrun > 60 else 'warning'
            gap = round(s['totalLoggedH'] - s['totalOrigEstH'], 1)
            avg_actual = s['totalLoggedH'] / max(s['totalTickets'], 1)
            suggested = round(s['totalOrigEstH'] / avg_actual)
            evidence = 'Committed {}h but logged {}h — a {}h gap.'.format(
                s['totalOrigEstH'], s['totalLoggedH'], gap)
            action = (
                'Original estimates are systematically optimistic. Apply a 1.3-1.5x buffer '
                'multiplier during planning, or reduce ticket count to approximately '
                '{} per sprint based on actual velocity.'.format(suggested)
            )
            issues.append((sev, 'Sprint ran {}% over estimated hours'.format(overrun), evidence, action))

        # R3: Overloaded team members (>150% of estimate)
        overloaded = [
            (u, d) for u, d in pu.items()
            if d['origEstH'] > 0 and d['timeSpentH'] / d['origEstH'] > 1.5
        ]
        if overloaded:
            overloaded.sort(key=lambda x: -x[1]['timeSpentH'])
            names = ', '.join(
                '{} ({}h vs {}h est)'.format(u, d['timeSpentH'], d['origEstH'])
                for u, d in overloaded[:3]
            )
            max_ratio = max(d['timeSpentH'] / d['origEstH'] for _, d in overloaded)
            sev = 'critical' if max_ratio > 2 else 'warning'
            evidence = 'Logged 150%+ of estimated hours: {}'.format(names)
            action = (
                'Review whether these team members are regularly absorbing unplanned work '
                'or cross-team requests not captured in estimates. '
                'Cap individual sprint commitment to ~80% of available capacity.'
            )
            issues.append((sev, 'Team member(s) significantly overloaded', evidence, action))

        # R4: One person carrying disproportionate share (>35%)
        if pu and s['totalLoggedH'] > 0:
            top_u, top_d = max(pu.items(), key=lambda kv: kv[1]['timeSpentH'])
            top_pct = round(top_d['timeSpentH'] / s['totalLoggedH'] * 100)
            if top_pct > 35:
                evidence = '{} logged {}h out of {}h total ({}%).'.format(
                    top_u, top_d['timeSpentH'], s['totalLoggedH'], top_pct)
                action = (
                    'High bus-factor risk. Ensure knowledge sharing and documentation for '
                    'the areas this person owns. Consider pairing or handoff tickets in the next sprint.'
                )
                issues.append(('warning',
                    '{} carried {}% of sprint hours'.format(top_u.split()[0], top_pct),
                    evidence, action))

        # R5: Untouched tickets
        untouched = m.get('untouchedTickets', [])
        if untouched:
            keys = ', '.join(t['key'] for t in untouched)
            evidence = '{} committed with 0h logged: {}'.format(len(untouched), keys)
            action = (
                'Investigate whether these had hidden blockers or were silently deprioritised. '
                'Move unstarted tickets out of the sprint immediately when scope changes, '
                'rather than leaving them to inflate the commitment number.'
            )
            issues.append(('warning', '{} ticket(s) committed but never started'.format(len(untouched)),
                           evidence, action))

        # R6: Spillover tickets
        spill = m.get('spilloverTickets', [])
        if spill:
            spill_est = sum(t['origEstH'] for t in spill)
            keys = ', '.join(t['key'] for t in spill[:4])
            sev = 'critical' if len(spill) > 2 else 'warning'
            evidence = '{} — representing ~{}h of committed work.'.format(keys, round(spill_est))
            action = (
                'Add to the top of next sprint backlog with re-estimated effort. '
                'Consider breaking down before re-committing if they have been deferred more than once.'
            )
            issues.append((sev, '{} ticket(s) spilled over to next sprint'.format(len(spill)),
                           evidence, action))

        # R7: Systematic underestimation (>=25% of tickets)
        under_count = len(m.get('underestimated', []))
        under_pct = round(under_count / max(s['totalTickets'], 1) * 100)
        if under_pct >= 25:
            evidence = '{} of {} tickets spent >130% of estimate ({}%).'.format(
                under_count, s['totalTickets'], under_pct)
            action = (
                'Run a short retrospective on estimation technique. '
                'Use reference/anchor stories, 3-point estimation, or planning poker '
                'for complex tickets to surface hidden assumptions early.'
            )
            issues.append(('warning', '{}% of tickets were underestimated (systematic bias)'.format(under_pct),
                           evidence, action))

        # R8: Back-loading (>65% of work in second half of sprint)
        if daily and len(daily) >= 10:
            mid = len(daily) // 2
            first_h  = sum(daily[:mid])
            second_h = sum(daily[mid:])
            total_h  = first_h + second_h
            if total_h > 0 and second_h / total_h > 0.65:
                back_pct = round(second_h / total_h * 100)
                evidence = 'First half: {}h  Second half: {}h  ({}% in second half).'.format(
                    round(first_h), round(second_h), back_pct)
                action = (
                    'Back-loading reduces QA time and increases end-of-sprint risk. '
                    'Run a mid-sprint check-in on day 7-8 to surface blockers early. '
                    'Tickets that cannot start in the first half are strong candidates for scope reduction.'
                )
                issues.append(('warning', '{}% of work logged in the second half of sprint'.format(back_pct),
                               evidence, action))

        # R9: Long-running carry-over tickets
        pag = m.get('paginatedTickets', [])
        if pag:
            evidence = 'Tickets with 20+ worklog entries spanning multiple sprints: {}.'.format(', '.join(pag))
            action = (
                'Long-running tickets accumulate invisible technical and planning debt. '
                'Consider closing and creating fresh tickets scoped only to remaining work, '
                'with a clean estimate based on what is actually left.'
            )
            issues.append(('info', 'Carry-over tickets with long work history', evidence, action))

        # R10: High velocity but persistent hour overrun = estimation calibration needed
        if s['velocityRatio'] >= 0.9 and overrun >= 40:
            evidence = '{}% tickets done but {}% hours over budget — team delivers but takes longer than planned.'.format(
                s['completionPct'], overrun)
            action = (
                'This is an estimation accuracy issue, not a delivery problem. '
                'After each sprint, compare actual vs estimated per ticket type and use '
                'those ratios to calibrate future planning. Even a simple 1.4x multiplier '
                'would make commitments more honest and reduce end-of-sprint surprises.'
            )
            issues.append(('info', 'Strong completion rate but estimates are consistently low',
                           evidence, action))

        if not issues:
            return ''

        # ── Render ───────────────────────────────────────────────────────────
        sev_cfg = {
            'critical': ('#ef4444', 'rgba(239,68,68,.08)',  'rgba(239,68,68,.3)',  '🔴 Critical'),
            'warning':  ('#f59e0b', 'rgba(245,158,11,.08)', 'rgba(245,158,11,.3)', '🟡 Improve'),
            'info':     ('#3b82f6', 'rgba(59,130,246,.08)', 'rgba(59,130,246,.25)','🔵 Suggest'),
        }

        crit  = sum(1 for sev, *_ in issues if sev == 'critical')
        warn  = sum(1 for sev, *_ in issues if sev == 'warning')
        info  = sum(1 for sev, *_ in issues if sev == 'info')
        badge = '{} critical · {} to improve · {} suggestions'.format(crit, warn, info)

        cards = ''
        for sev, title, evidence, action in issues:
            col, bg, border, label = sev_cfg[sev]
            cards += (
                '<div style="background:{};border:1px solid {};border-left:4px solid {};'
                'border-radius:10px;padding:16px 18px;margin-bottom:12px">'
                '<div style="display:flex;align-items:center;gap:10px;margin-bottom:8px">'
                '<span style="font-size:.72rem;color:{};font-weight:700;text-transform:uppercase;'
                'letter-spacing:.5px">{}</span>'
                '<span style="font-size:.92rem;font-weight:600;color:#e2e8f0">{}</span>'
                '</div>'
                '<div style="font-size:.82rem;color:#8892a4;margin-bottom:8px">📊 <em>{}</em></div>'
                '<div style="font-size:.83rem;color:#c4c9d4">💡 {}</div>'
                '</div>'
            ).format(bg, border, col, col, h(label), h(title), h(evidence), h(action))

        return (
            '\n<div class="card gf">'
            '<div class="stitle"><span>💡</span> Sprint Improvement Recommendations'
            '<span style="margin-left:auto;font-size:.75rem;color:#8892a4;font-weight:400">{}</span>'
            '</div>{}</div>\n'
        ).format(h(badge), cards)
    def _sec_committed_completed(self) -> str:
        s = self.m['summary']
        sc = self.m.get('statusCounts', {})
        bar_id  = self.cid('commitChart')
        dnut_id = self.cid('statusDonut')

        # Status legend bars
        status_order = ['Checked by QA','Cannot Test','Closed','Resolved','Testing','In Progress','Reopened','Open','Done','Carried over']
        legend = ''
        total = sum(sc.values()) or 1
        for st in status_order:
            cnt = sc.get(st, 0)
            if cnt == 0:
                continue
            col = status_color(st)
            pct = round(cnt / total * 100)
            legend += f"""<div class="pb-wrap">
  <div class="pb-label"><strong>{h(st)}</strong><span>{cnt}</span></div>
  <div class="pb-bg" style="height:9px"><div class="pb-fill" style="width:{pct}%;background:{col};height:9px"></div></div>
</div>"""

        self.js(f"""
new Chart(document.getElementById('{bar_id}'),{{
  type:'bar',
  data:{{
    labels:['Total Est.','Total Logged','Completed Est.','Completed Logged'],
    datasets:[{{
      data:[{s['totalOrigEstH']},{s['totalLoggedH']},{s['doneOrigEstH']},{s['doneLoggedH']}],
      backgroundColor:['#3b82f6','#ef4444','#22c55e','#14b8a6'],
      borderRadius:6,borderSkipped:false
    }}]
  }},
  options:{{responsive:true,maintainAspectRatio:false,
    plugins:{{legend:{{display:false}},tooltip:{{callbacks:{{label:c=>` ${{c.raw}}h`}}}}}},
    scales:{{
      x:{{ticks:{{color:'#8892a4',font:{{size:10}}}},grid:{{color:'#2e3250'}}}},
      y:{{ticks:{{color:'#8892a4',callback:v=>v+'h'}},grid:{{color:'#2e3250'}}}}
    }}
  }}
}});""")

        status_labels  = json.dumps(list(sc.keys()))
        status_data    = json.dumps(list(sc.values()))
        status_bg      = json.dumps([status_color(s) for s in sc.keys()])
        self.js(f"""
new Chart(document.getElementById('{dnut_id}'),{{
  type:'doughnut',
  data:{{labels:{status_labels},datasets:[{{data:{status_data},backgroundColor:{status_bg},borderWidth:0,hoverOffset:4}}]}},
  options:{{responsive:true,maintainAspectRatio:false,cutout:'65%',
    plugins:{{legend:{{display:false}},tooltip:{{callbacks:{{label:c=>` ${{c.label}}: ${{c.raw}}`}}}}}}
  }}
}});""")

        return f"""
<div class="g2">
  <div class="card">
    <div class="stitle"><span>📊</span> Committed vs Completed (Hours)</div>
    <div class="chart-wrap" style="height:240px"><canvas id="{bar_id}"></canvas></div>
  </div>
  <div class="card">
    <div class="stitle"><span>🔵</span> Ticket Status Breakdown</div>
    <div class="donut-row">
      <div class="donut-wrap"><canvas id="{dnut_id}"></canvas></div>
      <div style="flex:1;min-width:0;padding-top:4px;font-size:.78rem">{legend}</div>
    </div>
  </div>
</div>\n"""

    # ── §5 Per-User chart + Issue Type donut ───────────────────────────────
    def _sec_per_user_chart(self) -> str:
        pu = self.m.get('perUser', {})
        tc = self.m.get('typeCounts', {})
        users = [u for u in self.m.get('allUsers', list(pu.keys())) if pu.get(u, {}).get('origEstH', 0) + pu.get(u, {}).get('timeSpentH', 0) > 0]
        bar_id  = self.cid('userChart')
        dnut_id = self.cid('typeDonut')

        u_labels  = json.dumps([u.split()[0]+' '+u.split()[1][0]+'.' if len(u.split())>1 else u for u in users])
        u_est     = json.dumps([pu[u]['origEstH']   for u in users])
        u_spent   = json.dumps([pu[u]['timeSpentH'] for u in users])
        u_colors  = json.dumps([user_color(u)       for u in users])

        self.js(f"""
new Chart(document.getElementById('{bar_id}'),{{
  type:'bar',
  data:{{
    labels:{u_labels},
    datasets:[
      {{label:'Estimated',data:{u_est},backgroundColor:{json.dumps([hex_alpha(user_color(u),.3) for u in users])},borderColor:{u_colors},borderWidth:1.5,borderRadius:4}},
      {{label:'Logged',   data:{u_spent},backgroundColor:{json.dumps([hex_alpha(user_color(u),.8) for u in users])},borderColor:{u_colors},borderWidth:1.5,borderRadius:4}}
    ]
  }},
  options:{{responsive:true,maintainAspectRatio:false,
    plugins:{{legend:{{labels:{{color:'#8892a4',font:{{size:10}}}}}},tooltip:{{callbacks:{{label:c=>` ${{c.dataset.label}}: ${{c.raw}}h`}}}}}},
    scales:{{
      x:{{ticks:{{color:'#8892a4',font:{{size:9}}}},grid:{{color:'#2e3250'}}}},
      y:{{ticks:{{color:'#8892a4',callback:v=>v+'h'}},grid:{{color:'#2e3250'}}}}
    }}
  }}
}});""")

        type_colors_map = {'Improvement':'#6366f1','Task':'#3b82f6','Bug':'#ef4444','New Feature':'#22c55e','Tech Debt':'#f59e0b'}
        t_labels = json.dumps(list(tc.keys()))
        t_data   = json.dumps(list(tc.values()))
        t_colors = json.dumps([type_colors_map.get(k,'#8892a4') for k in tc.keys()])

        type_legend = ''
        total_t = sum(tc.values()) or 1
        for tp, cnt in tc.items():
            col = type_colors_map.get(tp, '#8892a4')
            pct = round(cnt / total_t * 100, 1)
            type_legend += f"""<div class="pb-wrap" style="margin-bottom:10px">
  <div class="pb-label"><strong>{h(tp)}</strong><span>{cnt} ({pct}%)</span></div>
  <div class="pb-bg" style="height:11px"><div class="pb-fill" style="width:{pct}%;background:{col};height:11px"></div></div>
</div>"""

        self.js(f"""
new Chart(document.getElementById('{dnut_id}'),{{
  type:'doughnut',
  data:{{labels:{t_labels},datasets:[{{data:{t_data},backgroundColor:{t_colors},borderWidth:0,hoverOffset:4}}]}},
  options:{{responsive:true,maintainAspectRatio:false,cutout:'60%',
    plugins:{{legend:{{display:false}},tooltip:{{callbacks:{{label:c=>` ${{c.label}}: ${{c.raw}}`}}}}}}
  }}
}});""")

        return f"""
<div class="g2">
  <div class="card">
    <div class="stitle"><span>👥</span> Per-User: Estimated vs Logged Hours</div>
    <div class="chart-wrap" style="height:280px"><canvas id="{bar_id}"></canvas></div>
  </div>
  <div class="card">
    <div class="stitle"><span>🗂</span> Issue Type Distribution</div>
    <div class="donut-row" style="height:280px">
      <div class="donut-wrap" style="width:210px;height:210px"><canvas id="{dnut_id}"></canvas></div>
      <div style="flex:1;padding-top:4px;font-size:.8rem">{type_legend}</div>
    </div>
  </div>
</div>\n"""

    # ── §6 Velocity / Spillover ────────────────────────────────────────────
    def _sec_velocity_spillover(self) -> str:
        s = self.m['summary']
        spill = self.m.get('spilloverTickets', [])

        def pb(label, val, total, color):
            pct = round(val / total * 100, 1) if total else 0
            return f"""<div class="pb-wrap">
  <div class="pb-label"><strong>{h(label)}</strong><span>{val} / {total}</span></div>
  <div class="pb-bg" style="height:13px"><div class="pb-fill" style="width:{pct}%;background:{color};height:13px"></div></div>
</div>"""

        left = f"""
<div style="margin-bottom:16px">
  <div style="font-size:.72rem;color:#8892a4;text-transform:uppercase;letter-spacing:.5px;margin-bottom:8px">Tickets Planned vs Completed</div>
  {pb('Completed', s['completedCount'], s['totalTickets'], '#22c55e')}
  <div style="margin-top:6px">{pb('Spillover / WIP', s['spilloverCount'], s['totalTickets'], '#f97316')}</div>
</div>
<div>
  <div style="font-size:.72rem;color:#8892a4;text-transform:uppercase;letter-spacing:.5px;margin-bottom:8px">Hours Planned vs Logged</div>
  {pb('Committed (Orig. Est.)', s['totalOrigEstH'], s['totalOrigEstH'], '#3b82f6')}
  <div style="margin-top:6px">{pb('Actual Logged', s['totalLoggedH'], s['totalLoggedH'], '#ef4444')}</div>
  <div style="margin-top:6px">{pb('Completed Tickets', s['doneLoggedH'], s['totalOrigEstH'], '#14b8a6')}</div>
</div>"""

        rows = ''
        for t in spill[:8]:
            sc = status_color(t['status'])
            rows += f"""<tr>
  <td class="tk"><a href="{h(t.get('webUrl','#'))}" target="_blank">{h(t['key'])}</a></td>
  <td><span class="badge" style="background:{hex_alpha(sc,.15)};color:{sc}">{h(t['status'])}</span></td>
  <td style="font-size:.78rem">{h(t['assignee'][:14])}</td>
  <td>{t['origEstH']}h</td>
  <td {'style="color:#ef4444"' if t['timeSpent']==0 else ''}>{t['timeSpentH']}h</td>
</tr>"""

        right = f"""<div style="font-size:.72rem;color:#8892a4;text-transform:uppercase;letter-spacing:.5px;margin-bottom:8px">Spillover Tickets</div>
<table><thead><tr><th>Ticket</th><th>Status</th><th>Assignee</th><th>Est</th><th>Spent</th></tr></thead>
<tbody>{rows}</tbody></table>"""

        return f"""
<div class="card gf">
  <div class="stitle"><span>🎯</span> Sprint Velocity — Ticket Completion Rate</div>
  <div class="g2" style="margin-bottom:0">
    <div>{left}</div>
    <div>{right}</div>
  </div>
</div>\n"""

    # ── §7 Estimation Accuracy chart ───────────────────────────────────────
    def _sec_estimation_accuracy(self) -> str:
        tickets = [t for t in self.m.get('tickets', []) if t.get('origEstH', 0) > 0 and t.get('timeSpentH', 0) > 0]
        tickets.sort(key=lambda t: -(t['timeSpentH'] - t['origEstH']))

        cid = self.cid('estChart')
        labels    = json.dumps([t['key'] for t in tickets])
        est_data  = json.dumps([t['origEstH']   for t in tickets])
        spent_data= json.dumps([t['timeSpentH'] for t in tickets])
        colors    = json.dumps([EST_COLORS.get(t.get('estCategory','accurate'), '#22c55e') for t in tickets])

        self.js(f"""
new Chart(document.getElementById('{cid}'),{{
  type:'bar',
  data:{{
    labels:{labels},
    datasets:[
      {{label:'Original Estimate',data:{est_data},backgroundColor:'rgba(59,130,246,.35)',borderColor:'#3b82f6',borderWidth:1.5,borderRadius:4,borderSkipped:false}},
      {{label:'Time Logged',data:{spent_data},backgroundColor:{json.dumps([hex_alpha(c,.6) for c in json.loads(colors)])},borderColor:{colors},borderWidth:1.5,borderRadius:4,borderSkipped:false}}
    ]
  }},
  options:{{responsive:true,maintainAspectRatio:false,
    plugins:{{
      legend:{{labels:{{color:'#8892a4',font:{{size:10}}}}}},
      tooltip:{{callbacks:{{label:c=>` ${{c.dataset.label}}: ${{c.raw}}h`}}}}
    }},
    scales:{{
      x:{{ticks:{{color:'#8892a4',font:{{size:8}},maxRotation:45}},grid:{{color:'#2e3250'}}}},
      y:{{ticks:{{color:'#8892a4',callback:v=>v+'h'}},grid:{{color:'#2e3250'}}}}
    }}
  }}
}});""")

        return f"""
<div class="card gf">
  <div class="stitle"><span>📏</span> Estimation Accuracy per Ticket</div>
  <div class="chart-wrap" style="height:380px"><canvas id="{cid}"></canvas></div>
</div>\n"""

    # ── §8 Over/Underestimated + Untouched ────────────────────────────────
    def _sec_over_underest(self) -> str:
        under  = self.m.get('underestimated', [])
        over   = self.m.get('overestimated', [])
        untouched = self.m.get('untouchedTickets', [])

        left = ''
        for t in under:
            delta = round(t['timeSpentH'] - t['origEstH'], 1)
            cls = 'alert-box' if t.get('estRatio', 0) > 2 else 'warn-box'
            lbl_cls = 'ah' if cls == 'alert-box' else 'wh'
            left += f"""<div class="{cls}">
  <div class="{lbl_cls}">{'🔥' if t.get('estRatio',0)>2 else '⚠'} {h(t['key'])} — {h(t['summary'][:55])}</div>
  <div>Est {t['origEstH']}h · Logged <strong style="color:{'#ef4444' if t.get('estRatio',0)>2 else '#f59e0b'}">{t['timeSpentH']}h</strong> · {round((t.get('estRatio') or 0)*100)}% of est · <em>{h(t['status'])}</em></div>
</div>"""

        over_rows = ''
        for t in over:
            over_rows += f"""<tr>
  <td><div class="tk"><a href="{h(t.get('webUrl','#'))}" target="_blank">{h(t['key'])}</a></div>
      <div style="color:#8892a4;font-size:.72rem">{h(t['summary'][:42])}</div></td>
  <td>{t['origEstH']}h</td><td>{t['timeSpentH']}h</td>
  <td><span class="chip" style="background:rgba(34,197,94,.15);color:#22c55e">{round((t.get('estRatio') or 0)*100)}%</span></td>
</tr>"""

        untouched_html = ''
        for t in untouched:
            untouched_html += f"""<div class="alert-box" style="margin-bottom:8px">
  <div class="ah">{h(t['key'])} · {h(t['assignee'])} · {h(t['status'])}</div>
  <div>{h(t['summary'][:60])} · Est. {t['origEstH']}h · 0h spent</div>
</div>"""

        right = f"""<table>
  <thead><tr><th>Ticket</th><th>Estimate</th><th>Spent</th><th>Logged %</th></tr></thead>
  <tbody>{over_rows}</tbody>
</table>
<div style="margin-top:16px">
  <div class="stitle" style="font-size:.95rem;margin-bottom:10px"><span>🚫</span> Untouched Tickets (0h logged)</div>
  {untouched_html or '<div style="color:#8892a4;font-size:.85rem">None — all tickets have at least some work logged.</div>'}
</div>"""

        return f"""
<div class="g2">
  <div class="card">
    <div class="stitle"><span>⚠️</span> Underestimated (Spent &gt;130% of Estimate)</div>
    {left or '<div style="color:#8892a4;font-size:.85rem">No significantly underestimated tickets.</div>'}
  </div>
  <div class="card">
    <div class="stitle"><span>✅</span> Overestimated (Spent &lt;70% of Estimate)</div>
    {right}
  </div>
</div>\n"""

    # ── §9 Per-User worklog table ──────────────────────────────────────────
    def _sec_per_user_table(self) -> str:
        pu = self.m.get('perUser', {})
        users = sorted(pu.keys(), key=lambda u: -pu[u].get('timeSpentH', 0))

        rows = ''
        for u in users:
            d  = pu[u]
            est   = d.get('origEstH',   0)
            spent = d.get('timeSpentH', 0)
            delta = round(spent - est, 1)
            ratio = spent / est if est > 0 else None
            pct   = round(ratio * 100) if ratio else 0
            bar_w = min(pct, 100) if ratio else 100
            if ratio is None:
                badge = '<span class="badge" style="background:rgba(136,146,164,.15);color:#8892a4">⚪ No estimate</span>'
                bar_color = '#8892a4'
            elif ratio > 1.5:
                badge = '<span class="badge" style="background:rgba(239,68,68,.15);color:#ef4444">🔴 Critical</span>'
                bar_color = '#ef4444'
            elif ratio > 1.1:
                badge = '<span class="badge" style="background:rgba(245,158,11,.15);color:#f59e0b">🟡 Slight Overrun</span>'
                bar_color = '#f59e0b'
            elif ratio >= 0.8:
                badge = '<span class="badge" style="background:rgba(34,197,94,.15);color:#22c55e">🟢 On Track</span>'
                bar_color = '#22c55e'
            else:
                badge = '<span class="badge" style="background:rgba(59,130,246,.15);color:#3b82f6">🔵 Overestimated</span>'
                bar_color = '#3b82f6'

            uc = user_color(u)
            initials = ''.join(p[0].upper() for p in u.split()[:2])
            delta_col = '#ef4444' if delta > 0 else '#22c55e'
            rows += f"""<tr>
  <td><div class="ucell"><div class="avatar" style="background:{uc}">{h(initials)}</div><strong>{h(u)}</strong></div></td>
  <td>{d.get('tickets',0)}</td>
  <td>{est}h</td>
  <td {'style="color:#ef4444"' if ratio and ratio>1.3 else ''}><strong>{spent}h</strong></td>
  <td style="color:{delta_col}">{'+' if delta>0 else ''}{delta}h</td>
  <td><div class="ibar"><div class="ibar-bg"><div class="ibar-fill" style="width:{bar_w}%;background:{bar_color}"></div></div>
      <span style="font-size:.72rem;color:{bar_color}">{pct}%</span></div></td>
  <td>{badge}</td>
</tr>"""

        # Cross-team contributors note
        cross = []
        for t in self.m.get('tickets', []):
            assigned = t['assignee']
            for wl in t.get('worklogs', []):
                if wl['author'] != assigned and wl['author'] not in ('Timesheets by Tempo - Jira Time Tracking',):
                    cross.append((wl['author'], t['key']))
        cross_note = ''
        if cross:
            names = sorted(set(a for a,_ in cross))
            cross_note = f"""<div style="margin-top:12px;padding:10px 12px;background:rgba(168,85,247,.08);border:1px solid rgba(168,85,247,.25);border-radius:8px;font-size:.8rem;color:#8892a4">
  <strong style="color:#a855f7">ℹ Cross-team contributors:</strong> {h(', '.join(names))} logged time on tickets they are not assigned to.
</div>"""

        return f"""
<div class="card gf">
  <div class="stitle"><span>🧑‍💻</span> Per-User Worklog Summary vs Estimated Work</div>
  <table>
    <thead><tr><th>Team Member</th><th>Tickets</th><th>Original Est.</th><th>Time Logged</th><th>Delta</th><th>Efficiency Bar</th><th>Status</th></tr></thead>
    <tbody>{rows}</tbody>
  </table>
  {cross_note}
</div>\n"""

    # ── §10 Worst Ticket Spotlight ─────────────────────────────────────────

    # ── §QS Quality Signals ────────────────────────────────────────────────
    def _sec_quality_signals(self) -> str:
        qs = self.m.get('qualitySignals', {})
        reopened = qs.get('reopenedTickets', [])
        blocked  = qs.get('blockedTickets',  [])
        chronic  = qs.get('chronicTickets',  [])

        if not reopened and not blocked and not chronic:
            return (
                '\n<div class="card gf" style="border-left:4px solid #22c55e">'
                '<div class="stitle"><span>✅</span> Quality Signals</div>'
                '<div style="color:#22c55e;font-size:.9rem">No quality regression signals detected this sprint — '
                'zero reopened tickets, no blocked work, no chronic carry-overs.</div>'
                '</div>\n'
            )

        cards = ''

        if reopened:
            rows = ''.join(
                f'<tr><td class="tk"><a href="https://maxxton.atlassian.net/browse/{h(t["key"])}" '
                f'target="_blank">{h(t["key"])}</a></td>'
                f'<td style="color:#8892a4;font-size:.8rem">{h(t["summary"])}</td>'
                f'<td style="font-size:.78rem">{h(t.get("assignee","—"))}</td></tr>'
                for t in reopened
            )
            cards += (
                f'<div style="background:rgba(239,68,68,.07);border:1px solid rgba(239,68,68,.25);'
                f'border-radius:10px;padding:14px 16px;margin-bottom:12px">'
                f'<div style="font-size:.72rem;color:#ef4444;font-weight:700;text-transform:uppercase;'
                f'letter-spacing:.5px;margin-bottom:10px">🔄 Reopened Tickets ({len(reopened)})'
                f' — each indicates a defect escaped review</div>'
                f'<table><thead><tr><th>Key</th><th>Summary</th><th>Assignee</th></tr></thead>'
                f'<tbody>{rows}</tbody></table></div>'
            )

        if blocked:
            rows = ''.join(
                f'<tr><td class="tk"><a href="https://maxxton.atlassian.net/browse/{h(t["key"])}" '
                f'target="_blank">{h(t["key"])}</a></td>'
                f'<td style="color:#8892a4;font-size:.8rem">{h(t["summary"])}</td>'
                f'<td><span class="badge" style="background:rgba(245,158,11,.15);color:#f59e0b">'
                f'{h(t.get("status","?"))}</span></td>'
                f'<td style="font-size:.78rem">{t.get("origEstH",0)}h</td></tr>'
                for t in blocked
            )
            cards += (
                f'<div style="background:rgba(245,158,11,.07);border:1px solid rgba(245,158,11,.25);'
                f'border-radius:10px;padding:14px 16px;margin-bottom:12px">'
                f'<div style="font-size:.72rem;color:#f59e0b;font-weight:700;text-transform:uppercase;'
                f'letter-spacing:.5px;margin-bottom:10px">🚧 Blocked / Stalled Tickets ({len(blocked)})'
                f' — 0h logged while in WIP status</div>'
                f'<table><thead><tr><th>Key</th><th>Summary</th><th>Status</th><th>Est</th></tr></thead>'
                f'<tbody>{rows}</tbody></table></div>'
            )

        if chronic:
            rows = ''.join(
                f'<tr><td class="tk"><a href="https://maxxton.atlassian.net/browse/{h(t["key"])}" '
                f'target="_blank">{h(t["key"])}</a></td>'
                f'<td style="color:#8892a4;font-size:.8rem">{h(t["summary"])}</td>'
                f'<td style="text-align:center;font-weight:700;color:#ef4444">{t.get("sprintCount","?")} sprints</td>'
                f'<td><span class="badge" style="background:rgba(99,102,241,.15);color:#818cf8">'
                f'{h(t.get("status","?"))}</span></td></tr>'
                for t in chronic
            )
            cards += (
                f'<div style="background:rgba(99,102,241,.07);border:1px solid rgba(99,102,241,.25);'
                f'border-radius:10px;padding:14px 16px">'
                f'<div style="font-size:.72rem;color:#818cf8;font-weight:700;text-transform:uppercase;'
                f'letter-spacing:.5px;margin-bottom:10px">🔁 Chronic Carry-Overs ({len(chronic)})'
                f' — alive across 3+ sprints, representing invisible accumulated scope</div>'
                f'<table><thead><tr><th>Key</th><th>Summary</th><th>Sprints</th><th>Status</th></tr></thead>'
                f'<tbody>{rows}</tbody></table></div>'
            )

        total_issues = len(reopened) + len(blocked) + len(chronic)
        return (
            f'\n<div class="card gf">'
            f'<div class="stitle"><span>⚠️</span> Quality Signals'
            f'<span style="margin-left:auto;font-size:.75rem;color:#8892a4;font-weight:400">'
            f'{total_issues} issue{"s" if total_issues != 1 else ""} flagged</span></div>'
            f'{cards}</div>\n'
        )

    # ── §SC Scope Creep ────────────────────────────────────────────────────
    def _sec_scope_creep(self) -> str:
        sc = self.m.get('scopeCreep', {})
        tickets = sc.get('tickets', [])
        count   = sc.get('count', 0)
        est_h   = sc.get('estH', 0)
        pct     = sc.get('pctOfEst', 0)

        if count == 0:
            return (
                '\n<div class="card gf" style="border-left:4px solid #22c55e">'
                '<div class="stitle"><span>🔒</span> Scope Creep</div>'
                '<div style="color:#22c55e;font-size:.9rem">No scope creep detected — '
                'no tickets were added after the sprint started.</div>'
                '</div>\n'
            )

        sev_color = '#ef4444' if pct > 30 else '#f59e0b' if pct > 15 else '#3b82f6'
        sev_label = 'High (>30% of hours)' if pct > 30 else 'Moderate (>15%)' if pct > 15 else 'Low (<15%)'

        rows = ''.join(
            f'<tr><td class="tk"><a href="https://maxxton.atlassian.net/browse/{h(t["key"])}" '
            f'target="_blank">{h(t["key"])}</a></td>'
            f'<td style="color:#8892a4;font-size:.8rem">{h(t["summary"])}</td>'
            f'<td style="font-size:.78rem;color:#8892a4">{h(t.get("createdDate","?"))}</td>'
            f'<td style="text-align:right">{t.get("origEstH",0)}h</td></tr>'
            for t in tickets[:5]
        )
        more = f'<tr><td colspan="4" style="color:#8892a4;font-size:.78rem;font-style:italic">... and {count-5} more</td></tr>' if count > 5 else ''

        return (
            f'\n<div class="card gf">'
            f'<div class="stitle"><span>📥</span> Scope Creep — Tickets Added Mid-Sprint'
            f'<span style="margin-left:auto;font-size:.75rem;font-weight:400;color:{sev_color}">'
            f'{count} ticket{"s" if count!=1 else ""} · {est_h}h · {pct}% of sprint est · {sev_label}</span></div>'
            f'<div style="font-size:.82rem;color:#8892a4;margin-bottom:12px">'
            f'Tickets created <strong>after the sprint start date</strong>. '
            f'{"⚠ Scope creep exceeded 15% — committed work was likely displaced." if pct>15 else "Within acceptable range."}'
            f'</div>'
            f'<table><thead><tr><th>Key</th><th>Summary</th><th>Added</th><th style="text-align:right">Est</th></tr></thead>'
            f'<tbody>{rows}{more}</tbody></table>'
            f'</div>'
        )  # end

    # ── §NF Next Sprint Forecast ───────────────────────────────────────────
    def _sec_next_sprint_forecast(self) -> str:
        fc = self.compare.get('forecast', {})
        s  = self.m['summary']
        if not fc:
            fc = {
                'sustainableThroughput': s['completedCount'],
                'recommendedScope80':    round(s['completedCount'] / 0.80),
                'recommendedScope75':    round(s['completedCount'] / 0.75),
                'trend': 'single',
                'note': 'Based on current sprint only',
            }
            single = True
        else:
            single = False

        trend_color = '#ef4444' if 'declining' in fc.get('trend', '') else '#22c55e'
        trend_icon  = '📉' if 'declining' in fc.get('trend', '') else '📊'
        trend_label = fc.get('trend', '').title()
        trend_note  = fc.get('note', '')

        stacked_hint = (
            '<div style="font-size:.78rem;color:#8892a4;margin-top:10px">'
            + trend_icon
            + ' Trend: <strong style="color:' + trend_color + '">'
            + trend_label + '</strong> · ' + trend_note + '</div>'
        ) if not single else ''

        hint_div = (
            '<div style="margin-top:12px;font-size:.78rem;color:#8892a4;padding:8px 10px;'
            'background:rgba(245,158,11,.07);border-radius:6px">'
            'Pass a sprint_trend.json via --compare for multi-sprint weighted forecast.</div>'
        ) if single else ''

        sp       = self.m.get('storyPoints', {})
        sp_total = sp.get('total', 0)
        sp_row   = ''
        if sp_total > 0:
            sp_vel = (' (' + str(sp.get('velocity', '?')) + '%)') if sp.get('velocity') else ''
            sp_row = (
                '<tr><td style="color:#8892a4;font-style:italic">Story points done / planned</td>'
                '<td style="text-align:right;color:#6366f1;font-weight:700">'
                + str(sp.get('done', 0)) + ' / ' + str(sp_total) + sp_vel
                + '</td></tr>'
            )

        return (
            '\n<div class="card gf">'
            '<div class="stitle"><span>🔭</span> Next Sprint Capacity Forecast</div>'
            '<div class="g2" style="margin-bottom:0">'
            '<div>'
            '<div style="text-align:center;padding:20px;background:#1f2235;border-radius:10px;margin-bottom:12px">'
            '<div style="font-size:2.8rem;font-weight:800;color:#6366f1;line-height:1">'
            + str(fc.get('sustainableThroughput', '?')) +
            '</div>'
            '<div style="font-size:.78rem;color:#8892a4;margin-top:6px">sustainable tickets / sprint</div>'
            '<div style="font-size:.72rem;color:#8892a4;margin-top:4px">' + trend_note + '</div>'
            '</div>'
            + stacked_hint +
            '</div>'
            '<div>'
            '<table>'
            '<thead><tr><th>Target completion</th><th style="text-align:right">Max tickets to commit</th></tr></thead>'
            '<tbody>'
            '<tr>'
            '<td style="color:#22c55e;font-weight:600">80% completion '
            '<span style="color:#8892a4;font-weight:400">(recommended)</span></td>'
            '<td style="text-align:right;font-size:1.3rem;font-weight:800;color:#22c55e">\u2264 '
            + str(fc.get('recommendedScope80', '?')) +
            '</td></tr>'
            '<tr>'
            '<td style="color:#f59e0b">75% completion '
            '<span style="color:#8892a4;font-weight:400">(conservative)</span></td>'
            '<td style="text-align:right;font-size:1.3rem;font-weight:800;color:#f59e0b">\u2264 '
            + str(fc.get('recommendedScope75', '?')) +
            '</td></tr>'
            '<tr><td style="color:#8892a4;font-style:italic">Current sprint size</td>'
            '<td style="text-align:right;color:#8892a4">'
            + str(s['totalTickets']) + ' \u2192 ' + str(s['completedCount'])
            + ' done (' + str(s['completionPct']) + '%)</td></tr>'
            + sp_row +
            '</tbody></table>'
            + hint_div +
            '</div>'
            '</div>'
            '</div>\n'
        )


    def _sec_worst_tickets(self) -> str:
        worst = self.m.get('worstOverruns', [])[:3]
        rank_labels = ['🏆 Worst Overrun', '🥈 2nd Biggest Overrun', '⚠️ Estimation Anomaly']
        rank_colors = [
            ('rgba(239,68,68,.07)',  'rgba(239,68,68,.25)',  '#ef4444'),
            ('rgba(249,115,22,.07)', 'rgba(249,115,22,.25)', '#f97316'),
            ('rgba(245,158,11,.07)', 'rgba(245,158,11,.25)', '#f59e0b'),
        ]
        cards = ''
        for i, t in enumerate(worst):
            bg, border, col = rank_colors[i] if i < len(rank_colors) else rank_colors[-1]
            overrun = round(t['timeSpentH'] - t['origEstH'], 1)
            sc = status_color(t['status'])
            stats = f"""<div style="display:flex;gap:12px;font-size:.82rem;margin-bottom:10px">
  <div><div style="color:#8892a4;font-size:.7rem">Estimated</div><div style="font-weight:700">{t['origEstH']}h</div></div>
  <div><div style="color:#8892a4;font-size:.7rem">Logged</div><div style="color:{col};font-weight:700">{t['timeSpentH']}h</div></div>
  <div><div style="color:#8892a4;font-size:.7rem">Overrun</div><div style="color:{col};font-weight:700">+{overrun}h</div></div>
  <div><div style="color:#8892a4;font-size:.7rem">Logged %</div><div style="color:{col};font-weight:700">{round((t.get('estRatio') or 0)*100)}%</div></div>
</div>"""
            cards += f"""<div style="background:{bg};border:1px solid {border};border-radius:10px;padding:16px">
  <div style="font-size:.7rem;color:{col};font-weight:600;text-transform:uppercase;letter-spacing:.5px;margin-bottom:6px">{rank_labels[i]}</div>
  <div class="tk" style="font-size:.95rem;margin-bottom:6px"><a href="{h(t.get('webUrl','#'))}" target="_blank">{h(t['key'])}</a></div>
  <div style="font-size:.85rem;font-weight:600;margin-bottom:8px">{h(t['summary'][:55])}</div>
  <div style="font-size:.78rem;color:#8892a4;margin-bottom:10px">Status: <span style="color:{sc}">{h(t['status'])}</span> · {h(t['assignee'])}</div>
  {stats}
</div>"""

        return f"""
<div class="card gf">
  <div class="stitle"><span>🔥</span> Worst Ticket Spotlight — Sprint's Biggest Pain Points</div>
  <div class="g3" style="margin-bottom:0">{cards}</div>
</div>\n"""

    # ── §11 Full Ticket List ───────────────────────────────────────────────
    def _sec_full_ticket_list(self) -> str:
        import json as _json
        tickets = sorted(self.m.get('tickets', []), key=lambda t: -(t['timeSpentH'] - t['origEstH']))

        # Collect unique statuses for chip filter
        statuses = sorted({t['status'] for t in tickets})
        status_dot = {st: status_color(st) for st in statuses}

        rows = ''
        for t in tickets:
            sc = status_color(t['status'])
            ratio = t.get('estRatio')
            cat   = t.get('estCategory', 'accurate')
            chip_col = EST_COLORS.get(cat, '#22c55e')
            chip_bg  = hex_alpha(chip_col, .15)
            chip_val = f"{round(ratio*100)}%" if ratio is not None else '—'
            rows += f'''<tr data-status="{h(t['status'])}">
  <td class="tk"><a href="{h(t.get('webUrl','#'))}" target="_blank">{h(t['key'])}</a></td>
  <td style="max-width:220px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">{h(t['summary'][:55])}</td>
  <td>{h(t['issuetype'])}</td>
  <td style="font-size:.78rem">{h(t['assignee'][:14])}</td>
  <td><span class="badge" style="background:{hex_alpha(sc,.15)};color:{sc}">{h(t['status'])}</span></td>
  <td>{t['origEstH']}h</td>
  <td {'style="color:#ef4444"' if cat=='underestimated' else ''}>{t['timeSpentH']}h</td>
  <td><span class="chip" style="background:{chip_bg};color:{chip_col}">{h(chip_val)}</span></td>
</tr>'''

        # Build chip HTML for each status
        chips_html = '\n'.join(
            f'''<span class="ftl-chip" data-status="{h(st)}" onclick="ftlToggleChip(this)">'''
            f'''<span style="width:7px;height:7px;border-radius:50%;background:{status_dot[st]};display:inline-block;flex-shrink:0;margin-right:4px"></span>{h(st)}</span>'''
            for st in statuses
        )

        tbl_id  = self.cid('fullTicketTbl')
        cnt_id  = self.cid('ftlCount')
        col_id  = self.cid('ftlSortCol')
        dir_id  = self.cid('ftlSortDir')
        chip_id = self.cid('ftlChipGroup')

        self.js(f"""
(function(){{
  function ftlApply(){{
    var chips = document.querySelectorAll('#{chip_id} .ftl-chip.active');
    var sel = Array.from(chips).map(function(c){{return c.dataset.status;}});
    var sortCol = parseInt(document.getElementById('{col_id}').value);
    var sortDir = document.getElementById('{dir_id}').value;
    var tbl = document.getElementById('{tbl_id}');
    if(!tbl) return;
    var tbody = tbl.querySelector('tbody');
    var rows = Array.from(tbody.querySelectorAll('tr'));
    var vis = 0;
    rows.forEach(function(r){{
      var show = sel.length===0 || sel.indexOf(r.dataset.status)!==-1;
      r.style.display = show ? '' : 'none';
      if(show) vis++;
    }});
    var ct = document.getElementById('{cnt_id}');
    if(ct) ct.textContent = vis + ' of ' + rows.length + ' tickets';
    var visRows = rows.filter(function(r){{return r.style.display!=='none';}});
    visRows.sort(function(a,b){{
      var ac = a.cells[sortCol] ? a.cells[sortCol].innerText.trim() : '';
      var bc = b.cells[sortCol] ? b.cells[sortCol].innerText.trim() : '';
      var an = parseFloat(ac.replace(/[^0-9.]/g,''));
      var bn = parseFloat(bc.replace(/[^0-9.]/g,''));
      if(!isNaN(an)&&!isNaN(bn)) return sortDir==='asc'?an-bn:bn-an;
      return sortDir==='asc'?ac.localeCompare(bc):bc.localeCompare(ac);
    }});
    visRows.forEach(function(r){{tbody.appendChild(r);}});
  }}
  function ftlToggleChip(chip){{chip.classList.toggle('active');ftlApply();}}
  function ftlReset(){{
    document.querySelectorAll('#{chip_id} .ftl-chip').forEach(function(c){{c.classList.remove('active');}});
    document.getElementById('{col_id}').value='0';
    document.getElementById('{dir_id}').value='asc';
    ftlApply();
  }}
  window.ftlToggleChip=ftlToggleChip; window.ftlReset=ftlReset; window.ftlApply=ftlApply;
  document.addEventListener('DOMContentLoaded',function(){{
    var rows=document.querySelectorAll('#{tbl_id} tbody tr');
    var ct=document.getElementById('{cnt_id}');
    if(ct) ct.textContent=rows.length+' of '+rows.length+' tickets';
  }});
}})();""")

        return f"""
<div class="card gf">
  <div class="stitle"><span>📋</span> Full Sprint Ticket List</div>
  <div class="filter-bar" style="flex-direction:column;align-items:flex-start;gap:10px">
    <div style="display:flex;flex-wrap:wrap;align-items:center;gap:8px">
      <span style="color:#8892a4;font-size:.78rem;white-space:nowrap">Filter status:</span>
      <div id="{chip_id}" style="display:flex;flex-wrap:wrap;gap:6px">{chips_html}</div>
    </div>
    <div style="display:flex;flex-wrap:wrap;align-items:center;gap:8px">
      <span style="color:#8892a4;font-size:.78rem">Sort:</span>
      <select id="{col_id}" class="filter-select" onchange="ftlApply()">
        <option value="0">Key</option><option value="2">Type</option>
        <option value="3">Assignee</option><option value="4">Status</option>
        <option value="5">Orig. Est.</option><option value="6">Logged</option>
        <option value="7">Logged %</option>
      </select>
      <select id="{dir_id}" class="filter-select" onchange="ftlApply()">
        <option value="asc">↑ Asc</option><option value="desc">↓ Desc</option>
      </select>
      <button class="filter-reset" onclick="ftlReset()">Reset</button>
      <span id="{cnt_id}" style="color:#8892a4;font-size:.75rem"></span>
    </div>
  </div>
  <table id="{tbl_id}" style="table-layout:fixed;width:100%">
    <thead><tr><th>Key</th><th>Summary</th><th>Type</th><th>Assignee</th><th>Status</th><th>Orig. Est.</th><th>Logged</th><th>Logged %</th></tr></thead>
    <tbody>{rows}</tbody>
  </table>
</div>\n"""

    # ── §12 Timeline header ────────────────────────────────────────────────
    def _sec_timeline_header(self) -> str:
        sw = self.m.get('sprintWindow', {})
        wd = len(self.m.get('workingDays', []))
        tot = sum(self.m.get('dailyTotals', []))
        pag = self.m.get('paginatedTickets', [])
        pag_note = ''
        if pag:
            pag_note = f'<span class="paginated-note">⚠ Paginated worklogs — timeline may be incomplete for: {h(", ".join(pag))}</span>'
        return f"""
<hr class="divider">
<div style="font-size:1.25rem;font-weight:700;color:#e2e8f0;margin-bottom:6px">⏱ Sprint Timeline — Hours Logged by Duration</div>
<div class="tl-intro">Sprint window: {h(sw.get('start','?'))} – {h(sw.get('end','?'))} · {wd} working days · {round(tot,1)}h total logged in-sprint {pag_note}</div>\n"""

    # ── §13 Daily burn + Burn-up ───────────────────────────────────────────
    def _sec_daily_burn(self) -> str:
        pu  = self.m.get('perUser', {})
        uda = self.m.get('userDailyArrays', {})
        active_users = [u for u in self.m.get('allUsers', []) if sum(uda.get(u, [])) > 0]
        days = self.m.get('dayLabels', [])
        cum  = self.m.get('cumulative', [])
        n    = len(days)
        ideal= [round(cum[-1] / max(n-1,1) * i, 2) for i in range(n)] if cum else []

        burn_id = self.cid('dailyBurn')
        up_id   = self.cid('burnUp')

        datasets_js = ',\n'.join(
            f'{{label:{json.dumps(u.split()[0])},data:{json.dumps(uda.get(u,[]))},backgroundColor:"{hex_alpha(user_color(u),.85)}",borderWidth:0,borderRadius:2}}'
            for u in active_users
        )
        self.js(f"""
new Chart(document.getElementById('{burn_id}'),{{
  type:'bar',
  data:{{labels:{json.dumps(days)},datasets:[{datasets_js}]}},
  options:{{responsive:true,maintainAspectRatio:false,
    plugins:{{legend:{{labels:{{color:'#8892a4',font:{{size:9}},boxWidth:10}},position:'bottom'}},tooltip:{{callbacks:{{label:c=>` ${{c.dataset.label}}: ${{c.raw}}h`}}}}}},
    scales:{{
      x:{{stacked:true,ticks:{{color:'#8892a4',font:{{size:8}},maxRotation:45}},grid:{{color:'#2e3250'}}}},
      y:{{stacked:true,ticks:{{color:'#8892a4',callback:v=>v+'h'}},grid:{{color:'#2e3250'}}}}
    }}
  }}
}});""")

        self.js(f"""
new Chart(document.getElementById('{up_id}'),{{
  type:'line',
  data:{{
    labels:{json.dumps(days)},
    datasets:[
      {{label:'Actual Logged',data:{json.dumps(cum)},borderColor:'#6366f1',backgroundColor:'rgba(99,102,241,.12)',fill:true,tension:.3,pointRadius:3,pointBackgroundColor:'#6366f1',borderWidth:2.5}},
      {{label:'Ideal Pace',data:{json.dumps(ideal)},borderColor:'#8892a4',borderDash:[5,4],backgroundColor:'transparent',fill:false,tension:0,pointRadius:0,borderWidth:1.5}}
    ]
  }},
  options:{{responsive:true,maintainAspectRatio:false,
    plugins:{{legend:{{labels:{{color:'#8892a4',font:{{size:10}}}}}},tooltip:{{callbacks:{{label:c=>` ${{c.dataset.label}}: ${{c.raw}}h`}}}}}},
    scales:{{
      x:{{ticks:{{color:'#8892a4',font:{{size:8}},maxRotation:45}},grid:{{color:'#2e3250'}}}},
      y:{{ticks:{{color:'#8892a4',callback:v=>v+'h'}},grid:{{color:'#2e3250'}}}}
    }}
  }}
}});""")

        return f"""
<div class="g2">
  <div class="card">
    <div class="stitle"><span>📅</span> Daily Hours Logged (Stacked by Team Member)</div>
    <div class="chart-wrap" style="height:280px"><canvas id="{burn_id}"></canvas></div>
  </div>
  <div class="card">
    <div class="stitle"><span>📈</span> Cumulative Burn-Up Over Sprint</div>
    <div class="chart-wrap" style="height:280px"><canvas id="{up_id}"></canvas></div>
  </div>
</div>\n"""

    # ── §14 Per-person daily heatmap ───────────────────────────────────────
    def _sec_person_heatmap(self) -> str:
        uda   = self.m.get('userDailyArrays', {})
        days  = self.m.get('dayLabels', [])
        users = [u for u in self.m.get('allUsers', []) if sum(uda.get(u, [])) > 0]

        def heat(val, max_val):
            if not val: return 'transparent'
            t = min(val / max_val, 1)
            r = round(99  + (239 - 99)  * t)
            g = round(102 + (68  - 102) * t)
            b = round(241 + (68  - 241) * t)
            return f'rgba({r},{g},{b},{0.2 + t * 0.75:.2f})'

        all_vals = [v for u in users for v in uda.get(u, []) if v > 0]
        max_val  = max(all_vals) if all_vals else 1

        head_cells = ''.join(
            f'<th style="padding:3px 4px;color:#8892a4;writing-mode:vertical-lr;transform:rotate(180deg);height:60px;font-size:.68rem;font-weight:500">{h(d)}</th>'
            for d in days
        )
        head = f'<tr><th style="text-align:left;padding:4px 8px;color:#8892a4;white-space:nowrap;min-width:120px;background:#1a1d27;position:sticky;left:0;z-index:2">Person</th>{head_cells}<th style="padding:3px 8px;color:#8892a4">Total</th></tr>'

        body = ''
        for u in users:
            daily  = uda.get(u, [])
            total  = round(sum(daily), 1)
            uc     = user_color(u)
            initials = ''.join(p[0] for p in u.split()[:2])
            cells  = ''.join(
                f'<td title="{h}h" style="text-align:center;padding:4px 2px;background:{heat(h, max_val)};color:{"#e2e8f0" if h>0 else "#3a3f55"};min-width:30px;border:1px solid #1a1d27;font-size:.7rem">{h if h >= 0.5 else ""}</td>'
                for h in daily
            )
            body += f'<tr data-user="{h(u)}"><td style="white-space:nowrap;padding:5px 8px;font-weight:600;color:#e2e8f0;background:#1a1d27;position:sticky;left:0;border-right:1px solid #2e3250"><span style="display:inline-block;width:10px;height:10px;border-radius:50%;background:{uc};margin-right:6px"></span>{h(u.split()[0]+" "+u.split()[1][0]+"." if len(u.split())>1 else u)}</td>{cells}<td style="text-align:right;padding:4px 8px;font-weight:700;color:#6366f1">{total}h</td></tr>'

        filter_id = f'personFilter_{self._cid}'
        self.js(f"""
(function(){{
  var sel = document.getElementById('{filter_id}');
  if(!sel) return;
  sel.addEventListener('change', function(){{
    var val = this.value;
    document.querySelectorAll('#personHeatTbl tr[data-user]').forEach(function(row){{
      row.style.display = (!val || row.getAttribute('data-user') === val) ? '' : 'none';
    }});
  }});
}})();""")

        # Tag body rows with data-user
        user_options = ''.join(f'<option value="{h(u)}">{h(u)}</option>'
                               for u in users if sum(uda.get(u, [])) > 0)

        return f"""
<div class="card gf">
  <div class="stitle"><span>🧑‍💻</span> Per-Person Daily Contribution (hours/day)</div>
  <div class="filter-bar">
    <label style="font-size:.78rem;color:#8892a4">Filter person:</label>
    <select id="{filter_id}" class="filter-select">
      <option value="">All team members</option>
      {user_options}
    </select>
    <button class="filter-reset" onclick="document.getElementById('{filter_id}').value='';document.querySelectorAll('#personHeatTbl tr[data-user]').forEach(r=>r.style.display='')">Reset</button>
  </div>
  <div style="overflow-x:auto"><table id="personHeatTbl" style="min-width:900px"><thead>{head}</thead><tbody>{body}</tbody></table></div>
</div>\n"""

    # ── §15 Per-ticket activity heatmap ────────────────────────────────────
    def _sec_ticket_heatmap(self) -> str:
        tickets = [t for t in self.m.get('tickets', []) if t.get('sprintTotal', 0) > 0]
        days    = self.m.get('dayLabels', [])

        all_vals = [v for t in tickets for v in t.get('dailyHours', []) if v > 0]
        max_val  = max(all_vals) if all_vals else 1

        def heat(val):
            if not val: return 'transparent'
            it = min(val / max_val, 1)
            r = round(99  + (239 - 99)  * it)
            g = round(102 + (68  - 102) * it)
            b = round(241 + (68  - 241) * it)
            return f'rgba({r},{g},{b},{0.2 + it * 0.75:.2f})'

        head_cells = ''.join(
            f'<th style="padding:3px 4px;color:#8892a4;writing-mode:vertical-lr;transform:rotate(180deg);height:60px;font-size:.68rem;font-weight:500">{h(d)}</th>'
            for d in days
        )
        head = (f'<tr>'
                f'<th style="text-align:left;padding:4px 8px;color:#8892a4;white-space:nowrap;min-width:110px;background:#1a1d27;position:sticky;left:0;z-index:2">Ticket</th>'
                f'<th style="padding:3px 8px;color:#8892a4;white-space:nowrap;background:#1a1d27;position:sticky;left:110px;z-index:2">Assignee</th>'
                f'{head_cells}'
                f'<th style="padding:3px 8px;color:#8892a4;white-space:nowrap">Sprint<br>Total</th>'
                f'<th style="padding:3px 8px;color:#8892a4">Status</th></tr>')

        body = ''
        sc_map = STATUS_COLORS
        for t in tickets:
            daily = t.get('dailyHours', [])
            cells = ''.join(
                f'<td title="{t["key"]} {days[i] if i<len(days) else ""}: {v}h" style="text-align:center;padding:4px 1px;background:{heat(v)};color:#e2e8f0;font-size:.68rem;min-width:28px;border:1px solid #1a1d27">{v if v >= 0.5 else ""}</td>'
                for i, v in enumerate(daily)
            )
            sc = sc_map.get(t['status'], '#8892a4')
            body += (f'<tr data-status="{h(t["status"])}">'
                     f'<td style="white-space:nowrap;padding:5px 8px;font-weight:600;color:#6366f1;background:#1a1d27;position:sticky;left:0;border-right:1px solid #2e3250"><a href="{h(t.get("webUrl","#"))}" target="_blank" style="color:#6366f1;text-decoration:none">{h(t["key"])}</a></td>'
                     f'<td style="white-space:nowrap;padding:5px 6px;font-size:.7rem;color:#c4c9d4;background:#1a1d27;position:sticky;left:110px;border-right:1px solid #2e3250">{h(t["assignee"][:12])}</td>'
                     f'{cells}'
                     f'<td style="text-align:right;padding:4px 8px;font-weight:700;color:#6366f1;white-space:nowrap">{t.get("sprintTotal",0)}h</td>'
                     f'<td style="padding:4px 6px;white-space:nowrap"><span style="display:inline-block;padding:2px 7px;border-radius:12px;font-size:.68rem;font-weight:600;background:{hex_alpha(sc,.13)};color:{sc};border:1px solid {hex_alpha(sc,.35)}">{h(t["status"])}</span></td>'
                     f'</tr>')

        tbl_id    = 'ticketHeatTbl'
        filt_id   = 'ticketFiltSel'
        statuses  = sorted({t['status'] for t in tickets})
        st_opts   = ''.join(f'<option value="{h(s)}">{h(s)}</option>' for s in statuses)

        self.js(f"""
(function(){{
  var sel = document.getElementById('{filt_id}');
  if(!sel) return;
  sel.addEventListener('change', function(){{
    var val = this.value;
    document.querySelectorAll('#{tbl_id} tr[data-status]').forEach(function(row){{
      row.style.display = (!val || row.getAttribute('data-status') === val) ? '' : 'none';
    }});
  }});
}})();""")

        return f"""
<div class="card gf">
  <div class="stitle"><span>🗓</span> Per-Ticket Activity Heatmap — Hours Logged Each Day</div>
  <div class="filter-bar">
    <span style="font-size:.75rem;color:#8892a4">Cell intensity = hours that day. Darker = more work.</span>
    <label style="font-size:.78rem;color:#8892a4;margin-left:auto">Filter status:</label>
    <select id="{filt_id}" class="filter-select">
      <option value="">All statuses</option>
      {st_opts}
    </select>
    <button class="filter-reset" onclick="document.getElementById('{filt_id}').value='';document.querySelectorAll('#{tbl_id} tr[data-status]').forEach(r=>r.style.display='')">Reset</button>
  </div>
  <div style="overflow-x:auto"><table id="{tbl_id}" style="min-width:900px;border-collapse:collapse"><thead>{head}</thead><tbody>{body}</tbody></table></div>
</div>\n"""

    # ── §16 Gantt ──────────────────────────────────────────────────────────
    def _sec_gantt(self) -> str:
        tickets  = [t for t in self.m.get('tickets', []) if t.get('firstDayIdx') is not None]
        tickets.sort(key=lambda t: t.get('firstDayIdx', 99))
        days     = self.m.get('dayLabels', [])
        cid_     = self.cid('ganttChart')

        height = max(len(tickets) * 22 + 60, 300)

        datasets_js = ',\n'.join(
            f'{{label:{json.dumps(t["key"])},data:[{{x:[{t["firstDayIdx"]},{t["lastDayIdx"]+0.9}],y:{json.dumps(t["key"]+" — "+t["summary"][:35])}}}],backgroundColor:"{hex_alpha(status_color(t["status"]), .75)}",borderColor:"{status_color(t["status"])}",borderWidth:1,borderSkipped:false,borderRadius:3,barThickness:14}}'
            for t in tickets
        )
        days_js = json.dumps(days)
        n = len(days)

        self.js(f"""
new Chart(document.getElementById('{cid_}'),{{
  type:'bar',
  data:{{datasets:[{datasets_js}]}},
  options:{{
    indexAxis:'y',responsive:true,maintainAspectRatio:false,
    plugins:{{
      legend:{{display:false}},
      tooltip:{{callbacks:{{
        title:ctx=>ctx[0]?.dataset?.label||'',
        label:ctx=>{{
          const x=ctx.raw.x;
          return ` Active: Day ${{Math.round(x[0])+1}} → Day ${{Math.round(x[1])+1}} · Sprint total: ${{ctx.raw.y}}h`;
        }}
      }}}}
    }},
    scales:{{
      x:{{type:'linear',min:0,max:{n},ticks:{{color:'#8892a4',font:{{size:9}},callback:v=>{days_js}[Math.round(v)]||''}},grid:{{color:'#2e3250'}}}},
      y:{{ticks:{{color:'#c4c9d4',font:{{size:9}}}},grid:{{color:'#1e2235'}}}}
    }}
  }}
}});"""
)

        return f"""
<div class="card gf">
  <div class="stitle"><span>📊</span> Per-Ticket Duration Bar — When Was Each Ticket Active?</div>
  <div class="chart-wrap" style="height:{height}px"><canvas id="{cid_}"></canvas></div>
</div>\n"""


# ── CLI entry point ────────────────────────────────────────────────────────────────────────────
def main():
    parser = argparse.ArgumentParser(description='Build Sprint Health Dashboard HTML')
    parser.add_argument('--metrics', required=True, help='Path to sprint_metrics.json')
    parser.add_argument('--output',  required=True, help='Output HTML file path')
    parser.add_argument('--depth',   default='full',
                        choices=['quick', 'standard', 'full'],
                        help='Dashboard depth (default: full)')
    parser.add_argument('--focus',   default='',
                        help='Comma-separated focus areas: health,workload,timeline,retro (default: all)')
    parser.add_argument('--insights', default='', help='Path to all_insights.json (optional)')
    parser.add_argument('--compare',  default='', help='Path to sprint_trend.json (optional)')
    args = parser.parse_args()

    with open(args.metrics) as f:
        metrics = json.load(f)

    focus = [x.strip() for x in args.focus.split(',') if x.strip()]

    # Cleanup: remove previous sprint files to free disk space
    import glob, os as _os
    sprint_id_str = str(metrics.get('sprintId', ''))
    if sprint_id_str:
        out_dir = _os.path.dirname(_os.path.abspath(args.output))
        patterns = [
            f'sprint{sprint_id_str}_*.html',
            f'sprint{sprint_id_str}_*_insights.json',
            f'sprint{sprint_id_str}_all_insights.json',
        ]
        removed = []
        for pat in patterns:
            for fp in glob.glob(_os.path.join(out_dir, pat)):
                if fp != args.output:   # don't delete the file we're about to write
                    try:
                        _os.remove(fp)
                        removed.append(_os.path.basename(fp))
                    except OSError:
                        pass
        if removed:
            print(f"  🗑  Cleaned up {len(removed)} previous file(s): {', '.join(removed)}")
    compare = {}
    if args.compare and __import__('os').path.exists(args.compare):
        with open(args.compare) as f:
            compare = __import__('json').load(f)
        print(f"  Loaded trend/comparison data from {args.compare}")
    builder = DashboardBuilder(metrics, args.depth, focus, compare=compare)
    html    = builder.build()

    with open(args.output, 'w', encoding='utf-8') as f:
        f.write(html)

    sections = resolve_sections(args.depth, focus)
    mode_str = args.depth + ('[' + ','.join(focus) + ']' if focus else ' [all]')
    print(f'\u2713 {mode_str} dashboard \u2192 {args.output}')
    print(f'  Sections: {", ".join(sections)}')
    print(f'  File size: {len(html):,} chars (~{len(html)//4:,} tokens output saved)')


if __name__ == '__main__':
    main()
