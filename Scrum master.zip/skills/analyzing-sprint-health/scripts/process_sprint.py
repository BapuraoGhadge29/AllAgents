#!/usr/bin/env python3
"""
process_sprint.py  —  Sprint Health Dashboard: data extraction + metric computation.

Usage:
    python3 process_sprint.py --input <jira_result.json> --output <metrics.json> --sprint-id <id>

Input:  Raw JSON file saved by the Jira MCP searchJiraIssuesUsingJql tool.
        Accepted: {"issues": [...]}, {"issues": {"nodes": [...]}}, either wrapped in
        {"data": ...} and/or the persisted-output list [{"type": "text", "text": ...}].
        Custom fields may be top-level customfield_* keys or under fields.customFields.

Output: sprint_metrics.json consumed by build_dashboard.py.
"""

import argparse
import json
import datetime
import os
from collections import defaultdict

TEAM_IDS_PATH = os.path.join(os.path.dirname(__file__), '..', 'references', 'team-ids.json')

# ── Status categories ───────────────────────────────────────────────────────
DONE_STATUSES        = {'Resolved', 'Closed', 'Checked by QA', 'Cannot Test', 'Done'}
WIP_STATUSES         = {'In Progress', 'Testing', 'Reopened'}
NOT_STARTED_STATUSES = {'Open', 'To Do', 'Backlog'}

# ── Estimation thresholds ────────────────────────────────────────────────────
UNDEREST_THRESHOLD = 1.30   # spent > 130 % of estimate
OVEREST_THRESHOLD  = 0.70   # spent <  70 % of estimate


def status_category(status_name: str) -> str:
    if status_name in DONE_STATUSES:
        return 'done'
    if status_name in WIP_STATUSES:
        return 'wip'
    return 'not_started'


def secs_to_h(s: float) -> float:
    return round(s / 3600, 2)


def get_working_days(start_iso: str, end_iso: str) -> list[str]:
    days, d = [], datetime.date.fromisoformat(start_iso)
    end = datetime.date.fromisoformat(end_iso)
    while d <= end:
        if d.weekday() < 5:
            days.append(str(d))
        d += datetime.timedelta(days=1)
    return days


def infer_sprint_window(all_dates: list[str]) -> tuple[str, str]:
    """
    Guess sprint start from worklog dates.
    Strategy: find the first date of the 4-week streak with the most total hours.
    Falls back to earliest date with >2 h logged if streak detection fails.
    """
    if not all_dates:
        return ('', '')

    # Count hours per date
    from collections import Counter
    date_counts: dict = {}
    # all_dates is a flat list with repetitions → count occurrences as proxy for hours
    for d in all_dates:
        date_counts[d] = date_counts.get(d, 0) + 1

    sorted_dates = sorted(date_counts)
    if not sorted_dates:
        return ('', '')

    # Find 20-working-day window with highest total activity
    windows = []
    for i, start in enumerate(sorted_dates):
        wdays = get_working_days(start, sorted_dates[-1])[:23]  # ~1 sprint
        if len(wdays) >= 5:
            total = sum(date_counts.get(d, 0) for d in wdays)
            windows.append((total, start, wdays[-1]))

    if windows:
        windows.sort(reverse=True)
        _, best_start, best_end = windows[0]
        return (best_start, best_end)

    return (sorted_dates[0], sorted_dates[-1])


def resolve_team(tickets_raw: list, team_ids_path: str = TEAM_IDS_PATH) -> tuple[dict | None, str | None]:
    """
    Resolve the sprint's Maxxton Team from customfield_10049 across all tickets.

    Returns (team, warning) where exactly one is None. `team` is
    {"id": "<id>", "name": "<name>"}. Resolution is keyed off the field's `.id`
    (not the free-text `.value` Jira returns) against the canonical team-ids.json
    table, since dropdown labels can drift while IDs stay stable. A sprint is
    assumed to belong to one team — ties in a multi-team sprint break to the
    first ID encountered.
    """
    from collections import Counter
    ids = []
    for t in tickets_raw:
        cf = t.get('fields', {}).get('customfield_10049')
        if isinstance(cf, dict) and cf.get('id'):
            ids.append(str(cf['id']))

    if not ids:
        return None, ('No ticket in this sprint has the Maxxton Team field '
                       '(customfield_10049) set.')

    # Counter.most_common(n) delegates to heapq.nlargest, whose tie-break order
    # isn't a hard cross-version/implementation guarantee — pick the first id
    # (in encounter order) at the max count explicitly, matching the docstring.
    counts = Counter(ids)
    max_count = max(counts.values())
    majority_id = next(i for i in ids if counts[i] == max_count)

    try:
        with open(team_ids_path, encoding='utf-8') as f:
            team_ids = json.load(f)
    except (OSError, json.JSONDecodeError):
        return None, f'Could not load team ID table at {team_ids_path}.'

    name = team_ids.get(majority_id)
    if not name:
        return None, (f'Maxxton Team id {majority_id} is not in the team ID table '
                       f'({team_ids_path}) — it may be new or renamed; update the table.')

    return {'id': majority_id, 'name': name}, None


def normalize_fields(issue: dict) -> None:
    """Flatten the Atlassian MCP `view: "full"` shape in place.

    That view returns custom fields as
    ``fields.customFields = {"Sprint": {"id": "customfield_10020", "value": [...]}}``
    instead of top-level ``customfield_*`` keys. Copy each value to its
    ``customfield_*`` key so the rest of the script reads one shape.
    """
    f = issue.setdefault('fields', {})
    for cf in (f.pop('customFields', None) or {}).values():
        if isinstance(cf, dict) and cf.get('id') and cf['id'] not in f:
            f[cf['id']] = cf.get('value')


def is_app_author(author: dict) -> bool:
    """True when a worklog author is an app account (e.g. Timesheets by Tempo).

    Tempo stores worklogs in its own backend and syncs them into Jira under its
    app account, so the Jira author is never the person who logged the time.
    """
    return (author or {}).get('accountType') == 'app'


def extract_metrics(raw_path: str, sprint_id: str, extract_worklog_dates: bool = True,
                     resolve_team_field: bool = False) -> dict:
    with open(raw_path, encoding='utf-8') as f:
        raw = json.load(f)

    # Unwrap MCP envelopes: persisted-output list and the {"data": {...}} wrapper.
    if isinstance(raw, list) and raw and isinstance(raw[0], dict) and 'text' in raw[0]:
        raw = json.loads(raw[0]['text'])
    if isinstance(raw, dict) and 'issues' not in raw and isinstance(raw.get('data'), dict):
        raw = raw['data']

    # Handle two Jira MCP response shapes:
    #   Shape A (older): {"issues": {"totalCount": N, "nodes": [...]}}
    #   Shape B (newer): {"issues": [...], "isLast": true}
    issues_val = raw['issues']
    if isinstance(issues_val, list):
        tickets_raw = issues_val                  # Shape B
    else:
        tickets_raw = issues_val.get('nodes', []) # Shape A
    for t in tickets_raw:
        normalize_fields(t)
    app_attributed_h = 0.0

    # ── Per-ticket data extraction ────────────────────────────────────────────
    tickets = []
    all_wl_dates: list[str] = []

    for t in tickets_raw:
        f = t['fields']
        key       = t['key']
        summary   = f.get('summary', '')
        status    = f['status']['name']
        issue_type = f['issuetype']['name']
        assignee  = (f.get('assignee') or {}).get('displayName', 'Unassigned')
        priority  = (f.get('priority') or {}).get('name', '')
        orig_est  = f.get('timeoriginalestimate') or 0
        timespent = f.get('timespent') or 0
        resolution    = (f.get('resolution') or {}).get('name', 'Unresolved')

        # Story points — try multiple field names
        story_points  = (f.get('customfield_10016') or
                         f.get('customfield_10028') or
                         f.get('story_points') or 0)
        if isinstance(story_points, dict):
            story_points = story_points.get('value', 0) or 0

        # Sprint history — number of sprints this ticket has been in
        sprint_field  = f.get('customfield_10020') or []
        sprint_count  = len(sprint_field) if isinstance(sprint_field, list) else 0
        chronic       = sprint_count >= 3   # chronic carry-over

        # Creation date (for scope creep detection)
        created_date  = (f.get('created') or '')[:10]

        wl_block   = f.get('worklog', {}) or {}
        wl_total   = wl_block.get('total', 0)
        wl_entries = wl_block.get('worklogs', []) or []
        paginated  = wl_total > len(wl_entries)


        worklogs = []
        for wl in wl_entries:
            started = wl.get('started', '')
            date    = started[:10] if started else ''
            secs    = wl.get('timeSpentSeconds', 0)
            author_obj = wl.get('author') or {}
            if is_app_author(author_obj):
                # Real author is not in Jira — credit the ticket assignee.
                author = assignee
                app_attributed_h += secs / 3600
            else:
                author = author_obj.get('displayName', 'Unknown')
            if date and extract_worklog_dates:
                all_wl_dates.append(date)
            worklogs.append({'id': wl.get('id', ''), 'date': date if extract_worklog_dates else '', 'hours': round(secs / 3600, 2), 'author': author})

        tickets.append({
            'key': key,
            'summary': summary,
            'status': status,
            'statusCategory': status_category(status),
            'issuetype': issue_type,
            'assignee': assignee,
            'priority': priority,
            'origEst': orig_est,
            'origEstH': secs_to_h(orig_est),
            'timeSpent': timespent,
            'timeSpentH': secs_to_h(timespent),
            'resolution': resolution,
            'wlTotal': wl_total,
            'wlReturned': len(wl_entries),
            'paginated': paginated,
            'worklogs':    worklogs,
            'webUrl':      t.get('webUrl', f'https://maxxton.atlassian.net/browse/{key}'),
            'storyPoints': float(story_points) if story_points else 0,
            'sprintCount': sprint_count,
            'chronic':     chronic,
            'createdDate': created_date,
        })

    # ── Carry-over: tickets also in a sprint that started after this one ──
    # Jira moves unfinished issues to the next sprint on close and leaves done
    # ones behind, so a later sprint in customfield_10020 means the ticket was
    # NOT done at this sprint's close — whatever its status is today.
    sprint_id_num = int(sprint_id) if str(sprint_id).isdigit() else None
    this_start = ''
    for tr in tickets_raw:
        for e in (tr.get('fields', {}).get('customfield_10020') or []):
            if isinstance(e, dict) and e.get('id') == sprint_id_num:
                this_start = e.get('startDate') or ''
                break
        if this_start:
            break
    carried_over = []
    if this_start:
        for t, tr in zip(tickets, tickets_raw):
            later = [e for e in (tr.get('fields', {}).get('customfield_10020') or [])
                     if isinstance(e, dict) and (e.get('startDate') or '') > this_start]
            if later:
                t['carriedOver']    = True
                t['currentStatus']  = t['status']
                t['status']         = 'Carried over'
                t['statusCategory'] = 'wip' if t['timeSpent'] else 'not_started'
                carried_over.append(t)

    # ── Quality signals ──────────────────────────────────────────────────────
    reopened_tickets  = [t for t in tickets if t.get('currentStatus', t['status']) == 'Reopened']
    blocked_tickets   = [t for t in tickets
                         if t.get('currentStatus', t['status']) in ('Blocked', 'On Hold')
                         or (t['timeSpent'] == 0 and t['statusCategory'] == 'wip')]
    chronic_tickets   = [t for t in tickets if t['chronic']]

    # ── Auto-extract sprint metadata from ticket sprint field ────────────────
    auto_meta = {}
    sprint_id_int = int(sprint_id) if str(sprint_id).isdigit() else None
    for t in tickets_raw:
        cf = (t.get('fields', {}).get('customfield_10020') or [])
        if isinstance(cf, list):
            for entry in cf:
                if isinstance(entry, dict) and entry.get('id') == sprint_id_int:
                    auto_meta = {
                        'name':      entry.get('name', ''),
                        'goal':      entry.get('goal', ''),
                        'startDate': (entry.get('startDate') or '')[:10],
                        'endDate':   (entry.get('endDate') or '')[:10],
                        'state':     entry.get('state', ''),
                    }
                    break
        if auto_meta:
            break

    # ── Sprint window ─────────────────────────────────────────────────────────
    sprint_start, sprint_end = infer_sprint_window(all_wl_dates)
    # Official dates from customfield_10020 win; inference is only a fallback
    # (it drifts badly when carry-over tickets bring older worklogs along).
    if auto_meta.get('startDate') and auto_meta.get('endDate'):
        sprint_start, sprint_end = auto_meta['startDate'], auto_meta['endDate']
    if not sprint_end:
        # Fall back to sprint meta dates — available for all modes, including
        # health/retro where worklog dates are not extracted (needs_dates=False).
        sprint_start = auto_meta.get('startDate', '') or sprint_start
        sprint_end   = auto_meta.get('endDate', '') or ''
    if not sprint_end:
        today = str(datetime.date.today())
        sprint_start = sprint_start or today
        sprint_end   = today

    working_days = get_working_days(sprint_start, sprint_end)

    # ── Scope creep — tickets added mid-sprint ───────────────────────────────
    # Prefer the authoritative sprint start date from Jira (auto_meta) over the
    # inferred date from worklog activity, which can drift from the real start.
    scope_creep_ref = auto_meta.get('startDate') or sprint_start
    scope_creep = [t for t in tickets
                   if t['createdDate'] and scope_creep_ref
                   and t['createdDate'] > scope_creep_ref]
    scope_creep_est_h = round(sum(t['origEstH'] for t in scope_creep), 1)

    # ── Sprint-window worklog filter ──────────────────────────────────────────
    def in_sprint(date: str) -> bool:
        return sprint_start <= date <= sprint_end

    # ── High-level counts ─────────────────────────────────────────────────────
    done             = [t for t in tickets if t['statusCategory'] == 'done']
    wip              = [t for t in tickets if t['statusCategory'] == 'wip']
    untouched        = [t for t in tickets if t['timeSpent'] == 0]
    spillover        = [t for t in tickets if t['statusCategory'] in ('wip', 'not_started')]
    # Touched spillover excludes untouched tickets to avoid double-counting in
    # the Focus health score (untouched is already its own penalty term).
    touched_spillover = [t for t in spillover if t['timeSpent'] > 0]

    total_orig    = sum(t['origEst']   for t in tickets)
    total_spent   = sum(t['timeSpent'] for t in tickets)
    done_orig     = sum(t['origEst']   for t in done)
    done_spent    = sum(t['timeSpent'] for t in done)

    velocity_ratio = round(len(done) / len(tickets), 3) if tickets else 0
    overrun_pct    = round((total_spent - total_orig) / total_orig * 100, 1) if total_orig else None

    total_sp       = sum(t['storyPoints'] for t in tickets)
    done_sp        = sum(t['storyPoints'] for t in done)
    sp_velocity    = round(done_sp / total_sp * 100, 1) if total_sp > 0 else None

    # ── Estimation accuracy ───────────────────────────────────────────────────
    for t in tickets:
        if t['origEst'] > 0 and t['timeSpent'] > 0:
            ratio = t['timeSpent'] / t['origEst']
            t['estRatio'] = round(ratio, 2)
            if ratio > UNDEREST_THRESHOLD:
                t['estCategory'] = 'underestimated'
            elif ratio < OVEREST_THRESHOLD:
                t['estCategory'] = 'overestimated'
            else:
                t['estCategory'] = 'accurate'
        elif t['timeSpent'] == 0:
            t['estRatio'] = 0
            t['estCategory'] = 'untouched'
        else:
            t['estRatio'] = None
            t['estCategory'] = 'no_estimate'

    underest = sorted([t for t in tickets if t['estCategory'] == 'underestimated'],
                      key=lambda t: -(t['timeSpent'] - t['origEst']))
    overest  = sorted([t for t in tickets if t['estCategory'] == 'overestimated'],
                      key=lambda t: t['estRatio'] or 1)

    # ── Per-user summary ──────────────────────────────────────────────────────
    user_assigned: dict = defaultdict(lambda: {'origEstH': 0, 'timeSpentH': 0, 'tickets': 0})
    for t in tickets:
        u = t['assignee']
        user_assigned[u]['origEstH']   += t['origEstH']
        user_assigned[u]['timeSpentH'] += t['timeSpentH']
        user_assigned[u]['tickets']    += 1

    # Worklogs by author (who actually logged time, may differ from assignee)
    user_logged: dict = defaultdict(float)
    for t in tickets:
        for wl in t['worklogs']:
            user_logged[wl['author']] += wl['hours']

    per_user = {}
    all_users = sorted(set(list(user_assigned.keys()) + list(user_logged.keys())))
    for u in all_users:
        assigned = user_assigned.get(u, {})
        per_user[u] = {
            'origEstH':   round(assigned.get('origEstH', 0), 2),
            'timeSpentH': round(assigned.get('timeSpentH', 0), 2),
            'loggedH':    round(user_logged.get(u, 0), 2),
            'tickets':    assigned.get('tickets', 0),
        }

    # ── Daily timeline (sprint window only) ───────────────────────────────────
    daily_totals: dict = defaultdict(float)
    user_daily:   dict = defaultdict(lambda: defaultdict(float))
    ticket_daily: dict = defaultdict(lambda: defaultdict(float))

    for t in tickets:
        for wl in t['worklogs']:
            d = wl['date']
            if d and in_sprint(d):
                daily_totals[d]            += wl['hours']
                user_daily[wl['author']][d] += wl['hours']
                ticket_daily[t['key']][d]   += wl['hours']

    # Ordered daily arrays
    day_labels  = []
    days_iso    = []
    daily_arr   = []
    cumulative  = []
    running     = 0
    weekday_names = ['Mon','Tue','Wed','Thu','Fri']
    for d in working_days:
        dt = datetime.date.fromisoformat(d)
        h  = round(daily_totals.get(d, 0), 2)
        day_labels.append(f"{weekday_names[dt.weekday()]} {dt.day}/{dt.month}")
        days_iso.append(d)
        daily_arr.append(h)
        running += h
        cumulative.append(round(running, 2))

    # User daily arrays (same order as working_days)
    user_daily_arrays: dict = {}
    for u in all_users:
        user_daily_arrays[u] = [round(user_daily[u].get(d, 0), 2) for d in working_days]

    # Ticket daily arrays
    sprint_ticket_totals = {k: round(sum(ticket_daily[k].values()), 1)
                            for k in ticket_daily}

    tickets_with_daily = []
    for t in sorted(tickets, key=lambda x: -sprint_ticket_totals.get(x['key'], 0)):
        daily = [round(ticket_daily[t['key']].get(d, 0), 2) for d in working_days]
        sprint_total = round(sum(daily), 1)
        active_days  = [i for i, h in enumerate(daily) if h > 0]
        tickets_with_daily.append({
            **t,
            'dailyHours':   daily,
            'sprintTotal':  sprint_total,
            'firstDayIdx':  active_days[0]  if active_days else None,
            'lastDayIdx':   active_days[-1] if active_days else None,
        })

    # ── Status breakdown counts ───────────────────────────────────────────────
    from collections import Counter
    status_counts = dict(Counter(t['status'] for t in tickets).most_common())
    type_counts   = dict(Counter(t['issuetype'] for t in tickets).most_common())

    # ── Worst overruns ────────────────────────────────────────────────────────
    worst = sorted([t for t in tickets if t['origEst'] > 0],
                   key=lambda t: -(t['timeSpent'] - t['origEst']))[:3]

    # ── Paginated tickets warning ─────────────────────────────────────────────
    paginated_tickets = [t['key'] for t in tickets if t['paginated']]
    account_ids = list({t.get('assigneeAccountId','') for t in tickets if t.get('assigneeAccountId')})

    # ── Maxxton Team (only resolved for standard/full depth — see caller) ────
    team, team_warning = resolve_team(tickets_raw) if resolve_team_field else (None, None)

    # ── Assemble output ───────────────────────────────────────────────────────
    return {
        'sprintId': sprint_id,
        'generatedAt': str(datetime.date.today()),
        'sprintWindow': {'start': sprint_start, 'end': sprint_end},
        'workingDays': working_days,
        'dayLabels': day_labels,
        'daysIso': days_iso,

        'summary': {
            'totalTickets':    len(tickets),
            'completedCount':  len(done),
            'wipCount':        len(wip),
            'untouchedCount':  len(untouched),
            'spilloverCount':        len(spillover),
            'touchedSpilloverCount': len(touched_spillover),
            'velocityRatio':   velocity_ratio,
            'completionPct':   round(velocity_ratio * 100, 1),
            'totalOrigEstH':   round(secs_to_h(total_orig),  1),
            'totalLoggedH':    round(secs_to_h(total_spent), 1),
            'doneOrigEstH':    round(secs_to_h(done_orig),   1),
            'doneLoggedH':     round(secs_to_h(done_spent),  1),
            'overrunPct':      overrun_pct,
        },

        'statusCounts': status_counts,
        'typeCounts':   type_counts,

        'tickets':          tickets_with_daily,
        'spilloverTickets': [t for t in tickets_with_daily if t['statusCategory'] != 'done'],
        'untouchedTickets': [t for t in tickets if t['timeSpent'] == 0],
        'underestimated':   underest,
        'overestimated':    overest,
        'worstOverruns':    worst,

        'perUser':            per_user,
        'allUsers':           all_users,
        'userDailyArrays':    user_daily_arrays,

        'dailyTotals':  daily_arr,
        'cumulative':   cumulative,

        'paginatedTickets': paginated_tickets,
        'carriedOverCount': len(carried_over),
        'appAttributedH':   round(app_attributed_h, 1),
        'sprintMeta':      auto_meta or None,

        'storyPoints': {
            'total':    round(total_sp, 1),
            'done':     round(done_sp, 1),
            'velocity': sp_velocity,
        },
        'qualitySignals': {
            'reopenedTickets':  [{'key': t['key'], 'summary': t['summary'][:60], 'assignee': t['assignee']} for t in reopened_tickets],
            'blockedTickets':   [{'key': t['key'], 'summary': t['summary'][:60], 'status': t.get('currentStatus', t['status']), 'origEstH': t['origEstH']} for t in blocked_tickets[:5]],
            'chronicTickets':   [{'key': t['key'], 'summary': t['summary'][:60], 'sprintCount': t['sprintCount'], 'status': t['status']} for t in sorted(chronic_tickets, key=lambda x: -x['sprintCount'])[:5]],
        },
        'scopeCreep': {
            'tickets':  [{'key': t['key'], 'summary': t['summary'][:60], 'createdDate': t['createdDate'], 'origEstH': t['origEstH']} for t in scope_creep[:5]],
            'count':    len(scope_creep),
            'estH':     scope_creep_est_h,
            'pctOfEst': round(scope_creep_est_h / secs_to_h(total_orig) * 100, 1) if total_orig else 0,
        },

        **({'team': team, 'teamWarning': team_warning} if resolve_team_field else {}),
    }


def main():
    parser = argparse.ArgumentParser(description='Process Jira sprint data into dashboard metrics')
    parser.add_argument('--input',     required=True, help='Path to raw Jira JSON file')
    parser.add_argument('--output',    required=True, help='Output path for sprint_metrics.json')
    parser.add_argument('--sprint-id', required=True, help='Sprint ID (for labelling)')
    parser.add_argument('--sprint-meta', default='', help='JSON sprint metadata from Jira agile API')
    parser.add_argument('--force', action='store_true', help='Re-process even if cached output exists')
    parser.add_argument('--mode', default='full',
                        choices=['quick', 'health', 'retro', 'workload', 'timeline', 'full'],
                        help='Dashboard mode — controls whether worklog dates are extracted '
                             '(only needed for timeline/workload/full). Default: full')
    args = parser.parse_args()

    # ── Staleness / caching check ─────────────────────────────────────────
    import os as _os
    if _os.path.exists(args.output) and not args.force:
        meta_str = args.sprint_meta or '{}'
        try:
            _meta  = json.loads(meta_str)
            state  = _meta.get('state', 'closed')
            end_dt = (_meta.get('endDate') or '')[:10]
            today  = str(datetime.date.today())
            active = (state == 'active') or (end_dt and end_dt >= today)
            if not active:
                print(f"  ✓ Using cached metrics (sprint ended {end_dt}). Pass --force to refresh.")
                if meta_str != '{}':
                    with open(args.output) as _f:
                        _cached = json.load(_f)
                    _cached['sprintMeta'] = _meta
                    with open(args.output, 'w') as _f:
                        json.dump(_cached, _f, indent=2)
                import sys; sys.exit(0)
            else:
                print(f"  ⟳ Sprint still active — re-processing (ignore cache with --force)")
        except Exception:
            pass  # can't parse meta — proceed normally

    needs_dates = args.mode in ('timeline', 'workload', 'full')
    resolve_team_field = args.mode != 'quick'
    metrics = extract_metrics(args.input, args.sprint_id, extract_worklog_dates=needs_dates,
                               resolve_team_field=resolve_team_field)

    # Inject sprint meta (goal, official dates, state) if provided.
    # Merge: auto-extracted meta fills gaps, caller-supplied values take precedence.
    if args.sprint_meta:
        try:
            provided = json.loads(args.sprint_meta)
            auto = metrics.get('sprintMeta') or {}
            metrics['sprintMeta'] = {**auto, **provided}
        except Exception:
            pass
    with open(args.output, 'w') as f:
        json.dump(metrics, f, indent=2)

    s = metrics['summary']
    print(f"✓ Sprint {args.sprint_id}: {s['totalTickets']} tickets, "
          f"{s['completedCount']} done ({s['completionPct']}%), "
          f"{s['totalOrigEstH']}h est → {s['totalLoggedH']}h logged "
          f"({'+' if s['overrunPct'] and s['overrunPct']>0 else ''}{s['overrunPct']}%)")
    print(f"  Underestimated: {len(metrics['underestimated'])}  "
          f"Overestimated: {len(metrics['overestimated'])}  "
          f"Untouched: {s['untouchedCount']}")
    print(f"  Sprint window: {metrics['sprintWindow']['start']} -> {metrics['sprintWindow']['end']}  ({len(metrics['workingDays'])} working days)")

    if metrics['carriedOverCount']:
        print(f"  Carried over to a later sprint (counted as not done): {metrics['carriedOverCount']}")
    if metrics['appAttributedH']:
        print(f"  App-synced (Tempo) worklogs credited to assignees: {metrics['appAttributedH']}h")
    if metrics['paginatedTickets']:
        print(f"  ⚠ Paginated: {', '.join(metrics['paginatedTickets'])}")
    if resolve_team_field:
        if metrics.get('team'):
            print(f"  Team: {metrics['team']['name']} (id {metrics['team']['id']})")
        else:
            print(f"  ⚠ Team unresolved: {metrics.get('teamWarning')}")
    print(f"✓ Saved to {args.output}")


if __name__ == '__main__':
    main()
