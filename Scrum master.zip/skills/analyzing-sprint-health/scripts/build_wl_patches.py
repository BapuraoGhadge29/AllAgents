#!/usr/bin/env python3
"""
build_wl_patches.py — Build a worklog patches JSON from getJiraIssue result files.

After the coordinator fetches full worklog history for paginated tickets via
getJiraIssue, it passes the result file paths here. This script extracts all
worklog entries and writes a patches JSON consumed by patch_worklogs.py.

Usage:
    python3 build_wl_patches.py \\
        --ticket-files MXTS-71637.json MXTS-72341.json \\
        --output       sprint14783_wl_patches.json

ticket-files: each is a raw getJiraIssue result file (the MCP tool saves to disk
              when the response is too large for context, otherwise pass the file
              you write from inline JSON).

Expected JSON shape per file (all MCP response shapes handled):
  Shape A: {"issues": {"nodes": [{"key": "MXTS-xxx", "fields": {"worklog": {...}}}]}}
  Shape B: {"issues": [{"key": "MXTS-xxx", "fields": {"worklog": {...}}}]}
  Shape C: {"key": "MXTS-xxx", "fields": {"worklog": {...}}}   ← single issue
  Shape D: [{"type": "text", "text": "<json string>"}]         ← MCP persisted-output wrapper
"""

import argparse, json, os
from typing import Optional


def extract_issue(raw: dict) -> Optional[dict]:
    """Return a single issue object from whatever response shape was returned."""
    if 'key' in raw and 'fields' in raw:
        return raw                                     # Shape C — direct issue

    issues = raw.get('issues', [])
    if isinstance(issues, list) and issues:
        return issues[0]                               # Shape B

    if isinstance(issues, dict):
        nodes = issues.get('nodes', [])
        if nodes:
            return nodes[0]                            # Shape A

    return None


def extract_worklogs(issue: dict) -> list:
    """Return all worklog entries from an issue."""
    wl_block = (issue.get('fields', {}).get('worklog', {}) or {})
    return wl_block.get('worklogs', []) or []


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--ticket-files', nargs='+', required=True,
                        help='One or more getJiraIssue result files (JSON)')
    parser.add_argument('--output', required=True,
                        help='Output patches JSON path')
    args = parser.parse_args()

    patches = {}   # { ticket_key: [worklog_entry, ...] }

    for fpath in args.ticket_files:
        if not os.path.exists(fpath):
            print(f"  ⚠ File not found, skipping: {fpath}")
            continue

        with open(fpath) as f:
            raw = json.load(f)

        # Unwrap MCP persisted-output format: [{"type": "text", "text": "<json>"}]
        if isinstance(raw, list):
            try:
                raw = json.loads(raw[0]['text'])
            except (IndexError, KeyError, json.JSONDecodeError, TypeError):
                print(f"  ⚠ Cannot parse persisted-output wrapper in {fpath}, skipping")
                continue

        issue = extract_issue(raw)
        if not issue:
            print(f"  ⚠ No issue found in {fpath}, skipping")
            continue

        key      = issue.get('key', os.path.splitext(os.path.basename(fpath))[0])
        worklogs = extract_worklogs(issue)

        if not worklogs:
            print(f"  ⚠ {key}: 0 worklogs returned (already fully paginated?)")
            continue

        patches[key] = worklogs
        total_h = round(sum(w.get('timeSpentSeconds', 0) for w in worklogs) / 3600, 1)
        print(f"  ✓ {key}: {len(worklogs)} worklog entries ({total_h}h)")

    if not patches:
        print("No patches to write — all files were empty or missing.")
        return

    with open(args.output, 'w') as f:
        json.dump(patches, f, indent=2)

    total_entries = sum(len(v) for v in patches.values())
    print(f"✓ Wrote patches for {len(patches)} ticket(s), "
          f"{total_entries} total worklog entries → {args.output}")


if __name__ == '__main__':
    main()
