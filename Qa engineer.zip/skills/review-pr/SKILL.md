---
name: review-pr
description: Reviews and merges a GitHub pull request containing Playwright test scripts. Checks for selector quality, test structure, coverage completeness, and naming conventions before approving. Use when reviewing and merging a Playwright spec PR.
disable-model-invocation: true
argument-hint: "[PR number or URL]"
allowed-tools:
- mcp__claude_ai_GitHub__pull_request_read
- mcp__claude_ai_GitHub__get_file_contents
- mcp__claude_ai_GitHub__search_code
- mcp__claude_ai_GitHub__pull_request_review_write
- mcp__claude_ai_GitHub__merge_pull_request
- mcp__claude_ai_GitHub__add_issue_comment
- Agent
---

# Review PR

Reviews a GitHub pull request containing Playwright test scripts for quality, structure, and coverage completeness — then merges if it passes all checks.

> **Standalone skill for reviewing and merging.** The `/test-ticket` orchestrator creates a spec PR in Phase 6, in `MaxxtonGroup/mxts-qa-automation` for MXTS URLs or `MaxxtonGroup/mcms-qa-automation` for MCMS/CMS URLs (see "Target repo detection" in that skill's SKILL.md). Use this skill to review and merge it — or use it directly if you committed a spec manually.

## Step 1: Fetch the Pull Request and Check Eligibility

**Resolve `owner`/`repo` before calling anything.** `/test-ticket` opens spec PRs in two different repos — `MaxxtonGroup/mxts-qa-automation` or `MaxxtonGroup/mcms-qa-automation`, depending on the story's URL (see "Target repo detection" above) — so a bare PR number alone does not identify which repo to call `pull_request_read` against.

- **A full GitHub URL was given** (`github.com/MaxxtonGroup/<repo>/pull/<n>`) → extract `owner`, `repo`, and the PR number directly from it.
- **Only a bare PR number was given** → do not guess the repo. Ask: `Which repo is PR #<n> in — mxts-qa-automation or mcms-qa-automation?` Use the answer as `repo` for every call below.

Call `pull_request_read` (method `get`) with the resolved `owner`, `repo`, and PR number. Carry `owner`/`repo` through every subsequent step (`get_file_contents`, `pull_request_review_write`, `merge_pull_request`, `add_issue_comment`) — never re-derive them from the PR number alone.

Extract:
- PR title
- PR body (check for story key, file list, coverage details)
- Base branch, head branch, head SHA (use the SHA, not the branch name, for all `get_file_contents` calls — the branch may move)
- Author
- `state` and `merged` fields

**Eligibility:**
- If `merged: true` or `state: closed` → this is a **retrospective review**. Run Steps 2–4 as normal, but skip Step 5 (post review) and Step 6 (merge) entirely — there is nothing left to approve or merge. Say so explicitly in Step 7.
- If the PR is a draft → note it in the report but still review; skip merge until it's marked ready.
- Otherwise → full workflow (Steps 1–7).

---

## Step 2: Classify Changed Files

Call `pull_request_read` (method `get_files`) with `perPage: 100`. If `changed_files` from Step 1 exceeds 100, paginate with `page`.

Split the results:
- **In scope**: files with `status: added` or `status: modified` ending in `.spec.js`. These get full content review.
- **Out of scope**: `status: removed` files. Do not fetch or review their content — a deleted file can't fail a quality check. List their count in the final report only.
- Non-spec files (page objects, fixtures, docs) — skim for obvious breakage (e.g. a shared helper losing a selector-quality fix) but do not apply the full rubric below to them.

### Step 2a: Decide serial vs. delegated review

- **≤ 12 in-scope spec files** — read each one directly with `get_file_contents` and apply Step 3 yourself (Steps 2b/2c not needed).
- **> 12 in-scope spec files** — reading every file serially will blow the context window before the review finishes. Split the in-scope file list into groups of ~8–10 files (group by directory/feature area, not arbitrarily) and dispatch one `Agent` per group in parallel.

### Step 2b: Sub-agent prompt (delegated mode)

Each dispatched agent must receive, verbatim:
- The repo (`owner`, `repo`), the head SHA, and its assigned file list (with full paths)
- Instruction to fetch each file via `get_file_contents` at that SHA
- The full Step 3 checklist below
- Instruction to return findings grouped by file, `[FILE] <path>` / `BLOCKING:` / `SUGGESTION:`, omitting files with no issues, plus a per-group tally line

### Step 2c: Aggregate

Concatenate the returned findings. Do not re-derive or re-verify them — the sub-agent already read the file. Sum the tallies for the final report's file/issue counts.

### Step 2d: Read the repo's rules first (every review, before Step 2a)

Fetch `CLAUDE.md` of `owner/repo` at the PR's **base** branch with `get_file_contents`, in full, on every review: never review from memory, and never from the PR's own head, which can carry changed rules. Its hard rules, tag taxonomy and comments and flaky-test policies decide what a defect is; the checks in Step 3 are the generic baseline, and where the repo disagrees, the repo wins. Before flagging any pattern as BLOCKING, search the repo's reference files for it (`mcp__claude_ai_GitHub__search_code` with `repo:<owner>/<repo> path:TEST_WRITING_REFERENCE <pattern>`): a pattern the repo documents as the approved fix is not a finding. In delegated mode give every agent the `CLAUDE.md` text and this instruction.

---

## Step 3: Review Checks

Run all checks below. Collect issues — do not stop at the first failure.

### Selector Quality
- PASS: Uses `page.getByRole()`, `page.getByLabel()`, `page.getByText()`, `page.getByPlaceholder()`, `page.getByTestId()`
- FAIL: Uses XPath (`//div`), `nth-child`, Angular Material internals (`.mat-mdc-*`, `_ngcontent-*`, `app-*`) or hardcoded IDs (`#id-123`) — flag as blocking. A simple CSS selector is only a suggestion, unless the repo documents it for that component.
- FAIL: Uses `.evaluate(el => el.click())` (or similar `evaluate`-based DOM interaction) to bypass Playwright's actionability/hit-testing checks — flag as blocking unless the repo documents that exact use as the approved fix (Step 2d). Otherwise it usually masks a real overlay/z-index bug rather than fixing it.

### Test Structure
- PASS: Each test follows Arrange / Act / Assert pattern (comments or structure)
- PASS: one test in a file is a bare `test()`; several tests are wrapped in one `test.describe` with a meaningful name
- PASS: `test.beforeEach` used for shared setup (if applicable)
- FAIL: All setup inside individual tests when it could be shared — flag as suggestion
- FAIL: No assertions in a test (`expect` never called) — flag as blocking
- FAIL: A single `test()` bundles multiple unrelated scenarios (e.g. new-case, existing-case, and error-path flows all in one test body) — flag as suggestion; split for failure isolation.

### Tags and Repo Hard Rules
- PASS: every test title carries its tags in square brackets, `[@<module> @<submodule>]` (module and submodule tag mandatory, `@regression` optional, no `{ tag }` object form) — missing in a new spec file is blocking, in an existing file a suggestion.
- FAIL (blocking): an import from `@playwright/test` in a module spec, `page.waitForTimeout()`, an inline `{ timeout }`, `Date.now()` for unique data (the repo uses `randomString()`), `page.screenshot()` inside a test, a `.click()` or `.fill()` with no visibility assertion before it. The list in the `CLAUDE.md` read in Step 2d is the authority, not this one.
- These checks apply to every file, including in delegated (multi-agent) mode — do not drop them when batching.

### TC_ID Coverage
- Compare TC_IDs in the spec file against those in the PR description.
- Flag any TC_ID listed in the PR description but missing from the spec files as blocking.
- If the PR description contains no explicit TC_ID list (common for bulk migrations or refactor PRs touching many pre-existing files), skip this check and note it as **N/A — no TC_ID list in PR description** rather than failing every file.

### Naming Conventions
- PASS: descriptive snake_case file name (`case_details_page.spec.js`) in `tests/modules/<module>/<sub_menu>/<feature_area>/`, test title `Action_Description [@tags]`
- FAIL: a file named after a Jira key, or generic titles like `test('should work')` — flag as suggestion
- For a PR that modifies many pre-existing, differently-named files (bulk migration/refactor), do not blanket-fail every file on filename: check that each file's *existing* naming is preserved and consistent, and note the PR-level naming scheme once rather than repeating it per file.

### No Hardcoded Data
- FAIL: Hardcoded credentials (passwords, tokens, API keys) in test files — flag as blocking security issue
- FAIL: Hardcoded personal data (a real person's email address, name, or other PII) used as test fixture data — flag as blocking. Use a generic/config-driven test identity instead.
- WARN: Hardcoded test URLs or IDs that differ from config — flag as suggestion

### Convention Consistency
- Compare navigation/interaction patterns across the files in this PR (e.g. clicking through the UI vs. `page.goto()` directly to a deep link, or one shared-helper style vs. another for the same interaction).
- FAIL: The PR uses two different patterns for the same kind of step in sibling files without explanation — flag as suggestion. Inconsistency within a single PR is a maintainability smell even when each individual pattern is valid.

### TODO Completeness
- Count remaining `// TODO` comments. If > 50% of tests are still TODO, flag as suggestion to implement before merging

---

## Step 4: Output Review Report

```
PR REVIEW REPORT
================
PR: #<number> — <title>
Story: <STORY_KEY, or "none — bulk migration" if not applicable>
Status: <open / merged / closed>
Files reviewed: <n> (+ <m> removed files excluded from content review)
Tests found: <n>
Review mode: <serial / delegated across N agents>

BLOCKING ISSUES (must fix before merge)
----------------------------------------
- [FILE] <filename> line <n>: <issue description>
...

SUGGESTIONS (non-blocking)
---------------------------
- [FILE] <filename>: <suggestion>
...

VERDICT: <APPROVED / CHANGES REQUIRED>
```

If the PR is already merged or closed, add one line directly under `Status`: `(retrospective review — no action taken on GitHub)`.

---

## Step 5: Post Review

**Skip this step entirely if the PR is merged or closed** (per Step 1's eligibility check) — go straight to Step 7.

Otherwise call `pull_request_review_write` with:
- If no blocking issues: `event: APPROVE` with the review report as the body
- If blocking issues exist: `event: REQUEST_CHANGES` with the review report as the body

---

## Step 6: Merge (if Approved)

**Skip this step entirely if the PR is merged or closed.**

If the review verdict is APPROVED and the PR is open, call `merge_pull_request` with:
- Merge method: `squash`
- Commit message: `test(<STORY_KEY>): add Playwright test suite — <story summary>`

---

## Step 7: Confirm

If the PR was already merged/closed (retrospective mode):
> PR #<number> was already merged/closed — this was a read-only retrospective review. No GitHub action was taken. See the report above for issues found.

If merged just now:
> PR #<number> approved and merged to <base branch>.
> Run `npx playwright test` via CI to execute the merged specs.

If changes required:
> PR #<number> reviewed — changes requested. Fix the blocking issues and re-run `/review-pr` once updated.
