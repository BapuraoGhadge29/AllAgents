---
name: sprint-planning
description: Fetches all tickets from a given Jira sprint, generates test cases interactively (with scenario review and automation exclusion gates), posts the finalised TC table as a Jira comment, and labels each ticket QA-Reviewed. Use when reviewing an upcoming sprint and generating test cases for all its tickets.
disable-model-invocation: true
argument-hint: "[sprint-number] — e.g. /sprint-planning 221"
allowed-tools:
- Bash
- mcp__claude_ai_Atlassian_MCP__getAccessibleAtlassianResources
- mcp__claude_ai_Atlassian_MCP__searchJiraIssuesUsingJql
- mcp__claude_ai_Atlassian_MCP__getJiraIssue
- mcp__claude_ai_Atlassian_MCP__getConfluenceContent
- mcp__claude_ai_Atlassian_MCP__searchConfluence
- mcp__claude_ai_Atlassian_MCP__addOrEditJiraIssueComment
- mcp__claude_ai_Atlassian_MCP__editJiraIssue
- mcp__claude_ai_Atlassian_MCP__discover
- mcp__claude_ai_Atlassian_MCP__executeRead
---

# Sprint Planning

Fetches every ticket in a given sprint, generates test cases for each one interactively, and labels the ticket `QA-Reviewed` when done. Tickets that already carry both `HL-Scenarios_Covered` and `QA-Reviewed` are skipped — safe to re-run on the same sprint after adding new tickets.

```
/sprint-planning 221
/sprint-planning finance-221
/sprint-planning Finance - 221
```

---

## Step 1: Resolve Inputs

**Sprint input parsing** — extract the sprint number by taking the last numeric sequence found anywhere in the input. Do not try to interpret prefixes (abbreviations, team names, module codes) — let Jira resolve the full sprint name.

| Input | Number extracted |
|---|---|
| `221` | `221` |
| `RM 253` | `253` |
| `RM253` | `253` |
| `TM 86` | `86` |
| `finance 221` | `221` |
| `Finance - 221` | `221` |
| `finance-221` | `221` |

After extracting the number, search Jira (Step 2) to discover the real sprint name. If the search returns exactly one sprint → show the user the full name and proceed. If multiple active sprints share the same number → list them and ask the user to pick one.

If no sprint number is provided, ask:
> Please provide a sprint number. Examples: `/sprint-planning 221` or `/sprint-planning Finance - 221`

Call `getAccessibleAtlassianResources` to get `cloudId`.

---

## Step 2: Validate Sprint + Fetch Tickets

**Sprint name resolution — always run this before fetching tickets. Resolve the full sprint name autonomously from Jira — never ask the user about prefixes or abbreviations. Only ask the user when Jira itself returns multiple ambiguous sprint matches for the same number.**

**Step A — try JQL by number:**

Call `searchJiraIssuesUsingJql`:
```
jql: project = MXTS AND sprint = <sprint-number> AND sprint in (openSprints(), futureSprints())
fields: [customfield_10020]
maxResults: 1
```

- **≥1 result** → read `customfield_10020[0].name` from the result (e.g. `"Reservations 253"`). Store as `sprint_name`. Skip to Step C.
- **0 results** → the number is part of the sprint name, not its Jira ID. Continue to Step B.

**Step B — board-sprints fallback (runs only when Step A returns 0):**

1. Call `mcp__claude_ai_Atlassian_MCP__executeRead` with `name: listJiraBoards` (`projectKeyOrId: MXTS`, `maxResults: 50`) to list all boards.
2. For each board `id`, call `mcp__claude_ai_Atlassian_MCP__executeRead` with `name: listJiraBoardSprints` (`boardId`, `state: active` and `state: future`) to list active and upcoming sprints.
3. Collect all sprints whose `name` contains the extracted sprint number as a whole word or token (e.g. number `86` matches `"Template Manager (Q2) 86"` but not `"Sprint 860"`).
4. Outcome:
   - **Exactly one match** → store its `name` as `sprint_name`. Log: `Resolved sprint: "<sprint_name>"` — no user prompt needed.
   - **Multiple matches** → list them and ask the user to pick one.
   - **No match** → sprint does not exist or is closed. Stop:
     > ⚠️ Sprint `<number>` not found in any active or upcoming sprint across all MXTS boards. Check the sprint number and try again.

**Step C — validate and fetch tickets:**

Confirm sprint is active or future (state = `active` or `future` from the board-sprints listing, or confirmed by Step A JQL). If closed → stop with the message above.

Call `searchJiraIssuesUsingJql`:
```
jql: project = MXTS AND sprint = "<sprint_name>" AND issuetype not in (Sub-task) ORDER BY created ASC
fields: [summary, description, status, labels, priority, assignee, issuetype, parent]
maxResults: 50
```

If the result is empty:
> No tickets found in sprint `<sprint_name>`.

From the results, split tickets into two buckets:
- **To process** — tickets that do NOT have both `QA-Reviewed` and `HL-Scenarios_Covered` labels
- **To skip** — tickets that already have BOTH labels

Show the full list and ask for confirmation before proceeding:

```
SPRINT <sprint-name> — <total> tickets found
──────────────────────────────────────────────
[1]  MXTS-12345 — <summary> (<issuetype>)
[2]  MXTS-12346 — <summary> (<issuetype>)
...
[n]  MXTS-12399 — <summary> (<issuetype>) ⊘ already labeled — will be skipped

<to-process> will be processed · <to-skip> already labeled and will be skipped

Does this look correct? Type `yes` to start or `no` to cancel.
```

- `yes` → proceed to Step 3 (process only the "to process" bucket)
- `no` → stop. Ask the user to re-run with the correct sprint number.

---

## Step 3: Process Each Ticket

Process tickets **one at a time, sequentially** — complete all steps for ticket N before moving to ticket N+1.

At the start of each ticket print:
```
── [N/<total>] MXTS-XXXXX — <summary> ──────────────────
```

Run Steps 4–8 for each ticket before proceeding to the next.

---

## Step 4: Read Requirements

Fetch from `getJiraIssue` (if not already loaded):
- Summary, description, acceptance criteria, priority, issue type, Epic key (from parent field)
- All comments (read with `mcp__claude_ai_Atlassian_MCP__executeRead` `name: listJiraIssueComments`; v2 `getJiraIssue` does not return them) — scan developer comments for implementation scope details (specific UI locations, pages, API endpoints, what was changed and where). Store as `impl_context`. Where `impl_context` is more specific than the ACs, use it to set TC scope.

Call `searchConfluence`:
```
cql: text ~ "<ticket summary>" AND space.type IN ("global")
limit: 5
```
For any result that looks like an LLD, HLD, exit report, or feature design page, call `getConfluenceContent` to retrieve its content.

If no Confluence pages found: proceed using only the Jira ticket content — do not block.

Build a requirement summary:
- Feature overview, functional requirements, ACs, user roles involved, known constraints, coverage gaps.

---

## Step 5: Generate Test Cases

Using the requirement summary from Step 4, generate the full 10-column test case table.

**High-level scenarios first** (brief table shown to user for the gate):

| TC_ID | Test Scenarios |
|---|---|
| TC_01 | Verify we are able to … |

TC_ID format: `TC_01`, `TC_02` — restart from `TC_01` per ticket, always two digits.

**Language rules (strictly enforced):**
- `Verify we are able to <action>`
- `Verify we are not able to <action>`
- `Verify error is shown when <condition>`
- `Verify <element> is shown/not shown when <condition>`
- `Verify <thing> is <state> when <condition>`
- Never use "Verify that..." — always one of the patterns above
- Reference specific field names, UI elements, and actions from the ticket

**For Bug tickets** — cover where relevant: Reproduction, Fix verification, Workaround scenarios, Data persistence, Regression.
**For Story/Improvement tickets** — cover: Happy path, Edge cases, Negative/error cases, Regression.

Do not impose a maximum TC count — generate as many as the content requires.

**Risk column — apply in priority order:**
1. Scan scenario text for `critical_paths` keywords (word-boundary match): `reservation`, `booking`, `payment`, `invoice`, `down payment`, `customer creation`, `customer contact`, `check-in`, `check-out`, `arrival`, `departure`, `authentication`, `login`, `logout`, `finance`, `work order`, `supplier`, `distribution channel`, `resort`, `resource allocation`, `reallocation`, `loyalty points`, `reseller`. Any whole-word match → `High` unconditionally.
2. Standard heuristic (if no match): High = core business flow / data loss / authorization; Medium = edit / search / error / boundary; Low = cosmetic / view-only.

**Automate column:** leave blank for now — set after Gate 2.

---

## Gate 1 — Scenario Review Gate

Display the full TC table, then ask:

> Which test case scenarios do you want to **remove** from `<TICKET_KEY>`? Enter TC IDs separated by commas (e.g. `TC_01, TC_05`), or `none` to keep all.
>
> You can also reply with:
> - `add <TC description>` — append a new TC row (auto-assign next TC_ID, infer Risk from heuristic)

After each `remove` or `add`, re-display the updated table and ask again until the user replies `none` or confirms no further changes.

---

## Gate 2 — Automation Exclusion Gate

Once the TC table is finalised from Gate 1, ask:

> **Automation — `<TICKET_KEY>`**
>
> Which TCs should be excluded from automation?
>
> | Type this | To do this |
> |---|---|
> | `TC_03, TC_07` | Exclude specific TCs from automation |
> | `none` | Automate all TCs |
> | `skip automation` | Skip automation for all TCs |

Store the response as `ticket.tc_skip_automation`.

**Set `Automate` column from Gate 2 result:**
- TC **not** in `tc_skip_automation` → `Automate = Yes`
- TC **in** `tc_skip_automation` → `Automate = No`
- `skip automation` response → all TCs: `Automate = No`

---

## Step 6: Post to Jira

Call `addOrEditJiraIssueComment` on the ticket with the finalised 10-column table using **exactly** the following format:

```
## Test Cases — <TICKET_KEY>

| TC_ID | Test case scenario | Preconditions | Test steps | Expected Result | Actual result | Story number | Epic number | Automate | Risk |
|---|---|---|---|---|---|---|---|---|---|
| TC_01 | … | … | … | … | To be Tested | <TICKET_KEY> | <EPIC_KEY or N/A> | Yes/No | High/Medium/Low |
…

_AC coverage: <covered>/<total> | Automate: <n> Yes / <m> No_
```

> ⛔ **Format is fixed.** The header must be exactly `## Test Cases — <TICKET_KEY>`. Do NOT use a different header. Do NOT omit the italic footer line. Do NOT add extra columns, sections, or narrative prose (the one allowed addition is the `_Part n of m_` line of a split comment, below).

**Validate before every post, and split long tables.** Save the body with the Write tool (read it back only with the Read tool) and run `node "${CLAUDE_PLUGIN_ROOT}/skills/test-ticket/scripts/validate-results-comment.js" <body_file> --kind tc --story <TICKET_KEY>`; exit 1 → rebuild from the template it prints. Jira rejects a comment over 32,767 characters, and `test-ticket` later merges the results into this same comment (longer rows), so a ticket whose comment would not fit after that is posted in parts: always above **45 TCs**, and shorter ones when their rows are long (otherwise one comment, as above):

1. **Plan once, by length.** Write the TC_IDs (table order) to a temp file and the whole drafted Test Cases body (all rows, unsplit) to a second one, then run `node "${CLAUDE_PLUGIN_ROOT}/skills/test-ticket/scripts/result-parts.js" plan --ids-file <ids.txt> --merged-from <draft.txt>`. The parts are cut from the real row lengths so that each still fits one Jira comment after the results are merged in: balanced, at most 40 rows, and a ticket of 45 TCs or fewer can be split too. For a ticket whose tests carry heavy evidence (several screenshots per TC) add `--extra-per-row 700`. `"split": true` → save `{ "planned_at": "<ISO now>", "parts": <printed parts> }` to `test-output/<TICKET_KEY>/tc-parts.json` before posting; the file already exists → reuse it, never plan again. `"split": false` → one comment, as above.
2. **Each part** is the full format above plus the line `_Part n of m_` directly after the header, only its own TC rows, and the footer with this part's `Automate` counts (AC coverage stays story-wide).
3. **Validate every part before posting part 1:** add `--part n/m --tc-ids TC_01,TC_02,…` to the validator command. A part over 32,000 characters fails with `CHECK 15`: re-plan with `plan … --batch 30`, replace the saved plan, rebuild (safe, because nothing is posted yet).
4. **Post the parts in order.** A part without a saved `comment_id`: first `listJiraIssueComments` — a comment whose first line is the header for this ticket and that carries this part's marker, created at or after `planned_at`, is already posted (record its id). Otherwise post it and save the returned id at once. A failed part stops the run of posts; a re-run resumes at the first part without an id.
5. **Reconcile:** read the posted parts back, save each body in part order, write the saved `parts` array to `parts.json` and run `node "${CLAUDE_PLUGIN_ROOT}/skills/test-ticket/scripts/result-parts.js" reconcile --plan parts.json --body-file <part1> --body-file <part2>`; it must print `OK — <n> TC(s) across <m> part(s), each exactly once.`

---

## Step 7: Add Label

Call `editJiraIssue` to add both `HL-Scenarios_Covered` and `QA-Reviewed` to the ticket:
- Read existing `labels` array from the ticket
- Append both labels — do not remove any existing labels
- Call `editJiraIssue` with the full updated labels array

Print confirmation:
```
✓ MXTS-XXXXX — <n> TCs posted, QA-Reviewed label added
```

Then move to the next ticket.

---

## Step 8: Final Summary

After all tickets are processed:

```
SPRINT <sprint-number> — RUN COMPLETE
======================================
Processed:  <n>
Skipped:    <n>  (QA-Reviewed label already present)

RESULTS
-------
✓ MXTS-12345 — <summary> — <n> TCs posted
✓ MXTS-12346 — <summary> — <n> TCs posted
⊘ MXTS-12347 — <summary> — skipped (both HL-Scenarios_Covered + QA-Reviewed already present)
```
