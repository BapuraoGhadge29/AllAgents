---
name: raise-defect
description: Raises Jira defect tickets for confirmed product defects from a triage-defect report. Attaches full evidence including failed test title, error message, steps to reproduce, expected vs actual behaviour, and screenshot references. Use when creating Jira Bug tickets from a triage-defect report.
disable-model-invocation: true
argument-hint: "[triage report or TC_IDs to raise]"
allowed-tools:
- mcp__claude_ai_Atlassian_MCP__getAccessibleAtlassianResources
- mcp__claude_ai_Atlassian_MCP__getJiraIssue
- mcp__claude_ai_Atlassian_MCP__searchJiraIssuesUsingJql
- mcp__claude_ai_Atlassian_MCP__createJiraIssue
- mcp__claude_ai_Atlassian_MCP__discover
- mcp__claude_ai_Atlassian_MCP__executeRead
- mcp__claude_ai_Atlassian_MCP__executeWrite
- mcp__claude_ai_Slack__slack_send_message
---

# Raise Defect

## Configuration
<!-- Edit these values once before first use. The skill reads from this block — no API lookup needed. -->

```yaml
project_key: MXTS
default_issue_type: Bug

# Maxxton Team custom field — required on every issue
team_field_id: customfield_10049
team_field_value: "10108"        # ⚠️ REQUIRED: change to your team's ID before first use (see Team field values table below)

# Epic link field
epic_link_field: customfield_10014

# Title prefix options the skill picks from when naming tickets
title_prefixes: [FM, CCM, OWNER, OM]

# Severity mapping — maps Jira priority to a severity label added to the bug
# Format: <priority>: <severity-label>
severity_map:
  P1: blocker
  P2: critical
  P3: major
  P4: minor

# Component routing — keyword in TC scenario → Jira component name
# Skill scans the failed TC scenario text for these keywords (case-insensitive)
# First match wins; leave empty to skip component assignment
component_routing:
  customer: "Customer Care"
  reservation: "Reservations"
  booking: "Reservations"
  invoice: "Finance"
  payment: "Finance"
  login: "Authentication"
  search: "Search"
  # add more as needed

# Slack notification — leave slack_channel blank to disable
slack_channel: ""               # e.g. "#qa-defects" or "C0123456789" (channel ID)
slack_notify_on: defects_raised  # options: defects_raised | run_complete | both

# Optional
sprint_field: customfield_10020  # leave blank to skip sprint assignment
custom_fields: {}                # any extra fields specific to your team
```

**Team field values (customfield_10049):**
| Team | ID |
|---|---|
| FM/OM/CCM | 10108 |
| QA - Overall | 10117 |
| Reservations/FOM | 10115 |
| DevOps / Core | 10107 |
| Content Manager | 10102 |
| Channel Manager | 10267 |
| Third Parties - API | 10122 |
| Third Parties - Connections | 10123 |
| Third Parties - Payments | 10124 |

---

Creates structured Jira defect tickets for every confirmed product defect from a `triage-defect` report. Each defect is raised with full evidence attached.

## Step 1: Resolve Cloud ID and Project

Call `getAccessibleAtlassianResources` to get `cloudId`.

Read the **Configuration** block above:
- Use `project_key`, `team_field_id`, `team_field_value`, `epic_link_field` directly — no API lookup needed
- Use `default_issue_type` as the issue type name (e.g. `Bug`)

Extract from the triage report for each `[PRODUCT DEFECT]`:
- Story key (e.g. MXTS-12345)
- TC_ID
- TC scenario text
- Actual error message / failure description

Call `getJiraIssue` on the parent story to extract:
- Epic key from `epic_link_field` config value

**Compute per-defect routing fields:**

1. **Priority (from TC risk, not story priority)** — read the `Risk` column of the failed TC (High/Medium/Low from the test case table):

   | TC Risk | Priority | Severity label |
   |---|---|---|
   | High | P2 | `critical` |
   | Medium | P3 | `major` |
   | Low | P4 | `minor` |

   Override to P1 (`blocker`) if the failure shows: data loss, auth bypass, or 5xx error on a core business endpoint.
   If TC table has no Risk column → fall back to the story priority (default P3).

2. **Component** — scan the TC scenario text against `component_routing` keys (case-insensitive, first match wins). If matched, set the Jira `components` field to the mapped value. If no match, leave component blank.

---

## Step 2: Build Defect for Each Confirmed Failure

For each `[PRODUCT DEFECT]` entry in the triage report, construct a Jira Bug with the following fields:

**Summary:**
```
[<STORY_KEY>] <TC_ID>: <short description of what failed>
```
Example: `[MXTS-12345] TC_03: Login error message not displayed for invalid credentials`

**Issue type:** Bug

**Priority:** Derived from TC risk column per Step 1 severity derivation

**Description (structured, markdown — pass `contentFormat: markdown`):**

```
**Story:** <STORY_KEY> — <story summary>
**Test case:** <TC_ID> — <test case scenario>
**Environment:** <environment from triage context, or "Not specified">

---

### Steps to Reproduce

<numbered reproduction steps from the test case>

---

### Expected Behaviour

<expected result from the test case table>

---

### Actual Behaviour

<exact error message and description of what happened>

---

### Test Evidence

**Failed step:** <step that failed>
**Error message:**
~~~
<exact error message from Playwright output>
~~~

**Screenshot:** <screenshot path or "No screenshot captured">

---

### Linked Test Case

TC_ID: <TC_ID>
Story: <STORY_KEY>
```

**Labels:** `qa-automated`, `auto-raised`, `<severity-label>` (from `severity_map`), `<STORY_KEY>-<TC_ID>` (required for dedup)

**Linked issues:** Link to parent story as "is caused by" or "relates to" — pick the exact link type name from `mcp__claude_ai_Atlassian_MCP__executeRead` (find an unknown operation name first with `mcp__claude_ai_Atlassian_MCP__discover`) with `name: listJiraIssueLinkTypes` and create the link after the bug exists (Step 5)

---

## Step 3: Confirm Before Creating

Before calling `createJiraIssue`, print a proposal table and ask for confirmation:

```
PROPOSED DEFECTS
================
#  TC_ID   Summary                                  Priority  Severity   Component
1  TC_03   Login error message not displayed        P2        critical   Authentication
2  TC_07   Search returns no results for valid term P3        major      Search
3  TC_11   Invoice export fails with 500 error      P2        critical   Finance

Raise <n> defect(s) in Jira? (yes / no)
```

- **User confirms yes** → proceed to create issues below
- **User says no** → stop. Inform the user: `Defect creation cancelled — defects listed above for manual review if needed.`

**This confirmation is unconditional — no flag, mode, or defect type skips it.** Every proposed defect goes through this table and waits for an explicit "yes," including a regression (a closed Jira bug was found for this TC_ID in dedup) — a regression is still a new ticket being created, so it gets the same ask as anything else. `--auto-raise` is accepted for backward compatibility but is now a no-op: it never skips this step. This prevents LLM-judged verdicts from ever auto-filing a bug without human review, regardless of how confident the classification is.

---

## Step 4: Dedup Check Before Creating

For each confirmed defect run three JQL checks in order (via `searchJiraIssuesUsingJql`):

**Check A — Open bug for this TC (label-match):**
```
issuetype = Bug AND labels = "<STORY_KEY>-<TC_ID>" AND project = <project_key> AND statusCategory != Done ORDER BY created DESC
```
- Bug found → **skip**. Log: `[dedup] TC_03 — open bug already exists (<BUG_KEY>), skipping.`
- No bug found → run Check B.

**Check B — Closed/resolved bug for this TC (regression check):**
```
issuetype = Bug AND labels = "<STORY_KEY>-<TC_ID>" AND project = <project_key> AND statusCategory = Done ORDER BY created DESC
```
- Closed bug found → note it as a **candidate regression** and proceed to Check C — do NOT create yet. Checks A/B only match bugs this pipeline itself already labeled `<STORY_KEY>-<TC_ID>`; a closed label-matched bug does not rule out an *open*, unlabeled bug already covering the same regression (e.g. filed manually before this pipeline re-detected it) — creating the regression bug before checking that would itself create the exact duplicate Check C exists to catch.
- No closed bug either → proceed to Check C.

**Check C — Broad match across the project (runs after Check B regardless of its result; candidate signal, not a confirmed duplicate):**

Run one more JQL using 2–3 distinguishing keywords from the failure itself (the specific error message, endpoint, or broken behaviour — not generic words like "error" or "bug"):
```
issuetype = Bug AND project = <project_key> AND statusCategory != Done AND text ~ "<distinguishing keywords>" ORDER BY created DESC
```
- One or more matches → candidates, not confirmed duplicates — keyword overlap is not semantic equality. Read each candidate's summary/description and compare against this TC's actual failure (same root cause, same broken behaviour), the same way Phase 2's Automation Duplicate Check verifies a `search_code` hit before trusting it.
  - **Genuine match** → do not create anything (neither a regression nor a new bug) — an open bug already tracks this, labeled or not. Log: `[dedup] TC_03 — likely duplicate of <BUG_KEY> found via broad search (not pipeline-labeled) — skipping.` Reference `<BUG_KEY>` instead.
  - **Coincidental keyword overlap only, different failure** → fall through to the Check B outcome below. Check C runs here, in Step 4, which is after Step 3's proposal/confirmation — the candidate cannot retroactively appear in a proposal the user already approved. Instead: create the bug as normal, then include `Possible related: <BUG_KEY>` for it in Step 6's Output Defect Summary, so the human still sees it (post-creation, not pre-confirmation) and can judge whether to link/merge the two.
- **No matches, or search unreachable/erroring** (fail open — a missed search must never silently block a real defect; the mandatory confirmation gate in Step 3 is the human backstop either way) → fall through to the Check B outcome below.

**Finalize using Check B's outcome** (only reached when Check C found no genuine match): Check B found a closed label-matched bug → **create a new bug**, append `(regression)` to the summary, log `[dedup] TC_03 — prior bug <BUG_KEY> was closed, filing regression.` Check B found nothing → create a plain new bug.

**Summary of dedup outcomes:**

| Situation | Action |
|---|---|
| Open bug for this TC_ID (label-matched) | Skip — already tracked (Check A) |
| No open label match, but broad search finds a genuine open match | Skip — reference existing bug (Check C), regardless of what Check B found |
| No genuine broad match, closed bug for this TC_ID (label-matched) | Create regression bug |
| No match anywhere | Create new bug (note any keyword-only candidates as "Possible related" in Step 6's summary) |

---

## Step 5: Create Jira Issues

For each defect that passed the dedup check, call `createJiraIssue` with:
- `projectKey`: from config `project_key`
- `issueType`: from config `default_issue_type`
- `summary`, `description`: as constructed in Step 2
- `contentFormat`: `markdown`
- `priority` (top-level): derived from TC risk column per Step 1 severity derivation (NOT inherited from parent story)
- `labels` (top-level): `["qa-automated", "auto-raised", "<severity-label>", "<STORY_KEY>-<TC_ID>"]` — severity label from `severity_map` config; `<STORY_KEY>-<TC_ID>` is required for dedup; omit severity label if not mapped
- `additional_fields`:
  - `[team_field_id]`: `{"id": "[team_field_value]"}` — from config
  - `[epic_link_field]`: epic key from parent story — from config
  - `components`: component matched from `component_routing` config (skip field entirely if no match)
  - any entries in `custom_fields` config

Then link each new bug to its parent story: call `mcp__claude_ai_Atlassian_MCP__executeWrite` with `name: createJiraIssueLink` (`linkType`, `inwardIssue`, `outwardIssue`).


---

## Step 6: Output Defect Summary

Output a summary of all raised defects:

```
DEFECTS RAISED
==============
Story: <STORY_KEY>

Raised:
- <BUG_KEY>: <TC_ID> — <summary>
- <BUG_KEY>: <TC_ID> — <summary>

Skipped (already exists):
- <TC_ID> — <BUG_KEY> already open
(or "None")

Possible related (created anyway — Check C keyword overlap only, review manually):
- <TC_ID>: <NEW_BUG_KEY> — possibly related to <BUG_KEY>
(omit this section entirely if none)

Total raised: <n> | Skipped (duplicates): <n>
```

---

## Step 7: Slack Notification

If `slack_channel` is set in the config, call `mcp__claude_ai_Slack__slack_send_message` with:

**Channel:** value from `slack_channel` config

**Message:**
```
🐛 *QA Defects Raised — <STORY_KEY>*

*Story:* <STORY_KEY>: <story summary>
*Environment:* <base URL or "Not specified">
*Run date:* <date>

*Defects raised (<n>):*
• <BUG_KEY>: <TC_ID> — <summary> | Priority: <P> | Component: <component or "—">
• <BUG_KEY>: <TC_ID> — <summary> | Priority: <P> | Component: <component or "—">

*Skipped (<n> already open):*
• <TC_ID> — <existing BUG_KEY> (or "None")

Review in Jira: <link to parent story>
```

- If `slack_channel` is blank → skip silently, no error
- If Slack MCP is not connected → skip silently, log: `[Slack] Not connected — notification skipped`
- Notification failure must never block or fail the defect creation

---

## Step 8: Confirm

Confirm to the user:
> <n> defect(s) raised in Jira. Slack notification sent to <channel> (or "Slack notifications disabled"). Run `/generate-reports <STORY_KEY>` to produce the full QA test run report.
