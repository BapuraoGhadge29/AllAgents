---
name: test-ticket
description: Orchestrates the full QA pipeline for a Jira Epic — reads requirements, generates test cases, executes live browser tests, triages failures, raises defects. Log in first; everything after runs automatically with resume support. Use for a full Epic QA run (e.g. "test-ticket MXTS-12345").
disable-model-invocation: true
argument-hint: "[TICKET-ID] [URL] [URL2] [[TICKET-ID] [URL] [URL2] ...] [--force] [--retest] [--from=phase1|phase2|phase2.5|phase3a|phase3b|phase4|phase5|phase6] [--unattended] [--auto-raise] [--skip-specs] [--auto-specs] [--skip-impact] [--clear-nav-cache] [--min-completeness=N] [--max-tcs=N] [--tc-timeout=N] [--max-time=N] [--skip-review] [--workers=N]"
allowed-tools:
- Bash
- AskUserQuestion
- Agent
- Monitor
- Skill
- mcp__claude_ai_Atlassian_MCP__getAccessibleAtlassianResources
- mcp__claude_ai_Atlassian_MCP__getJiraIssue
- mcp__claude_ai_Atlassian_MCP__searchJiraIssuesUsingJql
- mcp__claude_ai_Atlassian_MCP__getConfluenceContent
- mcp__claude_ai_Atlassian_MCP__searchConfluence
- mcp__claude_ai_Atlassian_MCP__discover
- mcp__claude_ai_Atlassian_MCP__executeRead
- mcp__claude_ai_Atlassian_MCP__executeWrite
- mcp__claude_ai_Atlassian_MCP__addOrEditJiraIssueComment
- mcp__claude_ai_Atlassian_MCP__editJiraIssue
- mcp__claude_ai_Atlassian_MCP__transitionJiraIssue
- mcp__claude_ai_Atlassian_MCP__createJiraIssue
- mcp__claude_ai_Maxxton_Knowledge__search_technical_graph
- mcp__claude_ai_Maxxton_Knowledge__search_repo_info
- mcp__claude_ai_Maxxton_Knowledge__get_service_overview
- mcp__claude_ai_Maxxton_Knowledge__get_call_chain
- mcp__claude_ai_Maxxton_Knowledge__find_path_between_nodes
- mcp__claude_ai_Maxxton_Knowledge__get_entity_usage
- mcp__claude_ai_Slack__slack_send_message
- mcp__claude_ai_Slack__slack_read_canvas
- mcp__claude_ai_Slack__slack_update_canvas
- mcp__claude_ai_Slack__slack_search_users
- mcp__claude_ai_Slack__slack_read_channel
- mcp__plugin_qa-engineer_playwright__browser_navigate
- mcp__plugin_qa-engineer_playwright__browser_navigate_back
- mcp__plugin_qa-engineer_playwright__browser_click
- mcp__plugin_qa-engineer_playwright__browser_fill_form
- mcp__plugin_qa-engineer_playwright__browser_snapshot
- mcp__plugin_qa-engineer_playwright__browser_find
- mcp__plugin_qa-engineer_playwright__browser_take_screenshot
- mcp__plugin_qa-engineer_playwright__browser_select_option
- mcp__plugin_qa-engineer_playwright__browser_press_key
- mcp__plugin_qa-engineer_playwright__browser_type
- mcp__plugin_qa-engineer_playwright__browser_hover
- mcp__plugin_qa-engineer_playwright__browser_drag
- mcp__plugin_qa-engineer_playwright__browser_drop
- mcp__plugin_qa-engineer_playwright__browser_file_upload
- mcp__plugin_qa-engineer_playwright__browser_handle_dialog
- mcp__plugin_qa-engineer_playwright__browser_wait_for
- mcp__plugin_qa-engineer_playwright__browser_resize
- mcp__plugin_qa-engineer_playwright__browser_close
- mcp__plugin_qa-engineer_playwright__browser_network_requests
- mcp__plugin_qa-engineer_playwright__browser_network_request
- mcp__plugin_qa-engineer_playwright__browser_evaluate
- mcp__plugin_qa-engineer_playwright__browser_run_code_unsafe
- mcp__plugin_qa-engineer_playwright__browser_console_messages
- mcp__plugin_qa-engineer_playwright__browser_storage_state
- mcp__plugin_qa-engineer_playwright__browser_tabs
- mcp__plugin_qa-engineer_playwright__browser_set_storage_state
- mcp__plugin_qa-engineer_playwright-w2__browser_navigate
- mcp__plugin_qa-engineer_playwright-w2__browser_navigate_back
- mcp__plugin_qa-engineer_playwright-w2__browser_click
- mcp__plugin_qa-engineer_playwright-w2__browser_fill_form
- mcp__plugin_qa-engineer_playwright-w2__browser_snapshot
- mcp__plugin_qa-engineer_playwright-w2__browser_find
- mcp__plugin_qa-engineer_playwright-w2__browser_take_screenshot
- mcp__plugin_qa-engineer_playwright-w2__browser_select_option
- mcp__plugin_qa-engineer_playwright-w2__browser_press_key
- mcp__plugin_qa-engineer_playwright-w2__browser_type
- mcp__plugin_qa-engineer_playwright-w2__browser_hover
- mcp__plugin_qa-engineer_playwright-w2__browser_drag
- mcp__plugin_qa-engineer_playwright-w2__browser_drop
- mcp__plugin_qa-engineer_playwright-w2__browser_file_upload
- mcp__plugin_qa-engineer_playwright-w2__browser_handle_dialog
- mcp__plugin_qa-engineer_playwright-w2__browser_wait_for
- mcp__plugin_qa-engineer_playwright-w2__browser_resize
- mcp__plugin_qa-engineer_playwright-w2__browser_tabs
- mcp__plugin_qa-engineer_playwright-w2__browser_close
- mcp__plugin_qa-engineer_playwright-w2__browser_network_requests
- mcp__plugin_qa-engineer_playwright-w2__browser_network_request
- mcp__plugin_qa-engineer_playwright-w2__browser_evaluate
- mcp__plugin_qa-engineer_playwright-w2__browser_run_code_unsafe
- mcp__plugin_qa-engineer_playwright-w2__browser_console_messages
- mcp__plugin_qa-engineer_playwright-w2__browser_storage_state
- mcp__plugin_qa-engineer_playwright-w2__browser_set_storage_state
- mcp__playwright__browser_navigate
- mcp__playwright__browser_navigate_back
- mcp__playwright__browser_click
- mcp__playwright__browser_fill_form
- mcp__playwright__browser_snapshot
- mcp__playwright__browser_find
- mcp__playwright__browser_take_screenshot
- mcp__playwright__browser_select_option
- mcp__playwright__browser_press_key
- mcp__playwright__browser_type
- mcp__playwright__browser_hover
- mcp__playwright__browser_drag
- mcp__playwright__browser_drop
- mcp__playwright__browser_file_upload
- mcp__playwright__browser_handle_dialog
- mcp__playwright__browser_wait_for
- mcp__playwright__browser_resize
- mcp__playwright__browser_close
- mcp__playwright__browser_network_requests
- mcp__playwright__browser_network_request
- mcp__playwright__browser_evaluate
- mcp__playwright__browser_run_code_unsafe
- mcp__playwright__browser_console_messages
- mcp__playwright__browser_storage_state
- mcp__playwright__browser_tabs
- mcp__playwright-headed__browser_navigate
- mcp__playwright-headed__browser_navigate_back
- mcp__playwright-headed__browser_click
- mcp__playwright-headed__browser_fill_form
- mcp__playwright-headed__browser_snapshot
- mcp__playwright-headed__browser_find
- mcp__playwright-headed__browser_take_screenshot
- mcp__playwright-headed__browser_select_option
- mcp__playwright-headed__browser_press_key
- mcp__playwright-headed__browser_type
- mcp__playwright-headed__browser_hover
- mcp__playwright-headed__browser_drag
- mcp__playwright-headed__browser_drop
- mcp__playwright-headed__browser_file_upload
- mcp__playwright-headed__browser_handle_dialog
- mcp__playwright-headed__browser_wait_for
- mcp__playwright-headed__browser_resize
- mcp__playwright-headed__browser_close
- mcp__playwright-headed__browser_network_requests
- mcp__playwright-headed__browser_network_request
- mcp__playwright-headed__browser_evaluate
- mcp__playwright-headed__browser_run_code_unsafe
- mcp__playwright-headed__browser_console_messages
- mcp__playwright-headed__browser_storage_state
- mcp__playwright-headed__browser_tabs
- mcp__claude_ai_GitHub__get_file_contents
- mcp__claude_ai_GitHub__search_code
- mcp__claude_ai_GitHub__list_commits
- mcp__claude_ai_GitHub__create_branch
- mcp__claude_ai_GitHub__push_files
- mcp__claude_ai_GitHub__create_pull_request
- mcp__claude_ai_GitHub__pull_request_read
- mcp__claude_ai_GitHub__search_pull_requests
---

# Test Ticket
**After a context compaction on a run that used parallel workers:** if `test-output/<EPIC_ID>/parallel/<STORY_KEY>/` exists (a multi-URL story has one subfolder per hostname: check them in run order, the first whose `next` is not `done` is the URL being run), run `node "$CLAUDE_PLUGIN_ROOT/skills/test-ticket/scripts/parallel-split.js" status <that folder>` and follow [the parallel execution reference](references/parallel-execution.md) from the step it names, but only when its `plan.created_at` is after this run began. That outranks the Resume Check's Phase 3a row.
## Configuration
<!-- Edit once for your team's Jira workflow — the skill reads from this block -->

```yaml
# ⚠️ MUST KEEP IN SYNC with generating-test-cases Configuration block (same status buckets, same critical_paths, same Source priority & grounding rule in Phase 1 step 3g) — both skills are self-contained, so update both when you change status_mapping, critical_paths, or the grounding rule.
status_mapping:
  development_stage:
    - Open
    - In Progress
    - To Do
    - In Development
    - Resolved
    - Reopened
    - Waiting for support
    # Done statuses — test cases only, no re-execution
    - Checked by QA
    - Cannot Test
    - Closed

  qa_stage:
    - Ready for QA
    - In QA
    - Testing
    - QA in Progress
    - Ready for Testing

# Fallback bucket for any status not listed above (development_stage | qa_stage)
default_bucket: development_stage

# Critical business paths (Maxxton MCMS service graph) — a TC matching one of these as a whole word
# (not substring — "login" matches "Login form" but not "verify-login-page-font") gets High risk,
# overriding the LLM heuristic. Prefer multi-word phrases (e.g. "down payment") to avoid false hits.
critical_paths:
  - reservation
  - booking
  - payment
  - invoice
  - down payment
  - customer creation
  - customer contact
  - check-in
  - check-out
  - arrival
  - departure
  - authentication
  - login
  - logout
  - finance
  - work order
  - supplier
  - distribution channel
  - resort
  - resource allocation
  - reallocation
  - loyalty points
  - reseller

# Slack notifications — leave slack_channel blank to disable
slack_channel: ""               # e.g. "#qa-team" — set to your team's QA channel; blank = disabled
slack_notify_on: both           # options: defects_raised | run_complete | both; ignored when slack_channel is blank

exit_gate:
  pass_rate_threshold: 80      # % of non-BLOCKED TCs that must PASS; set to 0 to disable
  block_on_open_p1_p2: true    # true = any P1/P2 defect raised this run blocks DoD
  auto_transition: false       # true = transition story on DoD PASS automatically, no per-run ask — this flag IS the confirmation
  transition_target: "Checked by QA"  # Jira status name to transition to on DoD PASS

# Story Action (after Phase 5) is automatic, not configurable — see "Story Action" section.

# AC coverage gate — set to 0 to report without gating
ac_coverage_threshold: 0       # minimum % of ACs that must be covered by ≥1 TC; 0 = report-only

# Build version source, used in results comment (auto = JS eval heuristic | jira_field:<fieldId> | env_var:<VAR> | manual = always prompt)
build_version_source: auto

# Lets the concurrency check auto-release a lock left by a force-quit/killed session (which skips
# the normal Per-Ticket Completion / Final Summary release) instead of blocking forever — no per-run
# ask, this value IS the policy decision. Set to 0 to disable staleness detection (always hard-block).
stale_lock_threshold_hours: 3

# Feedback collection (see "Feedback Collection" section) — blank feedback_canvas_id disables it entirely; blank feedback_slack_channel skips just the channel message.
feedback_slack_channel: "C06N19RHEQZ"   # #qa-all — the formatted feedback message goes here
feedback_canvas_id: "F0BHHBNQTS6"       # #core-qa-team's own Canvas tab — the checkbox entry goes here

# Cross-Module Impact broadcast (see Phase 2.5 "Slack posting") — blank disables just the Slack post.
impact_slack_channel: "C0BTM6Q2FDZ"     # #cross-module-impact
```

---

Pre-authenticated QA pipeline orchestrator. Executes all QA skills in sequence for a Jira Epic, producing test cases, Playwright scripts, defect reports, and a complete QA report. **Before running with a URL:** ensure you are already logged in to the target app in your browser — the pipeline detects your existing session, no credentials needed. Supports **resume mode** by default; use `--force` to re-run from scratch.

For usage examples and multi-Epic URL inheritance rules, see [the invocation examples reference](references/invocation-examples.md).

---

## Jira Comment Policy

> ⛔ **The pipeline posts only template-format comments. No free-form comments are ever posted to Jira.**
>
> There are exactly **three** comment types — all go through the scripts below by default:
>
> | Comment | Script — new / correct in place | Format |
> |---|---|---|
> | **Phase 2 TC comment** | `post-tc-comment.js` / `update-tc-comment.js` (API v2 wiki markup / PUT) | 10-column wiki markup table (see Phase 2) |
> | **Phase 3b Results comment** (new one per test cycle) | `post-comment.js` / `update-comment.js` (API v2 wiki markup / PUT) | 6-column wiki markup table (see Phase 3b) |
> | **Phase 6 PR-link comment** | `post-pr-comment.js` (API v2) | fixed two-line template (see Phase 6) |
>
> The Phase 2 and Phase 6 `(update)`/`(correct in place)` scripts are used only to fix an already-posted comment — never to post a second one. The Phase 3b results are the exception, in both directions: a story's **first cycle** writes its results INTO its Test Cases comment (`update-comment.js <STORY_KEY> <tc_comment_id>` with the merged 12-column table — one comment holding the test cases and their results, never a second comment; [the Phase 3b results reference](references/phase-3b-results-comment.md)), and **a new test cycle** (a `--retest` or `--force` run after the story was reopened) posts a **new** `post-comment.js` comment rather than editing the prior cycle's. Otherwise `update-comment.js` is reserved for fixing a malformed/incomplete comment within the SAME cycle. Same format validation runs in every script.
>
> ⛔ **`addOrEditJiraIssueComment` is the MCP write path — used only when `jira_write_path = mcp` (see phase-3a-execution.md's "Jira Write-Path Check" → MCP fallback), plus the same-path rule when correcting a comment the MCP path created.** When `jira_write_path = script`, all comments go through the scripts above — never call `addOrEditJiraIssueComment` directly in that case. When it's `mcp` (no usable token), calling it is mandatory, not optional: a comment that can be posted must be posted — the TC comment as markdown, the results comment as HTML with embedded screenshots ([the MCP write path reference](references/jira-mcp-write-path.md)) — never silently skipped just because the script path is unavailable.
>
> ⛔ **After context compaction — re-anchor before posting.** On a long run the conversation may be summarized (compacted) mid-pipeline, dropping the exact templates and the active story/verdict data from context. If you are about to build ANY Jira comment and are not 100% certain of the format, the target issue key, or the per-TC data: **STOP and re-read** — the comment template from this SKILL.md (Phase 2 / Phase 3b sections) and the run's own data from `test-output/<EPIC_ID>/results.md` and `execution-log.json`. Never reconstruct a comment format or its TC data from summarized memory. Every posting script also prints the exact template on validation failure (exit 1) — copy that template verbatim rather than guessing.
>
> ⛔ **Never invent columns, sections, or headers.** Copy the template from Phase 3b verbatim. Do not add `Steps Summary`, `Conclusion`, `Verdict`, custom metadata rows, emoji in the header, or any other deviation. The format is fixed — every deviation is a pipeline violation.
>
> Free-form text, execution notes, per-TC narrative, diagnostic output, phase summaries, status updates, and any text that does not match a defined template must **never** be posted to Jira. These are internal pipeline artifacts — they exist in the Claude conversation only and are never written to Jira.

---

**Atlassian MCP tools used by the phase references:** `createJiraIssue`, `searchJiraIssuesUsingJql` and `transitionJiraIssue` directly; `mcp__claude_ai_Atlassian_MCP__executeRead` (`listJiraIssueTransitions`, `listJiraIssueRemoteIssueLinks`, `listJiraIssueComments`) and `mcp__claude_ai_Atlassian_MCP__executeWrite` (`createJiraIssueLink`), with unknown operation names found via `mcp__claude_ai_Atlassian_MCP__discover`.

## Two-Phase Model

**Phase A — Generation + Review:** Phases 1 → Status Gate → 2 — reads requirements, generates test cases, collects scenario review and automation exclusion preferences from the user.

**Phase B — Execution + Analysis:** Phases 2.5 → Impact Summary → 3 → 4 → 5 — runs cross-module impact analysis (using the linked PR for code-level accuracy), presents impacted modules for team notification, executes live browser tests for the current story's TCs only, generates Playwright spec files, triages failures, and raises Jira defects.

> ⚠️ Phase B (3a onwards) requires a pre-authenticated browser session. Log in to the primary app before running. Cross-module apps are **not** executed by this pipeline — the Impact Summary surfaces the blast radius so the QA team can inform respective module teams for their own sanity testing.

**The plugin does not execute Playwright `.spec.js` files.** Phase 3a uses Playwright MCP tools directly. Generated spec files are for CI — they run via `npx playwright test`, not via this plugin.

**Single Epic:** Linear — 1 → 2 → 2.5 → Impact Summary → 3a → 3b → 4 → 5. **Multiple Epics:** Batched sequential — all Epics complete Phase 1+2 first, then each Epic fully completes 2.5 → Impact Summary → 3a → 3b → 4 → 5 before the next starts. One Claude thread, one browser. See [the multi-Epic model reference](references/multi-epic-model.md) for the execution diagram. Keep the session's task list in step with these phases — see [the progress list reference](references/progress-list.md).

---

## Pre-flight Check

**Argument parsing (run first):**

1. Scan tokens left-to-right: `[A-Z]+-[0-9]+` = Ticket ID; anything containing `.maxxton.net` or starting with `http` = URL.
2. **Normalize URLs** — if a URL token has no `https://` prefix, prepend it (e.g. `mqa-dev.maxxton.net` → `https://mqa-dev.maxxton.net`).
3. All consecutive URL tokens immediately following a Ticket ID belong to that ticket as its **execution URL list** (ordered — first URL executes first, second URL executes second, etc.).
4. Any ticket without URLs inherits the shared URLs (all URL tokens not claimed by a specific ticket).
5. No URL anywhere → all tickets run in Generation only mode.

Examples: `/test-ticket MXTS-00000 https://mqa-dev.maxxton.net https://rcn-dev.maxxton.net` → one ticket, two URLs (`mqa-dev.maxxton.net rcn-dev.maxxton.net` without `https://` behaves the same, auto-added); `/test-ticket MXTS-00000 https://mqa-dev.maxxton.net` → one ticket, one URL.

All global flags apply to every ticket. **Tickets run sequentially** — one complete pipeline at a time. Before starting, confirm at least one valid Ticket ID was parsed and the Atlassian MCP connector is reachable (`getAccessibleAtlassianResources`). Then check the claude.ai **Maxxton Knowledge** connector once per invocation (not per Epic): if it is not connected, tell the user once to connect it and carry on — never a stop, never a prompt ([the preflight detail reference](references/preflight-detail.md)).

**Playwright MCP tool-registration check (per Epic, only when a URL was provided — runs before Phase 1 for that Epic):** Confirm a Playwright MCP is present in your available tools — `mcp__plugin_qa-engineer_playwright__*` first, otherwise `mcp__playwright__*` or `mcp__playwright-headed__*` (both enumerated in `allowed-tools` above), which are the same `@playwright/mcp` server under the name the user's own `claude mcp add` gave it. A Playwright MCP under any other name is not usable here — a tool call under a prefix not in `allowed-tools` is silently rejected, not routed. A URL means this Epic is a pre-authenticated run and will need Phase 3a — catching a missing tool now avoids burning Phases 1/2/2.5 on an Epic that can never reach execution. Note the chosen prefix and use only that one for the rest of the run. If no Playwright MCP is present under any of the three names, do NOT start Phase 1 for this Epic: run the same Step 0 diagnosis — starting with `node "$CLAUDE_PLUGIN_ROOT/mcp/run-playwright.js" --doctor`, whose output *is* the diagnosis — and report the same ACTION REQUIRED block as the Phase 3a MCP Server Availability Check ([the Phase 3a execution reference](references/phase-3a-execution.md)), do not set `QA-RUNNING` for this Epic, and move on to the next Epic (if any) rather than blocking the whole batch. Epics with no URL (Generation only mode) are unaffected — they never touch Playwright.

**`--retest` flag:** Capture each TC's last verdict from `test-output/<EPIC_ID>/results.md` into an **in-memory snapshot**, then delete `results.md`, `execution-log.json`, `triage.md`, and `screenshot-hashes.json` (the duplicate-screenshot ledger — left in place, this cycle's captures would collide with the prior cycle's hashes and report false "same run" duplicates). Keep Phase 1 and 2 cache intact — **including `tc_comment_id` and `tc_parts`** (test scenarios are reused, not regenerated; the kept id points at the first cycle's merged comment, which this retest never edits). Clear `stories.<STORY_KEY>.results_comment_id`, `results_comment_path`, `results_merged`, `result_parts`, `cycle_started_at`, `user_wait_seconds`, `pause_count`, `last_activity_at`, `url_timing` (to `{}`), `phase5_done`, **and `partial_run`** to `null`/`0`/`false` in `run-state.json` for each affected story — Phase 3a will stamp a fresh `cycle_started_at` (and re-initialize `user_wait_seconds` to `0`) when it starts (see Phase 3a), which together with the cleared `results_comment_id` is what makes Phase 3b post a brand-new results comment for the retest cycle instead of treating the prior cycle's comment as already-posted, and gives Test Execution Timing a clean start instead of carrying over the prior cycle's elapsed time and wait time; clearing `phase5_done` is what lets Phase 5 actually re-run against this cycle's new triage results instead of the resume check treating last cycle's decision as still current; clearing `partial_run` prevents a prior cycle's degenerate all-BLOCKED run from forcing this retest's genuinely successful cycle to `BLOCKED` too. Log: `[Flags] --retest active — previous results loaded. Phases 3a/3b/4/5 will re-run for the retest scope only (see Phase 3a).` If no `results.md` exists, treat as a first run.

**`--unattended` flag:** Expand to `--auto-specs --auto-raise` internally before any gate. Log: `[Flags] --unattended expanded to --auto-specs --auto-raise.` **This does not reach Jira ticket creation, which always requires an explicit "yes" — no flag, mode, or defect type skips it (see Phase 5 below).** **`--skip-impact` flag:** Skip Phase 2.5 and the Impact Summary — use when the blast radius is already known or speed matters more. Log: `[Flags] --skip-impact active — Phase 2.5 and Impact Summary skipped.` **`--skip-review` flag:** Skip the batched Evidence Review between Phase 3a and 3b (see Phase 3a). Log: `[Flags] --skip-review active — Evidence Review skipped.` **Run metrics (fail-open, local only, opt out with `QA_ENGINEER_METRICS=off`):** right after the Pre-flight checks pass for an Epic, run `node "$CLAUDE_PLUGIN_ROOT/skills/test-ticket/scripts/run-metrics.js" phase "test-output/<EPIC_ID>" preflight || true`, and call `phase` again at the start of each later phase you already log (`phase1`, `phase2`, `phase2.5`, `phase3a`, `phase3b`, `phase4`, `phase5`, `phase6`); `finish` runs once after the Final Summary. Friction events (health-check blip, session recovery, host-guard stop, early abort, …) are recorded where the Phase 3a reference logs them. Never recorded: code, TC text, URLs, hostnames, Jira keys, file paths, customer data, secrets. Commands and codes: [the Run Metrics reference](${CLAUDE_PLUGIN_ROOT}/skills/execute-tests/references/run-metrics.md). A metrics failure never changes a verdict or blocks a phase.

**Environment detection (if base URL provided) — hard stop, no override:** (This checks the URL you were given; during execution the browser is also re-checked after every navigation — see [the Host Guard reference](${CLAUDE_PLUGIN_ROOT}/skills/execute-tests/references/host-guard.md).) For each `(Epic, URL)` pair — `*-dev.maxxton.net` or `*-test.maxxton.net` → proceed immediately. **Any other URL (production, staging, unknown, or anything not matching those two patterns) → stop the run for that Epic immediately.** Do not ask for confirmation and do not offer a way to proceed anyway — there is no "yes, run it on prod" path. Do not set `QA-RUNNING` for that Epic. In a multi-Epic invocation this blocks only that Epic; others with valid URLs proceed normally. Report (full message format: [the preflight detail reference](references/preflight-detail.md)):
> ⛔ `<EPIC_ID>` → `<URL>` is not a dev/test environment (`*-dev.maxxton.net` / `*-test.maxxton.net` only). This pipeline only runs against dev/test — re-run with a dev or test URL.

**Target repo detection (runs immediately after Environment detection, per Epic):** MCMS and MXTS specs live in two separate GitHub repos — derive `target_repo` from the Epic's execution URL hostname (`cms` in hostname → `mcms-qa-automation`, otherwise `mxts-qa-automation`), persist it to `run-state.json` immediately, and let every Phase 6 GitHub call and `post-pr-comment.js` target `MaxxtonGroup/<target_repo>`, never a hardcoded repo. Full hostname rules and log line: [the preflight detail reference](references/preflight-detail.md).

**Jira write-path check (run once per Epic, first — before lock acquisition or any other Jira write below):** Resolves and persists `jira_write_path` per Epic (`script` when a working Jira token is configured, otherwise `mcp` — never a prompt, no setup for the user) together with `screenshot_upload_enabled`. Full procedure (Step 0–2) and the token-less path ([MCP write path](references/jira-mcp-write-path.md)): [the Phase 3a execution reference](references/phase-3a-execution.md).

**Concurrency lock check:** Acquire `QA-RUNNING` per Epic before starting any pipeline work; if already present, resolve same-runner vs. stale vs. genuinely-active in that order before proceeding or hard-blocking. Full procedure: [the preflight detail reference](references/preflight-detail.md).

**URL guard / execution mode:** No URL provided for an Epic → do not ask the user for one; automatically run that Epic in **Generation only** mode (Phases 1–2, or 1–3b if QA-stage stories are present) and log `[URL] No URL provided for <EPIC_ID> — running Generation only mode automatically.` URL provided (environment confirmed dev/test above) → **Pre-authenticated run**, all phases: check browser session state and navigate/log in if needed (see [the preflight detail reference](references/preflight-detail.md)) — the pipeline detects your session automatically.

**Build / version capture (runs after URL guard):** Auto-detect via the ordered fallback in [the preflight detail reference](references/preflight-detail.md) (Steps 1–3 detect; Step 4 there is the `"Not provided"` fallback). **URL provided (pre-authenticated run)** — by this point URL guard has confirmed the browser is navigated and logged in on `<base URL>`, so all 3 steps apply: Jira `fixVersions`, then the `browser_evaluate`-based Assistance popup / DOM heuristic against that live, authenticated page. Running this after URL guard rather than before matters — Steps 2–3 read the live app DOM, so capturing beforehand means they'd read a blank/stale page and always miss. **No URL provided (Generation only mode)** — no browser session exists (URL guard's Generation-only path never touches Playwright), so only Step 1 (`fixVersions`) applies; Steps 2–3 are skipped entirely, never attempted. If nothing is found after the applicable steps → do not ask the user; silently set `build_version = "Not provided"` and continue. Log: `[Build] Could not auto-detect version — using "Not provided".` Store as `build_version`; reused for all Epics.

---

## Compaction & State Recovery

> ⛔ **This pipeline must be fully re-derivable from disk — never from conversation memory.** On a long run the conversation may be summarized (compacted) at any point, dropping earlier steps, verdicts, flags, and even this skill's own instructions from context. Every step therefore **persists its outcome to `test-output/<EPIC_ID>/` the moment it is produced**, and **re-anchors from disk before acting**. No step's result may live only in context.

**Durable state — all under `test-output/<EPIC_ID>/`:**

| File | Holds | Written |
|---|---|---|
| `run-state.json` | current `phase`, `target_repo`, per-story `stage`, `jira_write_path`, `screenshot_upload_enabled`, `tc_skip_automation`, `tc_already_automated`, `tc_already_automated_repo` (the `target_repo` that list was searched against — see Phase 2's Automation Derivation), `tc_comment_id`, `tc_parts` (the planned split of a Test Cases comment longer than 45 rows, with each part's `comment_id`; `null` when one comment), `tc_comment_path`, `results_comment_path` (`script` | `mcp` — which write path created each comment, for the same-path edit rule), `result_parts` (the planned split of a results comment longer than 45 rows, with each part's `comment_id` — see the split results reference; `null` when one comment), `cycle_started_at`, `user_wait_seconds` (accumulated pause time this cycle — Session Recovery waits plus gaps over 10 minutes found when the run was resumed), `pause_count` (how many such pauses) and `last_activity_at` (the heartbeat those gaps are measured from) — see Pause Tracking in phase-3a-execution.md and Phase 3b's Test Execution Timing computation; all of these timing fields are written by `scripts/run-timing.js`, never by hand, `results_comment_id`, `phase5_done`, `partial_run` (set by Phase 3b's partial-run detection, read by Exit Gate — see phase-3b-results-comment.md and phase-5-defects-and-exit.md), `pr_url`, `feedback_asked_at` / `feedback_outcome` / `feedback_entry` (when a feedback prompt was last answered or declined, for which outcome, and the saved reply `{ text, date, mention, canvas_done, channel_done }` — written before any Slack post so nothing is lost; see Feedback Collection; counts as "already asked" only while not earlier than the latest story `cycle_started_at`, so a new cycle asks again), `pr_comment_id` (MCP-fallback runs only — see phase-3a-execution.md's MCP fallback table), `flags_enabled_this_run`, `flags_disabled_this_run` (the mirror list — flags switched OFF for a flag-OFF TC; read and written the same way, both persisted the moment a flag is toggled, and read on resume so teardown still restores them), per-story `ac_overrides` (acceptance criteria superseded by a later developer/PM/BA comment — see phase-1-context-extraction.md step 3k; refreshed on resume from the same fetched comments), per-story `url_timing` (`{ "<hostname>": { "ended_at": <ISO>, "user_wait_seconds": <n>, "pauses": <n> } }` — per-URL timing boundaries for multi-URL runs, written as each URL's TC suite finishes; see Phase 3b Test Execution Timing), per-story `subtask_key` (set when the run tests a Sub-task under its parent — see Sub-task keys in phase-1-context-extraction.md; the Story Action is skipped for such a run), per-story `video_findings` (`{ attachment_ids, summary }` from Phase 1 step 3o on a Bug ticket; durable like `known_limitations`, read on resume instead of re-reading the video), per-story `preconditions_verified` (see Precondition Evidence Check in phase-3a-execution.md), per-story `known_limitations` (a durable fact about the ticket, not a per-cycle artifact — never cleared on `--retest`/`--force`; refreshed independently of whether Phase 1 itself ran this pass, see phase-1-context-extraction.md step 3j and the Known-Limitation Refresh in phase-3a-execution.md), per-story `dev_qa` (the developer's "For QA:" template — Major Impact, Main Tests, Concerns, Additional Notes; durable like `known_limitations`, replaced by the newest such comment on every Phase 3a refresh, see phase-1-context-extraction.md step 3l) and `change_types` (from step 3m), and per-Epic `env_check` (`{ checked_at, concern, status }` — the read-only Environment-Down Check result, see execute-tests/references/environment-down-check.md) | after **every** phase/gate transition |
| `results.md` | per-TC verdicts | **incrementally, after each TC** (Phase 3a) |
| `execution-log.json` | per-TC selectors + verdicts | **incrementally, after each TC** (Phase 3a) |
| `triage.md` | triage output | after Phase 4 |

`run-state.json` shape (write it the moment any field changes — this is the single source of truth for orchestration flags):

```json
{
  "epic": "<EPIC_ID>",
  "phase": "phase3a",
  "jira_write_path": "script", "screenshot_upload_enabled": true,
  "target_repo": "mxts-qa-automation",
  "pr_url": null, "feedback_asked_at": null, "feedback_outcome": null, "feedback_entry": null,
  "flags_enabled_this_run": [{ "flag": "NEW_CHECKOUT_FLOW", "host": "mqa-dev.maxxton.net" }], "flags_disabled_this_run": [], "flags_heartbeat_at": null,
  "stories": {
    "<STORY_KEY>": { "stage": "qa", "tc_skip_automation": ["TC_04"], "tc_already_automated": ["TC_02"], "tc_already_automated_repo": "mxts-qa-automation", "tc_comment_id": "10501", "tc_parts": null, "cycle_started_at": "2026-08-14T09:00:00Z", "user_wait_seconds": 0, "pause_count": 0, "last_activity_at": "2026-08-14T09:00:00Z", "url_timing": {}, "results_comment_id": null, "results_comment_path": null, "result_parts": null, "tc_comment_path": null, "phase5_done": true, "partial_run": false, "preconditions_verified": [], "known_limitations": [], "ac_overrides": [] }
  }
}
```

`cycle_started_at` is recorded once, the moment Phase 3a starts fresh for a story this invocation (see Phase 3a), and reset by `--retest` or `--force` (see those flags below). It scopes the Phase 3b "already posted" check to the CURRENT test cycle only, so a prior (pre-reopen) cycle's results comment is never mistaken for a duplicate — see Phase 3b. `user_wait_seconds` is initialized to `0` alongside it (with `pause_count` = `0` and `last_activity_at` = the same timestamp) and resets on the same triggers; it accumulates the time the tester was away — explicit Session Recovery waits, plus any gap over 10 minutes between the last recorded activity and a resume (see Pause Tracking in phase-3a-execution.md) — and is what Phase 3b's Test Execution Timing row subtracts from elapsed wall-clock time, with `pause_count` appended as ` (<n> pauses)`, so a slow human re-login or a run split over several sessions still gets a number, never N/A. `results_merged` (per story) is `true` once the first cycle's results were written INTO the Test Cases comment; it is set in the same step as `results_comment_id` (= `tc_comment_id`) and `results_comment_path` (= `tc_comment_path`), and `--retest`/`--force` clear it with them. It is a convenience, not the truth: after a compaction the truth is the comment in Jira — `tc_comment_id` (or the comment whose first line is `Test Cases — <STORY_KEY>`) still starting with `Test Cases —` means not merged yet, starting with `QA Test Results` and carrying the 12-column table means merged; see the compaction note in [the Phase 3b results reference](references/phase-3b-results-comment.md). `tc_comment_id` itself is never cleared by `--retest`, and after a merge it points at the merged comment.

`flags_enabled_this_run` (top-level within one Epic's `run-state.json` — shared across every story in that Epic, not per-story) lists feature flags this run itself switched on because it found them disabled (see Feature Flag Setup in [the Phase 3a execution reference](references/phase-3a-execution.md)). Written the moment a flag is enabled, read at Final Summary to disable them again. `flags_disabled_this_run` is the mirror: flags this run switched OFF (found enabled, to verify a flag-OFF TC), read at Final Summary to enable them again. A flag the run never changed is never added to either list and is never touched at teardown. Each entry is `{ "flag": "<name>", "host": "<base host the flag was changed on>" }` — flags are per environment, so a restore or a net-change only ever applies to entries whose `host` is the environment being restored (a bare string from an older plugin version is read as `{ flag, host: <current environment> }`). `flags_heartbeat_at` (top-level, ISO time) is rewritten after every toggle and after every TC while either list is non-empty; the startup restore leaves an Epic's entries alone unless that timestamp (or, if absent, the file's modified time) is more than 30 minutes old, because a fresher one belongs to a run still active in another session.

> ⛔ **`run-state.json` is per-Epic** — `test-output/<EPIC_ID>/run-state.json`, not one file shared across the whole invocation. In a multi-Epic run, a flag enabled while processing Epic A is recorded in *Epic A's* `run-state.json` only. Feature Flag Teardown (Final Summary) must read **every Epic's own `run-state.json`** processed this invocation, not just the last one — otherwise a flag enabled early in a multi-Epic batch is never torn down.

**Recovery Protocol — run this the moment you are unsure of the current phase, story, or any flag/verdict (the clearest trigger is noticing the conversation was just summarized/compacted):**
1. **STOP.** Do not post, create, transition, upload, or prompt the user from memory.
2. Re-read this SKILL.md and the reference file for the current phase.
3. Re-read `run-state.json` and re-run the **Resume Check** below to locate the first unfinished step.
4. Re-load per-story data from disk: verdicts from `results.md`, the TC table from its Jira comment, all flags from `run-state.json`. If `test-output/<EPIC_ID>/parallel/<STORY_KEY>` exists also run `node "$CLAUDE_PLUGIN_ROOT/skills/test-ticket/scripts/parallel-split.js" status test-output/<EPIC_ID>/parallel/<STORY_KEY>` (add `/<hostname>` on a multi-URL run) and follow [the parallel execution reference](references/parallel-execution.md) from the step it names, but only when its `plan.created_at` is after this run began.
5. Continue from the first unfinished step. **Never re-post, re-create, re-transition, or re-prompt anything an artifact shows is already done.** The scripts' duplicate/target guards are a backstop — not a licence to guess.

---

## Resume Check (runs before Phase 1)

Before skipping any phase — on every invocation, including every resume — run the permission-toggle startup check and the feature-flag startup restore (both sections at the top of the Phase 3a reference, run from here) — only when the invocation has an execution URL; a Generation-only run (no URL) has no environment to scope them to and skips both —, so a crash after the shared Maxxton Admin role or a flag was changed cannot be skipped over by a resume past Phase 3a. **Feedback Recovery also runs here, on every invocation (URL or not):** it posts feedback a dead session left unposted and asks about any started cycle that ended with no feedback asked — [the feedback collection reference](references/feedback-collection.md). Unless `--force` is passed, inspect existing artefacts:

| Phase | Check | Skip if |
|---|---|---|
| 1 — Read Requirements | Does `test-output/<EPIC_ID>/` exist? | Directory found |
| 2 — Generate Test Cases | Does each story have a `TC_01` comment? (per story) — the `Test Cases — <KEY>` comment, **or the same comment after execution** (first line `QA Test Results`, 12-column table with Preconditions and Test steps); a split TC comment (`Part n of m`) counts only when every part is there | TC comment found — generation skipped; Automation Derivation still runs before Phase 2.5 |
| 2.5 — Impact Analysis | Does `story.impact_summary` exist in memory for all QA-stage stories? | Impact summary found |
| 3a — Execute Tests | Does `results.md` have a non-"To be Tested" verdict? | File exists with result row, unless `parallel/<STORY_KEY>` holds a run whose `status` is not `done` (kept worker verdicts are written to `results.md` before the solo phase) |
| 3b — Playwright Tests | Does `<STORY_KEY>.spec.js` exist in `test-output/`? | File found on disk |
| 4 — Triage | Does `triage.md` exist with content? | File exists and non-empty |
| 5 — Raise Defects | Is `stories.<STORY_KEY>.phase5_done` true in `run-state.json`? (per story) | Flag set — Phase 5 already reached a real decision this pipeline's lifetime (bugs raised/matched, zero product defects, or the user declined the proposal). Not a Jira query: a story can legitimately finish Phase 5 with zero new Bugs, which a "does a linked Bug exist" check could never distinguish from "Phase 5 hasn't run yet" — see Phase 5's own persistence rule in [the Phase 5 defects and exit reference](references/phase-5-defects-and-exit.md) |
| 6 — Publish Specs | `run-state.json` has `pr_url`, OR an open PR with head `qa/specs/<EPIC_ID>*` exists | Found — reuse, do not create a duplicate PR |

Output a resume status table before starting (format: [the output formats reference](references/output-formats.md)). Run the Status Gate's live status re-read (see the Status Gate section) for every story now, before the first skipped or resumed phase from 2.5 onward is acted on: a story that fails it shows `[SKIP] not QA-stage (<status>)` in Phases 2.5–5 of that table.

**Resume decision — automatic, no prompt:** If any phase is being skipped (prior run detected) and neither `--force` nor `--from=` was explicitly passed, **default to resume, always** — do not ask. The per-phase resume-detection table above already checks the real state of each artifact (Jira comments, `run-state.json`, execution logs) before deciding a phase is skippable; that check is the decision, not a guess that needs a human to confirm. Log: `[Resume] Previous run detected for <EPIC_ID> — resuming from Phase <first-pending-phase>.`

`--force` remains the only way to restart all phases from Phase 1 — pass it explicitly when a full re-run is genuinely wanted (e.g. requirements changed materially since the last run). `--from=phase<ID>` remains the way to force-start from a specific phase.

**`--from=phase<ID>` flag:** Force-start from `phase1` / `phase2` / `phase2.5` / `phase3a` / `phase3b` / `phase4` / `phase5` — this resumes the CURRENT cycle from a specific point (e.g. Phase 3a finished but Phase 3b errored); it does NOT clear `results_comment_id`, `result_parts` or `cycle_started_at`, since no new test cycle is starting. **Exception:** if `stories.<STORY_KEY>.cycle_started_at` is already set for a story when `--from=phase1` / `phase2` / `phase2.5` / `phase3a` is passed for it, an earlier attempt already ran a cycle for that story — re-running execution now (to fix bad verdicts, a wrong selector, etc.) IS starting a new cycle for that story specifically. Trigger on `cycle_started_at`, not `results_comment_id` — an all-`BLOCKED` cycle sets `partial_run = true` and stamps `cycle_started_at` but deliberately skips posting a results comment (see phase-3b-results-comment.md), so `results_comment_id` alone would miss that case and leave the prior cycle's `partial_run`/`cycle_started_at` to bleed into the new attempt, wrongly forcing Phase 5 to BLOCKED again and inflating Test Execution Timing with the earlier cycle's elapsed time. Clear `results_comment_id`, `results_comment_path`, `results_merged`, `cycle_started_at`, `user_wait_seconds`, `pause_count`, `last_activity_at`, `url_timing` (to `{}`), `phase5_done`, and `partial_run` for that story only, and delete that story's entries from `screenshot-hashes.json` (or the whole file if this is the only QA-stage story in the Epic) — same reset `--retest`/`--force` perform — so Phase 3b posts the corrected results as a new comment, Phase 5 re-evaluates the corrected verdicts, and this cycle's fresh screenshots aren't flagged as duplicates of the prior cycle's, instead of any of the three silently no-op'ing against the earlier cycle. (`--from=phase3b`/`phase4`/`phase5` never hit this exception — they resume after Phase 3a already produced this cycle's real verdicts, so there is nothing to re-derive.)

**`--force` flag:** Re-run all phases from scratch — delete `results.md`, `execution-log.json`, `triage.md`, and `screenshot-hashes.json` first (same list as `--retest`). Like `--retest`, this starts a NEW test cycle — clear `stories.<STORY_KEY>.results_comment_id`, `results_comment_path`, `results_merged`, `result_parts`, `cycle_started_at`, `user_wait_seconds`, `pause_count`, `last_activity_at`, `url_timing` (to `{}`), `phase5_done`, **and `partial_run`** to `null`/`0`/`false` in `run-state.json` for every affected story, and delete `run1_verdicts` (Phase 3a will re-stamp `cycle_started_at` and re-initialize `user_wait_seconds` when it starts). Without this, a `--force` re-run of a story that was already tested and reopened would find the stale `results_comment_id`/`cycle_started_at` from the prior cycle still on disk and wrongly treat this new cycle as already-posted, silently skipping the results comment entirely — and the stale `phase5_done` would make the resume check skip Phase 5 even though this cycle produced fresh triage results.

**Persist after resolving:** Write `test-output/<EPIC_ID>/run-state.json` with the resolved `phase` and each story's `stage`. On resume (or after compaction) read `jira_write_path`, `screenshot_upload_enabled` and each story's `tc_skip_automation` / comment IDs from this file — do **not** re-derive or re-prompt for a value it already holds. Update the file whenever any of these change (see Compaction & State Recovery above).

---

## Phase 1: Read Requirements

*Skip if: resume check found existing requirement summary.*

1. Fetch Epic from Jira (`getJiraIssue`). A key that turns out to be a Sub-task is resolved first — see "Sub-task keys" in [the Phase 1 context extraction reference](references/phase-1-context-extraction.md).
2. Fetch child stories: `"Epic Link" = <EPIC_ID> AND status != Done ORDER BY created ASC` — use `fields: ["summary", "description", "subtasks", "issuelinks", "fixVersions", "components", "labels", "priority", "status", "assignee", "reporter", "issuetype", "attachment"]` to get everything in one call (comments are read separately with `mcp__claude_ai_Atlassian_MCP__executeRead` `name: listJiraIssueComments`).
3. **Extract full implementation context — nothing skipped.** Sub-steps 3a–3o (comments, subtasks, linked issues, structured description sections, components/labels, feature flags, linked PR, preconditions, Integration Manager, known limitations, AC overrides, the developer's "For QA:" template, change-type signals, ticket images, and — on Bug tickets only, through the `Skill` tool — ticket videos) and how to build `story.impl_context` from them, plus the Source priority & grounding rule that governs Phase 2: [the Phase 1 context extraction reference](references/phase-1-context-extraction.md). Missing any one source is a TC coverage gap in Phase 2.

4. Fetch linked Confluence pages (`getConfluenceContent`) and search for LLD/HLD/exit docs (`searchConfluence`)
5. Extract structured requirement summary (feature overview, functional requirements, ACs, coverage gaps) — include the full `story.impl_context` from step 3 as primary scope context alongside the ACs. Where impl_context is more specific than the ACs, use impl_context to set TC scope.
Log: `[Phase 1 complete] <n> stories processed — <n> Confluence docs read`

---

## Status Gate (after Phase 1, before Phase 2)

Read `status.name` from Jira data already fetched in Phase 1. **Every invocation that skipped Phase 1 (a resume, `--from=`, `--retest`) re-reads it live** (`getJiraIssue`, `fields: ["status"]`) for each story before any Phase 2.5, 3a, 3b, 4 or 5 work — `jira_status_at_start` in `run-state.json` is only the status the first run began with and never decides. A status that is not `qa_stage` (e.g. `Reopened`, `Resolved`, `In Progress`), or cannot be read, means no execution for that story in this invocation: no browser, no flag/permission/test-data change, no results or defect comment, no transition. Log: `[Status Gate] <STORY_KEY> is <status> — not QA-stage, execution skipped. Run again once the story is Ready for QA or Testing.` Only the `--force` Done-status promotion below overrides it; the crash-restore steps and Feedback Recovery in the Resume Check still run, because they undo or finish earlier work. Bucket each story using the Configuration block above. No match → use `default_bucket`, log a warning. Print a status summary before proceeding (format: [the output formats reference](references/output-formats.md)).

**Development-stage stories:** Include in Phase 2 only. Phase 2.5 and Phases 3a, 3b, 4, 5 are skipped — the PR is not yet available, and execution waits until the story reaches QA stage.

**`--force` + Done statuses:** If `--force` is passed, stories whose status maps to `development_stage` **and** whose Jira `statusCategory` is `Done` (e.g. `Checked by QA`, `Closed`, `Cannot Test`) are promoted to `qa_stage` for this run only — they get full Phase 3a execution. Log: `[Status Gate] <STORY_KEY> promoted to QA-stage for --force run (status: <status>).` Without `--force`, Done stories stay in development_stage and are never re-executed.

**QA-stage stories:** Verify test cases exist by reading the story's comments with `mcp__claude_ai_Atlassian_MCP__executeRead` with `name: listJiraIssueComments`. None found → run Phase 2 first. Apply `HL-Scenarios_Covered` label if missing. Phase 2.5 will run after Phase 2 to capture the blast radius from the linked PR.

Edge cases: all dev-stage → pipeline ends after Phase 2; all QA-stage → start at Phase 2 then 2.5; mixed → handle per bucket.

---

## Phase 2: Generate Test Cases

*Skip if: resume check found TC comment.*

Full procedure — generation steps 1–10, the auto-added TCs (5a frontend text, 5b location-variation) and the 5c self-check, Gate 1 (Scenario Review) and Gate 2 (Automation Exclusion), and the exact wiki-markup TC table format — is in [the Phase 2 test cases reference](references/phase-2-test-cases.md). Read it before generating or posting any TC table; the wiki-markup format there is fixed and must not be improvised from memory.

**Budget check after Phase 2:** If `total_tc_count × (--tc-timeout value, default 180s) > (--max-time value, default 90) × 60`, log: `[Phase 2] Budget warning: <n> TCs × <tc_timeout>s ≈ <estimated>min — exceeds --max-time=<max_time>min. Use --max-tcs=<n> to cap and stay within budget.`

Log: `[Phase 2 complete] <n> TCs across <n> stories | AC coverage: <covered>/<total> ACs`

If all stories for this Epic are development-stage → skip Phases 2.5, 3a–5 for this Epic. In Multi-Epic mode, continue to the next Epic in the batch rather than jumping to Final Summary — the Final Summary runs once after all Epics have been processed.

> **Scale note:** A story's TCs run on two browsers when that pays off ([the parallel execution reference](references/parallel-execution.md)), and one at a time in one browser otherwise (`--workers=1` forces that). For large Epics with many stories, use `--max-tcs` to stay within the run budget.

---

## Automation Derivation (after Phase 2, before Phase 2.5)

*Runs only when Phase 2 TC generation was skipped (TC comment already existed) AND the story is QA-stage.* No ask — `story.tc_skip_automation` is derived from the existing TC comment's `Automated` column (Gate 2 already asked this when the TCs were first generated), and `story.tc_already_automated` is recovered from `run-state.json` (or re-derived via a fresh duplicate check against `target_repo` if missing). Full procedure: [the Phase 2 test cases reference](references/phase-2-test-cases.md). Log: `[Automation] <STORY_KEY> — <n> TCs: <m> automated, <k> excluded, <j> already automated in <target_repo>.`

---

## Phase 2.5: Cross-Module Impact Analysis

*Skip if: `--skip-impact` flag is passed, story is dev-stage (no PR yet), OR resume check found an existing impact summary for this story. Runs after Phase 2 and the Status Gate, for QA-stage stories only — the linked PR is available by then, enabling code-level blast radius analysis rather than prose-only estimates.*

Full procedure — reading the linked PR, querying the technical graph, canonical module/QA resolution, and the impact-summary format — is in [the Phase 2.5 impact analysis reference](references/phase-2.5-impact-analysis.md). Store the result as `story.impact_summary`.

Log: `[Phase 2.5 complete] <n> modules in blast radius — Confidence: <level>`

---

## Impact Summary (after Phase 2.5, before Phase 3a)

*Skip if: `--skip-impact` was passed OR Phase 2.5 was skipped.*

Present the computed impact summary automatically (no interactive gate — the analysis is the source of truth), then decide whether to broadcast it to Slack. Full display format, the skip/do-not-skip conditions for the Slack broadcast, and the exact message-building steps (including the `<@USERID>` mention pitfalls that have bitten this pipeline in production) are in [the Phase 2.5 impact analysis reference](references/phase-2.5-impact-analysis.md) — read it before building or sending the Slack message.

Log: `[Impact] <STORY_KEY> — <n> modules identified, displayed, proceeding automatically.`, and on the Slack step: `[Impact] <STORY_KEY> — posted to Slack (<impact_slack_channel>)` on success, or the one-line failure warning documented in the reference.

---

## Phase 3: Execute Tests, then Generate Playwright Tests

### 3a — Execute Tests (live browser)

*Skip if: resume check found execution results.*

**Steps 0–1 — cycle stamp, MCP availability check, and stale-lock recovery** run first, in that order, before any TC execution. Any failure blocks all TCs and skips straight to Final Summary. Full procedure: [the Phase 3a execution reference](references/phase-3a-execution.md).

**Spec generation — no separate ask here.** Whether specs get generated (and a draft PR opened for them, Phase 6) was already decided per story by Gate 2 in Phase 2 (`story.tc_skip_automation`) — asking again here would be asking the same question twice. For each TC in this story: not in `tc_skip_automation` → capture its selector map during execution (below) and it gets a spec file in Phase 3b; in `tc_skip_automation` → executed normally, no selector capture, no spec file. If `tc_skip_automation` covers every TC in the story (via a manual `skip automation` response or `--skip-specs`), no selectors are captured for this story at all and Phase 6 has nothing to open a PR for.

> ⛔ `tc_skip_automation` controls **selector capture and spec file generation only** — it has no effect on screenshots. `browser_take_screenshot` is called for every TC regardless. Do not skip screenshots because a TC is in `tc_skip_automation`.

> ⛔ **Always pass `fullPage: true` to `browser_take_screenshot` — one screenshot per TC, taken once after all steps complete.** Finance/Bill pages need a Large-viewport capture exception; a bill-changing TC takes a Before/After pair instead of one screenshot ([the Bill Snapshots reference](${CLAUDE_PLUGIN_ROOT}/skills/execute-tests/references/bill-snapshot.md)); every call needs a pre-screenshot readiness check first; blank screenshots get retaken once. Full rules: [the Phase 3a execution reference](references/phase-3a-execution.md).

**Multi-URL execution and browser session detection** — running the full TC suite once per URL, and reusing/restoring the login session per URL: [the Phase 3a execution reference](references/phase-3a-execution.md).

**Execution scope:** `--max-tcs=N` → top N TCs by active order only. Log the cap at start.

**Pre-execution risk re-evaluation:** Scan each TC's scenario text against the `critical_paths` keyword list. Any match → override risk to `High` for this run. Log: `[critical_path] <TC_ID> risk overridden to High — matched "<keyword>"`.

**Execution order — normal run:** High risk → Medium risk → Low risk

**Scope and order — `--retest` mode:** a scoped retest, not a full re-run. Previous FAIL, then NEEDS REVIEW, then BLOCKED TCs first (High → Medium → Low within each); only when every previous FAIL now passes, the High-risk TCs that passed before; the first previous FAIL that fails again stops the run. Everything else keeps its previous verdict. Full procedure, recording and Jira comment marking: [the scoped retest reference](${CLAUDE_PLUGIN_ROOT}/skills/execute-tests/references/scoped-retest.md).

**Per-test timeout:** Default 3 min (`--tc-timeout=N` seconds). Exceeded → `BLOCKED 🚫 (timeout)`.

**Global run budget:** Default 90 min (`--max-time=N` minutes). Exceeded → remaining TCs `BLOCKED 🚫 (run budget exhausted)`, then **continue into Phase 3b/4/5 as normal** for whatever TCs did execute — same as Early abort below, and for the same reason: Phase 5's Exit Gate is what sets story status and releases this ticket's `QA-RUNNING` lock, so a partial/budget-exhausted run that never reaches it leaves both stuck. Confirmed in production 2026-09-24 (MXTS-77759): a budget-exhausted run (then still 30 min) posted its Phase 3b results comment but never reached Exit Gate — status stayed `Testing` and `QA-RUNNING` stayed locked until released manually.

**Early abort:** After 3 consecutive High-risk FAILs → stop execution automatically, no ask, and continue into Phase 3b/4/5 as normal for whatever TCs did execute. Full rationale: [the Phase 3a execution reference](references/phase-3a-execution.md).

For the full execution procedure — test data seeding, per-TC execution steps, BLOCKED/FAIL definitions, verdict tables, retry logic, PASS corroboration, retest cross-reference — see [the Phase 3a execution reference](references/phase-3a-execution.md). The TCs run on parallel browsers automatically when that pays off (`--workers=1` turns it off), falling back to this procedure when it does not: [the parallel execution reference](references/parallel-execution.md).

**Completeness gate (mandatory, before Phase 3b):** Before a story moves on to Phase 3b, re-parse its Phase 2 TC table mechanically (from Jira, not from the running count) and confirm every `TC_ID` has a recorded verdict — respecting `--max-tcs` if passed, and in `--retest` mode only the executed set. Any `TC_ID` missing a verdict is executed now, not deferred, and not reported as done until it has one. **Multi-URL stories:** run this check once per URL, against that URL's own `results_<hostname>.md` — a TC covered on URL 1 does not excuse a missing verdict on URL 2. Full procedure: [the Phase 3a execution reference](references/phase-3a-execution.md). **Evidence Review (right after the Completeness gate, before Phase 3b; `--skip-review` skips it):** one batched reviewer subagent checks the screenshots behind every High-risk PASS and can only downgrade it to NEEDS REVIEW; a reviewer failure keeps the PASS and is reported — [the Phase 3a execution reference](references/phase-3a-execution.md) → Evidence Review.

> **Do not post results to Jira yet.** Hold until after Phase 3b decision — the `Automated` column depends on spec generation outcome.

**Selector capture during execution** (for TCs not in `story.tc_skip_automation`) — recorded as a by-product of execution, no extra browser calls: [the Phase 3a execution reference](references/phase-3a-execution.md).

During execution: update `test-output/<EPIC_ID>/execution-log.json` and `test-output/<EPIC_ID>/results.md` **incrementally after each TC's verdict is finalized** (not only at the end) so a mid-run compaction never loses completed verdicts. See [the Phase 3a execution reference](references/phase-3a-execution.md) for file formats.

**Generation only mode (no base URL):** Skip 3a. Run 3b with TC table only — all selectors will be TODO placeholders.

---

**NEEDS REVIEW handling (after 3a, before 3b) — no ask, posted as-is:** Any TC that finished Phase 3a with verdict `NEEDS REVIEW 🔍` flows straight into Phase 3b and the Jira results table exactly as captured — no human pass/fail decision is requested. The `Actual Result` column already holds the real observation from execution (that's what made the verdict ambiguous in the first place — see "NEEDS REVIEW verdict... never guesses PASS/FAIL" in Phase 3a); `NEEDS REVIEW` in the `Status` column is itself the honest signal to whoever reads the ticket, not a placeholder waiting on a human to resolve it in-session. Log: `[Phase 3a] <n> TC(s) posted as NEEDS REVIEW — no resolution requested.`

---

### 3b — Generate Playwright Tests

**No separate resolution needed here** — `story.tc_skip_automation` (set by Phase 2 Gate 2, or derived from the existing TC comment on the resume path — see Automation Derivation) already fully decides spec generation per TC; there is nothing left to ask or resolve at the start of 3b.

**`story.tc_skip_automation` / `story.tc_already_automated` guaranteed by Phase 3b:** If either is still not set for a story for any reason (e.g. `--from=phase3b` bypassed both Phase 2 and the Automation Derivation step), default `tc_skip_automation` to `[]` — all TCs are eligible for automation — and `tc_already_automated` to `[]` — no known existing specs, so this run may generate one that turns out to duplicate an existing file (Phase 6's duplicate-PR guard and human review are the backstop, not a reason to skip the default). Log: `[Phase 3b] tc_skip_automation/tc_already_automated not set for <STORY_KEY> — defaulting to automate all / none known-automated.`

**Automation exclusion (`story.tc_skip_automation` from Phase 2 Gate 2) and duplicate automation (`story.tc_already_automated` from the Phase 2 duplicate check):**

> `tc_skip_automation` controls **spec file generation only** — it does NOT skip execution. Every TC in this list was still executed in Phase 3a and has a real actual result. The exclusion only means no Playwright `.spec.js` is generated for it. `tc_already_automated` means a spec already exists in `target_repo` for this TC — generating another would be a duplicate, not a fresh exclusion, so its `Automated` column stays `Yes` even though Phase 3b writes no new spec for it.

- TCs in `tc_already_automated` → `Automated = Yes` (genuinely automated already); skipped from spec file generation — an existing spec already covers it. Actual result column is still populated from Phase 3a execution.
- TCs in `tc_skip_automation` (and not in `tc_already_automated`) → `Automated = No` in the Jira results table; skipped from spec file generation. Actual result column is still populated from Phase 3a execution.
- TCs NOT in `tc_skip_automation` and NOT in `tc_already_automated` → `Automated = Yes`; generate spec files using `selector_map` from `execution-log.json`.
- If `tc_skip_automation` ∪ `tc_already_automated` covers all TCs for the story → no *new* spec file is generated; log: `[Phase 3b] All TCs excluded or already automated — no new spec file generated.`

**Selector priority for spec generation:**
1. `selector_map` captured in Phase 3a — always preferred (real, validated selectors)
2. Other `execution-log.json` entries (navigation paths, verdicts)
3. Patterns from the bundled Playwright reference library for known Angular/MXTS components
4. TODO placeholder only if selector was never encountered during Phase 3a execution

**Spec-writing conventions — same bar as `/generate-playwright-tests`, not a lesser one.** Before writing any spec code — every time, not once per session — complete Step 4 of `/generate-playwright-tests` (`${CLAUDE_PLUGIN_ROOT}/skills/generate-playwright-tests/SKILL.md`): read the target repo's `CLAUDE.md`, `TEST_WRITING_REFERENCE_MAIN.md` and module reference file fresh from the latest `origin/develop`, and write to those rules — do not write from memory. Three rules generated specs have violated in production (see MXTS-78992 PR review, `mxts-qa-automation#123`) — treat these as non-negotiable regardless of how thin this section is compared to that skill's Step 6:

- **Import**: always `import { test, expect } from '#mxts-test';`. Never `require('@playwright/test')` or `import ... from '@playwright/test'` in a module spec — that bypasses the shared login + module auto-navigation fixture.
- **A TODO-placeholder TC must never silently pass.** If a TC has no verified selector (BLOCKED by an undeployed dependency, no `selector_map` entry for it in `execution-log.json`, or Generation Only mode) wrap it in `test.fixme('<TC name> — TODO: <reason>', async ({ page }) => { ... })`. A plain `test()` containing only a TODO comment and no `expect()` calls reports a false PASS in CI — this is worse than not generating the test at all.
- **API assertions check the response status before parsing the body**: `expect(res.ok()).toBeTruthy();` (or `await expect(res).toBeOK();`) before `await res.json()` — parsing an error response as JSON produces a confusing failure on the wrong line instead of a clear one on the status check.

**Post results comment to Jira** (after spec decision) — full procedure, exact wiki-markup templates (single-URL and multi-URL), pre-posting self-check, column rules, debug-evidence appending, and partial-run detection: [the Phase 3b results-comment reference](references/phase-3b-results-comment.md). The format there is fixed — never improvise it from memory, and never post more than one results comment per story per run — except when the results exceed 45 rows (TCs × URL blocks): then they are posted as planned, validated parts per [the split results reference](references/phase-3b-split-results.md).

**Only if the story has at least one TC eligible for a new spec** (per the `tc_skip_automation` ∪ `tc_already_automated` decision above — i.e. the "no new spec file is generated" bullet did NOT apply to this story): generate one `<STORY_KEY>.spec.js` for it, using the selector priority above, and write it to `test-output/<EPIC_ID>/<STORY_KEY>.spec.js`. **No eligible TC** → write no file for this story, skip straight to the label step below, and this story contributes nothing to Phase 6 (it has no file for Phase 6 to publish).

**Add `QA_Pipeline` label** — after posting the results comment, run `node "$CLAUDE_PLUGIN_ROOT/skills/test-ticket/scripts/add-label.js" "<STORY_KEY>" "QA_Pipeline"` (or its MCP fallback — `getJiraIssue` + `editJiraIssue` — when `jira_write_path = mcp`; see phase-3a-execution.md's "Jira Write-Path Check"). The script reads current labels from the API, appends only if not already present, and writes back — it never replaces the full array; the MCP fallback must do the same (read, append, write the full array).

> ⛔ **This step must not fail silently — a posted results comment with no `QA_Pipeline` label undercounts pipeline throughput** (confirmed in production, MXTS-81133: results comment posted, label never applied, no failure surfaced anywhere). This step runs regardless of how the ticket was scoped down — `--max-tcs`, `--max-time`, `tc_skip_automation`, or a user's own "small ticket, finish fast, don't use many tokens" framing (confirmed in production, MXTS-80897, Sep 2026: exactly that framing produced a run with no label and a non-template comment) — none of those exempt it. On a non-zero exit (or an MCP-fallback `editJiraIssue` error): retry once. If the retry also fails, re-read `fields.labels` via `getJiraIssue` to check whether an earlier attempt actually landed it despite the error (the read-modify-write is not atomic, so a reported failure can still have succeeded) — only if it's genuinely still missing, log `[Phase 3b] <STORY_KEY> — failed to add QA_Pipeline label after retry: <error>` and surface it under ACTION REQUIRED in the Final Summary with the story key, so it can be applied manually. Never let this step's failure block or delay the rest of the story's pipeline flow — log and continue. **Then run Feedback Collection (below) once for the Epic, with `outcome = executed`** — after every story in it has finished this section (results comment posted, `QA_Pipeline` label step done) and before Phase 4. Skipped for `--unattended` and Generation only runs. The guards in [the feedback collection reference](references/feedback-collection.md) make the later calls skip a cycle already asked here.

---

## Phase 4: Triage Results

*Skip if: resume check found triage data, or Phase 3a was skipped.*

For each FAIL, BLOCKED, and NEEDS REVIEW verdict, classify using these criteria:

| Classification | When to apply |
|---|---|
| `product defect` | Feature does not behave as specified in the AC — expected behaviour is clearly defined and actual behaviour is wrong |
| `tooling misread` | Playwright MCP snapshot captured a transient state (loading spinner, animation frame, element not yet rendered) — the feature likely works; a re-run would pass |
| `test case issue` | TC steps or expected result are wrong/ambiguous — the feature may work correctly but the TC was poorly written or targets the wrong element |
| `needs review` | Genuinely unclear even after 3 attempts; requires human investigation, additional test data, or environment access not available in this run |

> ⛔ **Never classify a design-fidelity `NEEDS REVIEW` (forced by the Phase 3a Verdict Determination rule — an element/behaviour contradicting an approved design or already flagged by the reporter) as `tooling misread`.** `tooling misread` means the *tool* saw a transient rendering state, not that the *feature* is wrong — a confirmed design deviation is real regardless of how many times it re-runs. If Phase 3a already confirmed the deviation was present (not a loading-state artifact), it must be `product defect` or `needs review`, never `tooling misread`.

Write result to `test-output/<EPIC_ID>/triage.md`. Only TC IDs from the Phase 2 table are eligible for triage — any verdict without a matching TC_ID from Phase 2 is discarded, not classified or proposed as a defect. **Environment flagged broken ≠ product defect:** when half or more of a story's executed TCs ended `FAIL`/`BLOCKED`, run the read-only [Environment-Down Check](${CLAUDE_PLUGIN_ROOT}/skills/execute-tests/references/environment-down-check.md) (reuse `env_check` from `run-state.json` if Phase 3a already ran it); status `broken` → classify those TCs `needs review` (`Environment flagged broken by Oracle Bot (<concern>) — not a confirmed product defect`) and propose no defects from them; `not_flagged`/`unavailable` → classify as usual.

Log: `[Phase 4 complete] <n> product defects, <n> tooling misreads, <n> test case issues, <n> needs review`

**Triage Review Gate (before Phase 5):** Print triage table (format: [the output formats reference](references/output-formats.md)) and ask: "Proceed? (yes / no)" or accept `reclassify <TC_ID> as <classification>`.
- `reclassify` → update in memory AND overwrite `triage.md` on disk immediately, re-print, ask again.
- `no` → abort Phase 5. `triage.md` is current on disk. Log: `[Phase 4] Triage gate declined — run with --from=phase5 after reviewing triage.md`

**`--unattended`:** Skip this gate — proceed to Phase 5 automatically. **`--auto-raise`:** Does NOT skip this gate — triage classification is always required. It also no longer skips anything in Phase 5: ticket creation there always requires explicit user confirmation, regression or not (see Phase 5 below).

Compute and store execution completeness: `(PASS + FAIL confirmed + SKIP) / total TCs`. A `SKIP` is a settled, confirmed outcome (one clean execution against a developer-documented limitation — see the Known-Limitation Check in [the Phase 3a execution reference](references/phase-3a-execution.md)), unlike `BLOCKED`/`NEEDS REVIEW` which represent incomplete verification — neither of those two count.

---

## Phase 5: Raise Defects

Data Integrity Gate (default 60% completeness, `--min-completeness=N`), dedup (JQL checks A/B), failure clustering, and the defect-proposal/confirmation flow — full procedure in [the Phase 5 defects and exit reference](references/phase-5-defects-and-exit.md).

---

## Story Action and Exit Gate (after Phase 5)

*Story Action skips entirely if Phase 3a was skipped, or triage found zero Product-Defect-classified TCs this run. Exit Gate skips entirely if Phase 3a was skipped (generation-only mode).*

**Story Action:** No ask — the story's next status (`Checked by QA` vs `Reopened`) follows deterministically from whether a failure this run ended up tracked by a Bug. **Skipped for a run that tests a Sub-task under its parent** (`stories.<STORY_KEY>.subtask_key` set): one sub-task's result says nothing about the whole story, so no status changes — log `[Story Action] skipped — sub-task run under <PARENT>.` **Exit Gate:** pass rate and open-P1/P2 thresholds from the `exit_gate` Configuration block decide each story's DoD status, with an optional auto-transition on PASSED — computed and logged for a sub-task run too, but its auto-transition never fires (no status change at all). Full procedure for both: [the Phase 5 defects and exit reference](references/phase-5-defects-and-exit.md).

Log per story: `[Exit Gate] <STORY_KEY> DoD: <PASSED|BLOCKED> (pass rate: <n>%, P1/P2: <n>).`

> ⛔ **Immediately after Exit Gate above (this step is unconditional — it does not wait for Phase 6, and it runs whether or not Phase 6 ends up running at all):** run `node "$CLAUDE_PLUGIN_ROOT/skills/test-ticket/scripts/remove-label.js" "<EPIC_ID>" "QA-RUNNING"` for **this ticket** (or its MCP fallback when `jira_write_path = mcp` — same read-then-write rule as Acquisition, see [the preflight detail reference](references/preflight-detail.md); `remove-label.js` hard-requires `JIRA_EMAIL`/`JIRA_API_TOKEN` and exits non-zero without them). Phase 6 below is conditional on spec files having been generated — a ticket can skip it entirely — so the release must not live inside Phase 6's own body; putting it here, right after the step that is never skipped for a pre-authenticated run, is what makes it unconditional. Per-Ticket Completion below documents the full rationale and is a backstop, not where this normally executes. The script is idempotent (exits 0, no-ops if the label is already absent), so it is always safe to call again later (e.g. the connector-outage path in Error Handling, or the Final Summary safety net).
>
> **Generation only mode (no URL, Phase 3a/Exit Gate skipped entirely):** there is no Exit Gate step to hang this release off — for those tickets, Per-Ticket Completion below is the primary release point, not a backstop.

---

## Phase 6: Publish Spec Files to GitHub

*Runs automatically if this Epic had a base URL AND at least one spec file was generated in Phase 3b — no separate PR confirmation, no separate "generate specs?" ask.* Gate 2 (Phase 2) is the only opt-in. Generation only mode (no URL) never reaches this phase, even when Phase 3b produced a TODO-placeholder spec for a QA-stage story — see [the Phase 6 publish reference](references/phase-6-publish.md). This ticket's `QA-RUNNING` lock was already released above, right after Exit Gate — Phase 6 failing (or not running at all) has no effect on it.

Duplicate-PR guard, branch/push/draft-PR creation against `MaxxtonGroup/<target_repo>` (resolved during Pre-flight — see Target repo detection), and per-story label + PR-link comment attribution — full procedure in [the Phase 6 publish reference](references/phase-6-publish.md).

---

## Per-Ticket Completion

> ⛔ **For a pre-authenticated run, `QA-RUNNING` for this ticket was already released above, immediately after Exit Gate — before Phase 6, never deferred to the Final Summary, and never gated on Phase 6 finishing. For a Generation only ticket (no Exit Gate ran), this section is where it releases instead — that is its normal, expected release point, not a fallback.** In a multi-ticket invocation ("Tickets run sequentially — one complete pipeline at a time", Pre-flight), if lock release only happened once at the very end of the whole invocation, a crash, timeout, or context compaction while processing a *later* ticket would leave *every already-finished earlier ticket* still locked — even though its results were already posted and its status already moved to `Checked by QA`. This is a known failure mode this pipeline has hit in production: clusters of tickets updated minutes apart, all still `QA-RUNNING`, because the batch never reached the Final Summary. **A narrower version of the same failure mode hits a single ticket even when the rest of the batch finishes cleanly:** Phase 6 (branch/push/PR/label/comment against GitHub) is several external API calls that can fail or time out for *this* ticket alone, after its own Exit Gate already set it to `Checked by QA` — release must not wait for Phase 6 to finish, or that one ticket's lock stays stuck even though its testing is genuinely done. Phase 6 only publishes already-generated spec files; it never touches testing state, so it has no business holding the testing-concurrency lock hostage. Confirmed in production 2026-09-01: 10 tickets found `Checked by QA` yet still locked, all consistent with exactly this gap — the label was removed from them directly since this fix wasn't in place yet to have released them on its own.

**Backstop (pre-authenticated runs only):** if this ticket somehow reached here without the Exit-Gate-time release above having run (e.g. a code path that skipped it) → run `node "$CLAUDE_PLUGIN_ROOT/skills/test-ticket/scripts/remove-label.js" "<EPIC_ID>" "QA-RUNNING"` for **that ticket** now (or its MCP fallback when `jira_write_path = mcp` — [the preflight detail reference](references/preflight-detail.md)). Idempotent, safe to call again even if it already ran above. For Generation only tickets, run this same command (or its MCP fallback) here regardless — it's the primary release, not a backstop, per the callout above.

**Then run Feedback Collection (below) for this ticket**, with `outcome = completed`, before moving to the next ticket ID.

---

## Feedback Collection

Skip this entire section if `feedback_canvas_id` is blank in Configuration. Feedback is mandatory, asked at six entry points, each with its own `outcome`: the end of Phase 3b (`executed`), Per-Ticket Completion (`completed`), User-cancels-mid-run (`stopped`), connector-outage / unrecoverable-phase-failure (`error`, never skipped), a Final Summary sweep for any Epic with no ask recorded (`error`), and Feedback Recovery at the start of the next invocation for a closed or killed session (`interrupted`). The reply is saved to `run-state.json` before any Slack post, the canvas entry and the channel message are sent together, and a post that failed is finished at the next start. Asks once per test cycle (`feedback_asked_at`). Full procedure — the ask, Slack-identity resolution, canvas entry template, the two posts, compaction and recovery: [the feedback collection reference](references/feedback-collection.md).

---

## Final Summary

**Lock release (safety net only):** every ticket's own `QA-RUNNING` lock was already released above — immediately after Exit Gate for a pre-authenticated run, or at Per-Ticket Completion for a Generation only ticket — not here. If a ticket reached this point without its lock having been released (e.g. a code path that skipped both), run `node "$CLAUDE_PLUGIN_ROOT/skills/test-ticket/scripts/remove-label.js" "<EPIC_ID>" "QA-RUNNING"` for it now as a final backstop (or its MCP fallback when `jira_write_path = mcp` — [the preflight detail reference](references/preflight-detail.md)). **Feedback safety net:** before printing the summary, run Feedback Collection with `outcome = error` for every Epic that started a cycle this invocation (any story has `cycle_started_at`); its guard skips an Epic already asked, so this only catches the paths that jumped straight here (no Playwright MCP, Phase 6's duplicate-PR skip, a failed gate).

**Feature flag teardown:** After all Epics/stories in this invocation are done — never per-story, since two stories can reference the same flag and an earlier one finishing must not disable a flag a later one still needs. `run-state.json` is per-Epic (`test-output/<EPIC_ID>/run-state.json`), so this step runs **once per Epic that was actually processed this invocation**, not once globally — read that Epic's own `flags_enabled_this_run`, not just whichever Epic finished last. For each Epic, for every flag name in its `flags_enabled_this_run` (see Feature Flag Setup in [the Phase 3a execution reference](references/phase-3a-execution.md)): navigate to Maxxton Admin and disable it, then — only after re-reading the flag confirms the restored state — remove it from that Epic's list. Then, for every flag in that Epic's `flags_disabled_this_run`, navigate to Maxxton Admin and enable it, then — only after re-reading the flag confirms the restored state — remove it from that list; a flag that failed to restore stays in its list so a resume can retry — the original state is always restored, ON→OFF and OFF→ON. A flag is in at most one list (net change from the state it was found in); see Flag state reconciliation in the Phase 3a reference. Read every processed Epic's lists first and net them per flag and per host (an entry is restored only on its own host) (see Invocation-wide baseline in the Phase 3a reference) so opposing entries from different Epics cancel instead of both being applied. Best-effort — never fail the run over this. **Disable/enable failed for a flag** → do NOT retry silently; surface it under ACTION REQUIRED: `⚠️ Could not auto-restore feature flag "<flag>" (Epic <EPIC_ID>) — verify/reset manually in Maxxton Admin.` Log `[FeatureFlag] Teardown complete — <n> disabled, <n> re-enabled, <n> failed, across <n> Epic(s).` (or skip the log entirely if every processed Epic's `flags_enabled_this_run` and `flags_disabled_this_run` were empty — nothing to tear down). Then, last of all and on the connector-outage and user-cancel exits in Error Handling too, close the browsers this invocation opened: follow `${CLAUDE_PLUGIN_ROOT}/skills/execute-tests/references/browser-close.md`.

Print run summary per Epic + combined totals for multi-Epic runs, including per-story DoD status from the Exit Gate. If a story's `dev_qa.concerns` (Phase 1 step 3l) names concerns this run did not cover, add one line under it: `Developer asked to test: <concerns> — this run covered: <hosts>; not covered: <concerns>.` Informational only — it never starts a run. Then run `run-metrics.js finish "test-output/<EPIC_ID>" || true` for each processed Epic. Send Slack notification if `slack_channel` is set. For per-story detail, run `/generate-reports <STORY_KEY>`.

All format templates (single-Epic summary, multi-Epic totals, Slack notification): [the output formats reference](references/output-formats.md).

---

## Error Handling

Log each phase failure with the phase name and error, include it in the Final Summary under "ACTION REQUIRED", and continue to subsequent phases where possible — never stop the entire run over a single phase failure unless it is a connector outage.

**On connector outage:** Attempt to release `QA-RUNNING` before stopping. If Atlassian is unreachable:
> ⚠️ Could not release QA-RUNNING lock on `<EPIC_ID>` — Atlassian is unreachable. Remove the label manually before re-running.

Then run Feedback Collection for `<EPIC_ID>` with `outcome = error`. Never skip it: the ask and its saved record need no connector, and Feedback Recovery posts the entry once Slack is reachable.

**User cancels mid-run:** If the user explicitly asks to stop, abort the current phase immediately, release `QA-RUNNING` by running `node "$CLAUDE_PLUGIN_ROOT/skills/test-ticket/scripts/remove-label.js" "<EPIC_ID>" "QA-RUNNING"`, run Feedback Collection for `<EPIC_ID>` with `outcome = stopped`, and confirm to the user:
> ✅ Run stopped. QA-RUNNING lock released from `<EPIC_ID>`. Re-run `/test-ticket <EPIC_ID> <URL>` to resume from the last completed phase.

If a phase was skipped by resume check but its artefact is corrupt → log a warning and continue to the next phase.
