# Pre-flight Detail

## Environment Hard Stop (no override)

Non-dev/test URLs are blocked outright — there is no confirmation path that lets the run proceed anyway. For each `(Epic, URL)` pair that isn't `*-dev.maxxton.net` / `*-test.maxxton.net`, print (collect all such Epics first, then one combined message covering all of them):

```
⛔ Environment Check Failed
The following Epics are not pointed at a dev/test environment:
- `<EPIC_ID_1>` → `<URL_1>` (production)
- `<EPIC_ID_2>` → `<URL_2>` (unrecognized host)

This pipeline only runs against *-dev.maxxton.net or *-test.maxxton.net.
Re-run each of the above with a dev/test URL. Epics with a valid URL below proceed normally.
```

Do **not** set the `QA-RUNNING` lock for a blocked Epic. Log `[Environment] <EPIC_ID> blocked — <URL> is not dev/test.` for each. There is no yes/no here and no flag that bypasses it — this is intentionally not configurable.

## Target Repo Detection

Runs immediately after the Environment Hard Stop, per Epic. MCMS and MXTS specs live in two separate GitHub repos with separate CI — Phase 6 must never push to the wrong one, and Phase 6 opens exactly **one** PR per Epic (branch `qa/specs/<EPIC_ID>`, in exactly one repo) — so every URL this Epic executes against must resolve to the *same* `target_repo`, not just the first one.

For **every** execution URL this Epic will run (the full ordered list resolved at Argument Parsing — this pipeline explicitly supports multi-URL Epics, see [the invocation examples reference](invocation-examples.md)), classify its hostname:

- Contains `cms` (e.g. `krm-cms-test.maxxton.net`, `fmc-cms-dev.maxxton.net`, `ons-cms-test.maxxton.net`) → `mcms-qa-automation`
- Otherwise (e.g. `rcn-test.maxxton.net`, `mqa-dev.maxxton.net`) → `mxts-qa-automation`

**All URLs must classify to the same repo.** If they do, that shared value is `target_repo` for this Epic — persist it to `run-state.json` immediately. If they don't (an Epic mixing at least one `cms` URL with at least one non-`cms` URL), **stop this Epic here, same hard-stop posture as the Environment Hard Stop above — no override, no "pick one and continue"**:

```
⛔ Mixed MXTS/MCMS URLs for <EPIC_ID>
This Epic's URLs resolve to two different QA-automation repos:
- `<cms URL>` → mcms-qa-automation
- `<non-cms URL>` → mxts-qa-automation
Phase 6 opens one PR in one repo per Epic and cannot represent both.
Split this into two /test-ticket invocations, one per repo's URL(s), and re-run.
```

Do not set `QA-RUNNING` for this Epic. Log `[Target repo] <EPIC_ID> blocked — mixed MXTS/MCMS URLs, cannot resolve a single target_repo.` This never triggers for a single-URL Epic, nor for a multi-URL Epic whose URLs are all the same product (e.g. two MXTS dev URLs, or `krm-cms-dev` + `fmc-cms-dev`) — only when the SET of URLs spans both products.

No URL at all (Generation only mode — Phase 6 never runs) → default `target_repo = "mxts-qa-automation"`, unused.

Every GitHub call in Phase 6 — and `post-pr-comment.js`'s validation — targets `MaxxtonGroup/<target_repo>`, never a hardcoded repo name. Log: `[Target repo] <EPIC_ID> → MaxxtonGroup/<target_repo> (matched on <n> URL(s): "<hostnames>").`

## Concurrency Lock

**Acquisition:** For each Epic, call `getJiraIssue` and read `fields.labels`. If `QA-RUNNING` is absent, run `node "$CLAUDE_PLUGIN_ROOT/skills/test-ticket/scripts/add-label.js" "<EPIC_ID>" "QA-RUNNING"` (or its MCP fallback when `jira_write_path = mcp` — see phase-3a-execution.md's "Jira Write-Path Check"). No comment is posted. Check and acquire locks for **all** Epics before starting any pipeline work.

> ⛔ **Never call `editJiraIssue` with a raw `fields.labels` write, here or anywhere in this pipeline.** `editJiraIssue`'s `fields.labels` **replaces** the full label array; it does not append/remove. `add-label.js`/`remove-label.js` already handle this correctly (read current labels first, write back the merged set) and are the default path when `jira_write_path = script`. When it's `mcp` (no usable token), `editJiraIssue` is the fallback — but only as `getJiraIssue` (read `fields.labels`) → compute the full merged array yourself → `editJiraIssue` with that complete array. A direct `editJiraIssue` label write without first reading the current array will silently wipe every other label on the issue.

**If `QA-RUNNING` is present** — it may be a genuinely active run, a stale lock left behind by a force-quit/killed session (the release right after Exit Gate, or at Per-Ticket Completion for a Generation only ticket, plus the Final Summary backstop, all only run if the agent is still alive to reach them — a hard kill skips whichever of these would otherwise have fired), or the current runner's own earlier attempt on this same Epic. Resolve in this order:

1. **Same-runner check (first, before any age/threshold logic):** Call `getJiraIssue` with `expand=changelog` for this one Epic, find the most recent `labels` changelog entry whose `toString` adds `QA-RUNNING`, and read its author's email. **If it matches the current `JIRA_EMAIL`** → this is the runner's own lock (an earlier attempt on this Epic, crashed or otherwise), not someone else's active run. Do not ask, do not treat it as blocking: run `remove-label.js` then `add-label.js` (or the MCP fallback for both when `jira_write_path = mcp`) to refresh it, log `[Concurrency] <EPIC_ID> lock was this runner's own (from a prior attempt) — continuing, resume detection below decides where from.`, and proceed straight to normal resume detection (Compaction & State Recovery in SKILL.md), regardless of lock age. **When `jira_write_path = mcp`, there is no local `JIRA_EMAIL` to match against** — skip this step and fall through to step 2 as if it were always a different runner; the age-threshold logic below still resolves it safely, just without the same-runner shortcut.
2. **Different runner, and `stale_lock_threshold_hours = 0`** → always hard-block (skip straight to step 4's block message).
3. **Different runner, threshold > 0** — compute how long ago the changelog entry from step 1 was.
4. **Lock age ≤ threshold** → hard-block. Report: ⚠️ `<EPIC_ID>` is already being tested (lock acquired `<N>` ago by `<other runner's email>`). Remove the label manually if that run is no longer active, then re-run. Do not proceed for this Epic.
5. **Lock age > threshold** → likely stale, not active — release and proceed automatically, no ask. `stale_lock_threshold_hours` is itself the policy decision (default 3h; the team sets it, same as `auto_transition` or any other config flag in this skill) — asking again every time that threshold is crossed would be asking the same question the config already answered. Run `remove-label.js`, then acquire fresh via `add-label.js` (or the MCP fallback for both when `jira_write_path = mcp`), then continue to normal resume detection. Log: `[Concurrency] <EPIC_ID> lock held by <other runner's email> for <N> (past the <stale_lock_threshold_hours>h threshold) — released automatically, continuing.`

   If a team wants a genuinely slow-but-still-running pipeline (large Epic, many stories) to never be treated as stale, that's what raising `stale_lock_threshold_hours` is for — set it above the longest realistic run time, not a per-run ask.

**Release (immediately after Exit Gate — primary for a pre-authenticated run; Per-Ticket Completion — primary for a Generation only ticket, backstop otherwise; Final Summary — final backstop):** Run `node "$CLAUDE_PLUGIN_ROOT/skills/test-ticket/scripts/remove-label.js" "<EPIC_ID>" "QA-RUNNING"` (or its MCP fallback, same read-then-write rule as Acquisition above, when `jira_write_path = mcp`).

> 🔧 **Manual recovery:** If a run crashes mid-way and the label is stuck past the staleness threshold's ability to auto-resolve it, open the Epic in Jira → Edit labels → remove `QA-RUNNING` manually.

## URL Guard — Full Flow

If **no URL was provided** for an Epic in the parsed list — do not ask. Automatically proceed as Generation only mode for that Epic and log `[URL] No URL provided for <EPIC_ID> — running Generation only mode automatically.` (Phases 1–2, or 1–3b if QA-stage stories are present; no browser session needed.)

If a URL **was** provided for the Epic:

1. Store it. Then call `browser_snapshot` to check the current browser state:
   - **Current URL starts with the provided URL AND no login form visible** → session active on that app. Log: `[Session] Existing browser session detected at <URL> — reusing.` Proceed immediately.
   - **Browser is open but on a different URL** → no ask — the run always targets the URL the ticket was given, never wherever the browser happens to already be. `browser_navigate` to the provided URL, then check for a login form: logged in → reuse; not logged in → ask user to log in once (below), then continue. Log: `[Session] Browser was on a different URL — navigated to <provided URL> automatically.`
   - **Browser is empty / closed** → `browser_navigate` to the provided URL → wait for page to load → call `browser_snapshot` and inspect the result:
     - **No login form visible** → session cookies from the previous run are still valid. Log: `[Session] Session restored from browser profile — no login required.` Proceed immediately.
     - **Login form visible** → session has expired. Print:
       > Browser navigated to `<URL>`. Please log in, then reply here to continue.
       Wait for confirmation → verify session via `browser_snapshot` → proceed.

## Build / Version Auto-Detection Script

Runs immediately after URL Guard above completes for the Epic — Steps 2–3 below read the live app DOM via `browser_evaluate`, so the browser must already be navigated to `<base URL>` and past any login form (that's what URL Guard just confirmed). Running detection any earlier means Steps 2–3 evaluate a blank or stale page and always miss, silently pushing everything to Step 4 regardless of whether the user is logged in.

Detection runs in order — use the first value found:

> ⛔ **Every step below must log an outcome, success or not — a step that runs silently and falls
> through is indistinguishable from a step that never ran at all.** Confirmed as a live gap
> 2026-09-24 (MXTS-81144): `build_version` came back `"Not provided"` on an ordinary MXTS ticket
> where Step 2's Assistance popup should normally apply, and there was no way to tell afterward
> whether Step 2 was even attempted, found no Assistance button, found the button but the popup
> had no matching version text, or something else — every step only logged on success, so a
> failure anywhere in the chain left zero trail. Each step now logs its own miss before falling
> through to the next.

**Step 1 — Jira `fixVersions` field** (already fetched in Phase 1, zero extra calls):
Read `fixVersions` from the Epic/story Jira data. If one or more versions are set, use the name of the first released or unreleased version (prefer released). Log: `[Build] Version from Jira fixVersions: <value>`. If `fixVersions` is empty/unset → log `[Build] No Jira fixVersions set — trying Assistance popup.` and proceed to Step 2.

**Step 2 — Maxxton Assistance button** (via Playwright MCP, runs only if a browser session is active):

Click the Assistance (`?`) button in the sidebar, then read the version from the popup:
1. `browser_click` on the element matching `getByRole('button', { name: /assistance/i })` or `getByText('?')` in the sidebar. If no matching element is found → log `[Build] Assistance button not found in sidebar — trying DOM heuristic.` and skip straight to Step 3 (do not attempt steps 2–3 below).
2. `browser_evaluate`:
   ```js
   Array.from(document.querySelectorAll('*')).find(
     el => /V\d{4}\.\d+\.\d+-t\d+/.test(el.textContent?.trim())
   )?.textContent?.trim() || null
   ```
3. Close the popup: `browser_press_key('Escape')`

If found → store as `build_version`. Log: `[Build] Version from Assistance popup: <value>`. If the button was clicked but no matching version text was found in the popup → log `[Build] Assistance popup opened but no version text matched — trying DOM heuristic.` and proceed to Step 3.

**Step 3 — Browser DOM heuristic** (fallback, via `browser_evaluate`):

```js
window.__VERSION__ || window.APP_VERSION ||
document.querySelector('[data-version]')?.dataset.version ||
document.querySelector('meta[name="version"]')?.content ||
document.querySelector('.app-version, .build-version, footer [class*="version"]')?.textContent?.trim() ||
null
```

If found → store as `build_version`. Log: `[Build] Auto-detected version: <value>`. If nothing is found → log `[Build] DOM heuristic found no version — falling back to "Not provided".` and proceed to Step 4.

**Step 4 — Not provided** (final fallback):
If all steps return nothing → `build_version = "Not provided"`. Log: `[Build] Could not auto-detect version after Steps 1-3 — using "Not provided".` Captured once — reused for all Epics.

## Maxxton Knowledge Connector Check

Runs once per invocation, right after the Atlassian reachability check and before the first Epic's Phase 1 — never per Epic. It never stops the run, never asks the user for anything, and behaves the same with `--unattended`.

Confirm the claude.ai **Maxxton Knowledge** connector is connected: at least one `mcp__claude_ai_Maxxton_Knowledge__*` tool is available. The connector listed as needing authentication, or no such tool at all, means it is not connected.

- **Connected** → log `[Preflight] Maxxton Knowledge connected.`
- **Not connected** → print the message below once, log `[Preflight] Maxxton Knowledge not connected — continuing without it.` and carry on with Phase 1.

```
ℹ️ Maxxton Knowledge is not connected.
Please connect the "Maxxton Knowledge" connector in your claude.ai connector settings, then restart this session (a resumed run continues from disk).
Why: Phase 2.5 (impact analysis) uses its technical graph, and it holds the repo and API documentation that setting up missing test data can draw on. Without it this run still works, but impact analysis falls back to the code diff and prose (Confidence ≤ Medium), and more TCs can end up BLOCKED or NEEDS REVIEW because their data was never prepared.
```

Never ask the user for a token, code or URL for it — connecting is done in claude.ai, not in this session.
