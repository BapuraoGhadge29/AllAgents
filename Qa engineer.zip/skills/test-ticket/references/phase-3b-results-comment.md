# Phase 3b — Results Comment (full posting procedure)

**Test Execution Timing — capture `cycle_ended_at` as late as possible: after Step 1 (screenshot
uploads) below has finished, immediately before Step 2 (writing the body) starts.** This is the
latest point the elapsed time can honestly be captured — the number has to be known *before* it can
be written into the comment body that then gets posted, so it can never literally include the last
instant of posting itself, but capturing it here (not earlier, not before uploads) means the real
work — all TC execution plus every screenshot upload — is counted, and only the negligible,
non-network work of formatting the markup text is excluded. `total_testing_seconds = (cycle_ended_at
- stories.<STORY_KEY>.cycle_started_at) - stories.<STORY_KEY>.user_wait_seconds` (both read from
`run-state.json` — `cycle_started_at` is stamped at the top of Phase 3a, before the precondition
check and everything else in that phase; `user_wait_seconds` accumulates the pauses of this same
cycle — Session Recovery waits and the gaps the Resume Gap Check found when the run was picked up again after the tester
was away; see Pause Tracking in phase-3a-execution.md). This measures actual pipeline working time
for this cycle, end to end from Phase 3a's start through the screenshots that go into this exact
comment, not wall-clock time inflated by the user taking their own time to re-authenticate or by the tester being away between sessions. A resume of this phase runs the Resume Gap Check first (phase-3a-execution.md), so a pause just before posting is already subtracted.
**Run `node "$CLAUDE_PLUGIN_ROOT/skills/test-ticket/scripts/run-timing.js" render test-output/<EPIC_ID>/run-state.json <STORY_KEY> [<cycle_ended_at>] [--url <hostname>] [--screenshots-dir test-output/<STORY_KEY>]` and paste its output into the row — do not compute the figure by hand.** Leave `<cycle_ended_at>` out and the script uses the current time, which is exactly what is wanted right after the screenshot uploads. The script applies everything below (subtraction, rounding, the pause suffix, the per-URL boundaries, the screenshot fallback for a null start) and never prints N/A. The rest of this paragraph is the specification it implements — useful for checking the output, not for redoing it.
**Format: `h`/`m` only, never seconds** — round to total minutes *first*, then split: `total_minutes
= round(total_testing_seconds / 60)`, `h = total_minutes // 60`, `m = total_minutes % 60`. Rounding
seconds into minutes and hours separately is wrong — e.g. `1h 59m 31s` naively gives `h=1`, `m=60`
("1h 60m", not a valid time), but rounding total minutes first gives `total_minutes=120` → `h=2`,
`m=0` ("2h 0m"), correctly carrying the rounded minute into the hour. Then write `<m>m` when `h=0`
(e.g. `42m`) or `<h>h <m>m` when `h>0` (e.g. `1h 12m`) — drop the hours segment under 60 minutes, but
always show the minutes segment even when it's `0` (e.g. `1h 0m`, not bare `1h`). **Then append the pause count** from `stories.<STORY_KEY>.pause_count`: nothing when it is `0`, ` (1 pause)` when it is `1`, ` (<n> pauses)` above that — e.g. `38m (2 pauses)`, `1h 12m (1 pause)`, `42m`. The number always comes first (the adoption dashboard reads it) and the pause count is the only text that may follow it. **The row is a number on every run that executed TCs** — a subtraction that comes out negative (clock skew, a wait counted twice) is clamped to `0m`, never written as a negative or as N/A; a run that spanned several sessions, had tester pauses, or was resumed after a compaction still gets its active-time figure; never write `N/A` or a sentence there (`post-comment.js`, `update-comment.js` and `validate-results-comment.js` reject it with CHECK 16, and on the MCP path a hook denies the post). The dashboard also reads Total TCs, Passed, Failed, Blocked, Needs Review and Skipped as whole numbers and QA Pipeline Version as `major.minor.patch`: any explanation such as "retest of the non-pass TCs" goes in the Preconditions row, never in those cells (CHECK 17). If `cycle_started_at` is null on a run that executed TCs, take the earliest file modification time among this story's screenshots in `test-output/<STORY_KEY>/` as the start instead of giving up. **Multi-URL runs — one figure per URL block.** Each URL (concern) has its own timing; never reuse one value across blocks. Boundaries come from `stories.<STORY_KEY>.url_timing` (see Phase 3a): in run order, URL 1 starts at `cycle_started_at` and every later URL starts at the previous URL's `ended_at`; a URL ends at its own `ended_at`, except the last URL, which ends at `cycle_ended_at` (so the screenshot uploads are counted once, in the last block, and the per-URL figures add up to the single-URL total). `url_seconds = (url_end - url_start) - url_timing.<hostname>.user_wait_seconds`, formatted exactly like `total_testing_seconds` above (round total minutes first, `h`/`m` only) with that URL's own `url_timing.<hostname>.pauses` as the pause count (missing → `0`). A URL with no `ended_at` (aborted before it finished) ends at `cycle_ended_at`. A single-URL run keeps the formula above unchanged. **Generation only mode**
(Phase 3a never ran, `cycle_started_at` was never stamped) → this row does not apply; write
`N/A (generation only)` rather than omitting the row or computing against a null start time — the only case where this row is not a number.

**Write the results to Jira** (after spec decision). **A story's first cycle writes its results INTO its Test Cases comment**: the same comment, edited in place into the merged layout ([Merged comment](#first-cycle--merged-comment-edited-in-place) below) with `update-comment.js` on the script path, or `addOrEditJiraIssueComment` with that comment's id on the MCP path. The story ends up with ONE pipeline comment holding its test cases and their results — never a separate results comment. A later cycle (a `--retest` or `--force` run after the story was reopened) posts a **new** comment with `post-comment.js`; the prior cycle's comment is left in Jira as history, never edited into. A story that was never reopened ends up with exactly 1 pipeline comment; one that went through a reopen → retest cycle ends up with 2 (the merged first-cycle comment + one per retest cycle).

**The merge target is `stories.<STORY_KEY>.tc_comment_id`.** With no id on file, find it in Jira: the comment whose first line is `Test Cases — <STORY_KEY>`. `post-comment.js` refuses (exit 1) to post a new results comment while that comment is unmerged and no results comment exists, and prints its id — so a lost `run-state.json` or a context compaction cannot produce a second comment. Wiki markup below is the script path; the MCP path writes the same content as HTML ([the MCP write path reference](jira-mcp-write-path.md)).

> ⛔ **A story's first cycle already has its number of comments: the Phase 2 plan.** The results are merged into the Test Cases comment, so one comment when `tc_parts` is unset, otherwise the planned parts (sized by merged length, so even a story of 20 TCs can be two parts) — read [the split results reference](phase-3b-split-results.md) now and follow it. **A new results comment** (a `--retest` / `--force` cycle, or an older ticket) counts the rows first: **TCs with a verdict × URL blocks.** More than 45 rows → one comment is too long for Jira (32,767 characters), so the results are posted as several parts instead — read [the split results reference](phase-3b-split-results.md) now and follow it for planning, the part marker, validation, posting and the final reconcile. **45 rows or fewer → everything below applies unchanged, one comment.**

```bash
# Step 1 — ensure every TC has a screenshot uploaded (upload-screenshot.js).
#           Store the returned filename for each TC — needed for Test Proof column.
#           Capture cycle_ended_at HERE, right after this step finishes — see Total
#           Testing Time above — before moving on to Step 2.
# Step 2 — write the wiki markup body to a temp file following the exact template below.
# Step 3 — read stories.<STORY_KEY>.results_comment_id AND cycle_started_at from
#           run-state.json. results_comment_id is null unless this exact cycle already
#           posted once (e.g. resuming after compaction). cycle_started_at was stamped
#           at the top of Phase 3a — pass BOTH through:
node "$CLAUDE_PLUGIN_ROOT/skills/test-ticket/scripts/post-comment.js" "<STORY_KEY>" <body_file> [<results_comment_id>] [<cycle_started_at>]
# Both trailing args are positional — to pass cycle_started_at while results_comment_id
# is still null (the common case: first post attempt this cycle), pass "" for the third
# arg: post-comment.js "<STORY_KEY>" <body_file> "" "<cycle_started_at>"
# Exit 1 = format validation failed → discard draft, rewrite from scratch using ONLY
#           the template below, then call post-comment.js again. Repeat until exit 0.
# Exit 0 + "Already posted this cycle" message = a results comment for THIS cycle was
#           found (via results_comment_id, or via the cycle_started_at fallback if
#           results_comment_id was never recorded — e.g. a crash right after the Jira
#           POST succeeded but before the id was persisted) → no-op, do not post again.
#           If the message names an id you didn't have on file, persist it now to
#           run-state.json as stories.<STORY_KEY>.results_comment_id.
# Exit 0 + comment ID printed = success — a NEW comment was posted for this cycle.
#           Persist it immediately to run-state.json as stories.<STORY_KEY>.results_comment_id,
#           together with stories.<STORY_KEY>.results_comment_path = "script".
# Exit 3 = the comment IS posted (id on stdout — persist it exactly as for exit 0), but a screenshot
#           the body names is not attached to the issue, or Jira could not be asked. stderr names the
#           files. post-comment.js checks the attachments after every post and on every "Already posted"
#           detection, never skipped. Upload each named file with upload-screenshot.js (the images appear
#           without editing the comment), then run the same post-comment.js command again: the
#           "Already posted" detection repeats the check; update-comment.js runs the same check after
#           its PUT and exits 3 the same way. Still exit 3 → ACTION REQUIRED:
#           `Screenshots missing in results comment <id>: <n> of <m> are not attached (<first three file names>).`
```

**MCP path (`jira_write_path = mcp`):** the three steps above become — Step 1: upload every screenshot through MCP in one pass (`jira-mcp-write-path.md` §1; capture `cycle_ended_at` right after it, as above); Step 2: write the body as HTML (always — plain filenames go in `<p>` when `screenshot_upload_enabled = false`) per §2 and run `validate-results-comment.js` on it until it prints `OK`; Step 3: post or correct it with `addOrEditJiraIssueComment` using the duplicate guard and the persisted `results_comment_id` / `results_comment_path` (§3). `post-comment.js` and `update-comment.js` are not called on this path.

`update-comment.js` is reserved for correcting a comment that is malformed or incomplete **within the same cycle** (e.g. screenshots failed to attach when it was posted) and was created by the script path (`results_comment_path = script`) — never for reflecting a later cycle's new verdicts. A results comment created by the MCP path (`results_comment_path = mcp`) is corrected through MCP even in a script-path run — same-path rule in [the MCP write path reference](jira-mcp-write-path.md). A new test cycle always gets a new `post-comment.js` call, not an edit of the previous cycle's comment.

**Script path:** screenshots are uploaded via API v3 (`upload-screenshot.js`); the comment is posted via API v2 (wiki markup) because only API v2 renders `!filename.png!` as an inline image — API v3 (ADF) does not support wiki markup inline images.

> ⛔ **Use `post-comment.js` for results comments when `jira_write_path = script`.** When it's `mcp`, use `addOrEditJiraIssueComment` (an HTML body with the screenshots embedded, or with plain filenames in `<p>` when `screenshot_upload_enabled = false`; same table content) instead — upload, template conversion, validator and edit rules are in [the MCP write path reference](jira-mcp-write-path.md) — see phase-3a-execution.md's "Jira Write-Path Check" → MCP fallback; this is the mandatory substitution, not a skip. **The two paths do not mix.** If `post-comment.js` itself fails while `jira_write_path = script` (e.g. a transient API error, unrelated to missing credentials) — retry once, then log the error; do NOT fall back to `addOrEditJiraIssueComment` for that failure. It would bypass `post-comment.js`'s own duplicate/correct-in-place guard and post a different format (HTML or markdown instead of wiki markup) than every other comment on this story. Do NOT post free-form content either way. Do NOT invent a format — copy the exact template below (wiki markup for the script path; for the MCP path the HTML conversion in the MCP write path reference, with or without uploaded screenshots), character for character.

> ⛔ **The comment header is `h2. QA Test Results` — exactly that string, nothing else.** Do NOT write "QA Pipeline Results", "Pipeline Results", "Test Execution Results", or any other variation. Do NOT add the story key, a date, or emoji to the header. The stats table (Build/Version through Test Execution Timing) is MANDATORY — it is not optional and must appear before the TC table in every results comment. **QA Pipeline Version** (the qa-engineer plugin's own `version`, from `${CLAUDE_PLUGIN_ROOT}/.claude-plugin/plugin.json` — distinct from the app's Build/Version row) and **Test Execution Timing** (see the computation above — placed last, after QA Pipeline Version) are both part of this mandatory table. The TC table has exactly 6 columns — `TC_ID`, `Test case scenario`, `Expected Result`, `Actual Result`, `Status`, `Test Proof` — in a retest cycle's comment, and exactly the 12 columns of the merged table in a story's first cycle (First cycle above) — never add, remove, or rename a column (e.g. "Verdict", "Risk", "Notes", "Scenario" are all wrong column names).

> ⛔ **Pre-posting self-check — run this before calling `post-comment.js`:**
> 1. First line of body is exactly `h2. QA Test Results` — no emoji, no extra text, no Markdown `##`
> 2. Stats table present: rows for Concern, Environment, Build/Version, Preconditions, Total TCs, Passed, Failed, Blocked, Needs Review, Skipped, Pass rate, QA Pipeline Version, Test Execution Timing
> 3. TC table header is exactly `|| TC_ID || Test case scenario || Expected Result || Actual Result || Status || Test Proof ||` (retest cycle) or the 12-column merged header (first cycle, edited into the Test Cases comment)
> 4. Every TC is a single table row — no prose sections, no per-TC headings, no Steps/Expected/Actual as freetext blocks
> 5. No Phase labels in the body (`Phase 3a`, `Phase 1`, `Execution Results`, `Test Cases & Execution Evidence`, etc.)
> 6. No `##` Markdown headers anywhere in the body — only `h2.` / `h3.` wiki markup
> 7. First cycle: the body goes into `tc_comment_id` (`update-comment.js` / MCP edit with `commentId`), never into a new comment. Only while that comment is still an unmerged Test Cases comment: after `--retest` / `--force` it is the earlier cycle's merged comment (the id is kept for Phase 2 reuse), and this cycle's results are a new comment. This is the ONLY results comment being posted for this story in this run (or, for a split of more than 45 rows, the one comment for this part) — do not post a "summary" comment separately
> If any check fails → fix the draft. Do NOT post a failing draft.

> ⛔ **Phase 3a execution is an internal pipeline stage — it is NEVER posted to Jira.** Do NOT write a separate "Phase 3a Execution Results", "Execution Summary", or "Pipeline Summary" comment. The ONLY Jira output from Phase 3b is the single results comment produced by `post-comment.js` (script path) or by one `addOrEditJiraIssueComment` post (MCP path).

### First cycle — merged comment, edited in place

The Test Cases comment becomes the results comment. Header, stats table, rules and Cross-Module Impact are exactly those of the templates below; the one difference is the TC table: the **12-column merged table** — the 10 Test Cases columns, then `Status` and `Test Proof`.

1. **Read the LIVE comment, never rebuild it from memory:** `node "$CLAUDE_PLUGIN_ROOT/skills/test-ticket/scripts/read-comment.js" "<STORY_KEY>" "<tc_comment_id>" --out <live.txt>`. Copy every Test Cases cell from it unchanged.
2. **Fill only four things per row:** `Actual result` (what happened, same rules as the Actual Result column below), `Automated` (the final `Yes`/`No` after the Phase 3b spec decision), `Status` and `Test Proof` (same values and screenshot rules as below). Everything else — scenario, preconditions, steps, expected result, story, epic, risk — stays as it is.
3. **Header changes:** `h2. Test Cases — <STORY_KEY>` becomes `h2. QA Test Results`; the stats table goes right under it; the column `Automate` becomes `Automated`. Keep the AC-coverage footer but relabel and recount it with the column: `_AC coverage: <c>/<t> | Automate: <n> Yes / <m> No_` becomes `_AC coverage: <c>/<t> | Automated: <n> Yes / <m> No_`, counted from the final `Automated` values (CHECK 21 checks both the label and the counts), and keep an `h3. Extended cases added after Human review` section with its rows (same 12 columns) if the comment had one.
4. **Send it:** `node "$CLAUDE_PLUGIN_ROOT/skills/test-ticket/scripts/update-comment.js" "<STORY_KEY>" "<tc_comment_id>" <body_file>`. It validates the format, reads the live comment and **refuses to send** if any TC row, any kept column or the AC-coverage footer would be lost (`CHECK 18`), then edits the comment in place and checks the screenshots (exit 3 as for `post-comment.js`).
5. **Persist at once**, together: `results_comment_id` = `tc_comment_id`, `results_comment_path` = `tc_comment_path`, `results_merged = true`.

**Collapsible table (HTML bodies, MCP path):** with more than 5 TC rows in a table, that table sits inside `<details><summary>…</summary>…</details>`, so the comment opens collapsed; 5 or fewer stay a plain table (`validate-results-comment.js` CHECK 19 enforces both). The summary carries the counts, omitting zeros: `Results: <N> TCs — <P> passed, <F> failed, <B> blocked, <R> needs review, <S> skipped`. The stats table, the footer and Cross-Module Impact stay outside the expand, so the dashboard rows and the counts are always visible. This applies to every HTML results comment, a retest cycle's as well. Wiki (script path) and markdown bodies cannot carry an expand and stay plain.

```
h2. QA Test Results

<the 13 stats rows, as in the Single URL template below>

|| TC_ID || Test case scenario || Preconditions || Test steps || Expected Result || Actual result || Story number || Epic number || Automated || Risk || Status || Test Proof ||
| TC_01 | <scenario> | <preconditions> | <steps> | <expected> | <actual> | <STORY_KEY> | <EPIC_KEY or N/A> | Yes/No | High | PASS ✅ | !TC_01-login-success.png! |

_AC coverage: <covered>/<total> | Automated: <n> Yes / <m> No_

h2. Cross-Module Impact
…as in the Single URL template…
```

Multiple URLs: one block per URL exactly as in the Multiple URLs template (stats table + merged table per block, separated by `----`). A split Test Cases comment (`tc_parts`, whatever its row count) is already several parts; each part is merged in place with its own `_Part n of m_`, id and `--part` flags — [the split results reference](phase-3b-split-results.md).

> ⛔ **After a context compaction, never rebuild or re-post from memory.** Re-read `run-state.json`: `results_merged = true` → the results are already in the comment; do not write them again (only re-run the screenshot check). Unset → ask Jira, not memory: read `tc_comment_id` (or find the `Test Cases — <STORY_KEY>` comment), run `read-comment.js` on it. First line `h2. QA Test Results` and a 12-column table → it is already merged (persist step 5, nothing else). First line `h2. Test Cases —` → merge it (steps 1–5). The scripts back this up: `post-comment.js` blocks a second comment, `update-comment.js` blocks a lossy edit, `post-tc-comment.js` blocks a second Test Cases comment next to a merged one.

**Single URL** — use this Jira wiki markup format (script path; on the MCP path write the same content as HTML, converted per [the MCP write path reference](jira-mcp-write-path.md), validate it with `validate-results-comment.js`, and check that every screenshot is an embedded image with `verify-screenshot-embeds.js` before and after the post — "Verify the screenshots" in the same reference, never skipped):

```
h2. QA Test Results

| *Concern* | <MQA / RCN / KRM-CMS / ... — the product/system code from the base URL, uppercased> |
| *Environment* | <Dev / Test — the deployment stage from the base URL, title-cased> |
| *Build / Version* | <build_version> |
| *Preconditions* | <semicolon-joined summary from `stories.<STORY_KEY>.preconditions_verified` — see Precondition Evidence Check in [the Phase 3a execution reference](phase-3a-execution.md) — or "None detected"> |
| *Total TCs* | <n> |
| *Passed* | <n> |
| *Failed* | <n> |
| *Blocked* | <n> |
| *Needs Review* | <n> |
| *Skipped* | <n> |
| *Pass rate* | <n>% (BLOCKED and Skipped excluded) — or `N/A (no TC verified)` when Total TCs − Blocked − Skipped is 0 (every TC ended up BLOCKED/SKIP); never a computed percentage against a zero denominator |
| *QA Pipeline Version* | <qa-engineer plugin's own `version`, read from `${CLAUDE_PLUGIN_ROOT}/.claude-plugin/plugin.json`> |
| *Test Execution Timing* | <active time, number first: `42m` / `1h 12m`, plus ` (<n> pause)` / ` (<n> pauses)` when the run had pauses (`38m (2 pauses)`); `N/A (generation only)` only when Phase 3a never ran — see computation at the top of this reference |

|| TC_ID || Test case scenario || Expected Result || Actual Result || Status || Test Proof ||
| TC_01 | Verify we are able to... | Expected element visible | Element found in DOM | PASS ✅ | !TC_01-login-success.png! |

h2. Cross-Module Impact
Evidence: <PR diff (N files) + graph | graph only | prose only>
Confidence: <High / Medium / Low>

|| Module || Team || QA || Impact Type || What is affected ||
| <Module> | <Team> | <QA — `[~accountid:<Jira Account ID>]` per person from the QA ownership reference in analyzing-impact/SKILL.md; this posts via wiki-markup API v2 (post-comment.js), so it's `[~accountid:...]`, NOT the ADF mention node and NOT plain text/email. No match in that table → leave blank, never guess> | <Direct / Transitive> | <plain-language flow/screen (`technical reference`) — business-language first, per analyzing-impact/SKILL.md's "What is affected" rule> |

Overall Risk: <High / Medium / Low> — <one-line justification>
```

**Concern / Environment values** — both derived from the exact `<base URL>` this story's TCs actually ran against (from the execution URL list resolved at Preflight — see "Argument parsing"), which always follows `<concern>-<env>.maxxton.net` (e.g. `mqa-dev.maxxton.net`, `rcn-test.maxxton.net`, `krm-cms-dev.maxxton.net`) per the Environment detection hard-stop rule (`*-dev.maxxton.net` / `*-test.maxxton.net` only — nothing else ever reaches this step). Split it: **Concern** = the part before the last `-` (uppercased: `mqa` → `MQA`, `rcn` → `RCN`, `krm-cms` → `KRM-CMS`, `fmc-cms` → `FMC-CMS`, `ons-cms` → `ONS-CMS`); **Environment** = `dev`/`test` (title-cased: `Dev`/`Test`). Never post the raw hostname as either value.

> ⛔ **MCMS concerns: never truncate to the app's own bare environment code.** For an MCMS hostname (`<module>-cms-<env>.maxxton.net`), Concern is `<MODULE>-CMS` — e.g. `krm-cms-dev.maxxton.net` → `KRM-CMS`, never bare `KRM`. The webmanager's own UI may display just `krm` as its internal environment code (a different, app-level value, not the pipeline's Concern) — never copy that shorter string into the Concern row. This exact confusion happened in production (MXTS-80852, 2026-09-14) — the fix is spelling the rule out explicitly rather than leaving it to the general split-by-hyphen formula alone.

**No separate hostname heading — the Concern/Environment rows already identify the block.** Do not print the hostname as its own `h3.` (or any) heading anywhere in the comment, single-URL or multi-URL — it would only duplicate the Concern and Environment rows already inside that block's own stats table, and has been dropped from the Multiple URLs template below. **Generation only mode** (no base URL, no execution happened) → write `Generation only` for the Concern and Environment rows, and `None detected` for Preconditions (Phase 3a never ran, so `preconditions_verified` was never populated) — never leave any of them blank or omit them.

**Multiple URLs** — one section per environment in a single comment, separated by `----` only (no hostname heading — see "No separate hostname heading" above):

```
h2. QA Test Results

----

| *Concern* | MQA |
| *Environment* | Dev |
| *Build / Version* | <build_version> |
| *Preconditions* | <semicolon-joined summary from `stories.<STORY_KEY>.preconditions_verified` or "None detected" — same value in every URL block, the check runs once per story> |
| *Total TCs* | <n> |
| *Passed* | <n> |
| *Failed* | <n> |
| *Blocked* | <n> |
| *Needs Review* | <n> |
| *Skipped* | <n> |
| *Pass rate* | <n>% (BLOCKED and Skipped excluded) — or `N/A (no TC verified)` when Total TCs − Blocked − Skipped is 0 (every TC ended up BLOCKED/SKIP); never a computed percentage against a zero denominator |
| *QA Pipeline Version* | <qa-engineer plugin's own `version`, read from `${CLAUDE_PLUGIN_ROOT}/.claude-plugin/plugin.json`> |
| *Test Execution Timing* | <e.g. `42m` / `1h 12m` / `38m (2 pauses)` — see computation at the top of this reference; on a multi-URL run this is THIS URL's own figure and pause count from `url_timing`, different per block |

|| TC_ID || Test case scenario || Expected Result || Actual Result || Status || Test Proof ||
| TC_01 | Verify we are able to... | Expected element visible | Element found in DOM | PASS ✅ | !TC_01-login-success.png! |

----

| *Concern* | RCN |
| *Environment* | Dev |
| *Build / Version* | <build_version> |
| *Preconditions* | <same value as the MQA block above> |
| *Total TCs* | <n> |
| *Passed* | <n> |
| *Failed* | <n> |
| *Blocked* | <n> |
| *Needs Review* | <n> |
| *Skipped* | <n> |
| *Pass rate* | <n>% (BLOCKED and Skipped excluded) — or `N/A (no TC verified)` when Total TCs − Blocked − Skipped is 0 (every TC ended up BLOCKED/SKIP); never a computed percentage against a zero denominator |
| *QA Pipeline Version* | <qa-engineer plugin's own `version`, read from `${CLAUDE_PLUGIN_ROOT}/.claude-plugin/plugin.json`> |
| *Test Execution Timing* | <this URL's own timing and pause count from `url_timing` — not the MQA block's value> |

|| TC_ID || Test case scenario || Expected Result || Actual Result || Status || Test Proof ||
| TC_01 | Verify we are able to... | Expected element visible | Element found in DOM | PASS ✅ | !TC_01-rcn-login-success.png! |

----

h2. Cross-Module Impact
Evidence: <PR diff (N files) + graph | graph only | prose only>
Confidence: <High / Medium / Low>

|| Module || Team || QA || Impact Type || What is affected ||
| <Module> | <Team> | <QA — `[~accountid:<Jira Account ID>]` per person from the QA ownership reference in analyzing-impact/SKILL.md; this posts via wiki-markup API v2 (post-comment.js), so it's `[~accountid:...]`, NOT the ADF mention node and NOT plain text/email. No match in that table → leave blank, never guess> | <Direct / Transitive> | <plain-language flow/screen (`technical reference`) — business-language first, per analyzing-impact/SKILL.md's "What is affected" rule> |

Overall Risk: <High / Medium / Low> — <one-line justification>
```

> ⛔ **Format is fixed — all deviations are pipeline violations.**
> - **One comment per story per run — unless the results are planned in parts.** Run `post-comment.js` (or, on the MCP path, post the results comment) exactly once for the results. Never post a "supplement", "appendix", "Full Evidence", "Part 2", or any follow-up comment for the same story in the same run — all TC evidence goes in the table rows. The one sanctioned split is the planned, validated one in [the split results reference](phase-3b-split-results.md): a first cycle follows the Phase 2 plan (`tc_parts`, sized by length), and a new results comment of more than 45 rows (TCs × URL blocks) is cut into parts of at most 40 rows, each with a `_Part n of m_` line, and every TC appears in exactly one part. Never split any other way, and never split a new results comment of 45 rows or fewer unless it fails `CHECK 15`.
> - **No internal pipeline phases in Jira.** Phase 1 (Requirements), Phase 2 (Test Cases), Phase 3a (Execution steps) are internal pipeline stages — they never appear in a Jira comment. The only Jira output from Phase 3b is the results table. Do NOT write headings like `h2. Phase 1 — Requirements`, `h2. Phase 3a — Live Browser Test Execution`, or any variation.
> - **No per-TC narrative prose.** Every TC gets exactly one row in the 6-column table. Do NOT write free-form analysis below or between table rows — no "TC_07: Overnight row expanded — per-unit breakdown...", no per-TC findings, no step-by-step observations. The Actual Result column holds the verdict summary; that is all.
> - **TC IDs must match Phase 2 exactly.** Use only TC_01, TC_02… from the Phase 2 TC table. Never invent new IDs during execution (EXTRA_01, EXTRA_02, TC_EXTRA, etc.). If a scenario was tested that has no TC_ID from Phase 2, it is NOT posted to Jira — stop and ask the user to add it in Phase 2 before the next run.
> - **No "supersedes", "supplement", or cross-comment references.** Do NOT write "(This supersedes the summary comment above)", "(Supplement to pipeline report above)", or any text that references another comment.
> - TC results table must have **exactly 6 columns** (retest cycle): `TC_ID | Test case scenario | Expected Result | Actual Result | Status | Test Proof`, or the **12 columns of the merged table** (first cycle): the 10 Test Cases columns, then `Status` and `Test Proof` — no more, no fewer. Do NOT add, remove, or rename any column.
> - Do NOT rename the header (`h2. QA Test Results`). Do NOT add emoji to the header. (A split part adds its `_Part n of m_` marker on the line after it — never in the header itself.)
> - Do NOT add sections beyond what the template shows — no "Key Finding", "Recommendation", "Conclusion", "Execution Summary", or any narrative prose.
> - Cross-Module Impact appears **once at the end**, never per environment — and in a split, only in the last part.
> - **A user's own time/token-saving framing never exempts this section.** Confirmed in production (MXTS-80897, Sep 2026): a run invoked with "this is small, finish in 15–20 min, skip automation, don't use many tokens" posted a free-form "QA Verification — PASS" comment instead of this template, and skipped the `QA_Pipeline` label below. "Skip automation" scopes `tc_skip_automation` (selector capture/spec generation) only, per Phase 3; "finish fast" / "don't use tokens" scopes TC count/depth only, via `--max-tcs`/`--max-time`. None of that phrasing is license to skip reading this reference or to improvise the comment from memory — the format read + `post-comment.js` call cost the same small, fixed number of tokens on a 1-TC ticket as on a 20-TC one.

**Omit the Cross-Module Impact section entirely** if Phase 2.5 was skipped (`--skip-impact` or dev-stage story) or no `story.impact_summary` exists.

**Column rules:**
- **TC_ID**: TC_ID from Phase 2 TC table (e.g. TC_01)
- **Test case scenario**: exact scenario text from Phase 2 TC table — never paraphrase
- **Expected Result**: exact expected result from Phase 2 TC table
- **Actual Result**: description of what actually happened during execution (no status emoji in this column). **Never write a literal `|` character in this cell — not even escaped as `\|`.** Jira wiki-markup tables treat `|` as a cell delimiter regardless of a preceding backslash; `\|` is not a recognized escape and renders as a literal, garbled backslash-pipe in the posted comment (this has happened in production — an API condition written as `offDuty>=today\|\|null` rendered as visible backslash/pipe artifacts instead of the intended OR). When describing a boolean/logical condition (API query logic, regex alternation, `||`/`&&`), spell it out in words — "OR" / "AND" — or use `/` per the same substitution rule Debug Evidence Capture uses below. This applies to every TC's Actual Result, not just FAIL/BLOCKED rows with appended debug evidence. **A bill-changing TC** (see "Exception — bill-changing TCs" in [the Phase 3a execution reference](phase-3a-execution.md)) writes `Before to after: <summary>. Recalculation alone: <summary>.` from the `summary` line of `bill-diff.js` (second sentence only when a `changed` snapshot exists) — it lists the lines and totals that moved, with VAT, and never contains a `|`.
- **Status**: `PASS ✅` / `FAIL ❌` / `BLOCKED 🚫` / `NEEDS REVIEW 🔍` / `SKIP ⏭️` (see the Known-Limitation Check in [the Phase 3a execution reference](phase-3a-execution.md) — Actual Result must cite the matching developer comment, not just say "known issue")
- **Test Proof**: screenshot evidence for every TC (PASS, FAIL, BLOCKED, NEEDS REVIEW, SKIP) — always present, regardless of the `Automated` column value, `tc_skip_automation`, or `--skip-specs`. The `Automated` column controls spec file generation only and has no effect on screenshot capture or posting.

  **MXTS (single screenshot) — base value depends on upload status:**
  - Upload succeeded → `!TC_02-translate-visible.png!` — renders as an inline image directly in the Jira comment (Jira wiki markup via API v2). Do NOT use `|thumbnail!` — the `|` inside a table cell creates an extra column.
  - Upload failed, OR uploads are off for this run (`screenshot_upload_enabled = false` — on the MCP path, the media host was unreachable) → `TC_02-translate-visible.png` — plain filename; tester attaches manually from the working directory where screenshots were saved.
  - Screenshot capture itself failed (3/3 attempts) → `TC_02-capture-failed.png (screenshot capture failed — 3/3 attempts, CDP timeout)`.

  **MCMS (Before/After pair) — applies when the base URL's hostname contains `cms` (e.g. `krm-cms-dev.maxxton.net`, `fmc-cms-test.maxxton.net`), and on any hostname to a bill-changing TC (see "Exception — bill-changing TCs" in [the Phase 3a execution reference](phase-3a-execution.md)); every other TC on a plain MXTS hostname (e.g. `krm-dev.maxxton.net`, no `-cms-`) still uses the single-screenshot MXTS format above. Labeled, two-line cell using Jira's forced line-break token (see note immediately below — never a literal newline, that ends the table row instead of breaking within the cell):**

  > ⛔ **The token is `\\` followed by a mandatory space — `\\ `, not a bare `\\`.** Confirmed in production (2026-09-24, MXTS-77020, flagged by Sujata Pimpale): a bare `\\` immediately followed by the next character (`!` for an image macro, or the next label) is not recognized as a break by Jira's wiki-markup renderer inside a table cell — it renders as two literal, visible backslash characters instead, exactly what showed up in that ticket's Test Proof column. The space is part of the token, not incidental formatting; every `\\` below has one.

  ```
  Before:\\ !TC_02-translate-visible-before.png!\\ After:\\ !TC_02-translate-visible-after.png!
  ```
  which renders in Jira as:
  ```
  Before:
  [before screenshot]
  After:
  [after screenshot]
  ```
  Apply the same three upload-status substitutions as MXTS **independently to each half** — a half whose upload failed renders as its plain filename, a half whose capture failed renders as its `-capture-failed.png (...)` note; the other half still renders normally if it succeeded. Never drop the `Before:` / `After:` labels even when a half degrades to a plain filename or a capture-failed note — the reader must always be able to tell which image (or note) is which.

  **Multi-item (2+ named items actually verified — see "Exception — multi-item TCs" in [the Phase 3a execution reference](phase-3a-execution.md)):** one labeled line per item, each joined with the forced line-break token `\\ ` (space mandatory — see above), same pattern as Before/After but with the item's own name as the label instead of a fixed "Before"/"After":
  ```
  Spanish:\\ !TC_12-spanish.png!\\ Italian:\\ !TC_12-italian.png!\\ English (US):\\ !TC_12-english-us.png!
  ```
  which renders in Jira as:
  ```
  Spanish:
  [screenshot]
  Italian:
  [screenshot]
  English (US):
  [screenshot]
  ```
  Same three upload-status substitutions as MXTS, applied independently per item — one item's upload failing never hides or blocks another item's screenshot. Never drop an item's own label, and never collapse the TC to fewer screenshots than items actually verified (see Phase 3a: if not every named item could be verified this run, the verdict itself becomes `NEEDS REVIEW`, not a shortened Test Proof cell on an otherwise-PASS TC).

  **Multi-item on MCMS:** a Before/After pair per item, not a single pair for the whole TC (see the file-naming rule in Phase 3a: `<TC_ID>-<item-slug>-before.png` / `-after.png`) — this reuses the exact same multi-item mechanism above with no special case, because each half is just its own item with its own label (`<Item> (Before)`, `<Item> (After)`), not a nested structure:
  ```
  Spanish (Before):\\ !TC_12-spanish-before.png!\\ Spanish (After):\\ !TC_12-spanish-after.png!\\ Italian (Before):\\ !TC_12-italian-before.png!\\ Italian (After):\\ !TC_12-italian-after.png!
  ```

  **Comparison TCs (2+ sources compared — see "Exception — comparison TCs" in [the Phase 3a execution reference](phase-3a-execution.md)):** one labeled line per source, same pattern as Before/After but with the source's own name as the label instead of a fixed "Before"/"After":
  ```
  Widget:\\ !TC_01-widget.png!\\ Invoice:\\ !TC_01-invoice.png!
  ```
  which renders in Jira as:
  ```
  Widget:
  [screenshot]
  Invoice:
  [screenshot]
  ```
  Same three upload-status substitutions as MXTS, applied independently per source — one source's upload failing never hides or blocks another's screenshot. Never drop a source's own label, and never collapse the cell to a single screenshot when the TC's own Actual Result names values read from two or more sources.

  **Comparison TC that is also multi-item:** qualify each label by item — a bare source label (`Widget:`/`Invoice:`) is ambiguous once 2+ items repeat the same sources. Same file-naming rule as Phase 3a: `<TC_ID>-<item-slug>-<source-slug>.png`:
  ```
  Spanish Widget:\\ !TC_12-spanish-widget.png!\\ Spanish Invoice:\\ !TC_12-spanish-invoice.png!\\ Italian Widget:\\ !TC_12-italian-widget.png!\\ Italian Invoice:\\ !TC_12-italian-invoice.png!
  ```

  **`FAIL`/`BLOCKED` debug evidence (`tc_debug_evidence[<TC_ID>]` set — see Debug Evidence Capture in
  [the Phase 3a execution reference](phase-3a-execution.md)) is appended independently of
  which base value applies** — missing Jira credentials, a failed upload, or even a
  failed capture must never be the reason evidence silently disappears; if anything, a missing
  screenshot is exactly when the network/console evidence matters most. Append it after whichever base
  value applies (for MCMS, that means after the `After:` half — the debug evidence describes the end
  state, same as the After screenshot), joined with Jira's forced line-break token `\\ ` (space
  mandatory — see above; never a literal newline — that ends the table row instead of breaking within
  the cell):
  - MXTS, with inline image: `!TC_07-login-error.png!\\ POST /api/v1/reservations/12345/confirm\\ Status: 500 Internal Server Error\\ Response: {"error":"NullPointerException","path":"/api/v1/reservations/12345/confirm"}`
  - MXTS, with plain filename (upload failed or uploads disabled): `TC_07-login-error.png\\ POST /api/v1/reservations/12345/confirm\\ Status: 500 Internal Server Error`
  - MCMS, with inline images: `Before:\\ !TC_07-login-error-before.png!\\ After:\\ !TC_07-login-error-after.png!\\ POST /api/v1/reservations/12345/confirm\\ Status: 500 Internal Server Error`
  - Multi-item, with inline images (evidence describes the failing item specifically, not the whole TC): `Spanish:\\ !TC_12-spanish.png!\\ Italian:\\ !TC_12-italian.png!\\ GET /api/v1/translations?lang=it\\ Status: 404 Not Found`
  - Comparison, with inline images (evidence describes the mismatch/failure specifically, not just the two screenshots): `Widget:\\ !TC_01-widget.png!\\ Invoice:\\ !TC_01-invoice.png!\\ GET /api/v1/invoices/8278\\ Status: 500 Internal Server Error`
  - With capture-failed note: `TC_07-capture-failed.png (screenshot capture failed — 3/3 attempts, CDP timeout)\\ Status: 500 Internal Server Error`

  No relevant network/console evidence found → just the base value, same as any other TC. Never force
  in empty or irrelevant text.

> **`--retest` cycle:** the table holds only the TCs this cycle executed (previous non-pass TCs, plus the High-risk regression check when it ran); Run 1 against the retest is marked in the Preconditions row and at the end of each Actual Result cell, and the stats rows count this cycle's TCs only — see [the scoped retest reference](${CLAUDE_PLUGIN_ROOT}/skills/execute-tests/references/scoped-retest.md). The template itself does not change.

> ⛔ **Skip this comment entirely if ALL TCs for the story are `BLOCKED`.** Surface the block reason in the Final Summary under ACTION REQUIRED. The lock is still released normally. **Set `story.partial_run = true` here regardless** — before the skip takes effect, not only inside the Partial-run detection block below — since a 100%-BLOCKED story never reaches that block when the comment itself is skipped. Without this, Exit Gate falls through to its normal pass-rate math (`PASS / (total − BLOCKED)`) against a story where `total − BLOCKED` is `0`, bypassing the forced-`BLOCKED` handling this flag exists for.
>
> **Exception — do NOT skip when the block reason traces back to Precondition Evidence Check or Integration Manager Setup** ([the Phase 3a execution reference](phase-3a-execution.md)) — this covers every `BLOCKED` reason either of those two sections produces (an unconfirmed ticket-level precondition, missing/ambiguous/failed integration credentials or setup, an import/export job that never completed, an external-portal step out of scope — the full list, not a partial one). Those verdicts exist specifically to be visible **on the ticket** — that is the evidence this pipeline exists to leave behind (confirmed necessary, MXTS-79013, Sep 2026: a run whose only record of "why" lives in a Final Summary no one but the runner ever sees is exactly the gap this check was built to close). Post the results comment as normal — `Preconditions` row plus every TC's `BLOCKED` reason in its own Actual Result cell — even when every TC ends up `BLOCKED` this way. The skip above still applies to every other all-BLOCKED cause (Playwright MCP down, environment down, a failed setup TC cascading to its dependents) where a Jira comment full of `BLOCKED` rows would add no evidentiary value beyond what the Final Summary already gives the runner.

**⚠️ Partial-run detection (before posting):** Compute `blocked_rate = BLOCKED / total TCs` for this story. If `blocked_rate > 50%` OR the run was stopped early (budget exhausted / early-abort):
- Insert the warning line `⚠️ PARTIAL RUN — High BLOCKED rate (<n>%). Review logs for root cause (environment issue, missing test data, selector failure, or run stopped early).` **immediately after the `h2. QA Test Results` header** (on its own line, before the stats table). Do NOT put it before the header — the first non-empty line must stay exactly `h2. QA Test Results` or `post-comment.js` validation rejects the body and its known-comment/cycle guard cannot recognize the comment as a results comment.
- Set `story.partial_run = true` — this is what [the Phase 5 defects and exit reference](phase-5-defects-and-exit.md)'s Exit Gate reads to force DoD `BLOCKED` regardless of pass rate; do NOT count this story toward DoD exit gate metrics — exclude from pass rate and completeness calculations.
- Log: `[Phase 3a] <STORY_KEY> flagged as partial run — blocked rate <n>% exceeds 50%.`
