# Phase 3a — Detailed Execution Procedure

## Cycle Stamp (run before the availability check below — before anything else in this phase)

If `stories.<STORY_KEY>.cycle_started_at` is not already set in `run-state.json` for this story (a fresh story, or one just reset by `--retest`/`--force`), write the current time as an ISO timestamp to it now, immediately — before the tool-registration check, before the connectivity probe, before any TC execution. This anchors Phase 3b's duplicate-comment check to this cycle only (see Phase 3b in SKILL.md); skipping this step here — e.g. because an agent is driving off this reference file directly after a compaction and never saw SKILL.md's own copy of this instruction — leaves `cycle_started_at` permanently null for the story, degrading Phase 3b back to its full-history fallback check for that story only (see `post-comment.js`'s three-layer guard). At the same time, initialize `stories.<STORY_KEY>.url_timing = {}` (per-URL timing, see Multi-URL Execution below) `stories.<STORY_KEY>.user_wait_seconds = 0`, `stories.<STORY_KEY>.pause_count = 0` and `stories.<STORY_KEY>.last_activity_at` = the same timestamp — these are what Phase 3b's **Test Execution Timing** row subtracts from the elapsed wall-clock time and counts as pauses (see Pause Tracking below, Session Recovery, and Phase 3b in this reference); they reset in lockstep with `cycle_started_at` on every fresh cycle, `--retest`, and `--force`. `run-timing.js init` (see Pause Tracking below) performs this whole stamp in one call.

> ⛔ **Check `user_wait_seconds` independently of `cycle_started_at` — a story resumed from a
> `run-state.json` that already had `cycle_started_at` set (e.g. from before this field existed, or a
> resume after compaction) can have a valid cycle timestamp but no `user_wait_seconds` at all.**
> Whether or not the `cycle_started_at` branch above fires this run, separately check
> `stories.<STORY_KEY>.user_wait_seconds` and initialize it to `0` if it is missing/undefined (and `stories.<STORY_KEY>.url_timing` to `{}` if missing — a resumed multi-URL run needs the object before the first per-URL write) — never
> let Phase 3b's subtraction run against an undefined value, which produces an invalid Test Execution
> Timing (`NaN`-shaped) instead of a real number. Same for `stories.<STORY_KEY>.pause_count` (initialize to `0` when missing) and, on a multi-URL run, each `url_timing.<hostname>.pauses`. A missing `last_activity_at` is initialized to the current time — nothing is known about any gap before this resume, so no pause is counted for it.

A resume after mid-run compaction re-reads the already-stamped value from disk and does NOT re-stamp it — this only fires once per story per invocation.

**Run metrics (fail-open, local only):** `/test-ticket` keeps a privacy-scrubbed run record at `test-output/<EPIC_ID>/run-metrics.json`. Whenever this reference logs a line that has an event code in the table of [the Run Metrics reference](${CLAUDE_PLUGIN_ROOT}/skills/execute-tests/references/run-metrics.md) (health-check blip, session recovery, MCP fallback, early abort, TC timeout, budget exhausted, host-guard stop, evidence review…), also run `node "$CLAUDE_PLUGIN_ROOT/skills/test-ticket/scripts/run-metrics.js" event "test-output/<EPIC_ID>" <code> || true`. A metrics failure never changes a verdict or blocks a step.

## Pause Tracking (feeds Test Execution Timing — the row is always a number, never N/A)

A run can pause while the tester is away: a Session Recovery wait, or a Claude Code session closed and the story resumed later from `run-state.json`. Phase 3b reports the pipeline's active time (wall clock minus the pauses) and how many pauses there were, so these runs stay comparable with the QA-hours figures. Pauses are detected from one persisted heartbeat, `stories.<STORY_KEY>.last_activity_at`, because a closed session never gets to record its own end.

**Never do this bookkeeping by hand** — all of it goes through `node "$CLAUDE_PLUGIN_ROOT/skills/test-ticket/scripts/run-timing.js" <cmd> test-output/<EPIC_ID>/run-state.json <STORY_KEY> …`, which edits `run-state.json` in place and keeps every other field. `init` is the whole Cycle Stamp and the independent field checks above in one idempotent call (run it at the start of Phase 3a and on every resume); the other commands are named in the bullets below. Full usage is in the header of the script.

- **Heartbeat** — `touch`: on every poll of a Variable-Duration Job Wait (so one long TC is never mistaken for a pause by a compaction resume), and in Phase 3b right after the screenshot uploads (when `cycle_ended_at` is captured). `tc-start` and `tc-end` (Per-TC Execution Loop, Step 0 and Step 6) are the heartbeat for each TC's start and verdict. `url-end <hostname>` is the heartbeat for a finished URL (it also sets that URL's `ended_at`).
- **Resume Gap Check** — `gap-check [--url <hostname>]`, run right after `init` on a resume (`init` fills what is missing and never touches `last_activity_at` when it exists). Run it once whenever a story that already has `cycle_started_at` is picked up again — in Phase 3a and in Phase 3b (`--from=phase3b`, or a resume after compaction or a new session) — before any TC runs or anything is posted. A gap of more than **600 seconds (10 minutes)** since `last_activity_at` is a pause: the script adds the gap to `user_wait_seconds`, adds 1 to `pause_count`, and with `--url` (the URL the next TC belongs to; in Phase 3b the last URL in run order) does the same in that URL's `url_timing` entry. A gap of 600 seconds or less is normal thinking or compaction time and counts nothing. Either way the script ends with `last_activity_at` = now, so the same gap is never counted twice.
- **Session Recovery waits** are always exactly one pause each, however short — `pause-start` when the wait begins and `pause-end [--url <hostname>]` when it ends, see steps 3 and 7 below.
- **Per-URL blocks (multi-URL runs)** — `url-begin <hostname>` before that URL's first TC, `url-end <hostname>` when its suite finishes.

## MCP Server Availability Check (run first, before stale-lock recovery)

> ⛔ **Playwright only — and only the three named prefixes below.** TC execution runs on Playwright MCP tools and nothing else: never substitute claude.ai Chrome tools, Puppeteer, a `WebFetch`-based read of the page, or any other browser connector — they cannot drive the app and they corrupt the execution log. The bundled server (`mcp__plugin_qa-engineer_playwright__*`) is the default. If it is absent but `mcp__playwright__*` or `mcp__playwright-headed__*` is registered in this session (the name the user's own `claude mcp add` gave it), use that one instead of blocking the run — both are enumerated in `allowed-tools` in SKILL.md for exactly this case, and both are the same `@playwright/mcp` server, so every step in this reference applies unchanged with the prefix swapped. A Playwright MCP under any other name is **not** a usable fallback — a tool call under a prefix not in `allowed-tools` is silently rejected, not routed, so it behaves exactly like no Playwright MCP being present. Log the fallback once — `[Phase 3a] Bundled Playwright MCP absent; executing on <prefix> instead.` — note it in the Final Summary so the user still fixes their install, and keep using that one prefix for the whole run. Only when none of the three prefixes is registered does the run block.

**Step 0 — Tool registration check (before calling anything):** Confirm at least one Playwright MCP tool actually appears in your available tools for this session — `mcp__plugin_qa-engineer_playwright__*`, `mcp__playwright__*`, or `mcp__playwright-headed__*`, per the callout above. This is a distinct failure mode from calling a tool and getting an error back; here there is nothing to call. A server that is otherwise perfectly healthy can still show zero registered tools in a given session, so do not assume registration from server health alone.

If no Playwright MCP tool is present under any prefix, **run the launcher's own diagnostic first — do not guess:**

```bash
node "$CLAUDE_PLUGIN_ROOT/mcp/run-playwright.js" --doctor
```

It prints, for this exact machine and repo, whether Node can reach the server package, whether Chrome is installed, where the Chrome profile lives, and whether anything is holding its lock. It exits 1 and lists a `BLOCKERS` section when a real dependency is missing. Quote the relevant lines in the report — this is the difference between the user fixing one concrete thing and re-installing the plugin at random, which is what the symptom used to invite.

Then interpret:

1. **Doctor reports BLOCKERS** → that is the cause. Report its `BLOCKERS` lines verbatim under ACTION REQUIRED and stop there; do not add speculative install-scope advice on top.
2. **Doctor reports "No blockers found"** → the environment is fine and the session simply has not picked the server up. MCP tool lists are built once at session start and never hot-refresh mid-conversation, so the fix is to **fully quit and reopen Claude Code** (a window reload is not enough), then re-run with `--from=phase3a`. Retrying in this session cannot work.
3. **The doctor script itself is missing or fails to run** → the installed plugin predates this launcher, or the install does not cover this repo. Plugin install is **scoped** (`/plugin install qa-engineer@maxxton-marketplace --scope <user|project|local>`) — `user` scope covers every repo on the machine; `project`/`local` covers only the repo it was run from. A project-level `.claude/settings.json` → `enabledPlugins` entry only ever fixes *that one repo* and is not the durable fix (a missing or legacy-suffixed entry there, e.g. `"qa-engineer@maxxton.com"` from older repo templates, is a symptom of the same root cause, not a separate one). Have the user run `/plugin list`, then `/plugin install qa-engineer@maxxton-marketplace --scope user` and update the marketplace to pick up the current version.

Report under ACTION REQUIRED:
```
⚠️ No Playwright MCP tools in this session — all TCs blocked. This is not a product issue.

Diagnosis (from: node "$CLAUDE_PLUGIN_ROOT/mcp/run-playwright.js" --doctor):
<paste the doctor output's BLOCKERS section, or "No blockers found">

Fix:
- Doctor listed blockers → fix those (they are concrete: Chrome missing, Node broken).
- Doctor found none → fully QUIT and reopen Claude Code (not a window reload — MCP
  tool lists are built once at session start), then re-run:
    /test-ticket <EPIC_ID> <URL> --from=phase3a
- Doctor script not found → your installed plugin is older than this fix. Run
  /plugin list, then: /plugin install qa-engineer@maxxton-marketplace --scope user
  (one-time, covers every repo — no per-repo settings.json edit needed).
```
Then mark all TCs `BLOCKED 🚫 (No Playwright MCP tools available in this session)`, release the QA-RUNNING lock (`remove-label.js "<EPIC_ID>" "QA-RUNNING"`), and skip directly to Final Summary — do NOT enter Phase 4. Log: `[Phase 3a] No Playwright MCP registered in this session. All TCs marked BLOCKED. Skipping to Final Summary.`

**Step 1 — Connectivity probe (only once Step 0 confirms the tool exists):** Call `browser_snapshot` once as a connectivity probe.

**If the call fails with a connection/server error** — any error that is NOT `"Browser is already in use"` (e.g. `failed to connect`, `connection refused`, `server unavailable`, `MCP server not responding`, `multiple retries`) — the MCP server itself is down. Do NOT attempt per-TC execution:

1. Immediately mark **all TCs across all stories** as `BLOCKED 🚫 (Playwright MCP server unavailable — <error summary>)`.
2. Release the QA-RUNNING lock: run `node "$CLAUDE_PLUGIN_ROOT/skills/test-ticket/scripts/remove-label.js" "<EPIC_ID>" "QA-RUNNING"`.
3. Skip directly to Final Summary — do NOT enter Phase 4 (no verdicts to triage). Surface this under ACTION REQUIRED with the exact fix steps:
   ```
   ⚠️ Playwright MCP server unavailable — all TCs blocked. This is not a product issue.

   Fix in 2 steps:
   1. Run in your terminal, from this repo:
        node "<plugin root>/mcp/run-playwright.js" --doctor
      It names the missing dependency directly. Add --install instead of --doctor to
      pre-install the server package so startup needs no network at all.
   2. Fully quit and reopen Claude Code (not a window reload), then re-run:
        /test-ticket <EPIC_ID> <URL> --from=phase3a

   If the doctor reports Chrome NOT FOUND, install it from google.com/chrome first —
   the server drives your system Chrome.
   ```

Log: `[Phase 3a] MCP server unavailable — <error summary>. All TCs marked BLOCKED. Skipping to Final Summary.`

Do NOT loop retries — a server that failed the initial probe will fail per-TC calls too.

---

## Jira Write-Path Check (run at Preflight, before any Jira write — see SKILL.md)

**Purpose:** Decide how this run writes to Jira — locks, labels, the TC comment, the results comment, the PR-link comment, status transitions, raised defects, issue links and screenshot upload — and persist the decision. Two paths exist:

- **`script`** — the credential-based scripts (REST API v2). Used only when `JIRA_EMAIL` / `JIRA_API_TOKEN` are configured **and Jira accepts them**.
- **`mcp`** — the Atlassian MCP connector (the user's claude.ai login). Used in every other case. It needs no token and no setup, so a missing, expired or unreachable token is never a reason to stop, to prompt, or to ask the user to configure anything. Procedure: [the MCP write path reference](jira-mcp-write-path.md).

The decision is stored as two values in `test-output/<EPIC_ID>/run-state.json` (see Compaction & State Recovery in SKILL.md), so it survives resume and mid-run context compaction: `jira_write_path` (`script` | `mcp`) and `screenshot_upload_enabled` (`true` when this run uploads screenshots to Jira, `false` when the Test Proof column carries plain filenames).

> ⛔ **Never read `~/.claude/settings.json` directly** — not in this step, not anywhere in the pipeline. The file can contain secrets (JIRA_API_TOKEN). Reading it puts the token into Claude's context window regardless of whether it is displayed. Use the probe calls below instead — the scripts read credentials internally and only report a word. (`run-state.json` holds only values and flags — no secrets — and is safe to read.)

**Step 0 — Re-anchor (skip the probes if already decided):**
- `run-state.json` already has `jira_write_path` → use it and `screenshot_upload_enabled` directly. **Do NOT re-run the probes** — with one exception: when the stored value is `script`, run `manage-credentials.js probe` once at the Preflight of every invocation (a fresh run, or a resume hours later; not after a mid-session context compaction). Anything but `valid` → log `[Evidence] Jira token no longer accepted (<invalid|unreachable|missing>) — switching this run to the MCP write path.`, set `jira_write_path = mcp`, run Step 2 and persist both values: a token that expired between the first run and the resume must not leave the run stuck on a dead script path, and the same-path rule keeps the comments already posted editable. Otherwise log `[Evidence] Restored jira_write_path=<value> from run-state.json.` and skip to the next section. **Comments from before `*_comment_path` existed:** a run-state with a `tc_comment_id` or `results_comment_id` but no matching `tc_comment_path` / `results_comment_path` is not treated as MCP-created. Before choosing how to edit it, read the comment from Jira and infer its creator path from the body — wiki markup (`h2. `, `||` header row, `!file.png!`) means `script`, HTML or Markdown means `mcp` — and persist the result next to the id.
- It has only `screenshot_upload_enabled` (written by an older plugin version): do not trust it — a stored `true` says nothing about whether the token still works. Ignore the stored value and derive both values fresh with Step 1 and Step 2, silently, then persist them.
- Neither is set → Step 1.

**Step 1 — Probe the credentials (no file read, no prompt):**
```bash
node "$CLAUDE_PLUGIN_ROOT/skills/test-ticket/scripts/manage-credentials.js" probe
```
Interpret stdout (it never prints a value):
- `valid` → `jira_write_path = script`, `screenshot_upload_enabled = true`. Log `[Evidence] Jira token accepted — script write path, screenshot upload enabled.` Skip Step 2.
- `invalid` → `jira_write_path = mcp`. Log `[Evidence] Jira token present but rejected by Jira (expired or revoked) — using the MCP write path for this run.` and repeat that line under the Final Summary notes so the owner knows to renew the token. Go to Step 2.
- `unreachable` → `jira_write_path = mcp`. Log `[Evidence] Jira REST API not reachable with the configured token — using the MCP write path for this run.` Go to Step 2.
- `missing` → `jira_write_path = mcp`. Log `[Evidence] No Jira token configured — using the MCP write path (no setup needed).` Go to Step 2. **Do not tell the user to add credentials, do not write placeholders into `settings.json`, do not ask a question** — the MCP path is the normal flow for anyone without a token.

**Step 2 — MCP path only: can this machine upload screenshots?**
```bash
node "$CLAUDE_PLUGIN_ROOT/skills/test-ticket/scripts/probe-media-host.js"
```
- `reachable` → `screenshot_upload_enabled = true`.
- No word on stdout at all (the script itself crashed) → treat it as `reachable`. Only an explicit `blocked` / `offline` may switch uploads off: the per-file upload step already handles a real failure, but a wrong "off" silently drops every screenshot.
- `blocked` or `offline` → `screenshot_upload_enabled = false` (cloud/sandboxed sessions block `api.media.atlassian.com`). Log `[Evidence] Screenshot upload unavailable (<blocked|offline>) — Test Proof will carry plain filenames.` and add to the Final Summary under ACTION REQUIRED: `Screenshots were not uploaded: api.media.atlassian.com is not reachable from this session (cloud/sandboxed sessions need it on the network allowlist). Filenames are in the Test Proof column.`

**Persist the decision (mandatory — the moment it is resolved):** set `jira_write_path` and `screenshot_upload_enabled` in `run-state.json`. This is the source of truth for every subsequent TC and for Step 0 on resume/after compaction. No secrets go in this file. `--unattended` behaves exactly the same — no step here ever prompts.

Log on completion: `[Evidence] jira_write_path = <script|mcp>, screenshot_upload_enabled = <true|false> (persisted to run-state.json)`

> ⛔ **After context compaction — never re-run the probes just because you are unsure.** Re-read `jira_write_path` and `screenshot_upload_enabled` from `run-state.json`. Only when both are unset there, run Step 1 (and Step 2) again silently and re-persist.

## MCP fallback — when `jira_write_path = mcp`

Wherever this skill instructs you to run one of the scripts below, and `jira_write_path = mcp` for this run, call the listed Atlassian MCP tool instead, with the same inputs and the same outcome — this is a substitution, not a separate feature to opt into. Resolve `cloudId` once (`getAccessibleAtlassianResources`, already called at Preflight for connectivity) and reuse it for every call below.

> ⛔ **`jira_write_path = mcp` does NOT mean "skip the rest of the pipeline's Jira writes."** Every operation in the table below switches to its Atlassian MCP equivalent for the rest of this run — including screenshot upload and inline embedding, which have an MCP equivalent too (see [the MCP write path reference](jira-mcp-write-path.md)). Only when the media host is unreachable (`screenshot_upload_enabled = false`) does the Test Proof column fall back to plain filenames. Confirmed 2026-08-12: a run without `JIRA_EMAIL`/`JIRA_API_TOKEN` configured produced **no TC comment, no results comment, no labels, and no status transition** — every credential-dependent script failed the same way, and the failures were treated as "nothing to do" instead of "fall back." The ticket never left "Ready for QA." A missing script credential must degrade the pipeline, never silence it.

| Operation | Script path (`jira_write_path = script`) | MCP write path (`jira_write_path = mcp`) |
|---|---|---|
| Acquire/release `QA-RUNNING` lock; `HL-Scenarios_Covered`, `QA_Pipeline`, `QA_Pipeline_Automation` labels | `add-label.js` / `remove-label.js` | `getJiraIssue` (read current `fields.labels`) → `editJiraIssue` with `fields: { labels: [...] }` — the **full** array with the one label added or removed, never a blind replace of the others |
| TC comment (new / correct in place) | `post-tc-comment.js` / `update-tc-comment.js` | `addOrEditJiraIssueComment` with `commentBody` (markdown) (pass `commentId` to update in place — see note below) — same 10-column table, rendered as a markdown table; validated with `validate-results-comment.js --kind tc --story <STORY_KEY>` and a Jira duplicate guard first (Phase 2 step 9) |
| Results comment (new / correct in place) | `post-comment.js` / `update-comment.js` | `addOrEditJiraIssueComment` — an HTML body with every screenshot embedded in its Test Proof cell (plain filenames in `<p>` elements when `screenshot_upload_enabled = false` — never a markdown body, which cannot carry a real mention), checked with `validate-results-comment.js` before every post; pass `commentId` to correct it in place. Upload, wiki-to-HTML conversion, duplicate guard and edit rules: [the MCP write path reference](jira-mcp-write-path.md) |
| PR-link comment | `post-pr-comment.js` | `addOrEditJiraIssueComment` with `commentBody` (markdown) — same two-line template; reproduce the script's own no-op-if-already-posted guard manually (see note below) — `addOrEditJiraIssueComment` has no built-in duplicate check and will post a new comment every time it's called |
| Status transition | `transition-issue.js` | `getJiraIssue` (read `fields.status.name`) first — already the target status → no-op, same as the script's own `ALREADY_IN_STATUS`. Not yet → `mcp__claude_ai_Atlassian_MCP__executeRead` with `name: listJiraIssueTransitions` → match the target status name to a `transition.id` → `transitionJiraIssue` with that ID. No matching transition → log and skip, same as the script's `NO_MATCHING_TRANSITION`, never treat as an error |
| Raise defect | `raise-defect.js` | `createJiraIssue` (`issueTypeName: "Bug"`; the same fields the script sets go in `additional_fields`) — **⛔ unlike every other row above, this one creates an irreversible Jira ticket. `createJiraIssue` has no confirmation gate of its own the way `raise-defect.js`'s `--confirmed` flag does — you must still print the proposal and get the user's explicit "yes" before calling it, exactly as Phase 5 requires. This is unconditional: no flag, no regression match, and no MCP-fallback status changes that requirement.** See phase-5-defects-and-exit.md for the full procedure. |
| Issue link (duplicate-bug reference) | `create-issue-link.js` | `mcp__claude_ai_Atlassian_MCP__executeWrite` with `name: createJiraIssueLink` (`linkType`, `inwardIssue`, `outwardIssue`) |

QA mentions in an MCP-fallback comment or table cell must mention each person by Jira Account ID (markdown `commentBody` has no ADF `mention` node; verify the mention renders after posting) — never plain text or email, same no-fallback rule as the script path (see analyzing-impact/SKILL.md's "Rendering depends on destination").

> **`commentId` is real — this is the tool's own parameter schema, verbatim, not an assumption:** `"commentId": {"description": "ID of an existing comment to update. If omitted, a new comment is added.", "type": "string"}`. Passing it updates that comment in place; omitting it adds a new one. This is not inferred from the tool's name — it's the documented parameter itself, already covered by the existing `addOrEditJiraIssueComment` entry in `allowed-tools` (no separate tool needed).

> **Every MCP-fallback comment must persist its own dedup state, because none of these operations have a built-in duplicate guard the way their script counterparts do.**
> - TC comment / results comment → **before calling `addOrEditJiraIssueComment`, check `tc_comment_id` / `results_comment_id` in `run-state.json` first.** Unset → this is a new post: call without `commentId`, then persist the ID from the response. **Exception — a story's first cycle never posts a results comment of its own:** with `results_comment_id` unset, `results_merged` not `true` **and the live comment `tc_comment_id` still an unmerged Test Cases comment** (it starts with `Test Cases —`), the results go into that comment (`commentId` = `tc_comment_id`), see [the MCP write path reference](jira-mcp-write-path.md) §3. `--retest` and `--force` clear `results_merged` but keep `tc_comment_id`, which then points at the earlier cycle's merged `QA Test Results` comment: that is a new cycle, so post the retest's own 6-column comment **without** `commentId` — never edit the earlier cycle's comment. Already set → this is a correction: call **with** `commentId` set to that value, never a new post. This is the exact same branch the script path already makes (`post-tc-comment.js`/`post-comment.js` vs `update-tc-comment.js`/`update-comment.js`), just via one tool instead of two scripts. A results comment split into parts (more than 45 rows — see phase-3b-split-results.md) checks and persists `result_parts[n-1].comment_id` per part instead.
> - PR-link comment → persist a `pr_comment_id` field (per story) in `run-state.json` the first time it's posted. Before calling `addOrEditJiraIssueComment` for this comment on any subsequent run/resume/`--retest`, check whether `pr_comment_id` is already set for this story — if it is, skip (already posted, this is the fallback's version of `post-pr-comment.js`'s own "fails closed and no-ops if the comment already exists" behavior); if it isn't, post and persist the returned ID.

> ⛔ **The write path is decided once per Epic and persisted — never switch it mid-run.** If `jira_write_path = mcp` was decided for this run, every comment/label/transition uses the MCP write path for the whole run, including on resume — re-derive it from `run-state.json`, never re-probe per call, and never fall back to the script mid-run just because it "might work now." (`jira_write_path = script` never falls back to MCP either: a script failure is retried once and logged, per the Phase 3b rules.) The one exception is correcting an existing comment, which follows the same-path rule in [the MCP write path reference](jira-mcp-write-path.md).

---

## Stale Browser-Lock Recovery (run after MCP availability check, before session detection)

**The launcher already handles this at server start — never by killing anything, and never by
asking the user to choose.** `mcp/run-playwright.js` sorts the profile out before starting the
server: a lock file with no live owner is cleared (deleting an inert leftover, not touching a
process); a profile actively held by *any* process — orphaned or a genuinely live second
Claude Code session, deliberately not distinguished — is left alone, and that server starts
`--isolated` instead. If this repo has a saved login (see "Save the login" in Browser Session
Detection below), the isolated server starts already authenticated via `--storage-state`, so a
second ticket running in a second session needs neither a fresh login prompt nor for anyone to
wait on the first session. This means two tickets tested in two separate Claude Code sessions
against the same repo — the normal way to run them in parallel — just work, with no prompt and
no risk to the other session's browser.

The server drives its own dedicated Chrome profile (NOT the user's personal Chrome), at
`~/.claude/qa-engineer/pw-profiles/<repo>-<hash>` — one per repo, so two repos never contend.
Run `node "$CLAUDE_PLUGIN_ROOT/mcp/run-playwright.js" --doctor` to see this repo's profile
path, lock status, and whether a saved login exists.

A lock taken *during* a run (mid-Phase-3a, after this server already started) surfaces as:

```
Error: Browser is already in use for <profile dir>, use --isolated …
```

This can only happen if a second session raced this one for the *same* profile between this
server's own startup check and now — the fix is the same one-time restart the doctor's own
guidance already gives, never a mid-run kill:

1. Mark every TC `BLOCKED 🚫 (browser unavailable — profile lock held by another session)`.
2. Release the QA-RUNNING lock — `remove-label.js "<EPIC_ID>" "QA-RUNNING"` when
   `jira_write_path = script`, or its MCP fallback (read `fields.labels`, write back the
   array without `QA-RUNNING`) when it's `mcp`, same as every other lock release in this
   pipeline (see "Jira Write-Path Check" → MCP fallback).
3. Skip directly to Final Summary — do NOT enter Phase 3b/4, same as every other all-BLOCKED
   path in this section.
4. Surface under ACTION REQUIRED: `Restart this session's MCP server (fully quit and reopen
   Claude Code) and re-run — a saved login for this repo means the retry needs no fresh login.`

Do not attempt to detect or kill anything here — that is exactly the launcher's job at its own
startup, not a mid-run responsibility, and killing a process this skill cannot positively
identify as safe to kill is worse than a clean restart.

---

## Environment Health Check (runs after stale-lock recovery, before session detection)

Call `browser_navigate` to `<base URL>`. Then call `browser_snapshot` and inspect the result.

**Indicators of a degraded environment:**
- HTTP 5xx response (500, 502, 503, 504)
- Blank or empty page body
- "Service Unavailable", "Bad Gateway", "Maintenance", "Gateway Timeout" text visible
- Navigation itself errors (connection refused, timeout, DNS failure)

**If any indicator is present — one retry before mass-blocking, not zero:** a transient blip (mid-deploy restart, a momentary gateway hiccup) looks identical to a genuinely dead environment at the first probe, and mass-blocking an entire Epic's TCs over a 10-second window that would have cleared on its own is expensive to recover from (a full re-run). Wait 30 seconds, then repeat the same `browser_navigate` + `browser_snapshot` probe **exactly once**. Still showing an indicator → treat as a genuine outage and proceed to the mass-block below. Clear on the retry → log `[Phase 3a] Env health check — transient (<indicator> on first probe, cleared after 30s retry) — proceeding normally.` and continue to session detection as if nothing happened. Never retry a second time — a still-degraded environment after one retry will not recover on a third probe either, and this is not a substitute for the environment actually being fixed.

**Still degraded after the retry:**

0. Run the [Environment-Down Check](${CLAUDE_PLUGIN_ROOT}/skills/execute-tests/references/environment-down-check.md) once for this URL's concern (read-only Slack lookup of the Oracle Bot patch status; a missing Slack connector or any error just skips it). Result `broken` → use `BLOCKED 🚫 (Environment unavailable — Oracle Bot reports <concern> broken, <indicator summary>)` below and add that cause to the ACTION REQUIRED message; otherwise nothing changes.
1. Immediately mark **all TCs across all stories** as `BLOCKED 🚫 (Environment unavailable — <indicator summary>)`.
2. Release the QA-RUNNING lock: run `node "$CLAUDE_PLUGIN_ROOT/skills/test-ticket/scripts/remove-label.js" "<EPIC_ID>" "QA-RUNNING"`.
3. Skip directly to Final Summary. Do NOT enter Phase 4, do NOT post TC results comment.
   Surface under ACTION REQUIRED:
   ```
   ⚠️ Environment health check failed — <base URL> is not responding correctly (confirmed after a 30s retry).
   All TCs blocked. No results posted to Jira.

   Fix: Verify the environment is up and re-run:
     /test-ticket <EPIC_ID> <URL> --from=phase3a
   ```

Log: `[Phase 3a] Env health check — <base URL> returned <indicator> on both the initial probe and the 30s retry. All TCs blocked. Skipping to Final Summary.`

**If the page loads normally on the first probe** (login page, app shell, or any non-error page) → proceed immediately, no retry needed.

---

## Multi-URL Execution and Browser Session Detection (runs after environment health check)

**Multi-URL execution:** If the ticket has more than one URL, run the full TC suite on URL 1 first, then repeat on URL 2. Store results separately per URL — `results_<hostname>.md` (e.g. `results_mqa-dev.md`, `results_rcn-dev.md`). Log: `[Phase 3a] Running on URL <n>/<total>: <url>`

**Per-URL timing (multi-URL runs):** each URL is a different concern with its own run time, so the Test Execution Timing row is computed per URL, never copied across blocks. The moment URL <n>'s TC suite finishes (last TC recorded, before starting URL <n+1> or leaving Phase 3a), set `stories.<STORY_KEY>.url_timing.<hostname>.ended_at` to the current ISO time and persist `run-state.json` immediately. Session Recovery waits and Resume Gap Check pauses (Pause Tracking, above) are added to `url_timing.<hostname>.user_wait_seconds` — and counted in `url_timing.<hostname>.pauses` — for the URL being tested, in addition to the story-level `user_wait_seconds` and `pause_count`. A single-URL run needs no `url_timing`. Create `url_timing.<hostname>` with `run-timing.js url-begin <hostname>` (it writes `{ "user_wait_seconds": 0, "pauses": 0 }` when absent) and persist it **before** the URL's first TC starts — a Session Recovery wait on the first TC must find the entry — and keep an existing entry untouched on a resume. **MCP write path only (`jira_write_path = mcp`):** the moment the TC suite finishes, move that URL's result screenshots into `test-output/<STORY_KEY>/<hostname>/` (same filenames), taking each file from the absolute path resolved for it by the screenshot-path check below (normally `<project root>/.playwright-mcp/`, not `test-output/`), so the next URL's same-named captures cannot overwrite them before Phase 3b uploads; that folder is the file-to-URL mapping Phase 3b uploads from (see [the MCP write path reference](jira-mcp-write-path.md)).

**Browser session detection (per URL):** Attempt `browser_snapshot` (best-effort — if it fails because the browser is closed or not yet opened, treat it as the closed/empty case below).
- URL starts with base URL + no login form → reuse session. Log: `[Phase 3a] Existing session detected — reusing.`
- URL starts with base URL + login form → ask user to log in; wait; verify via `browser_snapshot`; then save the login (below).
- `browser_snapshot` failed, or browser is on a different URL → `browser_navigate` to base URL → wait for page load → call `browser_snapshot`:
  - No login form visible → session restored from browser profile cookies. Log: `[Phase 3a] Session restored from profile — no login required.` Proceed immediately.
  - Login form visible → ask user to log in; wait; verify via `browser_snapshot`; then save the login (below).

**Save the login (only right after a fresh login above — skip when the session was reused or restored from profile cookies):** run `node "$CLAUDE_PLUGIN_ROOT/mcp/run-playwright.js" --storage-state-path` to get this repo's save path, then call `browser_storage_state` with that path as `filename`. Log: `[Phase 3a] Login saved for this repo — a second ticket in a second session can now start straight into isolated mode, already authenticated.` This is what the Stale Browser-Lock Recovery section above relies on.

---

## Step Interpretation — domain-specific action steps

Confirmed necessary (MXTS-78484, Sep 2026): a TC step reading "Trigger a bill refresh/recalculation" doesn't describe a standard navigate/click/fill/select/observe action — it names a domain action, and skipping it silently (because it doesn't look like a UI interaction to perform) leaves the assertion that follows checking stale, pre-recalculation data instead of the state the TC actually requires. When a step names a domain action rather than a generic UI verb, locate the specific control for it (a button/menu item named accordingly, e.g. "Recalculate", "Refresh", "Reissue", "Cancel booking") via `browser_snapshot` and perform it — never treat it as already satisfied or move straight to the next step. **The action is destructive/irreversible** (cancel, unlink, delete, remove, deactivate — regardless of whether the step text contains the word "click") → route it through the Multi-Stage Inline Confirmation procedure below exactly like a click step would; a domain-action step name doesn't exempt it from re-snapshotting between confirmation stages. **The control is not on the current screen** → run Control Discovery first — the procedure is in `${CLAUDE_PLUGIN_ROOT}/skills/execute-tests/references/control-discovery.md` (the entity's own screens, the step's own words, the owning module, time-boxed; never ask the tester before it has run). A control missing from one screen is not proof it does not exist: MXTS-81060 had 10 TCs `BLOCKED` after only two read-only screens were checked, while the control sat on the reservation's unit. **Still nothing after Control Discovery** → the precondition it sets up is unmet: mark the TC `BLOCKED 🚫 (step "<step text>" — no matching control; checked: <places>)` rather than asserting against data that was never actually refreshed.

### Multi-stage inline confirmation (destructive actions)

<!-- ⚠️ MUST KEEP IN SYNC with execute-tests/references/multi-stage-confirmation.md — same mechanics. Both skills are self-contained — prompt-based skills cannot import each other's steps at runtime. -->

Some destructive actions (Unlink, Delete, Remove, Deactivate) confirm via a button that morphs its own label **in place** through 2–3 stages instead of opening a modal dialog — e.g. Channel Manager's "Unlink commission" → "Are you sure?" → "Confirm" (confirmed live, MXTS-81997, Sep 2026). Each stage is a genuinely different element (new accessible name, new DOM ref) rendered in the same visual slot — not the same button clicked repeatedly. **Never** reuse a cached ref/selector from an earlier stage, and **never** click "the same visual position" without re-reading the element's current label — an unrelated card loading elsewhere on the page can shift this button's position between clicks, and a stale-position click can land on a completely different control (confirmed real-world consequence: a stale-position click during a multi-stage confirmation deleted the wrong record entirely). A TC step reading as one instruction (e.g. "Confirm in the confirmation dialog") can still require 2–3 real clicks.

**Procedure:** click the initiating button → `browser_snapshot` again (never reuse the pre-click snapshot) → read the button's current accessible name in the same slot; if it names another confirmation stage, click it and repeat → stop once the action has actually executed (row disappears, success toast, or the button reverts/disables) and verify via a fresh snapshot before recording the verdict. **Cap at 5 clicks total** — a real sequence is 2–3 stages; still cycling after 5 means something is stuck, mark `NEEDS REVIEW` rather than clicking indefinitely. **Re-read label matches no expected stage** → stop clicking blindly; re-snapshot, reassess, and mark `NEEDS REVIEW` if still ambiguous rather than guessing which element to click next. Applies to any step-verb ending in an irreversible action, regardless of whether the TC table's own wording calls out the multiple stages.

**Related pattern — a list of cards/rows, not one morphing button:** the same root cause (trusting position/index instead of re-verifying identity right before a destructive click) shows up in a *list* of separate cards each with their own destructive action. If a card loads asynchronously and inserts itself above the target between identifying it and clicking its action, a position/index-based click (e.g. "click the 3rd card's Delete button") lands on whatever card now occupies that position, not the intended one. Never click a list item's destructive action by position/index alone — immediately before the click, re-snapshot and confirm the target's own identifying text (name/code/ID) matches the intended record.

## Navigation Cache (runs after environment health check, before test data setup)

Persists discovered page URLs across runs and tickets so Phase 3a can navigate directly to feature pages on future runs without clicking through the sidebar. Gets faster over time as more routes are cached.

**Cache file:** `test-output/nav-cache.json` — shared across all Epics and tickets (not scoped per Epic). Created on first run; updated after every Phase 3a completion.

Route key = URL path after `#/`, trailing slash stripped — e.g. `https://mqa-dev.maxxton.net/#/reservations/list` → key `reservations/list`.

```json
{
  "mqa-dev.maxxton.net": {
    "reservations": { "url": "https://mqa-dev.maxxton.net/#/reservations", "last_verified": "2026-06-23" },
    "customers":    { "url": "https://mqa-dev.maxxton.net/#/customers",    "last_verified": "2026-06-20" }
  },
  "rcn-dev.maxxton.net": {
    "reservations": { "url": "https://rcn-dev.maxxton.net/#/reservations", "last_verified": "2026-06-21" }
  },
  "_meta": { "run_count": 7, "last_updated": "2026-06-23", "max_entries": 200 }
}
```

**Load (after environment health check):**
1. Read `test-output/nav-cache.json`. If file is missing → start with empty cache (no error).
2. If file exists but JSON is invalid (parse error) → start with empty cache, log: `[Cache] nav-cache.json corrupted — starting fresh.` Do NOT crash or block execution.
3. Store valid cache as in-memory `nav_cache[<hostname>]`.

**Per-TC navigation — cache-first:**
1. From the TC scenario text, infer the target route key (e.g. "Verify reservation is created" → `reservations`; "Verify customer name is shown" → `customers`; "Verify invoice amount is correct" → `invoices`).
2. Check `nav_cache[<hostname>][<route-key>]`:
   - **Not in cache** → sidebar navigation. After landing on the correct page, record the URL + today's date as `last_verified`. Log: `[Cache] Nav miss — discovered <url>, cached for next run.`
   - **In cache, `last_verified` ≤ 30 days ago** → `browser_navigate(<cached_url>)`. Log: `[Cache] Nav hit — <route-key> → <url>`
   - **In cache, `last_verified` > 30 days ago** → treat as soft-stale: navigate to cached URL, then verify (step 3 below). Log: `[Cache] Nav stale — re-verifying <route-key>.`
3. **Post-navigate sanity check (cache hits only):** After `browser_navigate`, inspect the resulting URL and page title. If the current URL path does not start with the expected route key → wrong page loaded. Fall back to sidebar navigation immediately, update cache with the correct URL. Log: `[Cache] Nav hit led to wrong page — invalidated <route-key>, re-discovered.`

> ⛔ **Never skip sidebar fallback.** Cached URL failure (404, redirect-to-login, wrong page) → fall back immediately. Do NOT retry the cached URL.

**Eviction — enforce max 200 entries:** Before writing, if `nav_cache[<hostname>]` exceeds 200 route keys, evict the entries with the oldest `last_verified` dates until the count is ≤ 200.

**`--clear-nav-cache` flag:** If passed, delete `test-output/nav-cache.json` at Phase 3a start before loading. Use after a major app restructure where route paths have changed. Log: `[Cache] nav-cache.json cleared by --clear-nav-cache flag.`

**Write (immediately after execution-log.json) — under an exclusive lock, never a blind overwrite.** This file is shared across every concurrent story/ticket/Epic run against the same repo (that's the whole point of it). A re-read-then-write without a lock still loses updates: two sessions can both read the same fresh copy before either writes, merge their own dirty entries onto it, and the second write erases the first session's routes. Only a real mutual-exclusion lock around the whole read-merge-write closes that gap.

**Acquire the lock** — `test-output/nav-cache.lock/` is a *directory*, not a file: creating a directory is atomic on both Windows and POSIX, so two sessions racing to create it can never both succeed.
1. Try to create it (Bash: `mkdir "test-output/nav-cache.lock" 2>/dev/null && echo acquired`; PowerShell: `New-Item -ItemType Directory -Path "test-output/nav-cache.lock" -ErrorAction SilentlyContinue`). Succeeded (it did not already exist) → lock held, go to step 4.
2. Already exists → check its age. Older than 15 seconds → an abandoned lock from a crashed session; remove it and retry step 1 once. 15 seconds or younger → another session is actively writing; wait ~500ms and retry step 1.
3. **Give up after ~10 seconds of retrying** (~20 attempts) rather than block this run indefinitely on a stuck lock — but do NOT fall through to steps 4–9 without the lock; that would be the exact unprotected read-merge-write the lock exists to prevent. **Skip the cache write entirely for this run instead** — this run's own newly-discovered routes are lost for next time (a speed regression only, `browser_navigate` still worked fine via the sidebar this run), never a correctness problem, and never worth risking another session's already-recorded routes to save. Log: `[Cache] Could not acquire nav-cache.lock after 10s — skipping this run's cache write (routes discovered this run will not be persisted).` Do not retry further and do not proceed to step 4.

**Only once the lock is actually held:**
4. Track only the route keys *this run itself* discovered or re-verified this session as a small "dirty" set, not the whole in-memory cache.
5. Read `test-output/nav-cache.json` from disk again, fresh, right now (missing/corrupt → treat as empty, same as Load).
6. Merge this run's dirty set onto that fresh read — only the specific `[hostname][route-key]` entries this run touched get overwritten; every other route already on disk (written by any other session) is kept as-is.
7. Apply eviction on the merged result if needed.
8. Increment `_meta.run_count` on the merged result.
9. Write the merged result back.

**Release the lock immediately after** (Bash: `rmdir "test-output/nav-cache.lock"`; PowerShell: `Remove-Item "test-output/nav-cache.lock" -Force`) — attempt this even if a step above errored, so a genuine failure never leaves a stale lock for the next run to wait out.

Log: `[Cache] Nav cache updated — <n> routes for <hostname>.`

**Phase 3b fallback use:** When generating Playwright spec files and `execution-log.json` has no `navigated_to` URL for a TC, consult `nav_cache[<hostname>][<inferred-route-key>]` as a fallback URL source for the `browser_navigate` call in the spec. Log: `[Cache] Nav cache used as spec URL fallback for <TC_ID>.`

---

## Permission Toggle startup check (also run from SKILL.md's Resume Check on every invocation, before any phase is skipped; within Phase 3a it runs once before the per-TC loop, right after the Navigation Cache and before Precondition Evidence Check, Test Data Setup and Feature Flag Setup — nothing that writes to the environment runs before it)

List `test-output/permission-toggle/*.json` and restore any leftover marker for this environment before doing anything else — a crashed earlier run may have left the shared Maxxton Admin role restricted. Procedure and marker format: `${CLAUDE_PLUGIN_ROOT}/skills/execute-tests/references/permission-toggle.md` ("Startup check").

## Feature Flag startup restore (runs right after the Permission Toggle startup check — from SKILL.md's Resume Check on every invocation, and again here before any environment-writing setup)

Before processing any Epic, read every Epic's `test-output/<EPIC_ID>/run-state.json` for non-empty `flags_enabled_this_run` / `flags_disabled_this_run`. A non-empty list whose Epic's `flags_heartbeat_at` (or, if absent, `run-state.json`'s modified time) is more than 30 minutes old — or that belongs to an Epic this invocation is itself resuming — is a leftover from a run that crashed before its Final Summary; a fresher one belongs to a run still active in another session and is left alone (log it): take only the entries whose `host` is the environment this session is on (entries for other hosts stay in their lists for a run on that environment), net them per flag across Epics (see Invocation-wide baseline below), restore each flag in Maxxton Admin (enabled-list → disable, disabled-list → enable), and remove an entry only after re-reading the flag confirms the restored state. A flag that cannot be restored stays in its list and is reported under ACTION REQUIRED. Setup and per-TC reconciliation then re-apply whatever the TCs need, so later work starts from the original environment state instead of treating the altered one as the baseline.

## Precondition Evidence Check (runs once before the per-TC loop, before Test Data Setup)

<!-- ⚠️ MUST KEEP IN SYNC with the "Precondition Evidence Check" procedure in execute-tests/references/precondition-evidence.md — same detection signals, same automated-check + manual-gate tiering, same evidence shape. test-ticket has a Phase 1 step, so detection here consumes `story.preconditions` (built in Phase 1 step 3h) instead of re-scanning the ticket directly. Both skills are self-contained — prompt-based skills cannot import each other's steps at runtime. -->

**Why this exists:** distinct from a per-TC data precondition (Test Data Setup, below) — some tickets carry a *ticket-level* precondition: a companion ticket, PR, or fix that must be deployed to the environment before any TC result means anything. Confirmed necessary (MXTS-79013, Sep 2026): the ticket shipped once ("closest level wins"), QA found a real failure, the dev corrected the algorithm ("date-valid union" — a superseding PR), and that correction had to reach the test environment before a retest meant anything — but nothing in the pipeline's own output ever recorded that the correction was confirmed live *before* the retest ran. Running this check first, before Test Data Setup or Feature Flag Setup spend any effort, avoids seeding data or toggling flags for a story about to be blocked wholesale anyway.

For each entry in `story.preconditions` (built in Phase 1 step 3h — usually empty):

1. **`linked_ticket` is set** → call `getJiraIssue` on it (`fields: ["status"]`).
   - Status is done-like (`Done`, `Closed`, `Checked by QA`, `Resolved`, or `statusCategory` = `Done`) → **confirmed automatically**. Log `[Precondition] <linked_ticket>: <status> — confirmed before this run.`
   - Not done-like → a ticket's own status can lag reality — a merged PR routinely outruns its ticket's transition (MXTS-79013 sat "pending QA verification; status not transitioned" for days after merge). This does **not** mean the precondition is unmet, only that the automated check can't confirm it — fall through to the manual gate below.
2. **No `linked_ticket`, or the automated check above didn't confirm** → manual gate. Ask the tester:
   ```
   Precondition: "<description>"<, dependency <linked_ticket> currently <status>, if applicable> — confirmed satisfied on <base URL>? (yes/no)
   ```
   - `yes` → log `[Precondition] "<description>" — confirmed by tester before this run.`
   - `no` → not confirmed.
   - **`--unattended`** → skip the prompt entirely; default to **not confirmed** (fail closed — same convention as every other uncertain-verdict rule in this pipeline). Log `[Precondition] "<description>" — unattended mode, no tester confirmation available; treating as not confirmed.`

**Evidence (write before the per-TC loop, regardless of outcome — this is the audit trail):** persist the resolved list to `run-state.json` as `stories.<STORY_KEY>.preconditions_verified` — an array, one entry per `story.preconditions` item, overwritten fresh each cycle (`--retest`/`--force`) so a retest re-evidences rather than trusting a stale record:

```json
[
  {
    "description": "Rev 2 fix (date-valid union) must be deployed before retest",
    "linked_ticket": "MXTS-79012",
    "status_at_check": "Checked by QA",
    "confirmed": true,
    "confirmed_by": "automated",
    "confirmed_at": "2026-09-21T08:30:00Z"
  }
]
```

`confirmed_by` is one of `automated` / `tester` / `unattended-default`.

**Not confirmed → block.** Any entry with `confirmed: false` blocks **every TC in this story** — a ticket-level precondition has no reliable per-TC attribution to narrow the blast radius the way a data precondition does. Mark each TC `BLOCKED 🚫 (precondition not confirmed: "<description>")` and skip straight to the Completeness Gate — do not attempt any TC in this story. Log: `[Precondition] "<description>" not confirmed — all TCs in <STORY_KEY> blocked.`

**Results comment:** the Phase 3b stats block carries a `Preconditions` row summarizing `preconditions_verified`, semicolon-joined (or `None detected` when `story.preconditions` was empty) — see [the Phase 3b results-comment reference](phase-3b-results-comment.md).

Log a summary regardless of outcome: `[Precondition] Check complete — <n> found, <n> confirmed, <n> not confirmed.` (skip the log line entirely when `story.preconditions` is empty).

---

## Integration Manager Setup (Supplier / Reseller Tickets — runs once before the per-TC loop, after Precondition Evidence Check)

<!-- ⚠️ MUST KEEP IN SYNC with the "Integration Manager Setup" procedure in execute-tests/references/integration-manager-setup.md — same credential flow, same external-portal boundary. test-ticket has a Phase 1 step, so this consumes `story.integration_name` (built in Phase 1 step 3i) instead of re-scanning the ticket directly. Both skills are self-contained — prompt-based skills cannot import each other's steps at runtime. -->

**Scope decision (2026-09, per QA feedback on Supplier/Reseller pipeline coverage — MXTS-79080/MXTS-80518):**
- **Supplier tickets** (test setup → import → verify data landed in Integration Manager / Content Manager (Availability) / Revenue Manager (Rates)) — **in scope**, gated on the credential + polling procedure below.
- **Reseller tickets' internal half** (test setup → export → verify Content/Rates/Reservations) — **in scope**, same procedure.
- **Reseller tickets' external-portal half** (verifying the same export on the client's own portal — Booking.com Extranet, Airbnb Developer Portal, etc.) — **permanently out of scope.** No live session capability into a third-party system exists in this pipeline. See "External Portal Boundary" below for the exact verdict.

`story.integration_name` unset **and** `story.integration_ambiguous_candidates` empty (from Phase 1 step 3i) → skip this whole section; not an Integration Manager ticket.

`story.integration_name` unset **but** `story.integration_ambiguous_candidates` non-empty → this IS an Integration Manager ticket, just unresolved. Ask the tester once: `Which integration does this ticket test — <story.integration_ambiguous_candidates>?` `--unattended` → skip the prompt (fail closed); log `[IntegrationSetup] Ambiguous integration ("<candidates>") — unattended mode, no tester available to disambiguate.`, mark every TC whose own steps/preconditions explicitly name Integration Manager setup `BLOCKED 🚫 (integration name ambiguous — could not auto-detect in unattended mode)`, and skip the rest of this section (TCs that don't depend on this setup still run normally). Tester resolves it → set `story.integration_name` to the answer and continue below as normal.

**Credential Setup:**
1. Probe: `node "$CLAUDE_PLUGIN_ROOT/skills/test-ticket/scripts/manage-integration-credentials.js" check "<story.integration_name>"` (add `--fields=F1,F2,...` if the ticket names a non-username/password credential shape).
2. `present` → proceed to Test Setup.
3. `missing` → run `add "<story.integration_name>" [--fields=...]`, tell the user exactly:
   > 📎 **Test credentials for `<story.integration_name>` not configured.**
   >
   > I've added placeholder fields to your `~/.claude/settings.json`. Fill in this integration's test-environment credentials (never production), save, then type **`updated`** to continue — or **`skip`** to proceed without them (every TC needing this integration's setup will be `BLOCKED`).
4. `updated` → re-check. `present` → proceed; still `missing` → ask again or `skip`.
5. `skip`, or `--unattended` → run `remove "<story.integration_name>"` to clean up the empty placeholders, mark every TC needing this integration's setup `BLOCKED 🚫 (integration test credentials not configured for <story.integration_name>)`, and skip Test Setup below.

**Never** print, log, or paste a credential value anywhere in the conversation — the script only ever reports `present`/`missing`.

**Test Setup** (once credentials confirmed present): via Playwright, in the app's own Supplier/Reseller connection admin screen — add the test credentials, configure any test-specific IDs the ticket's setup notes name, and unlink/link existing connections where required. Log: `[IntegrationSetup] "<story.integration_name>" — credentials applied, <n> test ID(s) configured, <n> link/unlink action(s) applied.` **Setup step fails** → log the reason; mark only the TCs depending on it `BLOCKED 🚫 (integration test setup failed: <reason>)`.

**Variable-Duration Job Wait (Supplier import / Reseller export):** do not assume completion after a fixed pause — poll the job/queue screen's status via `browser_evaluate` (not `browser_wait_for` — no selector support, same limitation as the Page-ready wait below) with repeated short calls (each at most 60 s, see the rule at the start of the Per-TC Execution Loop), about every 5s, up to a 15-minute cap counted in wall-clock time (override if the ticket names a longer expected duration), until the status reads a completed/failed pattern. `done` → proceed to Cross-Module Verification. `failed` → `FAIL ❌`, capture the job's own error as evidence. `timeout` → `BLOCKED 🚫 (import/export job did not complete within 15 min — verify manually or re-run with a longer wait)`.

**Cross-Module Verification:** Supplier import → verify data in Integration Manager, then Content Manager (Availability) and Revenue Manager (Rates), same multi-screen comparison as any other TC. Reseller export (internal half) → verify across Content, Rates, and Reservations, and against a previous export only when the ticket actually provides one to compare against — never invent a baseline.

**External Portal Boundary:** any TC step requiring verification on a third-party client portal — mark it `BLOCKED 🚫 (external portal verification — <portal name> — out of pipeline scope, requires manual QA)`. Permanent boundary, not a missing-credential situation — never retry, never `NEEDS REVIEW`. The internal half of the same TC (data correct up to the point of export) still gets tested normally.

---

## Test Data Setup (runs once before the per-TC loop)

<!-- ⚠️ MUST KEEP IN SYNC with execute-tests/SKILL.md's "Step 2d: Test Data Setup" — same four precondition shapes (existence / state / quantity / combination). Both skills are self-contained — prompt-based skills cannot import each other's steps at runtime. -->

> ⛔ **Which data rules apply to live execution.** This section governs the live TCs on dev/test. A `CLAUDE.md` of the repo the session was opened in (typically `mxts-qa-automation` or `mcms-qa-automation`) may say regression specs use dummy data only and create their own uniquely suffixed records — that rule is for the committed spec files (Phase 3b/6), not for these live TCs. In live execution an existing record may be **read** (searched, opened, viewed, or used as proof of a status precondition) but never edited, deleted or changed — the exceptions are the setup actions in Test Data Setup (link a customer, fill fields, add or remove guests, add-ons and children on a spare record, create records), all logged in `seed_records` and put back after the story. Records a TC creates are `QA-AUTO-<STORY_KEY>-<TC_ID>-…` records, torn down after that TC (the per-TC rules below); a TC that edits data edits only a record this run created or seeded — a `QA-AUTO-` record, or a `QA-SEED-…` precondition fixture seeded by this section, which is torn down after the story. Never refuse a TC, or mark it `BLOCKED`, because an existing record is used read-only. KEEP IN SYNC with execute-tests' `references/test-data-rules.md`.

**Open a record only when it is needed (the whole run, not only this setup).** Never open the first or initial row of a list (a reservation list, the dashboard's "My Reservations", the Planning Chart) or any other existing record to look around: to learn the UI, to see whether a tab, toggle or control exists, or to find out what a state or a kind of record looks like. Open an existing record only when a TC step or a precondition needs that exact record, and then one found by searching or filtering on what the precondition names, or one this run created (`QA-SEED-…`, `QA-AUTO-…`). To learn how something works use the Help Centre and Knowledge tools, or a list's own filters and columns. A precondition whose record cannot be found is a data question for the procedures below (search, seed, or `BLOCKED` with the reason), never a reason to open records one by one. KEEP IN SYNC with execute-tests' `references/test-data-setup.md`.

**A TC that deletes, archives or edits a record gets its own.** When the record is one this run did not create (an existing one, or one a tester named), do not skip the TC and do not touch that record: create one for it (`QA-AUTO-<STORY_KEY>-<TC_ID>-…`, or reuse a `QA-SEED-…` one) and run the TC on that. It is `BLOCKED` only when no such record can be created within the limits of the quantity procedure below. A group reservation is created in Reservation Manager: dashboard menu → "New group reservation" (`/group-reservations/new`, needs the create permission for group reservations). KEEP IN SYNC with execute-tests' `references/test-data-setup.md`.

Scan the `Preconditions` column of every TC for this story. Identify all entities that must exist (edit, link, view, duplicate-check scenarios) — including a precondition that names a **state** the entity must be in (e.g. "1+ archived <entity>") or a **quantity** of it (e.g. "enough <entity> to span 2+ pages"). Those two shapes don't fit "does one record exist, yes/no" — handle them with the dedicated procedures below instead of the plain existence check.

**Search by what the list can search.** The seed name goes into a search box or filter only when the entity has a name field that holds it (a customer, a supplier, a product). A record without one (an ordinary reservation, a booking, an invoice, a payment) cannot carry `QA-SEED-…` (a group reservation is the exception: its TCs name it, so use the group list's own search): typing it into that list's search matches nothing and proves nothing. Find such a record by what it does have: its number, the customer linked to it, dates, status, type. Take a snapshot of the list's filter panel first and apply only a filter whose label matches an attribute the precondition names, with a value the precondition names. Never try filters to see what they do, and clear every filter you applied before the next search. Keep a found or created record of that kind by its number for the rest of the run (`[Seed] Reusing existing: reservation <number> (<attributes>).`). KEEP IN SYNC with execute-tests' `references/test-data-setup.md`.

**Small setup gaps and equivalent data — never block a TC or stop the run for them.** Confirmed necessary (2026-10-22, MXTS-79611): a run stopped to ask the tester to link a customer and name guests on the reservation the tester had named, and left TCs at `BLOCKED` / `NEEDS REVIEW` over a literal guest name and a count of 27 against 30. KEEP IN SYNC with execute-tests' `references/test-data-setup.md`.
1. **Do the setup a TC needs yourself — never ask first, never stop.** Whatever ordinary in-app actions close the gap is a setup step of this run, not a question for the tester: link a customer, fill a field, add or remove guests and add-ons (including mandatory ones, when the app offers the action), add up to 5 children (the quantity top-up), create a reservation or any record the TC's state needs (a normal one, a group one, one at another location or distribution channel), confirm or cancel a record you created to reach a state. Use a spare record that no other TC of this run reads, one per TC that needs its own state, and never overwrite or delete what another TC of this run needs. A shared setting (required fields, flags, permissions) is changed only when the TC cannot run without it, under the recovery contract of the Feature Flag Check and Permission Toggle references in execute-tests. A TC is `BLOCKED` only when the permission layer denies the action, the app offers no action for it, or a second login is needed that this session cannot open — never because the tester has not prepared the data. Before the action, append `{ "type": "<what>", "parent_id": "<id>", "parent": "existing", "child": "<identifier>", "original": { "<field>": "<old value>" }, "teardown": "pending" }` to `seed_records` in `run-state.json`, and log `[Seed] Filled: <record> <field> <old> → <new>.` Teardown puts every original value back.
2. **Run on equivalent data.** A literal in a precondition (a name such as `QA-Search-Guest`, a count such as "30 or more") stands in for a behaviour. When existing records exercise the same behaviour (one guest name that only one card carries, a list long enough that cards are still unrendered), run the TC on them, say in Actual Result what was substituted (`Searched Shannon, the only guest with that name, instead of QA-Search-Guest; 30 accommodations.`), and take the verdict from the Expected Result. `NEEDS REVIEW` only when the substitution leaves part of the Expected Result unproven; name that part.
3. **Never stop the run for data.** Do not ask the tester to edit data mid-run and do not end the turn waiting for it. If a setup action fails, or the permission layer denies it, do not retry it or look for a way around it: mark only the TCs that need it `BLOCKED 🚫 (setup denied: <action>)` or with the failure reason, continue with every other TC, and list each one once under ACTION REQUIRED in the final report with the exact action needed.

**Customers and guests in Reservation Manager.** On a reservation's customer or guests, never look for a `QA-…` name; a name precondition is met with a real customer. KEEP IN SYNC with execute-tests' `references/test-data-setup.md`.
- **Link a customer.** Reservation → Customer details → Customer tab → Change customer (the first click turns the button into "Are you sure?", confirm it) → search a common first name such as `Charlie` or `Frank` → pick any customer in the list. Linking fills the travel party by itself: the head of unit gets name, email and address (completeness 3/3), the other guests get the last name and email (1/3). Confirmed on reservation 1842022 (2026-10-22).
- **Edit the travel party.** Customer details → Travel party: every row has editable First name, Last name, Date of birth (the age fills in by itself) and more. Nothing autosaves: fill in every row the run needs first, then press **Save changes** under the table once for the whole batch (also there: Add guest, Remove guests, Reset). Never save row by row. The mandatory fields are First name and Date of birth (the last name comes from the linked customer); a guest with both filled is complete (green dot on the card, 3/3). Dev can be slow, so wait for `POST /api/v1/reservations/<id>/travelparty` to answer 200 before reading the cards, and do not click Save twice. Removing guests is three clicks within a few seconds of each other (Remove guests, Are you sure?, Confirm — the button falls back after about 5 s) and posts at once.
- Cards list a reservation's guests alphabetically by full name and show the first three, so to make a guest visible on the card give it a first name that sorts before the others (`Alpha`).

For each required entity:
1. Navigate to the relevant list/search page and search for `QA-SEED-<STORY_KEY>-<EntityType>`, by name only where the paragraph above allows it.
2. **Found** → reuse. Log: `[Seed] Reusing existing: <name>.`
3. **Not found → attempt browser creation before blocking:**
   a. Look for a "Create", "Add", "New", or equivalent action button on the page.
   b. Click it and fill all required fields with minimal valid values — infer values from field labels, placeholder text, and the TC preconditions.
   c. Use `QA-SEED-<STORY_KEY>-<EntityType>` as the name/identifier.
   d. Submit the form.
   e. **Created successfully** → reuse the new record. Log: `[Seed] Created: <name>.`
   f. **Creation failed** (form errors, required fields cannot be inferred, insufficient permissions) → log the specific failure reason. Mark only the TCs that depend on this entity as `BLOCKED 🚫 (test data creation failed: <reason>)`. TCs that do NOT depend on this entity continue normally.

**Precondition names a specific status/state value (e.g. "a Quote on hold work order", "1+ archived <entity>", "a cancelled <entity>"):**

**Default and primary action — apply the list's own filter for that value and read the result. Do this before attempting to construct anything.** Most list pages already expose a Status filter, dropdown, or toggle covering exactly the value the precondition names (e.g. the Work Orders page's `Status` filter). Select/apply it the same way a human tester would, then read what comes back — do not treat "I don't have a way to force a fresh record into this state" as equivalent to "no such record exists."

Confirmed necessary (2026-09-15, MXTS-80444 / TC03): a "Quote on hold" precondition was marked `BLOCKED` with the reasoning "no live 'Quote on hold' work order exists," purely because no UI action could drive a *fresh* record into that status. Applying the page's own `Status: On Hold Quote` filter — nothing more than that — showed 227 matching records the whole time. The pipeline never applied the filter at all; it went straight to "can I construct one?" and gave up when that path was hard. Many status values arise only through multi-step business workflows (approvals, quote cycles) that no single UI action reproduces, so filtering the environment's existing data is routinely the only realistic way to satisfy the precondition, not a fallback.

1. Navigate to the relevant list page and apply the filter/search control matching the named value directly (Status dropdown, toggle, saved view — whatever the page exposes for it).
2. Run the **Page-ready wait** (see below) after applying the filter, then re-read the result count — do not read it immediately, and do not trust a momentary "0-0 of 0" (see "Module with zero records" below, the same transient-count trap applies here).
3. **One or more matches found** → use the first matching record directly for the TC. It does not need the `QA-SEED-` prefix — a status precondition is read-only evidence, not an entity the TC edits, so any record already carrying that value is valid. Log: `[Seed] Found existing record via filter <filter>: <identifier> (<n> total matches).`
4. **Filter genuinely returns zero results (confirmed after the wait)** → only now fall back to construction:
   a. **Clear/remove the filter applied in step 1 first** — the generic existence check below searches the list by name, and a base `QA-SEED-` record (which will not yet carry this value, since it hasn't been transitioned) is invisible while the filter is still narrowed to this value. Then get a base record of the required type via steps 1–3 above (reuse or create).
   b. Look for a UI action that moves it into the required value — an "Archive", "Cancel", or equivalent button/menu item, on the list row or in a detail/edit view.
   c. **Action exists and succeeds** → reuse this record as the entity for the TC. Log: `[Seed] Transitioned to <value>: <name>.`
   d. **No such action exists, or it fails** (greyed out, permission error, no control found) → log the specific reason. Mark only the TCs that depend on this value as `BLOCKED 🚫 (test data creation failed: filter <filter> found no matches, and no UI action could set <value> — <reason>)`. Do not reach for a workaround the UI doesn't offer (editing a hidden field, calling an API directly) — a value a real user can't reach through the UI isn't one worth testing against.

**Precondition names a quantity, not just one record (e.g. "enough <entity> to span 2+ pages", "3 or more <entity>"):**
1. Work out the target count from the TC's own wording; if it just says "2+ pages" and the page size is visible on screen, default to page size + 1 (e.g. "10 per page" → 11).
2. **Check the existing count first** — navigate to the relevant list/search page (applying whatever filter the precondition implies, e.g. a status), run the **Page-ready wait** (see below), and only then read the total-record count the list itself displays (the same "Total <entity>: <n>" indicator used elsewhere in this doc) — the same transient "0-0 of 0" trap this document already warns about applies here too; reading the count before the wait completes can undercount and trigger unnecessary creation. If the environment already has ≥ target records matching the precondition → skip creation entirely, reuse the existing set. Log: `[Seed] Existing records already satisfy volume: <n>/<target> <EntityType> found via filter.`
3. **Shortfall of more than 5 → do not build, and do not open "Add" dialogs to see whether it could be done:** if Equivalent data (above) applies, run on what exists; otherwise go straight to step 5's `BLOCKED`. **Shortfall of 5 or fewer** → **if the records are children of an existing parent this run did not create or seed** (accommodations in a reservation a tester named, rows in someone's contract), follow **Top-up inside an existing parent** below; **otherwise clear/remove the filter from step 2 first** — reusing/searching for `QA-SEED-<STORY_KEY>-<EntityType>-N` records while that filter is still active hides any that exist but don't currently carry the filtered value, risking a duplicate create. With the filter cleared, make up the shortfall only, using `QA-SEED-<STORY_KEY>-<EntityType>-1`, `-2`, … as each new record's name — reuse any QA-SEED ones that already exist under that pattern before creating more.
4. **Reapply the filter from step 2 and recount** before declaring the target reached — if the precondition's filter is itself a state (e.g. "10+ archived `<entity>`"), a freshly created or reused `QA-SEED-N` record only counts once it actually carries that value; recounting against the same filter catches a shortfall the raw creation count would miss. **Target count reached** (organic + QA-SEED, confirmed under the filter) → reuse the full set for the TC. Log: `[Seed] Volume ready: <n>/<target> <EntityType> records.`
5. **Target count not reached** — creation started failing partway, or bulk creation is impractical this way (never create more than 5 records) — log how many were actually available/created. Mark only the TCs that depend on this volume as `BLOCKED 🚫 (test data creation failed: only <n>/<target> <EntityType> records available)`. Never test the scenario against fewer records than it requires and report PASS/FAIL anyway — an under-filled precondition proves nothing either way — unless the existing records exercise the same behaviour (Equivalent data above), which is a run on substituted data, not a shortfall.

**Top-up inside an existing parent (shortfall of 5 or fewer).** Adding children to a record this run did not create is allowed only as this top-up, and only when all of these hold: the parent is the record the precondition or the tester names (found by its number or search, never by browsing); the Host Guard passed (dev/test host); the additions are children of the type the precondition counts; nothing else changes — never edit, remove or reorder an existing child, never change a field of the parent. Confirmed necessary (2026-10-22, MXTS-79611): a reservation with 27 accommodations was left at `NEEDS REVIEW` for a "30 or more" precondition because this rule used to forbid adding the last 3. KEEP IN SYNC with execute-tests' `references/test-data-setup.md`.
1. Add exactly the shortfall through the app's own add flow (accommodations: Add accommodation → accommodation search → a type and unit free for the parent's dates).
2. Right after each child is added, append it to `seed_records` in `run-state.json`: `{ "type": "<EntityType>", "parent_id": "<id>", "parent": "existing", "child": "<identifier>", "added_at": "<ISO>", "teardown": "pending" }`. A resumed run recounts first and reuses these children instead of adding again.
3. Recount under the filter from step 2 and log `[Seed] Topped up existing <parent> <id>: <before> → <after>/<target> <EntityType> (+<n> added by this run).`
4. Every TC that depends on the volume says in its Actual Result: `<Parent> had <before> <EntityType>; this run added <n> to reach <target>.`
5. Teardown after the story deletes exactly the children listed in `seed_records` for that parent and nothing else, then sets `teardown` to `done` or `failed`. A failure never fails the run; list the parent and the child identifiers under ACTION REQUIRED in the final report.
6. An add that fails partway (no availability, permission, error) → log the reason and keep what was added in `seed_records` for teardown. The TCs that need the volume are `BLOCKED 🚫` per step 5 with `only <n>/<target>`.

**Precondition names a combination of attributes together on one record, not a plain entity, a single status, or a count (e.g. "two fully-booked accommodation types with a reservation pair of differing stay lengths," "an allotment reservation on a fully-booked accommodation," "a reservation with a child/addition reserved resource attached," "a reserved resource with a quantity other than 1 on a fully-booked type"):**

The existence/status/quantity procedures above don't fit here — this needs one record satisfying several conditions *at once*, not "does a record exist" or "how many."

**0. Fixture Cache — check before searching (this is what makes the expensive search below a one-time cost across the whole team, not a per-ticket one).** Confirmed necessary (recurring QA feedback, Sep 2026 — a rare combination like allotment+fully-booked can require checking multiple environments/resorts to find at all; re-doing that search from scratch on every ticket that happens to need the same shape is the actual cost driver behind repeated BLOCKED verdicts, not the search technique itself, which the steps below already fixed). Shape keys are the four combination attributes named above: `allotment_on_fully_booked`, `child_addition_resource`, `differing_stay_lengths`, `resource_quantity_not_1`.

- **Load:** read `test-output/fixture-cache.json` (shared across all Epics/tickets, same top-level scope as `nav-cache.json` — not per-Epic). Missing/corrupt → empty cache, no error.
- **Lookup:** `fixture_cache[<hostname>][<shape-key>]` present and `last_verified` ≤ 30 days ago → navigate to the cached `identifier` and **re-confirm the specific attribute still holds** (fully-booked status, allotment linkage, etc. can change between runs — never trust a cached fixture blindly). **Still holds** → reuse directly for the TC(s) needing this shape — **skip steps 1 through 5 below entirely for this shape**, there is nothing left to search for or construct, and **write this same entry back with `last_verified` refreshed to today** (see Write below) — each successful reuse extends its own life instead of the fixture expiring 30 days after its first verification regardless of how often it's confirmed still valid. Log `[FixtureCache] Hit — reusing cached fixture for <shape-key>: <identifier> (verified <date>).` **No longer holds, or stale (> 30 days)** → fall through to step 1, overwrite the entry once step 1 (search) or step 2 (construct) finds/creates a fresh one.
- **Miss** → proceed to step 1 as normal.
- **Write** — three cases all go through the same merge: (a) a cache hit whose re-confirmation succeeded (refresh `last_verified` only), (b) step 1's search found a fresh match, (c) step 2's construction created one (never for allotment — step 3 is explicit that allotment can't be constructed, so there is no write to trigger from that path; an allotment fixture only ever enters the cache via step 1's search). Merge `{ identifier, attributes: "<one-line description of what makes it match>", last_verified: today, source_ticket: "<STORY_KEY>" }` into `fixture_cache[<hostname>][<shape-key>]`. **Same lock/read-merge-write mechanics as the Navigation Cache section's Write procedure above** (`test-output/fixture-cache.lock/` as the atomic directory lock, 15s staleness, give up after ~10s and skip this run's write rather than risk another session's entry) — reuse that exact procedure, substituting `fixture-cache.json`/`fixture-cache.lock` for `nav-cache.json`/`nav-cache.lock`. Cap at 200 entries per hostname (unlikely to fill, only 4 shape keys exist today; evict oldest `last_verified` first if it somehow does).

1. **Search using the attribute's own dedicated UI marker, not a blind scan of reservations.** Confirmed on Front Office Manager's Planning Chart (2026-09-18, MXTS-80015): each attribute below has a specific, fast place to look — checking it first is what makes the search step actually work, the same way the Status-filter miss on MXTS-80444 was a search-technique gap, not a data gap.
   - **Allotment:** channel-contracted (allotment) reservations often show the **distribution channel/tour-operator name printed directly on the reservation bar in place of a guest name** (e.g. "LA FRANCE DU NORD AU SUD LIN CTV") — confirmed on Etoile d'Argens/Cottage 6p 3Bdrms AirCon **** (MXTS-80015, san-dev, 2026-09-18) — scan for a channel-name bar before opening anything. Confirm via the **Booking summary** panel (click the bar): `Booking category` — any value other than `Free Sale` (e.g. `Linear`, `Allotment` — the exact label depends on the channel's contract type) is a channel-contracted/allotment booking. Before scanning bars one by one, check the Planning Chart's own **⋮ menu → Allotment overview** report first — it's a grid of accommodation type × date showing `Allotments total / booked / free`; any date/type cell with `Allotments booked` > 0 is a candidate to shortlist, then confirm on the chart itself whether the type is also fully booked that day.
   - **Child/addition reserved resource (e.g. a pet, a cot):** these render as a small icon directly on the reservation's bar in the Planning Chart (e.g. a paw icon for a pet) — scan bars visually for an icon before opening any of them; the Booking summary panel's guest/resource line itemizes the exact addition and its quantity once opened.
   - **Differing stay lengths / resource quantity ≠ 1:** no dedicated report — filter by accommodation type + date range as usual, then inspect each candidate's Booking summary (stay dates; guest/resource counts) for the specific attribute.
   Never construct before confirming the combination isn't already present.
2. **Not found → construct only for attributes the app's own booking UI actually sets** — a differing-length stay or a resource quantity is just a value on the normal reservation/booking form, so build one via that UI the same way a human tester would. **Reuse anchor entities already set up for this story** (e.g. the same fully-booked accommodation-type pair used by other TCs) rather than creating fresh ones. Name it `QA-SEED-<STORY_KEY>-<EntityType>`.
   - **Created** → reuse. Log: `[Seed] Created combination record: <identifier> (<attributes>).`
   - **Creation failed** → log the specific reason. Mark only the TCs that depend on it `BLOCKED 🚫 (test data creation failed: <reason>)`.
3. **Allotment is not constructible this way — do not attempt it.** Confirmed on Front Office Manager (2026-09-18): an allotment reservation draws from a distribution-channel contract's pre-agreed allocation (the same `Allotments total/booked/free` pool from the report above), not from the general reservable pool a normal booking uses — there is no "make this booking an allotment booking" toggle on the reservation form itself. If the search step above finds no existing allotment reservation matching the precondition, mark it `BLOCKED 🚫 (test data creation failed: no existing allotment reservation found on this environment — allotment bookings are channel-contract-bound and cannot be constructed via the reservation UI)` rather than attempting construction. **Check other environments/resorts before giving up** — an allotment + fully-booked combination is contract- and season-specific, so its presence varies by environment; a resort with no match on one environment (e.g. the shared Acceptance env) may have it on another (e.g. a dev environment carrying the same anonymized resort data) — confirmed: Etoile d'Argens' `Cottage 6p 3Bdrms AirCon ****` had no simultaneous fully-booked+allotment day on san-test's Aloha resort, but did on san-dev's own copy of Etoile d'Argens (2026-09-18, ~86-100% occupancy with `Allotments booked` 5-6 of 7, distribution channel "LA FRANCE DU NORD AU SUD LIN CTV", late Sep 2026).
4. **Reasonable-step cap (for the constructible attributes in step 2):** if satisfying the combination needs an entire additional scenario beyond what's already in play — e.g. fully booking every unit of a second resort's accommodation type from scratch — rather than a bounded number of actions on data already set up, do not attempt it. Mark `BLOCKED 🚫 (test data creation failed: precondition requires a broader scenario than one record — <reason>)`. This is a scope limit, not a bug.
5. **Shared settings** (feature flags, global config) affect every other user of the environment. Change one for a combination precondition only when the TC cannot run without it and only under the recovery contract in Small setup gaps above (record the original, restore it at teardown, list the net change in the final report). Feature Flag Setup above is the separate, already-handled case.

**Module with zero records / page load wait:** Angular list pages display "0-0 of 0" transiently while the data request is in-flight — this is NOT a reliable signal. Before concluding a module has no data:
1. Run the **Page-ready wait** (see below) targeting the list row/table body selector (e.g. `mat-row`, `tr`, `.list-item`) as the content selector.
2. Take a fresh `browser_snapshot` and re-read the count only after the wait completes.
3. Only if the count is still 0 after the wait → apply the browser creation flow (step 3 above).

Do NOT read page counts or page content immediately after `browser_navigate` — always wait for Angular to finish rendering first. Only mark TCs BLOCKED if the creation attempt itself fails.

Log a seed summary: `[Seed] Setup complete — <n> ready, <n> reused, <n> created, <n> failed.`

---

## Feature Flag Setup (Phase 1 lookahead — runs once before the per-TC loop, after Test Data Setup)

*Runs only when `story.feature_flags` (Phase 1, step 3f) is non-empty. This is a cheap head start when the ticket names a flag explicitly — it is NOT the only line of defense. A ticket that never mentions a flag by name still gets full coverage: see Reactive Feature Flag Check below, which is mandatory regardless of this list. (Confirmed necessary, MXTS-80992/TC_08, Sep 2026: the flag gating Home Owner Association — `home.owner.association.enabled` — was never named anywhere in the ticket's description or comments, so this list came back empty, this step never ran, and TC_08 fell through to an untested "could not locate the screen." Closed by the reactive check below, not by this proactive one.)*

**Why this exists:** a missing UI element is genuinely ambiguous between "feature not deployed" and "feature deployed but sitting behind a disabled flag" — those are different problems with different fixes, and guessing "not deployed" from the UI alone (without checking) has produced wrong BLOCKED verdicts in production. Resolving the flag's actual state **before** any TC runs means the BLOCKED vs FAIL table's "Feature not deployed" row (below) can be trusted at TC-execution time — the ambiguity is already closed by then.

For each flag name in `story.feature_flags`:
1. Navigate to Maxxton Admin's feature flag section and search for the flag by name.
2. **Not found in Maxxton Admin** → log a warning: `[FeatureFlag] "<flag>" not found in Maxxton Admin — proceeding without toggling.` The Reactive Feature Flag Check below still runs per-TC regardless.
3. **Found, already enabled** → no action. Log `[FeatureFlag] "<flag>" already enabled — leaving as-is.`
4. **Found, disabled** → **first** append `{ "flag": "<flag>", "host": "<base host>" }` to the top-level `flags_enabled_this_run` array in `run-state.json` and persist to disk, **then** enable it and save, then re-read to confirm (if the enable fails, re-read the flag and remove the entry only when that read confirms it is still OFF — a save can reach the server although its response or the confirming read failed; if the state cannot be read, keep the entry and report the restore need under ACTION REQUIRED). The entry must exist before the toggle — it is the only record that makes the Feature Flag Teardown step (SKILL.md's Final Summary) and the startup restore possible, and a crash between toggle and write would otherwise lose it. Log `[FeatureFlag] "<flag>" was disabled — enabled for this run.`
5. **Enable attempt failed** (no toggle control found, permission error, save didn't take) → log the specific failure reason under `[FeatureFlag]`. Do NOT block the whole story — the Reactive Feature Flag Check below still runs per-TC.

> ⛔ **Restore every flag to the state it was found in — in both directions.** A flag this run switched ON (found disabled) goes in `flags_enabled_this_run` and is switched back OFF at teardown. A flag this run switched OFF (found enabled) goes in `flags_disabled_this_run` and is switched back ON at teardown. Switching a flag OFF is allowed only when a TC explicitly verifies the flag-OFF state (e.g. "Verify legacy behaviour when the flag is OFF"); never disable a flag for any other reason. **Flag state reconciliation** — before every TC that depends on a flag being ON or OFF, bring the flag to the state that TC needs. A flag has at most one entry, recorded as the net change from the state it was found in: in the *enabled* record (found OFF, now ON), in the *disabled* record (found ON, now OFF), or none (untouched). Switch ON: if it is in `flags_disabled_this_run` → switch ON, re-read to confirm, and only then remove it from there (it is back to its original state, no entry); otherwise (found OFF) → add it to `flags_enabled_this_run` and persist **before** the toggle, then switch ON. Switch OFF: if it is in `flags_enabled_this_run` → switch OFF, re-read to confirm, and only then remove it from there (back to original); otherwise (found ON) → add it to `flags_disabled_this_run` and persist **before** the toggle, then switch OFF. Already in the needed state → change nothing and record nothing. After every toggle re-read the flag to confirm it saved; if the switch fails, mark the TC `BLOCKED 🚫 (could not set flag "<flag>" to <ON|OFF>)` — never run a flag-dependent TC against the wrong state. Teardown restores every remaining entry; an entry is removed only after the restored state is verified. **Invocation-wide baseline:** the flag is shared by every Epic of this invocation while these lists are per-Epic, so before recording a change look the flag up, for the same host, in the lists of every Epic processed so far (their `run-state.json`), not just this one: if another Epic's list already holds it, move or remove that entry by the rules above instead of adding a second one, so teardown never applies opposing restores. While either list is non-empty, refresh `flags_heartbeat_at` in `run-state.json` after every toggle and after every TC. **Another active run owns the flag?** Before every toggle, look the flag up (same host) in the other Epics' `run-state.json` files from other sessions too: when a list holding it has a `flags_heartbeat_at` within 30 minutes and does not belong to this invocation, do not flip it — mark the TC `BLOCKED 🚫 (flag "<flag>" is in use by another active run)`; a stale list is restored by the startup restore first.

Log a flag summary: `[FeatureFlag] Setup complete — <n> already enabled, <n> newly enabled, <n> not found, <n> failed.`

---

## Reactive Feature Flag Check (mandatory — runs per-TC, independent of `story.feature_flags`)

**Why this exists (second confirmed miss, MXTS-80992/TC_08, Sep 2026):** the proactive step above only catches flags the ticket names explicitly. A ticket can legitimately never mention a flag at all — MXTS-80992 was a location-search enhancement with zero feature-flag language anywhere in its description or comments, yet the Home Owner Association screen TC_08 needed was gated behind the scenes by `home.owner.association.enabled`. `story.feature_flags` came back empty, Feature Flag Setup skipped entirely, and TC_08 reached "could not locate" without Maxxton Admin ever being checked. This step closes that gap unconditionally — it does not depend on Phase 1 having found anything.

**Trigger:** any TC step where, after confirmed-correct navigation (right menu, right screen, per the TC's own steps), the target element/screen genuinely cannot be found — the moment the verdict is about to become `BLOCKED` ("Feature not deployed") or `FAIL` ("Element not found"). Run this check **before** recording that verdict, not after.

1. Derive keywords (≥4 characters, split on whitespace/case boundaries) from the missing screen/module/entity's own name as the TC states it — e.g. "Home owner association Create/update" → `home`, `owner`, `association`, `homeowner`.
2. Navigate to Maxxton Admin's feature flag section and search/filter using each keyword in turn (case-insensitive substring match against flag names/descriptions).
3. **No match found for any keyword** → log `[FeatureFlag] Reactive check — no matching flag found for "<missing element>"; concluding <verdict> as genuine.` and record the original verdict. The ambiguity is now closed and auditable, not assumed.
4. **Match found, already enabled** → log and record the original verdict — a still-missing element behind an already-enabled flag really is "not deployed."
5. **Match found, disabled** → append to `flags_enabled_this_run` and persist first (persist-before-toggle, same as Feature Flag Setup step 4 above), then enable it now, log `[FeatureFlag] Reactive check found "<flag>" disabled — enabled, retrying TC now.`, then retry this TC's navigation/element lookup **once**. Retry finds the element → continue normal verdict determination (PASS/FAIL on actual behaviour), with a note in Reason: `flag "<flag>" was disabled and enabled during this run`. Retry still doesn't find it → record the original verdict; do not retry a second time.
6. **Enable attempt failed** → log the reason and record the original verdict.

This check runs **once per TC** that hits the trigger condition — never loop across multiple keyword/flag combinations beyond the first match found.

---

**Page-ready wait — canonical procedure, used everywhere this document says "wait for the page to be ready/stable."**

> ⛔ `browser_wait_for` only accepts `text` / `textGone` / `time` — it has **no `selector` or `state`
> parameter**. Waiting on a CSS selector (spinner hidden, content visible) must go through
> `browser_evaluate`, not `browser_wait_for`. (This mismatch — documentation describing a
> selector/state wait that the tool never supported — is the root cause of screenshots being taken
> before the page finished rendering; fixed 2026-07-21.)

Call `browser_evaluate` with a function that polls in-page until loading is done, images have
finished loading, in-flight API/XHR/fetch calls have quieted down, AND the DOM has stopped changing —
not just "spinner gone", which can still fire mid-animation, before an `<img>` has painted, while
API-driven content (search results, lazy sections) is still arriving, or before late/lazy-loaded
content settles:

```js
async () => {
  const spinnerSel = 'mat-progress-spinner, [class*="loading"], [class*="spinner"]';
  const contentSel = 'mat-card, .content-container, main, [role="main"], app-root'; // swap for a list/row selector when waiting on list content specifically
  const deadline = Date.now() + 10000; // 10s max wait
  let lastSize = -1, lastResourceCount = -1, stableTicks = 0;
  while (Date.now() < deadline) {
    const spinnerVisible = Array.from(document.querySelectorAll(spinnerSel)).some(el => el.offsetParent !== null);
    const content = document.querySelector(contentSel);
    const imagesLoaded = Array.from(document.images).every(img => img.complete); // true once loaded OR errored — never hangs on a broken image
    const resourceCount = performance.getEntriesByType('resource').length; // grows as each network request completes — still growing means requests are still landing
    if (!spinnerVisible && content && imagesLoaded) {
      const size = content.innerHTML.length;
      const stable = size === lastSize && resourceCount === lastResourceCount;
      stableTicks = stable ? stableTicks + 1 : 0;
      lastSize = size;
      lastResourceCount = resourceCount;
      if (stableTicks >= 2) {
        await new Promise(r => setTimeout(r, 250)); // let any in-flight CSS transition/fade-in finish painting
        return 'ready';
      }
    } else {
      lastResourceCount = resourceCount;
    }
    await new Promise(r => setTimeout(r, 200));
  }
  return 'timeout';
}
```

- Swap `contentSel` for the relevant content/list selector at each call site.
- Result `'ready'` → proceed. Result `'timeout'` → proceed anyway but treat the page as possibly not
  fully settled (this is what the blank-screenshot retry and BLOCKED fallback elsewhere in this
  document exist for) — do not loop forever.
- This same check is what "wait for spinners to hide, main content to appear" means everywhere below —
  it replaces the old two-call `browser_wait_for` selector pattern with one `browser_evaluate` call.
- Covers the four recurring causes of bad screenshots: (1) the broken selector-wait tool call, fixed
  above; (2) images mid-load (`imagesLoaded` check); (3) API/XHR/fetch calls still landing after the
  initial render — confirmed in production (2026-09-24, Sujata Pimpale on MXTS-77020): the DOM-size
  check alone can go stable while API-driven content is still arriving, especially on MCMS/cms-web
  pages, letting a screenshot (including the MCMS **Before** capture, which fires right after this
  check) land mid-load; the `resourceCount` stability check catches this the same way `lastSize` catches
  DOM churn; (4) CSS transitions/fade-ins still animating after the DOM itself has stopped changing size
  (trailing 250 ms settle).

> ⛔ **The Page-ready wait cannot see a search finish — use the Search Result Wait after ANY search or filter submit (AI search prompt, normal search box, filter Apply)** (e.g. Reservation Manager's "Find reservations in the system" bar). Measured live (SAN dev, 2026-10-06): after submit the page is idle for ~3 s (old `Total reservations`, no chip, no spinner) while the model runs, so the DOM-stability check returns `ready` inside that window and a reload, reset, next repeat run or screenshot lands on the old count. Record the baseline total before submitting (non-zero and stable — a fresh page shows a transient `0`), submit, then poll via `browser_evaluate` until the chip set, the filter URL parameter, a no-match callout or a clarification question appears (never the total alone — dev data is live and the total drifts on its own) AND the total has then been unchanged for ~1 s (5 polls, 60 s ceiling). Never reload, navigate, reset or start the next repeat run before that returns. Full procedure and script: `${CLAUDE_PLUGIN_ROOT}/skills/execute-tests/references/ai-search-result-wait.md`.

Teardown all `QA-SEED-<STORY_KEY>-` entities after all TCs for this story complete, the children a top-up added to an existing parent, and put back the original value of every field a setup step filled (only what is in `seed_records`). Best-effort — never fail the run if teardown fails.

**Test data rules (apply to every write operation during TC execution):**
- **Unique prefix:** Any entity created during a test must be prefixed `QA-AUTO-<STORY_KEY>-<TC_ID>-` (e.g. `QA-AUTO-MXTS-12345-TC05-John Doe`). Prevents "already exists" collisions on re-runs.
- **Best-effort teardown:** After each TC that created data, attempt to delete/archive it before moving on. Log outcome but never fail the TC result if teardown fails.
- **Read-only TCs:** Skip both rules — navigate/search/view tests need no data management.

## Known-Limitation Refresh (mandatory, once per story — runs before the per-TC loop, independent of whether Phase 1 ran this pass)

**Why this exists:** Phase 1's step 3j (see [the Phase 1 context extraction reference](phase-1-context-extraction.md)) only runs when Phase 1 itself runs — but Phase 1 is skipped on resume once `test-output/<EPIC_ID>/` already has a requirement summary. A developer's "NOT implemented" comment can land *after* that first run (confirmed, MXTS-79374), so a story resumed from a later phase would otherwise carry a permanently stale `story.known_limitations` from whenever Phase 1 last actually executed. This step closes that gap unconditionally, the same way the Reactive Feature Flag Check above closes the equivalent gap for `story.feature_flags`.

1. Read this story's comments with `mcp__claude_ai_Atlassian_MCP__executeRead` `listJiraIssueComments` (every page — `getJiraIssue` only reports the comment count) — one read, regardless of whether Phase 1 ran this pass.
2. Re-run step 3j's detection exactly (scan for a developer stating a specific behavior is not implemented, with a technical reason).
3. **Merge, never replace:** add any newly found entries to the persisted `story.known_limitations` (matched by `source_comment_id` to avoid duplicates); entries already in the list from an earlier pass stay untouched even if that comment is no longer the most recent one.
4. Persist the merged list to `run-state.json` immediately. Log: `[Phase 3a] <STORY_KEY> — known-limitation refresh: <n> new, <n> total.`
4a. **Developer QA template refresh:** with the same fetched comments, re-run Phase 1 step 3l (see [the Phase 1 context extraction reference](phase-1-context-extraction.md)) and overwrite `story.dev_qa` with the newest developer "For QA:" comment found (it is a durable fact about the ticket, replaced — not merged — because the newest comment supersedes an older one). Persist it to `run-state.json`. Log: `[Phase 3a] <STORY_KEY> — dev QA template refresh: <found|none>.` Nothing found → leave `story.dev_qa` as it was.
5. **AC-override refresh (use the story's fetched comments; on a resume where Phase 1 was skipped they are not in memory — re-fetch them with the same Jira comment fetch Phase 1 uses before comparing):** re-run step 3k's AC-vs-comment comparison and merge new entries into `story.ac_overrides` (matched by `ac` + `overridden_by`), persisted the same way. For every TC whose Expected Result still follows an overridden AC, rewrite that TC to the overriding behaviour before its loop starts (update the Jira TC comment in place: `update-tc-comment.js` when the comment was created by the script path and `jira_write_path = script`; otherwise `addOrEditJiraIssueComment` with the persisted `tc_comment_id` — same-path rule in [the MCP write path reference](jira-mcp-write-path.md)) — never execute it against the stale AC and report a FAIL. Log: `[Phase 3a] <STORY_KEY> — ac-override refresh: <n> new, <n> TCs corrected.`

## Parallel check (runs once per story, right before the first TC — every run, a `--retest` and a resume too)

Run [the parallel execution reference](parallel-execution.md) now and log its one-line result: `[parallel] plan: …` or `[parallel] sequential run — <reason>`. The planner decides, not your reading of the TCs: write `plan-input.json`, run `parallel-split.js plan`, and do what it says, including the second-login offer when its result names one. A TC that changes the logged-in user's own settings is `user_scoped`; that is no reason to skip this check. Skip it only when `--workers=1` was typed, `--retest` is active (the scoped retest stops at the first failed TC that fails again, which needs the serial order), or the story has `integration_name`. A story whose first TC started without that log line skipped the check by mistake: stop at the current TC, run the check for the TCs that have no verdict yet (they are the plan's scope), and go on.

## Per-TC Execution Loop

For each test case from Phase 2 (max 3 attempts before final verdict):

> ⛔ **Every `browser_evaluate` call is short: at most 60 seconds, and the script bounds itself. Any wait or polling loop inside a script has its own deadline (the Page-ready wait uses 10 s) and returns `'timeout'`, `'pending'` or what it found — it never loops until a condition that may never come true. The per-TC timeout (`--tc-timeout`, default 180 s) is only checked between tool calls, so one runaway call bypasses it and freezes the progress list too (a 19-minute `browser_evaluate` was seen on MXTS-81060, TC_20 setup). A longer wait is repeated short calls — evaluate, decide, evaluate — with the cap counted in wall-clock time.**

**Step 0 — Start the TC timer, then check the session (before every TC):** run `node "$CLAUDE_PLUGIN_ROOT/skills/test-ticket/scripts/run-timing.js" tc-start test-output/<EPIC_ID>/tc-timer.json <TC_ID> --state test-output/<EPIC_ID>/run-state.json --story <STORY_KEY>` once per TC (a retry attempt that calls it again keeps the first start; it also refreshes the heartbeat), then call `browser_snapshot` and inspect the current URL.
- URL contains `/login`, `/auth`, or a login form is present in the DOM → session has expired. See **Session Recovery** below before continuing.
- URL is the base URL or any app page → session active, proceed.

**Step 1 — Navigate.** For navigation steps, apply cache-first strategy (see Navigation Cache section) — use `nav_cache[<hostname>][<route-key>]` before attempting sidebar navigation.

**Step 2 — Wait for page ready (mandatory after every `browser_navigate`, and after every Save/submit action that re-renders the current view in place).** Angular pages render asynchronously — never read page content immediately after navigation, and never read it immediately after clicking Save/submit either, even when no navigation/URL change happens. Run the **Page-ready wait** (see above) before that read. Confirmed live (2026-09-24, MXTS-81144): after saving a form in place (no route change), the panel showing the saved result briefly re-rendered as an empty/loading skeleton before settling to the correct saved content a moment later — reading it during that flash would look identical to "nothing was saved," a false negative with the same shape as the "0-0 of 0" transient-list trap already documented elsewhere in this file, just triggered by a save instead of a navigation.

**Step 2b — Host guard (after every `browser_navigate`, and after every click/submit that changes the URL):** the host in the next `browser_snapshot`'s URL must still be `*-dev.maxxton.net` or `*-test.maxxton.net`. A dev site bound to a production hostname (after a prod→dev sync) can open the live site from a Login button or a redirect — never click, type or submit there. Disallowed host → stop interacting, screenshot what landed, navigate back, record `BLOCKED 🚫 (browser left dev/test — landed on <host>)`, never FAIL. A third-party hop the TC itself names (e.g. a payment provider's test page) is allowed for that named step only. Full rules: [the Host Guard reference](${CLAUDE_PLUGIN_ROOT}/skills/execute-tests/references/host-guard.md).

**Precondition verification (before Step 3, mandatory whenever the TC's precondition asserts a specific data relationship — not just "a record exists"):** Confirmed necessary (MXTS-76681, 2026-08-10) — a TC was executed against a reservation/offer that looked superficially right (an offer, plus an add-on, on the same reservation) but did not actually satisfy the precondition ("an offer that applies to both the Accommodation and the add-on"): the add-on was an unrelated, independently-priced line, not a component of that offer. The resulting screenshots were technically excellent and completely worthless, because they proved a different scenario than the one the TC exists to test.

- If the precondition claims two things are **linked** (e.g. "one offer covering both accommodation and add-on", "an offer that splits into two lines"), do not treat a superficially-matching record as sufficient. Verify the link directly on the record you're about to test: e.g., click the offer's row to check whether it expands into a sub-breakdown, or confirm both the accommodation portion and the add-on portion appear listed together under the same offer name — not as two separate, independently-priced lines that merely coexist on the same reservation.
- **If the first candidate does not actually satisfy the precondition** → do not proceed with it and rationalize whatever it shows as a result. Either find/construct a different record that does satisfy it, or — if that's not reasonably reachable in this session — mark the TC `BLOCKED 🚫 (could not find/construct a record where <the specific precondition> actually holds)`. A test run against unverified data is not evidence either way.
- **Never reinterpret "I tested the wrong data" as a product finding.** Writing an Actual Result like "the offer renders as one aggregated line" when the real issue is that the wrong offer/add-on pair was selected conflates a test-setup miss with a behavioural observation, and produces a verdict (e.g. NEEDS REVIEW) that looks like a real finding but isn't. If precondition verification fails, the row is BLOCKED on setup — it is not a finding about the feature.

**Step 3 — Execute test steps** via Playwright MCP (click, fill, select, press key).

> ⛔ **Search/filter/autocomplete inputs — mandatory, not just "fill".** (Same root cause as `generate-playwright-tests/references/maxxton-angular.md`'s `fill()` Anti-Pattern, applied here to live MCP execution. Confirmed necessary, MXTS-80992/TC_08, Sep 2026 — this exact failure mode produced a false FAIL.)
> 1. **Slow/sequential typing, not plain fill.** Call `browser_type` with `slowly: true` (Playwright's `pressSequentially`) for any search box, filter input, or autocomplete field — MXTS's Angular reactive forms need `keydown`/`keyup`/`input` events to trigger live filtering; plain fill can leave the results list unfiltered with no error, making a real match look like "not found."
> 2. **Clear the field before typing — never assume it's empty.** Click it, press `ControlOrMeta+a` then `Delete`, *then* type. A field can carry leftover text from an earlier attempt; typing without clearing appends onto it instead of replacing it, producing a garbled query that legitimately matches nothing. (Confirmed: MXTS-80992/TC_08 — a location-code search showed "No results found" purely because a prior `fill()` call's leftover text was never cleared before the next attempt concatenated onto it; the feature worked correctly once the field was properly cleared first.)
> 3. **Verify the query text before recording a negative verdict.** Before FAIL/BLOCKED/"no results"/"element not found" is recorded off a search/filter step, re-check that field's own current value via `browser_snapshot`/`browser_find` — confirm it exactly matches the intended query, not a garbled/concatenated string.

> ⛔ **Custom multi-select/dropdown components — never target by a global `id` or generic visible text; disambiguate by position relative to a labeled row instead.** Confirmed live (2026-09-24, MXTS-81144): a form with two `<multi-select>` components on the same page (one for "Bill", one for "reservation status") both rendered their placeholder/default option with the identical, non-unique `id="default.null.option"` — a lookup by that id, or by the visible text "All" alone, silently resolved to the *wrong* component (the first one in DOM order), not the one actually intended. Duplicate/reused ids on repeated custom components are a real, recurring pattern in this codebase's Angular UI, not a one-off. Before interacting with any custom (non-native-`<select>`) dropdown/multi-select on a page that has more than one instance of the same component type: locate it by walking up from (or querying near) the row's own unique label text (e.g. the specific field label, or an adjacent unique `<select>` in the same row like `parameter`/`operation`), not by an id or placeholder text that could be shared across instances. `browser_snapshot`/`browser_evaluate` first to confirm there is exactly one match before clicking, the same discipline Step 3's search-field rule already requires for text input.

> ⛔ **A multi-select showing a default-looking label (e.g. "All") is not evidence a value has actually been selected — a required-but-unset field can silently block Save with no visible error.** Confirmed live (2026-09-24, MXTS-81144): a "reservation status" multi-select displayed "All" by default, with no asterisk or other visible required-field marker distinguishing it from an optional field — but the form's Save button stayed disabled until an explicit status value was actually checked, wasting time re-deriving which field was blocking submission since nothing on screen flagged it as the cause. If Save/submit is unexpectedly disabled after all visibly-required (`*`-marked) fields are filled, do not assume the form is broken or the data is fine as-is — check every multi-select/dropdown on the form for a placeholder default that looks filled but isn't (`browser_evaluate` each one's actual selected-value state, not just its displayed text), and explicitly select a real value in each before concluding Save should be enabled.

**If Step 3 changed price, an addon, or the accommodation type/unit on a reservation:** run [Resource Reindex](resource-reindex.md) before verifying — the search index can lag behind the write and produce a false negative on any check that reads it. Other reservation edits (memo, status, arrival time, etc.) don't touch the resource's index entry — skip this step for those.

**Bill-changing TC (Step 3 saves a change to what a reservation is charged — override rates, add-on, offer/voucher/discount, dates, accommodation, unit, guests, a status that reprices):** record the whole bill, VAT included, before the change and after "Recalculate reservation", and let the diff set the verdict. Confirmed necessary (MXTS-81495, Oct 2026): every check on the MAR line passed while the customer total moved after the recalculation, and only a manual check found it. Follow `${CLAUDE_PLUGIN_ROOT}/skills/execute-tests/references/bill-snapshot.md` — the `before` snapshot and Before screenshot go ahead of the first changing step, the `changed` snapshot right before the recalculation, the `after` snapshot and After screenshot once it is done. The recalculation is the TC's own step (Phase 2 writes it in); a TC without one runs as written. Screenshot names and the Before/After pair: the bill-changing exception in the Screenshot rules below. A parallel worker follows this too; its `screenshots` list carries both halves.

**Step 4 — Determine verdict** (see Verdict Determination below) — take a screenshot for every TC (see Screenshot rules below).

**Step 5 — If verdict is ambiguous** → call `browser_snapshot` for DOM inspection, then re-evaluate.

**Step 6 — Show the user the running table: every TC finished so far, and what is still pending.** After the final verdict is recorded (retries, the screenshot and the `execution-log.json` write done), run `node "$CLAUDE_PLUGIN_ROOT/skills/test-ticket/scripts/run-timing.js" tc-end test-output/<EPIC_ID>/tc-timer.json <TC_ID> --state test-output/<EPIC_ID>/run-state.json --story <STORY_KEY>` — it prints how long the TC took (pauses subtracted; `n/a` when no timer was running) — and print the table as plain text between tool calls. It is cumulative: each time it holds one row per TC finished so far, in the order they finished, so it grows by one row after every TC:

```
| TC | Result | Time taken | Pending |
|---|---|---|---|
| TC_01 | PASS ✅ | 2m 10s | 2 |
| TC_02 | PASS ✅ | 3m | 1 |
```

`Pending` is the number of this run's TCs not finished yet at the moment that row's TC finished (`N` minus the TCs done then, so the column counts down 2, 1, 0; `N` respects `--max-tcs`, and TCs a `--retest` carries over unchanged are not counted). A printed row never changes. For `FAIL ❌`, `BLOCKED 🚫`, `NEEDS REVIEW 🔍` and `SKIP ⏭️` add, under the table, one line per such TC finished so far: `↳ <TC_ID>: <reason in under 15 words>`, e.g. `↳ TC_07: no matching control; checked: reservation, unit, Housekeeping`. Keep these lines under the table, never between rows, so it stays one table. After the last TC the table printed for it is the final one: add one tally line below it, `Phase 3a done — 26 TCs: 20 PASS, 3 FAIL, 2 BLOCKED, 1 NEEDS REVIEW`. One row per TC and only for its final verdict, never one per retry attempt; no file paths; never a customer name or amount from the app; on a multi-URL run put the hostname in front of the TC id (`rcn-dev · TC_01`). The same moment updates the TC count in the progress list. This is narration for the person watching: it never replaces the verdict and log writes and never delays the next TC. KEEP IN SYNC with execute-tests' `references/progress-reporting.md`.

---

**Session Recovery (triggered when login page detected mid-run):**

Do NOT immediately mark all remaining TCs as BLOCKED. Instead:
1. Log: `[Phase 3a] Login page detected after <TC_ID> — attempting session recovery.`
2. Take a screenshot of the login page as evidence.
3. Run `node "$CLAUDE_PLUGIN_ROOT/skills/test-ticket/scripts/run-timing.js" pause-start test-output/<EPIC_ID>/run-state.json <STORY_KEY>` (it stamps when the wait begins), then display to the user: `⚠️ Session expired after <TC_ID>. Please log in again and type "done" to continue, or "stop" to abort.`
4. **User types "done"** → verify session via `browser_snapshot` — session is confirmed only when BOTH conditions hold: URL no longer contains `/login` AND no login form is visible in the DOM (same criteria as Step 0 detection). If only the URL changed but a login form is still present, prompt the user again. Once confirmed, resume from the next TC. Mark the TC that was in-progress as `BLOCKED 🚫 (session expired during execution — re-authenticated, retrying)` and retry it once.
5. **User types "stop"** → mark all remaining TCs `BLOCKED 🚫 (session expired — run aborted by user)`, proceed to Phase 3b with partial results.
6. **No response within 3 minutes** → mark all remaining TCs `BLOCKED 🚫 (session expired — no user response)`, proceed to Phase 3b.
7. **Whichever of 4/5/6 fires** — run `run-timing.js pause-end` (add `--url <hostname of the URL being tested>` on a multi-URL run). It adds the time since `pause-start` to `user_wait_seconds` and 1 to `pause_count` (and to that URL's `user_wait_seconds` / `pauses`), and moves `last_activity_at` to now — no timestamps to type — so the Resume Gap Check never counts this wait a second time. This is what Phase 3b's **Test Execution Timing** row excludes and reports as a pause — time spent blocked on the user re-authenticating is not time spent testing, and must not inflate that figure.

> The old rule "Login fails → stop all remaining TCs immediately" is REMOVED. Session expiry mid-run is recoverable — always attempt recovery first.

**Screenshot rules:**

> ⛔ **Screenshots are ALWAYS taken — unconditionally.** `--skip-specs`, `--auto-specs`, `tc_skip_automation`, and the `Automated` column have zero effect on screenshot capture. Screenshots are proof of the actual result, not a by-product of spec generation. Never skip a screenshot because automation is disabled or specs are not requested.

> ⛔ **Always use `fullPage: true`.** Every `browser_take_screenshot` call MUST include the `fullPage: true` parameter. Viewport-only screenshots cut off content below the fold and miss critical evidence — always capture the full scrollable page.

> ⛔ **`fullPage: true` only captures `document.documentElement.scrollHeight` — it does NOT reach content that scrolls inside a nested container.** The Reservation Manager Finance/Bill details panel (confirmed — MXTS-76681, 2026-08-07) renders its real content inside a fixed-height `overflow-y: auto` div sized off the viewport, while the outer page itself has zero scroll (`documentHeight === viewportHeight`). On this page `fullPage: true` silently captures only the first visible slice of that inner box and permanently misses everything below the fold — no error, no blank-image signal, just a screenshot that looks fine but proves nothing. This was confirmed to be the root cause of screenshots that were cropped before the relevant row AND of multiple TCs on the same story producing byte-identical screenshots (the inner box was never scrolled between captures, so every shot showed the same default slice regardless of which TC ran). **Finance/Bill pages need the Large-Viewport Capture step below — every other page is unaffected and needs no special handling.**

**Pre-screenshot readiness check — run before every `browser_take_screenshot`:**
1. Run the **Page-ready wait** (see above) — this is what confirms spinners are gone AND the content
   area has stopped changing (not just appeared), which is what actually prevents a screenshot from
   catching the page mid-render.
2. If the wait returns `'timeout'` or the page appears blank → wait 1 s, call `browser_snapshot` to verify DOM state, then proceed.

**Large-viewport capture for Finance/Bill pages — scoped to this page type ONLY (mandatory when the TC's observation is on a reservation's Finance/Bill screen):**

Confirmed working approach (MXTS-76681, 2026-08-10): the Finance/Bill panel's internal scroll container is sized relative to the viewport, so simply resizing the browser window bigger before screenshotting eliminates the internal scroll entirely — no DOM manipulation needed. This is the "zoom out" a human gets from a bigger monitor, reproduced via `browser_resize`.

1. **Before screenshotting**, note the current viewport size (so it can be restored), then:
   ```
   browser_resize(width: 1920, height: 2700)
   ```
   1920×2700 is confirmed sufficient for this panel; if a future page still shows remaining scroll (check below), grow the height further rather than falling back to DOM tricks.
2. **Verify zero scroll remains** before capturing:
   ```js
   () => Array.from(document.querySelectorAll('*')).filter(el => {
     const cs = getComputedStyle(el);
     return (cs.overflowY === 'auto' || cs.overflowY === 'scroll') && el.scrollHeight > el.clientHeight + 5;
   }).length
   ```
   Must return `0`. If not, increase the resize height and re-check rather than screenshotting with content still hidden.
3. **Take the screenshot** (`fullPage: true`), saved directly as the TC's own actual result filename (`<TC_ID>-result.png`, or `<TC_ID>-<source-slug>.png` for a comparison-TC source — see the naming rule below) — this now captures Bill details (including VAT and Total/Due amount), Internal Bill, and Instalments in one image, unconditionally, even if the TC's own claim is about only one line in it. A single comprehensive bill screenshot legitimately proves several TCs' claims at once when they concern the same bill state. **This capture *is* the result screenshot — never take a second, separate screenshot for this TC/source at the restored viewport.**
4. **Restore the viewport to its noted size unconditionally** — on a successful capture, on a capture that errors or times out, and after every retry attempt. Every other page/TC in the run must continue at the normal viewport; a failed or retried capture must never leave the shared browser sitting at 1920×2700. This resize is a targeted step for Finance/Bill screenshots only, never a global setting for the run. **If this TC is retried** (a failed capture, or a `FAIL` verdict retry), repeat steps 1–2 (resize + zero-scroll check) again before re-screenshotting — the viewport was just restored to normal in this same step, so a retry that jumps straight to `browser_take_screenshot` without redoing the resize will silently capture the cropped image again.

> ⛔ **Scope this to Finance/Bill pages explicitly.** Do not resize the viewport for any other page — other TCs already work correctly at the normal viewport size and must stay untouched by this step.

A bill-changing TC (see "Exception — bill-changing TCs" below) runs steps 1–4 twice, once for its Before capture and once for its After capture; the viewport is back at its normal size in between, so the After capture repeats the resize and the zero-scroll check.

**Fallback only if a Finance/Bill page still shows remaining scroll after a reasonably large resize** (not expected — not seen in testing, but don't screenshot with hidden content if it happens): expand the container's overflow directly, take the screenshot (same rule as step 3 above — save it directly as the TC's own actual result filename, never a separate generic capture afterward), then restore the overflow immediately after so later TC steps on the same page aren't affected by the layout change:
```js
() => {
  const targets = Array.from(document.querySelectorAll('*')).filter(el => {
    const cs = getComputedStyle(el);
    return (cs.overflowY === 'auto' || cs.overflowY === 'scroll') && el.scrollHeight > el.clientHeight + 5;
  });
  targets.forEach(el => {
    el.dataset.qaOrigStyle = el.getAttribute('style') || '';
    el.style.maxHeight = 'none';
    el.style.height = 'auto';
    el.style.overflow = 'visible';
  });
  return { expandedCount: targets.length };
}
```
Restore after the screenshot:
```js
() => {
  const restored = document.querySelectorAll('[data-qa-orig-style]');
  restored.forEach(el => {
    el.setAttribute('style', el.dataset.qaOrigStyle);
    delete el.dataset.qaOrigStyle;
  });
  return restored.length;
}
```

## Invoice screenshots (comparison TCs whose "invoice" source is a downloaded PDF, not a page)

<!-- ⚠️ MUST KEEP IN SYNC with execute-tests/references/finance-bill-screenshots.md's "Invoice screenshots" section — same conversion procedure. Both skills are self-contained — prompt-based skills cannot import each other's steps at runtime. -->

An invoice is often only reachable as a PDF download (the in-app print/preview icon can be disabled), not a live page — `browser_take_screenshot` cannot capture a downloaded file directly. Convert the relevant PDF page to a PNG instead of skipping the invoice-side screenshot. **Never hardcode `python`/`python3`** — resolve the interpreter first (a bare `python3`/`python` can be the Windows Store's no-op alias stub; see CLAUDE.md → "Invoking Python from shell scripts"):
```bash
resolve_python() {
  local _cand
  for _cand in python3 python "py -3"; do
    if $_cand -c 'import sys; sys.exit(0 if sys.version_info[0] == 3 else 1)' >/dev/null 2>&1; then
      printf '%s\n' "$_cand"; return 0
    fi
  done
  return 1
}

PY=$(resolve_python) || { echo "no Python 3 found (tried python3, python, py -3)" >&2; exit 1; }
read -r -a PY_CMD <<< "$PY"      # split "py -3" into argv; quote on use

"${PY_CMD[@]}" -c "import fitz" 2>/dev/null || "${PY_CMD[@]}" -m pip install --quiet pymupdf

"${PY_CMD[@]}" -c "
import fitz
doc = fitz.open('<downloaded-invoice-path>.pdf')
page = doc[<page_index>]  # 0-indexed
pix = page.get_pixmap(dpi=200)
pix.save('test-output/<STORY_KEY>/<output-filename>')
"
```
`<output-filename>` is `<TC_ID>-invoice.png` for an ordinary comparison TC, or `<TC_ID>-<item-slug>-invoice.png` when the comparison TC is also multi-item (see the naming rule above) — **never the bare `<TC_ID>-invoice.png` for a multi-item TC**, or each item's conversion overwrites the previous item's invoice image on disk. `pymupdf` is pure-Python — no external Poppler binary needed, unlike `pdf2image`. Identify `<page_index>` from the PDF's own text content (e.g. search for "Total des prestations par taux de TVA" / "VAT by rate") rather than guessing the last page.

**Verify the conversion actually succeeded before treating it as done** — a failed `pip install`, an unreadable/corrupt PDF, a wrong `<page_index>`, or a `pix.save` error all leave no `<output-filename>` on disk, with no non-zero exit guaranteed from the inline `python -c` block:
```bash
test -f "test-output/<STORY_KEY>/<output-filename>" || echo "CONVERSION_FAILED"
```
**File missing** (whether from a conversion failure above, or no PDF viewer/text access available at all) → mark that source `BLOCKED 🚫 (invoice source unreachable — PDF conversion failed: <error/reason>)` rather than posting the comparison row without it; the TC's other source(s) still get their own screenshot. **File present** → proceed as normal.

> ⛔ **Never take a screenshot while a loading spinner is visible or before the main content is rendered.** Blank white screenshots (file size < 20 KB) are a sign the page was not ready — discard the file, wait 1 s, and retake once. If the retake is also blank, mark the TC `BLOCKED 🚫 (screenshot blank — page failed to render)` and skip upload.

> ⛔ **A screenshot is mandatory for every TC (and every item of a multi-item TC) — it is never skipped.** Verifying through an API call, the DOM or a snapshot does not replace it, and "capture skipped this run" is not a valid outcome. Call `browser_take_screenshot` even when the verdict is already clear. The `-capture-failed.png` form below is only for a call that was actually made 3 times and errored; its note must read exactly `(screenshot capture failed — 3/3 attempts, <error>)`, and the validators (CHECK 13) reject any other note.

**If the `browser_take_screenshot` call itself errors or times out** (CDP/renderer timeout — distinct from the blank-image case above, where the call succeeds but returns a bad image): wait 2 s and retry, up to 2 retries (3 attempts total). If all 3 attempts fail, do NOT silently drop the row or write a prose substitute like "see evidence note" for the whole comment — that produces a Test Proof cell with no `.png` reference, which `post-comment.js`/`update-comment.js` CHECK 8 exists specifically to catch, and it forces you outside the sanctioned posting path to get a non-compliant body through (never do this — see the `addOrEditJiraIssueComment` prohibition in SKILL.md).

- **MXTS (single screenshot):** per-TC, set `tc_evidence[<TC_ID>] = null` and write the Test Proof cell as literally `<TC_ID>-capture-failed.png (screenshot capture failed — 3/3 attempts, CDP timeout)` — the `.png` token keeps the row spec-compliant while honestly recording that no file exists.
- **MCMS (Before/After pair):** apply this independently to whichever half failed — if Before fails 3/3, set `tc_evidence_before[<TC_ID>] = null` and that half's filename becomes `<TC_ID>-slug-capture-failed-before.png (screenshot capture failed — 3/3 attempts, CDP timeout)`; the After capture still proceeds normally. Same in reverse if After fails. If BOTH halves fail, both get their own `-capture-failed-before.png` / `-capture-failed-after.png` note — never collapse the pair into one shared note, the reader must still be able to tell which half is missing.
- **Multi-item / Comparison TCs (2+ named entries):** apply independently to whichever named entry failed — set `tc_evidence[<TC_ID>-<slug>] = null` and that entry's filename becomes `<TC_ID>-<slug>-capture-failed.png (screenshot capture failed — 3/3 attempts, CDP timeout)`; every other entry still proceeds normally. Never let one entry's capture failure collapse, hide, or block another's — the reader must be able to tell exactly which item/source is missing.

Log `[Evidence] Screenshot capture failed for <TC_ID>` (append `(before)` / `(after)` for MCMS) `after 3 attempts — CDP timeout.` Do NOT block the TC verdict for this — the verdict still comes from the DOM/snapshot observation in Step 4.

**Screenshot is visual proof of the Actual Result — capture whatever you based the Actual Result on.**

The Actual Result column is filled based on what you observed on screen. The screenshot must show that exact observation — the same element or section you looked at to determine the verdict. Ask: *"What did I see that made me write this Actual Result?"* — screenshot that.

On a Finance/Bill page, running **Large-viewport capture** above means `fullPage: true` now captures the entire bill regardless of original viewport position — Bill details, Internal Bill, and Instalments in one image (see that section for the full rule; do not repeat the resize elsewhere). On any other page, `fullPage: true` alone is already sufficient — if that resulting page is very long (> 5 000 px) and the observed element is near the bottom, use `browser_evaluate` to scroll it into view first so it appears near the centre of the capture and is easy to locate in Jira:
```js
document.querySelector('<selector-of-observed-element>').scrollIntoView({ block: 'center', behavior: 'auto' })
```

**Also check for a row-level expand affordance before screenshotting** (Finance/Bill pages). Some offer/rate rows in Bill details are themselves expandable (a chevron control that reveals a nested per-period breakdown table underneath — e.g. an "Early booking discount" row splitting into two date-range sub-lines). This is a genuine UI feature, not the same thing as the large-viewport fix above. Before screenshotting: `browser_snapshot` (or visual inspection) the row your TC concerns — if it exposes an expand/chevron control, click it first so the breakdown is visible in the capture. If clicking the row does nothing (no new rows appear, only a selection highlight), that offer genuinely has no sub-breakdown on this reservation — that is a valid finding, not a missed step; do not force one.

Examples:
| Actual Result written as… | Screenshot must show… |
|---|---|
| "Instalment table shows updated amount" | the instalment table |
| "Error message displayed under the field" | the error message |
| "Success banner appeared" | the success banner |
| "Record now visible in the list" | the list with that record |
| "Page did not navigate / stayed on same screen" | the current page state |

If the observed element cannot be located with a selector, call `browser_snapshot` first to find it in the DOM, then screenshot.

> ⛔ Do NOT screenshot the element you last clicked or interacted with if your Actual Result observation was of a different element. The screenshot is evidence of what you saw — not what you did.

**Default — an ordinary MXTS, single-item TC: one screenshot, taken once, after ALL test steps (Step 3) are complete, immediately before writing the verdict.** Never call `browser_take_screenshot` during Steps 1–3, regardless of how significant an intermediate action is. If a TC involves setup actions (e.g. save a record, then re-open a wizard), execute all of them first, then take the single result screenshot that proves the final expected outcome. The MCMS, multi-item, comparison, two-state and bill-changing exceptions immediately below are the only sanctioned deviations from this default — they are authoritative over it, not overridden by it.

> ⛔ **Never take mid-TC screenshots on an ordinary single-item MXTS TC.** No "setup" shots, no "before the last step" shots, no "just to confirm I clicked" shots. One shot per TC in that default case — that is the only file that gets uploaded and referenced in Jira. (This does not apply to the MCMS Before capture, a multi-item TC's per-item shots or a bill-changing TC's Before/After pair below — those are required, not "mid-TC" in the sense this rule means.)

> ⛔ **Exception — MCMS runs (`target_repo == mcms-qa-automation`, i.e. the base URL's hostname contains `cms`): TWO screenshots per TC, not one.** Immediately after Step 2 (page ready, on the starting state) and before Step 3 begins, take a **Before** screenshot of the state the TC is about to act on — same readiness checks, same `fullPage: true` rule as any other screenshot. Then proceed with Step 3 and Step 4 exactly as normal, taking the existing **After** screenshot once all test steps are complete. This does not apply to MXTS runs, which keep the single after-only screenshot described above.

> ⛔ **Exception — multi-item TCs: one screenshot per item actually verified, never a single sample standing in for the rest.** Confirmed necessary (MXTS-79434, 2026-09-16): TC_12's own scenario named three specific remaining languages to verify ("Spanish, Italian, English (US)"), but only one was tested and screenshotted — the TC still recorded `PASS ✅` with the single Spanish screenshot as if all three had been checked. A TC whose Scenario or Expected Result names **2 or more discrete items to verify individually** (e.g. "each remaining supported language: Spanish, Italian, English (US)", "every user role", "each of the three environments") is a multi-item TC:
>
> 1. **Execute and observe every named item, not a subset.** Never test one item and generalize "no defect" to the others — a defect specific to Italian's translation, for example, would be invisible if only Spanish were checked.
> 2. **Take one screenshot per item**, immediately after that item's own observation (same readiness checks and `fullPage: true` rule as any other screenshot) — not one combined screenshot for the whole TC.
> 3. **If time/session constraints mean not every named item can actually be tested this run**, do not mark PASS on the strength of the items that were checked. Record `NEEDS REVIEW 🔍` and say exactly which items were verified and which were not in the Actual Result — this is an incomplete-coverage case, the same honest signal `NEEDS REVIEW` already exists for.
> 4. **If any one item fails while others pass**, the TC's overall verdict is `FAIL ❌` (the Expected Result requires all named items to hold) — still capture and keep the screenshot for every item that was checked, passing or failing, as evidence of what was and wasn't covered.
>
> This is additive to the MCMS Before/After exception above — an MCMS multi-item TC takes a Before/After pair *per item*, not a single pair for the whole TC.

> ⛔ **Exception — two-state TCs: one screenshot per state the Expected Result needs to see.** When the Expected Result can only be proven by two states (a switch between two views or modes such as Cards and Table, a choice that must survive a reload or leaving the page, a before and after of a delete or save, an element that must stay visible while scrolling) or is a negative assertion (positive state first, see the Positive-control rule in [the Evidence Review reference](../../execute-tests/references/evidence-review.md)), treat the states as the items of a multi-item TC: `<TC_ID>-<state-slug>.png` for each (e.g. `TC_10-cards.png`, `TC_10-table.png`, `TC_16-after-reload.png`), with the same readiness checks, `fullPage: true` rule and Test Proof format as any multi-item TC. One end-state shot is not enough: the Evidence Review sends that PASS back to `NEEDS REVIEW`. KEEP IN SYNC with execute-tests' Step 3h.

> ⛔ **Exception — comparison TCs: one screenshot per source being compared, each showing the specific value read, never a single end-state screenshot standing in for both.** Confirmed necessary (MXTS-78484, Sep 2026 — QA feedback: TC_01's "Total VAT per rate match the invoice's VAT-by-rate summary" PASS carried only a single small screenshot that showed neither the VAT rate nor the invoice, so the PASS wasn't actually demonstrated). A TC whose Scenario or Expected Result requires reading a value from one screen/document and checking it against the same (or a derived) value on a **different** screen/document — e.g. "the Reservation Manager's Total VAT per rate match the invoice's VAT-by-rate summary", "the list total matches the detail total" — is a comparison TC:
>
> 1. **Screenshot each source separately**, with the specific compared value clearly visible in frame — scroll/zoom it into view (same technique as the Finance/Bill large-viewport rule above); a thumbnail that only shows a pass/fail icon is not evidence.
> 2. **State the literal value read from each source in the Actual Result**, not just "confirmed match" (e.g. "RM widget: EUR 5,311.08; Invoice: EUR 5,311.08 — match") — the comment itself must be evidence, not only the screenshots.
> 3. **Values don't match** → `FAIL ❌`, still capture and keep both screenshots.
>
> This is additive to the MCMS Before/After and multi-item exceptions above — a comparison TC that is also multi-item takes one pair of source screenshots per item, **and states every item's own pair of values in the Actual Result** (e.g. "Spanish — widget: 5,311.08, invoice: 5,311.08, match. Italian — widget: 128.10, invoice: 128.08, mismatch.") — never collapse multiple items' values down to a single pair as if only one item existed.

> ⛔ **Exception — bill-changing TCs (MXTS): a Before/After pair instead of one result screenshot.** A TC that saves a change to what a reservation is charged takes a **Before** capture ahead of the first changing step and an **After** capture once "Recalculate reservation" is done — both the Finance/Bill large-viewport capture. When it applies, how the snapshots behind the pair are taken and how the diff sets the verdict: `${CLAUDE_PLUGIN_ROOT}/skills/execute-tests/references/bill-snapshot.md`. **Everything this section says about the MCMS Before/After pair applies to it unchanged:** the names `<TC_ID>-<slug>-before.png` / `-after.png`, the duplicate-screenshot ids `<TC_ID>-before` / `<TC_ID>-after`, the uploads stored as `tc_evidence_before[<TC_ID>]` / `tc_evidence_after[<TC_ID>]`, the per-half capture-failed and upload-failed notes, and the Test Proof pair format. Reservation Manager is MXTS, so this is the one case where an MXTS run takes a before screenshot. A bill-changing TC that is also multi-item takes one pair per item, named like the MCMS multi-item pair. The Actual Result carries the diff's `summary` lines (`Before to after: …. Recalculation alone: ….`).

Name it `<TC_ID>-<slug>.png` where `slug` is derived from the TC scenario text: take the 3–4 key words, lowercase, hyphen-separated (e.g. scenario "Verify translate button is visible" → `TC_02-translate-button-visible.png`; "Verify error is shown when field is empty" → `TC_05-error-field-empty.png`). **MCMS runs** name the pair `<TC_ID>-<slug>-before.png` and `<TC_ID>-<slug>-after.png` (e.g. `TC_02-translate-button-visible-before.png` / `-after.png`) — the suffix is mandatory so the two files never collide and Phase 3b can address each half independently. **Multi-item TCs (MXTS)** name each item's file `<TC_ID>-<item-slug>.png`, where `item-slug` is the item's own name lowercased/hyphenated (e.g. TC_12's three languages → `TC_12-spanish.png`, `TC_12-italian.png`, `TC_12-english-us.png`). **Multi-item TCs on MCMS** need a Before/After pair *per item* (see the exception above) — a single `<TC_ID>-<item-slug>.png` cannot hold both halves, so name them `<TC_ID>-<item-slug>-before.png` / `<TC_ID>-<item-slug>-after.png` (e.g. `TC_12-spanish-before.png` / `TC_12-spanish-after.png`), same suffix convention as the plain MCMS pair, just one pair per item instead of one pair for the whole TC. **Comparison TCs** name each source's file `<TC_ID>-<source-slug>.png` (e.g. `TC_01-widget.png`, `TC_01-invoice.png`). **Comparison TCs that are also multi-item** qualify by item too — `<TC_ID>-<item-slug>-<source-slug>.png` (e.g. `TC_12-spanish-widget.png`, `TC_12-spanish-invoice.png`) — same reasoning as the MCMS multi-item pair above: a bare source label collides across items the same way a bare `<TC_ID>` collides across sources. Do not pass a custom path — let the MCP tool use its own default save location; **do not assume that location is the shell tool's current working directory** — see the mandatory resolution step immediately below before treating the returned path as usable. Take this screenshot (this pair, for MCMS; this set, for a multi-item TC; this pair-per-item, for MCMS multi-item) for **every TC** regardless of verdict (PASS, FAIL, BLOCKED, NEEDS REVIEW).

**Resolve and verify the screenshot path is shell-reachable (mandatory, immediately after every `browser_take_screenshot`, before the duplicate-screenshot guard or the `upload-screenshot.js` upload — both are Node scripts invoked via the shell and fail in the same way if the path is wrong). Run this once per captured file — for an MCMS TC that means twice, once for the Before file and once for the After file, each independently:**

The launcher now pins the server's `--output-dir` to `<project root>/.playwright-mcp`, so screenshots land in a known place. The verification below still runs on every capture: the returned path can be relative, and an older installed plugin version has no `--output-dir` at all, in which case the file lands wherever the MCP **server process** happened to launch from — not necessarily the shell tool's working directory. That is what happened on MXTS-78302 (2026-08-11): the tool reported success, `upload-screenshot.js` then failed with `File not found`, and a shell-side search of the whole `C:\` drive still found nothing because the search was scoped wrong, not because the file was unreachable. A human had to supply the real path (`.playwright-mcp\` under the project root) before the upload worked. That hand-off should never be necessary — resolve it yourself:

1. Take `screenshot_path` = the path string `browser_take_screenshot` returned.
2. **Verify it before using it anywhere**: check the file exists from the shell (e.g. `test -f "<screenshot_path>"` in Bash, `Test-Path "<screenshot_path>"` in PowerShell).
3. **If found** → proceed as normal, no further action needed.
4. **If not found** → do not immediately declare failure or hand it to the user. Resolve the real absolute path yourself first:
   - **Define "project root" explicitly** — prefer `git rev-parse --show-toplevel` (same command works in both Bash and PowerShell, since `git` is a native executable) over a bare `pwd`/`Get-Location`, since the shell's cwd can itself be a subdirectory. Fall back to `pwd`/`Get-Location` only if the `git` call fails (not a git repo).
   - **Extract the filename robustly — the returned path may use backslashes on Windows, which Bash's `basename` does not treat as a separator.** Bash: `filename=$(basename "${screenshot_path//\\//}")` (normalize backslashes to forward slashes first, then `basename`). PowerShell: `$filename = Split-Path -Leaf $screenshot_path` (handles both separators natively).
   - Try `<project root>/.playwright-mcp/<filename>` — this is the folder the launcher pins the server's `--output-dir` to, so on a current install it is the answer, not a guess.
   - If still not found, run one targeted filename search **scoped to the project root** (e.g. `find "<project root>" -name "<filename>"` or `Get-ChildItem -Path "<project root>" -Recurse -Filter "<filename>"`) — not an unscoped whole-drive search, which is slow and (per MXTS-78302) can still miss the file if the search root itself was wrong.
   - Once the real path is found, **use that absolute path for every subsequent step this TC** (duplicate guard, upload) and log `[Evidence] Screenshot path resolved: <reported path> was unreachable from the shell, found at <real path>.`
5. **Only if truly not found anywhere in the project tree** → fall back to informing the user with the exact filename and the fact that automatic resolution failed, so they can point you at it (or attach manually) — this is the last resort, not the first response.

**Duplicate-screenshot guard (run immediately after every `browser_take_screenshot`, before upload — once per file):**

```bash
node "$CLAUDE_PLUGIN_ROOT/skills/test-ticket/scripts/check-screenshot-hash.js" \
  "<epic_id>" "<story_key>" "<TC_ID>" "<screenshot_path>"
```

**MCMS (Before/After pair):** the script's collision check is `id !== tcId` — passing the bare `<TC_ID>` for both halves would make them share one ledger key and the filter would always exclude "itself" from its own results, so a byte-identical Before/After pair (nothing visibly changed) would never be flagged. Pass a half-qualified id instead — `<TC_ID>-before` for the Before call, `<TC_ID>-after` for the After call — so the two halves are tracked as distinct ledger entries and a same-TC collision reports correctly, exactly like a cross-TC one:
```bash
node "$CLAUDE_PLUGIN_ROOT/skills/test-ticket/scripts/check-screenshot-hash.js" \
  "<epic_id>" "<story_key>" "<TC_ID>-before" "<before_screenshot_path>"
node "$CLAUDE_PLUGIN_ROOT/skills/test-ticket/scripts/check-screenshot-hash.js" \
  "<epic_id>" "<story_key>" "<TC_ID>-after" "<after_screenshot_path>"
```
No script change needed — `check-screenshot-hash.js` treats the id as an opaque label, so `<TC_ID>-before` / `<TC_ID>-after` work exactly like any other id, including reporting a collision against a different TC's half (e.g. `TC_02-before` colliding with `TC_03-after`).

**MCMS multi-item TCs (2+ items, each with its own Before/After pair):** `<TC_ID>-before` alone is not specific enough — Spanish's Before and Italian's Before would share the same ledger id and each new item would silently overwrite the previous item's hash entry, exactly the same collision the bare `<TC_ID>` fix above exists to prevent. Qualify by item too: `<TC_ID>-<item-slug>-before` / `<TC_ID>-<item-slug>-after` (e.g. `TC_12-spanish-before`, `TC_12-spanish-after`, `TC_12-italian-before`, `TC_12-italian-after`) — one call per half per item, same script, same no-change-needed reasoning.

**Comparison TCs (2+ sources, MXTS):** pass `<TC_ID>-<source-slug>` for each source's own call — same reasoning as the MCMS-half fix above: a bare `<TC_ID>` would make both sources share one ledger key.
```bash
node "$CLAUDE_PLUGIN_ROOT/skills/test-ticket/scripts/check-screenshot-hash.js" \
  "<epic_id>" "<story_key>" "<TC_ID>-widget" "<widget_screenshot_path>"
node "$CLAUDE_PLUGIN_ROOT/skills/test-ticket/scripts/check-screenshot-hash.js" \
  "<epic_id>" "<story_key>" "<TC_ID>-invoice" "<invoice_screenshot_path>"
```
**Comparison TCs that are also multi-item:** qualify by item too, same as MCMS multi-item above — `<TC_ID>-<item-slug>-<source-slug>` (e.g. `TC_12-spanish-widget`, `TC_12-spanish-invoice`, `TC_12-italian-widget`, `TC_12-italian-invoice`) — one call per source per item.

- Exit 0 → hash is new for this story, nothing to do.
- Exit 2 → byte-identical to another entry in this story (stderr lists which id(s) — for MCMS this can be the TC's *own other half*, meaning Before and After show no visible difference, or a different TC's half). This is NOT automatically an error — see Finance/Bill pages guidance above, a shared comprehensive screenshot can legitimately answer more than one TC. But it must never be *silent*: append a short parenthetical to this TC's Test Proof cell noting the shared evidence and why (e.g. `(same as this TC's Before — action produced no visible change)` or `(same bill view as TC_02 — both assertions visible in this screenshot)`). If not expected to share evidence, treat the collision as a real signal the capture is wrong — re-check and retake, do not paper over it.
- Exit 1 → script/IO error (bad args, file missing) — log and continue; do not block the TC verdict on this guard.

**Screenshot upload — script path only (immediately after the duplicate-screenshot guard, if `jira_write_path = script`):**

Run once per file (twice for an MCMS TC — Before, then After — each a separate call with its own path):
```bash
node "$CLAUDE_PLUGIN_ROOT/skills/test-ticket/scripts/upload-screenshot.js" \
  "<story_key>" "<screenshot_path>"
```
- `screenshot_path` = the path verified (or resolved) in the "Resolve and verify the screenshot path" step above — never the raw `browser_take_screenshot` return value unverified
- Credentials are read by the script itself from `~/.claude/settings.json` — **do NOT pass or log the token**
- On success (exit 0): stdout contains the uploaded filename.
  - **MXTS (single screenshot)** — store as `tc_evidence[<TC_ID>]`.
  - **MCMS (Before/After pair)** — store each upload independently as `tc_evidence_before[<TC_ID>]` and `tc_evidence_after[<TC_ID>]`. A failure on one half does not block the other — upload both regardless, then apply the per-half failure handling below to whichever one failed.
  - **Multi-item / Comparison TCs (2+ named entries — items, sources, or an item×source combination)** — store each upload independently as `tc_evidence[<TC_ID>-<slug>]`, using the exact same slug the duplicate-hash guard above used for that entry (`<item-slug>`, `<source-slug>`, or `<item-slug>-<source-slug>` for a multi-item comparison TC). One entry's upload failing never blocks or skips the others — upload every named entry regardless, then apply the per-entry failure handling below to whichever ones failed.
- On failure (exit 1): log `[Evidence] Upload failed for <TC_ID>` (append `(before)` / `(after)` for MCMS, or `(<slug>)` for a multi-item/comparison entry) `— <stderr>`. Set the corresponding variable (`tc_evidence[<TC_ID>]`, `tc_evidence_before[<TC_ID>]` / `tc_evidence_after[<TC_ID>]`, or `tc_evidence[<TC_ID>-<slug>]`) to `null`. **Do NOT block or retry the TC verdict.**

If `jira_write_path = mcp` or `screenshot_upload_enabled = false`: skip the per-TC upload step entirely (on the MCP path every screenshot is uploaded once, in Phase 3b Step 1 — see [the MCP write path reference](jira-mcp-write-path.md)). **The duplicate-screenshot guard still runs** — it hashes the local screenshot file and has nothing to do with Jira upload; skipping it here would defeat its own purpose (catching a silent capture bug) precisely when screenshots are only reachable via manual attachment from the working directory. Store `tc_evidence[<TC_ID>] = null` (MXTS), `tc_evidence_before[<TC_ID>] = null` and `tc_evidence_after[<TC_ID>] = null` (MCMS), or `tc_evidence[<TC_ID>-<slug>] = null` for every named entry (multi-item/comparison) — Phase 3b then resolves each entry: a file that was uploaded (script path here, or MCP path in Phase 3b Step 1) becomes an inline image, anything else its plain filename.

**Cleanup after all TCs for the story complete:** Delete every screenshot that is NOT a named result screenshot (`TC_01-<slug>.png`, `TC_02-<slug>.png`, etc. — or, for MCMS, `TC_01-<slug>-before.png` / `TC_01-<slug>-after.png`) — specifically any auto-saved screenshots, retry captures, or intermediate navigation screenshots. Only the per-TC result screenshots are kept; these are the exact filenames referenced in the Jira Test Proof column. **This allowlist must match whatever this story's TCs actually named their result files** — an MCMS story's kept files end in `-before.png` / `-after.png`, not the bare `-<slug>.png` an MXTS story uses (and so do the files of an MXTS bill-changing TC); deleting them here would leave the Test Proof cell pointing at a file that no longer exists.

**No before-screenshots — MXTS only, except for bill-changing TCs.** Do not take `TC_ID-before.png` at any point on an MXTS run, other than the Before capture of a bill-changing TC (its exception above). This is superseded by the explicit MCMS exception earlier in this section ("Exception — MCMS runs... TWO screenshots per TC") — an MCMS run takes both `<TC_ID>-<slug>-before.png` and `<TC_ID>-<slug>-after.png` by design; this blanket rule applies once `target_repo` has resolved to `mxts-qa-automation`, not before it, and never to `mcms-qa-automation`.

**`browser_snapshot` rule:** `browser_snapshot` is slow on complex Angular pages (~2s). Only call it when the result screenshot alone cannot determine the verdict — e.g. expected element is off-screen, or the page looks identical between pass and fail states. For the majority of TCs (element visible / not visible), the screenshot is sufficient. Do NOT call `browser_snapshot` by default after every TC.

## Completeness Gate (mandatory, after the last TC — before Phase 3b)

Before this story exits Phase 3a, verify 100% coverage of the Phase 2 TC table:

1. Re-read the Phase 2 TC table for this story from Jira — the `Test Cases — <STORY_KEY>` comment, or, when an earlier cycle already merged its results into it (first line `QA Test Results`, 12 columns), that same comment: its first ten columns are the TC table, and `Actual result`/`Status` there belong to the earlier cycle — (not from memory or the running count; a Test Cases comment split into parts (more than 45 TCs — see [the split results reference](phase-3b-split-results.md)) is several comments: read every part (`Part 1 of m` … `Part m of m`) and merge their TC rows; a part missing from Jira means the comment is incomplete, not found) and list every `TC_ID` it contains — in the main table and in the **Extended cases added after Human review** table when the comment has one.
2. Cross-check against `results.md` / in-memory verdicts for this run — every `TC_ID` from step 1 must have a recorded verdict. Exception: if `--max-tcs=N` was passed, TCs beyond the top-N cap are expected to be missing — they are not gaps.
3. **Any `TC_ID` present in the table but missing a verdict** → execute it now, following the Per-TC Execution Loop above, before continuing to Phase 3b. Do not defer it, and do not report the story as complete until it has a verdict.
4. **Multi-URL stories (see Multi-URL execution in SKILL.md):** run steps 1–3 separately for each URL, against that URL's own `results_<hostname>.md`. A TC verdict recorded on URL 1 does not satisfy the check for URL 2 — each environment gets its own independent coverage check.
5. **Any `TC_ID` currently verdict `BLOCKED` for "not deployed"/"could not locate"** → before this story exits Phase 3a, confirm the Reactive Feature Flag Check actually ran for it (a `[FeatureFlag] Reactive check` log line naming that TC's missing element). No such line → run it now before finalizing. This is the last checkpoint before Phase 3b posts results — a TC must never reach Jira as "not deployed" without this check having actually executed, whether or not `story.feature_flags` was populated back in Phase 1.

Log: `[Phase 3a] <STORY_KEY> completeness check — <n>/<n> TCs verified, 0 missing.` or, if gaps were found and closed: `[Phase 3a] <STORY_KEY> — <n> TC(s) were missing a verdict (re-parsed and executed): <TC_IDs>.`

> **Why this exists:** the Phase 2 TC table can run long — multiple functional areas, 20+ rows — which is exactly the shape most likely to get silently under-parsed on the first pass. Re-checking mechanically against the source table here, instead of trusting the count carried over from earlier in the run, catches dropped TCs and closes them automatically instead of surfacing only when a human asks "are you sure you got everything?"

## Evidence Review (after the Completeness Gate, before Phase 3b — skipped by `--skip-review`)

Hand every `High`-risk TC that finished `PASS` (one batched call, max 15 TCs) to a fresh reviewer subagent that sees only the TC text and its screenshots, never your reasoning. It can only downgrade a PASS to `NEEDS REVIEW` — a control the TC names that is not in the image, an empty result taken as proof of a hide, a last screenshot that stops before the outcome, a screenshot showing logs or a token. A reviewer that errors or returns something unparseable leaves the PASS untouched and is reported under ACTION REQUIRED (`Evidence review did not run for <TC_IDs>`) — never counted as a pass. Downgrades are written to `results.md` and `execution-log.json` immediately, like any verdict. Packet format, the reviewer prompt, and failure handling: [the Evidence Review reference](${CLAUDE_PLUGIN_ROOT}/skills/execute-tests/references/evidence-review.md). Call `run-metrics.js phase "test-output/<EPIC_ID>" evidence-review` before it starts.

## BLOCKED vs FAIL — Strict Definitions

| Situation | Verdict |
|---|---|
| Login fails at Phase 3a start (initial session check) | `BLOCKED` — ask user to log in, wait, retry |
| Session lost mid-run (login page detected during TC) | Trigger Session Recovery flow — do NOT stop remaining TCs |
| Page returns 404 / 500 / blank | `BLOCKED` — environment dependency |
| Browser navigated to a host that is not `*-dev` / `*-test` (a Login button or redirect opened production, or an unnamed third-party site) | `BLOCKED` — `browser left dev/test`, see Step 2b Host guard above. Never `FAIL`; never retry the click. |
| Required entity missing AND browser creation attempt failed | `BLOCKED` — creation failed (see reason in log) |
| TC needs a user WITHOUT a permission ("not able to ... without the <X> permission") and the tester only has Maxxton Admin | Never `BLOCKED` for "no restricted user" — disable the permission on the Maxxton Admin role, re-login, prove the restriction is effective, run the TC, then restore it, always. Full procedure (verified mechanics, 3-click save, restore marker): `${CLAUDE_PLUGIN_ROOT}/skills/execute-tests/references/permission-toggle.md` |
| Feature not deployed in this environment | `BLOCKED` — deployment dependency. Only reach this conclusion after the Reactive Feature Flag Check (above) has run for the missing element — that check is mandatory regardless of whether `story.feature_flags` was populated in Phase 1, so a still-missing element after it genuinely means "not deployed", not "disabled behind an unnamed flag". |
| Precondition asserts a data relationship (e.g. "offer applies to both X and Y") that the candidate record doesn't actually have, on verification | `BLOCKED` — setup doesn't match precondition, see Precondition verification above. Never write the mismatch up as a behavioural finding. |
| Ticket-level precondition not confirmed (see Precondition Evidence Check above) | `BLOCKED` — dependency/fix not confirmed deployed to this environment. Applies to every TC in the story, not just one. |
| TC step requires verifying data on a third-party client portal (Booking.com Extranet, Airbnb Developer Portal, etc.) | `BLOCKED` — permanent scope boundary, see Integration Manager Setup above. Never retry, never `NEEDS REVIEW` — manual QA only. |
| Domain-specific action step (e.g. "trigger a bill refresh/recalculation") has no matching UI control **after Control Discovery** | `BLOCKED` — precondition step could not be performed, see Step Interpretation above |
| Step executes but outcome is wrong | `FAIL` |
| Element not found after correct navigation | `FAIL` |

**Dependency model:**
- **Session lost mid-run** → trigger Session Recovery flow (see Per-TC Execution Loop above). Do NOT mass-block remaining TCs — they may resume after re-auth.
- **Setup TC in functional area fails** → next TC in same area that depends on the created entity → `BLOCKED ("Depends on <TC_ID> which failed")`. Independent areas continue normally.

## Verdict Determination

Extract the expected result text from the TC row. Apply these rules in order:

| Check | Verdict |
|---|---|
| Rendered message text matches the **raw translation-key pattern** below (any TC whose Expected Result names specific message copy — success banner, error toast, validation message, confirmation dialog, etc.) | `FAIL` — translation missing, confirmed defect (checked before the presence check below) |
| Expected text/element is **clearly present** in the snapshot | `PASS` |
| Expected text/element is **clearly absent**, absence is unambiguous, **AND the actual behavior exactly matches an entry in `story.known_limitations`** (Phase 1, step 3j) | `SKIP` — see Known-Limitation Check below; checked before the plain-FAIL row |
| Expected text/element is **clearly absent** and absence is unambiguous (no known-limitation match) | `FAIL` — trigger retry; on the final attempt run the Missing-Field API Cross-Check first (`${CLAUDE_PLUGIN_ROOT}/skills/execute-tests/references/missing-field-api-check.md`) and write its one-sentence result into the Actual Result |
| Snapshot state is **ambiguous** | `NEEDS REVIEW` — do not retry, flag for human |
| Dependency failed | `BLOCKED` — skip retries, note the blocker |

**Known-Limitation Check (`SKIP` verdict):** Before recording a `FAIL`, check the TC's actual failing behavior against `story.known_limitations` (Phase 1, step 3j — built from developer comments stating a specific behavior is not implemented, with a technical reason). A match requires the *actual observed behavior* to line up with the limitation's own `behavior` description — not just a topical overlap (e.g. "sorting doesn't work" alone does not match "Progress status sort not implemented" unless the failing TC is actually about that specific column). On a genuine match:
- Verdict = `SKIP`, Actual Result: `Matches known limitation documented by <author> (<date>): <reason>. Not a new defect.` — cite the specific comment, not a generic "known issue" note.
- **No retry** — this isn't an ambiguous flake, retrying wastes the attempt budget on an outcome already explained.
- **The TC still executes once and still gets its screenshot** — this is what catches the limitation going stale (the developer ships the fix later and the comment is never removed). If the actual behavior does *not* match — the feature now works, or fails in some new way the comment doesn't describe — fall through to normal `PASS`/`FAIL` handling instead; never assume a topically-similar comment still applies.
Confirmed necessary (MXTS-79374, Sep 2026): TC_03/TC_04 tested Progress-status column sorting, which a developer's comment already documented as not implemented (no backend field for the ratio; client-side computed, can't be server-sorted) — pending a product decision. Recording these as plain `FAIL` produced a reopen-and-reassign cycle back to the developer, who had already explained the limitation in the ticket.

> ⛔ **A rendered element is not the same as a rendered message.** Whenever a TC's Expected Result names specific message copy, read the *actual text content*, not just that something occupies that spot — a missing translation renders the raw i18n key in place of the resolved copy (e.g. `rest.success.update.work.schedule` instead of "Work schedule updated successfully"). The banner/toast/dialog element is technically present; the content is still broken.
>
> **Detection pattern — dotted key, not a sentence:** lowercase/camelCase tokens joined by **2+ dots**, no spaces, no sentence-ending punctuation (`.`/`!`/`?`) — e.g. `rest.success.update.work.schedule`, `error.validation.field.required`, `label.button.save`. A real user-facing message is always a phrase or sentence; none of this pipeline's target apps ever legitimately shows a dotted key to an end user, so a match is a confirmed defect, not a judgment call — do not downgrade it to `NEEDS REVIEW`.
>
> Record the Actual Result as: `Message rendered as raw translation key "<text>" instead of resolved copy — translation missing.` This check runs against every message-asserting TC regardless of Risk, and overrides an otherwise-PASS verdict from the presence check below.

**Retry logic (FAIL only):**
- On first FAIL: re-run the TC from step 1 (attempt 2)
- On second FAIL: re-run once more (attempt 3)
- If all 3 attempts FAIL with the same result → record as `FAIL (confirmed, 3/3 attempts)`
- If retry passes → record as `PASS (flaky — passed on attempt <n>)` and flag in triage

**Never blindly retry a TC whose failed/ambiguous attempt involved a multi-stage destructive confirmation** (see Multi-Stage Inline Confirmation above) without first confirming the prior attempt had no side effect — re-running from step 1 re-executes the destructive click sequence too, and if it's unclear whether the intended record (or a different one) was actually affected, retrying risks acting on a second wrong record. Verify the intended target's actual state via a fresh snapshot/search first; if genuinely unclear, mark `NEEDS REVIEW` instead of retrying.

**Do NOT use LLM judgment as the sole verdict.** If the snapshot does not clearly confirm or deny the expected result, always use `NEEDS REVIEW` rather than guessing PASS or FAIL.

> ⛔ **A negative assertion needs the positive state first.** Never record `PASS` for an Expected Result that says something is hidden / not shown / no longer visible / disabled / cannot happen unless the same TC also observed the positive state (the element present or enabled before the action, or on a comparable record where it should appear) in its own screenshot. An empty list or a missing element alone is indistinguishable from a broken page or missing data. Positive state unreachable → `NEEDS REVIEW`. A `--retest` PASS for a previously-FAILed TC likewise needs the corrected outcome on screen, not just the absence of the earlier error. Full rule: [the Evidence Review reference](${CLAUDE_PLUGIN_ROOT}/skills/execute-tests/references/evidence-review.md).

> ⛔ **Design-fidelity deviations always escalate to `NEEDS REVIEW` — never PASS, even if the TC's own Expected Result treats it as optional.** If the Actual Result confirms an element/behaviour that (a) contradicts an approved design/mockup referenced in the ticket, or (b) the ticket description or a prior reporter comment already flagged as wrong/unwanted — write it into that TC's own **Actual Result** cell and set **Status = `NEEDS REVIEW 🔍`**, not PASS. Do NOT rely on soft phrasing baked into the TC's Expected Result (e.g. "...recorded as finding", "...noted if present") to justify a PASS — that phrasing describes what to observe, not license to downgrade a real deviation. There is no separate "Findings" section to put this in (banned — see SKILL.md's fixed-format rule); it belongs in the row for the TC that covers it, and it must move the Needs Review count off zero so the stats table cannot read as a clean pass when it isn't.

## PASS Corroboration

**Default (no flag):** Applies only to **High-risk write TCs** — TC involves a write operation (form submit, save, create, delete, update), verdict is PASS, and the TC's Risk column is `High`. Skip for Medium/Low-risk write TCs and all read-only/view TCs.


**Why selective by default:** `browser_network_requests` + `browser_console_messages` are each ~1s calls. Running them on every write TC adds 2+ calls per TC. For a 20-TC run with 10 write TCs, that is ~20 extra tool calls. High-risk TCs (form saves, payment flows, deletions) are where silent API failures matter most — Medium/Low-risk TCs rarely surface hidden failures that aren't already visible in the UI.

When corroboration applies:

1. `browser_network_requests` → scan requests triggered by this TC's final action. If any response has status `4xx` or `5xx`:
   → Downgrade to `NEEDS REVIEW 🔍 — UI showed success but API returned <status>; verify data was actually saved`

2. `browser_console_messages` → check for `error`-level console messages since the last TC started. If any found:
   → Downgrade to `NEEDS REVIEW 🔍 — UI passed but console errors detected: <error summary>`

If both checks are clean → keep `PASS`.

## Debug Evidence Capture

Reuses the same two tools as PASS Corroboration above (`browser_network_requests`,
`browser_console_messages`), applied to a TC's **final** verdict (after retries). What happens with the
captured evidence depends on the verdict:

**`FAIL` or `BLOCKED` → embed directly in the Test Proof cell, under the screenshot:**

1. Look for the request tied to this TC's failing action (status `4xx`/`5xx`) and/or `error`-level
   console messages since this TC started.
2. **Nothing relevant found** (e.g. a pure UI/text mismatch with no failing request or console error) →
   leave the Test Proof cell as just the screenshot. Never force in empty or irrelevant evidence.
3. **Found** → build a short plain-text snippet, 3–4 lines, not the full raw dump — just the failing
   request/error that explains the verdict:
   ```
   POST /api/v1/reservations/12345/confirm
   Status: 500 Internal Server Error
   Response: {"error":"NullPointerException","path":"/api/v1/reservations/12345/confirm"}
   ```
4. **Sanitize before it goes anywhere near Jira:**
   - Strip `Authorization`, `Cookie`, `Set-Cookie` header values → replace with `[REDACTED]`.
   - Strip query/body params matching (case-insensitive) `token`, `api_key`, `access_token`, `secret`,
     `password`.
   - Replace any literal `|` character with `/` — an unescaped pipe splits a Jira wiki-markup table cell
     into an extra column and corrupts the row. Do not rely on `\|` escaping — write the check in
     `post-comment.js`/`update-comment.js` does not understand it (see CHECK 8).
   - Truncate the whole snippet to ~300 characters — the cell is evidence, not a log dump.
5. Store as `tc_debug_evidence[<TC_ID>]`. Phase 3b renders it into the Test Proof cell using Jira's
   forced line-break token `\\ ` — backslash-backslash-**space**, the space is mandatory (a literal
   newline inside a cell breaks the table row instead; a bare `\\` with no trailing space is not
   recognized by Jira's wiki-markup renderer as a break at all — it renders as two literal, visible
   backslash characters, confirmed in production 2026-09-24 on MXTS-77020) — see the Test Proof column
   rules in phase-3b-results-comment.md and `PROOF_RE` in `post-comment.js` / `update-comment.js`.

   > ⛔ **This append is independent of upload status — it must never be skipped just because
   > uploads being off for this run (`screenshot_upload_enabled = false`, e.g. the media host is unreachable)
   > or the capture itself failed.** Append it after whichever base value the Test Proof cell already
   > has — a missing/unattached screenshot is exactly when the technical evidence matters most, not a
   > reason to drop it:
   ```
   !TC_07-login-error.png!\\ POST /api/v1/reservations/12345/confirm\\ Status: 500 Internal Server Error\\ Response: {"error":"NullPointerException","path":"/api/v1/reservations/12345/confirm"}

   TC_07-login-error.png\\ POST /api/v1/reservations/12345/confirm\\ Status: 500 Internal Server Error
   (^ plain filename — upload failed or uploads disabled — evidence still appended)

   TC_07-capture-failed.png (screenshot capture failed — 3/3 attempts, CDP timeout)\\ Status: 500 Internal Server Error
   (^ screenshot capture failed — evidence still appended)
   ```

**`NEEDS REVIEW`** (including a PASS downgraded by PASS Corroboration above) → capture and sanitize the
same way, but do NOT embed in the Jira cell — save as `TC_ID-console.txt` / `TC_ID-network.txt` in the
current working directory instead (skip writing a file if that capture came back empty). Log:
`[Evidence] <TC_ID> — debug capture saved (<n> console lines, <n> network requests, sanitized).` These
files are local only, for manual attachment if the user wants them — NEEDS REVIEW is a softer signal
than FAIL/BLOCKED and does not get the same automatic cell treatment.

**Plain `PASS` with no corroboration downgrade** → skip this entirely. Capturing console/network dumps
for every passing TC would be noise, not evidence.

## Retest Cross-Reference (--retest mode only)

Which TCs run, when the run stops, and how the comment marks Run 1 against the retest: [the scoped retest reference](${CLAUDE_PLUGIN_ROOT}/skills/execute-tests/references/scoped-retest.md). Only TCs that ran get a new verdict below.

Compare the new verdict against the verdict from the **in-memory previous-verdicts snapshot** (captured in pre-flight before `results.md` was deleted — do NOT re-read the file):

| Previous | Current | Flag |
|---|---|---|
| `FAIL` | `PASS` | ✅ **Fixed** — record as `PASS (previously FAIL — verified fixed)` |
| `PASS` | `FAIL` | 🔴 **Regression** — record as `FAIL ⚠️ REGRESSION (previously PASS)` |
| `FAIL` | `FAIL` | No change — record normally |
| `PASS` | `PASS` | No change — record normally |
| `BLOCKED` / `NEEDS REVIEW` | `PASS` / `FAIL` | No flag — record normally; the comment marks the Run 1 verdict (see the scoped retest reference). A `FAIL` here is a new finding, not a regression |
| Any | `NEEDS REVIEW` | Flag as before |

Regressions are highlighted in the results table and listed separately in the Jira comment under a `⚠️ REGRESSIONS INTRODUCED` section.

This Fixed/Regression-annotated body is posted as a **brand-new** results comment for this retest cycle — `--retest` clears `stories.<STORY_KEY>.results_comment_id` **and** `cycle_started_at` in `run-state.json`, and Phase 3a re-stamps a fresh `cycle_started_at` when it starts, precisely so Phase 3b calls `post-comment.js` fresh instead of no-op'ing against the prior cycle's comment. The story's earlier results comment (from before it was reopened) is left in Jira untouched, as history (see Phase 3b in SKILL.md).

## Selector Capture for Spec Generation

For TCs not in `story.tc_skip_automation` and not in `story.tc_already_automated` (the latter already has a spec in `target_repo` — see Phase 2's duplicate check — so Phase 3b will never generate a new one for it and has no use for its selectors): as you navigate each functional area to execute those TCs, simultaneously record into `execution-log.json` under a `selector_map` object keyed by functional area:
- Sidebar nav selector used to reach the module
- Sub-menu link selector and URL pattern
- Create/action button selector (exact text, `a[flat-button]` vs `button`)
- Dialog accessible name (from `getByRole('dialog')`)
- Every form field interacted with: `{ label → locator }` (prefer `input[name="..."]` or `getByRole('textbox', { name: '...' })`)
- Success message text captured from snackbar

This happens **as a by-product of TC execution** — no extra navigation, no extra browser calls. The selector you click to open a form IS the selector. Record it immediately after use.

## Execution Log Format (per TC)

Collect during 3a execution — feeds directly into Phase 3b for real selectors:

```
TC_01:
  - navigated to: /customer/edit
  - selector used: page.getByLabel('Customer Name')
  - selector used: page.getByRole('button', { name: 'Save' })
  - verdict: PASS

TC_03:
  - navigated to: /customer/list
  - selector used: page.getByRole('searchbox', { name: 'Search customers' })
  - verdict: FAIL (confirmed, 3/3)
```

## execution-log.json Format

Write `test-output/<EPIC_ID>/execution-log.json` **incrementally — add/update each TC's entry the moment its verdict is finalized, not only at the end of Phase 3a.** A mid-run context compaction must never lose completed verdicts; on resume, any TC already present here (with a verdict) is not re-executed. This file also enables `--from=phase3b` to use real selectors across sessions. Each verdict write also refreshes `last_activity_at` in `run-state.json` (see Pause Tracking).

```json
{
  "TC_01": {
    "navigated_to": ["/customer/edit"],
    "selectors": ["page.getByLabel('Customer Name')", "page.getByRole('button', { name: 'Save' })"],
    "verdict": "PASS"
  },
  "TC_03": {
    "navigated_to": ["/customer/list"],
    "selectors": ["page.getByRole('searchbox', { name: 'Search customers' })"],
    "verdict": "FAIL (confirmed, 3/3)"
  }
}
```

The `navigated_to` URLs written here are merged into `test-output/nav-cache.json` immediately after this file is written — they become the navigation cache for future runs across all tickets and Epics.

---

## results.md Format

Write `test-output/<EPIC_ID>/results.md` **incrementally — append/update each TC's row the moment its verdict is finalized, not only at the end of Phase 3a**, so a mid-run compaction never loses completed verdicts. Used by resume check and Phase 4 triage.

```
# Execution Results — <EPIC_ID>
Generated: <datetime>
Environment: <base URL>
Build / Version: <build_version>

| TC_ID | Scenario | Verdict | Reason | Attempts |
|---|---|---|---|---|
| TC_01 | Verify we are able to... | PASS | Expected element found | 1 |
| TC_02 | Verify we are not able to... | FAIL (confirmed, 3/3) | Element missing | 3 |
...
```

## Early Abort on Consecutive High-Risk Failures

After 3 consecutive High-risk FAILs → stop execution automatically, no ask. This usually signals an environment issue or upstream blocker rather than 3 independent bugs, and the pipeline already has a designed way to surface that without a human in the loop: mark all remaining unexecuted TCs as `BLOCKED 🚫 (run stopped automatically after <n> consecutive High-risk FAILs)`, log `[Phase 3a] Auto-stopped after <n> consecutive High-risk FAILs — <m> TCs marked BLOCKED.`, then **continue into Phase 3b as normal** — post the standard 6-column results comment for whatever TCs did execute (the Partial-run detection step in the Phase 3b results-comment reference already flags this exact case with the `⚠️ PARTIAL RUN` warning line and excludes the story from DoD metrics, which is the correct place for this signal to live — in the story's own Jira comment, not a chat prompt). Then continue through Phase 4/5 normally. This is not a user-cancellation — do not route lock release through the "User cancels mid-run" handler in SKILL.md; the ticket's own Per-Ticket Completion step covers it once this story's pipeline finishes.
