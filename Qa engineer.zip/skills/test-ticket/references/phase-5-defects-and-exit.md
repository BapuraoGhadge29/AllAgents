# Phase 5 — Raise Defects, Story Action, Exit Gate (full procedure)

## Phase 5: Raise Defects

**Data Integrity Gate:** Default threshold 60% (`--min-completeness=N`).

| Completeness | Action |
|---|---|
| ≥ threshold | Proceed to defect proposal |
| < threshold | Suppress Phase 5 — print warning (format: [the output formats reference](output-formats.md)) |
| Phase 3a skipped | Suppress Phase 5, no warning |

**Dedup:** For each triage-confirmed defect, run three JQL checks in order:

**Check A — Open bug for this TC:**
```
issuetype = Bug AND labels = "<STORY_KEY>-<TC_ID>" AND project = <PROJECT_KEY> AND statusCategory != Done ORDER BY created DESC
```
- Bug found → **skip** (`Duplicate of <BUG_KEY>`)
- No bug found → run Check B.

**Check B — Closed/resolved bug for this TC:**
```
issuetype = Bug AND labels = "<STORY_KEY>-<TC_ID>" AND project = <PROJECT_KEY> AND statusCategory = Done ORDER BY created DESC
```
- Closed bug found → note as a **candidate regression**, but do not propose yet — run Check C first. A closed label-matched bug doesn't rule out an *open*, unlabeled bug already tracking the same regression; proposing the regression before checking that would create the exact duplicate Check C exists to catch.
- No match → run Check C anyway (not only on a Check B miss — Check C must run regardless of Check B's result).

**Check C — Broad keyword match (runs after Check B regardless of its result; candidate signal, catches bugs this pipeline never labeled — e.g. filed manually for the same failure):**
```
issuetype = Bug AND project = <PROJECT_KEY> AND statusCategory != Done AND text ~ "<2-3 distinguishing keywords from the failure>" ORDER BY created DESC
```
- Match found → verify it's a genuine same-root-cause match (not just keyword overlap), same way the Automation Duplicate Check in Phase 2 verifies a `search_code` hit. Genuine match → skip, reference the existing bug — regardless of what Check B found. Keyword-only overlap → fall through to the Check B outcome below, noting it as `Possible related: <BUG_KEY>` in the proposal table.
- No match, or search unreachable → fall through to the Check B outcome below (fail open — Step 3's confirmation gate is the human backstop either way).

**Finalize (only reached when Check C found no genuine match):** Check B found a closed label match → **propose a regression bug** (append `(regression)` to summary, reference `[REGRESSION of <BUG_KEY>]`). Check B found nothing → **propose as new**.

In `--retest` mode: FAIL→PASS = skip proposal (bug already tracked); PASS→FAIL = flag as regression in proposal.

**Failure clustering (before proposal):** Group triage-confirmed product defects by functional area and failure pattern. If ≥2 TCs in the same functional area share the same failure root cause (same missing element, same 5xx endpoint, same broken flow) → group them into one defect proposal. List all TC_IDs in the description; use the first TC's ID in the Jira summary. Log: `[cluster] TC_03, TC_07 grouped → 1 defect (same login error, Authentication area).`

**Zero defects:** If no defects remain after dedup (all matched existing open bugs, or triage produced zero product defects) → log `[Phase 5] No new defects to raise — skipping to Exit Gate.`, persist `stories.<STORY_KEY>.phase5_done = true` to `run-state.json` (see note below), and proceed to Exit Gate immediately. Do not print an empty proposal table.

> ⛔ **Persist `stories.<STORY_KEY>.phase5_done = true` the moment Phase 5 reaches a real decision for this story** — the zero-defects path above, a declined proposal (Step 3's "no"), or after defect creation/dedup finishes below. This is what the resume check (SKILL.md) reads instead of guessing from a JQL bug search, because "zero defects raised" and "Phase 5 hasn't run yet" are otherwise indistinguishable from Jira alone — a story with no product defects would otherwise re-run Phase 5 (and re-propose already-declined defects) on every resume. Do **not** set it when the Data Integrity Gate suppresses Phase 5 (completeness below threshold) — that is genuinely "not done yet," and should retry once completeness improves on a later run.

**Defect Proposal:** Print proposal table (format: [the output formats reference](output-formats.md)) and ask user to confirm. **This confirmation is unconditional — no flag, mode, or defect type skips it.** `--auto-raise` and `--unattended` do not skip it. A regression (closed prior bug found) does not skip it either — it still goes in the proposal table like any other defect and waits for an explicit "yes" before anything is created. `--auto-raise` is accepted for backward compatibility but is now a no-op here. **User declines ("no")** → stop, inform the user the listed defects are available for manual review, and persist `stories.<STORY_KEY>.phase5_done = true` per the note above — the user made an explicit decision this run.

> ⛔ **All Bug creation goes through `raise-defect.js` when `jira_write_path = script`.** When it's `mcp`, use `createJiraIssue` instead (`issueTypeName: "Bug"`, same `labels`/`extraLabels` split via `additional_fields`, **plus `additional_fields.priority: { name: "<P1|P2|P3|P4>" }`** — the same Priority value the script path writes; omitting it here silently reintroduces the dead Exit-Gate-count bug on the MCP-fallback path only) — but two more things `raise-defect.js` enforces mechanically become your responsibility to reproduce by hand on this path, and skipping either is exactly how a ticket gets created without the user knowing:
> 1. **The confirmation pause.** `raise-defect.js` physically cannot create anything without a second, separate invocation carrying `--confirmed`. `createJiraIssue` has no such gate — it creates on the first call. So on this path **you must stop after printing the proposal table and wait for the user's explicit reply** before calling `createJiraIssue` at all; do not let "jira_write_path is mcp, so I'm already in a fallback path" read as license to also skip the ask. The unconditional confirmation rule above applies exactly the same way here as on the script path.
> 2. **The dedup re-check.** `raise-defect.js` also runs the pre-create duplicate check internally (guard 2: an open Bug already carrying this `<STORY_KEY>-<TC_ID>` label blocks creation); `createJiraIssue` does not. **Reproduce that check manually** — run the same dedup JQL this phase already uses (`issuetype = Bug AND labels = "<STORY_KEY>-<TC_ID>" AND project = <PROJECT_KEY> AND statusCategory != Done`, see the duplicate-check queries above) via `searchJiraIssuesUsingJql` before calling `createJiraIssue`; a match means DUPLICATE_BLOCKED, same as the script would report — reference the existing bug, do not create a new one.
>
> For each defect (one per cluster), write a payload JSON `{ "project", "type": "Bug", "summary", "description", "labels": ["<STORY_KEY>-<TC_ID>", …], "extraLabels": ["QA_Pipeline_Bug"], "priority": "<P1|P2|P3|P4>" }`. **`priority` is this defect's Priority from the proposal table** (the P1–P4 value derived from the TC's Risk — High → P2, Medium → P3, Low → P4; P1 only for data loss, auth bypass, or a 5xx on a core business endpoint) — **not** the Severity label (`blocker`/`critical`/`major`/`minor`, which is a separate value used only for the label, never for this field). Written as the Jira priority name, without it the Bug lands on the project default and the Exit Gate's open-P1/P2 count has nothing real to read. `labels` stays exactly as before (one `<STORY_KEY>-<TC_ID>` per TC_ID in the cluster, required for dedup). **`QA_Pipeline_Bug` goes in `extraLabels`, never in `labels`** — it marks every Bug this phase creates (for usage tracking), always included, unconditionally, on every defect; but it's a label shared across *all* pipeline-raised bugs, and `labels` entries are OR'd together in the pre-create dedup re-check (guard 2 in the script) — putting a shared label there would make the second pipeline bug falsely match the first as a duplicate and block it. `extraLabels` applies to the created issue without touching that dedup query. Then:

```bash
# Step 1 — propose (creates nothing). Show the output to the user.
node "$CLAUDE_PLUGIN_ROOT/skills/test-ticket/scripts/raise-defect.js" <payload_file>
# stdout "AWAITING_CONFIRMATION" → present the proposal and get user approval.
# Step 2 — only after the user explicitly approves this specific proposal (no flag skips this), create:
node "$CLAUDE_PLUGIN_ROOT/skills/test-ticket/scripts/raise-defect.js" <payload_file> --confirmed
# stdout "CREATED <KEY>"        → store the key, then link it (see below).
# stdout "DUPLICATE_BLOCKED …"  → an open bug already has this label; do NOT create — reference it.
# exit 1                        → validation/dedup/API failure; nothing was created (failed closed).
node "$CLAUDE_PLUGIN_ROOT/skills/test-ticket/scripts/create-issue-link.js" "<NEW_BUG_KEY>" "<STORY_KEY>" "Blocks"
# stdout "LINKED ..." / "ALREADY_LINKED ..." — same idempotent guard as the fix-task link below.
```
When `jira_write_path = mcp`, use `mcp__claude_ai_Atlassian_MCP__executeWrite` with `name: createJiraIssueLink` instead (`inwardIssue`/`outwardIssue`/`linkType` matching the script's args) — check `getJiraIssue` with `fields: ["issuelinks"]` first for an existing link of the same type between the same two issues, to reproduce the script's own idempotent guard. **Not** `listJiraIssueRemoteIssueLinks` — that's a different Jira feature (links to external URLs/systems), not the issue-to-issue links (`Blocks`, `Duplicate`, `Relates`) `create-issue-link.js` and `createJiraIssueLink` both create; checking it would miss existing links and risk duplicates on a rerun/resume.

> The script re-runs the open-bug dedup JQL immediately before creating (defense-in-depth on top of the Check A/B dedup above) and refuses without `--confirmed`, so a duplicate or unconfirmed Bug cannot be created even if this gate is reached with stale context after compaction.

**Persist `stories.<STORY_KEY>.phase5_done = true` once every confirmed defect for this story has reached a genuine terminal outcome — `CREATED` or `DUPLICATE_BLOCKED` only** (see the note under "Zero defects" above for the other two paths that also set this flag). This is the path most runs actually take, and it is the one place this flag was previously left unset — without it, a story whose defects were successfully created or matched still looked "not done" to the resume check and re-entered Phase 5 on the next run.

> ⛔ **A `failed` defect (exit 1 — validation/dedup/API error, nothing created) must NOT set `phase5_done`.** Treating a failure as "done" the same as a real `CREATED`/`DUPLICATE_BLOCKED` outcome would let a transient Jira/MCP/API error permanently suppress that defect — the resume check would see `phase5_done = true` and never re-attempt Phase 5 for this story again, silently losing a real product defect to a one-off API hiccup. Leave `phase5_done` unset (or `false`) for a story with any failed defect so the next run's resume check re-enters Phase 5 and retries it; log `[Phase 5] <STORY_KEY> — defect creation failed for <n> confirmed defect(s), phase5_done left unset, will retry on next run.`

## Story Action (after Phase 5, before Exit Gate)

*Skip entirely if Phase 3a was skipped, or triage found zero Product-Defect-classified TCs for this story this run (nothing failed as a real product issue — proceed straight to Exit Gate, unchanged), **or the run tests a Sub-task under its parent** (`stories.<STORY_KEY>.subtask_key` set — see Sub-task keys in [the Phase 1 reference](phase-1-context-extraction.md)): one sub-task's result says nothing about the whole story, so nothing is transitioned. Log `[Story Action] skipped — sub-task run under <PARENT>.`*

No ask, no `on_defects_raised` config, no menu of options — the story's next status follows deterministically from whether a failure this run actually ended up tracked by a Bug:

- **At least one Bug is now associated with this story's failures** — either created fresh this run, or matched to an already-existing open Bug via the Phase 5 dedup check — → **transition to `Checked by QA`.** The failure is tracked on its own ticket; the story itself is done from QA's side.
- **Triage found Product-Defect-classified TC(s), but none of them ended up tracked by any Bug** (e.g. the Defect Proposal confirmation was declined) → **transition to `Reopened`.** Nothing is tracking the failure anywhere else, so the story itself has to carry it back to dev.

**Transition to `Checked by QA`:**
```bash
node "$CLAUDE_PLUGIN_ROOT/skills/test-ticket/scripts/transition-issue.js" "<STORY_KEY>" "Checked by QA"
# stdout "ALREADY_IN_STATUS <status>"    → no-op, already there
# stdout "TRANSITIONED <from> -> <to>"   → applied
# stdout "NO_MATCHING_TRANSITION ..."    → none reachable; log a warning and skip, do not fail the run
```
Log: `[Story Action] <STORY_KEY> transitioned to Checked by QA — <n> defect(s) tracked: <BUG_KEYs>.`

**Transition to `Reopened`:**
```bash
node "$CLAUDE_PLUGIN_ROOT/skills/test-ticket/scripts/transition-issue.js" "<STORY_KEY>" "Reopened,Reopen,In Progress"
# stdout "ALREADY_IN_STATUS <status>"    → no-op, already there
# stdout "TRANSITIONED <from> -> <to>"   → applied
# stdout "NO_MATCHING_TRANSITION ..."    → none reachable; log a warning and skip, do not fail the run
```
Log: `[Story Action] <STORY_KEY> transitioned to Reopened — <n> product defect(s) found but not tracked by any Bug this run.`

> ⛔ **Use `transition-issue.js` when `jira_write_path = script`** — it checks current status first so a re-run never double-transitions or errors on an issue already in the target state. **When it's `mcp`, use `mcp__claude_ai_Atlassian_MCP__executeRead` with `name: listJiraIssueTransitions` + `transitionJiraIssue` instead** (match the target status name to a `transition.id`, check current status first the same way) — see phase-3a-execution.md's "Jira Write-Path Check" → MCP fallback. A missing script credential is not a reason to leave the ticket status untouched.

## Exit Gate (after Phase 5)

*Skip entirely if Phase 3a was skipped (generation-only mode).*

> ⛔ **Check `story.partial_run` before computing anything below.** If [Phase 3b's partial-run detection](phase-3b-results-comment.md) set it (`blocked_rate > 50%`, or the run was stopped early by run-budget exhaustion or early-abort), skip the pass-rate computation entirely — DoD status is `❌ BLOCKED` regardless of what PASS/(total−BLOCKED) would otherwise compute, and `auto_transition` does not fire even if `pass_rate_threshold` would technically be met on the executed subset. A partial run proves nothing about the untested TCs; treating it as PASSED would silently pass a story most of which was never actually verified — confirmed as a live risk 2026-09-24 (MXTS-77759, 68% BLOCKED on a budget-exhausted run) once run-budget exhaustion started continuing into this phase instead of stopping short of it. Log per story: `[Exit Gate] <STORY_KEY> DoD: BLOCKED (partial run — pass rate not computed).` **This does not affect the `QA-RUNNING` lock release** ([test-ticket/SKILL.md](../SKILL.md)'s unconditional post-Exit-Gate step still fires) — only the DoD status and auto-transition are suppressed.

For every other QA-stage story that had Phase 3a execution, compute from the collected results (in `--retest` mode, the merged verdicts: this cycle's verdict where a TC ran, its carried-forward verdict otherwise — see [the scoped retest reference](${CLAUDE_PLUGIN_ROOT}/skills/execute-tests/references/scoped-retest.md); a run stopped because a failed TC failed again is not a `partial_run`):

- **Pass rate** = PASS / (total TCs − BLOCKED − SKIP). BLOCKED and SKIP are both excluded — BLOCKED is an environment issue, not a test failure, and SKIP is a confirmed developer-documented limitation (see the Known-Limitation Check in [the Phase 3a execution reference](phase-3a-execution.md)), not an outcome the story should be penalized or credited for either way. NEEDS REVIEW counts as non-pass. No defect is raised for a SKIP verdict — the developer's own comment already explains it. **If `(total TCs − BLOCKED − SKIP)` is `0`** (every TC ended up BLOCKED, SKIP, or some mix of the two) — do not compute a rate against a zero denominator. Treat this exactly like the `partial_run` case above: DoD status is `❌ BLOCKED` unconditionally, `auto_transition` does not fire, and the log line becomes `[Exit Gate] <STORY_KEY> DoD: BLOCKED (no TC actually verified — all BLOCKED/SKIP).` A story where nothing was actually pass/fail-tested cannot read as PASSED just because there was nothing to fail.
- **Open P1/P2 count** = Bugs actually created this run (Phase 5 `CREATED <KEY>` results) whose priority — the proposal's Priority column (P1–P4, not the Severity label), written to the Bug's `priority` field via the payload — is P1 or P2. Dedup-skipped duplicates and declined proposals do not count.

Apply thresholds from the `exit_gate` Configuration block:

| Criterion | Threshold | Result |
|---|---|---|
| Pass rate | ≥ `pass_rate_threshold`% | ✅ / ❌ |
| Open P1/P2 | 0 (if `block_on_open_p1_p2: true`) | ✅ / ❌ |

**DoD status per story:** `✅ PASSED` only if all applicable criteria pass; otherwise `❌ BLOCKED`.

Print the exit gate result per story (format: [the output formats reference](output-formats.md)).

**Sub-task run (`stories.<STORY_KEY>.subtask_key` set): no transition at all.** The DoD above is still computed and logged — it describes the sub-task's scoped TCs — but it is never applied: neither the parent nor the sub-task changes status, whatever `auto_transition` says. Log `[Exit Gate] <STORY_KEY> transition skipped — sub-task run under <PARENT>.` Skip the rest of this paragraph.

**Transition (only if `auto_transition: true` AND story DoD = PASSED AND not a sub-task run) — automatic, no ask:** `auto_transition: true` in Configuration is itself the opt-in; a per-run confirmation on top of that config choice was asking the same thing twice — a Jira status change is visible to the team either way, config or confirm, so the config is where that judgment call belongs.

Run `node "$CLAUDE_PLUGIN_ROOT/skills/test-ticket/scripts/transition-issue.js" "<STORY_KEY>" "<transition_target>"` directly (no `--check-only` — nothing left to gate on the result of checking):
- `TRANSITIONED <from> -> <to>` → applied. Log: `[Exit Gate] <STORY_KEY> transitioned to <transition_target>.`
- `ALREADY_IN_STATUS <status>` → no-op, log the current status.
- `NO_MATCHING_TRANSITION` → log a warning and skip; do not fail the run.

> ⛔ **Use `transition-issue.js` when `jira_write_path = script`; use `mcp__claude_ai_Atlassian_MCP__executeRead` with `name: listJiraIssueTransitions` + `transitionJiraIssue` instead when it's `mcp`** — see phase-3a-execution.md's "Jira Write-Path Check" → MCP fallback.

Log per story: `[Exit Gate] <STORY_KEY> DoD: <PASSED|BLOCKED> (pass rate: <n>%, P1/P2: <n>).`
