# Feedback Collection (full procedure)

Skip this entire section if `feedback_canvas_id` is blank in Configuration. Feedback is **mandatory**: it is asked at every entry point below, and once asked it is saved to `run-state.json` before anything is posted, so a compaction, a crash, a killed session or Slack being down cannot lose it.

**Entry points** — each passes an `outcome`:

| `outcome` | Called from |
|---|---|
| `executed` | End of Phase 3b — once per Epic, after every story's results comment and `QA_Pipeline` label, before Phase 4 |
| `completed` | Per-Ticket Completion |
| `stopped` | User-cancels-mid-run |
| `error` | Connector outage / unrecoverable phase failure — never skipped, not even when Atlassian is down: the ask and the saved record need no connector |
| `error` | Final Summary sweep — every Epic that started a cycle this invocation and has no ask recorded for it. Catches each path that jumps straight to Final Summary (no Playwright MCP, Phase 6's duplicate-PR skip, a failed gate) |
| `interrupted` | Feedback Recovery — start of the next invocation, for a run whose session was closed, killed or cleared |

**A killed session cannot ask at that instant** — no code runs after the process is dead (the same limit as `QA-RUNNING` release). What is guaranteed instead: a kill after Phase 3b is already covered by the `executed` ask, and a kill before it is asked about by Feedback Recovery at the start of the next invocation.

**Guards — check both before step 1:**

- **Once per cycle.** Read `feedback_asked_at` and `feedback_outcome` from `test-output/<EPIC_ID>/run-state.json`. If `feedback_asked_at` is set, not earlier than the latest `cycle_started_at` across the Epic's stories, and `feedback_outcome` is `executed` or `completed`, skip this entire section silently, whatever the call. If the earlier outcome was `stopped`, `error` or `interrupted` (the run had not finished when it was asked), a `completed` call asks again and every other call skips. Every ask writes these fields (step 1), so a `--retest` / `--force` run, which stamps a newer `cycle_started_at`, is asked again.
- **`executed` only — skip when the run is `--unattended` or Generation only.** This call sits before Exit Gate; an unanswered prompt there would hold the story status and the `QA-RUNNING` lock. Skipping it leaves the later calls untouched.

1. **Ask, once, per ticket:** `Any feedback on this run for <EPIC_ID>? Your reply is posted as you write it to the QA feedback canvas and, when a feedback channel is set up, to that Slack channel. (optional — press enter to skip)`. The prompt names where the reply goes: that disclosure is what makes the reply consent to the posts in step 4, so never shorten it to the bare question. Ask even when Slack is not connected; nothing about the ask needs it. **Save the reply before any Slack call**: right after it, a blank reply included, set top-level `feedback_asked_at` (current ISO time), `feedback_outcome` (this call's outcome) and `feedback_entry` in `run-state.json` — `{ "text": "<verbatim>", "date": "<YYYY-MM-DD>", "mention": null, "canvas_done": false, "channel_done": false }`, or `null` for a blank reply. A blank reply is a decline: skip the rest of this section silently, no Slack call.
2. **Resolve the Slack identity:** take the local part of `JIRA_EMAIL` (before the `@`) and call `slack_search_users` with that email to find the matching Slack user ID. Found → use `![](@<slack_user_id>)` (a real mention, matches the canvas's existing entries). Not found or the lookup fails → fall back to plain text `@<local-part>` (e.g. `@v.chauhan`) — never block or retry on this step. Save the result as `feedback_entry.mention` so Feedback Recovery never needs `JIRA_EMAIL`.
3. **Build the canvas entry**, following the exact structure already used in the canvas — do not deviate from this template:
   `- [ ] <mention or @handle> <YYYY-MM-DD> — <feedback text, verbatim> _(<EPIC_ID> · <outcome>)_`
   `<YYYY-MM-DD>` is today's date, placed straight after the mention; it is not repeated inside the brackets.
4. **Post the canvas entry and the channel message together, no second confirmation gate** — step 1's prompt already said both destinations and the user chose to answer it (a blank reply posts nothing); do not show either back or ask a second time. They are one feedback and must land together: send `slack_read_canvas` (4a) and `slack_send_message` (4b) in the same tool-call batch, then `slack_update_canvas`. Never post one and decide about the other afterwards, and never skip one because the other failed. Set `canvas_done` / `channel_done` in `feedback_entry` the moment each call succeeds.
   - **4a — canvas, append-only, never full-replace:** read `feedback_canvas_id`, find the section whose text is exactly `## Feedback` in `section_id_mapping`, then call `slack_update_canvas` with `action: "append"` and that `section_id`. **Never call `slack_update_canvas` with `action: "replace"` and no `section_id`** — that overwrites every prior entry in the canvas, including everyone else's feedback.
   - **4b — channel message to `feedback_slack_channel`:** skip if it is blank in Configuration. The Configuration value is the opt-in, as `impact_slack_channel` is for the impact post. Call `slack_send_message` with `channel_id = feedback_slack_channel` and exactly this standard-markdown message, one `> ` prefix per line of the feedback:

     ```
     :memo: **QA pipeline feedback** — [<EPIC_ID>](https://maxxton.atlassian.net/browse/<EPIC_ID>)

     > <feedback text, verbatim>

     _Run outcome: <outcome> · <YYYY-MM-DD>_
     ```

     Remove Slack broadcast tokens (`<!channel>`, `<!here>`, `<!everyone>`) from the quoted text — the channel is large and a tester's words must not ping it (the canvas entry keeps the text verbatim). The message carries no mention: the post's author already shows who sent it. On success log `[Feedback] Posted to <feedback_slack_channel>`.
5. **If either post in step 4 fails for any reason** (permissions, canvas deleted, runner not in the channel, Slack not connected, network) — log a one-line warning (`[Feedback] Could not post to canvas: <error>` or `[Feedback] Could not post to <feedback_slack_channel>: <error>`) and continue the run. Leave that post's flag `false`: the feedback is not lost, Feedback Recovery finishes it at the next invocation. The other post is unaffected — a failed canvas append does not skip the message, and a failed message does not undo the canvas entry. Never retry in a loop and never let a feedback-posting failure block, fail, or delay the rest of the pipeline — this step is a courtesy, not a gate. Note: this failure mode is about the *runner's* own Slack access, not the feedback-giver's — a tester who isn't in the channel (or not in the workspace) does not cause this step to fail; only step 2's identity lookup degrades gracefully for that case (see above), while the writes depend solely on the runner's own canvas permissions and channel membership.

## Chat compaction

Nothing here lives only in the conversation. The reply is saved to `run-state.json` before any Slack call, and every call re-reads it first (Guards). A compaction between the ask and the posts leaves a `feedback_entry` with a done flag still `false`: do not ask again, post the missing one(s) from the saved entry (Feedback Recovery step 1). A compaction before the ask leaves no `feedback_asked_at`: the next entry point asks, at the latest Per-Ticket Completion.

## Feedback Recovery (start of every invocation)

Run from the Resume Check, before Phase 1, on every invocation — with or without a URL. Scan `test-output/*/run-state.json` in the current project, newest first, at most 3 Epics, ignoring any whose latest `last_activity_at` or `cycle_started_at` is older than 7 days. Epics named in this invocation are skipped by step 2 only — their own run asks. **First run on a project:** if `test-output/.feedback-recovery-since` does not exist, create it holding the current ISO time; step 2 only considers a cycle that started after that time, so runs from before this feature existed are never asked about (step 1 is unaffected).

1. **Finish unposted entries — no prompt, also under `--unattended`.** `feedback_entry` is not null and `canvas_done` or `channel_done` is `false` → post only the missing one(s) by step 4's rules, after a duplicate check, because the earlier call may have succeeded without its flag being saved. Canvas: `slack_read_canvas` already runs; if the exact entry line is already in it, set `canvas_done` and do not append. Channel: call `slack_read_channel` on `feedback_slack_channel` (limit 20); if a message with this Epic's header and the first line of the text is already there, set `channel_done` and do not send.
2. **Ask about runs that ended without feedback — skipped under `--unattended`.** An Epic qualifies when it has a started cycle (any story has `cycle_started_at`), no ask recorded for it (the "Once per cycle" guard would not skip it), at least one story whose `phase5_done` is not true (the run never reached its end), and a latest `last_activity_at` more than 30 minutes old (a fresher one may belong to a session still running — the same heartbeat rule the feature-flag restore uses). Ask `Your last run for <EPIC_ID> ended without feedback being collected (session closed, killed or cleared). Any feedback on it? (optional — press enter to skip)`, then save the reply and post it exactly as steps 1–5 describe, with `outcome = interrupted` (this question replaces step 1's wording). One question per Epic, then go on with the invocation.
