# Output Format Templates

## Resume Check Status Table

```
RESUME CHECK — MXTS-12345
=========================
Phase 1 — Read Requirements:    [SKIP] Report directory found
Phase 2 — Generate Test Cases:  [PARTIAL] MXTS-12346 SKIP (TC comment found) | MXTS-12348 RUN (no TC comment)
Phase 2.5 — Impact Analysis:    [RUN]  No impact summary found for QA-stage stories
Phase 3a — Execute Tests:       [RUN]  No execution results found
Phase 3b — Playwright Tests:    [SKIP] MXTS-12345.spec.js found in test-output/
Phase 4 — Triage:               [RUN]  No triage data found
Phase 5 — Raise Defects:        [RUN]  No linked bugs found

Starting from Phase 3a. Use --force to re-run all phases.
```

## Status Gate Summary

```
STATUS GATE — MXTS-12345 stories
=================================
MXTS-12346 (Feature A): In Progress   → [GENERATE TEST CASES ONLY — pipeline stops after Phase 2]
MXTS-12347 (Feature B): Ready for QA  → [SKIP TEST CASES — full pipeline, Phases 2.5–5]
MXTS-12348 (Feature C): Open          → [GENERATE TEST CASES ONLY — pipeline stops after Phase 2]
```

## --max-tcs Scope Log

```
[Phase 3a] --max-tcs=30 set — running top 30 of <total> TCs.
<total - 30> TCs will be skipped.
```

## Early Abort Notice (3 consecutive High-risk FAILs) — informational, not a prompt

No ask — stop Phase 3a automatically and print this notice (do not wait for a reply):

```
⚠️ 3 consecutive High-risk failures detected (TC_08, TC_09, TC_10).
   This may indicate an environment issue or upstream blocker rather than individual bugs.
   Stopping remaining <n> tests — marking them BLOCKED. Continuing to Phase 3b; the results
   comment for this story will carry a PARTIAL RUN warning (see Partial-run detection).
```

Then mark all remaining unexecuted TCs `BLOCKED 🚫 (run stopped automatically after 3 consecutive High-risk FAILs)` and proceed into Phase 3b as normal — same flow as any other run, not a special case that skips ahead to Final Summary.

## Triage Review Gate — Table Format

```
TRIAGE REVIEW — <STORY_KEY>
============================
#   TC_ID   Scenario                              Classification    Reason
1   TC_03   Login error message not displayed     Product Defect    Expected UI element missing confirmed
2   TC_07   Search returns wrong results          Product Defect    Functional mismatch
3   TC_11   Save button unresponsive              Tooling Misread   Snapshot captured loading state — button not yet rendered
4   TC_14   Duplicate name not rejected           NEEDS REVIEW      Ambiguous — may need data setup

Proceed to raise defects for the <n> Product Defect(s)? (yes / no)
Or correct any misclassification: "reclassify TC_11 as product defect"
```

## Data Integrity Gate — Suppressed Warning

```
⚠️ DATA INTEGRITY GATE — Phase 5 suppressed
=============================================
Execution completeness: <n>% (<x> of <total> TCs produced signal)
Required threshold:     60%

Too many tests were BLOCKED or NEEDS REVIEW to trust the failure data.
Filing defects from degraded execution risks false positives in Jira.

Recommended actions:
1. Fix environment / test data issues (see BLOCKED reasons above)
2. Re-run: /test-ticket <EPIC_ID> <URL> --from=phase3a
3. Or override: /test-ticket <EPIC_ID> <URL> --min-completeness=0

Defects will NOT be raised until completeness meets the threshold.
```

## Defect Proposal Table

```
PROPOSED DEFECTS — MXTS-12345
==============================
#  TC_ID   Summary                                         Severity   Note
1  TC_03   Login error message not displayed               P2         New
2  TC_07   Search returns no results for valid term        P3         [REGRESSION of MXTS-71234]

2 defect(s) ready to raise. <n> skipped (duplicates of open bugs). Proceed? (yes / no)
```

## Exit Gate Result

```
EXIT GATE
=========
Story: MXTS-12346 — Feature A
Pass rate:    89% (17 PASS / 2 FAIL / 1 BLOCKED / 1 SKIP excluded)   ✅ ≥80%
Open P1/P2:   0 defects raised this run                      ✅
DoD status:   ✅ PASSED

Story: MXTS-12347 — Feature B
Pass rate:    60% (12 PASS / 8 FAIL / 0 BLOCKED / 0 SKIP)             ❌ <80%
Open P1/P2:   2 defects raised this run (MXTS-77001, MXTS-77002)  ❌
DoD status:   ❌ BLOCKED — fix failures and re-run from Phase 3a

Story: MXTS-12348 — Feature C
Pass rate:    N/A (0 PASS / 0 FAIL / 3 BLOCKED / 2 SKIP — no TC actually verified)   ❌
Open P1/P2:   0 defects raised this run                      ✅
DoD status:   ❌ BLOCKED — every TC ended up BLOCKED or SKIP, nothing to compute a rate from
```

## Final Summary — Single Epic

```
TEST-TICKET RUN COMPLETE
========================
Epic: <EPIC_ID> — <Epic summary>
Run date: <date>
Mode: <Resume / Force / Retest / Generation only>
Duration: <start time> → <end time>

PHASE RESULTS
-------------
Phase 1 — Read Requirements:    <Complete / Skipped (cached)> — <n> stories, <n> docs
Phase 2 — Generate Test Cases:  <Complete / Skipped (cached/QA-stage)> — <n> test cases, <n> gaps
Phase 3a — Execute Tests:       <Complete / Skipped (cached/no URL)> — <n> tests PASS/FAIL/BLOCKED | completeness: <n>%
Phase 3b — Playwright Tests:    <Complete / Skipped> — <n> spec files displayed
Phase 4 — Triage:               <Complete / Skipped> — <n> defects found
Phase 5 — Raise Defects:        <Complete / Suppressed (degraded <n>%) / Skipped (user declined)> — <n> defects raised
Phase 6 — Publish Specs:        <Complete / Skipped (no specs generated)> — PR: <URL or "skipped">

DELIVERABLES
------------
- Jira test case comments: posted on all <n> stories (development-stage + first-time QA-stage runs)
- Jira results comments: posted on all <n> QA-stage stories
- Playwright spec files: displayed above — copy into your project's test directory
- Jira defects: <n> raised (<comma-separated keys>)
```

## Final Summary — Multi-Epic Totals Block

Append after all per-Epic summaries:

```
MULTI-EPIC RUN SUMMARY
======================
Epics processed: <n>  (<EPIC_1>, <EPIC_2>, ...)
Total duration:  <start time> → <end time>

TOTALS
------
Stories processed:  <n>
Test cases run:     <n> | Pass: <n> | Fail: <n> | Blocked: <n> | Needs Review: <n> | Skipped (known limitation): <n>
Defects raised:     <n> | Skipped (duplicates): <n>
Regressions found:  <n>  ← only shown in --retest mode
Bugs verified fixed: <n>  ← only shown in --retest mode

PER-EPIC RESULTS
----------------
| Epic         | Environment                    | TCs | Pass | Fail | Blocked | Skipped | Defects |
|---|---|---|---|---|---|---|---|
| MXTS-76746   | https://mqa-dev.maxxton.net    | 24  | 18   | 4    | 2       | 0       | 3       |
| MXTS-75065   | https://rcn-dev.maxxton.net    | 31  | 27   | 2    | 1       | 1       | 2       |
```

```
ACTION REQUIRED
---------------
<list any items needing human follow-up, e.g. NEEDS REVIEW TCs, skipped phases, low completeness>
(or "No action required — run complete")
```

> ⛔ **"No action required" is only valid when every count is actually zero.** If the Needs Review total (from the stats table) or the BLOCKED total is > 0, this section MUST list each one by TC_ID and story — do NOT summarize them away with a judgment call like "minor" or "no action required" just because the pipeline itself classified them as non-blocking. The human reading this section is the backstop for exactly the cases the pipeline's own severity classification could get wrong (see the Verdict Determination design-fidelity rule in phase-3a-execution.md) — never let this section hide a signal the stats table already surfaced.

## Slack Run-Complete Notification

Send only if `slack_notify_on` is `run_complete` or `both` and `slack_channel` is set. Notification failure must never block the run or the lock release.

```
✅ *QA Run Complete — <EPIC_ID>*

*Epic:* <EPIC_ID>: <summary>
*Environment:* <base URL or "Generation only">
*Stories processed:* <n>

*Results:*
• Tests run: <n> | Pass: <n> | Fail: <n> | Blocked: <n> | Needs Review: <n> | Skipped (known limitation): <n>
• Defects raised: <n> | Skipped (duplicates): <n>
• Execution completeness: <n>%

<Confluence report URL if generated, otherwise omit>
```
