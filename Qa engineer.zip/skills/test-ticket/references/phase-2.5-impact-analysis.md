# Phase 2.5 — Cross-Module Impact Analysis (full procedure)

## Computing the blast radius

**Step 1 — Read the linked PR (primary signal).**

Call `mcp__claude_ai_Atlassian_MCP__executeRead` with `name: listJiraIssueRemoteIssueLinks` to find linked PRs. For each `github.com/MaxxtonGroup/<repo>/pull/<n>` link found, call `pull_request_read` to get the list of changed files and classes. If no remote PR link found, call `search_pull_requests` on `MaxxtonGroup` for PRs whose branch or title contains the story key.

If no PR found → proceed with technical graph only; Confidence ≤ Medium. Log: `[Phase 2.5] No linked PR found — blast radius derived from technical graph and ticket prose only.`

**Step 2 — Query the technical graph.** Using changed files/classes from Step 1 as entry points (fall back to story prose when no diff is available):
- `get_service_overview` on the directly-touched service(s)
- `get_call_chain` for each changed controller or service method — run **outbound** (what it calls) and **inbound** (what calls it). Node IDs follow the pattern from `search_technical_graph` results: backend = `com.maxxton.<service>.<package>.<Class>.<method>`, frontend = `<ServiceClass>.<method>`. **`FeignMethod` nodes in the outbound chain = cross-service impact** — each one is a transitive module that must appear in the blast radius.
- `get_entity_usage` for shared entities or components changed
- `search_technical_graph` with domain keywords from the ticket

**Step 3 — Produce blast radius.** List each impacted module (direct + transitive) with a one-line description of what is affected and which team owns it. Include an overall risk level (High / Medium / Low). Store as `story.impact_summary`.

Every entry in the `Module` column MUST be one of the **Canonical module names** in
`analyzing-impact/SKILL.md` (`General`, `Content`, `Reservations`, `Rates`, `Customer Care`,
`Operations`, `Owners`, `Partner Portal`, `Availability Index`, `Front Office`, `Channels`,
`Finance`, `Legislation`, `Comité d'Entreprise`, `Notification`, `Customer Kiosk`) — never a
free-form technical/service description (e.g. `Channels`, not "Reseller Connection Service
(Booking.com flow)"). Use that skill's **Repository → Module mapping** table to resolve each
changed repo/class; if a finding genuinely doesn't map to any of them, write `<finding> —
canonical module unconfirmed, verify` rather than inventing a label.

Every entry in the `QA` column is looked up by **Team** (not Module) in that same skill's **QA
ownership reference** table — sourced from the QA Team Slack canvas
([maxxton.slack.com/docs/T02U60K4R/F06MQ4GSSLA](https://maxxton.slack.com/docs/T02U60K4R/F06MQ4GSSLA)).
**No fallback:** if a Team value isn't covered there (includes `Frontend Core Team`, `Platform Team`,
anything marked "unconfirmed") → leave the QA cell **blank (`—`)**. Never default to the table's Core QA
row, never guess the closest-sounding pod — a wrong @mention pings the wrong person.

**Impact summary format** — shown at the Impact Summary step, NOT posted to Jira automatically:

```
## Cross-Module Impact — <STORY_KEY>
Evidence: [PR diff (N files) + graph | graph only | prose only]
Confidence: [High / Medium / Low]

| Module | Team | QA | Impact Type | What is affected |
|---|---|---|---|---|
| [Module] | [Team] | [QA — see QA ownership reference in analyzing-impact/SKILL.md, keyed by Team] | Direct / Transitive | plain-language flow/screen (`technical reference`) — business-language first, per analyzing-impact/SKILL.md's "What is affected" rule; never technical-only |

Overall Risk: High / Medium / Low — [one-line justification]
```

> **Note:** The impact summary produced here is condensed for pipeline use. Running `/analyzing-impact` as a standalone skill produces a richer output (bug-history signal, Confidence breakdown, Recommendations) — that additional context is not captured inline.

> **Posting ownership — no duplicate broadcasts.** This pipeline owns both destinations for a
> QA-stage story it runs: the Jira comment (execution results + Cross-Module Impact together, per
> Phase 3b/5) and the Slack broadcast below (impact only). If `/analyzing-impact` is ever invoked
> standalone for the same story — e.g. someone runs it manually mid-pipeline — its own Step 10 Slack
> post is skipped by design (see `analyzing-impact/SKILL.md`) precisely so it never duplicates this
> Phase 2.5 broadcast. Do not add a second Slack post from anywhere else in this pipeline for the same
> story/run.

## Impact Summary display

No interactive gate — the analysis (technical graph + linked PR where available) is the source of truth for blast radius; there's nothing for the user to manually add/remove that the analysis itself doesn't already have better evidence for. Present it as information and proceed automatically, always (this used to be interactive — `add`/`remove`/`done` — and only auto-proceeded under `--unattended`; it's unconditional now). **Print the whole table in the session right after `impact-summary.md` is written, and print it even when the Slack post is skipped: the tester reads it here. A one-line mention, or the file alone, is not the display.**

> **Cross-Module Impact — `<STORY_KEY>`**
>
> Based on analysis of this ticket (including the linked PR where available), the following modules are impacted:
>
> | Module | Team | QA | Impact Type | What is affected |
> |---|---|---|---|---|
> | [Module] | [Team] | [QA] | Direct / Transitive | plain-language flow/screen (`technical reference`) — business-language first, per analyzing-impact/SKILL.md's "What is affected" rule; never technical-only |
>
> **Inform the respective teams** so they can run a quick sanity check of their areas.
>
> ⚠️ This pipeline will **not** execute tests for these cross-module areas — each team is responsible for testing their own module.

## Slack posting

**No confirmation gate, never a blocker — and not deferrable.** Run the skip check and, if it doesn't
apply, build and send the message in the same turn you produce the impact summary — before moving on
to anything else in Phase 2.5 or Phase 3a. Confirmed 2026-09-24 (MXTS-77759): this step was reached
but not executed during a live pipeline run — the impact summary itself was correct (5 modules,
well past the broadcast threshold below) but no message was sent and no `[Impact]` log line was
emitted either way, until the user separately asked for the post by name. **Every branch below —
every skip and the send itself — ends with its own `[Impact]` log line; there is no silent branch.**
Treat the absence of any of those log lines as this step never having run — if you reach the end of
Phase 2.5 without one of these seven specific fragments logged for this step, go back and run it now,
don't silently carry on into Phase 3a: `not configured — Slack broadcast skipped`, `zero modules in
blast radius — Slack broadcast skipped`, `impact confined to own module`, `all owned by the same team`,
`MCMS-side finding(s), same QA as story's own team, no MXTS crossover`, `posted to Slack`, or `could not post to Slack`. **Do not accept the earlier `[Impact] <STORY_KEY> — <n> modules identified,
displayed, proceeding automatically.` line (Impact Summary display, above) as satisfying this check —
it logs before this Slack branch even runs, so it is present whether or not the send happened, and
using it as the signal is exactly how the MXTS-77759 failure mode goes undetected.**

Skip this entire step — no message built, no prompt of any kind — in any of these cases:
- `impact_slack_channel` is blank in Configuration. Log: `[Impact] <STORY_KEY> — impact_slack_channel not configured — Slack broadcast skipped.`
- The impact summary has zero modules in the blast radius (nothing meaningful to broadcast) — do not post an empty table. Log: `[Impact] <STORY_KEY> — zero modules in blast radius — Slack broadcast skipped.`
- **The blast radius is confined to the story's own module** — ALL of the following must hold: the `Module` column lists exactly one distinct value; that value is a confirmed canonical module (not `<finding> — canonical module unconfirmed, verify`); and it matches the story's own module (`components[].name` from Phase 1, step 3e). Skip **regardless of Confidence** — Low confidence about a finding that is still the ticket's own module is not a reason to alert other teams; there is no other team to alert. Log: `[Impact] <STORY_KEY> — impact confined to own module (<Module>) — Slack broadcast skipped.` The table is still shown in this step and still goes into the Jira results comment (Phase 3b/5) for review during ticket testing — only the Slack alert is skipped.
- **2+ distinct modules are found but every one is owned by the same single team** — ALL must hold: every `Team` value in the table (via the Module → Team ownership reference in `analyzing-impact/SKILL.md`) is the same, confirmed value (not `owner unconfirmed — verify`); and that team matches the story's own team/component. Multiple *module names* is not itself a cross-team hit — several areas of one team's own system don't produce one. Confirmed in production (MXTS-77020, Sep 2026): a cms-web dependency upgrade produced 4 distinct Module rows (MCMS rendering, search/filters, rich text editor, owner portal) all owned by the same team (`Web Manager - Development`: Sujata Pimpale/Amruta Jadhav), and the ticket's own Overall Risk line already said the blast radius "stays within Web Manager (MCMS)" — yet it still broadcast because the skip check only looked at Module-name uniqueness, never Team uniqueness. Log: `[Impact] <STORY_KEY> — <n> modules, all owned by the same team (<Team>) — Slack broadcast skipped.`
- **An MCMS/CMS-side story whose finding(s) never cross into MXTS** — even though the `Module` column will resolve as `unconfirmed, verify` on every row here (expected, not a gap: the canonical module list in `analyzing-impact/SKILL.md` is MXTS-only, so a `cms-web`/`cms-service`/`cms-mxts-gateway`/`cms-api` finding can never match one) — ALL of the following must hold: the story's own component/team is CMS/Web Manager; every row's `Team`/QA mention resolves, via the Team → QA ownership reference in `analyzing-impact/SKILL.md`, to that same CMS/Web-Manager team — this is what makes the row "confirmed" here, independent of the Module name itself; and every row's technical reference in `What is affected` names only CMS-side code (`cms-web`, `cms-service`, `cms-mxts-gateway`, `cms-api`/`cms-mxts-api`) — never an MXTS-side repo, `com.maxxton.*` package, or MXTS client. Skip regardless of Confidence, same reasoning as the other two conditions above — a story whose own QA already covers every impacted row has no other team to alert. Confirmed necessary (MXTS-82006, Sep 2026): a payment-page fix produced one `Impacted Modules` row ("CMS payment pages — canonical module unconfirmed, verify"), Team `Web Manager - Development`, QA `Sujata Pimpale`/`Amruta Jadhav` — the same people as the ticket's own team — yet it broadcast anyway, because the existing "unconfirmed, verify" language below was written for an MXTS-side unresolved owner (a genuine ambiguity) and didn't distinguish that from a CMS-side finding whose module can *structurally* never resolve to the MXTS-only canonical list, no matter how well-confirmed the Team/QA actually are. Log: `[Impact] <STORY_KEY> — MCMS-side finding(s), same QA as story's own team, no MXTS crossover — Slack broadcast skipped.`

> Changed 2026-08-12 (MXTS-78466): Confidence used to force a broadcast even when confined to the ticket's own module. Aparna Shinde flagged this as noise — her ticket was UI-only, scoped entirely to her own team's module, yet Low confidence alone pushed it to `#qa-all` anyway with nothing for any other team to act on. The core rule now is: **broadcast only when a genuinely different module is impacted; never merely because confidence is low.** Confidence still matters — see the `unconfirmed, verify` and differing-component cases below — but it no longer overrides an otherwise-confirmed own-module-only finding.

**Do NOT skip** — post even when the blast radius resolves to a single module or single team — when either holds, since each means a real *other* team may need to know:
- The single module/team found **differs from the story's own component/team** — still a real cross-team hit, just not one spanning multiple teams.
- The module, or (for the multi-module/single-team check) any one module's team, is `unconfirmed, verify` — an unresolved owner could be a different team's — **unless** the MCMS/CMS-side condition immediately above fully applies (Team/QA independently confirmed as the story's own team, no row touches MXTS); that condition exists specifically to distinguish "genuinely unresolved owner" from "resolved fine via Team, just never going to match the MXTS-only Module list" — but **any** row's technical reference naming an MXTS-side repo, package, or client overrides that exemption regardless of Team/QA match, since that's a real cross-system hit.

Otherwise (2+ distinct teams in the blast radius, or neither skip condition above is fully met) post the impact summary to `impact_slack_channel`, automatically — this is informational broadcast to the module teams, not a Jira write, so it needs no user confirmation (same reasoning as the rest of this step being non-interactive). See "Build the message" below for the exact format — a Markdown table, the same columns as the Jira comment.

> ⛔ **Immediately before calling `slack_send_message`, re-run the skip check above as an explicit yes/no — do not let momentum from having already written up the ticket's risk carry you into posting anyway.** Confirmed 2026-08-10 (MXTS-77623): a broadcast went out to `#qa-all` for a change the dev's own PR/spec scoped to one repo/module ("internal-only change narrowly scoped to VSI ranking") — the skip condition is documented above but wasn't re-checked at the moment of sending, and the message went out with an empty module table (there was nothing else to list), just the ticket header and risk line. If, right now, at the point of calling `slack_send_message`, the blast radius is confined to the story's own module OR every impacted module resolves to a single team (either skip condition above fully holds) — STOP. Do not build a message, do not send one. There is no partial/header-only post — either the full broadcast goes out because a real cross-team hit exists, or nothing goes out at all.

1. **Build the message by copying the `Impacted Modules` table verbatim out of `story.impact_summary`** — the same table already computed in "Producing the blast radius" above, character-for-character, not retyped or re-summarized from memory. **A real Markdown table, the same `| Module | Team | QA | Impact Type | What is affected |` columns as the Jira comment.** Slack's chat tool renders standard Markdown tables natively (`|`-delimited, unescaped) — confirmed via a live test message in `#core-qa-team` (2026-08-12) and matches Tuhina Gupta's MXTS-73837 broadcast, which rendered as a real table with a working in-cell mention.
   >
   > The earlier "one bullet per module" format is retired. Its second line (the "what is affected" detail) had no bullet or real indent of its own — Slack mrkdwn has no hanging-indent/continuation-line support for plain bullets — so it rendered flush-left, indistinguishable from the next line, and the whole block read as one dense run-on instead of a clear per-module breakdown. That's what looked broken about MXTS-78466's broadcast to Aparna Shinde (2026-08-12) — not the mention (it wasn't backtick-wrapped, so it resolved fine) and not the Module/Team pairing (`Channels` + `Third Parties - API` is the correct, documented pairing for `third-party-v2-service`/`tpi-*`, per the Repository → Module mapping in `analyzing-impact/SKILL.md`) — just the bullet-plus-continuation-line format falling apart visually. The *actual* root cause of the original missing-mention incident (MXTS-77438) was always a backtick-wrapped mention token, never table syntax — see below, and it applies identically inside a table cell.
   ```
   *Cross-Module Impact — <STORY_KEY>* — <ticket summary>
   <JIRA_BROWSE_URL><STORY_KEY>

   | Module | Team | QA | Impact Type | What is affected |
   |---|---|---|---|---|
   | [Module] | [Team] | [QA mention(s), copied verbatim from the QA ownership reference in analyzing-impact/SKILL.md — "—" if no match] | Direct / Transitive | [plain-language flow/screen] (`[technical reference]`) — business-language first, per analyzing-impact/SKILL.md's "What is affected" rule; never technical-only |

   Overall Risk: <High/Medium/Low> — <one-line justification>
   QA Pipeline Version: <qa-engineer plugin version, from plugin.json>
   ```
   > ⛔ **The code-fence markers above are for readability in this doc only — never post them.** The message text you send is everything *between* the fences, not the fences themselves. Wrapping the actual `slack_send_message` call's text in a triple-backtick code block would make Slack render the whole thing — table and `<@USERID>` mention included — as literal, unrendered code, the same failure this skill already warns against for a single mention token (MXTS-77438), just applied to the entire message instead of one word.

   The `QA` column: one `<@USERID>` per QA person from the QA ownership reference in
   analyzing-impact/SKILL.md, space-separated, written **directly with no backticks around it** —
   copied character-for-character from that table, never retyped or replaced with the person's name.

   > ⛔ **Do not wrap `<@USERID>` in backtick code-formatting in the actual message text** —
   > e.g. `` `<@U06N3TU2UTT>` ``, including inside a table cell. A backtick-wrapped mention sits
   > inside a code span, which Slack's mrkdwn parser does not resolve — it posts as literal,
   > unrendered text instead of a real @mention. This happened in production (MXTS-77438's
   > Cross-Module Impact broadcast, 2026-08-04) and required a manual correction/repost. Backticks
   > appear elsewhere in this skill's own documentation purely as *notation* to mark a token as
   > literal when talking about it — never copy that styling into the message body itself.

   > ⛔ **Verify the mention is actually in the string before sending — do not assume the lookup above made it in.** Confirmed 2026-08-10: an audit of 12 consecutive Cross-Module Impact broadcasts in `#qa-all` found **zero** contained a real QA-person `<@USERID>` mention — every one silently dropped or paraphrased the QA field into a plain name while the message text was being built, even though the ownership lookup itself was correct. Before calling `slack_send_message`, re-read the exact string you are about to send: for every module row where the QA ownership reference resolved ≥1 person, that literal `<@` mention token (copied verbatim from the ownership reference, whatever the ID prefix — usually `U`, but don't hard-assume it) must appear in the string, once per person — not paraphrased into a name, not silently omitted. If a resolved mention is missing, you dropped it while formatting — add it back before sending. A row with no match in the ownership reference correctly shows `—` and needs no mention; only a *resolved* row missing its mention is the bug.
   > ⛔ **A table that looks missing when you read a sent message back is not on its own proof the send was malformed.** Confirmed 2026-09-24 (MXTS-77759): a Cross-Module Impact message that `slack_read_channel`/`slack_read_thread` reported as header-only (no table) turned out, on inspection of the actual Slack UI in a browser, to contain the full 5-row table rendered correctly with working mentions — the read tools simply drop table content from their text summary of a message that has one. If you need to confirm what was actually posted, verify via a browser screenshot of the permalink, not the read tool's text summary.
2. **Post it directly** with `slack_send_message` to `impact_slack_channel` — no preview-then-confirm step; the config value itself is the opt-in, same as `auto_transition` and `slack_channel` elsewhere in this skill. On success, log: `[Impact] <STORY_KEY> — posted to Slack (<impact_slack_channel>)`.
3. **Fail open on ANY send failure, whatever shape the error takes.** Real Slack/MCP failures do not reliably arrive as a clean, recognizable auth code — a private-channel permission gap can come back as a generic "Internal Server Error" with no distinguishing detail at all (verified directly: drafting to a channel succeeded while sending to the same channel failed this way). So don't try to pattern-match the error text into "auth" vs "other" — treat every failure identically: log one line, `[Impact] <STORY_KEY> — could not post to Slack: <error>`, and continue straight into Phase 3a. Never retry, never ask the user to check/authenticate Slack, never block. This is a courtesy broadcast, not a gate — its failure must never be visible to the user as an interruption, only as a log line they can ignore.
