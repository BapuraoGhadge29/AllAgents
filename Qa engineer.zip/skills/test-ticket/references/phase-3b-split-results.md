# Phase 3b — Split Results Comment (more than 45 rows)

Read this only when the results table would be too long for one Jira comment (the limit is 32,767 characters): **rows = TCs that have a verdict × URL blocks, and rows > 45** — or the story's first-cycle Test Cases comment is already split into `tc_parts` (planned by length in Phase 2, so a story of 45 rows or fewer can be split too). Otherwise, 45 rows or fewer → post one comment exactly as the main Phase 3b reference says, and ignore this file.

If a comment of 45 rows or fewer still fails `CHECK 15` (very long rows), treat it as a split: plan with `--batch` (step 3 below) and continue here. A split changes only how the same results are cut into comments. Execution, verdicts, the Completeness gate, Evidence Review, triage and defects all run unchanged, over all TCs, before anything is posted. Every part keeps the exact format, columns, screenshots and validators of a normal results comment.

## 1. Plan once and persist it

Run after the Completeness gate and Evidence Review, before the screenshot uploads. Write the TC_IDs that have a verdict (all Phase 2 TCs, or the top N under `--max-tcs`), in Phase 2 table order, one per line to a temp file, then:

```bash
node "$CLAUDE_PLUGIN_ROOT/skills/test-ticket/scripts/result-parts.js" plan --ids-file <ids.txt> --urls <number of URL blocks>
```

- `"split": false` → one comment, stop reading this file.
- `"split": true` → store the printed `parts` array in `run-state.json` as `stories.<STORY_KEY>.result_parts` (`[{part, of, tc_ids, comment_id: null}, …]`) **before posting anything**.
- `result_parts` already present (resume after a crash or compaction) → reuse it unchanged. Never plan again: a second plan could cut the TCs differently and duplicate or drop some.

The rule behind the plan: parts of at most 40 rows in TC order; a last part under 10 rows is rebalanced with the one before it (46 TCs → 23 + 23, 60 → 40 + 20, 85 → 40 + 23 + 22). The script refuses a plan where any TC is missing, duplicated or out of order.

## 2. Screenshots and timing — once, for all parts

Run Step 1 of the main reference for every TC of every part, then capture `cycle_ended_at` once. Every part shows the same Test Execution Timing figure (the whole cycle, pause count included — `38m (2 pauses)` in every part), computed exactly as in the main reference. Compute the figure, Concern and Build / Version once and copy the same text into every part: the adoption dashboard counts parts with identical Concern, Build / Version and Timing as one run, so a value that differs in one part splits the run in two there.

## 3. Validate every part first, then post the parts one after another, in order

**Build and validate all `m` parts before posting part 1.** A part that trips the length guard (`CHECK 15`) or any other check is then found while nothing is posted yet, and re-planning (`plan --ids-file <ids> --batch 30`, replace the stored `result_parts`, rebuild) cannot leave parts of an old partition in Jira. Validation needs no credentials and no Jira call:

```bash
# script path (wiki markup): runs every check of the post, then prints OK without posting anything
node "$CLAUDE_PLUGIN_ROOT/skills/test-ticket/scripts/post-comment.js" "<STORY_KEY>" <body_file> --part n/m --tc-ids TC_01,TC_02,… --run-total <N> --validate-only
# MCP path (HTML): the same checks
node "$CLAUDE_PLUGIN_ROOT/skills/test-ticket/scripts/validate-results-comment.js" <body_file> --part n/m --tc-ids TC_01,TC_02,… --run-total <N>
```

Once any part is posted the plan is frozen: never re-plan after that. If a posted part later needs a change, correct that part in place (below).

For part `n` of `m` (skip a part whose `comment_id` is already set):

1. Build the body from the normal template, with these differences only:
   - The marker is the first non-empty line after the header, in exactly this form: `_Part n of m_` (wiki markup, script path), `<p>Part n of m</p>` directly after the heading (HTML, MCP path), `_Part n of m_` (markdown). Any other form or position is rejected, because the duplicate guard looks for that exact line. The `⚠️ PARTIAL RUN` line, when it applies, goes after the marker. The header line itself stays exactly `h2. QA Test Results`.
   - The TC table holds only this part's `tc_ids` (in every URL block of a multi-URL comment).
   - The stats table counts the **whole story**, so a reader sees at a glance how many of the story's TCs passed and failed without opening the other parts. Passed, Failed, Blocked, Needs Review, Skipped and Pass rate are computed from the verdicts of **all** the story's TCs (from `results.md`), never from this part's rows, so they are the same in every part and the five counts add up to the story total. **Total TCs** reads `<story total> (<first>-<last>)`: the story's TC count, then the TC numbers this part covers, e.g. `55 (1-30)` in part 1 and `55 (31-55)` in part 2. Concern, Environment, Build / Version, Preconditions, QA Pipeline Version and Test Execution Timing are as in a normal comment — and identical in every part (Concern, Build / Version and Test Execution Timing are what the reconcile step below compares).
   - Cross-Module Impact goes **only in part `m`** (the last), in its normal position. Parts `1…m-1` never carry it.
2. Validate and post with the part flags (`--tc-ids` is the part's `tc_ids`, comma-separated; `--run-total` is the story's TC count, the sum of the `tc_ids` lengths in `result_parts`, which is the plan's `total`):
   ```bash
   # script path — the 3rd/4th args are this part's comment_id (usually "") and cycle_started_at, as usual
   node "$CLAUDE_PLUGIN_ROOT/skills/test-ticket/scripts/post-comment.js" "<STORY_KEY>" <body_file> "<part comment_id or empty>" "<cycle_started_at>" --part n/m --tc-ids TC_01,TC_02,… --run-total <N>
   # MCP path — validate first, then post through addOrEditJiraIssueComment as in the MCP write path reference
   node "$CLAUDE_PLUGIN_ROOT/skills/test-ticket/scripts/validate-results-comment.js" <body_file> --part n/m --tc-ids TC_01,TC_02,… --run-total <N>
   ```
   Exit 1 → rebuild this part from the template the script prints and run it again. The validator blocks a part that misses a TC, contains a TC from another part, repeats a TC inside one URL block, lacks or mislabels the marker, carries Cross-Module Impact before the last part, or has stats that do not count the whole story (Total TCs not `<--run-total> (<first>-<last>)`, the five counts not adding up to `--run-total`, a count below what the part alone holds, a Pass rate that is not the story's). A part needs `--run-total`; without it the validator stops.
3. Persist the returned comment id **immediately** as `result_parts[n-1].comment_id` (and `results_comment_path`: `script` or `mcp`). The duplicate guard matches on this part's own marker, so a crash between the post and the persist is recovered by the `cycle_started_at` scan: it prints the id to record, and the part is not posted twice.
4. If a part fails to post after the usual single retry, stop. Do not post later parts. Log it, and list posted and unposted parts under ACTION REQUIRED in the Final Summary. A re-run resumes at the first part without a `comment_id`.

A part posted by the script path is corrected with `update-comment.js <STORY_KEY> <comment_id> <body_file> --part n/m --tc-ids … --run-total <N>`; an MCP-posted part through MCP (same-path rule). Both validate the part exactly as a post does.

## 4. Reconcile after the last part

```bash
# script path: reads every recorded comment back from Jira
node "$CLAUDE_PLUGIN_ROOT/skills/test-ticket/scripts/result-parts.js" reconcile --plan <result_parts.json> --story <STORY_KEY>
# MCP path: pass the body of each posted part, in part order (read through listJiraIssueComments)
node "$CLAUDE_PLUGIN_ROOT/skills/test-ticket/scripts/result-parts.js" reconcile --plan <result_parts.json> --body-file <part1> --body-file <part2>
```

`<result_parts.json>` is the stored `result_parts` array written to a temp file. It must print `OK — <n> TC(s) across <m> part(s), each exactly once.` Any other output means a TC is missing or doubled in Jira, or that Concern, Build / Version or Test Execution Timing differs between parts, or that a part's Total TCs, Passed, Failed, Blocked, Needs Review, Skipped or Pass rate is not what the TC rows of all parts add up to: report it under ACTION REQUIRED and correct the named part with the update path above. Then continue with the `QA_Pipeline` label.

## 5. New cycles

`--retest` and `--force` clear `result_parts` together with `results_comment_id` (see those flags in SKILL.md): a new cycle plans and posts fresh parts, and the earlier cycle's comments stay in Jira as history.

## 6. First cycle — the results go into the Test Cases parts

When the story's Test Cases comment is split (`tc_parts`), the first cycle plans and posts **no** separate results parts. Each Test Cases part is merged in place ([First cycle in the results reference](phase-3b-results-comment.md)); `result_parts` is the same plan as `tc_parts`, each `comment_id` being that Test Cases part's id.

1. **Per part:** `read-comment.js <STORY_KEY> <tc_parts[n-1].comment_id> --out <live_n.txt>`, then build the merged body: header `h2. QA Test Results`, the line `_Part n of m_` directly under it, the stats table (whole-story counts and `Total TCs` as in section 3), the merged 12-column table with only this part's rows, the footer, and the Extended section and Cross-Module Impact in the last part only.
2. **Validate all parts first, then update in order** — nothing is edited until every part passed. A part over 32,000 characters (`CHECK 15`) here means its evidence is longer than the plan allowed, and its Test Cases part can no longer be re-planned. Nothing is edited yet, so: shorten that part's `Actual result` cells to at most 300 characters, longest first (the full text stays in `execution-log.json`), and validate again. Still over → stop: edit no part, post no second results comment, and report the part number, its length and its TC ids under ACTION REQUIRED; the Test Cases comments stay as they are until the tester decides. Never drop a Test Proof image or change a kept Test Cases column to make it fit. MCP path: `validate-results-comment.js <part body> --part n/m --tc-ids <csv> --run-total <n> --previous <live part>`. Script path: `update-comment.js <STORY_KEY> <part comment id> <body_file> --part n/m --tc-ids <csv> --run-total <n>` (it checks the format and that nothing is lost; exit 1 sends nothing).
3. **Reconcile after the last part:** `result-parts.js reconcile --plan <result_parts.json> --story <STORY_KEY>`: every TC exactly once across the parts.
4. **Persist** `results_merged = true` after the last part. After a compaction, update only the parts whose comment still starts with `Test Cases —`; a part that already starts with `QA Test Results` and was updated at or after this cycle's `cycle_started_at` is done. One last updated before it belongs to an earlier cycle (`--retest` / `--force` keep `tc_parts`): never edit it, this cycle's results are new comments.
5. **`tc_parts` / `result_parts` lost after a compaction?** Rebuild the plan from Jira, never re-plan: list the story's comments, take those whose first line is `Test Cases — <STORY_KEY>` or `QA Test Results` and that carry a `_Part n of m_` line, order them by `n`; each comment's id is the part's `comment_id` and the TC ids in its table are the part's `tc_ids` (`result-parts.js` reads them the same way for `reconcile`). The count of parts found must equal `m`; fewer means a part was never posted — post only that one.

## Test Cases comment (Phase 2) — same split, same checks

The Phase 2 Test Cases comment (10 columns, so longer rows than the results table) is split into parts too, and **it is sized for what it becomes**: after execution the same comments are edited in place into the results, and a merged row is longer still (Actual result, Status, and the Test Proof — in HTML an embedded screenshot is a long media node). Parts are fixed once posted, so a part that is too long after the merge could not be merged or re-planned. Therefore the parts are planned **by length**, not by a fixed 40 rows (step 1). With realistic text this means about 15 TCs per part on the MCP/HTML path and about 30 on the script (wiki) path; a story of 20 TCs can already be two parts. A story whose whole merged comment fits one Jira comment (and has at most 45 rows) stays one comment.

1. **Plan once, before posting.** Write the TC_IDs of the final table (after Gate 1 and Gate 2, main TCs only; accepted human additions are planned with `--extended <E>` — see item 6), in table order, to a temp file and run `result-parts.js plan --ids-file <ids.txt> --merged-from <draft.txt>`, where `<draft.txt>` is the whole drafted Test Cases body (all rows, unsplit, wiki, markdown or HTML): the parts are cut from the real row lengths so that each part still fits one Jira comment (32,000 characters) AFTER the results are merged into it, balanced, at most 40 rows. The plan JSON carries `estimated_chars` per part and `row_allowance_chars`, the allowance for what execution adds to a row. That allowance is typical, not a worst case, so each part is filled to 85% of the limit as headroom, and a story with heavy evidence (multi-item TCs, Before/After pairs, several screenshots per TC) adds `--extra-per-row 1600` (HTML) or `700` (wiki); a value below the default is refused. `--merged-from` cannot be combined with `--extended`, `--batch` or `--urls`: for a comment with human-added cases run the `--merged-from` plan on the main rows, then `plan --ids-file <main ids> --extended <E> --batch <size of its largest part>`. `"split": true` → store the `parts` array in `run-state.json` as `stories.<STORY_KEY>.tc_parts` before the first post. Already stored (resume) → reuse it, never plan again.
2. **Build and validate every part first, then post the parts in order** (validate with `post-tc-comment.js … --part n/m --tc-ids … --validate-only`, or `validate-results-comment.js … --kind tc` on the MCP path; neither posts anything). Each part is a full Test Cases comment: header `h2. Test Cases — <STORY_KEY>` (MCP path: `## Test Cases — <STORY_KEY>`), then the marker line `_Part n of m_`, then only this part's TC rows, and the italic footer (`AC coverage` as for the whole story, `Automate: <n> Yes / <m> No` for this part's rows). Use `post-tc-comment.js <STORY_KEY> <body_file> --part n/m --tc-ids <csv>`; on the MCP path run `validate-results-comment.js <body_file> --kind tc --story <STORY_KEY> --part n/m --tc-ids <csv>` first and apply the duplicate guard per part (a comment whose first line is the Test Cases header and that carries this part's marker line). Persist each returned id as `tc_parts[n-1].comment_id` immediately. A failed part stops the run of posts (no later part), is reported under ACTION REQUIRED, and a re-run resumes at the first part without an id.
3. **Correct a part in place** with `update-tc-comment.js <STORY_KEY> <comment_id> <body_file> --part n/m --tc-ids <csv>` (MCP path: edit through MCP, validated the same way).
4. **Reconcile after the last part:** write `tc_parts` to a temp file and run `result-parts.js reconcile --plan <tc_parts.json> --story <STORY_KEY>` (MCP path: `--body-file` per part, in order). Same rule as the results parts: every TC exactly once.
5. **Length guard.** Any body over 32,000 characters (HTML included) fails validation (`CHECK 15`) before Jira can reject it. Because every part is validated before the first post, re-plan with a smaller batch (`plan ... --batch 30`), replace the stored `tc_parts`, and rebuild — never after a part is posted.
6. **Extended cases** (`extend-tc-comment.js`: human-added cases at Gate 1, or later via `--extend`) are supported on a split Test Cases comment, in the **last part only**. The Extended section counts toward the row limit, so plan with them: `result-parts.js plan --ids-file <main ids> --extended <E>` (E = the accepted additions) reserves their ids (TC_<max+1> …) in the last part's `tc_ids` and keeps main rows there (60 main + 5 extended → 40 + 25 = 20 main + 5 extended; 40 + 10 → 20 + 30). Then build the last part's normal body and run `extend-tc-comment.js <body> <entries.json> <out> --main-total <number of main TCs of the whole story>`: "Claude generated" and the miss rate count all main TCs, not just that part's rows (the script refuses any part but the last, and a missing `--main-total`). Validate and post every part as usual; the last part's validator call also takes `--main-total`. The extended ids must equal the ids `plan` reserved (the script prints the ids it added). **Adding extended cases later, to a comment that is already posted in parts:** run the same script on the last part's current body (get it from Jira), append the printed new ids to that part's `tc_ids` in the saved plan, and correct that comment in place with `update-tc-comment.js … --part m/m --tc-ids <the part's updated ids> --main-total <n>`; if the longer last part trips `CHECK 15`, the case cannot be added to this comment (the other parts are already posted): tell the user.
7. **Readers:** everything that reads the TC table from Jira (resume check, Automation Derivation, the Phase 3a Completeness gate) reads every part and merges the rows; a missing part means the comment is incomplete.
