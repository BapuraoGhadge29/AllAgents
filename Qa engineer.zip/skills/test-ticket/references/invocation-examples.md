# Invocation Examples

## Single and Multi-Epic Usage

```
# Single Epic — full run
/test-ticket MXTS-12345 https://app.example.com

# Single Epic — no URL → runs Generation only mode automatically, no prompt
/test-ticket MXTS-12345

# Multiple Epics — each with its own URL
/test-ticket MXTS-12345 https://mqa-dev.maxxton.net MXTS-67890 https://rcn-dev.maxxton.net

# Multiple Epics — one shared URL (all Epics inherit it)
/test-ticket MXTS-12345 MXTS-67890 https://rcn-dev.maxxton.net

# Multiple Epics — first Epic has own URL, second inherits it
/test-ticket MXTS-12345 https://mqa-dev.maxxton.net MXTS-67890

# Force re-run from scratch (applies to all Epics)
/test-ticket MXTS-12345 MXTS-67890 https://rcn-dev.maxxton.net --force

# Retest after a fix (applies to all Epics)
/test-ticket MXTS-12345 MXTS-67890 https://rcn-dev.maxxton.net --retest
```

## Multi-Epic URL Inheritance — Resolved Examples

```
MXTS-76746 MXTS-75065 https://rcn-dev.maxxton.net
→ MXTS-76746: https://rcn-dev.maxxton.net (inherited)
→ MXTS-75065: https://rcn-dev.maxxton.net (own)

MXTS-76746 https://mqa-dev.maxxton.net MXTS-75065
→ MXTS-76746: https://mqa-dev.maxxton.net (own)
→ MXTS-75065: https://mqa-dev.maxxton.net (inherited)

MXTS-76746 https://mqa-dev.maxxton.net MXTS-75065 https://rcn-dev.maxxton.net
→ MXTS-76746: https://mqa-dev.maxxton.net (own)
→ MXTS-75065: https://rcn-dev.maxxton.net (own)
```
