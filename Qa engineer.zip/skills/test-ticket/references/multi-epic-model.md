# Multi-Epic Execution Model

## Batched Sequential Diagram

```
┌─────────────────────────────────────────────────────────┐
│  BATCH 1: PHASE 1 + 2  →  ALL Epics in sequence         │
│  (API-only: Jira/Confluence reads + TC generation)       │
│  Complete all Epics' Phase 1+2 before any 3a starts      │
└──────────────────────┬──────────────────────────────────┘
                       │  all Epics ready
                       ▼
┌─────────────────────────────────────────────────────────┐
│  PHASE 2.5 + EXECUTION  →  one Epic at a time (browser) │
│  Epic 1: 2.5 → Impact Summary → 3a → 3b → 4 → 5        │
│  Epic 2: 2.5 → Impact Summary → 3a → 3b → 4 → 5        │
│  Epic 3: 2.5 → Impact Summary → 3a → 3b → 4 → 5        │
└─────────────────────────────────────────────────────────┘
```

Each Epic runs Phase 2.5 (impact analysis) then fully completes Phases 3a → 3b → 4 → 5 before the next Epic starts.

## Queue Log

Log at the start of Phase 3a:
```
[Phase 3a] Execution queue: MXTS-76746 → MXTS-75065 → MXTS-12345
           Each Epic will fully complete 3a→3b→4→5 before the next starts.
```

Log when an Epic completes and the next begins:
```
[Epic complete] MXTS-76746 — Phases 3a–5 done. Starting MXTS-75065.
```
