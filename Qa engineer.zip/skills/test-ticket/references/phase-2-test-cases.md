# Phase 2 — Generate Test Cases (full procedure)

**Known-limitation match check (runs for every story, every pass — before anything else below, regardless of which path this story takes):** If `story.known_limitations` (Phase 1, step 3j) is non-empty, match each entry's `behavior` against the TC table's scenario text — the existing table if one is already posted (the "QA-stage stories with existing TC comment" path below never rewrites it), or the table about to be generated otherwise. A match doesn't change the TC's Expected Result or any column — the fixed 10-column format stays exactly as-is — it's a heads-up logged now so it's visible before Phase 3a executes, not a surprise after: `[Phase 2] <STORY_KEY> — <TC_ID> may match known limitation documented by <author> (<date>): <behavior>.` No match for any TC → log nothing. Phase 3a's Known-Limitation Check (in [the Phase 3a execution reference](phase-3a-execution.md)) is what actually decides `SKIP` against the TC's real executed behavior — this step only surfaces the possibility early.

**Bill-recalculation check on an existing TC comment (every pass, only when the TC table is already posted — the path below that never rewrites it):** count the TCs whose steps save a change to what a reservation is charged (override rates, add-on, offer/voucher/discount, dates, accommodation, unit, guests, a status that reprices) but contain no `Recalculate reservation` step. Any → log `[Phase 2] <STORY_KEY> — <n> bill-changing TC(s) in the existing TC comment have no Recalculate step (<TC_IDs>); comment not rewritten, Phase 3a records before/after without one.` Nothing is added to the table and no gate is raised; correct the comment in place with `update-tc-comment.js` when the steps should be in it. None → log nothing.

For each story, apply the following based on stage:

**Development-stage stories:**
1. Derive steps and preconditions from story content
2. Generate high-level scenarios table
3. Expand into detailed test case table — **10 columns:** `TC_ID | Test case scenario | Preconditions | Test steps | Expected Result | Actual result | Story number | Epic number | Automate | Risk`. Set defaults:
   - Actual result: `To be Tested`
   - Story number: story key (e.g. `MXTS-12345`)
   - Epic number: Epic key from Phase 1 (e.g. `MXTS-60001`); `N/A` if not present
   - Automate: set after Gate 2 — `Yes` for TCs not excluded from automation, `No` for TCs in `tc_skip_automation`

   > ⛔ **Expected Result must state a single, unambiguous, objectively-checkable outcome — never pre-classify a potential deviation as non-blocking.** Do NOT write phrasing like "...recorded as finding", "...if present", "...noted as observation", or any wording that decides in advance that a deviation will be soft/optional. That decision belongs to verdict determination in Phase 3a (which already forces `NEEDS REVIEW` for any design-fidelity deviation), not to the TC's own wording. If a scenario covers a known design-fidelity risk (e.g. "no unapproved UI elements"), write the Expected Result as a plain pass/fail check — e.g. "Only the 3 approved filter options are shown, no other elements" — not a soft catch-all.
4. **Risk column — apply in priority order:**
   - **Step 1 — Critical path override:** Scan TC scenario text against the `critical_paths` keyword list in Configuration above. Match keywords as **whole words only** — "login" must appear as a standalone word in the scenario text, not as part of another word (e.g. "login page font" does NOT match). Any whole-word match → risk = `High` unconditionally.
   - **Step 1b — Same-feature-area inheritance:** If the TC is a structural variation (search, cancel/discard, persistence-after-save, boundary, API-payload spot-check, control-state gating/transition, or similar) of another TC in the same functional area that already got `High` from Step 1 → inherit `High`, even though this TC's own text doesn't repeat the keyword. The whole feature area carries the criticality, not only the literal row containing the word. Only fall through to Step 2 when the TC is genuinely unrelated to any Step-1-flagged scenario in the same area.
   - **Step 2 — Standard heuristic (if no match and no Step 1b inheritance):** High = core business flow/data loss/authorization; Medium = edit/search/error/boundary; Low = cosmetic/view-only.
   - **Step 3 — Developer-flagged major impact (after Steps 1–2):** If `story.dev_qa.major_impact` is `Yes` (Phase 1 step 3l), raise every TC that ended `Low` to `Medium`. It never lowers a risk and never touches `High`/`Medium` TCs. Log once: `[Phase 2] <STORY_KEY> — developer flagged Major Impact: Yes; <n> Low TC(s) raised to Medium.` Skip silently when `dev_qa` is null or `major_impact` is not `Yes`.
5. Identify coverage gaps and compute AC coverage: for each AC, check ≥1 TC targets it. Record `ac_coverage = <covered>/<total>`. Include count in Jira comment footer. If `ac_coverage_threshold > 0` and `(covered/total * 100) < ac_coverage_threshold` → log a warning: `[Phase 2] <STORY_KEY> AC coverage <n>% below threshold <threshold>% — generation continues but flag for review.`

5a. **Frontend text/copy check — auto-added TC (`Improvement` and `New Feature` tickets only):** If the story's `issuetype` is `Improvement` or `New Feature` AND `story.impl_context` (Phase 1, step 3) or the description names specific new or changed frontend text — a label, button, message, tooltip, heading, or any other user-facing copy — add one additional TC to the table before Gate 1:
   - If the ticket quotes the exact new/changed text → `Verify the text "<exact text from ticket>" on <screen/flow> is grammatically correct, free of typos, and matches the ticket's approved copy exactly`.
   - If the ticket only describes the change without quoting the actual copy → `Verify the newly added/changed text on <screen/flow> is grammatically correct and free of typos`.
   - Risk: `Low` by default; `Medium` if the screen/flow matches the `critical_paths` keyword list (same whole-word rule as the Risk column above).
   - Skip entirely if the ticket makes no frontend text change (e.g. a purely backend/API change) — do not force this TC onto every `Improvement`/`New Feature` ticket regardless of content.
   - This TC does not need to map to a specific AC — it is scope QA adds independently of `ac_coverage`.

   Log: `[Phase 2] <STORY_KEY> — frontend text change detected, added grammar-check TC (<TC_ID>).` Skip silently (no log line) when no frontend text change is present.

5b. **Location/resort-variation check — auto-added TC (any `issuetype`, scoped by feature domain):** If the story's feature displays or manipulates resort/location-scoped data — detected via `story.impl_context` (Phase 1, step 3), the description, or `components[]` naming a location-scoped module/flow (scheduling, work schedule, planning dashboard, housekeeping, resource/staff allocation, availability, rates, resort/unit filters or listings) — or the scenario text matches the `critical_paths` keyword list as whole words (`resort`, `resource allocation`, `reallocation`) — add one additional TC to the table before Gate 1:
   - Scenario: `Verify <primary scenario from TC_01 / the story's main AC behaviour> holds when tested against a second, different location/resort — not just the default/first location.`
   - Test steps: switch the location/resort selector to a second, different resort with representative data, then repeat the primary TC's steps in that context.
   - Preconditions: note that a second resort/location with representative data must exist (may require seed data there — same `QA-SEED-` mechanism as any other precondition).
   - Risk: inherit the primary TC's Risk (usually `High`/`Medium` — a data-dependent state bug found only in a second location is as real as one found in the first).
   - Skip entirely if the ticket explicitly scopes itself to a single location/global setting (e.g. an "Out of scope: multi-location" note, or the feature has no location dimension at all — account settings, a generic component with no resort-scoped data). Do not force this TC onto every ticket regardless of domain.
   - This TC does not need to map to a specific AC — it is scope QA adds independently of `ac_coverage`.
   - Distinct from **Multi-URL execution** (Phase 3a) — that varies *environment* (mqa-dev vs rcn-dev); this varies *resort/location data* within one environment. Both can apply to the same story independently.

   Log: `[Phase 2] <STORY_KEY> — location-scoped feature detected, added location-variation TC (<TC_ID>).` Skip silently (no log line) when the feature has no location dimension.

5c. **Pre-output self-check (mandatory) — same as `/generating-test-cases` Step 5.** Before Gate 1, confirm at least one row exists for each unconditional-trigger group whose condition applies to this story: Data persistence (for derived-display fields — dropdown/select/multi-select/lookup-mapped — a *pair*: full-reload row AND back/collapse-navigation row for the same value; one row covering only one path is a self-check failure for that field. Plain scalar fields need only the single reload row. See `generating-test-cases/SKILL.md` Step 4.), API payload spot-check, Cancel/discard without saving, Search (if a dropdown/typeahead/searchable list is involved), Conditional mandatory field / control-state gating (if any field/control is conditionally required), Feature flag gating (if `story.feature_flags` from Phase 1 step 3f is non-empty), Confirmation dialog gating (if any irreversible/destructive action shows a confirm dialog), Bill recalculation (if any TC saves a change to what a reservation is charged — every such TC carries the recalculate and compare steps), and the change-type groups — **UI text localisation** (`story.change_types` contains `i18n`), **API / backend-only** (`api_only`), **Cross-service** (`multi_repo`), **Widget / admin-configured** (`widget`) — set by Phase 1 step 3m. A group whose trigger fired but produced zero rows is a self-check failure — generate it now, using the group's own trigger condition and row-template wording as defined in `generating-test-cases/SKILL.md` Step 4 (the canonical source for these groups — this reference does not duplicate them, so read that skill's Step 4 if a definition is needed here). Log: `[Self-check] persistence: <n> | API-payload: <n> | cancel: <n> | search: <n or n/a> | control-gating: <n or n/a> | flag-gating: <n or n/a> | confirm-dialog: <n or n/a> | bill-recalc: <n or n/a> | i18n: <n or n/a> | api-only: <n or n/a> | cross-service: <n or n/a> | widget: <n or n/a>`.

5d. **Developer QA bullet cross-check (only when `story.dev_qa` is non-null — Phase 1 step 3l):** the developer's own Main Tests are a list of things they consider must be checked. For each `dev_qa.main_tests` bullet, check by meaning (not by wording) that at least one TC in the table would exercise it. A bullet no TC covers → keep a list `dev_qa_uncovered`, and show it in the same message as the Gate 1 table: `Developer's QA bullets not covered by any TC: <bullet> …`. Never auto-add a TC for it — Gate 1's `add <TC description>` is the way — and never remove a TC because the developer didn't list it. Log: `[Phase 2] <STORY_KEY> — dev QA bullets: <n> total, <n> uncovered.` Under `--unattended`/`--auto-specs` (Gate 1 skipped) the log line is the only output.

5e. **Bug video repro (only when `story.video_findings` is non-null — Phase 1 step 3o):** at least one TC must replay the repro steps as the video shows them, in the same order, with the expected result "the defect no longer occurs". If none of the generated TCs does, add one (Risk `High`) and log `[Phase 2] <STORY_KEY> — added repro TC from the ticket video (<TC_ID>).` Write the steps generically — no customer names, e-mail addresses or amounts from the recording.

6. **Gate 1 — Scenario Review Gate** — display the full TC table, then ask the user directly. The user can only remove or add what they can see: the table must be in the **same message** as the question — every TC as its own row (`TC_ID | Test case scenario | Expected Result | Risk` at minimum), never a count, a TC-ID range ("TC_01–TC_06"), or a prose summary of what the TCs cover ("covering the rename flow, regression, multi-locale…"). A summary may follow the table as context; it never replaces it. This holds whichever tool asks the question — a question tool that shows only its own text needs the table inside that text, or in a message sent immediately before it. Self-check before sending: the number of table rows equals the number of TCs generated, including auto-added 5a/5b rows. If the table is not in the message, do not ask yet — print it first. If 5d found uncovered developer bullets, list them right after the table (context, never a replacement for the rows).
   > Which test case scenarios do you want to **remove** from `<STORY_KEY>`? Enter TC IDs separated by commas (e.g. `TC_01, TC_05`), or `none` to keep all.
   >
   > You can also reply with:
   > - `add <TC description>` — Claude first answers yes/no (accepted / already covered / declined; `insist <n>` overrides a no). Accepted cases are **not** merged into the main table — they are listed under **Extended cases added after Human review**, so the human-added share is tracked: [the Extended Cases reference](${CLAUDE_PLUGIN_ROOT}/skills/generating-test-cases/references/extended-cases.md)

   After each `remove` or `add`, re-display the updated table and ask again until the user replies `none` (keep as-is) or confirms no further changes.

   `--unattended` or `--auto-specs` → skip gate, keep table as-is.

6a. **Automation duplicate check (before Gate 2, runs only when a base URL is present)** — prevents Phase 6 from generating a second spec for a TC someone already automated. Skip entirely in Generation only mode (no URL, nothing to search against — `story.tc_already_automated = []`).
   1. `target_repo` was already resolved in Pre-flight ("Target repo detection" — `mcms-qa-automation` for a `cms` hostname, `mxts-qa-automation` otherwise). Reuse it here; do not re-derive.
   2. For each finalised TC, call `search_code` scoped to `repo:MaxxtonGroup/<target_repo> extension:js path:tests/modules <keywords>`, using 2–3 distinguishing keywords from the TC's scenario/entity name (the entity + action, e.g. `archive case`, not generic words like "verify" or "test"). **Use `extension:js`, never `extension:spec.js`** — GitHub's `extension:` qualifier matches only the final file extension, so a real spec file named `TC_01.spec.js` has extension `js`, not `spec.js`; `extension:spec.js` silently matches nothing and this check would always report zero existing automation.
   3. A search hit is a **candidate**, not a confirmed duplicate — fetch it with `get_file_contents` only if the snippet is ambiguous, and compare its test name / `test.step()` descriptions against this TC's scenario text for a genuine semantic match (same entity, same action, same condition), not just keyword co-occurrence.
   4. A genuine match → add the TC_ID to `story.tc_already_automated` (list) with the matched file path. This does **not** go into `tc_skip_automation` — the TC is genuinely automated, so its `Automate` column stays `Yes`; it only means Phase 3b must not generate a second spec for it (see step 8 below).
   5. `search_code` unreachable/erroring → log a warning and treat every TC as not-yet-found (fail open on availability — a missed search never silently causes a duplicate spec to be *skipped*; it just means this run may end up generating one Phase 6's duplicate-PR guard and a human reviewer would still catch). Do not block the pipeline over this.
   6. Persist `story.tc_already_automated` **and** `story.tc_already_automated_repo` (the `target_repo` this list was searched against) to `run-state.json` immediately. Log: `[Automation] <STORY_KEY> — <n> TC(s) already automated in <target_repo>: <TC_IDs>.` (or `— no existing automation found in <target_repo>.` if empty).

   > A manually-maintained "Automated?" tracking sheet is a second candidate signal for this same check — not wired in yet, pending a decision on where it lives (Google Sheet / Excel / Confluence). Until then, this repo search is the only duplicate-detection source.

7. **Gate 2 — Automation Exclusion Gate** — once the TC table is finalised (Gate 1 done) and the duplicate check above has run, ask the user about the **remaining** TCs only (exclude anything already in `story.tc_already_automated` from this prompt — asking to exclude a TC that's already automated elsewhere is a pointless question).

   **No remaining TCs (every TC already in `story.tc_already_automated`)** → skip the ask entirely, there is nothing left to exclude. Persist `story.tc_skip_automation = []` and log: `[Automation] <STORY_KEY> — all <n> TC(s) already automated in <target_repo>; Gate 2 skipped, nothing to ask.` Proceed to step 8 below.

   Otherwise, ask:
   > **Automation — `<STORY_KEY>`**
   >
   > <if `story.tc_already_automated` is non-empty, print this line first:> `<n> TC(s) already have a Playwright spec in <target_repo> — <TC_IDs> — no new spec will be generated for these.`
   >
   > <then list every remaining TC as `TC_ID — Test case scenario` (one per line) — the user picks IDs from this list, so IDs alone are not enough:>
   >
   > Which of the remaining TCs should be excluded from automation?
   >
   > | Type this | To do this |
   > |---|---|
   > | `TC_03, TC_07` | Exclude specific TCs from automation |
   > | `none` | Automate all TCs |
   > | `skip automation` | Skip automation for all TCs |
   >
   > ℹ️ Excluded TCs are still **executed** in Phase 3a — only the Playwright spec file won't be generated for them.

   Store the response as `story.tc_skip_automation` (list of TC_IDs, from the remaining TCs only — never re-adds a TC already in `tc_already_automated`). `skip automation` → all remaining TCs: `Automate = No`. **Immediately persist it to `run-state.json`** under this story — it must survive compaction so it is never re-prompted mid-run.

   `--unattended` or `--auto-specs` → skip gate, set `story.tc_skip_automation = []` (automate all remaining TCs — `tc_already_automated` is unaffected either way).
   `--skip-specs` → skip gate, set `story.tc_skip_automation` to **every remaining** TC_ID (equivalent to a manual `skip automation` response) — no *new* spec files are generated for this story at all.

   > This gate is now the **only** place spec generation is decided for TCs not already covered by the duplicate check — there is no separate "generate specs for this run?" ask later. Whether a TC gets a new Playwright spec follows directly from: in `tc_already_automated` → no (one already exists); else in `tc_skip_automation` → no; else → yes. Phase 3a captures selectors for exactly the TCs that will get a new spec (see Phase 3a).

8. **Set `Automate` column from Gate 2 + duplicate check results** — for every TC in the finalised table:
   - TC is in `tc_already_automated` → `Automate = Yes` (genuinely automated already — Phase 3b generates no new spec for it)
   - TC is **not** in `tc_skip_automation` (and not already-automated) → `Automate = Yes` (Phase 3b generates a new spec)
   - TC **is** in `tc_skip_automation` → `Automate = No`

9. Write the 10-column TC table body to a temp file in wiki markup, then post it with the path in `jira_write_path` (script path below; the MCP path has its own block after the template). Persist the returned comment ID as `tc_comment_id` and the path that created it as `tc_comment_path` (`script` | `mcp`):

```bash
node "$CLAUDE_PLUGIN_ROOT/skills/test-ticket/scripts/post-tc-comment.js" "<STORY_KEY>" <body_file>
# Exit 1 = validation failed → rewrite body using the exact template below, retry.
# Exit 0 + comment ID = success. Store comment ID (and tc_comment_path = script) for potential update-tc-comment.js call later.
```

Body must use **exactly** this wiki markup format — no variation:

```
h2. Test Cases — <STORY_KEY>

|| TC_ID || Test case scenario || Preconditions || Test steps || Expected Result || Actual result || Story number || Epic number || Automate || Risk ||
| TC_01 | … | … | … | … | To be Tested | <STORY_KEY> | <EPIC_KEY or N/A> | Yes/No | High/Medium/Low |

_AC coverage: <covered>/<total> | Automate: <n> Yes / <m> No_
```

> ⛔ **A table that would not fit one Jira comment after execution is posted as several comments (parts), not one.** The 10-column rows are long, the same comment is later merged with its results (longer rows), and Jira rejects a comment over 32,767 characters. A story of more than 45 TCs is always split; a shorter one is split when its drafted rows are long (`result-parts.js plan --merged-from <draft>` decides, see the split results reference). Plan the split once, post each part with `post-tc-comment.js ... --part n/m --tc-ids ...` (MCP path: validate with `--part` too), persist the ids in `run-state.json` as `tc_parts`, and finish with the reconcile check — all in the "Test Cases comment" section of [the split results reference](phase-3b-split-results.md). 45 TCs or fewer → one comment as below.

> ⛔ **Format is fixed.** Header must be exactly `h2. Test Cases — <STORY_KEY>`. Use wiki markup (`h2.`, `|| col ||`) — NOT Markdown (`##`, `| col |`) — on the script path. Do NOT omit the italic footer. Do NOT add extra columns, sections, or narrative prose — the one allowed addition is the `h3. Extended cases added after Human review` section, appended by `extend-tc-comment.js` when a human added cases (never typed by hand).

**Human-added cases at Gate 1:** when the reviewer's `add` requests were accepted (or overridden), first count the rows: **main TCs plus the accepted additions more than 45** → the comment is posted in parts and the Extended section goes in the **last part**: plan with `result-parts.js plan … --extended <accepted count>` and run `extend-tc-comment.js` on the last part's body with `--main-total <main TC count>`, as described in item 6 of the "Test Cases comment" section of [the split results reference](phase-3b-split-results.md). **45 rows or fewer** → write the main body as usual, then run `extend-tc-comment.js` on it with the Gate 1 decisions (set each accepted row's `automated` from the Gate 2 result) and post the output — the posted comment then carries the **Extended cases added after Human review** section with its counts and miss rate. Afterwards run `run-metrics.js human-review` for the story. Procedure, entries format and the validators that enforce it: [the Extended Cases reference](${CLAUDE_PLUGIN_ROOT}/skills/generating-test-cases/references/extended-cases.md).

**MCP write path (`jira_write_path = mcp`):** the same table and wording as markdown — header `## Test Cases — <STORY_KEY>`, a pipe table with the ten column names above, the italic footer — posted with `addOrEditJiraIssueComment` (`contentFormat: markdown`). **Exception — more than 5 TCs (counting the TCs of this part, for a split comment) and no Extended-cases section: post it as HTML (`contentFormat: html`) so the table sits in a collapsed expand:** `<h2>Test Cases — <STORY_KEY></h2>`, `<details><summary>Test cases (<N>)</summary><table>…</table></details>`, the italic footer `<p><em>AC coverage: <c>/<t> | Automate: <n> Yes / <m> No</em></p>`, the same ten column names, and the Test steps as plain text in a `<p>` (`1. … 2. …`), never a list. Validate it with `--kind tc --story <STORY_KEY> --format html` (CHECK 19: more than 5 rows must be in `<details>`, 5 or fewer must not). The Extended-cases section is not supported in the HTML form (`extend-tc-comment.js` writes wiki and markdown only): a comment that has one, and any comment of 5 TCs or fewer, stays markdown with a plain table. The script path (wiki markup) always posts a plain table. The MCP has no server-side guard, so before posting:
1. **Validate the body:** `node "$CLAUDE_PLUGIN_ROOT/skills/test-ticket/scripts/validate-results-comment.js" "<body_file>" --kind tc --story "<STORY_KEY>"` — exit 1 prints the canonical markdown template (rebuild from it, never from memory) and the violations (header and story key, ten columns, footer, no execution verdicts). Save the body with the Write tool and read it back only with the Read tool — PowerShell's plain `Get-Content` turns `—` into `â€”`; the validator rejects that (CHECK 0).
2. **Duplicate guard:** with no `tc_comment_id` in `run-state.json`, list the story's comments (`listJiraIssueComments`, every page) and look for one whose whole first line is `h2. Test Cases — <STORY_KEY>` or `## Test Cases — <STORY_KEY>` with **this** story's key (a Test Cases comment for another key is not this story's and is ignored), **or the same comment after execution**: first line `QA Test Results` with the 12-column table (Preconditions, Test steps … Status, Test Proof) — the results were merged into it, so the test cases are posted. Found → record its id and path (`script` for the `h2.` form, `mcp` otherwise) and do not post again (a crash happened between the post and the persist). The listing failed → do not post. Not found → post.
3. Persist the returned `commentId` as `tc_comment_id` and `tc_comment_path = mcp` immediately.

10. **Add `HL-Scenarios_Covered` label** — run `node "$CLAUDE_PLUGIN_ROOT/skills/test-ticket/scripts/add-label.js" "<STORY_KEY>" "HL-Scenarios_Covered"` (or, when `jira_write_path = mcp`, its MCP fallback: `getJiraIssue` for `fields.labels`, then `editJiraIssue` with the full merged array). The script reads current labels from the API and appends — never replaces.

**QA-stage stories with no existing TC comment (first-time run):**
- Run steps 1 through 5c above (1, 2, 3, 4, 5, 5a, 5b, 5c, in that order) — generate the full TC table.
- Apply Gate 1 (Scenario Review Gate) and Gate 2 (Automation Exclusion Gate) exactly as for development-stage stories above. Store `story.tc_skip_automation` from Gate 2.
- Post the 10-column TC table using `post-tc-comment.js` (or `addOrEditJiraIssueComment` on the MCP path, as in step 9) with the same format as step 9 above (script path: wiki markup; MCP path: the markdown form with its validator and duplicate guard).
- **Add `HL-Scenarios_Covered` label** — run `node "$CLAUDE_PLUGIN_ROOT/skills/test-ticket/scripts/add-label.js" "<STORY_KEY>" "HL-Scenarios_Covered"` (or, when `jira_write_path = mcp`, its MCP fallback: `getJiraIssue` for `fields.labels`, then `editJiraIssue` with the full merged array). The script reads current labels from the API and appends — never replaces.

**QA-stage stories with existing TC comment:**
- Skip generation — TC table already in Jira. Phase 3b reads it from Jira as usual. Cases a human wants added after review go through `/generating-test-cases <STORY_KEY> --extend` (adds the **Extended cases added after Human review** section in place); execution then reads both tables.
- **Add `HL-Scenarios_Covered` label** — run `node "$CLAUDE_PLUGIN_ROOT/skills/test-ticket/scripts/add-label.js" "<STORY_KEY>" "HL-Scenarios_Covered"` (or, when `jira_write_path = mcp`, its MCP fallback: `getJiraIssue` for `fields.labels`, then `editJiraIssue` with the full merged array). The script reads current labels from the API and appends — never replaces.
- **Do not re-run Gate 2 and do not rewrite the TC comment.** `story.tc_skip_automation` / `story.tc_already_automated` are derived — without asking — from the existing comment's `Automate` (`Automated` on an older comment, or on one already updated with execution results) column and `run-state.json`; see Automation Derivation below. (`update-tc-comment.js` stays the tool for correcting a TC comment in place when its *content* is actually wrong — not for this path, where nothing changed.)

## Automation Derivation (after Phase 2, before Phase 2.5)

*Runs only when Phase 2 TC generation was skipped (TC comment already existed) AND the story is QA-stage.*

No ask here — the question this used to ask ("which TCs should be excluded from automation?") is the same question Gate 2 already asked when these TCs were first generated, and the answer is sitting right in the existing TC comment's `Automate` (`Automated` on an older comment, or on one already updated with execution results) column. Re-asking would be asking the same thing twice.

0. **Recover `story.tc_already_automated` first, before deriving anything from the Jira comment.** Read it — and its paired `story.tc_already_automated_repo` — from this Epic's `run-state.json` (persisted by an earlier run's duplicate check, step 6a above) and unaffected by the Jira comment's `Automate` (`Automated` on an older comment, or on one already updated with execution results) column, which cannot tell "already automated elsewhere" apart from "newly automated this run" (both render as `Yes`).
   - **Not present in `run-state.json`** (e.g. a story generated before this check existed) **and a base URL is available for this Epic** (`target_repo` resolved) → run the step 6a duplicate check now against `target_repo` to populate both fields, rather than assuming `[]`.
   - **Present, but `tc_already_automated_repo` ≠ the currently-resolved `target_repo`** (e.g. `--retest` re-ran this Epic with a URL that switched MXTS↔MCMS since the list was populated) → the stored list was searched against the wrong repo and is not valid evidence for this run. Re-run the step 6a duplicate check now against the current `target_repo` rather than trusting it — do not silently carry a cross-repo list forward.
   - **No base URL (Generation only mode)** → there is no `target_repo` to search and Phase 6 never runs for this Epic anyway, so skip the re-check and set `story.tc_already_automated = []` directly — do not call GitHub.

For each QA-stage story whose TC comment was found in the resume check:

1. Read the story's comments with `mcp__claude_ai_Atlassian_MCP__executeRead` `listJiraIssueComments` (every page — `getJiraIssue` only reports the comment count), find the most recent `h2. Test Cases — <STORY_KEY>` (script path, wiki markup) or `## Test Cases — <STORY_KEY>` (MCP path, markdown) comment — or, when it carries a `Part n of m` line, every part of it (all `m` must be present) — and extract all TC_IDs and their current `Automate` (`Automated` on an older comment) column values — from the main table and, when present, the **Extended cases added after Human review** table.

2. Derive `story.tc_skip_automation` directly from those values — no ask, no comment rewrite (nothing changed, so nothing to update in place):
   - TC already in `story.tc_already_automated` (step 0) → always leave out of `tc_skip_automation`, regardless of what the comment says — it's genuinely automated, just not by a new spec this run.
   - `Automate = No` (or `Automated = No`) for a TC not in `tc_already_automated` → include its TC_ID in `tc_skip_automation`.
   - `Automate = Yes` (or `Automated = Yes`) for a TC not in `tc_already_automated` → leave it out of `tc_skip_automation`.
   - The ninth column (`Automate` / `Automated`) blank/missing/unrecognized for a TC (e.g. an older comment format) → leave it out of `tc_skip_automation` (default to automate — consistent with the "default to automate all" fallback used elsewhere when a value is genuinely unknown).

3. **Overrides, applied instead of the derivation above:** `--unattended` or `--auto-specs` → `story.tc_skip_automation = []` (force automate all, ignoring whatever the comment says) — `tc_already_automated` still blocks a duplicate spec regardless of this flag. `--skip-specs` → `story.tc_skip_automation` = every TC_ID not already in `tc_already_automated` (force skip all new specs).

Log: `[Automation] <STORY_KEY> — <n> TCs: <m> automated, <k> excluded, <j> already automated in <target_repo> (derived from the existing Automate/Automated column + run-state.json).`
