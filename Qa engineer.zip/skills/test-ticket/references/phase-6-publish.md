# Phase 6 — Publish Spec Files to GitHub (full procedure)

*Runs automatically if this Epic had a base URL (pre-authenticated run, `target_repo` resolved) AND at least one spec file was actually generated in Phase 3b — check both, not the TC lists below.* No separate PR confirmation, and no separate "generate specs?" ask either — Gate 2 (Phase 2) is the only opt-in. A story generates a new spec only for a TC that is **both** outside `tc_skip_automation` **and** outside `tc_already_automated` (see Phase 3b's per-TC decision in SKILL.md) — a story where every TC falls into one list or the other produced no spec file and has nothing for Phase 6 to publish, even though it has TCs "not in `tc_skip_automation`". If no story in this Epic generated a file, Phase 6 does not run at all for it.

> ⛔ **Generation only mode (no URL) never reaches this phase, even though Phase 3b still runs and can produce a TODO-placeholder spec for QA-stage stories.** There is no live URL to derive `target_repo` from (see preflight-detail.md's Target Repo Detection), and a spec built entirely from TODO placeholders isn't meant to auto-publish without a human first filling it in. That spec stays local, on disk, for manual review or a later `/generate-playwright-tests`/`/review-pr` pass — Phase 6 is a pre-authenticated-run feature only.

> Every repo reference below is `MaxxtonGroup/<target_repo>` — `target_repo` was already resolved once per Epic during Pre-flight's "Target repo detection" (`mcms-qa-automation` for a `cms` hostname, `mxts-qa-automation` otherwise) and persisted to `run-state.json`. Re-read it from there rather than re-deriving it here.

0. **Duplicate-PR guard (mandatory, before anything else)** — a PR may already exist from an earlier run or a pre-compaction continuation of this run:
   - First check `run-state.json` for a recorded `pr_url` — if present, the PR was already created this run. Do NOT create another; reuse it and skip to the Final Summary.
   - Otherwise call `search_pull_requests` on `MaxxtonGroup/<target_repo>` for an **open** PR whose head branch starts with `qa/specs/<EPIC_ID>` (or title contains `<EPIC_ID>`). If one exists → reuse its URL, persist it to `run-state.json`, and skip creation. Log: `[Phase 6] Existing open PR found for <EPIC_ID> — reusing, not creating a duplicate.`
   - Only if neither is found → proceed to step 1.

1. **Derive file paths** — for each `<STORY_KEY>.spec.js` (the local file under `test-output/<EPIC_ID>/` keeps that name), build the published path from the module, sub-menu and feature-area folders resolved during Phase 3b:
   ```
   tests/modules/<module>/<sub_menu>/<feature_area>/<name>.spec.js
   ```
   `<name>` is the story's Jira summary in snake_case: lowercase, every run of other characters becomes one `_`, trimmed, at most 50 characters and cut at a word boundary. It is never the Jira key: the repo names spec files by feature (`case_details_page.spec.js`), not by ticket. `<module>` must be a key of `MODULE_URLS` in the repo's `fixtures/mxts-test.js`. Before pushing, call `get_file_contents` on the target folder: when `<name>.spec.js` already exists there, never overwrite it; use `<name>_2.spec.js` (then `_3`, …) and say in the PR body that the file belongs in the existing spec and should be merged into it.

2. **Pull latest develop** — call `list_commits` on repo `MaxxtonGroup/<target_repo>`, branch `develop` (the default branch of both `mxts-qa-automation` and `mcms-qa-automation`; neither has a `main`), limit 1. Extract the latest commit SHA. Log: `[Phase 6] Latest develop SHA: <sha> — branching from here.`

3. **Create branch:**
   - Branch name: `qa/specs/<EPIC_ID>` (single Epic) or `qa/specs/<EPIC_ID_1>-<EPIC_ID_2>-...` (multi-Epic)
   - Base SHA: commit SHA from step 2
   - Call `create_branch` on repo `MaxxtonGroup/<target_repo>`
   - If `create_branch` fails because the branch already exists, append a UTC timestamp: `qa/specs/<EPIC_ID>-<YYYYMMDDTHHmmss>` and retry once. Log: `[Phase 6] Branch already exists — using timestamped branch <new_branch>.`

4. **Push files:**
   - **Pre-push check (fail closed):** read each local spec file first. It must exist, be non-empty and contain at least one `test(` or `test.describe(` call. A file that fails is not pushed: log `[Phase 6] <path> is empty or has no test — not published.` and list it under ACTION REQUIRED in the Final Summary. When no file passes, skip the rest of this phase.
   - Call `push_files` with all spec files that passed the check
   - Repo: `MaxxtonGroup/<target_repo>`, branch: above
   - Commit message: `test: add automated Playwright specs for <EPIC_ID>`
   - **Post-push check:** call `get_file_contents` for every pushed path on the new branch. Each must return non-empty content. If one comes back missing or empty, do not open the PR: log `[Phase 6] <path> is missing or empty on <branch> after the push.`, list it under ACTION REQUIRED with the branch name so the branch can be inspected, and skip steps 5–7.

5. **Create PR — as a draft, always:**
   - Call `create_pull_request` with **`draft: true`**. This is not optional and not user-configurable — every PR this phase opens is a draft, whether newly created here or reused via the duplicate-PR guard in step 0 (an existing PR found there was itself created as a draft by an earlier run of this same phase).
   - Title: `test: Playwright specs for <EPIC_ID>`
   - Body: stories included with a `<STORY_KEY> → published path` table, pass rate from Exit Gate, link to Jira Epic, and a line noting it's a draft pending review before merge, plus the merge conditions of the repo's `CLAUDE.md` ("Pipeline-generated specs") that this phase can state: `Test cases approved at Gate 2: yes`, `Burn-in (5 clean passes): not run by the pipeline, run before merging`, `Comment cleanup pass: not run by the pipeline, run before merging`
   - Base: `develop`, head: branch above

6. **Persist `pr_url` to `run-state.json` immediately** (so a compaction right after creation cannot trigger a duplicate PR), then print the PR URL and include it in the Final Summary. Log: `[Phase 6] Complete — branch qa/specs/<EPIC_ID> has an open draft PR. Next run will pull latest develop and create a fresh branch automatically.`

7. **Attribute the automation, per story** — for each `<STORY_KEY>` whose spec file was included in this PR (whether the PR was just created in step 5 or reused from the duplicate-PR guard in step 0). This step only runs at all once a spec file exists (Phase 3b) **and** a draft PR is open for it (steps 0–6 above) — the three preconditions (spec generated → draft PR open → label added) gate strictly in this order, per story:
   1. **Spec generated** — already true, or Phase 6 would not be running for this story (see the "at least one spec file" guard at the top of this phase).
   2. **Draft PR open** — already true, or step 5/step 0 would not have produced a `pr_url`. The same `pr_url` used here is always the draft PR from step 5 — there is no separate "ready" PR link; the Jira comment and the label always refer to that one draft.
   3. **Label added** — run `node "$CLAUDE_PLUGIN_ROOT/skills/test-ticket/scripts/add-label.js" "<STORY_KEY>" "QA_Pipeline_Automation"` (or its MCP fallback — `getJiraIssue` + `editJiraIssue` — when `jira_write_path = mcp`; see phase-3a-execution.md's "Jira Write-Path Check"). This is distinct from the `QA_Pipeline` label (added in Phase 3b on local spec generation, regardless of whether a PR ever follows) — `QA_Pipeline_Automation` means the pipeline generated the spec file **and** a draft PR is open for it. **If this step fails for a story on whichever path applies, do NOT run step 4 for that story** — log the failure and move to the next story; do not post a PR-link comment without the label having been applied first.
   4. **Comment posted** — only after step 3 succeeds for this story, run `node "$CLAUDE_PLUGIN_ROOT/skills/test-ticket/scripts/post-pr-comment.js" "<STORY_KEY>" "<pr_url>" "<target_repo>"` — pass this Epic's own persisted `target_repo` (not re-derived from the URL) so the script rejects a `pr_url` that doesn't actually belong to it. Fails closed and no-ops if the comment already exists — safe to call on every run, including reused PRs and `--retest`. **When `jira_write_path = mcp`,** use `addOrEditJiraIssueComment` with `commentBody` (markdown) instead (same two-line template) — but unlike the script, it has no built-in duplicate check, so reproduce the no-op manually: check `pr_comment_id` in `run-state.json` for this story first; if it's already set, skip (already posted this run or a prior one); if not, search the story's comments (`listJiraIssueComments`) for one that already contains this `pr_url` — found → persist its id as `pr_comment_id` and skip (a crash happened between the post and the persist); the search failed → do not post, log it and leave the story unposted; searched with no match → post and persist the returned ID as `pr_comment_id` — see phase-3a-execution.md's MCP fallback table.
   - Log: `[Phase 6] <STORY_KEY> labeled QA_Pipeline_Automation, draft PR link posted.`
