#!/usr/bin/env node
/**
 * Tests for run-timing.js tc-start / tc-end (the per-TC "Time taken" of the progress table).
 * Self-contained: node:test + node:assert.
 * Run: node plugins/qa-engineer/skills/test-ticket/scripts/run-timing-tc.test.js
 */
'use strict';

const test = require('node:test');
const assert = require('node:assert');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { spawnSync } = require('child_process');

const SCRIPT = path.join(__dirname, 'run-timing.js');
const tmpRoots = [];
function tmp() { const d = fs.mkdtempSync(path.join(os.tmpdir(), 'run-timing-tc-')); tmpRoots.push(d); return d; }
const run = (args, now) => {
  const r = spawnSync(process.execPath, [SCRIPT, ...args], { encoding: 'utf8', env: { ...process.env, RUN_TIMING_NOW: now || '' } });
  return { code: r.status, out: r.stdout.trim(), err: r.stderr.trim() };
};
test.after(() => { for (const d of tmpRoots) fs.rmSync(d, { recursive: true, force: true }); });

test('tc-start / tc-end print the time taken in the progress-table format', () => {
  const timer = path.join(tmp(), 'tc-timer.json');
  const cases = [['TC_01', '2026-10-14T09:00:00.000Z', '2026-10-14T09:03:00.000Z', '3m'],
    ['TC_02', '2026-10-14T09:03:00.000Z', '2026-10-14T09:05:10.000Z', '2m 10s'],
    ['TC_03', '2026-10-14T09:05:10.000Z', '2026-10-14T09:05:55.000Z', '45s'],
    ['TC_04', '2026-10-14T09:06:00.000Z', '2026-10-14T10:11:30.000Z', '1h 5m']];
  for (const [tc, start, end, want] of cases) {
    assert.strictEqual(run(['tc-start', timer, tc], start).out, 'OK');
    assert.strictEqual(run(['tc-end', timer, tc], end).out, want, tc);
    assert.ok(!fs.existsSync(timer), 'the timer is removed once the TC ended');
  }
});

test('a retry attempt calls tc-start again and keeps the first start; a stale or foreign timer is replaced', () => {
  const timer = path.join(tmp(), 'tc-timer.json');
  run(['tc-start', timer, 'TC_01'], '2026-10-14T09:00:00.000Z');
  run(['tc-start', timer, 'TC_01'], '2026-10-14T09:01:30.000Z');
  assert.strictEqual(run(['tc-end', timer, 'TC_01'], '2026-10-14T09:02:00.000Z').out, '2m', 'attempt 2 does not restart the clock');
  run(['tc-start', timer, 'TC_05'], '2026-10-14T09:00:00.000Z');
  run(['tc-start', timer, 'TC_06'], '2026-10-14T09:10:00.000Z');
  assert.strictEqual(run(['tc-end', timer, 'TC_05'], '2026-10-14T09:11:00.000Z').out, 'n/a', 'the timer now belongs to TC_06');
  run(['tc-start', timer, 'TC_07'], '2026-10-14T09:00:00.000Z');
  run(['tc-start', timer, 'TC_07'], '2026-10-14T12:00:00.000Z');
  assert.strictEqual(run(['tc-end', timer, 'TC_07'], '2026-10-14T12:01:00.000Z').out, '1m', 'a timer older than 2 hours is replaced');
});

test('tc-end without a timer prints n/a and exits 0', () => {
  const timer = path.join(tmp(), 'none.json');
  const r = run(['tc-end', timer, 'TC_01'], '2026-10-14T09:00:00.000Z');
  assert.deepStrictEqual([r.code, r.out], [0, 'n/a']);
});

test('with --state/--story a pause counted during the TC is subtracted, and the heartbeat moves', () => {
  const dir = tmp();
  const state = path.join(dir, 'run-state.json');
  const timer = path.join(dir, 'tc-timer.json');
  fs.writeFileSync(state, JSON.stringify({ stories: { K: { cycle_started_at: '2026-10-14T08:00:00.000Z', user_wait_seconds: 100, pause_count: 1 } } }));
  run(['tc-start', timer, 'TC_01', '--state', state, '--story', 'K'], '2026-10-14T09:00:00.000Z');
  assert.strictEqual(JSON.parse(fs.readFileSync(state, 'utf8')).stories.K.last_activity_at, '2026-10-14T09:00:00.000Z');
  run(['pause', state, 'K', '2026-10-14T09:02:00.000Z', '2026-10-14T09:08:00.000Z']);
  assert.strictEqual(run(['tc-end', timer, 'TC_01', '--state', state, '--story', 'K'], '2026-10-14T09:10:00.000Z').out, '4m', '10 min elapsed minus the 6 min pause');
  assert.strictEqual(JSON.parse(fs.readFileSync(state, 'utf8')).stories.K.last_activity_at, '2026-10-14T09:10:00.000Z');
});

test('a timer from another cycle is stale when --state is given', () => {
  const dir = tmp();
  const state = path.join(dir, 'run-state.json');
  const timer = path.join(dir, 'tc-timer.json');
  fs.writeFileSync(state, JSON.stringify({ stories: { K: { cycle_started_at: '2026-10-14T08:00:00.000Z', user_wait_seconds: 0 } } }));
  run(['tc-start', timer, 'TC_01', '--state', state, '--story', 'K'], '2026-10-14T09:00:00.000Z');
  fs.writeFileSync(state, JSON.stringify({ stories: { K: { cycle_started_at: '2026-10-14T09:30:00.000Z', user_wait_seconds: 0 } } }));
  run(['tc-start', timer, 'TC_01', '--state', state, '--story', 'K'], '2026-10-14T09:31:00.000Z');
  assert.strictEqual(run(['tc-end', timer, 'TC_01', '--state', state, '--story', 'K'], '2026-10-14T09:33:00.000Z').out, '2m');
});

test('usage errors exit 1', () => {
  const dir = tmp();
  assert.strictEqual(run(['tc-start']).code, 1);
  assert.strictEqual(run(['tc-start', path.join(dir, 't.json'), 'TC_01', '--state', path.join(dir, 'x.json')]).code, 1, '--state without --story');
});

test('tc-end with --state but a timer started without it subtracts nothing', () => {
  const dir = tmp();
  const state = path.join(dir, 'run-state.json');
  const timer = path.join(dir, 'tc-timer.json');
  fs.writeFileSync(state, JSON.stringify({ stories: { K: { cycle_started_at: '2026-10-14T08:00:00.000Z', user_wait_seconds: 500 } } }));
  run(['tc-start', timer, 'TC_01'], '2026-10-14T09:00:00.000Z');
  assert.strictEqual(run(['tc-end', timer, 'TC_01', '--state', state, '--story', 'K'], '2026-10-14T09:05:00.000Z').out, '5m');
});
