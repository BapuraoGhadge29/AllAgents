#!/usr/bin/env node
/**
 * Can this machine upload files to Atlassian Media?
 *
 * The Atlassian MCP's `uploadAttachmentToJiraIssue` hands back a `curl` command that sends the file
 * bytes straight to https://api.media.atlassian.com. That works from a normal developer machine but
 * is blocked inside a sandbox whose network egress allowlist does not include the host (the sandbox
 * answers 403 "Host not in allowlist"). This probe tells the pipeline once, at preflight, so it can
 * choose filenames instead of failing on every screenshot.
 *
 * No credentials, no token, no write: one unauthenticated GET.
 *
 * Usage:
 *   node probe-media-host.js
 *
 * Prints exactly one word, exits 0 in every case (the caller branches on stdout):
 *   reachable  - the real host answered (recognised by its CloudFront signature, or a 2xx/3xx status)
 *   blocked    - an egress allowlist, proxy or filter refused the host (allowlist text, or a 403/407/5xx without the host's signature)
 *   offline    - no connection (DNS, TLS, timeout, no network)
 *
 * MEDIA_PROBE_URL overrides the URL for tests only, and only for a bare loopback http URL; redirects are not followed.
 */

// The override exists only to test this script against a local server: anything that is not a bare loopback
// HTTP URL is ignored, so an inherited or malicious variable cannot turn the preflight probe into a request
// to an arbitrary host.
const PROD = 'https://api.media.atlassian.com/';
const override = process.env.MEDIA_PROBE_URL || '';
const url = /^http:\/\/(127\.0\.0\.1|localhost)(:\d+)?\/?$/.test(override) ? override : PROD;

(async () => {
  const ctrl  = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), 8000);
  try {
    const res  = await fetch(url, { signal: ctrl.signal, redirect: 'manual' });
    const body = (await res.text()).slice(0, 2000);
    const deny = String(res.headers.get('x-deny-reason') || '');
    const server = String(res.headers.get('server') || '');
    // The real host sits behind CloudFront and answers an unauthenticated GET with a WAF challenge
    // (202, no body). Anything that carries that signature is the real host, whatever the status.
    const realHost = res.headers.has('x-amz-cf-id') || /cloudfront|atlassianedge/i.test(server);
    if (/not in allowlist|host_not_allowed|egress/i.test(body) || /host_not_allowed|allowlist/i.test(deny)) {
      process.stdout.write('blocked\n');          // a sandbox's egress allowlist refused the host
    } else if (realHost || (res.status >= 200 && res.status < 400)) {
      process.stdout.write('reachable\n');
    } else {
      process.stdout.write('blocked\n');          // 403/407/5xx from something that is not the host (proxy, filter)
    }
  } catch {
    process.stdout.write('offline\n');
  } finally {
    clearTimeout(timer);
  }
  // process.exit() right after an HTTPS fetch aborts Node on Windows (libuv assertion, exit 127).
  process.exitCode = 0;
})();
