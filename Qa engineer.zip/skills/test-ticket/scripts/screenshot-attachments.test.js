#!/usr/bin/env node
/**
 * Tests for screenshot-attachments.js. Self-contained: node:test + node:assert, no network.
 * Run: node plugins/qa-engineer/skills/test-ticket/scripts/screenshot-attachments.test.js
 */
'use strict';

const test = require('node:test');
const assert = require('node:assert');
const { referencedImages, missingImages, check, describe } = require('./screenshot-attachments');

const body = [
  'h2. QA Test Results',
  '|| TC_ID || Test Proof ||',
  '| TC_01 | !TC_01-result.png! |',
  '| TC_02 | TC_02-result.png |',
  '| TC_03 | Before:\\\\ !TC_03-x-before.png!\\\\ After:\\\\ !TC_03-x-after.png! |',
  '| TC_04 | TC_04-capture-failed.png (screenshot capture failed — 3/3 attempts, timeout) |',
  '| TC_05 | !TC_01-result.png! |',
].join('\n');

const jira = (names, ok = true) => async () => ({
  ok,
  status: ok ? 200 : 500,
  json: async () => ({ fields: { attachment: names.map((filename) => ({ filename })) } }),
});

test('referencedImages finds embedded and plain names once, and skips capture-failed entries', () => {
  assert.deepStrictEqual(referencedImages(body), ['TC_01-result.png', 'TC_02-result.png', 'TC_03-x-before.png', 'TC_03-x-after.png']);
  assert.deepStrictEqual(referencedImages('no proof here, same view as TC_04'), []);
});

test('missingImages lists the names that are not attached', () => {
  assert.deepStrictEqual(missingImages(['a.png', 'b.png'], ['a.png', 'c.png']), ['b.png']);
});

test('check: every screenshot attached', async () => {
  const r = await check(body, 'https://x/rest/api/2/issue/K-1', {}, jira(['TC_01-result.png', 'TC_02-result.png', 'TC_03-x-before.png', 'TC_03-x-after.png', 'other.png']));
  assert.deepStrictEqual(r.missing, []);
  assert.strictEqual(describe(r, 'K-1', '9'), 'Screenshots: 4/4 attached to K-1.');
});

test('check: a plain filename (failed upload) and a broken !image! are both reported', async () => {
  const r = await check(body, 'https://x/rest/api/2/issue/K-1', {}, jira(['TC_01-result.png', 'TC_03-x-before.png']));
  assert.deepStrictEqual(r.missing, ['TC_02-result.png', 'TC_03-x-after.png']);
  const line = describe(r, 'K-1', '9');
  assert.match(line, /2 of 4 referenced in comment 9 are not attached to K-1: TC_02-result.png, TC_03-x-after.png/);
  assert.match(line, /upload-screenshot\.js/);
});

test('check: asks Jira once, with the headers, for the attachment field', async () => {
  const calls = [];
  const fetchFn = async (url, init) => {
    calls.push({ url, init });
    return jira(['TC_01-result.png'])();
  };
  await check('!TC_01-result.png!', 'https://x/rest/api/2/issue/K-1', { Authorization: 'Basic abc' }, fetchFn);
  assert.deepStrictEqual(calls, [{ url: 'https://x/rest/api/2/issue/K-1?fields=attachment', init: { headers: { Authorization: 'Basic abc' } } }]);
});

test('check: a body without screenshot references does not call Jira', async () => {
  const r = await check('h2. nothing', 'https://x/rest/api/2/issue/K-1', {}, () => {
    throw new Error('must not be called');
  });
  assert.deepStrictEqual(r, { expected: [], missing: [] });
});

test('check: rejects when Jira cannot be asked, so the caller never reports an unchecked comment as fine', async () => {
  await assert.rejects(() => check(body, 'https://x/rest/api/2/issue/K-1', {}, jira([], false)), /GET attachments failed: 500/);
});

test('describe shortens a long list', () => {
  const missing = ['a', 'b', 'c', 'd', 'e', 'f', 'g'].map((n) => `TC_01-${n}.png`);
  const line = describe({ expected: missing, missing }, 'K-1', '1');
  assert.match(line, /7 of 7/);
  assert.match(line, /TC_01-e\.png, …/);
  assert.ok(!line.includes('TC_01-f.png'));
});
