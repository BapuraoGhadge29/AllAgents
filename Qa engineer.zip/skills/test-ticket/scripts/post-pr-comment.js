#!/usr/bin/env node
/**
 * Post a fixed-template "Playwright draft PR opened" comment to a Jira issue via API v2.
 * Companion to post-comment.js / post-tc-comment.js — third and last comment type
 * the pipeline is allowed to post (see Jira Comment Policy in SKILL.md). Runs once
 * per story after Phase 6 opens (or reuses) a draft PR for that story's spec file.
 *
 * Built-in gates (run before posting — cannot be bypassed):
 *   1. Format validation — body must be exactly the two-line template below.
 *   2. Duplicate guard — refuses to post if a PR-link comment already exists on this
 *      issue (prevents re-runs / --retest from posting it twice).
 *
 * Usage:
 *   node post-pr-comment.js <issue_key> <pr_url> <target_repo>
 *
 * <target_repo> is the Epic's persisted target repo (see "Target repo detection" in
 * SKILL.md) — "mxts-qa-automation" or "mcms-qa-automation". Required, not just validated
 * against the pair: `pr_url` is normally read back from `run-state.json`'s `pr_url`, and
 * without pinning it to the repo this run actually resolved, a stale/wrong value there
 * (from a bug elsewhere, or manual editing) would silently pass as long as it pointed at
 * *some* valid qa-automation repo, even the wrong one for this Epic's URL.
 *
 * Exits 0 on success (prints comment ID) or when duplicate is blocked (prints warning).
 * Exits 1 on validation failure or API error.
 */

const [, , issueKey, prUrl, targetRepo] = process.argv;

if (!issueKey || !prUrl || !targetRepo) {
  process.stderr.write('Usage: node post-pr-comment.js <issue_key> <pr_url> <target_repo>\n');
  process.exit(1);
}

if (!['mxts-qa-automation', 'mcms-qa-automation'].includes(targetRepo)) {
  process.stderr.write(
    `post-pr-comment.js BLOCKED — <target_repo> must be "mxts-qa-automation" or "mcms-qa-automation".\n` +
    `  Got: "${targetRepo}"\n`
  );
  process.exit(1);
}

const prUrlMatch = /^https:\/\/github\.com\/MaxxtonGroup\/([\w-]+)\/pull\/\d+$/.exec(prUrl);
if (!prUrlMatch || prUrlMatch[1] !== targetRepo) {
  process.stderr.write(
    `post-pr-comment.js BLOCKED — <pr_url> must be a MaxxtonGroup/${targetRepo} PR URL (this Epic's target repo).\n` +
    `  Got: "${prUrl}"\n`
  );
  process.exit(1);
}

const fs   = require('fs');
const path = require('path');

// ─── Credentials ────────────────────────────────────────────────────────────

function loadCredentials() {
  let email    = process.env.JIRA_EMAIL    || '';
  let apiToken = process.env.JIRA_API_TOKEN || '';
  if (!email || !apiToken) {
    try {
      const home = process.env.USERPROFILE || process.env.HOME || '';
      if (!home) throw new Error('no home dir');
      const settingsPath = path.join(home, '.claude', 'settings.json');
      const s = JSON.parse(fs.readFileSync(settingsPath, 'utf8'));
      if (s && s.env) {
        email    = email    || s.env.JIRA_EMAIL    || '';
        apiToken = apiToken || s.env.JIRA_API_TOKEN || '';
      }
    } catch { /* settings.json unreadable — fall through */ }
  }
  return { email, apiToken };
}

const { email, apiToken } = loadCredentials();
if (!email || !apiToken) {
  process.stderr.write('Missing JIRA_EMAIL or JIRA_API_TOKEN.\n');
  process.exit(1);
}

const auth    = Buffer.from(`${email}:${apiToken}`).toString('base64');
const headers = { Authorization: `Basic ${auth}`, 'Content-Type': 'application/json', Accept: 'application/json' };
const baseUrl = `https://maxxton.atlassian.net/rest/api/2/issue/${encodeURIComponent(issueKey)}`;

// ─── Fixed template — the ONLY body this script ever posts ─────────────────
// Keep byte-for-byte in sync with the sentinel line the duplicate guard scans for.

const SENTINEL = 'h3. Automated Playwright PR';
const body     = `${SENTINEL}\n\nThis story's Playwright spec was pushed and a *draft* PR is open (pending review before merge): ${prUrl}`;

// ─── Duplicate guard (paginated — scans ALL comments, not just the latest page) ─

async function findExistingPrComment() {
  const pageSize = 100;
  let startAt = 0;
  let total   = Infinity;
  while (startAt < total) {
    const res = await fetch(`${baseUrl}/comment?startAt=${startAt}&maxResults=${pageSize}&orderBy=-created`, { headers });
    if (!res.ok) throw new Error(`GET comments failed: ${res.status}`);
    const data = await res.json();
    const page = data.comments || [];
    const hit  = page.find(c =>
      typeof c.body === 'string' && c.body.trimStart().startsWith(SENTINEL)
    );
    if (hit) return hit;
    total = typeof data.total === 'number' ? data.total : Infinity;
    if (page.length === 0) break;   // guard against a non-advancing page
    startAt += page.length;
  }
  return null;
}

(async () => {
  let existing;
  try {
    existing = await findExistingPrComment();
  } catch (err) {
    process.stderr.write(
      `post-pr-comment.js — duplicate check could not run: ${err.message}\n` +
      `Not posting (failed closed) to avoid a duplicate PR-link comment. Retry once the API is reachable.\n`
    );
    process.exit(1);
  }
  if (existing) {
    process.stdout.write(
      `Duplicate blocked: a PR-link comment (id=${existing.id}) already exists on ${issueKey}.\n`
    );
    // process.exit() right after an HTTPS fetch aborts Node on Windows (libuv assertion, exit 127).
    process.exitCode = 0;
    return;
  }
  return postComment();
})();

// ─── Post ─────────────────────────────────────────────────────────────────────

function postComment() {
  return fetch(`${baseUrl}/comment`, {
    method:  'POST',
    headers,
    body:    JSON.stringify({ body }),
  })
    .then(res => {
      if (!res.ok) {
        return res.text().then(t => {
          process.stderr.write(`Jira API error ${res.status}: ${t}\n`);
          process.exit(1);
        });
      }
      return res.json();
    })
    .then(data => {
      process.stdout.write(String(data.id) + '\n');
    })
    .catch(err => {
      process.stderr.write(`Post failed: ${err.message}\n`);
      process.exit(1);
    });
}
