#!/usr/bin/env node
/**
 * Format check for a results comment that will be posted through the Atlassian MCP
 * (`addOrEditJiraIssueComment`), i.e. when `jira_write_path = mcp`.
 *
 * `post-comment.js` refuses a malformed wiki-markup body on the script path. The MCP path has no such
 * guard, so this script ports the same checks to the two body formats it can post, without any
 * credential or network access:
 *   html      - the normal body: screenshots embedded as media nodes in the Test Proof cells
 *   markdown  - the fallback body used when screenshots could not be uploaded (filenames only)
 *
 * Split results (more than 45 rows — see result-parts.js): add --part <n>/<m> --tc-ids <csv> (or --tc-ids-file <file>) and, for a results comment, --run-total <n>: the story's TC count.
 * The stats of a part count the whole story and Total TCs reads "<n> (<first>-<last>)", e.g. "55 (31-55)" (see phase-3b-split-results.md).
 * The body then needs one "Part n of m" line right after the header, exactly the TCs of that part (once per URL
 * block), and Cross-Module Impact only in the last part.
 *
 * Usage:
 *   node validate-results-comment.js <body-file> [--format html|markdown] [--part <n>/<m> --tc-ids <csv> --run-total <n>]
 *   node validate-results-comment.js <body-file> --kind tc --story <STORY_KEY>
 *
 * --kind gtc | exec | gresults (with --story <KEY>) check the comments the other skills post through the MCP:
 * generating-test-cases ("## QA Test Cases — KEY", Coverage Gaps), execute-tests ("## QA Test Results — KEY" with its
 * stats table) and generating-test-cases' post-execution results (no stats table). See skill-comment-checks.js.
 * All of them accept --part <n>/<m> --tc-ids <csv>. sprint-planning's "## Test Cases — KEY" is --kind tc.
 *
 * --kind tc checks the Phase 2 Test Cases comment (markdown, posted through the MCP) the way
 * post-tc-comment.js checks its wiki-markup body: header with the right story key, the 10-column table,
 * the AC-coverage footer, no execution verdicts.
 *
 * Merged layout: after execution the Test Cases comment is edited in place into a 12-column table (the 10 Test Cases
 * columns, then Status and Test Proof; see results-layout.js). Add --previous <file> (the comment as Jira holds it now)
 * to prove the edit loses nothing. --kind tc requires `Automate`; --existing also accepts the older `Automated`.
 *
 * --format defaults to "html" when the body starts with "<", otherwise "markdown".
 * Exits 0 and prints "OK" when the body passes. Exits 1 and prints every violation plus the canonical
 * template when it does not — rebuild the body from that template instead of from memory (it stays
 * correct after a context compaction, when the reference docs are no longer in the conversation).
 *
 * Keep the checks in step with post-comment.js (CHECK 1-8, 11, 12) and with the Phase 3b template.
 */
const fs = require('fs');

const [, , file, ...rest] = process.argv;
if (!file) {
  process.stderr.write('Usage: node validate-results-comment.js <body-file> [--format html|markdown]\n');
  process.exit(1);
}
let body;
try { body = fs.readFileSync(file, 'utf8'); }
catch (e) { process.stderr.write(`Cannot read ${file}: ${e.message}\n`); process.exit(1); }

const optValue = (name) => { const i = rest.indexOf(name); return i !== -1 ? rest[i + 1] : undefined; };
const kind = optValue('--kind') || 'results';
const STORY_KINDS = ['tc', 'gtc', 'exec', 'gresults'];
if (kind !== 'results' && !STORY_KINDS.includes(kind)) {
  process.stderr.write('--kind must be "results", "tc", "gtc", "exec" or "gresults"\n');
  process.exit(1);
}
const storyKey = optValue('--story');
// Split results (see result-parts.js): --part <n>/<m> with --tc-ids <csv> | --tc-ids-file <file>.
const resultParts = require('./result-parts');
const resultsLayout = require('./results-layout');
const { statsErrors } = require('./dashboard-stats');
const { part: partOpt, tcIds: partTcIds, mainTotal: mainTotalArg, runTotal } = resultParts.takePartArgs(rest);
const mainTotal = Number.isNaN(mainTotalArg) ? null : mainTotalArg;
const notMarker = (l) => !(partOpt && resultParts.isMarkerLine(l));
if (STORY_KINDS.includes(kind) && !storyKey) {
  process.stderr.write(`--kind ${kind} needs --story <STORY_KEY>\n`);
  process.exit(1);
}
const fmtArg = optValue('--format');
const format = fmtArg || (STORY_KINDS.includes(kind) ? 'markdown' : (body.trimStart().startsWith('<') ? 'html' : 'markdown'));
if (format !== 'html' && format !== 'markdown') {
  process.stderr.write('--format must be "html" or "markdown"\n');
  process.exit(1);
}

const STATS_LABELS = [
  'Concern', 'Environment', 'Build / Version', 'Preconditions', 'Total TCs', 'Passed', 'Failed', 'Blocked',
  'Needs Review', 'Skipped', 'Pass rate', 'QA Pipeline Version', 'Test Execution Timing',
];
const TC_HEADER = ['TC_ID', 'Test case scenario', 'Expected Result', 'Actual Result', 'Status', 'Test Proof'];
// A whole filename token: not glued to other word characters, and not followed by a further extension ("x.png.bak").
const PROOF_FILE_RE = /(?<![\w.-])TC_\d+-[\w-]+\.png(?![\w-]|\.\w)/;
const PROOF_FILE_EXACT = /^TC_\d+-[\w-]+\.png$/;
// A "-capture-failed.png" token is only for a screenshot that really failed 3 attempts. KEEP IN SYNC with post-comment.js / update-comment.js CHECK 13.
const BAD_CAPTURE_FAILED_RE = /[\w-]*capture-failed[\w-]*\.png(?!\s*\(screenshot capture failed — 3\/3 attempts, [^)|]+\))/i;
const captureFailedMessage = (affected) =>
  '[CHECK 13] Test Proof says the screenshot capture failed or was skipped without the required note.\n' +
  '  A screenshot is mandatory for every TC — API/DOM verification is never a substitute and capture is never skipped.\n' +
  '  Take the screenshot (retry up to 3 attempts, see Phase 3a). Only after 3 real failed attempts may the cell read:\n' +
  '  TC_XX-capture-failed.png (screenshot capture failed — 3/3 attempts, <error>)\n' +
  `  Affected: ${affected.slice(0, 5).join(', ')}`;
const PHASE_PATTERNS = [/phase\s*3a/i, /phase\s*1\b/i, /phase\s*2\b/i, /execution results/i, /test cases & execution evidence/i, /qa pipeline\s*[-–]/i, /execution summary/i, /pipeline summary/i, /tester:\s*qa pipeline/i];
const SUPPLEMENT_PATTERNS = [/supersedes/i, /supplement/i, /appendix/i, /part\s*2/i, /full evidence/i];
const PROSE_PATTERNS = [/^\*\*Steps:\*\*/i, /^\*\*Expected:\*\*/i, /^\*\*Actual:\*\*/i, /^\*\*Screenshot:\*\*/i, /^Steps:/i, /^Expected:/i, /^Actual:/i, /^Screenshot:/i];
// KEEP IN SYNC with post-comment.js CHECK 12 and analyzing-impact/SKILL.md's QA ownership reference.
const TEAMS_WITH_QA_OWNERS = ['Reservations/CCM/NM', 'Finance / Owner / Compliance', 'Content & Back Office', 'Channel Manager', 'Revenue & Availability', 'Revenue & Channel', 'Third Parties - API', 'Third Parties - Connections', 'Email Notifications', 'FrontOps', 'Web Manager - Development', 'Reporting & BI'];

// ─── helpers ────────────────────────────────────────────────────────────────

function decode(s) {
  return s.replace(/&nbsp;/g, ' ').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&#39;/g, "'").replace(/&amp;/g, '&');
}
function stripTags(s) { return decode(s.replace(/<[^>]+>/g, ' ')).replace(/\s+/g, ' ').trim(); }
function visibleLines(html) {
  return decode(html.replace(/<(br|\/p|\/li|\/h[1-6]|\/tr|\/table|\/figure)[^>]*>/gi, '\n').replace(/<[^>]+>/g, ' '))
    .split('\n').map(l => l.replace(/\s+/g, ' ').trim()).filter(Boolean);
}
function attr(tag, name) {
  const m = tag.match(new RegExp(`\\b${name}\\s*=\\s*(?:"([^"]*)"|'([^']*)')`, 'i'));
  return m ? (m[1] !== undefined ? m[1] : m[2]) : null;
}
const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
function tablesOf(html) { return html.match(/<table[\s\S]*?<\/table>/gi) || []; }
function rowsOf(table) { return (table.match(/<tr[\s\S]*?<\/tr>/gi) || []).map(r => (r.match(/<t[dh][^>]*>[\s\S]*?<\/t[dh]>/gi) || [])); }
function cellInner(cell) { return cell.replace(/^<t[dh][^>]*>/i, '').replace(/<\/t[dh]>$/i, ''); }

function mdRows(text) {
  return text.split('\n').map(l => l.trim()).filter(l => l.startsWith('|') && !/^\|\s*:?-{2,}/.test(l))
    .map(l => l.replace(/^\|/, '').replace(/\|$/, '').split('|').map(c => c.trim()));
}

// ─── collapsible TC tables (HTML bodies only) ───────────────────────────────

// More than 5 TC rows in a table → the table sits inside an expand (<details><summary>…</summary>…</details>), so a long
// comment opens collapsed; 5 or fewer → a plain table. Markdown and wiki bodies cannot carry an expand and are not checked.
const EXPAND_THRESHOLD = 5;
function expandErrors(text, tables) {
  const details = text.match(/<details\b[^>]*>[\s\S]*?<\/details>/gi) || [];
  const errors = [];
  tables.forEach((table, i) => {
    const rows = rowsOf(table).slice(1).filter(r => /^TC_\d+$/.test(stripTags(cellInner(r[0] || '')))).length;
    const wrapper = details.find(d => d.includes(table));
    const where = tables.length > 1 ? ` (TC table ${i + 1})` : '';
    if (rows > EXPAND_THRESHOLD && !wrapper) {
      errors.push(`[CHECK 19] The TC table${where} has ${rows} rows: with more than ${EXPAND_THRESHOLD} TCs it must sit inside <details><summary>…</summary> … </details> so the comment opens collapsed.`);
    } else if (rows <= EXPAND_THRESHOLD && wrapper) {
      errors.push(`[CHECK 19] The TC table${where} has ${rows} row(s): with ${EXPAND_THRESHOLD} TCs or fewer it stays a plain table, not inside <details>.`);
    } else if (wrapper && !/<summary\b[^>]*>[\s\S]*?\S[\s\S]*?<\/summary>/i.test(wrapper)) {
      errors.push(`[CHECK 19] The <details> around the TC table${where} needs a non-empty <summary> title (e.g. the number of TCs and, after execution, passed/failed).`);
    }
  });
  return errors;
}

// ─── checks ─────────────────────────────────────────────────────────────────

function validateHtml(text) {
  const errors = [];

  // 1. First element is exactly <h2>QA Test Results</h2>
  const first = text.trimStart().match(/^<(h[1-6])[^>]*>([\s\S]*?)<\/\1>/i);
  if (!first || first[1].toLowerCase() !== 'h2' || stripTags(first[2]) !== 'QA Test Results') {
    errors.push(`[CHECK 1] The body must start with exactly <h2>QA Test Results</h2> — no emoji, date, story key or other text.\n  Found: ${first ? `<${first[1]}>${stripTags(first[2])}` : '(no heading at the start)'}`);
  }

  // A multi-URL comment has one block per URL, separated by <hr/>. Every non-empty block must carry its
  // own complete stats table and TC table; the Cross-Module Impact section is checked separately below.
  const impactAt = text.search(/<h2[^>]*>\s*Cross-Module Impact\s*<\/h2>/i);
  const executionText = impactAt === -1 ? text : text.slice(0, impactAt);
  const isEmptyBlock = (b) => !/\S/.test(stripTags(b)) && !/<(table|figure|div|img)\b/i.test(b);
  const blocks = executionText.split(/<hr\b[^>]*>/i).filter((b, i) => i === 0 || !isEmptyBlock(b));
  const tcTables = [];
  const tcLayouts = [];
  blocks.forEach((block, bi) => {
    const where = blocks.length > 1 ? ` (block ${bi + 1})` : '';
    const tables = tablesOf(block);

    // 2. Stats table: 13 labelled rows, label in bold, two cells each.
    const statsTables = tables.filter(t => rowsOf(t).some(r => r.length && stripTags(cellInner(r[0])) === 'Concern'));
    if (!statsTables.length) {
      errors.push(`[CHECK 2] Stats table not found${where} (a two-column table whose first row is "Concern").`);
    }
    statsTables.forEach((statsTable) => {
      const rows = rowsOf(statsTable).filter(r => r.length);
      const labelOf = (r) => stripTags(cellInner(r[0]));
      for (const label of STATS_LABELS) {
        const found = rows.filter(r => labelOf(r) === label);
        const row = found[0];
        if (found.length > 1) errors.push(`[CHECK 2] Duplicate stats table row${where}: ${label}`);
        if (!row) errors.push(`[CHECK 2] Missing stats table row${where}: ${label}`);
        else if (!/<(strong|b)\b/i.test(cellInner(row[0]))) errors.push(`[CHECK 2] Stats row "${label}"${where} must have its label in bold (<strong>).`);
        else if (row.length !== 2) errors.push(`[CHECK 2] Stats row "${label}"${where} must have exactly 2 cells, found ${row.length}.`);
      }
      const unexpected = rows.filter(r => !STATS_LABELS.includes(labelOf(r)));
      if (unexpected.length) errors.push(`[CHECK 2] Unexpected row in the stats table${where}: ${unexpected.slice(0, 3).map(r => `"${labelOf(r)}"`).join(', ')}`);
    });

    // 3. TC table with exactly the six header columns, or the twelve of the merged table (the Test Cases comment after execution)
    const blockTcTables = tables.filter(t => { const r = rowsOf(t)[0]; return r && stripTags(cellInner(r[0] || '')) === 'TC_ID'; });
    if (!blockTcTables.length) {
      errors.push(`[CHECK 3] TC table not found${where}. Its header must be exactly: ${TC_HEADER.join(' | ')}`);
    }
    blockTcTables.forEach((tcTable) => {
      const header = rowsOf(tcTable)[0].map(c => stripTags(cellInner(c)));
      const layout = resultsLayout.layoutOfCells(header);
      if (!layout) {
        errors.push(`[CHECK 3] TC table header${where} must be exactly ${TC_HEADER.join(' | ')}
  or, in the merged Test Cases + results table: ${resultsLayout.MERGED_COLS.join(' | ')} — never add, remove or rename a column.
  Found: ${header.join(' | ')}`);
      }
      tcTables.push(tcTable);
      tcLayouts.push(layout || resultsLayout.LAYOUTS[0]);
    });
  });
  const tcRows = tcTables.flatMap((t, i) => rowsOf(t).slice(1).map(cells => Object.assign(cells, { layout: tcLayouts[i] })));
  errors.push(...expandErrors(text, tcTables));

  // 4. Only <h2>/<h3> headings, no Markdown "#" headings left in the text
  const badHeadings = (text.match(/<h[14-6]\b/gi) || []);
  const mdHeadings = visibleLines(text).filter(l => /^#{1,6}\s/.test(l));
  if (badHeadings.length || mdHeadings.length) {
    errors.push(`[CHECK 4] Only <h2>/<h3> headings are allowed, and no Markdown "#" headings.\n  Found: ${[...badHeadings, ...mdHeadings.slice(0, 3)].join(', ')}`);
  }

  // 5–7. Prose sections, internal phase labels, supplement markers
  // Prose and pipeline-label checks look at text the pipeline wrote: everything outside the tables plus the
  // Actual Result and Test Proof cells. A TC's scenario and expected text and the stats values come from the
  // ticket and may legitimately say "Phase 1", "part 2" or "supplement"; checking them would make the
  // validate-and-rebuild loop endless. A TC cell may also start with "Expected:", so prose is outside tables only.
  const outsideTables = text.replace(/<table[\s\S]*?<\/table>/gi, ' ');
  const pipelineCells = tcRows.flatMap(cells => [cells[cells.layout.actual], cells[cells.layout.proof]].filter(Boolean).map(c => cellInner(c)));
  const lines = visibleLines(outsideTables).concat(pipelineCells.flatMap(c => visibleLines(c)));
  const prose = visibleLines(outsideTables).filter(l => PROSE_PATTERNS.some(p => p.test(l)));
  if (prose.length) errors.push(`[CHECK 5] Per-TC prose sections detected — each TC must be a single table row.\n  Found: ${prose.slice(0, 3).map(l => `"${l}"`).join(', ')}`);
  const phase = lines.filter(l => PHASE_PATTERNS.some(p => p.test(l)));
  if (phase.length) errors.push(`[CHECK 6] Internal pipeline labels found — they must never appear in Jira.\n  Found: ${phase.slice(0, 3).map(l => `"${l}"`).join(', ')}`);
  const supp = lines.filter(l => notMarker(l) && SUPPLEMENT_PATTERNS.some(p => p.test(l)));
  if (supp.length) errors.push(`[CHECK 7] Supplement/appendix markers found — only ONE results comment per story per run.\n  Found: ${supp.slice(0, 2).map(l => `"${l}"`).join(', ')}`);

  // 8 + 10. Every TC row: six cells and a valid Test Proof (media node with a TC_XX-slug.png alt, or the plain filename)
  const badProof = [], badCount = [], badCapture = [];
  for (const cells of tcRows) {
    const id = stripTags(cellInner(cells[0] || ''));
    if (!/^TC_\d+$/.test(id)) continue; // EXTRA_xx rows are not proof-checked, as on the script path
    if (cells.length !== cells.layout.cols.length) { badCount.push(`${id} (${cells.length} cells, expected ${cells.layout.cols.length})`); continue; }
    const proof = cellInner(cells[cells.layout.proof]);
    const media = (proof.match(/<div\b[^>]*>/gi) || []).filter(t => attr(t, 'data-type') === 'media');
    // A capture-failed note is plain text with the mandatory 3/3-attempts wording; an uploaded media node is a real
    // screenshot, so its data-alt may never be a capture-failed filename.
    if (BAD_CAPTURE_FAILED_RE.test(stripTags(proof)) || media.some(m => /capture-failed/i.test(attr(m, 'data-alt') || ''))) badCapture.push(id);
    const mediaOk = media.length > 0 && media.every(m => UUID_RE.test(attr(m, 'data-id') || '') && PROOF_FILE_EXACT.test(attr(m, 'data-alt') || '') && attr(m, 'data-collection') !== '');
    const mediaBad = media.length > 0 && !mediaOk;
    const plain = PROOF_FILE_RE.test(stripTags(proof.replace(/<div\b[^>]*>[\s\S]*?<\/div>/gi, ' ')));
    // Every label paragraph ("Before:", "Spanish:") must be followed by its own image or plain filename. Free text
    // (a note, a debug-evidence line) is allowed around them, exactly as on the script path.
    const parts = proof.match(/<figure[\s\S]*?<\/figure>|<div\b[^>]*>[\s\S]*?<\/div>|<p\b[^>]*>[\s\S]*?<\/p>/gi) || [];
    const isItem = (part) => /^<(figure|div)\b/i.test(part) || PROOF_FILE_RE.test(stripTags(part));
    const danglingLabel = parts.some((part, k) => /^<p\b/i.test(part) && /:$/.test(stripTags(part)) && !PROOF_FILE_RE.test(stripTags(part)) && !(parts[k + 1] && isItem(parts[k + 1])));
    if (danglingLabel) { badProof.push(`${id}: a label (e.g. "Before:") is not followed by its image or filename`); continue; }
    if (mediaBad || (media.length === 0 && !plain)) badProof.push(`${id}: ${mediaBad ? 'media node without a UUID data-id, a TC_XX-slug.png data-alt, or with an empty data-collection' : `"${stripTags(proof) || '(empty)'}"`}`);
  }
  if (badCount.length) errors.push(`[CHECK 10] Wrong column count in ${badCount.length} TC row(s): ${badCount.slice(0, 5).join(', ')}`);
  if (badCapture.length) errors.push(captureFailedMessage(badCapture));
  if (badProof.length) {
    errors.push('[CHECK 8] Missing/malformed screenshot proof in the Test Proof column.\n' +
      '  Each TC needs, per item: an embedded media node (data-type="media", data-id = the uploaded fileId (a UUID), data-alt = TC_XX-slug.png)\n' +
      '  or, if the upload did not happen, the plain filename TC_XX-slug.png. Labels (Before:/After:/<item>:) and a debug-evidence line may sit around them.\n' +
      `  Affected: ${badProof.slice(0, 5).join('; ')}`);
  }

  // 11 + 12. Cross-Module Impact: canonical Team value, real QA mention for teams with a documented owner
  const impactIdx = text.search(/<h2[^>]*>\s*Cross-Module Impact\s*<\/h2>/i);
  if (impactIdx !== -1) {
    const after = text.slice(impactIdx);
    const impactTable = tablesOf(after)[0];
    if (impactTable) {
      const rows = rowsOf(impactTable).slice(1);
      const badSuffix = [], missingMention = [];
      for (const cells of rows) {
        const team = stripTags(cellInner(cells[1] || ''));
        const qaCell = cellInner(cells[2] || '');
        if (team && /\s(frontend|backend|fe|be)$/i.test(team)) badSuffix.push(team);
        // Wiki "[~accountid:...]" is not accepted here: inside an HTML body it posts as literal text.
        const hasMention = /data-type="mention"[^>]*data-user-id="[^"]+"|data-user-id="[^"]+"[^>]*data-type="mention"/i.test(qaCell);
        if (team && TEAMS_WITH_QA_OWNERS.includes(team) && !hasMention) missingMention.push(team);
      }
      if (badSuffix.length) errors.push(`[CHECK 11] Cross-Module Impact "Team" value has a Frontend/Backend/FE/BE suffix — use the exact canonical value (e.g. "Email Notifications").\n  Affected: ${badSuffix.join(', ')}`);
      if (missingMention.length) errors.push(`[CHECK 12] Cross-Module Impact QA cell has no real mention for team(s) with a documented QA owner: ${missingMention.join(', ')}.\n  Use a mention node (<span data-type="mention" data-user-id="<Jira Account ID>">) — never a plain name or email.`);
    }
  }
  // CHECK 16/17: the stats rows the dashboard reads hold plain values (dashboard-stats.js); KEEP IN SYNC with post-comment.js / update-comment.js.
  errors.push(...statsErrors(text));
  // CHECK 21: the footer counts what the Automate/Automated column says.
  errors.push(...resultsLayout.footerCountErrors(text));
  return errors;
}

function validateMarkdown(text) {
  const errors = [];
  const lines = text.split('\n');

  const firstContent = lines.find(l => l.trim().length > 0);
  if (firstContent?.trim() !== '## QA Test Results') {
    errors.push(`[CHECK 1] The body must start with exactly "## QA Test Results".\n  Found: "${firstContent?.trim() ?? '(empty)'}"`);
  }

  // A multi-URL body has one block per URL, separated by a line holding only "---". Every block that carries a
  // stats table or TC rows is checked on its own; the Cross-Module Impact section is checked separately below.
  const blocks = text.split(/^[ \t]*---+[ \t]*$/m);
  let tcRows = [];
  const executionBlocks = [];
  blocks.forEach((block) => {
    const rows = mdRows(block);
    const hasStats = rows.some(r => STATS_LABELS.some(l => r[0] === `**${l}**` || r[0] === `*${l}*`));
    const headerIdx = rows.findIndex(r => resultsLayout.layoutOfCells(r));
    const layout = headerIdx === -1 ? resultsLayout.LAYOUTS[0] : resultsLayout.layoutOfCells(rows[headerIdx]);
    const hasTcRows = rows.some(r => /^TC_\d+$/.test(r[0] || ''));
    if (!hasStats && headerIdx === -1 && !hasTcRows) return;
    executionBlocks.push(block);
    const where = ` (block ${executionBlocks.length})`;
    const tag = blocks.length > 1 ? where : '';
    const isLabel = (cell, label) => cell === `**${label}**` || cell === `*${label}*`;
    for (const label of STATS_LABELS) {
      const found = rows.filter(r => isLabel(r[0], label));
      if (!found.length) errors.push(`[CHECK 2] Missing stats table row${tag}: **${label}**`);
      else if (found.length > 1) errors.push(`[CHECK 2] Duplicate stats table row${tag}: **${label}**`);
      else if (found[0].length !== 2) errors.push(`[CHECK 2] Stats row **${label}**${tag} must have exactly 2 cells, found ${found[0].length}.`);
    }
    const strayStats = rows.filter(r => r.length === 2 && !STATS_LABELS.some(l => isLabel(r[0], l)));
    if (strayStats.length) errors.push(`[CHECK 2] Unexpected two-cell row in the stats table${tag}: ${strayStats.slice(0, 3).map(r => `"${r[0]}"`).join(', ')}`);
    if (headerIdx === -1) errors.push(`[CHECK 3] TC table header not found or wrong columns${tag}. Expected exactly: | ${TC_HEADER.join(' | ')} |\n  or, in the merged Test Cases + results table: | ${resultsLayout.MERGED_COLS.join(' | ')} |`);
    else tcRows = tcRows.concat(rows.slice(headerIdx + 1).filter(r => /^TC_\d+$/.test(r[0] || '') || /^EXTRA_\d+$/.test(r[0] || '')).map(r => Object.assign(r, { layout })));
  });
  if (!executionBlocks.length) {
    errors.push('[CHECK 2] No stats table and no TC table found.');
  }

  // Prose and pipeline-label checks look at text the pipeline wrote: everything outside the tables plus the
  // Actual Result and Test Proof cells (scenario / expected text and stats values come from the ticket).
  const outside = lines.filter(l => !l.trim().startsWith('|'));
  const prose = outside.filter(l => PROSE_PATTERNS.some(p => p.test(l.trim())));
  if (prose.length) errors.push(`[CHECK 5] Per-TC prose sections detected — each TC must be a single table row.\n  Found: ${prose.slice(0, 3).map(l => `"${l.trim()}"`).join(', ')}`);
  const pipelineText = outside.concat(tcRows.flatMap(r => [r[r.layout.actual], r[r.layout.proof]].filter(Boolean)));
  const shown = pipelineText.filter(l => PHASE_PATTERNS.some(p => p.test(l)));
  if (shown.length) errors.push(`[CHECK 6] Internal pipeline labels found — they must never appear in Jira.\n  Found: ${shown.slice(0, 3).map(l => `"${l.trim()}"`).join(', ')}`);
  const supp = pipelineText.filter(l => notMarker(l) && SUPPLEMENT_PATTERNS.some(p => p.test(l)));
  if (supp.length) errors.push(`[CHECK 7] Supplement/appendix markers found — only ONE results comment per story per run.\n  Found: ${supp.slice(0, 2).map(l => `"${l.trim()}"`).join(', ')}`);

  const badCount = [], badProof = [], badCapture = [];
  for (const r of tcRows) {
    if (!/^TC_\d+$/.test(r[0])) continue;
    if (r.length !== r.layout.cols.length) { badCount.push(`${r[0]} (${r.length} cells, expected ${r.layout.cols.length})`); continue; }
    const proofCell = r[r.layout.proof];
    if (BAD_CAPTURE_FAILED_RE.test(proofCell)) badCapture.push(r[0]);
    if (!PROOF_FILE_RE.test(proofCell)) badProof.push(`${r[0]}: "${proofCell || '(empty)'}"`);
  }
  if (badCapture.length) errors.push(captureFailedMessage(badCapture));
  if (badCount.length) errors.push(`[CHECK 10] Wrong column count (a stray "|" inside a cell splits the row): ${badCount.slice(0, 5).join(', ')}`);
  if (badProof.length) errors.push(`[CHECK 8] Test Proof must contain the plain filename TC_XX-slug.png.\n  Affected: ${badProof.slice(0, 5).join('; ')}`);

  const impactIdx = lines.findIndex(l => l.trim() === '## Cross-Module Impact');
  if (impactIdx !== -1) {
    const section = lines.slice(impactIdx + 1);
    const end = section.findIndex(l => /^##\s/.test(l.trim()));
    const impactRows = mdRows((end === -1 ? section : section.slice(0, end)).join('\n')).slice(1);
    const badSuffix = [], missingMention = [];
    for (const c of impactRows) {
      const team = c[1] || '', qa = c[2] || '';
      if (team && /\s(frontend|backend|fe|be)$/i.test(team)) badSuffix.push(team);
      // A markdown body has no mention node ("[~accountid:...]" posts as literal text), so a team with a documented QA owner can never pass here.
      if (team && TEAMS_WITH_QA_OWNERS.includes(team)) missingMention.push(team);
    }
    if (badSuffix.length) errors.push(`[CHECK 11] Cross-Module Impact "Team" value has a Frontend/Backend/FE/BE suffix.\n  Affected: ${badSuffix.join(', ')}`);
    if (missingMention.length) errors.push(`[CHECK 12] Cross-Module Impact has team(s) with a documented QA owner (${missingMention.join(', ')}), but a markdown body cannot carry a real mention.\n  Post the results comment as HTML (--format html): plain filenames go in <p> elements, the QA cell gets <span data-type="mention" data-user-id="...">.`);
  }
  // CHECK 16/17 and 21: see validateHtml.
  errors.push(...statsErrors(text));
  errors.push(...resultsLayout.footerCountErrors(text));
  return errors;
}

const TC10_HEADER = ['TC_ID', 'Test case scenario', 'Preconditions', 'Test steps', 'Expected Result', 'Actual result', 'Story number', 'Epic number', 'Automate', 'Risk'];
// A new Test Cases comment says `Automate`; --existing (correcting a comment posted before the rename) also accepts `Automated`.
const ACCEPTED_AUTOMATE = rest.includes('--existing') ? resultsLayout.AUTOMATE_NAMES : [resultsLayout.AUTOMATE_NAMES[0]];
const isTc10Header = (r) => r.length === TC10_HEADER.length && r.every((c, i) => (i === 8 ? ACCEPTED_AUTOMATE.includes(c) : c === TC10_HEADER[i]));
const VERDICT_RE = /(PASS ✅|FAIL ❌|BLOCKED 🚫|NEEDS REVIEW 🔍|SKIP ⏭️)/;

// KEEP IN SYNC with post-tc-comment.js (CHECK 0-6) and the Phase 2 template.
function validateTc(text, story) {
  const errors = [];
  const lines = text.split('\n');
  const firstContent = (lines.find(l => l.trim().length > 0) || '').trim();
  const headerMatch = /^##\s*Test Cases —\s*(\S+)\s*$/.exec(firstContent);
  if (!headerMatch) {
    errors.push(`[CHECK 1] The body must start with exactly "## Test Cases — ${story}".\n  Found: "${firstContent || '(empty)'}"`);
  } else if (headerMatch[1].toUpperCase() !== story.toUpperCase()) {
    errors.push(`[CHECK 0] Target mismatch. The header is for "${headerMatch[1]}" but the comment is for "${story}".`);
  }

  const extraHeadings = lines.filter(l => /^#{1,6}\s/.test(l.trim()) && !/^#{1,6}\s*Extended cases added after Human review\s*$/.test(l.trim())).slice(1);
  if (extraHeadings.length) errors.push(`[CHECK 3] Extra headings after the Test Cases header — Phase 2 allows no other sections.\n  Found: ${extraHeadings.slice(0, 3).map(l => `"${l.trim()}"`).join(', ')}`);

  const rows = mdRows(text);
  const headerIdx = rows.findIndex(isTc10Header);
  if (headerIdx === -1) errors.push(`[CHECK 2] 10-column TC table header not found. Expected exactly: | ${TC10_HEADER.join(' | ')} |${ACCEPTED_AUTOMATE.length > 1 ? ' (older comments: "Automated" in place of "Automate")' : ''}`);

  if (!lines.some(l => /^_AC coverage:.*Automated?:.*_$/.test(l.trim()))) {
    errors.push('[CHECK 4] Missing italic AC-coverage footer line.\n  Expected a line matching: _AC coverage: <covered>/<total> | Automate: <n> Yes / <m> No_');
  }

  const tcRows = rows.filter(r => /^TC_\d+$/.test(r[0] || ''));
  if (!tcRows.length) errors.push('[CHECK 7] The TC table has no TC_XX rows — an empty Test Cases comment must not be posted.');
  const badCols = tcRows.filter(r => r.length !== TC10_HEADER.length);
  if (badCols.length) errors.push(`[CHECK 5] ${badCols.length} TC row(s) do not have exactly 10 columns (a stray "|" inside a cell splits the row): ${badCols.slice(0, 2).map(r => r[0]).join(', ')}`);
  const wrongStory = tcRows.filter(r => r.length === TC10_HEADER.length && r[6].toUpperCase() !== story.toUpperCase());
  if (wrongStory.length) errors.push(`[CHECK 0] "Story number" must be ${story} in every row. Found: ${wrongStory.slice(0, 3).map(r => `${r[0]}=${r[6]}`).join(', ')}`);
  const verdictRows = tcRows.filter(r => VERDICT_RE.test(r.join(' | ')));
  if (verdictRows.length) errors.push(`[CHECK 6] Execution verdicts found in a Phase 2 TC table (Actual result must be "To be Tested"): ${verdictRows.slice(0, 2).map(r => r[0]).join(', ')}`);
  errors.push(...require('./tc-extended').validateExtended(text, { markdown: true, mainTotal, split: !!partOpt }));
  errors.push(...resultsLayout.footerCountErrors(text));
  return errors;
}

// The Test Cases comment as HTML (--kind tc --format html): what the MCP path posts when the story has more than 5 TCs, so
// the table can sit in an expand. KEEP IN SYNC with validateTc (markdown). The Extended-cases section is not supported in
// this form (extend-tc-comment.js writes wiki and markdown only): a comment with that section stays markdown.
function validateTcHtml(text, story) {
  const errors = [];
  const first = text.trimStart().match(/^<(h[1-6])[^>]*>([\s\S]*?)<\/\1>/i);
  const headerMatch = first && first[1].toLowerCase() === 'h2' ? /^Test Cases —\s*(\S+)$/.exec(stripTags(first[2])) : null;
  if (!headerMatch) {
    errors.push(`[CHECK 1] The body must start with exactly <h2>Test Cases — ${story}</h2>.\n  Found: ${first ? `<${first[1]}>${stripTags(first[2])}` : '(no heading at the start)'}`);
  } else if (headerMatch[1].toUpperCase() !== story.toUpperCase()) {
    errors.push(`[CHECK 0] Target mismatch. The header is for "${headerMatch[1]}" but the comment is for "${story}".`);
  }
  if (/<h[1-6][^>]*>\s*Extended cases added after Human review/i.test(text)) {
    errors.push('[CHECK 20] The "Extended cases added after Human review" section is not supported in an HTML Test Cases comment (extend-tc-comment.js writes wiki and markdown only). Post this comment as markdown (it then has no collapsible table).');
  }
  const tcTables = tablesOf(text).filter(t => { const r = rowsOf(t)[0]; return r && stripTags(cellInner(r[0] || '')) === 'TC_ID'; });
  if (!tcTables.length) errors.push(`[CHECK 2] 10-column TC table not found. Its header must be exactly: ${TC10_HEADER.join(' | ')}`);
  const tcRows = [];
  tcTables.forEach(t => {
    const rows = rowsOf(t);
    const header = rows[0].map(c => stripTags(cellInner(c)));
    if (!isTc10Header(header)) errors.push(`[CHECK 2] 10-column TC table header must be exactly ${TC10_HEADER.join(' | ')}\n  Found: ${header.join(' | ')}`);
    rows.slice(1).forEach(r => { if (/^TC_\d+$/.test(stripTags(cellInner(r[0] || '')))) tcRows.push(r.map(c => stripTags(cellInner(c)))); });
  });
  if (!tcRows.length) errors.push('[CHECK 7] The TC table has no TC_XX rows — an empty Test Cases comment must not be posted.');
  const badCols = tcRows.filter(r => r.length !== TC10_HEADER.length);
  if (badCols.length) errors.push(`[CHECK 5] ${badCols.length} TC row(s) do not have exactly 10 columns: ${badCols.slice(0, 2).map(r => r[0]).join(', ')}`);
  const wrongStory = tcRows.filter(r => r.length === TC10_HEADER.length && r[6].toUpperCase() !== story.toUpperCase());
  if (wrongStory.length) errors.push(`[CHECK 0] "Story number" must be ${story} in every row. Found: ${wrongStory.slice(0, 3).map(r => `${r[0]}=${r[6]}`).join(', ')}`);
  const verdictRows = tcRows.filter(r => VERDICT_RE.test(r.join(' | ')));
  if (verdictRows.length) errors.push(`[CHECK 6] Execution verdicts found in a Phase 2 TC table (Actual result must be "To be Tested"): ${verdictRows.slice(0, 2).map(r => r[0]).join(', ')}`);
  if (!visibleLines(text).some(l => /^AC coverage:.*Automated?:/.test(l))) {
    errors.push('[CHECK 4] Missing italic AC-coverage footer line.\n  Expected: <p><em>AC coverage: <covered>/<total> | Automate: <n> Yes / <m> No</em></p>');
  }
  errors.push(...expandErrors(text, tcTables));
  errors.push(...resultsLayout.footerCountErrors(text));
  return errors;
}

const TEMPLATE_TC_HTML = [
  '<h2>Test Cases — <STORY_KEY></h2>',
  '(more than 5 TCs: wrap the table — <details><summary>Test cases (<N>)</summary> <table>…</table> </details>; 5 or fewer: no <details>)',
  '<table><thead><tr>' + TC10_HEADER.map(h => `<th><p>${h}</p></th>`).join('') + '</tr></thead><tbody>',
  '<tr><td><p>TC_01</p></td><td><p>…</p></td><td><p>…</p></td><td><p>1. … 2. …</p></td><td><p>…</p></td><td><p>To be Tested</p></td><td><p>&lt;STORY_KEY&gt;</p></td><td><p>&lt;EPIC_KEY or N/A&gt;</p></td><td><p>Yes/No</p></td><td><p>High/Medium/Low</p></td></tr>',
  '</tbody></table>',
  '<p><em>AC coverage: <covered>/<total> | Automate: <n> Yes / <m> No</em></p>',
].join('\n');

const TEMPLATE_TC = [
  '## Test Cases — <STORY_KEY>', '',
  `| ${TC10_HEADER.join(' | ')} |`, '|---|---|---|---|---|---|---|---|---|---|',
  '| TC_01 | … | … | … | … | To be Tested | <STORY_KEY> | <EPIC_KEY or N/A> | Yes/No | High/Medium/Low |', '',
  '_AC coverage: <covered>/<total> | Automate: <n> Yes / <m> No_', '',
  '(optional, appended by extend-tc-comment.js — do not type it by hand)',
  '### Extended cases added after Human review',
  '_Human review: Claude generated <N> · Human requested <R> (accepted <A>, already covered <C>, declined <D>, added on request <P>) · Miss rate <X>% (<A+P>/<N+A+P>) · Last extended <YYYY-MM-DD>_',
].join('\n');

const TIMING_HINT = '<n>m or <h>h <m>m, then " (<n> pause)" / " (<n> pauses)" when the run had pauses — e.g. 38m (2 pauses), 1h 12m (1 pause), 42m';
const TIMING_HINT_HTML = TIMING_HINT.replace(/</g, '&lt;').replace(/>/g, '&gt;');
const TEMPLATE_HTML = [
  '<h2>QA Test Results</h2>',
  '<table><tbody>',
  ...STATS_LABELS.map(l => `<tr><td><p><strong>${l}</strong></p></td><td><p>${l === 'Test Execution Timing' ? TIMING_HINT_HTML : '&lt;value&gt;'}</p></td></tr>`),
  '</tbody></table>',
  '<table><thead><tr>' + TC_HEADER.map(h => `<th><p>${h}</p></th>`).join('') + '</tr></thead><tbody>',
  '<tr><td><p>TC_01</p></td><td><p>&lt;scenario&gt;</p></td><td><p>&lt;expected&gt;</p></td><td><p>&lt;actual&gt;</p></td><td><p>PASS ✅</p></td>' +
    '<td><figure data-type="media-single" data-layout="center" data-width="100" data-width-type="percentage"><div data-type="media" data-media-type="file" data-id="&lt;fileId&gt;" data-collection="&lt;collection&gt;" data-alt="TC_01-slug.png"></div></figure></td></tr>',
  '(one row per TC; Before:/After: or <item>: labels go in <p> elements between the figures; upload failed → <p>TC_01-slug.png</p>)',
  '</tbody></table>',
].join('\n');
const TEMPLATE_MD = [
  '## QA Test Results', '',
  '| **Concern** | <value> |', '|---|---|',
  ...STATS_LABELS.slice(1).map(l => `| **${l}** | ${l === 'Test Execution Timing' ? TIMING_HINT : '<value>'} |`), '',
  `| ${TC_HEADER.join(' | ')} |`, '|---|---|---|---|---|---|',
  '| TC_01 | <scenario> | <expected> | <actual> | PASS ✅ | TC_01-slug.png |',
].join('\n');

// UTF-8 text decoded as Windows-1252 ("PASS âœ…", "â€”", "Â·"). Windows PowerShell 5.1 `Get-Content` does this to a
// BOM-less UTF-8 file, and the garbled string then gets posted to Jira as-is.
const MOJIBAKE_RE = /[ÂÃâ][\u0080-¿ŒœŠšŸŽžƒˆ˜–—‘-„†-•…‰‹›€™]|�/g;
function validateEncoding(text) {
  const hits = [...new Set((text.match(MOJIBAKE_RE) || []).map(h => `"${h}"`))].slice(0, 5);
  if (!hits.length) return [];
  return [`[CHECK 0] Garbled characters (mojibake) in the body: ${hits.join(', ')} — UTF-8 text was decoded as Windows-1252.\n` +
    '  Cause: the body was read back with Windows PowerShell\'s Get-Content (default ANSI code page), or rebuilt from text read that way.\n' +
    '  Fix: rebuild the body from the template below and save it with the Write tool; to read a body file, use the Read tool or\n' +
    '  `Get-Content -Encoding utf8` — never plain Get-Content / type / cat in PowerShell. Then validate again.'];
}

const skillChecks = require('./skill-comment-checks');
const kindErrors = () => {
  if (kind === 'tc') return format === 'html' ? validateTcHtml(body, storyKey) : validateTc(body, storyKey);
  if (kind === 'gtc') return skillChecks.validateGtc(body, storyKey, partOpt, mainTotal);
  if (kind === 'exec') return skillChecks.validateKeyedResults(body, storyKey, { stats: 'required', requireProof: true, part: partOpt });
  if (kind === 'gresults') return skillChecks.validateKeyedResults(body, storyKey, { stats: 'optional', requireProof: false, part: partOpt });
  return format === 'html' ? validateHtml(body) : validateMarkdown(body);
};
// --previous <file>: the Test Cases comment as it is in Jira right now (read it with listJiraIssueComments,
// responseContentFormat html, and save that body). A merged body (12 columns) replaces that comment, so it must keep
// every TC row, every kept column and the AC-coverage footer (CHECK 18, see results-layout.js).
const previousFile = optValue('--previous');
const lostErrors = () => {
  if (kind !== 'results' || !previousFile) return [];
  let previous;
  try { previous = fs.readFileSync(previousFile, 'utf8'); }
  catch (e) { return [`[CHECK 18] Cannot read --previous ${previousFile}: ${e.message}`]; }
  const first = resultsLayout.tcRows(body)[0];
  return first && first.cells.length === resultsLayout.MERGED_COLS.length ? resultsLayout.lostFromTestCases(previous, body) : [];
};
const errors = validateEncoding(body)
  .concat(kindErrors())
  .concat(lostErrors())
  .concat(resultParts.partErrors(body, partOpt, partTcIds, runTotal));
const template = { tc: format === 'html' ? TEMPLATE_TC_HTML : TEMPLATE_TC, gtc: skillChecks.TEMPLATE_GTC, exec: skillChecks.TEMPLATE_EXEC, gresults: skillChecks.TEMPLATE_GRESULTS }[kind] || (format === 'html' ? TEMPLATE_HTML : TEMPLATE_MD);
if (errors.length === 0) {
  process.stdout.write('OK\n');
  process.exit(0);
}
process.stderr.write(
  `\n❌ validate-results-comment.js — ${kind === 'results' ? format : kind + ' comment'} body failed validation (${errors.length} issue(s)).\n` +
  `Discard this draft and rebuild it from the template below — do NOT reconstruct the format from memory:\n\n` +
  `──────── COPY THIS TEMPLATE ────────\n${template}\n────────────────────────────────────\n\n` +
  errors.join('\n\n') + '\n'
);
process.exit(1);
