#!/usr/bin/env node
/**
 * Duplicate-screenshot guard for Phase 3a.
 *
 * Hashes a TC's screenshot and checks it against every other screenshot hash already
 * recorded for the same story in this run. A byte-identical screenshot shared by two
 * different TCs is exactly the failure mode that shipped on MXTS-76681 (2026-08-07):
 * a capture bug silently produced the same cropped/incomplete image for three TCs in a
 * row. That specific cause (nested `overflow: auto` containers `fullPage: true` can't
 * reach) is fixed separately — see "Large-viewport capture for Finance/Bill pages" in
 * references/phase-3a-execution.md — but this guard is a backstop for ANY future cause
 * of the same symptom, not a re-check of that one fix.
 *
 * This does NOT block the pipeline. A shared screenshot is occasionally legitimate
 * (e.g. two BLOCKED TCs that both hit the identical "reservation not found" empty
 * state, or a deliberate single comprehensive screenshot that legitimately answers
 * more than one TC's question — see Phase 3a's "Duplicate screenshot detected" handling
 * in references/phase-3a-execution.md for what to do with the result). It only surfaces
 * the collision so a human-legible reason ends up next to the evidence instead of an
 * unexplained duplicate silently reaching Jira.
 *
 * Usage:
 *   node check-screenshot-hash.js <epic_id> <story_key> <tc_id> <screenshot_path>
 *
 * Exit 0  — hash is new for this story, nothing to report.
 * Exit 2  — hash already seen for a DIFFERENT TC in this story (prints the colliding
 *           TC_ID(s) to stderr). Non-fatal — the caller decides what to do.
 * Exit 1  — usage/IO error (bad args, file not found, ledger unreadable/unwritable).
 */

const [, , epicId, storyKey, tcId, screenshotPath] = process.argv;

if (!epicId || !storyKey || !tcId || !screenshotPath) {
  process.stderr.write('Usage: node check-screenshot-hash.js <epic_id> <story_key> <tc_id> <screenshot_path>\n');
  process.exit(1);
}

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

if (!fs.existsSync(screenshotPath)) {
  process.stderr.write(`File not found: ${screenshotPath}\n`);
  process.exit(1);
}

const ledgerPath = path.join('test-output', epicId, 'screenshot-hashes.json');

function loadLedger() {
  let raw;
  try {
    raw = fs.readFileSync(ledgerPath, 'utf8');
  } catch (err) {
    if (err.code === 'ENOENT') return {}; // no ledger yet — first screenshot for this epic
    process.stderr.write(`Could not read ${ledgerPath}: ${err.message}\n`);
    process.exit(1);
  }
  try {
    return JSON.parse(raw);
  } catch (err) {
    // A ledger that exists but fails to parse is corruption, not "no ledger yet" — treating it
    // as empty would silently discard every previously-recorded hash and hide real collisions.
    process.stderr.write(`Could not parse ${ledgerPath}: ${err.message}\n`);
    process.exit(1);
  }
}

let hash;
try {
  hash = crypto.createHash('sha256').update(fs.readFileSync(screenshotPath)).digest('hex');
} catch (err) {
  process.stderr.write(`Could not hash ${screenshotPath}: ${err.message}\n`);
  process.exit(1);
}

const ledger = loadLedger();
const story = ledger[storyKey] || {};
const existing = story[hash] || [];
const collidingWithOthers = existing.filter(id => id !== tcId);

// Record this TC against the hash (idempotent — safe to call more than once per TC,
// e.g. on a retake after a blank-screenshot retry).
story[hash] = Array.from(new Set([...existing, tcId]));
ledger[storyKey] = story;

try {
  fs.mkdirSync(path.dirname(ledgerPath), { recursive: true });
  fs.writeFileSync(ledgerPath, JSON.stringify(ledger, null, 2));
} catch (err) {
  process.stderr.write(`Could not write ${ledgerPath}: ${err.message}\n`);
  process.exit(1);
}

if (collidingWithOthers.length > 0) {
  process.stderr.write(
    `[Duplicate] ${tcId}'s screenshot is byte-identical to: ${collidingWithOthers.join(', ')} (same story, same run).\n`
  );
  process.exit(2);
}

process.exit(0);
