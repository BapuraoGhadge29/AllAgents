#!/usr/bin/env node
/**
 * Are the screenshots really in the Jira results comment?
 *
 * A results comment on the MCP path shows a screenshot only when its Test Proof cell holds a media node
 * (`<div data-type="media" data-id="…" data-alt="<file>">`). A plain `<p>TC_01-result.png</p>` is a filename,
 * not an image: it is what the comment carries when an upload failed or was skipped. This script counts both,
 * so the pipeline never has to assume that "posted" means "screenshots are visible".
 *
 * Run it twice per post or edit: on the body file before posting, and on the comment read back afterwards.
 *
 * Usage:
 *   node verify-screenshot-embeds.js <html_file> [--expect <body_file>] [--comment-id <id>]
 *
 *   <html_file>   a comment body in HTML, or the JSON that `listJiraIssueComments` returned (also when the
 *                 harness saved that result to a file); --comment-id picks the comment out of a list
 *   --expect      the body file that was posted: every screenshot it names must be embedded in <html_file>
 *                 (without it, the screenshots named in <html_file> itself are the expectation)
 *
 * stdout:
 *   MISSING <file> plain-filename | absent     one line per screenshot that is not an embedded image
 *   embedded <n>/<m>
 * Exit 0 when every expected screenshot is embedded, 1 when any is not (or none is referenced), 2 on a usage error.
 * `<name>-capture-failed.png` entries are plain on purpose (the capture itself failed) and are not counted.
 */
'use strict';

const fs = require('fs');

const IMAGE = '[A-Za-z0-9_][A-Za-z0-9_.-]*\\.(?:png|jpe?g)';
const PLAIN_PROOF = new RegExp(`<p>\\s*(${IMAGE})(?:\\s+\\([^<]*\\))?\\s*</p>`, 'g');

function decode(s) {
  return s
    .replace(/&#0*39;|&apos;/g, "'")
    .replace(/&quot;/g, '"')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&amp;/g, '&');
}

function bodyOf(raw, commentId) {
  let json;
  try {
    json = JSON.parse(raw);
    if (Array.isArray(json) && json[0] && typeof json[0].text === 'string') json = JSON.parse(json[0].text);
  } catch (e) {
    return raw;
  }
  const comments = (json && json.data && json.data.comments) || (json && json.comments);
  if (Array.isArray(comments)) {
    const hit = commentId ? comments.find((c) => String(c.id) === String(commentId)) : comments.length === 1 ? comments[0] : null;
    if (!hit || typeof hit.body !== 'string') throw new Error(commentId ? `comment ${commentId} not found` : 'pass --comment-id: the file holds several comments');
    return hit.body;
  }
  if (json && json.data && typeof json.data.body === 'string') return json.data.body;
  return raw;
}

function embeddedNames(html) {
  const named = [];
  let unnamed = 0;
  for (const tag of html.match(/<div\b[^>]*\bdata-type="media"[^>]*>/g) || []) {
    const alt = /\bdata-alt="([^"]*)"/.exec(tag);
    if (alt) named.push(decode(alt[1]));
    else unnamed++;
  }
  return { named, unnamed };
}

function plainNames(html) {
  const withoutFigures = html.replace(/<figure\b[\s\S]*?<\/figure>/g, '');
  return [...withoutFigures.matchAll(PLAIN_PROOF)].map((m) => m[1]);
}

const counted = (name) => !/capture-failed/i.test(name);

/** @returns {{expected:string[], missing:{name:string, why:string}[]}} */
function verify(commentHtml, expectHtml) {
  const have = embeddedNames(commentHtml);
  const plain = new Set(plainNames(commentHtml));
  const source = expectHtml === undefined ? commentHtml : expectHtml;
  const expected = [...new Set([...embeddedNames(source).named, ...plainNames(source)])].filter(counted);
  const embedded = new Set(have.named);
  let spare = have.unnamed;
  const missing = [];
  for (const name of expected) {
    if (embedded.has(name)) continue;
    if (spare > 0) {
      spare--;
      continue;
    }
    missing.push({ name, why: plain.has(name) ? 'plain-filename' : 'absent' });
  }
  return { expected, missing };
}

function main() {
  const argv = process.argv.slice(2);
  const file = argv[0];
  const opt = (name) => (argv.includes(name) ? argv[argv.indexOf(name) + 1] : undefined);
  if (!file || file.startsWith('--')) {
    process.stderr.write('Usage: node verify-screenshot-embeds.js <html_file> [--expect <body_file>] [--comment-id <id>]\n');
    process.exit(2);
  }
  let html;
  let expect;
  try {
    html = bodyOf(fs.readFileSync(file, 'utf8'), opt('--comment-id'));
    if (opt('--expect')) expect = bodyOf(fs.readFileSync(opt('--expect'), 'utf8'));
  } catch (e) {
    process.stderr.write(`${e.message}\n`);
    process.exit(2);
  }
  const { expected, missing } = verify(html, expect);
  for (const m of missing) process.stdout.write(`MISSING ${m.name} ${m.why}\n`);
  if (expected.length === 0) process.stdout.write('NONE no screenshot references found\n');
  process.stdout.write(`embedded ${expected.length - missing.length}/${expected.length}\n`);
  process.exit(missing.length === 0 && expected.length > 0 ? 0 : 1);
}

if (require.main === module) main();

module.exports = { bodyOf, verify };
