#!/usr/bin/env node
/**
 * End-to-end test of the split Test Cases comment (parts) merged in place into its results (parts), on a stateful stub Jira.
 * Self-contained: node:test + node:assert; no real Jira call.
 *   - script path (wiki): 85 TCs -> 3 parts (40/23/22): post the Test Cases parts, refuse a second results comment per part,
 *     merge every part in place (same comment ids, same comment count), reconcile.
 *   - MCP path (HTML): 130 TCs -> 4 parts (40/40/40/10): every part's table is collapsible, validate Test Cases parts, merged
 *     parts (--previous), reconcile.
 *   - compaction: with no run-state at all, the guards decide from what Jira holds.
 * Run: node plugins/qa-engineer/skills/test-ticket/scripts/split-merge.test.js
 */
'use strict';

const test = require('node:test');
const assert = require('node:assert');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { spawnSync } = require('child_process');
const rp = require('./result-parts');
const layout = require('./results-layout');

const KEY = 'QA-1';
const TC10 = layout.MERGED_COLS.slice(0, 10).map((c, i) => (i === 8 ? 'Automate' : c));
const idOf = (i) => `TC_${String(i).padStart(2, '0')}`;
const range = (n) => Array.from({ length: n }, (_, i) => i + 1);
const risk = (i) => ['High', 'Medium', 'Low'][i % 3];
const isAuto = (i) => i % 3 === 0;
const statusOf = (i) => (i % 13 === 0 ? 'BLOCKED 🚫' : i % 9 === 0 ? 'FAIL ❌' : 'PASS ✅');
const key = (s) => s.split(' ')[0];

const inTmp = (fn) => { const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'split-')); try { return fn(dir); } finally { fs.rmSync(dir, { recursive: true, force: true }); } };
const write = (dir, name, text) => { const f = path.join(dir, name); fs.writeFileSync(f, text); return f; };

// ─── stateful stub Jira (file-backed, shared by the child processes) ────────

const stubSource = `
  const fs = require('fs');
  const store = process.env.STUB_STORE;
  const load = () => JSON.parse(fs.readFileSync(store, 'utf8'));
  const save = (s) => fs.writeFileSync(store, JSON.stringify(s));
  globalThis.fetch = async (url, opts = {}) => {
    const json = (data, status = 200) => ({ ok: status < 400, status, json: async () => data, text: async () => JSON.stringify(data) });
    const s = load();
    const method = opts.method || 'GET';
    const now = new Date().toISOString();
    if (method === 'POST') { const id = String(s.next++); s.comments.push({ id, body: JSON.parse(opts.body).body, created: now, updated: now }); save(s); return json({ id }); }
    const m = /\\/comment\\/(\\d+)$/.exec(url);
    if (method === 'PUT') { const c = s.comments.find(x => x.id === m[1]); if (!c) return json({}, 404); c.body = JSON.parse(opts.body).body; c.updated = now; save(s); return json({ id: c.id }); }
    if (/\\/comment\\?/.test(url)) return json({ total: s.comments.length, comments: s.comments.slice().reverse() });
    if (m) { const c = s.comments.find(x => x.id === m[1]); return c ? json(c) : json({}, 404); }
    const names = []; for (let i = 1; i <= 300; i++) { const n = String(i).padStart(2, '0'); names.push({ filename: 'TC_' + n + '-a.png' }); }
    return json({ fields: { attachment: names } });
  };`;

function makeJira(dir) {
  const store = path.join(dir, 'store.json');
  fs.writeFileSync(store, JSON.stringify({ next: 1000, comments: [] }));
  const stub = write(dir, 'stub.js', stubSource);
  const env = { ...process.env, JIRA_EMAIL: 'a@b.c', JIRA_API_TOKEN: 'x', STUB_STORE: store };
  return {
    comments: () => JSON.parse(fs.readFileSync(store, 'utf8')).comments,
    run: (script, args) => spawnSync(process.execPath, ['--require', stub, path.join(__dirname, script), ...args], { encoding: 'utf8', env }),
  };
}
const offline = (script, args) => spawnSync(process.execPath, [path.join(__dirname, script), ...args], { encoding: 'utf8' });

// ─── bodies ─────────────────────────────────────────────────────────────────

const counts = (n) => {
  const c = { PASS: 0, FAIL: 0, BLOCKED: 0 };
  range(n).forEach(i => { c[key(statusOf(i))]++; });
  return { ...c, rate: Math.round((100 * c.PASS) / (n - c.BLOCKED)) };
};
const statRows = (n, ids) => {
  const c = counts(n);
  const first = Number(ids[0].slice(3)), last = Number(ids[ids.length - 1].slice(3));
  return [['Concern', 'MQA'], ['Environment', 'Dev'], ['Build / Version', 'V1'], ['Preconditions', 'None detected'], ['Total TCs', `${n} (${first}-${last})`],
    ['Passed', c.PASS], ['Failed', c.FAIL], ['Blocked', c.BLOCKED], ['Needs Review', 0], ['Skipped', 0], ['Pass rate', `${c.rate}% (BLOCKED and Skipped excluded)`],
    ['QA Pipeline Version', '2.13.0'], ['Test Execution Timing', '40m']];
};
const nums = (ids) => ids.map(id => Number(id.slice(3)));
const footer = (n, ids, label = 'Automate') => { const y = nums(ids).filter(isAuto).length; return `AC coverage: ${n}/${n} | ${label}: ${y} Yes / ${ids.length - y} No`; };

// wiki
const wikiTcPart = (n, p, m, ids, total) => ['h2. Test Cases — ' + KEY, `_Part ${p} of ${m}_`, '', layout.wikiHeader(TC10),
  ...nums(ids).map(i => `| ${idOf(i)} | Scenario ${i} | Logged in | 1. Open. 2. Act ${i}. | Expected ${i} | To be Tested | ${KEY} | N/A | ${isAuto(i) ? 'Yes' : 'No'} | ${risk(i)} |`), '', `_${footer(total, ids)}_`].join('\n');
const wikiMergedPart = (total, p, m, ids) => ['h2. QA Test Results', `_Part ${p} of ${m}_`, '', ...statRows(total, ids).map(([k, v]) => `| *${k}* | ${v} |`), '', layout.wikiHeader(layout.MERGED_COLS),
  ...nums(ids).map(i => `| ${idOf(i)} | Scenario ${i} | Logged in | 1. Open. 2. Act ${i}. | Expected ${i} | Result ${i} | ${KEY} | N/A | ${isAuto(i) ? 'Yes' : 'No'} | ${risk(i)} | ${statusOf(i)} | !${idOf(i)}-a.png! |`), '', `_${footer(total, ids, 'Automated')}_`].join('\n');

// HTML
const td = (c) => `<td><p>${c}</p></td>`;
const table = (cols, rows) => `<table><thead><tr>${cols.map(c => `<th><p>${c}</p></th>`).join('')}</tr></thead><tbody>${rows.map(r => `<tr>${r.map(td).join('')}</tr>`).join('')}</tbody></table>`;
const htmlTcPart = (p, m, ids, total) => `<h2>Test Cases — ${KEY}</h2><p>Part ${p} of ${m}</p><details><summary>Test cases (${ids.length})</summary>` +
  table(TC10, nums(ids).map(i => [idOf(i), `Scenario ${i}`, 'Logged in', `1. Open. 2. Act ${i}.`, `Expected ${i}`, 'To be Tested', KEY, 'N/A', isAuto(i) ? 'Yes' : 'No', risk(i)])) +
  `</details><p><em>${footer(total, ids)}</em></p>`;
const htmlMergedPart = (total, p, m, ids) => {
  const c = counts(total);
  const stats = '<table><tbody>' + statRows(total, ids).map(([k, v]) => `<tr><td><p><strong>${k}</strong></p></td>${td(v)}</tr>`).join('') + '</tbody></table>';
  const rows = nums(ids).map(i => [idOf(i), `Scenario ${i}`, 'Logged in', `1. Open. 2. Act ${i}.`, `Expected ${i}`, `Result ${i}`, KEY, 'N/A', isAuto(i) ? 'Yes' : 'No', risk(i), statusOf(i), `${idOf(i)}-a.png`]);
  return `<h2>QA Test Results</h2><p>Part ${p} of ${m}</p>${stats}<details><summary>Results: ${total} TCs — ${c.PASS} passed, ${c.FAIL} failed, ${c.BLOCKED} blocked</summary>${table(layout.MERGED_COLS, rows)}</details><p><em>${footer(total, ids, 'Automated')}</em></p>`;
};

const planOf = (total) => rp.planParts(range(total).map(idOf)).map((ids, i, all) => ({ part: i + 1, of: all.length, tc_ids: ids, comment_id: null }));

// ─── script path (wiki), 85 TCs -> 3 parts ──────────────────────────────────

test('split, script path: 85 TCs make 3 Test Cases parts; each part is merged in place; nothing is duplicated or lost', () => inTmp(dir => {
  const jira = makeJira(dir);
  const total = 85;
  const plan = planOf(total);
  assert.deepStrictEqual(plan.map(p => p.tc_ids.length), [40, 23, 22]);
  const m = plan.length;

  // before execution: validate every part offline, then post them in order
  plan.forEach(p => {
    const f = write(dir, `tc${p.part}.txt`, wikiTcPart(total, p.part, m, p.tc_ids, total));
    const args = [KEY, f, '--part', `${p.part}/${m}`, '--tc-ids', p.tc_ids.join(',')];
    const v = offline('post-tc-comment.js', [...args, '--validate-only']);
    assert.strictEqual(v.status, 0, `part ${p.part}: ${v.stderr}`);
  });
  plan.forEach(p => {
    const f = path.join(dir, `tc${p.part}.txt`);
    const r = jira.run('post-tc-comment.js', [KEY, f, '--part', `${p.part}/${m}`, '--tc-ids', p.tc_ids.join(',')]);
    assert.strictEqual(r.status, 0, r.stderr);
    p.comment_id = r.stdout.trim().split('\n').pop();
  });
  assert.strictEqual(jira.comments().length, 3);
  // posting the same part again is blocked by the duplicate guard
  const again = jira.run('post-tc-comment.js', [KEY, path.join(dir, 'tc2.txt'), '--part', `2/${m}`, '--tc-ids', plan[1].tc_ids.join(',')]);
  assert.match(again.stdout, /Duplicate blocked/);
  assert.strictEqual(jira.comments().length, 3);

  // compaction: no run-state, nothing remembered. A separate results comment for any part is refused and names the comment to edit.
  plan.forEach(p => {
    const f = write(dir, `res${p.part}.txt`, wikiMergedPart(total, p.part, m, p.tc_ids));
    const r = jira.run('post-comment.js', [KEY, f, '--part', `${p.part}/${m}`, '--tc-ids', p.tc_ids.join(','), '--run-total', String(total)]);
    assert.strictEqual(r.status, 1, `part ${p.part}: ${r.stdout}${r.stderr}`);
    assert.match(r.stderr, new RegExp(`update-comment\\.js ${KEY} ${p.comment_id}`));
  });
  assert.strictEqual(jira.comments().length, 3);

  // after execution: merge part 1 first, then (as after a compaction) check the guards from Jira alone, then merge the rest
  const merge = (p) => jira.run('update-comment.js', [KEY, p.comment_id, path.join(dir, `res${p.part}.txt`), '--part', `${p.part}/${m}`, '--tc-ids', p.tc_ids.join(','), '--run-total', String(total)]);
  const first = merge(plan[0]);
  assert.strictEqual(first.status === 0 || first.status === 3, true, first.stdout + first.stderr);
  assert.match(first.stdout, new RegExp(`Updated comment ${plan[0].comment_id}`));
  const dupPart1 = jira.run('post-comment.js', [KEY, path.join(dir, 'res1.txt'), '--part', `1/${m}`, '--tc-ids', plan[0].tc_ids.join(','), '--run-total', String(total)]);
  assert.match(dupPart1.stdout, /Duplicate blocked/, dupPart1.stdout + dupPart1.stderr);
  const part2still = jira.run('post-comment.js', [KEY, path.join(dir, 'res2.txt'), '--part', `2/${m}`, '--tc-ids', plan[1].tc_ids.join(','), '--run-total', String(total)]);
  assert.strictEqual(part2still.status, 1);
  plan.slice(1).forEach(p => { const r = merge(p); assert.strictEqual(r.status === 0 || r.status === 3, true, r.stdout + r.stderr); });

  // same ids, same count, every part now a results part
  const after = jira.comments();
  assert.deepStrictEqual(after.map(c => c.id), plan.map(p => p.comment_id));
  after.forEach((c, i) => {
    assert.ok(c.body.startsWith('h2. QA Test Results'), `part ${i + 1} header`);
    assert.ok(c.body.includes(`_Part ${i + 1} of ${m}_`));
    assert.deepStrictEqual(rp.tcIdsFromBody(c.body), plan[i].tc_ids);
  });
  const planFile = write(dir, 'plan.json', JSON.stringify(plan));
  const files = after.map((c, i) => write(dir, `posted${i + 1}.txt`, c.body));
  const rec = offline('result-parts.js', ['reconcile', '--plan', planFile, ...files.flatMap(f => ['--body-file', f])]);
  assert.strictEqual(rec.status, 0, rec.stderr);
  assert.match(rec.stdout, /OK — 85 TC\(s\) across 3 part\(s\)/);
}));

test('split, script path: a merged part that loses a TC, changes a kept column or has a wrong footer is refused and nothing is sent', () => inTmp(dir => {
  const jira = makeJira(dir);
  const total = 50;
  const plan = planOf(total);
  const m = plan.length;
  plan.forEach(p => {
    const r = jira.run('post-tc-comment.js', [KEY, write(dir, `tc${p.part}.txt`, wikiTcPart(total, p.part, m, p.tc_ids, total)), '--part', `${p.part}/${m}`, '--tc-ids', p.tc_ids.join(',')]);
    p.comment_id = r.stdout.trim().split('\n').pop();
  });
  const p = plan[1];
  const good = wikiMergedPart(total, 2, m, p.tc_ids);
  const run = (body) => jira.run('update-comment.js', [KEY, p.comment_id, write(dir, 'b.txt', body), '--part', `2/${m}`, '--tc-ids', p.tc_ids.join(','), '--run-total', String(total)]);
  const before = jira.comments().find(c => c.id === p.comment_id).body;
  assert.strictEqual(run(good.replace('Scenario 41', 'Scenario CHANGED')).status, 1);
  assert.strictEqual(run(good.split('\n').filter(l => !l.startsWith('| TC_45 ')).join('\n')).status, 1);
  const badFooter = run(good.replace(/Automated: \d+ Yes/, 'Automated: 9 Yes'));
  assert.strictEqual(badFooter.status, 1);
  assert.match(badFooter.stderr, /CHECK 21/);
  assert.strictEqual(jira.comments().find(c => c.id === p.comment_id).body, before, 'the live comment must be untouched after refused updates');
  const ok = run(good);
  assert.strictEqual(ok.status === 0 || ok.status === 3, true, ok.stdout + ok.stderr);
}));

// ─── MCP path (HTML), 130 TCs -> 4 parts, every table collapsible ──────────────────────────────

test('split, MCP path: 130 TCs make 4 parts, every part table is in an expand, parts validate, merge keeps everything, reconcile passes', () => inTmp(dir => {
  const total = 130;
  const plan = planOf(total);
  assert.deepStrictEqual(plan.map(p => p.tc_ids.length), [40, 40, 40, 10]);
  const m = plan.length;
  const tcFiles = [], mergedFiles = [];
  plan.forEach(p => {
    const tcBody = htmlTcPart(p.part, m, p.tc_ids, total);
    assert.ok(/<details>/.test(tcBody), 'each part has more than 5 TCs and sits in an expand');
    const tcFile = write(dir, `tc${p.part}.html`, tcBody);
    tcFiles.push(tcFile);
    const v = offline('validate-results-comment.js', [tcFile, '--kind', 'tc', '--story', KEY, '--format', 'html', '--part', `${p.part}/${m}`, '--tc-ids', p.tc_ids.join(',')]);
    assert.strictEqual(v.status, 0, `Test Cases part ${p.part}: ${v.stderr}`);
    const mergedFile = write(dir, `merged${p.part}.html`, htmlMergedPart(total, p.part, m, p.tc_ids));
    mergedFiles.push(mergedFile);
    const r = offline('validate-results-comment.js', [mergedFile, '--format', 'html', '--part', `${p.part}/${m}`, '--tc-ids', p.tc_ids.join(','), '--run-total', String(total), '--previous', tcFile]);
    assert.strictEqual(r.status, 0, `merged part ${p.part}: ${r.stderr}`);
  });
  // Test Cases parts reconcile as the plan says, and so do the merged parts
  const planFile = write(dir, 'plan.json', JSON.stringify(plan));
  const recTc = offline('result-parts.js', ['reconcile', '--plan', planFile, ...tcFiles.flatMap(f => ['--body-file', f])]);
  assert.strictEqual(recTc.status, 0, recTc.stderr);
  const rec = offline('result-parts.js', ['reconcile', '--plan', planFile, ...mergedFiles.flatMap(f => ['--body-file', f])]);
  assert.strictEqual(rec.status, 0, rec.stderr);
  assert.match(rec.stdout, /OK — 130 TC\(s\) across 4 part\(s\)/);
}));

test('split, MCP path: a part without its expand, a lost TC or a wrong whole-story count is caught', () => inTmp(dir => {
  const total = 130;
  const plan = planOf(total);
  const m = plan.length;
  const p = plan[1];
  const tc = write(dir, 'tc.html', htmlTcPart(2, m, p.tc_ids, total));
  const args = (f) => [f, '--format', 'html', '--part', `2/${m}`, '--tc-ids', p.tc_ids.join(','), '--run-total', String(total), '--previous', tc];
  const good = htmlMergedPart(total, 2, m, p.tc_ids);
  assert.strictEqual(offline('validate-results-comment.js', args(write(dir, 'g.html', good))).status, 0);
  const noExpand = offline('validate-results-comment.js', args(write(dir, 'n.html', good.replace(/<details>.*?<\/summary>/, '').replace('</details>', ''))));
  assert.strictEqual(noExpand.status, 1);
  assert.match(noExpand.stderr, /CHECK 19/);
  const lost = offline('validate-results-comment.js', args(write(dir, 'l.html', good.replace(/<tr><td><p>TC_45<\/p>.*?<\/tr>/, ''))));
  assert.strictEqual(lost.status, 1);
  assert.match(lost.stderr, /CHECK 14|CHECK 18/);
  const wrongStats = offline('validate-results-comment.js', args(write(dir, 'w.html', good.replace(/(<strong>Passed<\/strong><\/p><\/td><td><p>)\d+/, '$11'))));
  assert.strictEqual(wrongStats.status, 1);
  assert.match(wrongStats.stderr, /CHECK 14/);
}));

// ─── parts sized for the MERGED comment (realistic row lengths) ─────────────────────────────

const words = (n) => 'lorem ipsum dolor sit amet '.repeat(Math.ceil(n / 27)).slice(0, n).trim();
const keyLink = `<a href="https://maxxton.atlassian.net/browse/${KEY}#icft=${KEY}" data-card-appearance="inline">https://maxxton.atlassian.net/browse/${KEY}#icft=${KEY}</a>`;
const proofCell = (i) => `<td><figure data-type="media-single" data-layout="center" data-width="100" data-width-type="percentage"><div data-type="media" data-media-type="file" data-id="d9a28989-fcac-40e5-8ca8-196c5d70063b" data-collection="contentId-1" data-alt="${idOf(i)}-slug-name.png"></div></figure><p> </p></td>`;
const tdRaw = (c) => `<td><p>${c}</p></td>`;
const realCells = (i, actual) => [idOf(i), `${words(100)} ${i}`, words(90), `1. ${words(95)} 2. ${words(95)}`, words(140), actual, keyLink, keyLink, isAuto(i) ? 'Yes' : 'No', risk(i)];
const realTcRowHtml = (i) => `<tr>${realCells(i, 'To be Tested').map(tdRaw).join('')}</tr>`;
const realMergedRowHtml = (i) => `<tr>${realCells(i, words(230)).map(tdRaw).join('')}${tdRaw(statusOf(i))}${proofCell(i)}</tr>`;
const realTcDraftHtml = (ids) => `<h2>Test Cases — ${KEY}</h2><table><thead><tr>${TC10.map(c => `<th><p>${c}</p></th>`).join('')}</tr></thead><tbody>${nums(ids).map(realTcRowHtml).join('')}</tbody></table><p><em>${footer(ids.length, ids)}</em></p>`;
const realMergedPartHtml = (total, p, m, ids) => {
  const c = counts(total);
  const stats = '<table><tbody>' + statRows(total, ids).map(([k, v]) => `<tr><td><p><strong>${k}</strong></p></td>${td(v)}</tr>`).join('') + '</tbody></table>';
  const head = `<thead><tr>${layout.MERGED_COLS.map(h => `<th><p>${h}</p></th>`).join('')}</tr></thead>`;
  return `<h2>QA Test Results</h2><p>Part ${p} of ${m}</p>${stats}<details><summary>Results: ${total} TCs — ${c.PASS} passed, ${c.FAIL} failed, ${c.BLOCKED} blocked</summary><table>${head}<tbody>${nums(ids).map(realMergedRowHtml).join('')}</tbody></table></details><p><em>${footer(total, ids, 'Automated')}</em></p>`;
};
const realTcRowWiki = (i) => `| ${idOf(i)} | ${words(100)} ${i} | ${words(90)} | 1. ${words(95)} 2. ${words(95)} | ${words(140)} | To be Tested | ${KEY} | QA-5111 | ${isAuto(i) ? 'Yes' : 'No'} | ${risk(i)} |`;
const realMergedRowWiki = (i) => `| ${idOf(i)} | ${words(100)} ${i} | ${words(90)} | 1. ${words(95)} 2. ${words(95)} | ${words(140)} | ${words(230)} | ${KEY} | QA-5111 | ${isAuto(i) ? 'Yes' : 'No'} | ${risk(i)} | ${statusOf(i)} | !${idOf(i)}-slug-name.png! |`;
const realTcDraftWiki = (ids) => ['h2. Test Cases — ' + KEY, '', layout.wikiHeader(TC10), ...nums(ids).map(realTcRowWiki), '', `_${footer(ids.length, ids)}_`].join('\n');
const realMergedPartWiki = (total, p, m, ids) => ['h2. QA Test Results', `_Part ${p} of ${m}_`, '', ...statRows(total, ids).map(([k, v]) => `| *${k}* | ${v} |`), '', layout.wikiHeader(layout.MERGED_COLS), ...nums(ids).map(realMergedRowWiki), '', `_${footer(total, ids, 'Automated')}_`].join('\n');

const planCli = (dir, total, draft) => {
  const ids = write(dir, 'ids.txt', range(total).map(idOf).join(','));
  const r = offline('result-parts.js', ['plan', '--ids-file', ids, '--merged-from', write(dir, 'draft.txt', draft)]);
  assert.strictEqual(r.status, 0, r.stderr);
  return JSON.parse(r.stdout);
};

test('merged sizing, HTML: parts planned from real row lengths stay under 32,000 characters once merged; the fixed 40-row plan does not', () => inTmp(dir => {
  const total = 60;
  const ids = range(total).map(idOf);
  const plan = planCli(dir, total, realTcDraftHtml(ids));
  assert.ok(plan.split && plan.parts.length >= 3, `60 realistic HTML TCs need several parts, got ${plan.parts.length}`);
  assert.strictEqual(plan.basis, 'merged html');
  assert.deepStrictEqual(plan.parts.flatMap(p => p.tc_ids), ids);
  plan.parts.forEach(p => {
    const body = realMergedPartHtml(total, p.part, p.of, p.tc_ids);
    assert.ok(body.length < 32000, `part ${p.part}: ${body.length} characters`);
    const r = offline('validate-results-comment.js', [write(dir, `m${p.part}.html`, body), '--format', 'html', '--part', `${p.part}/${p.of}`, '--tc-ids', p.tc_ids.join(','), '--run-total', String(total)]);
    assert.strictEqual(r.status, 0, `part ${p.part}: ${r.stderr}`);
  });
  const fixed = rp.planParts(ids)[0];
  const tooBig = realMergedPartHtml(total, 1, 2, fixed);
  const r = offline('validate-results-comment.js', [write(dir, 'big.html', tooBig), '--format', 'html', '--part', '1/2', '--tc-ids', fixed.join(','), '--run-total', String(total)]);
  assert.strictEqual(r.status, 1);
  assert.match(r.stderr, /CHECK 15/);
}));

test('merged sizing, wiki: 100 realistic TCs are split by length, every merged part passes the length guard, and a small story is not split', () => inTmp(dir => {
  const total = 100;
  const ids = range(total).map(idOf);
  const plan = planCli(dir, total, realTcDraftWiki(ids));
  assert.strictEqual(plan.basis, 'merged wiki');
  assert.deepStrictEqual(plan.parts.flatMap(p => p.tc_ids), ids);
  plan.parts.forEach(p => {
    const body = realMergedPartWiki(total, p.part, p.of, p.tc_ids);
    assert.ok(body.length < 32000, `part ${p.part}: ${body.length} characters`);
    const r = offline('post-comment.js', [KEY, write(dir, `w${p.part}.txt`, body), '--part', `${p.part}/${p.of}`, '--tc-ids', p.tc_ids.join(','), '--run-total', String(total), '--validate-only']);
    assert.strictEqual(r.status, 0, `part ${p.part}: ${r.stderr}`);
  });
  const small = planCli(dir, 10, realTcDraftWiki(range(10).map(idOf)));
  assert.strictEqual(small.split, false);
  assert.strictEqual(small.parts.length, 1);
}));

test('merged sizing: parts leave headroom for longer evidence, and --extra-per-row plans for heavy evidence (never below the default)', () => inTmp(dir => {
  const total = 60;
  const ids = range(total).map(idOf);
  const draft = realTcDraftHtml(ids);
  const base = planCli(dir, total, draft);
  base.parts.forEach(p => assert.ok(p.estimated_chars <= Math.floor((32000 - 3500) * 0.85) + 3500, `part ${p.part}: ${p.estimated_chars}`));
  assert.strictEqual(base.row_allowance_chars, 700);
  const idsFile = write(dir, 'heavy-ids.txt', ids.join(','));
  const heavy = offline('result-parts.js', ['plan', '--ids-file', idsFile, '--merged-from', write(dir, 'heavy.txt', draft), '--extra-per-row', '1600']);
  assert.strictEqual(heavy.status, 0, heavy.stderr);
  const heavyPlan = JSON.parse(heavy.stdout);
  assert.strictEqual(heavyPlan.row_allowance_chars, 1600);
  assert.ok(heavyPlan.parts.length > base.parts.length, `${heavyPlan.parts.length} parts vs ${base.parts.length}`);
  assert.deepStrictEqual(heavyPlan.parts.flatMap(p => p.tc_ids), ids);
  const low = offline('result-parts.js', ['plan', '--ids-file', idsFile, '--merged-from', write(dir, 'low.txt', draft), '--extra-per-row', '100']);
  assert.notStrictEqual(low.status, 0);
  assert.match(low.stderr, /--extra-per-row must be an integer of at least 700/);
}));

test('merged sizing: parts are balanced, never exceed 40 rows, and a draft with a missing row or a combined option is refused', () => inTmp(dir => {
  const total = 60;
  const ids = range(total).map(idOf);
  const sizes = planCli(dir, total, realTcDraftHtml(ids)).parts.map(p => p.tc_ids.length);
  assert.ok(Math.max(...sizes) - Math.min(...sizes) <= 2, `unbalanced: ${sizes}`);
  assert.ok(Math.max(...sizes) <= 40);
  const idsFile = write(dir, 'ids2.txt', ids.join(','));
  const missing = offline('result-parts.js', ['plan', '--ids-file', idsFile, '--merged-from', write(dir, 'd.txt', realTcDraftHtml(ids.slice(0, 50)))]);
  assert.notStrictEqual(missing.status, 0);
  const combined = offline('result-parts.js', ['plan', '--ids-file', idsFile, '--merged-from', write(dir, 'd2.txt', realTcDraftHtml(ids)), '--batch', '20']);
  assert.notStrictEqual(combined.status, 0);
}));
