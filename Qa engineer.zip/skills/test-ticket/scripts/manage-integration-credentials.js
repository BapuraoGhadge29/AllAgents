#!/usr/bin/env node
/**
 * Manages per-integration test-credential placeholder fields in ~/.claude/settings.json,
 * for Supplier/Reseller (Integration Manager) tickets — e.g. MaxxtonLink, Booking.com,
 * Airbnb. Same non-negotiable as manage-credentials.js: Claude calls this script instead
 * of reading or editing settings.json directly — actual credential values are never
 * passed as args or printed to stdout/stderr.
 *
 * Unlike manage-credentials.js (one fixed Jira email/token pair for the whole team),
 * Supplier/Reseller test credentials are per-integration — a different named entry per
 * supplier or reseller, each potentially shaped differently (username+password, API key,
 * client ID+secret). This script is keyed by an integration name and takes an optional
 * field list so each integration's actual credential shape can differ.
 *
 * Usage:
 *   node manage-integration-credentials.js add <key> [--fields=F1,F2,...]
 *     Adds empty placeholder env fields QA_INTEGRATION_<KEY>_<FIELD> (default fields:
 *     USERNAME,PASSWORD). Prints a JSON manifest of which key names were added (no values).
 *   node manage-integration-credentials.js remove <key>
 *     Removes only the empty fields added by the last 'add' call for this <key>.
 *   node manage-integration-credentials.js check <key> [--fields=F1,F2,...]
 *     Idempotent probe: prints "present" (every field non-empty) or "missing" — no prompt,
 *     no write, no secret values. Safe to call any time, e.g. to re-derive setup status
 *     after context compaction without re-prompting.
 *
 * <key> is the integration/supplier/reseller name as named on the ticket (e.g. "MaxxtonLink",
 * "BookingCom") — normalized by uppercasing and stripping every non-alphanumeric character
 * for the env var name and the manifest filename, so two spellings of the same integration
 * ("Booking.com" / "BookingCom") land on the same credentials (both -> "BOOKINGCOM").
 *
 * Exits 0 on success, 1 on failure.
 */

const fs   = require('fs');
const path = require('path');
const os   = require('os');

const SETTINGS_PATH = path.join(os.homedir(), '.claude', 'settings.json');

function normalizeKey(rawKey) {
  // Strip separators entirely (not collapse-to-underscore) so spelling variants of the
  // same integration name alias to one key regardless of punctuation — "Booking.com" and
  // "BookingCom" must both normalize to "BOOKINGCOM", not diverge into two credential sets.
  return rawKey
    .toUpperCase()
    .replace(/[^A-Z0-9]+/g, '');
}

function manifestPath(normKey) {
  return path.join(os.homedir(), '.claude', `integration-evidence-setup-${normKey}.tmp`);
}

function parseFields(argv) {
  const fieldsArg = argv.find(a => a.startsWith('--fields='));
  if (!fieldsArg) return ['USERNAME', 'PASSWORD'];
  return fieldsArg
    .slice('--fields='.length)
    .split(',')
    .map(f => f.trim().toUpperCase())
    .filter(Boolean);
}

const [, , command, rawKey, ...rest] = process.argv;

if (!rawKey && command !== undefined) {
  process.stderr.write('Usage: node manage-integration-credentials.js <add|remove|check> <integration-key> [--fields=F1,F2,...]\n');
  process.exit(1);
}

const normKey = rawKey ? normalizeKey(rawKey) : null;
if (rawKey && normKey === '') {
  // No alphanumerics survive normalization (e.g. "..."): normKey would be "" for every
  // such input, colliding env var keys (QA_INTEGRATION__USERNAME) across unrelated bad
  // inputs, and MANIFEST_PATH below would fall through to null since '' is falsy — which
  // crashes remove's fs.existsSync(MANIFEST_PATH) on a null path. Reject up front instead.
  process.stderr.write(`Integration key "${rawKey}" has no letters or digits after normalization — provide a real integration name.\n`);
  process.exit(1);
}
const MANIFEST_PATH = normKey ? manifestPath(normKey) : null;

if (command === 'add') {
  const fields = parseFields(rest);
  try {
    let settings = {};
    if (fs.existsSync(SETTINGS_PATH)) {
      settings = JSON.parse(fs.readFileSync(SETTINGS_PATH, 'utf8'));
    }

    let addedBlock = false;
    const addedKeys = [];

    if (!settings.env) {
      settings.env = {};
      addedBlock = true;
    }
    for (const field of fields) {
      const envKey = `QA_INTEGRATION_${normKey}_${field}`;
      // Presence check, not truthiness — a placeholder already sitting empty from an
      // earlier 'add' call must NOT be re-claimed as "added by this run", or a later
      // 'remove' in *this* run would delete a placeholder a different run created.
      if (!(envKey in settings.env)) {
        settings.env[envKey] = '';
        addedKeys.push(envKey);
      }
    }

    if (addedKeys.length > 0 || addedBlock) {
      try {
        fs.writeFileSync(SETTINGS_PATH, JSON.stringify(settings, null, 2), 'utf8');
      } catch (writeErr) {
        process.stderr.write(
          `PERMISSION_ERROR: Cannot write to ${SETTINGS_PATH}\n` +
          `Reason: ${writeErr.message}\n\n` +
          `Please add the credentials manually:\n` +
          `  1. Open ${SETTINGS_PATH} in a text editor (run as Administrator if needed)\n` +
          `     If the file does not exist yet, create it.\n` +
          `  2. Add or update the "env" block with:\n` +
          `     ${JSON.stringify(Object.fromEntries(fields.map(f => [`QA_INTEGRATION_${normKey}_${f}`, `your_${rawKey}_test_${f.toLowerCase()}`])), null, 6)}\n` +
          `  3. Save the file and type "updated" to continue.\n`
        );
        process.exit(1);
      }
    }

    const manifest = { key: normKey, fields, addedKeys, addedBlock };
    try {
      fs.writeFileSync(MANIFEST_PATH, JSON.stringify(manifest), 'utf8');
    } catch { /* manifest write failure is non-fatal */ }

    // Print only key names + block flag — no credential values ever reach stdout
    process.stdout.write(JSON.stringify(manifest) + '\n');
  } catch (err) {
    process.stderr.write(`Failed to add placeholders: ${err.message}\n`);
    process.exit(1);
  }

} else if (command === 'remove') {
  try {
    if (!fs.existsSync(MANIFEST_PATH)) {
      process.stdout.write('nothing-to-remove\n');
      process.exit(0);
    }

    const manifest = JSON.parse(fs.readFileSync(MANIFEST_PATH, 'utf8'));
    const { addedKeys, addedBlock } = manifest;

    if (!fs.existsSync(SETTINGS_PATH)) {
      fs.unlinkSync(MANIFEST_PATH);
      process.stdout.write('settings-not-found\n');
      process.exit(0);
    }

    const settings = JSON.parse(fs.readFileSync(SETTINGS_PATH, 'utf8'));

    // Remove only keys that were newly added AND are still empty (user didn't fill them)
    for (const key of addedKeys) {
      if (settings.env && settings.env[key] === '') {
        delete settings.env[key];
      }
    }

    // Remove env block if it was created by add and is now empty
    if (addedBlock && settings.env && Object.keys(settings.env).length === 0) {
      delete settings.env;
    }

    fs.writeFileSync(SETTINGS_PATH, JSON.stringify(settings, null, 2), 'utf8');
    fs.unlinkSync(MANIFEST_PATH);

    process.stdout.write('removed\n');
  } catch (err) {
    process.stderr.write(`Failed to remove placeholders: ${err.message}\n`);
    process.exit(1);
  }

} else if (command === 'check') {
  const fields = parseFields(rest);
  let settingsEnv = {};
  try {
    const s = JSON.parse(fs.readFileSync(SETTINGS_PATH, 'utf8'));
    if (s && s.env) settingsEnv = s.env;
  } catch { /* no/unreadable settings file → treat as missing */ }

  const allPresent = fields.every(field => {
    const envKey = `QA_INTEGRATION_${normKey}_${field}`;
    const value = process.env[envKey] || settingsEnv[envKey] || '';
    return value !== '';
  });
  process.stdout.write((allPresent ? 'present' : 'missing') + '\n');
  process.exit(0);

} else {
  process.stderr.write('Usage: node manage-integration-credentials.js <add|remove|check> <integration-key> [--fields=F1,F2,...]\n');
  process.exit(1);
}
