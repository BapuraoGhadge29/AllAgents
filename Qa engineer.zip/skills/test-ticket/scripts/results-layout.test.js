#!/usr/bin/env node
/**
 * Tests for the merged Test Cases + results layout (results-layout.js and the checks that use it).
 * Self-contained: node:test + node:assert. Jira is never called: post/update run against a stubbed fetch.
 * Run: node plugins/qa-engineer/skills/test-ticket/scripts/results-layout.test.js
 */
'use strict';

const test = require('node:test');
const assert = require('node:assert');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { spawnSync } = require('child_process');
const layout = require('./results-layout');
const rp = require('./result-parts');

const KEY = 'MXTS-1';
const MERGED_HEADER = layout.wikiHeader(layout.MERGED_COLS);
const TC10 = layout.MERGED_COLS.slice(0, 10).map((c, i) => (i === 8 ? 'Automate' : c));

const STATS = [
  ['Concern', 'MQA'], ['Environment', 'Dev'], ['Build / Version', 'V1'], ['Preconditions', 'None detected'], ['Total TCs', '2'],
  ['Passed', '2'], ['Failed', '0'], ['Blocked', '0'], ['Needs Review', '0'], ['Skipped', '0'],
  ['Pass rate', '100% (BLOCKED and Skipped excluded)'], ['QA Pipeline Version', '2.13.0'], ['Test Execution Timing', '11m'],
].map(([k, v]) => `| *${k}* | ${v} |`).join('\n');

const FOOTER = '_AC coverage: 2/2 | Automate: 0 Yes / 2 No_';
const FOOTER_MERGED = '_AC coverage: 2/2 | Automated: 0 Yes / 2 No_';
// Test Cases comment (before execution), wiki markup
const tcRow = (n, steps = '1. Open the page. 2. Click Save.') =>
  `| TC_0${n} | Scenario ${n} | Logged in | ${steps} | Expected ${n} | To be Tested | ${KEY} | MXTS-9 | No | High |`;
const tcComment = (rows = [tcRow(1), tcRow(2)]) => ['h2. Test Cases — ' + KEY, '', `|| ${TC10.join(' || ')} ||`, ...rows, '', FOOTER].join('\n');
// Merged comment (after execution), wiki markup
const mergedRow = (n, o = {}) =>
  `| TC_0${n} | Scenario ${n} | Logged in | ${o.steps || '1. Open the page. 2. Click Save.'} | Expected ${n} | ${o.actual || 'Saved without error'} | ${KEY} | MXTS-9 | ${o.automated || 'No'} | High | ${o.status || 'PASS ✅'} | !TC_0${n}-a.png! |`;
const merged = (rows = [mergedRow(1), mergedRow(2)], footer = FOOTER_MERGED) => ['h2. QA Test Results', '', STATS, '', MERGED_HEADER, ...rows, '', footer].join('\n');

const inTmp = (fn) => { const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'merged-')); try { return fn(dir); } finally { fs.rmSync(dir, { recursive: true, force: true }); } };
const write = (dir, name, text) => { const f = path.join(dir, name); fs.writeFileSync(f, text); return f; };
const run = (script, args, env = {}) => spawnSync(process.execPath, [path.join(__dirname, script), ...args], { encoding: 'utf8', env: { ...process.env, ...env } });

// ─── layouts ────────────────────────────────────────────────────────────────

test('layouts: the merged columns are the 10 Test Cases columns plus Status and Test Proof', () => {
  assert.deepStrictEqual(layout.MERGED_COLS.slice(0, 8), TC10.slice(0, 8));
  assert.strictEqual(layout.MERGED_COLS[8], 'Automated');
  assert.deepStrictEqual(layout.MERGED_COLS.slice(9), ['Risk', 'Status', 'Test Proof']);
  const m = layout.LAYOUTS.find(l => l.name === 'merged');
  assert.deepStrictEqual([m.actual, m.status, m.proof], [5, 10, 11]);
  assert.strictEqual(layout.wikiLayout(['x', MERGED_HEADER]).name, 'merged');
  assert.strictEqual(layout.wikiLayout(['x', layout.wikiHeader(layout.RESULTS_COLS)]).name, 'results');
  assert.strictEqual(layout.wikiLayout(['x', '|| TC_ID || Nope ||']), null);
});

// ─── nothing lost (CHECK 18) ────────────────────────────────────────────────

test('lostFromTestCases: filling Actual result, Automated, Status and Proof loses nothing (wiki)', () => {
  assert.deepStrictEqual(layout.lostFromTestCases(tcComment(), merged()), []);
  assert.deepStrictEqual(layout.lostFromTestCases(tcComment(), merged([mergedRow(1, { automated: 'Yes' }), mergedRow(2, { actual: 'Other text' })])), []);
});

test('lostFromTestCases: a changed kept column, a dropped TC and a dropped footer are each reported', () => {
  const changed = layout.lostFromTestCases(tcComment(), merged([mergedRow(1, { steps: 'rewritten' }), mergedRow(2)]));
  assert.match(changed.join('\n'), /TC_01: column "Test steps" changed/);
  const dropped = layout.lostFromTestCases(tcComment(), merged([mergedRow(1)]));
  assert.match(dropped.join('\n'), /TC_02 is in the existing comment but not in the merged body/);
  const footer = layout.lostFromTestCases(tcComment(), merged(undefined, '_nothing_'));
  assert.match(footer.join('\n'), /AC-coverage footer/);
});

test('lostFromTestCases: a comment that is not a 10-column Test Cases table is refused', () => {
  const six = ['h2. QA Test Results', '', layout.wikiHeader(layout.RESULTS_COLS), '| TC_01 | s | e | a | PASS ✅ | !TC_01-a.png! |'].join('\n');
  assert.match(layout.lostFromTestCases(six, merged()).join('\n'), /not a 10-column Test Cases table/);
  assert.match(layout.lostFromTestCases('just text', merged()).join('\n'), /holds no TC rows/);
});

test('lostFromTestCases: an already merged comment can be corrected again (same kept columns)', () => {
  assert.deepStrictEqual(layout.lostFromTestCases(merged(), merged([mergedRow(1, { actual: 'fixed text' }), mergedRow(2)])), []);
});

test('lostFromTestCases: a duplicated TC row and a TC the existing comment does not have are reported (wiki)', () => {
  const dup = layout.lostFromTestCases(tcComment(), merged([mergedRow(1), mergedRow(1), mergedRow(2)]));
  assert.match(dup.join('\n'), /\[CHECK 18\] TC_01 has 1 row\(s\) in the existing comment but 2 in the merged body/);
  const extra = layout.lostFromTestCases(tcComment(), merged([mergedRow(1), mergedRow(2), mergedRow(3)]));
  assert.match(extra.join('\n'), /\[CHECK 18\] TC_03 is in the merged body but not in the existing comment/);
  assert.deepStrictEqual(layout.lostFromTestCases(tcComment([tcRow(1), tcRow(1), tcRow(2)]), merged([mergedRow(1), mergedRow(1), mergedRow(2)])), []);
});

const html = (cells, header = layout.MERGED_COLS) =>
  `<table><thead><tr>${header.map(h => `<th><p><strong>${h} </strong></p></th>`).join('')}</tr></thead><tbody>${cells.map(r => `<tr>${r.map(c => `<td><p>${c} </p></td>`).join('')}</tr>`).join('')}</tbody></table>`;
const htmlTc = (steps = '1. Open &quot;x&quot;. 2. Save.') => (n) => [`TC_0${n}`, `Scenario ${n}`, 'Logged in', steps, `Expected ${n}`, 'To be Tested', KEY, 'MXTS-9', 'No', 'High'];
const htmlOld = (steps) => `<h2>Test Cases — ${KEY}</h2>` + html([htmlTc(steps)(1), htmlTc(steps)(2)], TC10) + '<p><em>AC coverage: 2/2 | Automate: 0 Yes / 2 No</em></p>';
const htmlStats = '<table><tbody>' + STATS.split('\n').map(l => { const [, k, v] = /^\| \*(.+?)\* \| (.+) \|$/.exec(l); return `<tr><td><p><strong>${k}</strong> </p></td><td><p>${v} </p></td></tr>`; }).join('') + '</tbody></table>';
const htmlMerged = (steps) => '<h2>QA Test Results</h2>' + htmlStats +
  html([1, 2].map(n => [...htmlTc(steps)(n).slice(0, 5), 'Saved without error', KEY, 'MXTS-9', 'No', 'High', 'PASS ✅', `TC_0${n}-a.png`]))
  + '<p><em>AC coverage: 2/2 | Automated: 0 Yes / 2 No</em></p>';

test('lostFromTestCases: HTML bodies are compared on their text, entities included', () => {
  assert.deepStrictEqual(layout.lostFromTestCases(htmlOld(), htmlMerged()), []);
  assert.match(layout.lostFromTestCases(htmlOld(), htmlMerged('1. Open "y". 2. Save.')).join('\n'), /column "Test steps" changed/);
});

// ─── status counting in the merged table ────────────────────────────────────

test('statusCounts reads the Status column of the merged table (wiki and HTML)', () => {
  const body = merged([mergedRow(1), mergedRow(2, { status: 'FAIL ❌' })]);
  assert.deepStrictEqual([rp.statusCounts(body)[0].PASS, rp.statusCounts(body)[0].FAIL], [1, 1]);
  const h = htmlMerged().replace('PASS ✅ </p></td><td><p>TC_02', 'FAIL ❌ </p></td><td><p>TC_02');
  assert.deepStrictEqual([rp.statusCounts(h)[0].PASS, rp.statusCounts(h)[0].FAIL], [1, 1]);
  const six = ['h2. QA Test Results', layout.wikiHeader(layout.RESULTS_COLS), '| TC_01 | s | e | a | PASS ✅ | !TC_01-a.png! |'].join('\n');
  assert.strictEqual(rp.statusCounts(six)[0].PASS, 1);
});

// ─── post-comment.js / update-comment.js format checks ─────────────────────

test('post-comment.js --validate-only accepts the merged wiki body, and ticket text may say "Phase 1" or "part 2"', () => inTmp(dir => {
  const ok = run('post-comment.js', [KEY, write(dir, 'ok.txt', merged()), '--validate-only']);
  assert.strictEqual(ok.status, 0, ok.stderr);
  const ticketText = merged([mergedRow(1, { steps: 'Check the Execution results screen of Phase 1, part 2' }), mergedRow(2)]);
  const ok2 = run('post-comment.js', [KEY, write(dir, 'ok2.txt', ticketText), '--validate-only']);
  assert.strictEqual(ok2.status, 0, ok2.stderr);
}));

test('post-comment.js: the pipeline-written cells of a merged row are still checked', () => inTmp(dir => {
  const bad = run('post-comment.js', [KEY, write(dir, 'bad.txt', merged([mergedRow(1, { actual: 'Phase 3a execution done' }), mergedRow(2)])), '--validate-only']);
  assert.strictEqual(bad.status, 1);
  assert.match(bad.stderr, /CHECK 6/);
}));

test('post-comment.js and update-comment.js: a merged row with the wrong cell count or an unknown header is blocked', () => inTmp(dir => {
  const eleven = merged([mergedRow(1).replace(' | High | PASS', ' | PASS'), mergedRow(2)]);
  const r = run('post-comment.js', [KEY, write(dir, 'eleven.txt', eleven), '--validate-only']);
  assert.strictEqual(r.status, 1);
  assert.match(r.stderr, /CHECK 10[\s\S]*expected 12/);
  const unknown = merged().replace(MERGED_HEADER, MERGED_HEADER.replace('Risk', 'Priority'));
  const u = run('update-comment.js', [KEY, '1', write(dir, 'unknown.txt', unknown)], { JIRA_EMAIL: 'a@b.c', JIRA_API_TOKEN: 'x' });
  assert.strictEqual(u.status, 1);
  assert.match(u.stderr, /CHECK 3/);
}));

test('post-comment.js: the 6-column results table is still valid', () => inTmp(dir => {
  const six = ['h2. QA Test Results', '', STATS, '', layout.wikiHeader(layout.RESULTS_COLS), '| TC_01 | s | e | a | PASS ✅ | !TC_01-a.png! |'].join('\n');
  const r = run('post-comment.js', [KEY, write(dir, 'six.txt', six), '--validate-only']);
  assert.strictEqual(r.status, 0, r.stderr);
}));

// ─── validate-results-comment.js (MCP path) ────────────────────────────────

test('validate-results-comment.js: merged HTML passes, and --previous proves nothing was lost', () => inTmp(dir => {
  const body = write(dir, 'm.html', htmlMerged());
  assert.strictEqual(run('validate-results-comment.js', [body, '--format', 'html']).status, 0);
  const prev = write(dir, 'prev.html', htmlOld());
  const ok = run('validate-results-comment.js', [body, '--format', 'html', '--previous', prev]);
  assert.strictEqual(ok.status, 0, ok.stderr);
  const lost = run('validate-results-comment.js', [write(dir, 'm2.html', htmlMerged('1. Open "y". 2. Save.')), '--format', 'html', '--previous', prev]);
  assert.strictEqual(lost.status, 1);
  assert.match(lost.stderr, /CHECK 18/);
}));

test('validate-results-comment.js --previous: a merged body that repeats a TC row is refused (CHECK 18)', () => inTmp(dir => {
  const rows = [1, 1, 2].map(n => [...htmlTc()(n).slice(0, 5), 'Saved without error', KEY, 'MXTS-9', 'No', 'High', 'PASS ✅', `TC_0${n}-a.png`]);
  const dup = write(dir, 'dup.html', '<h2>QA Test Results</h2>' + htmlStats + html(rows) + '<p><em>AC coverage: 2/2 | Automated: 0 Yes / 2 No</em></p>');
  const r = run('validate-results-comment.js', [dup, '--format', 'html', '--previous', write(dir, 'prev.html', htmlOld())]);
  assert.strictEqual(r.status, 1);
  assert.match(r.stderr, /\[CHECK 18\] TC_01 has 1 row\(s\) in the existing comment but 2 in the merged body/);
}));

test('validate-results-comment.js: merged markdown passes', () => inTmp(dir => {
  const row = (n) => `| TC_0${n} | s | p | st | e | a | ${KEY} | MXTS-9 | No | High | PASS ✅ | TC_0${n}-a.png |`;
  const md = ['## QA Test Results', '', '| **Concern** | MQA |', '|---|---|',
    ...STATS.split('\n').slice(1).map(l => l.replace(/\*(.+?)\*/, '**$1**')), '',
    `| ${layout.MERGED_COLS.join(' | ')} |`, '|---|---|---|---|---|---|---|---|---|---|---|---|', row(1), row(2)].join('\n');
  const r = run('validate-results-comment.js', [write(dir, 'm.md', md), '--format', 'markdown']);
  assert.strictEqual(r.status, 0, r.stderr);
}));

test('validate-results-comment.js --kind tc: new Test Cases comments say Automate; --existing also accepts Automated', () => inTmp(dir => {
  const md = (col) => ['## Test Cases — ' + KEY, '', `| ${TC10.map((c, i) => (i === 8 ? col : c)).join(' | ')} |`, '|---|---|---|---|---|---|---|---|---|---|',
    `| TC_01 | s | p | st | e | To be Tested | ${KEY} | N/A | No | High |`, '', `_AC coverage: 1/1 | ${col}: 0 Yes / 1 No_`].join('\n');
  const args = (f, extra = []) => [f, '--kind', 'tc', '--story', KEY, ...extra];
  assert.strictEqual(run('validate-results-comment.js', args(write(dir, 'new.md', md('Automate')))).status, 0);
  const old = write(dir, 'old.md', md('Automated'));
  assert.strictEqual(run('validate-results-comment.js', args(old)).status, 1);
  assert.strictEqual(run('validate-results-comment.js', args(old, ['--existing'])).status, 0);
}));

// ─── Jira-side guards of post-comment.js (fetch is stubbed) ─────────────────
// These hold with no run-state.json at all, which is what a context compaction can leave behind.

const stubFetch = (dir, comments) => {
  const f = write(dir, 'stub-fetch.js', `
    const comments = ${JSON.stringify(comments)};
    globalThis.fetch = async (url, opts = {}) => {
      const json = (data, status = 200) => ({ ok: status < 400, status, json: async () => data, text: async () => JSON.stringify(data) });
      if ((opts.method || 'GET') === 'POST') return json({ id: '999' });
      if (opts.method === 'PUT') return json({ id: /(\\d+)$/.exec(url)[1] });
      if (/\\/comment\\?/.test(url)) return json({ total: comments.length, comments });
      const m = /\\/comment\\/(\\d+)$/.exec(url);
      if (m) { const c = comments.find(x => x.id === m[1]); return c ? json(c) : json({}, 404); }
      return json({ fields: { attachment: [{ filename: 'TC_01-a.png' }, { filename: 'TC_02-a.png' }] } });
    };`);
  return f;
};
const post = (dir, comments, body, extra = []) => spawnSync(process.execPath, ['--require', stubFetch(dir, comments), path.join(__dirname, 'post-comment.js'), KEY, write(dir, 'body.txt', body), ...extra],
  { encoding: 'utf8', env: { ...process.env, JIRA_EMAIL: 'a@b.c', JIRA_API_TOKEN: 'x' } });
const c = (id, body, created = '2026-10-26T10:00:00.000+0100', updated = created) => ({ id, body, created, updated });

test('merge guard: the first results of a story are refused as a new comment while its Test Cases comment is unmerged', () => inTmp(dir => {
  const r = post(dir, [c('100', tcComment())], merged(), ['', '2026-10-26T10:30:00.000+0100']);
  assert.strictEqual(r.status, 1, r.stdout + r.stderr);
  assert.match(r.stderr, /still has its Test Cases comment \(id=100\)/);
  assert.match(r.stderr, /update-comment\.js MXTS-1 100/);
}));

test('merge guard: no cycle info at all (nothing in run-state) is refused the same way', () => inTmp(dir => {
  const r = post(dir, [c('100', tcComment())], merged());
  assert.strictEqual(r.status, 1, r.stdout + r.stderr);
  assert.match(r.stderr, /update-comment\.js MXTS-1 100/);
}));

test('merge guard: a retest of an already merged ticket posts its own new comment', () => inTmp(dir => {
  const r = post(dir, [c('100', merged(), '2026-10-26T10:00:00.000+0100', '2026-10-26T11:00:00.000+0100')], merged(), ['', '2026-10-27T09:00:00.000+0100']);
  assert.strictEqual(r.status, 0, r.stdout + r.stderr);
  assert.match(r.stdout, /^999$/m);
}));

test('merge guard: an older ticket that already has its separate results comment is not affected', () => inTmp(dir => {
  const sixBody = ['h2. QA Test Results', '', STATS, '', layout.wikiHeader(layout.RESULTS_COLS), '| TC_01 | s | e | a | PASS ✅ | !TC_01-a.png! |'].join('\n');
  const r = post(dir, [c('100', tcComment()), c('101', sixBody, '2026-10-26T10:10:00.000+0100')], sixBody, ['', '2026-10-27T09:00:00.000+0100']);
  assert.strictEqual(r.status, 0, r.stdout + r.stderr);
  assert.match(r.stdout, /^999$/m);
}));

test('same-cycle guard: after a lost run-state, a merged comment UPDATED this cycle is found and nothing is posted again', () => inTmp(dir => {
  const r = post(dir, [c('100', merged(), '2026-10-26T10:00:00.000+0100', '2026-10-26T10:45:00.000+0100')], merged(), ['', '2026-10-26T10:30:00.000+0100']);
  assert.strictEqual(r.status === 0 || r.status === 3, true, r.stdout + r.stderr);
  assert.match(r.stdout, /Already posted this cycle: found results comment \(id=100/);
  assert.doesNotMatch(r.stdout, /^999$/m);
}));

test('same-cycle guard: the known id of a merged comment (run-state kept) is recognised too', () => inTmp(dir => {
  const r = post(dir, [c('100', merged())], merged(), ['100']);
  assert.strictEqual(r.status === 0 || r.status === 3, true, r.stdout + r.stderr);
  assert.match(r.stdout, /Already posted this cycle: results comment \(id=100\)/);
}));

// ─── update-comment.js: the original comment is edited in place (fetch is stubbed) ─────────

const update = (dir, comments, body, id = '100') => spawnSync(process.execPath, ['--require', stubFetch(dir, comments), path.join(__dirname, 'update-comment.js'), KEY, id, write(dir, 'body.txt', body)],
  { encoding: 'utf8', env: { ...process.env, JIRA_EMAIL: 'a@b.c', JIRA_API_TOKEN: 'x' } });

test('update-comment.js: the Test Cases comment is replaced by the merged body (same comment id, no second comment)', () => inTmp(dir => {
  const r = update(dir, [c('100', tcComment())], merged());
  assert.strictEqual(r.status === 0 || r.status === 3, true, r.stdout + r.stderr);
  assert.match(r.stdout, /Updated comment 100/);
  assert.doesNotMatch(r.stdout, /999/);
}));

test('update-comment.js: refuses, without sending anything, when the merged body would lose data from the live comment', () => inTmp(dir => {
  const r = update(dir, [c('100', tcComment())], merged([mergedRow(1, { steps: 'rewritten' }), mergedRow(2)]));
  assert.strictEqual(r.status, 1, r.stdout + r.stderr);
  assert.match(r.stderr, /would lose data from the existing comment 100/);
  assert.match(r.stderr, /TC_01: column "Test steps" changed/);
  assert.doesNotMatch(r.stdout, /Updated comment/);
}));

test('update-comment.js: refuses when the comment it is told to replace is not a Test Cases table', () => inTmp(dir => {
  const r = update(dir, [c('100', 'Verified, all fine.')], merged());
  assert.strictEqual(r.status, 1, r.stdout + r.stderr);
  assert.match(r.stderr, /holds no TC rows/);
}));

test('update-comment.js: a comment that cannot be read fails closed', () => inTmp(dir => {
  const r = update(dir, [c('100', tcComment())], merged(), '555');
  assert.strictEqual(r.status, 1, r.stdout + r.stderr);
  assert.doesNotMatch(r.stdout, /Updated comment/);
}));

// ─── post-tc-comment.js: a merged comment still counts as the story's Test Cases comment ─────

const postTc = (dir, comments) => spawnSync(process.execPath, ['--require', stubFetch(dir, comments), path.join(__dirname, 'post-tc-comment.js'), KEY, write(dir, 'tc.txt', tcComment())],
  { encoding: 'utf8', env: { ...process.env, JIRA_EMAIL: 'a@b.c', JIRA_API_TOKEN: 'x' } });

test('post-tc-comment.js: with the Test Cases comment already merged into the results, a second Test Cases comment is blocked', () => inTmp(dir => {
  const r = postTc(dir, [c('100', merged())]);
  assert.strictEqual(r.status, 0, r.stdout + r.stderr);
  assert.match(r.stdout, /Duplicate blocked: a Test Cases comment \(id=100\) already exists/);
  assert.doesNotMatch(r.stdout, /^999$/m);
}));

test('post-tc-comment.js: a story with no Test Cases comment at all gets one', () => inTmp(dir => {
  const r = postTc(dir, [c('100', 'Some other comment')]);
  assert.strictEqual(r.status, 0, r.stdout + r.stderr);
  assert.match(r.stdout, /^999$/m);
}));

// ─── read-comment.js ────────────────────────────────────────────────────────

const readComment = (dir, comments, args) => spawnSync(process.execPath, ['--require', stubFetch(dir, comments), path.join(__dirname, 'read-comment.js'), ...args],
  { encoding: 'utf8', env: { ...process.env, JIRA_EMAIL: 'a@b.c', JIRA_API_TOKEN: 'x' } });

test('read-comment.js: prints the live body, writes it with --out, and fails on a missing comment', () => inTmp(dir => {
  const printed = readComment(dir, [c('100', tcComment())], [KEY, '100']);
  assert.strictEqual(printed.status, 0, printed.stderr);
  assert.strictEqual(printed.stdout.trim(), tcComment().trim());
  const out = path.join(dir, 'live.txt');
  const wrote = readComment(dir, [c('100', tcComment())], [KEY, '100', '--out', out]);
  assert.strictEqual(wrote.status, 0, wrote.stderr);
  assert.strictEqual(fs.readFileSync(out, 'utf8'), tcComment());
  assert.strictEqual(readComment(dir, [c('100', tcComment())], [KEY, '555']).status, 1);
  assert.strictEqual(readComment(dir, [], [KEY]).status, 1);
}));

// ─── collapsible TC tables (HTML): more than 5 TCs → inside <details> ───────────────────────

const mergedHtmlN = (n, { wrap = true, summary = `Results: ${n} TCs — ${n} passed` } = {}) => {
  const rows = Array.from({ length: n }, (_, i) => [`TC_${String(i + 1).padStart(2, '0')}`, `Scenario ${i + 1}`, 'Logged in', '1. Open. 2. Save.', 'Expected', 'Saved without error', KEY, 'MXTS-9', 'No', 'High', 'PASS ✅', `TC_${String(i + 1).padStart(2, '0')}-a.png`]);
  const table = html(rows);
  return '<h2>QA Test Results</h2>' + htmlStats + (wrap ? `<details><summary>${summary}</summary>${table}</details>` : table) + `<p><em>AC coverage: ${n}/${n} | Automated: 0 Yes / ${n} No</em></p>`;
};
const tcHtmlN = (n, { wrap = true, extra = '' } = {}) => {
  const rows = Array.from({ length: n }, (_, i) => [`TC_${String(i + 1).padStart(2, '0')}`, `Scenario ${i + 1}`, 'Logged in', '1. Open. 2. Save.', 'Expected', 'To be Tested', KEY, 'N/A', 'No', 'High']);
  const table = html(rows, TC10);
  return `<h2>Test Cases — ${KEY}</h2>` + (wrap ? `<details><summary>Test cases (${n})</summary>${table}</details>` : table) + `<p><em>AC coverage: ${n}/${n} | Automate: 0 Yes / ${n} No</em></p>` + extra;
};
const validate = (dir, name, text, args) => run('validate-results-comment.js', [write(dir, name, text), ...args]);

test('collapsible results: 6 rows must be in <details>, 5 rows must not, and the summary needs text', () => inTmp(dir => {
  const fmt = ['--format', 'html'];
  assert.strictEqual(validate(dir, 'six.html', mergedHtmlN(6), fmt).status, 0, validate(dir, 'six.html', mergedHtmlN(6), fmt).stderr);
  const bare6 = validate(dir, 'bare6.html', mergedHtmlN(6, { wrap: false }), fmt);
  assert.strictEqual(bare6.status, 1);
  assert.match(bare6.stderr, /CHECK 19[\s\S]*6 rows/);
  assert.strictEqual(validate(dir, 'five.html', mergedHtmlN(5, { wrap: false }), fmt).status, 0);
  const wrapped5 = validate(dir, 'wrapped5.html', mergedHtmlN(5), fmt);
  assert.strictEqual(wrapped5.status, 1);
  assert.match(wrapped5.stderr, /CHECK 19[\s\S]*stays a plain table/);
  const noTitle = validate(dir, 'notitle.html', mergedHtmlN(6, { summary: ' ' }), fmt);
  assert.strictEqual(noTitle.status, 1);
  assert.match(noTitle.stderr, /non-empty <summary>/);
}));

test('collapsible results: the nothing-lost check still reads rows inside <details>', () => inTmp(dir => {
  const prev = write(dir, 'prev.html', `<h2>Test Cases — ${KEY}</h2>` + html(Array.from({ length: 6 }, (_, i) => [`TC_0${i + 1}`, `Scenario ${i + 1}`, 'Logged in', '1. Open. 2. Save.', 'Expected', 'To be Tested', KEY, 'MXTS-9', 'No', 'High']), TC10) + '<p><em>AC coverage: 6/6 | Automate: 0 Yes / 6 No</em></p>');
  const r = validate(dir, 'm6.html', mergedHtmlN(6), ['--format', 'html', '--previous', prev]);
  assert.strictEqual(r.status, 0, r.stderr);
}));

test('collapsible Test Cases (HTML, --kind tc --format html): same rule, Automate header, no verdicts, no extended section', () => inTmp(dir => {
  const args = ['--kind', 'tc', '--story', KEY, '--format', 'html'];
  assert.strictEqual(validate(dir, 'tc6.html', tcHtmlN(6), args).status, 0, validate(dir, 'tc6.html', tcHtmlN(6), args).stderr);
  assert.match(validate(dir, 'tc6bare.html', tcHtmlN(6, { wrap: false }), args).stderr, /CHECK 19/);
  assert.strictEqual(validate(dir, 'tc3.html', tcHtmlN(3, { wrap: false }), args).status, 0);
  assert.match(validate(dir, 'tc3w.html', tcHtmlN(3), args).stderr, /CHECK 19/);
  assert.match(validate(dir, 'tcold.html', tcHtmlN(6).replace('<strong>Automate </strong>', '<strong>Automated </strong>'), args).stderr, /CHECK 2/);
  const oldSpelling = (b) => b.replace('<strong>Automate </strong>', '<strong>Automated </strong>').replace('Automate: 0 Yes', 'Automated: 0 Yes');
  assert.strictEqual(validate(dir, 'tcold2.html', oldSpelling(tcHtmlN(6)), [...args, '--existing']).status, 0);
  // the footer must carry the column's own name: an old-spelling column with the new-spelling footer is refused
  const mixed = validate(dir, 'tcmixed.html', tcHtmlN(6).replace('<strong>Automate </strong>', '<strong>Automated </strong>'), [...args, '--existing']);
  assert.strictEqual(mixed.status, 1);
  assert.match(mixed.stderr, /footer label "Automate:" must be the column's name "Automated:"/);
  assert.match(validate(dir, 'tcwrong.html', tcHtmlN(6).replace(`<td><p>${KEY} </p></td>`, '<td><p>QA-2 </p></td>'), args).stderr, /Story number|CHECK 0/);
  assert.match(validate(dir, 'tcverdict.html', tcHtmlN(6).replace('To be Tested', 'PASS ✅'), args).stderr, /CHECK 6/);
  assert.match(validate(dir, 'tcext.html', tcHtmlN(6, { extra: '<h3>Extended cases added after Human review</h3>' }), args).stderr, /CHECK 20/);
}));

// ─── footer counts (CHECK 21): "Automated: n Yes / m No" must match the Automate/Automated column ──────────

test('footerCountErrors: a matching footer passes in wiki, markdown and HTML, a wrong one is reported with the real counts', () => {
  const rows = [mergedRow(1, { automated: 'Yes' }), mergedRow(2), mergedRow(3, { automated: 'Yes' })];
  assert.deepStrictEqual(layout.footerCountErrors(merged(rows, '_AC coverage: 3/3 | Automated: 2 Yes / 1 No_')), []);
  const wrong = layout.footerCountErrors(merged(rows, '_AC coverage: 3/3 | Automated: 0 Yes / 3 No_'));
  assert.match(wrong.join('\n'), /CHECK 21[\s\S]*"Automated: 0 Yes \/ 3 No"[\s\S]*2 Yes \/ 1 No/);
  assert.deepStrictEqual(layout.footerCountErrors(tcComment()), []);
  assert.match(layout.footerCountErrors(tcComment().replace('0 Yes / 2 No', '1 Yes / 1 No')).join(''), /CHECK 21/);
  const md = (foot) => ['## Test Cases — ' + KEY, '', `| ${TC10.join(' | ')} |`, '|---|---|---|---|---|---|---|---|---|---|', `| TC_01 | s | p | st | e | To be Tested | ${KEY} | N/A | Yes | High |`, '', foot].join('\n');
  assert.deepStrictEqual(layout.footerCountErrors(md('_AC coverage: 1/1 | Automate: 1 Yes / 0 No_')), []);
  assert.match(layout.footerCountErrors(md('_AC coverage: 1/1 | Automate: 0 Yes / 1 No_')).join(''), /CHECK 21/);
  assert.deepStrictEqual(layout.footerCountErrors(tcHtmlN(6)), []);
  assert.match(layout.footerCountErrors(tcHtmlN(6).replace('0 Yes / 6 No', '6 Yes / 0 No')).join(''), /CHECK 21/);
});

test('footerCountErrors: the Extended section after the footer is not counted, repeated URL blocks count each TC once, other values are refused', () => {
  const ext = ['', 'h3. Extended cases added after Human review', '_Human review: Claude generated 2 · Human requested 1 (accepted 1, already covered 0, declined 0, added on request 0) · Miss rate 33% (1/3) · Last extended 2026-10-29_', `|| ${TC10.join(' || ')} ||`, tcRow(3).replace('| No | High |', '| Yes | High |')].join('\n');
  assert.deepStrictEqual(layout.footerCountErrors(tcComment() + ext), []);
  const twoBlocks = merged([mergedRow(1, { automated: 'Yes' })], '_AC coverage: 1/1 | Automated: 1 Yes / 0 No_') + '\n----\n' + [MERGED_HEADER, mergedRow(1, { automated: 'Yes' })].join('\n');
  assert.deepStrictEqual(layout.footerCountErrors(twoBlocks), []);
  assert.match(layout.footerCountErrors(merged([mergedRow(1, { automated: 'Maybe' })], '_AC coverage: 1/1 | Automated: 0 Yes / 0 No_')).join(''), /must be Yes or No/);
  const six = ['h2. QA Test Results', layout.wikiHeader(layout.RESULTS_COLS), '| TC_01 | s | e | a | PASS ✅ | !TC_01-a.png! |'].join('\n');
  assert.deepStrictEqual(layout.footerCountErrors(six), []);
});

test('the scripts reject a footer that does not match the table (post-comment, validate-results-comment, post-tc-comment)', () => inTmp(dir => {
  const wrongMerged = merged([mergedRow(1, { automated: 'Yes' }), mergedRow(2)], '_AC coverage: 2/2 | Automated: 0 Yes / 2 No_');
  const a = run('post-comment.js', [KEY, write(dir, 'w.txt', wrongMerged), '--validate-only']);
  assert.strictEqual(a.status, 1);
  assert.match(a.stderr, /CHECK 21/);
  assert.strictEqual(run('post-comment.js', [KEY, write(dir, 'r.txt', merged([mergedRow(1, { automated: 'Yes' }), mergedRow(2)], '_AC coverage: 2/2 | Automated: 1 Yes / 1 No_')), '--validate-only']).status, 0);
  const h = run('validate-results-comment.js', [write(dir, 'h.html', tcHtmlN(6).replace('0 Yes / 6 No', '1 Yes / 5 No')), '--kind', 'tc', '--story', KEY, '--format', 'html']);
  assert.strictEqual(h.status, 1);
  assert.match(h.stderr, /CHECK 21/);
  const t = run('post-tc-comment.js', [KEY, write(dir, 't.txt', tcComment().replace('0 Yes / 2 No', '2 Yes / 0 No')), '--validate-only']);
  assert.strictEqual(t.status, 1);
  assert.match(t.stderr, /CHECK 21/);
}));

// ─── footer label follows the phase: "Automate:" before execution, "Automated:" after ──────────

test('footer label: before execution it is "Automate:", after execution "Automated:", and the other one is refused (wiki, markdown, HTML)', () => inTmp(dir => {
  // before execution (Test Cases comment)
  assert.deepStrictEqual(layout.footerCountErrors(tcComment()), []);
  const tcWrong = tcComment().replace('| Automate: 0 Yes', '| Automated: 0 Yes');
  assert.match(layout.footerCountErrors(tcWrong).join(''), /footer label "Automated:" must be the column's name "Automate:"/);
  const t = run('post-tc-comment.js', [KEY, write(dir, 'tc-wrong.txt', tcWrong), '--validate-only']);
  assert.strictEqual(t.status, 1);
  assert.match(t.stderr, /CHECK 21/);
  assert.strictEqual(run('post-tc-comment.js', [KEY, write(dir, 'tc-ok.txt', tcComment()), '--validate-only']).status, 0);
  assert.match(layout.footerCountErrors(tcHtmlN(6).replace('Automate: 0 Yes', 'Automated: 0 Yes')).join(''), /must be the column's name "Automate:"/);
  // after execution (merged comment)
  assert.deepStrictEqual(layout.footerCountErrors(merged()), []);
  const mergedWrong = merged(undefined, '_AC coverage: 2/2 | Automate: 0 Yes / 2 No_');
  assert.match(layout.footerCountErrors(mergedWrong).join(''), /footer label "Automate:" must be the column's name "Automated:"/);
  const m = run('post-comment.js', [KEY, write(dir, 'm-wrong.txt', mergedWrong), '--validate-only']);
  assert.strictEqual(m.status, 1);
  assert.match(m.stderr, /CHECK 21/);
  const mh = run('validate-results-comment.js', [write(dir, 'm-wrong.html', mergedHtmlN(6).replace('Automated: 0 Yes', 'Automate: 0 Yes')), '--format', 'html']);
  assert.strictEqual(mh.status, 1);
  assert.match(mh.stderr, /CHECK 21/);
}));

test('footer label: the merge turns "Automate:" into "Automated:" together with the column, counts unchanged by the rename', () => {
  const before = tcComment([tcRow(1).replace('| No | High |', '| Yes | High |'), tcRow(2)]).replace('Automate: 0 Yes / 2 No', 'Automate: 1 Yes / 1 No');
  assert.deepStrictEqual(layout.footerCountErrors(before), []);
  const after = merged([mergedRow(1, { automated: 'Yes' }), mergedRow(2)], '_AC coverage: 2/2 | Automated: 1 Yes / 1 No_');
  assert.deepStrictEqual(layout.footerCountErrors(after), []);
  assert.deepStrictEqual(layout.lostFromTestCases(before, after), []);
});
