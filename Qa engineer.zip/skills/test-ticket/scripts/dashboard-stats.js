/**
 * The stats rows of a results comment that the adoption dashboard reads by label, and what each may hold.
 * A value the dashboard cannot read as a number (an improvised "Not tracked", "13 (retest of the non-pass TCs)")
 * is rejected here, in every body format (wiki markup, markdown, HTML).
 *
 *   Test Execution Timing   a number, see timing-value.js                          -> CHECK 16
 *   Total TCs, Passed, Failed, Blocked, Needs Review, Skipped    a whole number    -> CHECK 17
 *       (Total TCs of a part of a split results comment: "<story total> (<first>-<last>)", e.g. "55 (31-55)")
 *   QA Pipeline Version     major.minor.patch                                      -> CHECK 17
 *   Concern, Build / Version   not empty                                           -> CHECK 17
 *
 * Shared by post-comment.js, update-comment.js, validate-results-comment.js and hooks/guard-results-comment.js.
 */
'use strict';

const { timingError } = require('./timing-value');
const { statValues, markersIn, isResultsBody } = require('./result-parts');

const INTEGER_ROWS = ['Total TCs', 'Passed', 'Failed', 'Blocked', 'Needs Review', 'Skipped'];

/**
 * All violations in `body`'s stats tables, as `[CHECK n]` messages. By default a row that is absent is left to the
 * callers' own CHECK 2; with `{ requireRows: true }` (the hook, which has no CHECK 2) an absent row is a violation too.
 */
function statsErrors(body, { requireRows = false } = {}) {
  const errors = [];

  if (requireRows) {
    const missing = [...INTEGER_ROWS, 'QA Pipeline Version', 'Concern', 'Build / Version', 'Test Execution Timing']
      .filter((label) => !statValues(body, label).length);
    if (missing.length) {
      errors.push(`[CHECK 16] The stats table must carry these rows (the dashboard reads them by name): ${missing.join(', ')}. ` +
        'Test Execution Timing always holds a number — get it from `run-timing.js render`.');
    }
  }

  const timing = statValues(body, 'Test Execution Timing');
  timing.forEach((value, i) => {
    const err = timingError(value, timing.length > 1 ? ` (block ${i + 1})` : '');
    if (err) errors.push(err);
  });

  const bad = [];
  // A part of a split results comment carries the story's TC count and its own TC range in Total TCs: "55 (31-55)".
  const splitPart = isResultsBody(body) && markersIn(body).length > 0;
  for (const label of INTEGER_ROWS) {
    const valid = label === 'Total TCs' && splitPart ? /^\d+ \(\d+-\d+\)$/ : /^\d+$/;
    for (const v of statValues(body, label)) if (!valid.test(v)) bad.push(`${label} = "${v || '(empty)'}"`);
  }
  for (const v of statValues(body, 'QA Pipeline Version')) if (!/^\d+\.\d+\.\d+$/.test(v)) bad.push(`QA Pipeline Version = "${v || '(empty)'}"`);
  for (const label of ['Concern', 'Build / Version']) {
    for (const v of statValues(body, label)) if (!v) bad.push(`${label} = (empty)`);
  }
  if (bad.length) {
    errors.push('[CHECK 17] Stats rows the dashboard reads must hold a plain value: a whole number for Total TCs, Passed, Failed, Blocked, ' +
      'Needs Review and Skipped (Total TCs of a part of a split results comment reads "<story total> (<first>-<last>)", e.g. "55 (31-55)"), ' +
      'major.minor.patch for QA Pipeline Version, and text for Concern and Build / Version. ' +
      'Put any explanation (e.g. "retest of the non-pass TCs") in the Preconditions row, never in these cells.\n  Found: ' + [...new Set(bad)].slice(0, 6).join('; '));
  }
  return errors;
}

module.exports = { INTEGER_ROWS, statsErrors };
