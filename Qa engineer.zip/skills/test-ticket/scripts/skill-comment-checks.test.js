#!/usr/bin/env node
/**
 * Tests for skill-comment-checks.js, driven through validate-results-comment.js (--kind gtc | exec | gresults | tc).
 * Run: node plugins/qa-engineer/skills/test-ticket/scripts/skill-comment-checks.test.js
 */
'use strict';

const test = require('node:test');
const assert = require('node:assert');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { spawnSync } = require('child_process');
const rp = require('./result-parts');

const STORY = 'QA-9';
const ids = (n, from = 1) => Array.from({ length: n }, (_, i) => `TC_${String(from + i).padStart(2, '0')}`);
const mk = (n, m) => (m > 1 ? [rp.markerLine(n, m), ''] : []);

const TC10 = '| TC_ID | Test case scenario | Preconditions | Test steps | Expected Result | Actual result | Story number | Epic number | Automate | Risk |\n|---|---|---|---|---|---|---|---|---|---|';
const gtcRow = (id, story = STORY) => `| ${id} | scenario | pre | steps | expected | To be Tested | ${story} | N/A | No | High |`;
function gtc(list, { n = 1, m = 1, updated = false, banner = updated, gaps = true, story = STORY, rows } = {}) {
  return ['## QA Test Cases — ' + STORY + (updated ? ' (Updated)' : ''), '', ...mk(n, m),
    banner && (m === 1 || n === 1) ? '> ⚠️ This comment supersedes the previous test case comment (ID: 123). Please delete or ignore the earlier one.' : '', '',
    TC10, ...(rows || list.map(id => gtcRow(id, story))), '', ...(gaps ? ['## Coverage Gaps', '- none found'] : [])].join('\n');
}

const EXEC_STATS = ['Build / Version', 'Preconditions', 'Total TCs', 'Passed', 'Failed', 'Blocked', 'Needs Review', 'Skipped', 'Pass rate', 'QA Pipeline Version'];
const TC6 = '| TC_ID | Test case scenario | Expected Result | Actual Result | Status | Test Proof |\n|---|---|---|---|---|---|';
const resRow = (id, { status = 'PASS ✅', proof = `${id}-result.png`, scenario = 's' } = {}) => `| ${id} | ${scenario} | e | a | ${status} | ${proof} |`;
function results(list, { n = 1, m = 1, stats = true, extras = [], dropStat, rows, story = STORY } = {}) {
  return ['## QA Test Results — ' + story, '', ...mk(n, m),
    ...(stats ? ['| | |', '|---|---|', ...EXEC_STATS.filter(l => l !== dropStat).map(l => `| **${l}** | x |`), ''] : []),
    TC6, ...(rows || list.map(id => resRow(id))), ...extras].join('\n');
}

function validate(body, kind, extra = []) {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'sck-'));
  try {
    const f = path.join(dir, 'b.md');
    fs.writeFileSync(f, body);
    const r = spawnSync(process.execPath, [path.join(__dirname, 'validate-results-comment.js'), f, '--kind', kind, '--story', STORY, ...extra], { encoding: 'utf8' });
    return { ok: r.status === 0, out: r.stdout, err: (r.stderr.match(/\[CHECK \d+\][^\n]*/g) || []).join('\n') };
  } finally { fs.rmSync(dir, { recursive: true, force: true }); }
}
const part = (n, m, list) => ['--part', `${n}/${m}`, '--tc-ids', list.join(',')];

// ─── generating-test-cases: QA Test Cases ───────────────────────────────────

test('gtc: a normal comment and an (Updated) comment with its banner pass', () => {
  assert.ok(validate(gtc(ids(3)), 'gtc').ok);
  assert.ok(validate(gtc(ids(3), { updated: true }), 'gtc').ok);
});

test('gtc: wrong key, missing banner, missing gaps, verdicts, wrong story number and column count are blocked', () => {
  assert.match(validate(gtc(ids(2)).replace('QA-9', 'QA-10'), 'gtc').err, /CHECK 0.*Target mismatch/);
  assert.match(validate(gtc(ids(2), { updated: true, banner: false }), 'gtc').err, /CHECK 10.*banner/);
  assert.match(validate(gtc(ids(2), { gaps: false }), 'gtc').err, /CHECK 9.*exactly one "## Coverage Gaps"/);
  assert.match(validate(gtc(ids(2)).replace('To be Tested', 'PASS ✅'), 'gtc').err, /CHECK 6/);
  assert.match(validate(gtc(ids(2), { story: 'QA-10' }), 'gtc').err, /CHECK 0.*Story number/);
  assert.match(validate(gtc(ids(1), { rows: [gtcRow('TC_01').replace('| High |', '| High | extra |')] }), 'gtc').err, /CHECK 5/);
  assert.match(validate(gtc(ids(2)).replace('## Coverage Gaps', '## Other Section'), 'gtc').err, /CHECK 3|CHECK 9/);
});

test('gtc: split parts — gaps only in the last part, banner only in the first, every TC once', () => {
  const p1 = ids(40), p2 = ids(20, 41);
  assert.ok(validate(gtc(p1, { n: 1, m: 2, gaps: false }), 'gtc', part(1, 2, p1)).ok);
  assert.ok(validate(gtc(p2, { n: 2, m: 2 }), 'gtc', part(2, 2, p2)).ok);
  assert.ok(validate(gtc(p1, { n: 1, m: 2, gaps: false, updated: true }), 'gtc', part(1, 2, p1)).ok);
  assert.ok(validate(gtc(p2, { n: 2, m: 2, updated: true, banner: false }), 'gtc', part(2, 2, p2)).ok, 'banner is needed in part 1 only');
  assert.match(validate(gtc(p1, { n: 1, m: 2 }), 'gtc', part(1, 2, p1)).err, /CHECK 9.*only in the last part/);
  assert.match(validate(gtc(p2, { n: 2, m: 2, gaps: false }), 'gtc', part(2, 2, p2)).err, /CHECK 9.*last part/);
  assert.match(validate(gtc(p1.slice(1), { n: 1, m: 2, gaps: false }), 'gtc', part(1, 2, p1)).err, /CHECK 14.*TC_01/);
  assert.match(validate(gtc(p1, { n: 1, m: 2, gaps: false, updated: true, banner: false }), 'gtc', part(1, 2, p1)).err, /CHECK 10/);
});

// ─── execute-tests: QA Test Results with stats ──────────────────────────────

test('exec: a normal comment passes; the failure modes are blocked', () => {
  assert.ok(validate(results(ids(3)), 'exec').ok);
  assert.ok(validate(results(ids(3), { extras: ['| EXTRA_01 | **[EXTRA]** x | e | a | PASS ✅ | EXTRA_01-result.png |'] }), 'exec').ok);
  assert.match(validate(results(ids(3), { dropStat: 'Passed' }), 'exec').err, /CHECK 2.*Passed.*exactly once/);
  assert.match(validate(results(ids(3), { stats: false }), 'exec').err, /CHECK 2/);
  assert.match(validate(results(ids(1), { rows: [resRow('TC_01', { status: 'DONE' })] }), 'exec').err, /CHECK 8.*Status/);
  assert.match(validate(results(ids(1), { rows: [resRow('TC_01', { proof: '' })] }), 'exec').err, /CHECK 8.*Test Proof/);
  assert.match(validate(results(ids(1), { rows: [resRow('TC_01').replace('| a |', '| a | b |')] }), 'exec').err, /CHECK 10/);
  assert.match(validate(results(ids(2), { rows: [resRow('TC_01'), resRow('TC_01')] }), 'exec').err, /CHECK 4.*Duplicate/);
  assert.match(validate(results(ids(2), { extras: ['| EXTRA_01 | no prefix | e | a | PASS ✅ | x.png |'] }), 'exec').err, /CHECK 11/);
  assert.match(validate(results(ids(2), { story: 'QA-10' }), 'exec').err, /CHECK 0.*Target mismatch/);
  assert.match(validate(results(ids(2)) + '\nPhase 3a notes', 'exec').err, /CHECK 6/);
});

test('exec: split parts — EXTRA rows only in the last part, marker form enforced, every TC once', () => {
  const p1 = ids(40), p2 = ids(20, 41);
  const extra = ['| EXTRA_01 | **[EXTRA]** x | e | a | PASS ✅ | EXTRA_01-result.png |'];
  assert.ok(validate(results(p1, { n: 1, m: 2 }), 'exec', part(1, 2, p1)).ok);
  assert.ok(validate(results(p2, { n: 2, m: 2, extras: extra }), 'exec', part(2, 2, p2)).ok);
  assert.match(validate(results(p1, { n: 1, m: 2, extras: extra }), 'exec', part(1, 2, p1)).err, /CHECK 11.*only in the last part/);
  assert.match(validate(results(p1, { n: 1, m: 2 }).replace('_Part 1 of 2_', '*Part 1 of 2*'), 'exec', part(1, 2, p1)).err, /CHECK 14/);
  assert.match(validate(results(p2.slice(1), { n: 2, m: 2 }), 'exec', part(2, 2, p2)).err, /CHECK 14.*TC_41/);
  assert.match(validate(results(p1, { n: 1, m: 2 }), 'exec', part(1, 2, [...p1, 'TC_99'])).err, /CHECK 14.*TC_99/);
});

// ─── generating-test-cases Step 10: results without stats ───────────────────

test('gresults: no stats table needed, empty Test Proof and SKIPPED are allowed', () => {
  assert.ok(validate(results(ids(2), { stats: false, rows: [resRow('TC_01', { proof: '' }), resRow('TC_02', { status: 'SKIPPED ⏭️', proof: '' })] }), 'gresults').ok);
  assert.match(validate(results(ids(2), { stats: false, rows: [resRow('TC_01', { status: 'DONE', proof: '' })] }), 'gresults').err, /CHECK 8/);
  const p1 = ids(40);
  assert.ok(validate(results(p1, { n: 1, m: 2, stats: false }), 'gresults', part(1, 2, p1)).ok);
  assert.match(validate(results(p1, { n: 1, m: 2, stats: false }), 'gresults', part(2, 2, p1)).err, /CHECK 14/);
});

test('tc (sprint-planning "## Test Cases"): the existing kind already supports parts', () => {
  const body = (list, n, m) => ['## Test Cases — ' + STORY, '', ...mk(n, m), TC10, ...list.map(id => gtcRow(id)), '', `_AC coverage: 2/2 | Automate: 0 Yes / ${list.length} No_`].join('\n');
  assert.ok(validate(body(ids(40), 1, 2), 'tc', part(1, 2, ids(40))).ok);
  assert.match(validate(body(ids(39), 1, 2), 'tc', part(1, 2, ids(40))).err, /CHECK 14.*TC_40/);
});

// ─── whole flow: plan -> build every part -> validate each -> reconcile ─────

test('whole flow for all three skills over many sizes: planner, bodies, validators and reconcile agree', () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'sck-flow-'));
  try {
    for (const [kind, build] of [
      ['gtc', (l, n, m) => gtc(l, { n, m, gaps: n === m, updated: true })],
      ['exec', (l, n, m) => results(l, { n, m, extras: n === m ? ['| EXTRA_01 | **[EXTRA]** x | e | a | PASS ✅ | EXTRA_01-result.png |'] : [] })],
      ['gresults', (l, n, m) => results(l, { n, m, stats: false })],
    ]) {
      for (const total of [10, 45, 46, 60, 85, 100]) {
        const all = ids(total);
        const parts = rp.planParts(all);
        const m = parts.length;
        const files = parts.map((list, i) => {
          const f = path.join(dir, `${kind}-${total}-${i}.md`);
          fs.writeFileSync(f, build(list, i + 1, m));
          const r = validate(fs.readFileSync(f, 'utf8'), kind, m > 1 ? part(i + 1, m, list) : []);
          assert.ok(r.ok, `${kind} n=${total} part ${i + 1}/${m}: ${r.err}`);
          return f;
        });
        const planFile = path.join(dir, 'plan.json');
        fs.writeFileSync(planFile, JSON.stringify(parts.map((tc_ids, i) => ({ part: i + 1, of: m, tc_ids, comment_id: String(i) }))));
        const rc = spawnSync(process.execPath, [path.join(__dirname, 'result-parts.js'), 'reconcile', '--plan', planFile, ...files.flatMap(f => ['--body-file', f])], { encoding: 'utf8' });
        assert.strictEqual(rc.status, 0, `${kind} n=${total}: ${rc.stderr}`);
      }
    }
  } finally { fs.rmSync(dir, { recursive: true, force: true }); }
});

// ─── template sync: the validators must accept what each skill's own template tells the model to post ──────────

const skillsDir = path.join(__dirname, '..', '..');
const fence = (file, startsWith) => {
  const text = fs.readFileSync(path.join(skillsDir, file), 'utf8');
  const blocks = [];
  let cur = null;
  for (const line of text.split('\n')) {
    if (/^\s*```/.test(line)) {
      if (cur === null) cur = []; else { blocks.push(cur.join('\n')); cur = null; }
    } else if (cur !== null) cur.push(line);
  }
  const b = blocks.find(x => x.startsWith(startsWith));
  assert.ok(b, `no fenced template starting with "${startsWith}" in ${file}`);
  return b;
};

test('template sync: execute-tests Step 6c template is accepted (stats labels, 6 columns, EXTRA row)', () => {
  const tpl = fence('execute-tests/SKILL.md', '## QA Test Results — <STORY_KEY>');
  const labels = [...tpl.matchAll(/^\| \*\*(.+?)\*\* \|/gm)].map(m => m[1]);
  assert.deepStrictEqual(labels, EXEC_STATS, 'the template lists exactly the labels the validator requires, in order');
  const body = tpl.replace(/<STORY_KEY>/g, STORY).replace(/<[^>\n]*>/g, 'x')
    .replace(/^\| TC_01 \|.*$/m, '') // the placeholder "all rows" line is replaced by real rows below
    .replace(/^x$/m, '');
  const real = body.replace(/^\| EXTRA_01 \|.*$/m, [resRow('TC_01'), resRow('TC_02', { status: 'SKIP ⏭️' }), '| EXTRA_01 | **[EXTRA]** Verify we are able to x | x | x | PASS ✅ | EXTRA_01-result.png |'].join('\n'));
  const r = validate(real, 'exec');
  assert.ok(r.ok, r.err + '\n' + real);
});

test('template sync: generating-test-cases Step 8 and Step 10 templates are accepted', () => {
  const step8 = fence('generating-test-cases/SKILL.md', '## QA Test Cases — <STORY_KEY>\n');
  assert.match(step8, /\| TC_ID \| Test case scenario \| Preconditions \| Test steps \| Expected Result \| Actual result \| Story number \| Epic number \| Automate \| Risk \|/);
  assert.match(step8, /^## Coverage Gaps$/m);
  const body8 = ['## QA Test Cases — ' + STORY, '', TC10, gtcRow('TC_01'), '', '## Coverage Gaps', '- none'].join('\n');
  assert.ok(validate(body8, 'gtc').ok);
  const updated = fence('generating-test-cases/SKILL.md', '## QA Test Cases — <STORY_KEY> (Updated)');
  const bannerLine = updated.split('\n').find(l => l.startsWith('> ⚠️'));
  assert.ok(bannerLine, 'the (Updated) template has its banner line');
  const bodyU = ['## QA Test Cases — ' + STORY + ' (Updated)', '', bannerLine.replace('<original-comment-id>', '2565589'), '', TC10, gtcRow('TC_01'), '', '## Coverage Gaps', '- none'].join('\n');
  const rU = validate(bodyU, 'gtc');
  assert.ok(rU.ok, rU.err);
  const step10 = fence('generating-test-cases/SKILL.md', '## QA Test Results — <STORY_KEY>');
  assert.match(step10, /\| TC_ID \| Test case scenario \| Expected Result \| Actual Result \| Status \| Test Proof \|/);
  const statuses = [...step10.matchAll(/\| (PASS ✅|FAIL ❌) \|/g)].map(m => m[1]);
  assert.ok(statuses.length >= 2);
  const body10 = ['## QA Test Results — ' + STORY, '', TC6, ...statuses.map((st, i) => `| TC_0${i + 1} | Verify x | e | a | ${st} | |`)].join('\n');
  assert.ok(validate(body10, 'gresults').ok, validate(body10, 'gresults').err);
});

test('template sync: sprint-planning Step 6 "## Test Cases" template is accepted by --kind tc', () => {
  const tpl = fence('sprint-planning/SKILL.md', '## Test Cases — <TICKET_KEY>');
  assert.match(tpl, /_AC coverage: <covered>\/<total> \| Automate: <n> Yes \/ <m> No_/);
  const body = ['## Test Cases — ' + STORY, '', TC10, gtcRow('TC_01'), '', '_AC coverage: 2/2 | Automate: 0 Yes / 1 No_'].join('\n');
  assert.ok(validate(body, 'tc').ok, validate(body, 'tc').err);
});

test('status strings: the exact spellings used in the skills (with or without the variation selector) are accepted', () => {
  for (const f of ['execute-tests/SKILL.md', 'generating-test-cases/SKILL.md', 'test-ticket/SKILL.md']) {
    const text = fs.readFileSync(path.join(skillsDir, f), 'utf8');
    for (const m of text.matchAll(/SKIP(?:PED)? ⏭️?/g)) {
      const body = results(ids(1), { stats: false, rows: [resRow('TC_01', { status: m[0], proof: '' })] });
      assert.ok(validate(body, 'gresults').ok, `${f}: "${m[0]}" (${[...m[0]].map(c => c.codePointAt(0).toString(16)).join(' ')})`);
    }
  }
});
