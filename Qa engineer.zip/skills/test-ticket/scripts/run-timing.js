#!/usr/bin/env node
/**
 * Test Execution Timing bookkeeping for /test-ticket: keeps the timing fields of one story in run-state.json
 * and prints the finished "Test Execution Timing" cell, so the agent never does the date arithmetic by hand.
 * No network, no dependencies.
 *
 * Usage (<state> = test-output/<EPIC_ID>/run-state.json, <KEY> = the story key used in run-state.json):
 *   node run-timing.js init       <state> <KEY>
 *   node run-timing.js touch      <state> <KEY>
 *   node run-timing.js gap-check  <state> <KEY> [--url <hostname>]
 *   node run-timing.js pause      <state> <KEY> <wait_start_iso> <wait_end_iso> [--url <hostname>]
 *   node run-timing.js pause-start <state> <KEY>
 *   node run-timing.js pause-end   <state> <KEY> [--url <hostname>]
 *   node run-timing.js url-begin  <state> <KEY> <hostname>
 *   node run-timing.js url-end    <state> <KEY> <hostname>
 *   node run-timing.js render     <state> <KEY> [<cycle_ended_at_iso>] [--url <hostname>] [--screenshots-dir <dir>]
 *
 *   init       Idempotent. Sets whatever is missing: cycle_started_at (now), user_wait_seconds 0, pause_count 0,
 *              url_timing {}, last_activity_at (= cycle_started_at when it was just stamped, else now). Never
 *              overwrites a value that is already there, so it is safe on every start and resume.
 *   touch      Heartbeat: last_activity_at = now.
 *   gap-check  (an unreadable last_activity_at counts as missing) Resume Gap Check: a gap over 600 s since last_activity_at is one pause (added to user_wait_seconds,
 *              pause_count + 1, and to url_timing.<hostname> with --url). Always ends with last_activity_at = now.
 *              A missing last_activity_at is set to now and counts no pause.
 *   pause      A Session Recovery wait: wait_end - wait_start is added, pause_count + 1 (and url_timing.<hostname>),
 *              last_activity_at = wait_end.
 *   pause-start / pause-end  The same pause without typing times: pause-start stamps pause_started_at when the wait begins, pause-end counts
 *              the time since it as one pause (and in the --url block) and moves last_activity_at. Prefer these over `pause`.
 *   url-begin  Creates url_timing.<hostname> = { user_wait_seconds: 0, pauses: 0 } when absent (run order = key order).
 *   url-end    url_timing.<hostname>.ended_at = now, last_activity_at = now.
 *   render     <cycle_ended_at_iso> defaults to now. Prints the cell text to stdout: "42m", "1h 12m", "38m (2 pauses)". Without --url the whole cycle,
 *              with --url that URL's block (URL 1 starts at cycle_started_at, a later URL at the previous URL's end;
 *              the last URL and any URL without ended_at end at cycle_ended_at). A null cycle_started_at falls back
 *              to the earliest .png modification time under --screenshots-dir. Never prints N/A.
 *
 *
 * Time taken per TC (the progress table the user sees after every TC):
 *   node run-timing.js tc-start <timer-file> <TC_ID> [--state <run-state.json> --story <KEY>]
 *   node run-timing.js tc-end   <timer-file> <TC_ID> [--state <run-state.json> --story <KEY>]
 *   tc-start   Stamps the start of <TC_ID> in <timer-file> (e.g. test-output/<EPIC_ID>/tc-timer.json). Call it once per TC
 *              at its start; a second call for the same TC (a retry attempt) keeps the first start. A timer from another
 *              cycle or older than 2 hours is stale and replaced. With --state/--story it also records the pauses already
 *              counted (user_wait_seconds) and refreshes last_activity_at (the heartbeat).
 *   tc-end     Prints the time the TC took ("45s", "3m", "2m 10s", "1h 5m"), minus any pause counted since tc-start, removes
 *              the timer and (with --state/--story) refreshes the heartbeat. Prints "n/a" when no timer is running for <TC_ID>.
 *
 * RUN_TIMING_NOW=<iso> fixes the clock (tests). Exit 0 on success, 1 on any error (message on stderr).
 */
'use strict';

const fs = require('fs');
const path = require('path');
const { formatTiming } = require('./timing-value');

const GAP_THRESHOLD_SECONDS = 600;

const fail = (msg) => { process.stderr.write(`run-timing.js: ${msg}\n`); process.exit(1); };
const now = () => new Date(process.env.RUN_TIMING_NOW || Date.now());
const toMs = (iso, what) => { const t = Date.parse(iso); if (!Number.isFinite(t)) fail(`${what} is not a valid ISO time: "${iso}"`); return t; };
// Fractional seconds are kept on purpose: rounding happens once, to total minutes, in formatTiming, and the
// 600 s gap threshold is compared against the raw gap.
const seconds = (fromMs, toMsValue) => Math.max(0, (toMsValue - fromMs) / 1000);
const ms3 = (s) => Math.round(s * 1000) / 1000;

function load(file) {
  let state;
  try { state = JSON.parse(fs.readFileSync(file, 'utf8')); } catch (e) { fail(`cannot read ${file}: ${e.message}`); }
  if (!state || typeof state !== 'object') fail(`${file} is not a JSON object`);
  return state;
}

function save(file, state) {
  const tmp = `${file}.${process.pid}.tmp`;
  try {
    fs.writeFileSync(tmp, JSON.stringify(state, null, 2) + '\n');
    fs.renameSync(tmp, file);
  } catch (e) {
    try { fs.unlinkSync(tmp); } catch { /* nothing to clean */ }
    fail(`cannot write ${file}: ${e.message}`);
  }
}

function storyOf(state, key) {
  if (!state.stories || typeof state.stories !== 'object') fail('run-state.json has no "stories" object');
  const story = state.stories[key];
  if (!story || typeof story !== 'object') fail(`no story "${key}" in run-state.json`);
  return story;
}

const num = (v) => (Number.isFinite(v) && v >= 0 ? v : 0);

function urlEntry(story, host, create) {
  if (!story.url_timing || typeof story.url_timing !== 'object') story.url_timing = {};
  let e = story.url_timing[host];
  if (!e && create) e = story.url_timing[host] = { user_wait_seconds: 0, pauses: 0 };
  if (e) { e.user_wait_seconds = num(e.user_wait_seconds); e.pauses = num(e.pauses); }
  return e;
}

function addPause(story, host, waitSeconds) {
  waitSeconds = ms3(waitSeconds);
  story.user_wait_seconds = ms3(num(story.user_wait_seconds) + waitSeconds);
  story.pause_count = num(story.pause_count) + 1;
  if (host) {
    const e = urlEntry(story, host, true);
    e.user_wait_seconds = ms3(e.user_wait_seconds + waitSeconds);
    e.pauses += 1;
  }
}

function earliestScreenshot(dir) {
  let best = null;
  const walk = (d) => {
    let entries;
    try { entries = fs.readdirSync(d, { withFileTypes: true }); } catch { return; }
    for (const e of entries) {
      const p = path.join(d, e.name);
      if (e.isDirectory()) walk(p);
      else if (/\.png$/i.test(e.name)) { const t = fs.statSync(p).mtimeMs; if (best === null || t < best) best = t; }
    }
  };
  walk(dir);
  return best;
}

function render(story, endedIso, host, screenshotsDir) {
  const endMs = toMs(endedIso, 'cycle_ended_at');
  let startMs = story.cycle_started_at ? toMs(story.cycle_started_at, 'cycle_started_at') : null;
  if (startMs === null && screenshotsDir) startMs = earliestScreenshot(screenshotsDir);
  if (startMs === null) fail('cycle_started_at is null and no screenshots were found to fall back on (--screenshots-dir)');

  if (!host) return formatTiming(seconds(startMs, endMs) - num(story.user_wait_seconds), num(story.pause_count));

  const hosts = story.url_timing && typeof story.url_timing === 'object' ? Object.keys(story.url_timing) : [];
  const i = hosts.indexOf(host);
  if (i === -1) fail(`url_timing has no entry for "${host}"`);
  const endOf = (h, idx) => {
    const ended = story.url_timing[h] && story.url_timing[h].ended_at;
    return idx === hosts.length - 1 || !ended ? endMs : toMs(ended, `url_timing.${h}.ended_at`);
  };
  const urlStart = i === 0 ? startMs : endOf(hosts[i - 1], i - 1);
  const e = urlEntry(story, host, false);
  return formatTiming(seconds(urlStart, endOf(host, i)) - e.user_wait_seconds, e.pauses);
}

const STALE_TIMER_MS = 2 * 60 * 60 * 1000;

// Seconds -> "45s", "3m", "2m 10s", "1h 5m". Display only (the Jira Timing cell has its own format in timing-value.js).
function formatDuration(totalSeconds) {
  const t = Math.max(0, Math.round(totalSeconds));
  if (t < 60) return `${t}s`;
  if (t < 3600) { const m = Math.floor(t / 60), sec = t % 60; return sec ? `${m}m ${sec}s` : `${m}m`; }
  return `${Math.floor(t / 3600)}h ${Math.floor((t % 3600) / 60)}m`;
}

function readTimer(file) {
  try { const t = JSON.parse(fs.readFileSync(file, 'utf8')); return t && typeof t === 'object' ? t : null; } catch { return null; }
}

function timerCommand(cmd, timerFile, tcId, rest, at) {
  const optValue = (name) => { const i = rest.indexOf(name); return i !== -1 ? rest[i + 1] : undefined; };
  const stateFile = optValue('--state'), storyKey = optValue('--story');
  let state = null, story = null;
  if (stateFile || storyKey) {
    if (!stateFile || !storyKey) fail('--state and --story go together');
    state = load(stateFile);
    story = storyOf(state, storyKey);
  }
  const wait = story ? num(story.user_wait_seconds) : 0;
  const cycle = story && story.cycle_started_at ? story.cycle_started_at : null;
  const existing = readTimer(timerFile);

  if (cmd === 'tc-start') {
    const reusable = existing && existing.tc_id === tcId && existing.started_at
      && at.getTime() - Date.parse(existing.started_at) <= STALE_TIMER_MS && (existing.cycle || null) === cycle;
    if (!reusable) {
      try { fs.writeFileSync(timerFile, JSON.stringify({ tc_id: tcId, started_at: at.toISOString(), wait_baseline: story ? wait : null, cycle }) + '\n'); }
      catch (e) { fail(`cannot write ${timerFile}: ${e.message}`); }
    }
    process.stdout.write('OK\n');
  } else {
    let out = 'n/a';
    if (existing && existing.tc_id === tcId && existing.started_at) {
      out = formatDuration(seconds(Date.parse(existing.started_at), at.getTime()) - Math.max(0, wait - (Number.isFinite(existing.wait_baseline) ? existing.wait_baseline : wait)));
    }
    try { fs.unlinkSync(timerFile); } catch { /* no timer to remove */ }
    process.stdout.write(`${out}\n`);
  }
  if (story) { story.last_activity_at = at.toISOString(); save(stateFile, state); }
}

function main(argv) {
  if (argv[0] === 'tc-start' || argv[0] === 'tc-end') {
    const [cmd, timerFile, tcId, ...tail] = argv;
    if (!timerFile || !tcId) fail(`usage: run-timing.js ${cmd || 'tc-start|tc-end'} <timer-file> <TC_ID> [--state <run-state.json> --story <KEY>]`);
    return timerCommand(cmd, timerFile, tcId, tail, now());
  }
  const [cmd, file, key, ...rest] = argv;
  if (!cmd || !file || !key) fail('usage: run-timing.js <init|touch|gap-check|pause-start|pause-end|pause|url-begin|url-end|render> <run-state.json> <STORY_KEY> [args], or tc-start|tc-end <timer-file> <TC_ID> [--state <run-state.json> --story <KEY>] — see the header of this file');
  const optValue = (name) => { const i = rest.indexOf(name); return i !== -1 ? rest[i + 1] : undefined; };
  const positional = rest.filter((a, i) => !a.startsWith('--') && !(i > 0 && rest[i - 1].startsWith('--')));
  const host = optValue('--url');
  const at = now();
  const state = load(file);
  const story = storyOf(state, key);

  if (cmd === 'init') {
    let stamped = false;
    if (!story.cycle_started_at) { story.cycle_started_at = at.toISOString(); stamped = true; delete story.pause_started_at; }
    if (!Number.isFinite(story.user_wait_seconds)) story.user_wait_seconds = 0;
    if (!Number.isFinite(story.pause_count)) story.pause_count = 0;
    if (!story.url_timing || typeof story.url_timing !== 'object') story.url_timing = {};
    if (!story.last_activity_at) story.last_activity_at = stamped ? story.cycle_started_at : at.toISOString();
    save(file, state);
    process.stdout.write('OK\n');
  } else if (cmd === 'touch') {
    story.last_activity_at = at.toISOString();
    save(file, state);
    process.stdout.write('OK\n');
  } else if (cmd === 'gap-check') {
    let msg;
    const heartbeat = story.last_activity_at ? Date.parse(story.last_activity_at) : NaN;
    if (!Number.isFinite(heartbeat)) msg = 'no valid last_activity_at on file — set to now, no pause counted';
    else {
      const gap = seconds(heartbeat, at.getTime());
      if (gap > GAP_THRESHOLD_SECONDS) { addPause(story, host, gap); msg = `pause counted: gap ${Math.round(gap)}s (pause_count ${story.pause_count})`; }
      else msg = `no pause: gap ${Math.round(gap)}s`;
    }
    story.last_activity_at = at.toISOString();
    save(file, state);
    process.stdout.write(`${msg}\n`);
  } else if (cmd === 'pause-start') {
    story.pause_started_at = at.toISOString();
    save(file, state);
    process.stdout.write('OK\n');
  } else if (cmd === 'pause-end') {
    const startedMs = story.pause_started_at ? Date.parse(story.pause_started_at) : NaN;
    let msg = 'no pause was started — nothing counted';
    if (Number.isFinite(startedMs)) { addPause(story, host, seconds(startedMs, at.getTime())); msg = `pause counted (pause_count ${story.pause_count})`; }
    delete story.pause_started_at;
    story.last_activity_at = at.toISOString();
    save(file, state);
    process.stdout.write(`${msg}\n`);
  } else if (cmd === 'pause') {
    const [startIso, endIso] = positional;
    if (!startIso || !endIso) fail('pause needs <wait_start_iso> <wait_end_iso>');
    const endMs = toMs(endIso, 'wait_end');
    addPause(story, host, seconds(toMs(startIso, 'wait_start'), endMs));
    story.last_activity_at = new Date(endMs).toISOString();
    save(file, state);
    process.stdout.write(`pause counted (pause_count ${story.pause_count})\n`);
  } else if (cmd === 'url-begin' || cmd === 'url-end') {
    const h = positional[0];
    if (!h) fail(`${cmd} needs <hostname>`);
    const e = urlEntry(story, h, true);
    if (cmd === 'url-end') { e.ended_at = at.toISOString(); story.last_activity_at = e.ended_at; }
    save(file, state);
    process.stdout.write('OK\n');
  } else if (cmd === 'render') {
    process.stdout.write(`${render(story, positional[0] || at.toISOString(), host, optValue('--screenshots-dir'))}\n`);
  } else {
    fail(`unknown command "${cmd}"`);
  }
}

main(process.argv.slice(2));
