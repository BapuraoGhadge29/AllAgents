#!/usr/bin/env node
/**
 * Add human-requested cases to the "Extended cases added after Human review" section of a Test Cases comment.
 *
 * Pure text transform — no network, no credentials. It reads the current comment body, applies Claude's decision
 * on each case a human asked for, and writes the new body. The numbers in the "_Human review: …_" line are
 * computed here, never typed by the model, and the section is validated by tc-extended.js (the same module the
 * post/update validators use), so a hand-edited or inconsistent section is rejected at post time.
 *
 * Usage:
 *   node extend-tc-comment.js <body_in_file> <entries_json_file> <body_out_file> [--main-total <n>]
 *
 * Split Test Cases comment (more than 45 rows, see result-parts.js): run it on the body of the LAST part only (it carries
 * the "_Part m of m_" line) and pass --main-total <n>, the number of main TCs of the whole story: "Claude generated" counts
 * all of them, not just this part's rows. Any other part is refused. The new TC ids continue after the highest id in the body.
 *
 * entries_json_file:
 *   { "entries": [
 *       { "decision": "accepted" | "overridden",            // adds a TC row
 *         "row": { "scenario": "...", "preconditions": "...", "steps": "...", "expected": "...",
 *                  "automate": "Yes|No" (default No; "automated" is accepted too), "risk": "High|Medium|Low" (default Medium),
 *                  "story": "<KEY>" (optional; must equal the comment's own story key — a different key is rejected),
 *                  "epic": "<KEY or N/A>" (defaults to the main table's first row) } },
 *       { "decision": "covered" | "declined" }               // counted only — no row, no text stored
 *   ] }
 *
 *   accepted   = a real miss, Claude agrees and adds it
 *   overridden = Claude said no, the human insisted, added on request (still counted as a miss)
 *   covered    = already covered by an existing TC (not a miss)
 *   declined   = out of scope / contradicts the ticket (not a miss)
 *
 * The body can be the wiki form (script path, "|| TC_ID ||" header) or the markdown form (MCP path, "| TC_ID |").
 * The section header uses the same ninth-column name as the main table ("Automate"; an older comment keeps "Automated").
 * Where the section goes: appended to the end of a pipeline "Test Cases —" comment; for the standalone
 * "QA Test Cases —" comment it goes before a trailing "Coverage Gaps" heading when there is one.
 *
 * Prints one JSON line: { added: ["TC_13"], stats: {...}, missRatePct: 20 }.
 * Exits 0 on success; 1 on bad input (prints why to stderr). Set EXTEND_TC_NOW=<ISO date> to fix the date (tests).
 */

const fs = require('fs');
const T = require('./tc-extended');

// --main-total <n>: only for the LAST part of a split Test Cases comment (see the header). Everything else is positional.
const rawArgs = process.argv.slice(2);
const mtAt = rawArgs.indexOf('--main-total');
const mainTotal = mtAt === -1 ? null : Number(rawArgs[mtAt + 1]);
if (mainTotal !== null && !(Number.isInteger(mainTotal) && mainTotal >= 1)) {
  process.stderr.write('--main-total must be a positive integer\n');
  process.exitCode = 1;
  return;
}
const [inFile, entriesFile, outFile] = mtAt === -1 ? rawArgs : rawArgs.filter((_, i) => i !== mtAt && i !== mtAt + 1);
if (!inFile || !entriesFile || !outFile) {
  process.stderr.write('Usage: node extend-tc-comment.js <body_in_file> <entries_json_file> <body_out_file> [--main-total <n>]\n');
  process.exitCode = 1;
  return;
}

function fail(msg) { process.stderr.write(`❌ extend-tc-comment.js — ${msg}\n`); process.exitCode = 1; }

const ALLOWED = new Set(['accepted', 'overridden', 'covered', 'declined']);
const RISKS = new Set(['High', 'Medium', 'Low']);
const cell = s => String(s == null ? '' : s).replace(/\r?\n+/g, '  ').replace(/\|/g, '/').trim();

function main() {
  let body, input;
  try { body = fs.readFileSync(inFile, 'utf8'); } catch (e) { return fail(`cannot read ${inFile}: ${e.message}`); }
  try { input = JSON.parse(fs.readFileSync(entriesFile, 'utf8')); } catch (e) { return fail(`cannot read ${entriesFile} as JSON: ${e.message}`); }
  const entries = input && Array.isArray(input.entries) ? input.entries : null;
  if (!entries || !entries.length) return fail('entries_json_file needs a non-empty "entries" array.');

  // A split Test Cases comment: the Extended section lives in the LAST part only, and "Claude generated" counts the
  // main TCs of the whole story (--main-total), not just this part's rows.
  const marker = /^\s*[_*]?Part (\d+) of (\d+)[_*]?\s*$/m.exec(body);
  if (marker) {
    if (marker[1] !== marker[2]) return fail(`this is part ${marker[1]} of ${marker[2]} of a split Test Cases comment. The Extended cases section goes only in the last part (${marker[2]} of ${marker[2]}) — pass that part's body.`);
    if (mainTotal === null) return fail('this is the last part of a split Test Cases comment: pass --main-total <n>, the number of main TCs of the whole story.');
  } else if (mainTotal !== null) {
    return fail('--main-total is only for the last part of a split Test Cases comment (the body has no "Part n of m" line).');
  }
  const wiki = /^\s*\|\|\s*TC_ID\s*\|\|/m.test(body);
  const markdown = !wiki && /^\s*\|\s*TC_ID\s*\|/m.test(body);
  if (!wiki && !markdown) return fail('no TC table (|| TC_ID || … or | TC_ID | …) found in the body.');

  const lines = body.replace(/\r\n/g, '\n').split('\n');
  const sec = T.findSection(lines);
  if (sec.headings.length > 1) return fail(`the "${T.SECTION_TITLE}" heading appears ${sec.headings.length} times — fix the comment first.`);

  const all = T.tcRowsOf(lines);
  const mainRows = sec.idx === -1 ? all : all.filter(r => r.i < sec.idx);
  if (!mainRows.length) return fail('the main TC table has no TC_NN rows.');
  const maxId = all.reduce((mx, r) => Math.max(mx, T.tcNumber(T.cells(r.l)[0])), 0);
  const firstMain = T.cells(mainRows[0].l);
  const story = firstMain[6] || '';
  const epic = firstMain[7] || 'N/A';

  // Previous counts: from the stats line when the section already exists, else zero.
  let stats = { generated: mainTotal === null ? mainRows.length : mainTotal, requested: 0, accepted: 0, covered: 0, declined: 0, overridden: 0 };
  let existingRows = [];
  if (sec.idx !== -1) {
    const prev = T.parseStatsLine(sec.statsLine);
    if (!prev) return fail(`the existing "${T.SECTION_TITLE}" section has no valid "_Human review: …_" line — fix it first.`);
    stats = { ...prev };
    stats.generated = mainTotal === null ? mainRows.length : mainTotal;
    existingRows = all.filter(r => r.i > sec.idx && r.i < sec.end).map(r => r.l.trim());
  }

  const newRows = [];
  const added = [];
  let next = maxId;
  for (const [n, e] of entries.entries()) {
    if (!e || !ALLOWED.has(e.decision)) return fail(`entry ${n + 1}: "decision" must be one of ${[...ALLOWED].join(', ')}.`);
    stats.requested += 1;
    if (e.decision === 'covered') { stats.covered += 1; continue; }
    if (e.decision === 'declined') { stats.declined += 1; continue; }
    const r = e.row || {};
    if (r.story && String(r.story).trim().toUpperCase() !== String(story).trim().toUpperCase()) {
      return fail(`entry ${n + 1}: row.story "${r.story}" differs from the comment's story "${story}" — extended rows always use the comment's own story key.`);
    }
    if (!cell(r.scenario) || !cell(r.expected)) return fail(`entry ${n + 1}: an added case needs row.scenario and row.expected.`);
    const risk = r.risk || 'Medium';
    if (!RISKS.has(risk)) return fail(`entry ${n + 1}: row.risk must be High, Medium or Low.`);
    const automated = (r.automate ?? r.automated) === 'Yes' ? 'Yes' : 'No';
    next += 1;
    const id = `TC_${String(next).padStart(2, '0')}`;
    added.push(id);
    const vals = [id, cell(r.scenario), cell(r.preconditions) || 'None', cell(r.steps) || '…', cell(r.expected), 'To be Tested', story, cell(r.epic) || epic, automated, risk];
    newRows.push(wiki ? `| ${vals.join(' | ')} |` : `| ${vals.join(' | ')} |`);
    if (e.decision === 'accepted') stats.accepted += 1; else stats.overridden += 1;
  }

  const date = (process.env.EXTEND_TC_NOW || new Date().toISOString()).slice(0, 10);
  const heading = wiki ? `h3. ${T.SECTION_TITLE}` : `### ${T.SECTION_TITLE}`;
  // The section repeats the main table's column spelling ("Automate", or "Automated" on a comment posted before the rename).
  const cols = T.tc10Cols(T.detectAutomateCol(lines) || T.AUTOMATE_COLS[0]);
  const header = wiki ? `|| ${cols.join(' || ')} ||` : `| ${cols.join(' | ')} |`;
  const sep = '|---|---|---|---|---|---|---|---|---|---|';
  const section = [heading, '', T.buildStatsLine(stats, date), '', header];
  if (markdown) section.push(sep);
  section.push(...existingRows, ...newRows);

  let out;
  if (sec.idx !== -1) {
    out = lines.slice(0, sec.idx).concat(section, lines.slice(sec.end));
  } else {
    // Standalone "QA Test Cases" comments end with a Coverage Gaps heading; keep it last.
    let at = lines.length;
    for (let i = lines.length - 1; i >= 0; i--) {
      if (/^(?:h[1-6]\.|#{1,6})\s*Coverage Gaps\s*$/i.test(lines[i].trim())) { at = i; break; }
    }
    const head = lines.slice(0, at);
    while (head.length && head[head.length - 1].trim() === '') head.pop();
    out = head.concat([''], section, at < lines.length ? [''] : [], lines.slice(at));
  }
  let text = out.join('\n');
  if (!text.endsWith('\n')) text += '\n';

  const problems = T.validateExtended(text, { markdown, mainTotal, split: marker !== null, requireFooter: lines.some(l => /^_AC coverage:.*Automated?:.*_$/.test(l.trim())) });
  if (problems.length) return fail(`the rebuilt section does not validate:\n  ${problems.join('\n  ')}`);

  fs.writeFileSync(outFile, text, 'utf8');
  const m = T.missRate(stats.accepted, stats.overridden, stats.generated);
  process.stdout.write(JSON.stringify({ added, stats, missRatePct: m.pct }) + '\n');
}

main();
