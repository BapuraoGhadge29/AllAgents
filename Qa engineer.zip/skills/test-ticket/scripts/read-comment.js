#!/usr/bin/env node
/**
 * Print one Jira comment's body exactly as Jira holds it (API v2: wiki markup for a comment written by the script path).
 * Used to build the merged Test Cases + results body from the LIVE Test Cases comment instead of from memory,
 * which stays correct after a context compaction.
 *
 * Usage:
 *   node read-comment.js <issue_key> <comment_id> [--out <file>]
 *
 * Without --out the body goes to stdout. Exits 0 on success, 1 on a missing argument, credentials, a comment that does
 * not exist, or an API error. Never writes to Jira.
 */
'use strict';

const fs = require('fs');
const path = require('path');

const argv = process.argv.slice(2);
const outAt = argv.indexOf('--out');
const outFile = outAt === -1 ? null : argv[outAt + 1];
const [issueKey, commentId] = argv.filter((a, i) => outAt === -1 || (i !== outAt && i !== outAt + 1));
if (!issueKey || !commentId || (outAt !== -1 && !outFile)) {
  process.stderr.write('Usage: node read-comment.js <issue_key> <comment_id> [--out <file>]\n');
  process.exit(1);
}

function loadCredentials() {
  let email = process.env.JIRA_EMAIL || '';
  let apiToken = process.env.JIRA_API_TOKEN || '';
  if (!email || !apiToken) {
    try {
      const home = process.env.USERPROFILE || process.env.HOME || '';
      if (!home) throw new Error('no home dir');
      const s = JSON.parse(fs.readFileSync(path.join(home, '.claude', 'settings.json'), 'utf8'));
      if (s && s.env) {
        email = email || s.env.JIRA_EMAIL || '';
        apiToken = apiToken || s.env.JIRA_API_TOKEN || '';
      }
    } catch { /* settings.json unreadable — fall through */ }
  }
  return { email, apiToken };
}

const { email, apiToken } = loadCredentials();
if (!email || !apiToken) {
  process.stderr.write('Missing JIRA_EMAIL or JIRA_API_TOKEN.\n');
  process.exit(1);
}

const auth = Buffer.from(`${email}:${apiToken}`).toString('base64');
const headers = { Authorization: `Basic ${auth}`, Accept: 'application/json' };
const url = `https://maxxton.atlassian.net/rest/api/2/issue/${encodeURIComponent(issueKey)}/comment/${encodeURIComponent(commentId)}`;

fetch(url, { headers })
  .then(res => {
    if (!res.ok) return res.text().then(t => { process.stderr.write(`Jira API error ${res.status} for comment ${commentId} on ${issueKey}: ${t}\n`); process.exit(1); });
    return res.json();
  })
  .then(data => {
    const body = String(data.body || '');
    if (outFile) { fs.writeFileSync(outFile, body); process.stdout.write(`Wrote comment ${data.id} (${body.length} characters) to ${outFile}\n`); }
    else process.stdout.write(body.endsWith('\n') ? body : body + '\n');
  })
  .catch(err => { process.stderr.write(`Read failed: ${err.message}\n`); process.exit(1); });
