#!/usr/bin/env node
/**
 * Tests the screenshot check inside post-comment.js by running the real script with a fake `fetch`
 * (preloaded with node -r), so no Jira, no credentials and no network are involved.
 * Run: node plugins/qa-engineer/skills/test-ticket/scripts/post-comment-screenshots.test.js
 */
'use strict';

const test = require('node:test');
const assert = require('node:assert');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { spawnSync } = require('child_process');

const SCRIPT = path.join(__dirname, 'post-comment.js');
const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'post-comment-shots-'));
test.after(() => fs.rmSync(tmp, { recursive: true, force: true }));

const BODY = [
  'h2. QA Test Results',
  '',
  '| *Concern* | MQA |',
  '| *Environment* | Dev |',
  '| *Build / Version* | 1.0.0 |',
  '| *Preconditions* | None detected |',
  '| *Total TCs* | 2 |',
  '| *Passed* | 2 |',
  '| *Failed* | 0 |',
  '| *Blocked* | 0 |',
  '| *Needs Review* | 0 |',
  '| *Skipped* | 0 |',
  '| *Pass rate* | 100% (BLOCKED and Skipped excluded) |',
  '| *QA Pipeline Version* | 2.13.0 |',
  '| *Test Execution Timing* | 5m |',
  '',
  '|| TC_ID || Test case scenario || Expected Result || Actual Result || Status || Test Proof ||',
  '| TC_01 | Open the page | The page opens | The page opened | PASS ✅ | !TC_01-slug.png! |',
  '| TC_02 | Click the button | The dialog opens | The dialog opened | PASS ✅ | !TC_02-slug.png! |',
  '',
].join('\n');
const bodyFile = path.join(tmp, 'body.txt');
fs.writeFileSync(bodyFile, BODY);

const preload = path.join(tmp, 'fake-fetch.js');
fs.writeFileSync(
  preload,
  `
const cfg = JSON.parse(process.env.FAKE_JIRA);
global.fetch = async (url, init = {}) => {
  const ok = (json) => ({ ok: true, status: 200, json: async () => json, text: async () => JSON.stringify(json) });
  if (url.includes('?fields=attachment')) {
    return cfg.attachmentsFail ? { ok: false, status: 500, json: async () => ({}) } : ok({ fields: { attachment: cfg.attachments.map((filename) => ({ filename })) } });
  }
  if (init.method === 'POST') return ok({ id: '777' });
  if (init.method === 'PUT') return ok({ id: '123' });
  if (/\\/comment\\/\\d+$/.test(url)) return ok({ id: '123', created: '2026-10-22T00:00:00.000+0000', body: 'h2. QA Test Results' });
  return ok({ comments: [], total: 0 });
};
`
);

function run(script, args, fake) {
  const r = spawnSync(process.execPath, ['-r', preload, path.join(__dirname, script), ...args], {
    encoding: 'utf8',
    env: { ...process.env, JIRA_EMAIL: 'a@b.c', JIRA_API_TOKEN: 'x', FAKE_JIRA: JSON.stringify(fake) },
  });
  return { code: r.status, out: r.stdout, err: r.stderr };
}

function post(fake, extra = ['', '2026-10-22T00:00:00Z']) {
  const r = spawnSync(process.execPath, ['-r', preload, SCRIPT, 'K-1', bodyFile, ...extra], {
    encoding: 'utf8',
    env: { ...process.env, JIRA_EMAIL: 'a@b.c', JIRA_API_TOKEN: 'x', FAKE_JIRA: JSON.stringify(fake) },
  });
  return { code: r.status, out: r.stdout, err: r.stderr };
}

test('a posted comment whose screenshots are all attached exits 0 and keeps stdout to the comment id', () => {
  const r = post({ attachments: ['TC_01-slug.png', 'TC_02-slug.png'] });
  assert.strictEqual(r.code, 0);
  assert.strictEqual(r.out, '777\n');
  assert.match(r.err, /Screenshots: 2\/2 attached to K-1/);
});

test('a posted comment with an unattached screenshot exits 3, names it, and still prints the comment id', () => {
  const r = post({ attachments: ['TC_01-slug.png'] });
  assert.strictEqual(r.code, 3);
  assert.strictEqual(r.out, '777\n');
  assert.match(r.err, /1 of 2 referenced in comment 777 are not attached to K-1: TC_02-slug\.png/);
});

test('when Jira cannot be asked for the attachments the comment is not reported as checked', () => {
  const r = post({ attachmentsFail: true });
  assert.strictEqual(r.code, 3);
  assert.strictEqual(r.out, '777\n');
  assert.match(r.err, /could not be checked for K-1/);
});

test('the already-posted detection repeats the check, so the same command re-verifies after an upload', () => {
  const gap = post({ attachments: ['TC_01-slug.png'] }, ['123']);
  assert.strictEqual(gap.code, 3);
  assert.match(gap.out, /Already posted this cycle/);
  assert.match(gap.err, /1 of 2 referenced in comment 123/);
  const fixed = post({ attachments: ['TC_01-slug.png', 'TC_02-slug.png'] }, ['123']);
  assert.strictEqual(fixed.code, 0);
  assert.match(fixed.err, /Screenshots: 2\/2 attached/);
});

test('update-comment.js runs the same check after the PUT: exit 3 with a gap, exit 0 when all are attached', () => {
  const gap = run('update-comment.js', ['K-1', '123', bodyFile], { attachments: ['TC_02-slug.png'] });
  assert.strictEqual(gap.code, 3);
  assert.strictEqual(gap.out, 'Updated comment 123\n');
  assert.match(gap.err, /1 of 2 referenced in comment 123 are not attached to K-1: TC_01-slug\.png/);
  const fixed = run('update-comment.js', ['K-1', '123', bodyFile], { attachments: ['TC_01-slug.png', 'TC_02-slug.png'] });
  assert.strictEqual(fixed.code, 0);
  assert.match(fixed.err, /Screenshots: 2\/2 attached/);
  assert.strictEqual(run('update-comment.js', ['K-1', '123', bodyFile], { attachmentsFail: true }).code, 3);
});
