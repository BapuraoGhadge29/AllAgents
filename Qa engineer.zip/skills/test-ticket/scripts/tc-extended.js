/**
 * Shared helpers for the "Extended cases added after Human review" section of a Test Cases comment.
 *
 * A human reviewer can say "these cases are missing". Claude answers each one (accepted / already covered /
 * declined / added on request) and the accepted ones are added to a SEPARATE section under the main table, so
 * Jira always shows how much Claude generated versus how much a human had to add:
 *
 *   h3. Extended cases added after Human review          (markdown form: "### Extended cases added after Human review")
 *
 *   _Human review: Claude generated 12 · Human requested 4 (accepted 2, already covered 1, declined 0, added on request 1) · Miss rate 20% (3/15) · Last extended 2026-10-14_
 *
 *   || TC_ID || ...the same 10 columns... ||
 *   | TC_13 | ... |
 *
 * Used by extend-tc-comment.js (builds the section) and by post-tc-comment.js, update-tc-comment.js and
 * validate-results-comment.js --kind tc (validate it). Keep the format in ONE place — here.
 */

const SECTION_TITLE = 'Extended cases added after Human review';
// New comments name the ninth column "Automate"; comments posted before the rename carry "Automated". Both stay valid, and an
// edit keeps whichever spelling the comment's main table already has.
const AUTOMATE_COLS = ['Automate', 'Automated'];
const tc10Cols = (automate = AUTOMATE_COLS[0]) => ['TC_ID', 'Test case scenario', 'Preconditions', 'Test steps', 'Expected Result', 'Actual result', 'Story number', 'Epic number', automate, 'Risk'];
const TC10_COLS = tc10Cols();
const HEADING_RE = /^(?:h[1-6]\.|#{1,6})\s*Extended cases added after Human review\s*$/;
const STATS_RE = /^_Human review: Claude generated (\d+) · Human requested (\d+) \(accepted (\d+), already covered (\d+), declined (\d+), added on request (\d+)\) · Miss rate (\d+)% \((\d+)\/(\d+)\) · Last extended (\d{4}-\d{2}-\d{2})_$/;
const TC_ROW_RE = /^\|\s*TC_\d+\s*\|/;

function cells(line) {
  const t = line.trim();
  if (!t.startsWith('|')) return [];
  const body = t.replace(/^\|\|?/, '').replace(/\|\|?$/, '');
  return body.split(/\|\|?/).map(c => c.trim());
}

/** The spelling of the ninth column in the main TC table of a body ('Automate' | 'Automated'), or null when no 10-column header row is found. */
function detectAutomateCol(lines) {
  for (const l of lines) {
    const c = cells(l);
    if (c.length === 10 && c[0] === 'TC_ID' && AUTOMATE_COLS.includes(c[8])) return c[8];
  }
  return null;
}

function tcRowsOf(lines) {
  return lines.map((l, i) => ({ l, i })).filter(({ l }) => TC_ROW_RE.test(l.trim()));
}

function tcNumber(id) { return Number(String(id).replace(/^TC_/, '')); }

function missRate(accepted, overridden, generated) {
  const missed = accepted + overridden;
  const total = generated + missed;
  return { pct: total === 0 ? 0 : Math.round((missed / total) * 100), missed, total };
}

function buildStatsLine(s, date) {
  const m = missRate(s.accepted, s.overridden, s.generated);
  return `_Human review: Claude generated ${s.generated} · Human requested ${s.requested} (accepted ${s.accepted}, already covered ${s.covered}, declined ${s.declined}, added on request ${s.overridden}) · Miss rate ${m.pct}% (${m.missed}/${m.total}) · Last extended ${date}_`;
}

function parseStatsLine(line) {
  const m = STATS_RE.exec((line || '').trim());
  if (!m) return null;
  return {
    generated: +m[1], requested: +m[2], accepted: +m[3], covered: +m[4], declined: +m[5], overridden: +m[6],
    pct: +m[7], missed: +m[8], total: +m[9], date: m[10],
  };
}

/** Locate the section. Returns { headings: [idx...], idx, statsIdx, statsLine, end } — idx is the first heading or -1. */
function findSection(lines) {
  const headings = [];
  lines.forEach((l, i) => { if (HEADING_RE.test(l.trim())) headings.push(i); });
  if (!headings.length) return { headings, idx: -1 };
  const idx = headings[0];
  let statsIdx = -1;
  for (let i = idx + 1; i < lines.length; i++) {
    if (lines[i].trim() === '') continue;
    statsIdx = i; break;
  }
  // The section ends at the next heading of any kind, or at the end of the body.
  let end = lines.length;
  for (let i = idx + 1; i < lines.length; i++) {
    if (/^(?:h[1-6]\.|#{1,6})\s/.test(lines[i].trim())) { end = i; break; }
  }
  return { headings, idx, statsIdx, statsLine: statsIdx === -1 ? '' : lines[statsIdx], end };
}

/**
 * Validate the section of a pipeline Test Cases comment. Returns a list of error strings (empty = fine).
 * A body with no section is always fine (it is optional); a stray stats line without a heading is not.
 */
// mainTotal: the story-wide count of main TCs when this body is the LAST part of a split Test Cases comment (its own main
// table holds only that part's rows). split: true when a --part flag was given, which makes mainTotal mandatory here.
function validateExtended(text, { markdown = false, requireFooter = true, mainTotal = null, split = false } = {}) {
  const errors = [];
  const lines = text.split('\n');
  const sec = findSection(lines);
  const strayStats = lines.some(l => /^_Human review:/.test(l.trim()));

  if (sec.idx === -1) {
    if (strayStats) errors.push(`[CHECK 8] A "_Human review: …_" line exists but the "${SECTION_TITLE}" heading is missing.`);
    return errors;
  }
  const hint = markdown ? '### ' : 'h3. ';
  if (sec.headings.length > 1) errors.push(`[CHECK 8] The "${SECTION_TITLE}" heading appears ${sec.headings.length} times — exactly one section is allowed.`);

  const footerIdx = lines.findIndex(l => /^_AC coverage:.*Automated?:.*_$/.test(l.trim()));
  if (requireFooter && (footerIdx === -1 || footerIdx > sec.idx)) {
    errors.push(`[CHECK 8] The "${SECTION_TITLE}" section must come after the italic AC-coverage footer, not before or without it.`);
  }

  const stats = parseStatsLine(sec.statsLine);
  if (!stats) {
    errors.push(
      `[CHECK 8] The first line under "${hint}${SECTION_TITLE}" must be exactly:\n` +
      `  _Human review: Claude generated <N> · Human requested <R> (accepted <A>, already covered <C>, declined <D>, added on request <P>) · Miss rate <X>% (<A+P>/<N+A+P>) · Last extended <YYYY-MM-DD>_\n` +
      `  Found: "${(sec.statsLine || '(nothing)').trim()}"\n` +
      `  Build the section with extend-tc-comment.js instead of typing the numbers.`
    );
    return errors;
  }

  const allRows = tcRowsOf(lines);
  const mainRows = allRows.filter(r => r.i < sec.idx);
  const extRows = allRows.filter(r => r.i > sec.idx && r.i < sec.end);
  const stray = allRows.filter(r => r.i >= sec.end);
  if (stray.length) errors.push(`[CHECK 8] TC rows after the end of the "${SECTION_TITLE}" section — it must be the last section: ${stray.slice(0, 3).map(r => cells(r.l)[0]).join(', ')}`);

  if (split && mainTotal === null) {
    errors.push('[CHECK 8] This is a part of a split comment: pass --main-total <n> (the number of main TCs of the whole story) so "Claude generated" can be checked.');
  } else if (stats.generated !== (mainTotal === null ? mainRows.length : mainTotal)) {
    errors.push(`[CHECK 8] "Claude generated ${stats.generated}" but ${mainTotal === null ? `the main table has ${mainRows.length} TC rows` : `the story has ${mainTotal} main TCs (--main-total)`}.`);
  }
  if (stats.requested !== stats.accepted + stats.covered + stats.declined + stats.overridden) {
    errors.push(`[CHECK 8] "Human requested ${stats.requested}" does not equal accepted ${stats.accepted} + already covered ${stats.covered} + declined ${stats.declined} + added on request ${stats.overridden}.`);
  }
  const m = missRate(stats.accepted, stats.overridden, stats.generated);
  if (stats.pct !== m.pct || stats.missed !== m.missed || stats.total !== m.total) {
    errors.push(`[CHECK 8] Miss rate is ${stats.pct}% (${stats.missed}/${stats.total}) but accepted + added-on-request over generated + those gives ${m.pct}% (${m.missed}/${m.total}).`);
  }
  if (extRows.length !== stats.accepted + stats.overridden) {
    errors.push(`[CHECK 8] The section has ${extRows.length} TC row(s) but accepted + added on request = ${stats.accepted + stats.overridden}.`);
  }

  // The section's header repeats the main table's spelling; with no main header to compare against, either spelling passes.
  const mainSpelling = detectAutomateCol(lines.slice(0, sec.idx));
  const wantedCols = (mainSpelling ? [mainSpelling] : AUTOMATE_COLS).map(tc10Cols);
  const headerWanted = markdown ? `| ${wantedCols[0].join(' | ')} |` : `|| ${wantedCols[0].join(' || ')} ||`;
  const hdrOk = lines.slice(sec.statsIdx + 1, sec.end).some(l => {
    const c = cells(l);
    return wantedCols.some(cols => c.length === cols.length && c.every((x, i) => x === cols[i]));
  });
  if (!hdrOk) errors.push(`[CHECK 8] The 10-column header row is missing under the stats line. Expected: ${headerWanted}`);

  const ids = allRows.map(r => cells(r.l)[0]);
  const dup = ids.filter((id, i) => ids.indexOf(id) !== i);
  if (dup.length) errors.push(`[CHECK 8] Duplicate TC_ID(s) across the two tables: ${[...new Set(dup)].join(', ')}`);
  const maxMain = mainRows.reduce((mx, r) => Math.max(mx, tcNumber(cells(r.l)[0])), 0);
  const lowExt = extRows.filter(r => tcNumber(cells(r.l)[0]) <= maxMain).map(r => cells(r.l)[0]);
  if (lowExt.length) errors.push(`[CHECK 8] Extended TC IDs must continue after the main table's last ID (TC_${String(maxMain).padStart(2, '0')}): ${lowExt.join(', ')}`);

  return errors;
}

module.exports = {
  SECTION_TITLE, TC10_COLS, AUTOMATE_COLS, tc10Cols, detectAutomateCol, HEADING_RE, STATS_RE, TC_ROW_RE,
  cells, tcRowsOf, tcNumber, missRate, buildStatsLine, parseStatsLine, findSection, validateExtended,
};
