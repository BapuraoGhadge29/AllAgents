#!/usr/bin/env node
/**
 * Split a story's TCs into several results comments when one comment would get too long, and prove that
 * no TC is missed or posted twice. Shared by post-comment.js, update-comment.js and validate-results-comment.js.
 *
 * Rule (rows = TC count x URL blocks, because a multi-URL comment repeats every TC once per URL):
 *   rows <= 45  -> one comment, nothing changes.
 *   rows  > 45  -> parts of at most 40 rows, in TC order; a last part under 10 rows is rebalanced with the one
 *                  before it (46 TCs -> 23 + 23, not 40 + 6).
 *
 * CLI:
 *   node result-parts.js plan --ids TC_01,TC_02,... | --ids-file <file>  [--urls N] [--batch B] [--extended E]
 *       --extended E: a Test Cases comment with E human-added cases (the "Extended cases" section). They count toward the
 *       limit and always sit at the end of the LAST part; their ids (TC_<max+1> ...) are added to that part's tc_ids.
 *       --batch B: split whenever rows > B into parts of at most B rows (use it when a part tripped the length guard).
 *       Prints the plan as JSON. Store its "parts" array in run-state.json as stories.<KEY>.result_parts.
 *   node result-parts.js plan --ids-file <file> --merged-from <drafted Test Cases body> [--extra-per-row <chars>]
 *       sizes the parts of a Test Cases comment so that each part still fits one Jira comment (32,000 characters) AFTER the results
 *       are merged into it: from the real row lengths of the draft (wiki, markdown or HTML), not from a fixed 40 rows.
 *   node result-parts.js reconcile --plan <file.json> --body-file <posted body> [--body-file ...]   (one per part, in order)
 *   node result-parts.js reconcile --plan <file.json> --story <KEY>   (script path: reads each part's comment_id back from Jira)
 *       Exits 0 when every planned TC appears exactly once across the parts, 1 otherwise.
 */
'use strict';

const MAX_ROWS_UNSPLIT = 45;
const BATCH_ROWS = 40;
const MIN_TAIL_ROWS = 10;
// Jira rejects a comment over 32,767 characters; fail a little before that. Applied to the raw body of every format,
// HTML included (the MCP results path), so a body that passes here can never be the reason Jira refuses a part.
const LENGTH_LIMIT = 32000;
const TC_ID_RE = /^TC_\d+$/;
const MARKER_RE = /^[_*]?Part (\d+) of (\d+)[_*]?$/;

// ─── planning ───────────────────────────────────────────────────────────────

function planParts(tcIds, { urls = 1, batch = null } = {}) {
  if (!Array.isArray(tcIds) || !tcIds.length) throw new Error('planParts: no TC ids');
  const bad = tcIds.filter(id => !TC_ID_RE.test(id));
  if (bad.length) throw new Error(`planParts: not TC_<n> ids: ${bad.slice(0, 5).join(', ')}`);
  const seen = new Set();
  const dup = tcIds.filter(id => (seen.has(id) ? true : (seen.add(id), false)));
  if (dup.length) throw new Error(`planParts: duplicate ids in the TC list: ${[...new Set(dup)].join(', ')}`);
  if (!Number.isInteger(urls) || urls < 1) throw new Error(`planParts: urls must be a positive integer (got ${urls})`);
  const u = urls;

  // --batch B (a smaller batch after the length guard tripped) splits whenever rows > B instead of > 45.
  const batchRows = batch || BATCH_ROWS;
  if (tcIds.length * u <= (batch || MAX_ROWS_UNSPLIT)) return [tcIds.slice()];

  // One TC takes u rows (one per URL block); a batch smaller than that cannot hold a single complete TC.
  if (batchRows < u) throw new Error(`planParts: a batch of ${batchRows} rows cannot hold one TC across ${u} URL blocks (use a batch of at least ${u})`);
  const perPart = Math.floor(batchRows / u);
  const parts = [];
  for (let i = 0; i < tcIds.length; i += perPart) parts.push(tcIds.slice(i, i + perPart));
  if (parts.length > 1 && parts[parts.length - 1].length * u < MIN_TAIL_ROWS) {
    const merged = parts[parts.length - 2].concat(parts.pop());
    const half = Math.ceil(merged.length / 2);
    parts[parts.length - 1] = merged.slice(0, half);
    parts.push(merged.slice(half));
  }
  assertPartition(tcIds, parts);
  return parts;
}

// Test Cases comment with human-added ("extended") cases: the Extended section is one section at the end of the LAST
// part, so its rows count toward the limit but can never be split across parts.
//   rows = main TCs + extended; rows <= 45 -> one comment (the section stays in it).
//   rows  > 45 -> main TCs are front-filled in parts of 40, the last part holding at most 40 - extended main rows; a last
//                 part with fewer than 10 main rows is rebalanced evenly with the one before it (60 + 5 -> 40 + (20 + 5)).
// Returns { parts, extendedIds }: parts hold main ids, the last one also lists the extended ids (TC_<max+1> ...).
function planPartsExtended(tcIds, extended, { batch = null } = {}) {
  if (!Number.isInteger(extended) || extended < 1) throw new Error(`planPartsExtended: extended must be a positive integer (got ${extended})`);
  const base = planParts(tcIds, { urls: 1 });
  const maxNum = tcIds.reduce((mx, id) => Math.max(mx, Number(id.slice(3))), 0);
  const width = Math.max(2, String(maxNum).length);
  const extendedIds = Array.from({ length: extended }, (_, i) => `TC_${String(maxNum + i + 1).padStart(width, '0')}`);
  const limit = batch || MAX_ROWS_UNSPLIT;
  const batchRows = batch || BATCH_ROWS;
  if (tcIds.length + extended <= limit) return { parts: [tcIds.concat(extendedIds)], extendedIds, single: true };
  const lastCap = batchRows - extended;
  if (lastCap < 1) throw new Error(`planPartsExtended: ${extended} extended cases leave no room for main rows in the last part (limit ${batchRows}); add them as normal rows instead`);

  const parts = [];
  let i = 0;
  while (tcIds.length - i > lastCap) {
    const take = Math.min(batchRows, tcIds.length - i);
    parts.push(tcIds.slice(i, i + take));
    i += take;
  }
  parts.push(tcIds.slice(i));
  if (parts.length > 1 && parts[parts.length - 1].length < MIN_TAIL_ROWS) {
    const merged = parts[parts.length - 2].concat(parts.pop());
    let last = Math.floor(merged.length / 2);
    if (last > lastCap) last = lastCap;
    if (last < 1) last = 1;
    parts.push(merged.slice(merged.length - last));
    parts[parts.length - 2] = merged.slice(0, merged.length - last);
  }
  parts[parts.length - 1] = parts[parts.length - 1].concat(extendedIds);
  const sizeBad = parts.findIndex((p, k) => p.length > batchRows || (k === parts.length - 1 && p.length - extended < 1));
  if (sizeBad !== -1) throw new Error(`planPartsExtended: part ${sizeBad + 1} has ${parts[sizeBad].length} rows (limit ${batchRows}, last part needs main rows)`);
  assertPartition(tcIds.concat(extendedIds), parts);
  return { parts, extendedIds, single: false };
}

// Every TC exactly once, in the original order. Throws with the exact difference.
function assertPartition(all, parts) {
  const flat = parts.flat();
  const count = new Map();
  for (const id of flat) count.set(id, (count.get(id) || 0) + 1);
  const missing = all.filter(id => !count.has(id));
  const duplicated = [...count].filter(([, n]) => n > 1).map(([id]) => id);
  const unknown = flat.filter(id => !all.includes(id));
  const empty = parts.some(p => !p.length);
  const reordered = !missing.length && !duplicated.length && !unknown.length && flat.some((id, i) => id !== all[i]);
  if (missing.length || duplicated.length || unknown.length || empty || reordered) {
    throw new Error(
      `result parts do not partition the TC list: missing [${missing.join(', ')}], duplicated [${duplicated.join(', ')}], ` +
      `unknown [${[...new Set(unknown)].join(', ')}]${empty ? ', an empty part' : ''}${reordered ? ', order changed' : ''}`
    );
  }
}

// ─── planning parts that still fit one Jira comment once the results are merged in ─────────────────────

// The Test Cases comment is later edited in place into the results, whose rows are longer (Actual result, Status, Test Proof;
// an embedded screenshot is a long media node in HTML). Parts are fixed once posted, so they are sized for the MERGED comment:
// from the real row lengths of the drafted Test Cases body, plus what execution adds to a row, plus the stats table and footer.
// What execution adds to a row is not bounded (long Actual result, several Test Proof images), so the allowance is a typical
// value, not a worst case. Two things keep a part from overflowing anyway: parts are filled to MERGED_FILL of the limit, and
// `--extra-per-row` raises the allowance for a story known to carry heavy evidence (it can never go below the default).
const MERGED_ROW_EXTRA = { html: 700, wiki: 350 };
const MERGED_OVERHEAD = { html: 3500, wiki: 1800 };
const MERGED_FILL = 0.85;

function rowChars(body) {
  const text = String(body);
  const out = new Map();
  if (/^\s*</.test(text)) {
    for (const tr of text.match(/<tr[\s\S]*?<\/tr>/gi) || []) {
      const first = tr.match(/<t[dh][^>]*>([\s\S]*?)<\/t[dh]>/i);
      const id = first ? first[1].replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim() : '';
      if (TC_ID_RE.test(id)) out.set(id, tr.length);
    }
    return out;
  }
  for (const line of text.split('\n')) {
    const id = (/^\s*\|\s*(TC_\d+)\s*\|/.exec(line) || [])[1];
    if (id) out.set(id, line.length + 1);
  }
  return out;
}

function planPartsMerged(tcIds, draftBody, { extraPerRow } = {}) {
  if (!Array.isArray(tcIds) || !tcIds.length) throw new Error('planPartsMerged: no TC ids');
  const flat = [tcIds];
  assertPartition(tcIds, flat);
  const kind = /^\s*</.test(String(draftBody)) ? 'html' : 'wiki';
  const chars = rowChars(draftBody);
  const missing = tcIds.filter(id => !chars.has(id));
  if (missing.length) throw new Error(`planPartsMerged: no row for ${missing.slice(0, 5).join(', ')} in the drafted Test Cases body`);
  const rowExtra = extraPerRow === undefined ? MERGED_ROW_EXTRA[kind] : extraPerRow;
  if (!Number.isInteger(rowExtra) || rowExtra < MERGED_ROW_EXTRA[kind]) {
    throw new Error(`planPartsMerged: --extra-per-row must be an integer of at least ${MERGED_ROW_EXTRA[kind]} for a ${kind} body`);
  }
  const est = tcIds.map(id => chars.get(id) + rowExtra);
  const budget = Math.floor((LENGTH_LIMIT - MERGED_OVERHEAD[kind]) * MERGED_FILL);
  const sum = (a) => a.reduce((s, n) => s + n, 0);
  if (tcIds.length <= MAX_ROWS_UNSPLIT && sum(est) <= budget) return { kind, rowExtra, parts: [tcIds.slice()], estimated: [sum(est) + MERGED_OVERHEAD[kind]] };
  const maxRow = Math.max(...est);
  if (maxRow > budget) throw new Error(`planPartsMerged: one row alone is about ${maxRow} characters once merged; it cannot fit a ${LENGTH_LIMIT}-character comment with headroom`);
  const cut = (limit) => {
    const parts = []; let cur = [], cs = 0;
    est.forEach((e, i) => {
      if (cur.length && (cs + e > limit || cur.length >= BATCH_ROWS)) { parts.push(cur); cur = []; cs = 0; }
      cur.push(tcIds[i]); cs += e;
    });
    parts.push(cur);
    return parts;
  };
  const greedy = cut(budget);
  // Same number of parts, filled evenly (a 30-row story is 15 + 15, not 24 + 6): the tightest limit that still gives that count.
  const average = Math.ceil(sum(est) / greedy.length);
  let parts = greedy;
  for (const factor of [1, 1.02, 1.05, 1.1, 1.2, 1.35]) {
    const even = cut(Math.min(budget, Math.max(average * factor, maxRow)));
    if (even.length === greedy.length) { parts = even; break; }
  }
  assertPartition(tcIds, parts);
  const at = new Map(tcIds.map((id, i) => [id, est[i]]));
  return { kind, rowExtra, parts, estimated: parts.map(p => sum(p.map(id => at.get(id))) + MERGED_OVERHEAD[kind]) };
}

// ─── reading a posted / drafted body ────────────────────────────────────────

const isHtml = (body) => /^\s*</.test(body);
const stripTags = (s) => s.replace(/<[^>]+>/g, ' ').replace(/&nbsp;/g, ' ').replace(/\s+/g, ' ').trim();

function visibleLines(body) {
  const text = String(body);
  if (!isHtml(text)) return text.split('\n').map(l => l.trim()).filter(Boolean);
  return text.replace(/<(br|\/p|\/li|\/h[1-6]|\/tr|\/table|\/figure)[^>]*>/gi, '\n').split('\n').map(stripTags).filter(Boolean);
}

function tcIdsFromBody(body) {
  const text = String(body);
  if (isHtml(text)) {
    const ids = [];
    for (const tr of text.match(/<tr[\s\S]*?<\/tr>/gi) || []) {
      const first = tr.match(/<t[dh][^>]*>([\s\S]*?)<\/t[dh]>/i);
      const cell = first ? stripTags(first[1]) : '';
      if (TC_ID_RE.test(cell)) ids.push(cell);
    }
    return ids;
  }
  return text.split('\n').map(l => (/^\s*\|\s*(TC_\d+)\s*\|/.exec(l) || [])[1]).filter(Boolean);
}

function tcTableCount(body) {
  const text = String(body);
  if (isHtml(text)) {
    return (text.match(/<table[\s\S]*?<\/table>/gi) || []).filter(t => {
      const first = (t.match(/<tr[\s\S]*?<\/tr>/i) || [''])[0].match(/<t[dh][^>]*>([\s\S]*?)<\/t[dh]>/i);
      return first && stripTags(first[1]) === 'TC_ID';
    }).length;
  }
  // The "Extended cases added after Human review" section has its own TC_ID header: it is not another URL block.
  const lines = text.split('\n');
  const cut = lines.findIndex(l => /^(?:h[1-6]\.|#{1,6})\s*Extended cases added after Human review\s*$/.test(l.trim()));
  return (cut === -1 ? lines : lines.slice(0, cut)).filter(l => /^\s*\|\|?\s*TC_ID\s*\|/.test(l)).length;
}

function markersIn(body) {
  return visibleLines(body).map(l => MARKER_RE.exec(l)).filter(Boolean).map(m => ({ n: Number(m[1]), m: Number(m[2]) }));
}

const markerLine = (n, m) => `_Part ${n} of ${m}_`;

// The canonical marker in its canonical place: the first non-empty line after the header for wiki/markdown
// (`_Part n of m_`), the paragraph right after the leading heading for HTML (`<p>Part n of m</p>`).
function markerPlacedAfterHeader(body, n, m) {
  const text = String(body);
  if (isHtml(text)) {
    return new RegExp(`^\\s*<h[1-6][^>]*>[\\s\\S]*?</h[1-6]>\\s*<p>Part ${n} of ${m}</p>`).test(text);
  }
  const lines = text.split('\n').map(l => l.trim()).filter(Boolean);
  return lines[1] === markerLine(n, m);
}
const isMarkerLine = (line) => MARKER_RE.test(String(line).trim());

function hasImpactSection(body) {
  return visibleLines(body).some(l => /^(h2\.|##)?\s*Cross-Module Impact$/.test(l));
}

// The results comment of test-ticket (not a Test Cases, execute-tests or generating-test-cases comment).
const isResultsBody = (body) => /^(?:h[1-6]\.|#{1,6})?\s*QA Test Results$/.test(visibleLines(body)[0] || '');

// ─── checks used by the three comment scripts ───────────────────────────────

function checkPartIds(body, expected) {
  const found = tcIdsFromBody(body);
  const blocks = Math.max(1, tcTableCount(body));
  const count = new Map();
  for (const id of found) count.set(id, (count.get(id) || 0) + 1);
  const missing = expected.filter(id => !count.has(id));
  const extra = [...count.keys()].filter(id => !expected.includes(id));
  const wrongCount = expected.filter(id => count.has(id) && count.get(id) !== blocks);
  const errors = [];
  if (missing.length) errors.push(`missing TC(s) assigned to this part: ${missing.join(', ')}`);
  if (extra.length) errors.push(`TC(s) that belong to another part (or are not planned): ${extra.join(', ')}`);
  if (wrongCount.length) errors.push(`TC(s) not appearing exactly once per URL block (${blocks} block${blocks > 1 ? 's' : ''}): ${wrongCount.map(id => `${id} x${count.get(id)}`).join(', ')}`);
  return errors;
}

function lengthErrors(body) {
  const text = String(body);
  if (text.length <= LENGTH_LIMIT) return [];
  return [`[CHECK 15] The body is ${text.length} characters; Jira rejects a comment over 32,767. Split into more parts: ` +
    'node result-parts.js plan --ids-file <ids> --batch <smaller, e.g. 30> and post each part with --part n/m.'];
}

// A part of a split results comment says what the whole story held and which TCs this part covers in its
// Total TCs row: "<story total> (<first>-<last>)", e.g. "55 (31-55)". Passed, Failed, Blocked, Needs Review,
// Skipped and Pass rate count the whole story in every part (runStatsErrors). Other comment types are not touched.
function totalTcsErrors(body, tcIds, runTotal) {
  if (!isResultsBody(body) || !tcIds || !tcIds.length) return [];
  const values = statValues(body, 'Total TCs');
  if (!values.length) return [];
  if (!Number.isInteger(runTotal) || runTotal < tcIds.length) {
    return [`[CHECK 14] A part of a split results comment needs --run-total <n>: the number of TCs of the whole story ` +
      `(the sum of the tc_ids lengths in result_parts), at least this part's ${tcIds.length}.`];
  }
  const nums = tcIds.map(id => Number(id.slice(3)));
  const expected = `${runTotal} (${Math.min(...nums)}-${Math.max(...nums)})`;
  const wrong = [...new Set(values.filter(v => v !== expected))];
  if (!wrong.length) return [];
  return [`[CHECK 14] Total TCs of a part of a split results comment must read "${expected}": the story's TC count, then the TC numbers ` +
    `this part covers. Found: ${wrong.map(v => `"${v || '(empty)'}"`).join(', ')}. Passed, Failed, Blocked, Needs Review, Skipped and Pass rate still count only this part's TCs.`];
}

// The other stats rows of a part of a split results comment count the whole story too, so a reader sees how many of
// the story's TCs passed and failed without opening the other parts.
const STAT_ROWS = [['Passed', 'PASS'], ['Failed', 'FAIL'], ['Blocked', 'BLOCKED'], ['Needs Review', 'NEEDS REVIEW'], ['Skipped', 'SKIP']];

// Verdicts of the TC rows: one count per status for every URL block (one TC table per block), in order.
function statusCounts(body) {
  const blocks = [];
  const fresh = () => ({ PASS: 0, FAIL: 0, BLOCKED: 0, 'NEEDS REVIEW': 0, SKIP: 0 });
  const add = (status) => {
    const key = (/^(PASS|FAIL|BLOCKED|NEEDS REVIEW|SKIP)\b/.exec(status) || [])[1];
    if (blocks.length && key) blocks[blocks.length - 1][key]++;
  };
  const text = String(body);
  if (isHtml(text)) {
    const cells = (tr) => (tr.match(/<t[dh][^>]*>[\s\S]*?<\/t[dh]>/gi) || []).map(stripTags);
    for (const table of text.match(/<table[\s\S]*?<\/table>/gi) || []) {
      const rows = table.match(/<tr[\s\S]*?<\/tr>/gi) || [];
      if (!rows.length || cells(rows[0])[0] !== 'TC_ID') continue;
      blocks.push(fresh());
      // The Status column sits at index 4 of the 6-column table and 10 of the 12-column merged table: read it from the header.
      const statusAt = cells(rows[0]).indexOf('Status');
      for (const tr of rows.slice(1)) add(cells(tr)[statusAt === -1 ? 4 : statusAt] || '');
    }
    return blocks;
  }
  let statusAt = 4;
  for (const line of text.split('\n')) {
    if (/^\s*\|\|?\s*TC_ID\s*\|/.test(line)) {
      blocks.push(fresh());
      const at = line.split(/\|+/).map(c => c.trim()).filter(Boolean).indexOf('Status');
      statusAt = at === -1 ? 4 : at;
    } else if (/^\s*\|\s*TC_\d+\s*\|/.test(line)) add(line.split('|').map(c => c.trim())[statusAt + 1] || '');
  }
  return blocks;
}

// What the Pass rate row must say: N/A when nothing was verified, else passed / (total - blocked - skipped), one point of rounding allowed.
function passRateError(value, total, passed, blocked, skipped, where) {
  const denominator = total - blocked - skipped;
  if (denominator <= 0) return /^N\/A/.test(value) ? null : `[CHECK 14] Pass rate${where} must be N/A (no TC verified) when the story's Total minus Blocked minus Skipped is 0. Found: "${value}"`;
  const expected = Math.round((100 * passed) / denominator);
  const given = (/^(\d+)%/.exec(value) || [])[1];
  if (given !== undefined && Math.abs(Number(given) - expected) <= 1) return null;
  return `[CHECK 14] Pass rate${where} must be the whole story's, ${expected}% (${passed} / (${total} - ${blocked} - ${skipped})), not this part's. Found: "${value}"`;
}

// Per URL block: Passed + Failed + Blocked + Needs Review + Skipped add up to the story total, none is below what this part
// alone holds, and the Pass rate matches. The exact numbers are proved against all parts by `reconcile`.
function runStatsErrors(body, tcIds, runTotal) {
  if (!isResultsBody(body) || !tcIds || !tcIds.length || !Number.isInteger(runTotal) || runTotal < tcIds.length) return [];
  const own = statusCounts(body);
  const rows = Object.fromEntries([...STAT_ROWS.map(([label]) => label), 'Pass rate'].map(label => [label, statValues(body, label)]));
  const errors = [];
  for (let b = 0; b < rows.Passed.length; b++) {
    const where = rows.Passed.length > 1 ? ` (URL block ${b + 1})` : '';
    const nums = STAT_ROWS.map(([label]) => Number(rows[label][b]));
    if (nums.some(n => !Number.isInteger(n))) continue;
    const sum = nums.reduce((s, n) => s + n, 0);
    if (sum !== runTotal) {
      errors.push(`[CHECK 14] Passed, Failed, Blocked, Needs Review and Skipped must add up to the story's ${runTotal} TCs${where}; they add up to ${sum}. ` +
        'In a part of a split results comment they count the whole story, not only this part.');
    }
    STAT_ROWS.forEach(([label, key], i) => {
      const alone = own[b] ? own[b][key] : 0;
      if (nums[i] < alone) errors.push(`[CHECK 14] ${label} is ${nums[i]}${where}, but this part alone has ${alone} ${key} row(s): the stats count the whole story.`);
    });
    if (rows['Pass rate'][b] !== undefined) {
      const err = passRateError(rows['Pass rate'][b], runTotal, nums[0], nums[2], nums[4], where);
      if (err) errors.push(err);
    }
  }
  return errors;
}

// part: { n, m } or null; tcIds: the TCs this part must contain (required whenever part is set);
// runTotal: the story's TC count, which the Total TCs row of a results part must carry.
// Also reports a body too long for one Jira comment.
function partErrors(body, part, tcIds, runTotal = null) {
  return partMarkerErrors(body, part, tcIds, runTotal).concat(lengthErrors(body));
}

function partMarkerErrors(body, part, tcIds, runTotal = null) {
  const errors = [];
  const markers = markersIn(body);
  if (!part) {
    if (markers.length) {
      errors.push(`[CHECK 14] The body carries a "Part ${markers[0].n} of ${markers[0].m}" marker but no --part was given. ` +
        'Pass --part <n>/<m> --tc-ids <ids> for a split comment, or remove the marker.');
    }
    return errors;
  }
  const { n, m } = part;
  if (!Number.isInteger(n) || !Number.isInteger(m) || m < 2 || n < 1 || n > m) {
    return [`[CHECK 14] --part must be <n>/<m> with 1 <= n <= m and m >= 2 (got ${n}/${m}).`];
  }
  if (!tcIds || !tcIds.length) return ['[CHECK 14] --part needs --tc-ids (or --tc-ids-file): the TCs this part must contain.'];
  if (markers.length !== 1 || markers[0].n !== n || markers[0].m !== m || !markerPlacedAfterHeader(body, n, m)) {
    errors.push(`[CHECK 14] This is part ${n} of ${m}: the body must carry exactly one marker, ${isHtml(String(body)) ? `<p>Part ${n} of ${m}</p>` : `the line "${markerLine(n, m)}"`}, ` +
      `directly after the header (the duplicate guard looks for exactly that). ` +
      `Found: ${markers.length ? markers.map(x => `Part ${x.n} of ${x.m}`).join(', ') : 'none'}`);
  }
  for (const msg of checkPartIds(body, tcIds)) errors.push(`[CHECK 14] Part ${n} of ${m}: ${msg}.`);
  if (n < m && visibleLines(body).some(l => /^(?:h[1-6]\.|#{1,6})\s*Extended cases added after Human review$/.test(l))) {
    errors.push(`[CHECK 14] The "Extended cases added after Human review" section belongs only in the last part (${m} of ${m}); part ${n} must not contain it.`);
  }
  if (n < m && hasImpactSection(body)) {
    errors.push(`[CHECK 14] Cross-Module Impact belongs only in the last part (${m} of ${m}); part ${n} must not contain it.`);
  }
  errors.push(...totalTcsErrors(body, tcIds, runTotal), ...runStatsErrors(body, tcIds, runTotal));
  return errors;
}

// ─── CLI argument helpers (flags are removed from argv so positional parsing stays unchanged) ─────

function parseTcIds(csv) {
  return String(csv).split(/[\s,]+/).map(s => s.trim()).filter(Boolean);
}

function takePartArgs(argv) {
  const rest = [];
  let part = null, tcIds = null, validateOnly = false, mainTotal = null, runTotal = null;
  const fs = require('fs');
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === '--main-total') {
      const v = Number(argv[++i]);
      mainTotal = Number.isInteger(v) && v >= 1 ? v : NaN;
    } else if (a === '--run-total') {
      const v = Number(argv[++i]);
      runTotal = Number.isInteger(v) && v >= 1 ? v : NaN;
    } else if (a === '--validate-only') {
      validateOnly = true;
    } else if (a === '--part') {
      const m = /^(\d+)\/(\d+)$/.exec(argv[++i] || '');
      part = m ? { n: Number(m[1]), m: Number(m[2]) } : { n: NaN, m: NaN };
    } else if (a === '--tc-ids') {
      tcIds = parseTcIds(argv[++i] || '');
    } else if (a === '--tc-ids-file') {
      tcIds = parseTcIds(fs.readFileSync(argv[++i], 'utf8'));
    } else {
      rest.push(a);
    }
  }
  return { rest, part, tcIds, validateOnly, mainTotal, runTotal };
}

// ─── reconcile ──────────────────────────────────────────────────────────────

// Stats rows the adoption dashboard reads to count the parts of a split comment as one run: they must be identical in every part.
const SHARED_STATS = ['Concern', 'Build / Version', 'Test Execution Timing'];

// Values of one stats row, one per URL block in order, from a wiki-markup, markdown or HTML body.
function statValues(body, label) {
  const text = String(body);
  const esc = label.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const rowRes = [
    new RegExp(String.raw`^\|\s*\*${esc}\*\s*\|\s*(.*?)\s*\|?\s*$`, 'gm'),
    new RegExp(String.raw`^\|\s*\*\*${esc}\*\*\s*\|\s*(.*?)\s*\|?\s*$`, 'gm'),
    new RegExp(String.raw`<tr[^>]*>\s*<t[dh][^>]*>(?:(?!</t[dh]>)[\s\S])*?<strong>\s*${esc}\s*</strong>(?:(?!</t[dh]>)[\s\S])*</t[dh]>\s*<t[dh][^>]*>([\s\S]*?)</t[dh]>`, 'gi'),
  ];
  for (const re of rowRes) {
    const vals = [...text.matchAll(re)].map(m => m[1].replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim());
    if (vals.length) return vals;
  }
  return [];
}

function sharedStatErrors(bodies) {
  const errors = [];
  const rows = bodies.map((b) => (b == null ? null : Object.fromEntries(SHARED_STATS.map((l) => [l, statValues(b, l)]))));
  for (const label of SHARED_STATS) {
    // A row no part carries belongs to a comment type without it (a Test Cases comment has no stats table, an
    // execute-tests comment has no Concern or Timing row); the validators judge a missing row on its own.
    if (rows.every((r) => !r || !r[label].length)) continue;
    const present = [];
    rows.forEach((r, i) => {
      if (!r) return;
      if (r[label].length) present.push({ part: i + 1, vals: r[label] });
      else errors.push(`${label} row is missing in part ${i + 1}; every part must carry it`);
    });
    const odd = present.find((x) => x.vals.join(' ') !== present[0].vals.join(' '));
    if (odd) errors.push(`${label} must be identical in every part: part ${present[0].part} has "${present[0].vals.join('" / "')}", part ${odd.part} has "${odd.vals.join('" / "')}"`);
  }
  return errors;
}

// Every part of a results comment must show the story's real numbers: the TC rows of all parts are counted per status
// and every part's Passed, Failed, Blocked, Needs Review, Skipped and Pass rate must match them.
function runStatsReconcileErrors(bodies) {
  if (bodies.some(b => b == null || !isResultsBody(b))) return [];
  const perPart = bodies.map(statusCounts);
  const rowsPerPart = bodies.map(b => Object.fromEntries([...STAT_ROWS.map(([label]) => label), 'Pass rate'].map(label => [label, statValues(b, label)])));
  const blockCount = Math.max(0, ...perPart.map(c => c.length));
  const errors = [];
  for (let b = 0; b < blockCount; b++) {
    const where = blockCount > 1 ? ` (URL block ${b + 1})` : '';
    const total = Object.fromEntries(STAT_ROWS.map(([, key]) => [key, perPart.reduce((s, c) => s + (c[b] ? c[b][key] : 0), 0)]));
    const runTotal = Object.values(total).reduce((s, n) => s + n, 0);
    const rates = [];
    rowsPerPart.forEach((rows, i) => {
      if (rows.Passed[b] === undefined) return;
      for (const [label, key] of STAT_ROWS) {
        if (rows[label][b] !== String(total[key])) errors.push(`part ${i + 1}: ${label} says ${rows[label][b]}${where}, but the TC rows of all parts add up to ${total[key]}`);
      }
      if (rows['Pass rate'][b] !== undefined) {
        rates.push(rows['Pass rate'][b]);
        const err = passRateError(rows['Pass rate'][b], runTotal, total.PASS, total.BLOCKED, total.SKIP, where);
        if (err) errors.push(`part ${i + 1}: ${err}`);
      }
    });
    if (new Set(rates).size > 1) errors.push(`Pass rate${where} must be identical in every part: ${[...new Set(rates)].map(r => `"${r}"`).join(' / ')}`);
  }
  return errors;
}

function reconcile(parts, bodies) {
  const errors = [];
  try { assertPartition(parts.flatMap(p => p.tc_ids), parts.map(p => p.tc_ids)); } catch (e) { errors.push(e.message); }
  const runTotal = parts.reduce((sum, p) => sum + p.tc_ids.length, 0);
  parts.forEach((p, i) => {
    const body = bodies[i];
    if (body == null) { errors.push(`part ${i + 1}: no posted body to check`); return; }
    for (const msg of partErrors(body, parts.length > 1 ? { n: i + 1, m: parts.length } : null, p.tc_ids, runTotal)) errors.push(`part ${i + 1}: ${msg}`);
  });
  if (parts.length > 1) errors.push(...sharedStatErrors(bodies), ...runStatsReconcileErrors(bodies));
  return errors;
}

async function fetchBodies(parts, story) {
  const fs = require('fs'), path = require('path');
  let email = process.env.JIRA_EMAIL || '', apiToken = process.env.JIRA_API_TOKEN || '';
  if (!email || !apiToken) {
    try {
      const s = JSON.parse(fs.readFileSync(path.join(process.env.USERPROFILE || process.env.HOME || '', '.claude', 'settings.json'), 'utf8'));
      email = email || (s.env && s.env.JIRA_EMAIL) || '';
      apiToken = apiToken || (s.env && s.env.JIRA_API_TOKEN) || '';
    } catch { /* fall through */ }
  }
  if (!email || !apiToken) throw new Error('no Jira credentials — pass --body-file per part instead (MCP path)');
  const headers = { Authorization: `Basic ${Buffer.from(`${email}:${apiToken}`).toString('base64')}`, Accept: 'application/json' };
  const out = [];
  for (const p of parts) {
    if (!p.comment_id) { out.push(null); continue; }
    const res = await fetch(`https://maxxton.atlassian.net/rest/api/2/issue/${encodeURIComponent(story)}/comment/${encodeURIComponent(p.comment_id)}`, { headers });
    if (!res.ok) throw new Error(`GET comment ${p.comment_id} failed: ${res.status}`);
    const data = await res.json();
    out.push(typeof data.body === 'string' ? data.body : null);
  }
  return out;
}

async function main(argv) {
  const fs = require('fs');
  const [cmd, ...rest] = argv;
  const opt = (name) => { const i = rest.indexOf(name); return i !== -1 ? rest[i + 1] : undefined; };
  const all = (name) => rest.reduce((acc, a, i) => (a === name ? acc.concat(rest[i + 1]) : acc), []);

  if (cmd === 'plan') {
    const ids = parseTcIds(opt('--ids') !== undefined ? opt('--ids') : fs.readFileSync(opt('--ids-file'), 'utf8'));
    const urls = Number(opt('--urls') || 1);
    const batch = opt('--batch') ? Number(opt('--batch')) : null;
    if (batch !== null && !(Number.isInteger(batch) && batch >= 2)) throw new Error('--batch must be an integer >= 2');
    const extended = opt('--extended') !== undefined ? Number(opt('--extended')) : 0;
    const mergedFrom = opt('--merged-from');
    if (mergedFrom) {
      if (extended || batch !== null || urls !== 1) throw new Error('--merged-from sizes the parts itself: do not combine it with --extended, --batch or --urls');
      const extraPerRow = opt('--extra-per-row') !== undefined ? Number(opt('--extra-per-row')) : undefined;
      const plan = planPartsMerged(ids, fs.readFileSync(mergedFrom, 'utf8'), { extraPerRow });
      process.stdout.write(JSON.stringify({
        total: ids.length, urls, rows: ids.length, split: plan.parts.length > 1, basis: `merged ${plan.kind}`, row_allowance_chars: plan.rowExtra,
        parts: plan.parts.map((tc_ids, i) => ({ part: i + 1, of: plan.parts.length, tc_ids, comment_id: null, estimated_chars: plan.estimated[i] })),
      }, null, 2) + '\n');
      return 0;
    }
    if (extended) {
      if (urls !== 1) throw new Error('--extended is only for a Test Cases comment (--urls must be 1)');
      const plan = planPartsExtended(ids, extended, { batch });
      process.stdout.write(JSON.stringify({
        total: ids.length, main_total: ids.length, extended: extended, extended_ids: plan.extendedIds, urls, rows: ids.length + extended, split: plan.parts.length > 1,
        parts: plan.parts.map((tc_ids, i) => ({ part: i + 1, of: plan.parts.length, tc_ids, comment_id: null })),
      }, null, 2) + '\n');
      return 0;
    }
    const parts = planParts(ids, { urls, batch });
    process.stdout.write(JSON.stringify({
      total: ids.length, urls, rows: ids.length * urls, split: parts.length > 1,
      parts: parts.map((tc_ids, i) => ({ part: i + 1, of: parts.length, tc_ids, comment_id: null })),
    }, null, 2) + '\n');
    return 0;
  }

  if (cmd === 'reconcile') {
    const raw = JSON.parse(fs.readFileSync(opt('--plan'), 'utf8'));
    const parts = Array.isArray(raw) ? raw : raw.parts;
    const files = all('--body-file');
    const bodies = files.length ? files.map(f => fs.readFileSync(f, 'utf8')) : await fetchBodies(parts, opt('--story'));
    if (files.length && files.length !== parts.length) {
      process.stderr.write(`reconcile: ${files.length} --body-file given for ${parts.length} part(s)\n`);
      return 1;
    }
    const errors = reconcile(parts, bodies);
    if (errors.length) { process.stderr.write(`❌ reconcile failed:\n  - ${errors.join('\n  - ')}\n`); return 1; }
    process.stdout.write(`OK — ${parts.flatMap(p => p.tc_ids).length} TC(s) across ${parts.length} part(s), each exactly once.\n`);
    return 0;
  }

  process.stderr.write('Usage: result-parts.js plan --ids <csv> | --ids-file <f> [--urls N] [--batch B]\n' +
    '       result-parts.js reconcile --plan <f.json> (--body-file <f>... | --story <KEY>)\n');
  return 1;
}

module.exports = {
  MAX_ROWS_UNSPLIT, BATCH_ROWS, MIN_TAIL_ROWS,
  planParts, planPartsExtended, planPartsMerged, assertPartition, tcIdsFromBody, tcTableCount, markersIn, markerLine, isMarkerLine,
  LENGTH_LIMIT, lengthErrors, checkPartIds, partErrors, totalTcsErrors, runStatsErrors, statusCounts, isResultsBody, takePartArgs, parseTcIds, reconcile, statValues, sharedStatErrors,
};

if (require.main === module) {
  main(process.argv.slice(2)).then(code => { process.exitCode = code; }).catch(err => {
    process.stderr.write(`result-parts.js: ${err.message}\n`);
    process.exitCode = 1;
  });
}
