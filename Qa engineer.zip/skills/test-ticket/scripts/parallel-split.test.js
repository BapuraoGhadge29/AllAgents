#!/usr/bin/env node
/**
 * Tests for parallel-split.js. Self-contained: node:test + node:assert.
 * Run: node plugins/qa-engineer/skills/test-ticket/scripts/parallel-split.test.js
 */
'use strict';

const test = require('node:test');
const assert = require('node:assert');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { spawnSync } = require('child_process');
const { plan, verify, mergeCheck, progressRows, formatProgressRow, setState, status, InputError } = require('./parallel-split');

const SCRIPT = path.join(__dirname, 'parallel-split.js');
const id = (n) => 'TC_' + String(n).padStart(2, '0');

// The 30-test example from the proposal: A and B stay together, R runs alone, F is free.
const ORDER = 'AAFARFAFBAFRABFFARBFFARFBFRFRF';
function exampleInput(workers) {
  return {
    workers,
    tcs: ORDER.split('').map((code, i) => {
      const base = { id: id(i + 1), risk: 'Medium', writes: [], lists: [] };
      if (code === 'A') return Object.assign(base, { class: 'keyed', keys: ['seed:Customer'] });
      if (code === 'B') return Object.assign(base, { class: 'keyed', keys: ['pool:Availability'] });
      if (code === 'R') return Object.assign(base, { class: 'serial' });
      return Object.assign(base, { class: 'free' });
    }),
  };
}
const tcsOf = (result, worker) => result.workers.find((w) => w.worker === worker).tcs;
const idsFor = (code) => ORDER.split('').map((c, i) => (c === code ? id(i + 1) : null)).filter(Boolean);
// Small plans: no minimum size or minimum saving, so the grouping itself is what is tested.
const small = (workers, tcs) => plan({ workers, min_tcs: 1, min_saving: 0, tcs });

test('plan: the 30-test example splits 12 / 12 with 6 tests left to run alone', () => {
  const result = plan(exampleInput(3));
  assert.strictEqual(result.mode, 'parallel');
  assert.deepStrictEqual(result.workers.map((w) => w.load), [12, 12]);
  assert.deepStrictEqual(result.serial, idsFor('R'));
  assert.deepStrictEqual(tcsOf(result, 1).slice(0, 8), idsFor('A'), 'the biggest group goes first, in its original order');
  assert.deepStrictEqual(tcsOf(result, 2).filter((t) => idsFor('B').includes(t)), idsFor('B'), 'the second group stays together, in its original order');
  assert.deepStrictEqual(result.estimate, { serial_baseline: 30, parallel_phase: 12, serial_phase: 6, merge_and_reruns: 1, total: 19 });
});

test('plan: the proposal page assignment (which free tests go where) is what the script produces', () => {
  const result = plan(exampleInput(3));
  const num = (ids) => ids.map((t) => Number(t.slice(3)));
  assert.deepStrictEqual(num(tcsOf(result, 1)), [1, 2, 4, 7, 10, 13, 17, 22, 15, 20, 24, 28]);
  assert.deepStrictEqual(num(tcsOf(result, 2)), [3, 6, 8, 9, 14, 19, 25, 11, 16, 21, 26, 30]);
});

function dependentInput(dependent, alone, freeCount) {
  return { workers: 3, tcs: [
    ...Array.from({ length: dependent }, (_, i) => ({ id: id(i + 1), class: 'keyed', keys: ['seed:x'] })),
    ...Array.from({ length: alone }, (_, i) => ({ id: id(dependent + i + 1), class: 'serial' })),
    ...Array.from({ length: freeCount }, (_, i) => ({ id: id(dependent + alone + i + 1), class: 'free' })),
  ] };
}

test('plan: the best case and the mostly-dependent case on the page match the script', () => {
  const best = plan({ workers: 3, tcs: Array.from({ length: 30 }, (_, i) => ({ id: id(i + 1), class: 'free' })) });
  assert.deepStrictEqual(best.workers.map((w) => w.load), [15, 15]);
  assert.strictEqual(best.estimate.total, 16);
  const dependent = plan(dependentInput(16, 4, 10));
  assert.strictEqual(dependent.mode, 'parallel');
  assert.deepStrictEqual(dependent.workers.map((w) => w.load), [16, 10]);
  assert.strictEqual(dependent.estimate.total, 21);
});

test('plan: a ticket where almost everything shares data stays a normal sequential run', () => {
  const result = plan(dependentInput(20, 4, 6));
  assert.strictEqual(result.mode, 'serial');
  assert.match(result.reason, /would save only 5 of 30 time units, needs 6/);
});

test('plan: every TC lands exactly once, either on a worker or in the serial list', () => {
  const result = plan(exampleInput(3));
  const all = result.workers.flatMap((w) => w.tcs).concat(result.serial).sort();
  assert.deepStrictEqual(all, Array.from({ length: 30 }, (_, i) => id(i + 1)).sort());
});

test('plan: same input gives the same output', () => {
  assert.deepStrictEqual(plan(exampleInput(3)), plan(exampleInput(3)));
});

test('plan: TCs linked through different keys end up in one group (transitive)', () => {
  const result = small(2, [
    { id: 'T1', class: 'keyed', keys: ['a'] },
    { id: 'T2', class: 'keyed', keys: ['a', 'b'] },
    { id: 'T3', class: 'keyed', keys: ['b'] },
    { id: 'T4', class: 'free' },
  ]);
  assert.deepStrictEqual(result.workers.find((w) => w.tcs.includes('T1')).tcs, ['T1', 'T2', 'T3']);
});

test('plan: names are compared without regard to case', () => {
  const result = small(2, [
    { id: 'T1', class: 'keyed', keys: ['seed:Customer'] },
    { id: 'T2', class: 'keyed', keys: ['SEED:customer '] },
    { id: 'T3', class: 'free' },
  ]);
  assert.deepStrictEqual(result.workers.find((w) => w.tcs.includes('T1')).tcs, ['T1', 'T2']);
  assert.deepStrictEqual(result.footprints.T2.keys, ['seed:customer']);
});

test('plan: a TC that needs another TC\'s data stays on its worker, after the TC that creates it', () => {
  const result = small(2, [
    { id: 'T1', class: 'free' },
    { id: 'T2', class: 'free', depends_on: ['T4'] },
    { id: 'T3', class: 'free' },
    { id: 'T4', class: 'free' },
  ]);
  assert.deepStrictEqual(result.workers.find((w) => w.tcs.includes('T2')).tcs, ['T4', 'T2']);
});

test('plan: a serial group and the sequential fallback also put the data creator first', () => {
  const serialGroup = small(2, [
    { id: 'T1', class: 'serial', depends_on: ['T2'] },
    { id: 'T2', class: 'free' },
    { id: 'T3', class: 'free' },
    { id: 'T4', class: 'free' },
  ]);
  assert.deepStrictEqual(serialGroup.serial, ['T2', 'T1']);

  const fallback = plan({ tcs: [
    { id: 'T1', class: 'free', risk: 'Low' },
    { id: 'T2', class: 'free', risk: 'High', depends_on: ['T1'] },
    { id: 'T3', class: 'free', risk: 'Medium' },
  ] });
  assert.strictEqual(fallback.mode, 'serial');
  assert.deepStrictEqual(fallback.serial, ['T1', 'T2', 'T3'], 'High risk first, but never before the TC whose data it needs');
});

test('plan: a group that holds a serial TC runs alone as a whole', () => {
  const result = small(3, [
    { id: 'T1', class: 'serial' },
    { id: 'T2', class: 'free', depends_on: ['T1'] },
    { id: 'T3', class: 'keyed', keys: ['k'] },
    { id: 'T4', class: 'keyed', keys: ['k'] },
    { id: 'T5', class: 'free' },
  ]);
  assert.deepStrictEqual(result.serial, ['T1', 'T2']);
  assert.deepStrictEqual(result.workers.flatMap((w) => w.tcs).sort(), ['T3', 'T4', 'T5']);
});

test('plan: unsure input fails closed and says why', () => {
  const result = small(2, [
    { id: 'T1' },
    { id: 'T2', class: 'keyed' },
    { id: 'T3', class: 'free', depends_on: ['GHOST'] },
    { id: 'T4', class: 'free' },
    { id: 'T5', class: 'free' },
  ]);
  assert.deepStrictEqual(result.serial, ['T1', 'T2', 'T3']);
  assert.strictEqual(result.warnings.length, 3);
});

test('plan: an unknown risk is a warning and counts as Medium, it does not stop the run', () => {
  const result = small(2, [
    { id: 'T1', class: 'free', risk: 'High ' },
    { id: 'T2', class: 'free', risk: 'Critical' },
  ]);
  assert.strictEqual(result.mode, 'parallel');
  assert.strictEqual(result.footprints.T1.risk, 0, 'trailing space is tolerated');
  assert.strictEqual(result.footprints.T2.risk, 1);
  assert.ok(result.warnings.some((w) => /T2: unknown risk "Critical"/.test(w)));
});

test('plan: falls back to a sequential run when parallel would not pay off', () => {
  assert.strictEqual(plan(exampleInput(1)).mode, 'serial');
  const few = plan({ workers: 3, tcs: exampleInput(3).tcs.slice(0, 7) });
  assert.strictEqual(few.mode, 'serial');
  assert.match(few.reason, /fewer than 8/);
  const oneGroup = small(3, [
    { id: 'T1', class: 'keyed', keys: ['k'] }, { id: 'T2', class: 'keyed', keys: ['k'] }, { id: 'T3', class: 'serial' },
  ]);
  assert.strictEqual(oneGroup.mode, 'serial');
  assert.deepStrictEqual(oneGroup.workers, []);
});

test('plan: no break-even guard slip: 28 tests that run alone plus 2 free tests stay sequential', () => {
  const tcs = [
    ...Array.from({ length: 28 }, (_, i) => ({ id: id(i + 1), class: 'serial' })),
    { id: id(29), class: 'free' }, { id: id(30), class: 'free' },
  ];
  const result = plan({ workers: 3, tcs });
  assert.strictEqual(result.mode, 'serial');
  assert.match(result.reason, /would save only/);
});

test('plan: nobody has to ask for workers: the number is picked automatically', () => {
  const all = plan({ tcs: exampleInput(3).tcs });
  assert.strictEqual(all.mode, 'parallel');
  assert.strictEqual(all.auto, true);
  assert.strictEqual(all.workers.length, 2, '30 TCs: both browsers');

  const eight = plan({ tcs: free(8) });
  assert.strictEqual(eight.mode, 'parallel');
  assert.strictEqual(eight.workers.length, 2, '8 TCs: two workers of 4 TCs each');

  const capped = plan({ max_workers: 3, tcs: exampleInput(3).tcs });
  assert.strictEqual(capped.workers.length, 2, 'never more than two worker browsers, however many were reported');
  assert.strictEqual(plan({ tcs: exampleInput(3).tcs }, { maxWorkers: '2' }).workers.length, 2);
});

test('plan: automatic mode stays sequential when too little can run in parallel', () => {
  const tcs = [...free(7).map((t) => Object.assign(t, { id: 'F' + t.id })), ...Array.from({ length: 5 }, (_, i) => ({ id: 'S' + i, class: 'serial' }))];
  const result = plan({ tcs });
  assert.strictEqual(result.mode, 'serial');
  assert.match(result.reason, /only 7 TCs can run in parallel, too few for two workers/);
  assert.strictEqual(plan({ max_workers: 1, tcs: exampleInput(3).tcs }).mode, 'serial', 'a single browser means sequential');
});

test('plan: a number someone typed is an override', () => {
  assert.strictEqual(plan({ tcs: exampleInput(3).tcs }, { workers: '1' }).mode, 'serial', '--workers=1 turns it off');
  assert.match(plan({ tcs: exampleInput(3).tcs }, { workers: '1' }).reason, /fewer than 2 workers asked for/);
  const asked = plan({ tcs: free(8) }, { workers: '2' });
  assert.strictEqual(asked.auto, false);
  assert.strictEqual(asked.workers.length, 2, 'an explicit 2 is honoured');
  assert.strictEqual(plan({ tcs: free(8) }, { workers: '3' }).workers.length, 2, 'a typed 3 is clamped to the two browsers there are');
  assert.strictEqual(plan({ tcs: exampleInput(3).tcs }, { workers: '2', maxWorkers: '1' }).mode, 'serial', 'never more than the browsers available');
});

test('plan: never asks for more than 2 workers, or more than there are groups', () => {
  assert.strictEqual(plan(exampleInput(9)).workers.length, 2);
  assert.strictEqual(small(3, [{ id: 'T1', class: 'free' }, { id: 'T2', class: 'free' }]).workers.length, 2);
});

test('plan: with two worker browsers (the plugin ships one extra) real ticket shapes split or fall back sensibly', () => {
  const free = (n, from = 1) => Array.from({ length: n }, (_, i) => ({ id: id(from + i), class: 'free' }));
  const alone = (n, from) => Array.from({ length: n }, (_, i) => ({ id: id(from + i), class: 'serial' }));
  const lane = (n, from) => Array.from({ length: n }, (_, i) => ({ id: id(from + i), class: 'keyed', keys: ['seed:x'] }));
  const two = (tcs) => plan({ max_workers: 2, tcs });
  const loads = (result) => result.workers.map((w) => w.load);

  const example = two(exampleInput(3).tcs);
  assert.deepStrictEqual(loads(example), [12, 12], 'the 30-test example: lanes of 8 and 4 plus 12 free tests balance out');
  assert.deepStrictEqual(example.estimate, { serial_baseline: 30, parallel_phase: 12, serial_phase: 6, merge_and_reruns: 1, total: 19 });

  assert.strictEqual(two(free(7)).mode, 'serial', 'under 8 TCs');
  assert.deepStrictEqual(loads(two(free(8))), [4, 4]);
  assert.deepStrictEqual(loads(two(free(10))), [5, 5]);
  assert.deepStrictEqual(loads(two([...alone(1, 1), ...free(8, 2)])), [4, 4], 'one TC run alone does not stop the split');
  assert.deepStrictEqual(loads(two([...lane(8, 1), ...free(12, 9)])), [10, 10], 'a lane of 8 plus 12 free tests balances');

  const mostlyAlone = two([...alone(6, 1), ...free(6, 7)]);
  assert.strictEqual(mostlyAlone.mode, 'serial');
  assert.match(mostlyAlone.reason, /only 6 TCs can run in parallel, too few for two workers/);

  const oneBigLane = two([...lane(12, 1), ...free(4, 13)]);
  assert.strictEqual(oneBigLane.mode, 'serial', 'one lane of 12 in 16 TCs: the second browser saves too little');
  assert.match(oneBigLane.reason, /would save only 3 of 16 time units, needs 4/);
});

test('plan: High risk groups run first on their worker', () => {
  const result = small(2, [
    { id: 'T1', class: 'free', risk: 'Low' },
    { id: 'T2', class: 'free', risk: 'High' },
    { id: 'T3', class: 'free', risk: 'Medium' },
    { id: 'T4', class: 'free', risk: 'High' },
  ]);
  for (const w of result.workers) {
    const ranks = w.tcs.map((t) => result.footprints[t].risk);
    assert.deepStrictEqual(ranks, ranks.slice().sort((a, b) => a - b));
  }
});

test('plan: rejects input it cannot trust', () => {
  assert.throws(() => plan({ tcs: [] }), InputError);
  assert.throws(() => plan({ tcs: [{ id: 'T1', class: 'free' }, { id: 'T1', class: 'free' }] }), /duplicate/);
  assert.throws(() => plan({ tcs: [{ id: 'T1', class: 'weird' }] }), /class must be/);
  assert.throws(() => plan({ tcs: [{ id: 'T1', class: 'free', keys: 'x' }] }), /keys of T1/);
  assert.throws(() => plan(exampleInput(3), { workers: 'abc' }), /workers must be/);
});

// ---- verify ---------------------------------------------------------------

const T0 = Date.parse('2026-10-19T10:00:00Z');
const at = (minutes) => new Date(T0 + minutes * 60000).toISOString();
function entry(tc, verdict, from, to, extra) {
  return Object.assign({ tc, verdict, start: at(from), end: at(to), screenshots: ['test-output/K/' + tc + '-result.png'] }, extra || {});
}
function docsFor(planDoc, entriesByWorker) {
  return planDoc.workers.map((w) => ({ worker: w.worker, entries: entriesByWorker[w.worker] || [] }));
}
function entriesFor(planDoc, fn) {
  const out = {};
  for (const w of planDoc.workers) out[w.worker] = w.tcs.map(fn).filter(Boolean);
  return out;
}
const free = (n) => Array.from({ length: n }, (_, i) => ({ id: 'T' + (i + 1), class: 'free' }));

test('verify: clean passes stand, everything doubtful goes to a solo run', () => {
  const planDoc = small(2, free(6));
  const verdicts = { T1: '✅ PASS', T2: 'FAIL', T3: 'NEEDS REVIEW 🔍', T4: 'PASS', T5: 'UNRUN', T6: 'DEFERRED' };
  const entries = entriesFor(planDoc, (tc, i) => entry(tc, verdicts[tc], i * 2, i * 2 + 1, { reason: 'why' }));
  const result = verify(planDoc, docsFor(planDoc, entries));
  assert.deepStrictEqual(result.keep.map((k) => k.tc).sort(), ['T1', 'T4']);
  assert.deepStrictEqual(result.rerun.map((r) => r.tc).sort(), ['T2', 'T3', 'T5', 'T6']);
  assert.strictEqual(result.rerun.find((r) => r.tc === 'T3').reason, 'non-pass:NEEDS REVIEW');
  assert.strictEqual(result.rerun.find((r) => r.tc === 'T5').reason, 'unrun:why');
});

test('verify: a verdict word inside another word is not a verdict', () => {
  const planDoc = small(2, free(2));
  const entries = entriesFor(planDoc, (tc) => entry(tc, 'PASSWORD rejected', 0, 1));
  const result = verify(planDoc, docsFor(planDoc, entries));
  assert.deepStrictEqual(result.rerun.map((r) => r.reason), ['unknown-verdict', 'unknown-verdict']);
});

test('verify: only the safety-check BLOCKED verdicts stand, the rest is run again', () => {
  const planDoc = small(2, free(4));
  const kinds = { T1: 'other', T2: 'data', T3: undefined, T4: 'timeout' };
  const entries = entriesFor(planDoc, (tc, i) => entry(tc, 'BLOCKED 🚫 (why)', i, i + 1, { blocked_kind: kinds[tc] }));
  const result = verify(planDoc, docsFor(planDoc, entries));
  assert.deepStrictEqual(result.keep.map((k) => k.tc), ['T1']);
  assert.deepStrictEqual(result.rerun.map((r) => r.tc).sort(), ['T2', 'T3', 'T4']);
  assert.ok(result.warnings.some((w) => /T3: BLOCKED without blocked_kind "other"/.test(w)));
});

test('verify: a worker SKIP is not trusted', () => {
  const planDoc = small(2, free(2));
  const entries = entriesFor(planDoc, (tc, i) => entry(tc, 'SKIP', i, i + 1));
  const result = verify(planDoc, docsFor(planDoc, entries));
  assert.deepStrictEqual(result.rerun.map((r) => r.reason), ['skip-by-worker', 'skip-by-worker']);
});

test('verify: a verdict needs screenshots that exist and were taken during the TC', () => {
  const planDoc = small(2, free(5));
  const shots = { T1: [], T2: undefined, T3: ['missing.png'], T4: ['stale.png'], T5: ['fresh.png'] };
  const modified = { 'fresh.png': Date.now(), 'stale.png': T0 - 86400000 };
  const stat = (p) => (p in modified ? modified[p] : null);
  const entries = entriesFor(planDoc, (tc, i) => entry(tc, 'PASS', i, i + 1, { screenshots: shots[tc] }));
  const result = verify(planDoc, docsFor(planDoc, entries), { stat });
  assert.deepStrictEqual(result.rerun.map((r) => r.tc).sort(), ['T1', 'T2', 'T3', 'T4']);
  assert.ok(result.rerun.every((r) => r.reason === 'no-evidence'));
  assert.deepStrictEqual(result.keep.map((k) => k.tc), ['T5']);
});

test('verify: a missing result or a result from the wrong worker needs a solo run', () => {
  const planDoc = small(2, free(2));
  const [w1, w2] = planDoc.workers;
  const result = verify(planDoc, [
    { worker: w1.worker, entries: [entry(w1.tcs[0], 'PASS', 0, 1), entry(w2.tcs[0], 'PASS', 0, 1)] },
    { worker: w2.worker, entries: [] },
  ]);
  assert.deepStrictEqual(result.keep.map((k) => k.tc), [w1.tcs[0]]);
  assert.deepStrictEqual(result.rerun, [{ tc: w2.tcs[0], worker: w2.worker, reason: 'no-result' }]);
  assert.ok(result.warnings.some((w) => /assigned to worker/.test(w)));
});

test('verify: a file older than the plan is a leftover of an earlier run and is ignored', () => {
  const planDoc = Object.assign(small(2, free(2)), { created_at: at(10) });
  const entries = entriesFor(planDoc, (tc, i) => entry(tc, 'PASS', i, i + 1));
  const docs = docsFor(planDoc, entries).map((d, i) => Object.assign(d, { mtimeMs: T0 + (i === 0 ? 1 : 11) * 60000 }));
  const result = verify(planDoc, docs);
  assert.deepStrictEqual(result.keep.map((k) => k.tc), planDoc.workers[1].tcs);
  assert.deepStrictEqual(result.rerun.map((r) => r.reason), ['no-result']);
  assert.ok(result.warnings.some((w) => /older than the plan/.test(w)));
});

function overlapPlan() {
  return small(2, [
    { id: 'READER', class: 'free', lists: ['Customer'] },
    { id: 'WRITER', class: 'free', writes: ['customer'] },
    { id: 'OTHER', class: 'free', writes: ['Invoice'] },
    { id: 'FILLER', class: 'free' },
  ]);
}
const workerOf = (planDoc, tc) => planDoc.workers.find((w) => w.tcs.includes(tc)).worker;
function overlapEntries(planDoc, reader, writer) {
  const entries = {};
  for (const w of planDoc.workers) entries[w.worker] = [];
  if (reader) entries[workerOf(planDoc, 'READER')].push(reader);
  if (writer) entries[workerOf(planDoc, 'WRITER')].push(writer);
  return entries;
}

test('verify: a pass is run again when another worker was writing what it reads at the same time', () => {
  const planDoc = overlapPlan();
  assert.notStrictEqual(workerOf(planDoc, 'READER'), workerOf(planDoc, 'WRITER'));
  const result = verify(planDoc, docsFor(planDoc, overlapEntries(planDoc, entry('READER', 'PASS', 0, 5), entry('WRITER', 'PASS', 3, 8))));
  const reader = result.rerun.find((r) => r.tc === 'READER');
  assert.ok(reader && /^overlap:WRITER/.test(reader.reason), JSON.stringify(result.rerun));
  assert.ok(result.keep.some((k) => k.tc === 'WRITER'), 'the writer itself reads nothing shared and stands');
});

test('verify: a pass that starts soon after the writer finished is still run again (index lag), a late one is not', () => {
  const planDoc = overlapPlan();
  const soon = verify(planDoc, docsFor(planDoc, overlapEntries(planDoc, entry('READER', 'PASS', 5.5, 8), entry('WRITER', 'PASS', 0, 5))));
  assert.ok(soon.rerun.some((r) => r.tc === 'READER'), 'started 30 s after the writer ended');
  const late = verify(planDoc, docsFor(planDoc, overlapEntries(planDoc, entry('READER', 'PASS', 10, 12), entry('WRITER', 'PASS', 0, 5))));
  assert.ok(late.keep.some((k) => k.tc === 'READER'), 'started 5 minutes after the writer ended');
  const early = verify(planDoc, docsFor(planDoc, overlapEntries(planDoc, entry('READER', 'PASS', 0, 5), entry('WRITER', 'PASS', 6, 9))));
  assert.ok(early.keep.some((k) => k.tc === 'READER'), 'finished before the writer began');
});

test('verify: no shared data keeps the pass even when the times overlap', () => {
  const planDoc = overlapPlan();
  const entries = {};
  for (const w of planDoc.workers) entries[w.worker] = [];
  entries[workerOf(planDoc, 'READER')].push(entry('READER', 'PASS', 0, 5));
  entries[workerOf(planDoc, 'OTHER')].push(entry('OTHER', 'PASS', 1, 4));
  if (workerOf(planDoc, 'OTHER') !== workerOf(planDoc, 'READER')) {
    assert.ok(verify(planDoc, docsFor(planDoc, entries)).keep.some((k) => k.tc === 'READER'));
  }
});

test('verify: missing timestamps are treated as overlapping', () => {
  const planDoc = overlapPlan();
  const result = verify(planDoc, docsFor(planDoc, overlapEntries(planDoc, Object.assign(entry('READER', 'PASS', 0, 1), { start: undefined }), entry('WRITER', 'PASS', 50, 60))));
  assert.ok(result.rerun.some((r) => r.tc === 'READER' && /time unknown/.test(r.reason)));
});

test('verify: a writer that never ran does not force a re-run, one that left no result at all does', () => {
  const planDoc = overlapPlan();
  const reader = entry('READER', 'PASS', 0, 5);
  const unrun = verify(planDoc, docsFor(planDoc, overlapEntries(planDoc, reader, { tc: 'WRITER', verdict: 'UNRUN', reason: 'budget' })));
  assert.ok(unrun.keep.some((k) => k.tc === 'READER'), 'UNRUN wrote nothing');
  const crashed = verify(planDoc, docsFor(planDoc, overlapEntries(planDoc, reader, null)));
  assert.ok(crashed.rerun.some((r) => r.tc === 'READER' && /^overlap:WRITER/.test(r.reason)), 'a crashed worker may have written');
});

test('verify: a TC run again alone brings the TCs it depends on with it', () => {
  const planDoc = small(2, [
    { id: 'T1', class: 'free' },
    { id: 'T2', class: 'free', depends_on: ['T1'] },
    { id: 'T3', class: 'free' },
  ]);
  const verdicts = { T1: 'PASS', T2: 'FAIL', T3: 'PASS' };
  const entries = entriesFor(planDoc, (tc, i) => entry(tc, verdicts[tc], i, i + 1));
  const result = verify(planDoc, docsFor(planDoc, entries));
  assert.deepStrictEqual(result.rerun.map((r) => r.tc).sort(), ['T1', 'T2']);
  assert.strictEqual(result.rerun.find((r) => r.tc === 'T1').reason, 'dependency-of:T2');
  assert.ok(result.serial_queue.indexOf('T1') < result.serial_queue.indexOf('T2'));
  assert.deepStrictEqual(result.keep.map((k) => k.tc), ['T3']);
});

test('verify: the solo queue is High risk first and keeps dependencies ahead of dependents', () => {
  const planDoc = small(2, [
    { id: 'T1', class: 'free', risk: 'Low' },
    { id: 'T2', class: 'free', risk: 'High', depends_on: ['T3'] },
    { id: 'T3', class: 'free', risk: 'Low' },
    { id: 'T4', class: 'serial', risk: 'Medium' },
    { id: 'T5', class: 'free', risk: 'Medium' },
  ]);
  const entries = entriesFor(planDoc, (tc, i) => entry(tc, 'FAIL', i, i + 1));
  const queue = verify(planDoc, docsFor(planDoc, entries)).serial_queue;
  assert.ok(queue.indexOf('T3') < queue.indexOf('T2'), queue.join(','));
  assert.ok(queue.indexOf('T4') < queue.indexOf('T1'), 'Medium before Low');
  assert.strictEqual(new Set(queue).size, queue.length);
  assert.strictEqual(queue.length, 5);
});

test('verify: rejects a plan or worker data it cannot read', () => {
  assert.throws(() => verify({}, []), InputError);
  const planDoc = small(2, free(2));
  assert.throws(() => verify(planDoc, [{ worker: 1, entries: {} }]), /JSON array/);
  assert.throws(() => verify(plan(exampleInput(1)), []), /sequential plan/);
});

// ---- surviving a context compaction ---------------------------------------

function withRunDir(fn) {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'parallel-run-'));
  try { return fn(dir); } finally { fs.rmSync(dir, { recursive: true, force: true }); }
}
function writeJson(dir, name, value, when) {
  const file = path.join(dir, name);
  fs.writeFileSync(file, JSON.stringify(value));
  if (when) fs.utimesSync(file, when, when);
  return file;
}
const stamped = (secondsAgo) => Object.assign(plan(exampleInput(3)), { created_at: new Date(Date.now() - secondsAgo * 1000).toISOString() });

test('status: works out where a run stands from the files alone, step by step', () => withRunDir((dir) => {
  assert.strictEqual(status(dir).next, 'plan', 'an empty folder means nothing was planned');
  const planDoc = stamped(60);
  writeJson(dir, 'plan.json', planDoc);
  assert.strictEqual(status(dir).next, 'dispatch');

  writeJson(dir, 'worker-1.json', [entry(planDoc.workers[0].tcs[0], 'PASS', 0, 1)]);
  const midway = status(dir);
  assert.strictEqual(midway.next, 'verify');
  assert.strictEqual(midway.workers[0].done, 1);
  assert.strictEqual(midway.workers[0].pending.length, 11);
  assert.strictEqual(midway.workers[1].file, 'missing');

  writeJson(dir, 'verify.json', { keep: [], rerun: [], serial_queue: ['TC_05', 'TC_12'] });
  const solo = status(dir);
  assert.deepStrictEqual([solo.next, solo.solo.pending], ['solo', ['TC_05', 'TC_12']]);
  writeJson(dir, 'solo-results.json', [{ tc: 'TC_05', verdict: 'PASS' }]);
  assert.deepStrictEqual(status(dir).solo.pending, ['TC_12']);
  writeJson(dir, 'solo-results.json', [{ tc: 'TC_05' }, { tc: 'TC_12' }]);
  assert.strictEqual(status(dir).next, 'merge');

  setState(dir, ['phase=merged']);
  assert.strictEqual(status(dir).next, 'post', 'merged is not finished: the post and the flag teardown are left');
  setState(dir, ['phase=done']);
  assert.strictEqual(status(dir).next, 'done');
  assert.ok(Number.isFinite(status(dir).plan.age_minutes), 'the age of the plan is reported');
}));

test('status: a worker file left by an earlier run does not count', () => withRunDir((dir) => {
  const planDoc = stamped(60);
  writeJson(dir, 'plan.json', planDoc);
  writeJson(dir, 'worker-1.json', [entry(planDoc.workers[0].tcs[0], 'PASS', 0, 1)], new Date('2020-01-01'));
  writeJson(dir, 'verify.json', { keep: [], rerun: [], serial_queue: ['TC_05'] }, new Date('2020-01-01'));
  const result = status(dir);
  assert.strictEqual(result.workers[0].file, 'stale');
  assert.strictEqual(result.next, 'dispatch', 'neither the old worker file nor the old verify.json moves the run forward');
}));

test('status: a run marked dispatched goes to verify even when no worker wrote anything', () => withRunDir((dir) => {
  writeJson(dir, 'plan.json', stamped(60));
  setState(dir, ['phase=dispatched']);
  assert.strictEqual(status(dir).next, 'verify');
}));

test('status: flags that still have to be enabled are called out until the state says they are', () => withRunDir((dir) => {
  writeJson(dir, 'plan.json', stamped(60));
  writeJson(dir, 'verify.json', { keep: [], rerun: [], serial_queue: ['TC_05', 'TC_12'] });
  setState(dir, ['flags_to_enable=["new.flag"]', 'flags_enabled=false']);
  writeJson(dir, 'solo-results.json', [{ tc: 'TC_05', verdict: 'PASS' }]);
  const result = status(dir);
  assert.deepStrictEqual(result.solo.pending, ['TC_12']);
  assert.ok(result.notes.some((n) => /enable the flags/.test(n)));
  setState(dir, ['flags_enabled=true']);
  assert.ok(!status(dir).notes.some((n) => /enable the flags/.test(n)));
}));

test('status: what a finished earlier run left behind never makes a new run look done', () => withRunDir((dir) => {
  const old = new Date('2020-01-01');
  setState(dir, ['phase=merged']);
  fs.utimesSync(path.join(dir, 'state.json'), old, old);
  writeJson(dir, 'solo-results.json', [{ tc: 'TC_05' }, { tc: 'TC_12' }], old);
  writeJson(dir, 'plan.json', stamped(60));
  assert.notStrictEqual(status(dir).next, 'done', 'an old state.json that says merged');
  writeJson(dir, 'verify.json', { keep: [], rerun: [], serial_queue: ['TC_05', 'TC_12'] });
  const result = status(dir);
  assert.strictEqual(result.next, 'solo', 'an old solo-results.json must not count as progress');
  assert.deepStrictEqual(result.solo.pending, ['TC_05', 'TC_12']);
  assert.ok(result.notes.some((n) => /state.json is older than the plan/.test(n)));
  assert.ok(result.notes.some((n) => /solo-results.json is older than the plan/.test(n)));
}));

test('status: a plan that fell back to a sequential run says so instead of asking for a new plan', () => withRunDir((dir) => {
  writeJson(dir, 'plan.json', Object.assign(plan(exampleInput(1)), { created_at: new Date().toISOString() }));
  const result = status(dir);
  assert.strictEqual(result.next, 'sequential');
  assert.match(result.why, /fewer than 2 workers/);
  assert.strictEqual(result.solo.pending.length, 30);

  writeJson(dir, 'solo-results.json', [{ tc: 'TC_01', verdict: 'PASS' }, { tc: 'TC_02', verdict: 'RUNNING' }, { tc_id: 'TC_03' }]);
  const later = status(dir);
  assert.strictEqual(later.solo.done, 1, 'only finished TCs count, so a resume skips TC_01 alone');
  assert.ok(later.solo.pending.includes('TC_02') && later.solo.pending.includes('TC_03'));
  assert.deepStrictEqual(later.solo.interrupted, ['TC_02']);
  assert.ok(later.notes.some((n) => /TC_02 was running when the session ended/.test(n)));
  assert.ok(later.notes.some((n) => /without a "tc" key/.test(n)));
}));

test('state: refuses values the rest of the procedure would trip over', () => withRunDir((dir) => {
  const real = writeJson(dir, 'storage-state.json', {});
  assert.throws(() => setState(dir, ['workers=["mcp__x__"]']), /state "workers" must be/);
  assert.throws(() => setState(dir, ['flags_to_enable=new.flag']), /must be a JSON list/);
  assert.throws(() => setState(dir, ['flags_enabled=yes']), /true or false/);
  assert.throws(() => setState(dir, ['deadline=tomorrow']), /an ISO time/);
  assert.throws(() => setState(dir, ['base_url=mqa-dev']), /http\(s\) URL/);
  assert.throws(() => setState(dir, ['options=[1]']), /a JSON object/);
  assert.throws(() => setState(dir, ['storage_state=C:Usersv.chauhanstorage-state.json']), /file that exists/);
  const ok = setState(dir, [
    'workers=[{"worker":1,"prefix":"mcp__plugin_qa-engineer_playwright__"}]', 'flags_to_enable=[]', 'flags_enabled=false',
    'deadline=2026-10-19T12:00:00Z', 'base_url=https://mqa-dev.maxxton.net', 'options={"max_tcs":10}', 'storage_state=' + real, 'free_text=anything goes',
  ]);
  assert.strictEqual(ok.options.max_tcs, 10);
  assert.strictEqual(ok.free_text, 'anything goes', 'keys the script does not know are stored as given');
  assert.ok(!fs.existsSync(path.join(dir, 'state.json.tmp')));
}));

test('state: merges keys, reads JSON values, leaves no temp file and survives a damaged file', () => withRunDir((dir) => {
  const first = setState(dir, ['phase=planned', 'workers=[{"worker":1,"prefix":"mcp__x__"}]', 'deadline=2026-10-19T12:00:00Z', 'flags_enabled=false']);
  assert.strictEqual(first.phase, 'planned');
  assert.deepStrictEqual(first.workers, [{ worker: 1, prefix: 'mcp__x__' }]);
  assert.strictEqual(first.flags_enabled, false);
  const second = setState(dir, ['phase=dispatched']);
  assert.strictEqual(second.phase, 'dispatched');
  assert.strictEqual(second.deadline, '2026-10-19T12:00:00Z', 'earlier keys stay');
  assert.deepStrictEqual(fs.readdirSync(dir), ['state.json']);
  assert.deepStrictEqual(setState(dir, []).phase, 'dispatched', 'no pairs only reads');
  fs.writeFileSync(path.join(dir, 'state.json'), '{ damaged');
  assert.strictEqual(setState(dir, ['phase=planned']).phase, 'planned');
  assert.throws(() => setState(dir, ['novalue']), /key=value/);
}));

// ---- a switched setting, and the last completeness check ---------------------

test('verify: a PASS whose notes say the TC switched a saved setting is run again alone', () => {
  const planDoc = small(2, free(5));
  const notes = {
    T1: 'Same 2 accommodations stayed selected after switching Table to Cards',
    T2: 'Cards toolbar shows Add filters, search box and Add accommodation; no Change location',
    T3: 'The table is unchanged and shows no Cards/Table toggle',
    T4: 'ok',
    T5: 'ok',
  };
  const entries = entriesFor(planDoc, (tc, i) => entry(tc, 'PASS', i, i + 1, { reason: notes[tc], user_setting_write: tc === 'T4' ? true : undefined }));
  const result = verify(planDoc, docsFor(planDoc, entries));
  assert.deepStrictEqual(result.rerun.map((r) => r.tc).sort(), ['T1', 'T4']);
  assert.match(result.rerun.find((r) => r.tc === 'T1').reason, /^user-setting:.*switching Table/);
  assert.strictEqual(result.rerun.find((r) => r.tc === 'T4').reason, 'user-setting', 'the worker said so with the flag');
  assert.deepStrictEqual(result.keep.map((k) => k.tc).sort(), ['T2', 'T3', 'T5']);
  assert.strictEqual(result.summary.by_reason['user-setting'], 2);
  assert.ok(result.serial_queue.includes('T1') && result.serial_queue.includes('T4'));
});

test('verify: only a real switch of a saved setting sends a PASS to the solo run (notes from a real run)', () => {
  const flagged = [
    'switching Cards to Table Selected cards 161 and 160 in Cards',
    'switched to Table',
    'Switching to Table view',
    'switching Table to Cards In Table view',
    'changed the language to Dutch and back',
    'set the default view to Table',
  ];
  const harmless = [
    'toggle, filter',
    'toggle, Add accommodation, Add filters',
    'toggle was already active (saved view',
    'toggle, no cards On the Overview tab the accommodations table',
    'switching the filter to Complete gave 0 cards',
    'toggle: Table, Add accommodation, Add filters',
    'Cards toolbar shows Add filters, search box and Add accommodation; no Change location',
  ];
  const planDoc = small(2, free(flagged.length + harmless.length));
  const all = flagged.concat(harmless);
  const entries = entriesFor(planDoc, (tc, i) => entry(tc, 'PASS', i, i + 1, { reason: all[Number(tc.slice(1)) - 1] }));
  const result = verify(planDoc, docsFor(planDoc, entries));
  const rerun = new Set(result.rerun.map((r) => r.tc));
  flagged.forEach((_, i) => assert.ok(rerun.has('T' + (i + 1)), 'should go solo: ' + flagged[i]));
  harmless.forEach((_, i) => assert.ok(!rerun.has('T' + (flagged.length + i + 1)), 'should stay: ' + harmless[i]));
});

test('verify: a TC that is neither kept nor run again goes to the solo run', () => {
  const planDoc = small(2, free(4));
  const entries = entriesFor(planDoc, (tc, i) => entry(tc, 'PASS', i, i + 1));
  const result = verify(planDoc, docsFor(planDoc, entries));
  const accounted = new Set(result.keep.map((k) => k.tc).concat(result.rerun.map((r) => r.tc)));
  assert.deepStrictEqual(Array.from(accounted).sort(), ['T1', 'T2', 'T3', 'T4'], 'every assigned TC is accounted for');
});

test('merge-check: every TC of the plan needs one final verdict', () => {
  const planDoc = small(2, free(6));
  const verifyDoc = { keep: [{ tc: 'T1' }, { tc: 'T2' }, { tc: 'T3' }] };

  const gaps = mergeCheck(planDoc, verifyDoc, [{ tc: 'T4', verdict: 'PASS' }, { tc: 'T5', verdict: 'RUNNING' }]);
  assert.strictEqual(gaps.ok, false);
  assert.deepStrictEqual(gaps.missing, ['T5', 'T6']);
  assert.deepStrictEqual(gaps.not_final, ['T5'], 'a solo entry still RUNNING is not a verdict');
  assert.strictEqual(gaps.final, 4);
  assert.strictEqual(gaps.expected, 6);

  const solo = [{ tc: 'T4', verdict: 'PASS' }, { tc: 'T5', verdict: 'FAIL' }, { tc: 'T6', verdict: '✅ PASS' }];
  assert.strictEqual(mergeCheck(planDoc, verifyDoc, solo).ok, true);
  assert.deepStrictEqual(mergeCheck(planDoc, verifyDoc, solo.concat({ tc: 'T1', verdict: 'FAIL' })).in_both, ['T1'], 'a re-run of a kept TC is reported, not an error');

  const stray = mergeCheck(planDoc, verifyDoc, solo.concat({ tc: 'T99', verdict: 'PASS' }));
  assert.strictEqual(stray.ok, false);
  assert.deepStrictEqual(stray.extra, ['T99']);

  assert.deepStrictEqual(mergeCheck(planDoc, { keep: [] }, undefined).missing, ['T1', 'T2', 'T3', 'T4', 'T5', 'T6']);
  assert.throws(() => mergeCheck(planDoc, {}, []), /no "keep" list/);
});

test('cli: merge-check prints the gaps and exits 3 when a TC has no final verdict', () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'parallel-split-'));
  try {
    const planDoc = small(2, free(4));
    const planFile = writeJson(dir, 'plan.json', planDoc);
    const soloFile = writeJson(dir, 'solo-results.json', [{ tc: 'T4', verdict: 'PASS' }]);
    const gaps = cli(['merge-check', planFile, writeJson(dir, 'verify-gaps.json', { keep: [{ tc: 'T1' }] }), soloFile]);
    assert.strictEqual(gaps.code, 3);
    assert.deepStrictEqual(JSON.parse(gaps.out).missing, ['T2', 'T3']);
    const whole = cli(['merge-check', planFile, writeJson(dir, 'verify-all.json', { keep: [{ tc: 'T1' }, { tc: 'T2' }, { tc: 'T3' }] }), soloFile]);
    assert.strictEqual(whole.code, 0, whole.err);
    assert.strictEqual(JSON.parse(whole.out).ok, true);
  } finally {
    fs.rmSync(dir, { recursive: true, force: true });
  }
});

// ---- the live table ---------------------------------------------------------

test('progress: one row per finished TC in the Step 3h format, oldest first, with the pending count', () => {
  const planDoc = small(2, free(4));
  const [w1, w2] = planDoc.workers;
  const entries = {
    [w1.worker]: [entry(w1.tcs[0], 'PASS', 0, 2), entry(w1.tcs[1], 'FAIL', 2, 5, { reason: 'Arrival and departure dates are one combined range text, not separate fields' })],
    [w2.worker]: [entry(w2.tcs[0], 'PASS', 1, 3), entry(w1.tcs[0], 'FAIL', 0, 1)],
  };
  const rows = progressRows(planDoc, docsFor(planDoc, entries));
  assert.deepStrictEqual(rows.map((r) => r.tc), [w1.tcs[0], w2.tcs[0], w1.tcs[1]], 'finished order, and a TC reported by the wrong worker is ignored');
  assert.strictEqual(formatProgressRow(rows[0], 3), '| ' + w1.tcs[0] + ' | ' + w1.worker + ' | PASS ✅ | 2m | 3 |');
  assert.strictEqual(
    formatProgressRow(rows[2], 1),
    '| ' + w1.tcs[1] + ' | ' + w1.worker + ' | FAIL ❌ | 3m | 1 |\n↳ Arrival and departure dates are one combined range text, not separate fields',
  );
  assert.match(formatProgressRow({ tc: 'T9', worker: 2, verdict: 'PASS', seconds: 45, reason: '' }, 0), /\| 45s \|/);
  assert.match(formatProgressRow({ tc: 'T9', worker: 2, verdict: 'PASS', seconds: 130, reason: '' }, 0), /\| 2m 10s \|/, 'same shape as run-timing.js tc-end');
  assert.match(formatProgressRow({ tc: 'T9', worker: 2, verdict: 'PASS', seconds: 3900, reason: '' }, 0), /\| 1h 5m \|/);
  assert.match(formatProgressRow({ tc: 'T9', worker: 2, verdict: 'PASS', seconds: NaN, reason: '' }, 0), /\| — \|/, 'no usable times');
});

test('cli: progress prints the header once and a row per finished TC', () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'parallel-split-'));
  try {
    const planDoc = small(2, free(4));
    writeJson(dir, 'plan.json', planDoc);
    const [w1, w2] = planDoc.workers;
    writeJson(dir, 'worker-' + w1.worker + '.json', [entry(w1.tcs[0], 'PASS', 0, 1)]);
    writeJson(dir, 'worker-' + w2.worker + '.json', [entry(w2.tcs[0], 'BLOCKED 🚫', 0, 2, { reason: 'no data' })]);
    const r = cli(['progress', dir]);
    assert.strictEqual(r.code, 0, r.err);
    const lines = r.out.trim().split('\n');
    assert.strictEqual(lines[0], '| TC | Worker | Result | Time taken | Pending |');
    assert.strictEqual(r.out.split('| TC | Worker |').length - 1, 1, 'the header is printed once');
    assert.ok(lines.some((l) => l.includes('PASS ✅') && l.endsWith('| 3 |')), r.out);
    assert.ok(lines.some((l) => l.includes('BLOCKED 🚫') && l.endsWith('| 2 |')), r.out);
    assert.ok(lines.includes('↳ no data'));
  } finally {
    fs.rmSync(dir, { recursive: true, force: true });
  }
});

// ---- user_scoped TCs and a second login -----------------------------------

test('plan: user_scoped TCs run alone on one login and split once the workers have their own users', () => {
  const lane = Array.from({ length: 17 }, (_, i) => ({ id: id(i + 1), class: 'user_scoped', keys: ['reservation:1842049'] }));
  const reads = Array.from({ length: 38 }, (_, i) => ({ id: id(i + 18), class: 'user_scoped' }));
  const tcs = [...lane, ...reads];

  const oneLogin = plan({ max_workers: 2, tcs });
  assert.strictEqual(oneLogin.mode, 'serial');
  assert.strictEqual(oneLogin.separate_users, false);
  assert.strictEqual(oneLogin.user_scoped.length, 55);
  assert.strictEqual(oneLogin.second_login.would_split, true, 'the result says what a second login would give');
  assert.deepStrictEqual(oneLogin.second_login.workers.map((w) => w.load), [28, 27]);
  assert.strictEqual(oneLogin.second_login.estimate.total, 29);
  assert.strictEqual(oneLogin.second_login.estimate.serial_baseline, 55);

  const twoLogins = plan({ max_workers: 2, separate_users: true, tcs });
  assert.strictEqual(twoLogins.mode, 'parallel');
  assert.strictEqual(twoLogins.separate_users, true);
  assert.deepStrictEqual(twoLogins.workers.map((w) => w.load), [28, 27]);
  assert.deepStrictEqual(tcsOf(twoLogins, 1).slice(0, 17), lane.map((t) => t.id), 'a keyed lane stays together, in order');
  assert.deepStrictEqual(twoLogins.serial, []);
  assert.strictEqual(twoLogins.second_login, undefined, 'no hint once the second login is there');
  assert.strictEqual(plan({ max_workers: 2, separate_users: true, tcs }, { separateUsers: false }).mode, 'serial', 'an option typed on the command line wins over the input');
});

test('plan: no second_login hint when a second login would not help', () => {
  const plain = (n, cls) => Array.from({ length: n }, (_, i) => ({ id: id(i + 1), class: cls }));
  const tooFew = plan({ max_workers: 2, tcs: plain(6, 'user_scoped') });
  assert.strictEqual(tooFew.mode, 'serial');
  assert.strictEqual(tooFew.second_login, undefined, 'under 8 TCs stays sequential either way');
  const flagsAndPermissions = plan({ max_workers: 2, tcs: plain(20, 'serial') });
  assert.strictEqual(flagsAndPermissions.mode, 'serial');
  assert.strictEqual(flagsAndPermissions.second_login, undefined, 'serial TCs that are not user_scoped are not helped by a second user');
  assert.deepStrictEqual(flagsAndPermissions.user_scoped, []);
  assert.strictEqual(plan({ max_workers: 1, tcs: plain(30, 'user_scoped') }).second_login, undefined, 'a single browser stays sequential');
});

test('plan: a user_scoped TC next to ordinary ones only holds itself back', () => {
  const tcs = [
    ...Array.from({ length: 8 }, (_, i) => ({ id: id(i + 1), class: 'free' })),
    { id: id(9), class: 'user_scoped' }, { id: id(10), class: 'user_scoped' },
  ];
  const oneLogin = plan({ max_workers: 2, tcs });
  assert.strictEqual(oneLogin.mode, 'parallel');
  assert.deepStrictEqual(oneLogin.serial, [id(9), id(10)], 'they run alone after the parallel phase');
  assert.deepStrictEqual(oneLogin.user_scoped, [id(9), id(10)]);
  const twoLogins = plan({ max_workers: 2, separate_users: true, tcs });
  assert.deepStrictEqual(twoLogins.serial, []);
  assert.strictEqual(twoLogins.workers.reduce((sum, w) => sum + w.load, 0), 10);
});

test('state: the second login keys are checked', () => withRunDir((dir) => {
  assert.throws(() => setState(dir, ['worker2_url=rvp-dev']), /http\(s\) URL/);
  assert.throws(() => setState(dir, ['separate_users=maybe']), /true or false/);
  const ok = setState(dir, ['worker2_url=https://rvp-dev.maxxton.net/home/en-us/', 'separate_users=true']);
  assert.strictEqual(ok.separate_users, true);
  assert.strictEqual(ok.worker2_url, 'https://rvp-dev.maxxton.net/home/en-us/');
}));

// ---- command line ---------------------------------------------------------

function cli(args) {
  const r = spawnSync(process.execPath, [SCRIPT, ...args], { encoding: 'utf8' });
  return { code: r.status, out: r.stdout, err: r.stderr };
}

test('cli: plan then verify round trip, a missing or stale worker file is not fatal, bad input exits 2', () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'parallel-split-'));
  const shot = path.join(dir, 'shot.png');
  fs.writeFileSync(shot, 'x');
  try {
    const input = path.join(dir, 'input.json');
    fs.writeFileSync(input, JSON.stringify(exampleInput(3)));
    const planned = cli(['plan', input, '--workers=2']);
    assert.strictEqual(planned.code, 0, planned.err);
    const planDoc = JSON.parse(planned.out);
    assert.strictEqual(planDoc.workers.length, 2);
    assert.ok(Number.isFinite(Date.parse(planDoc.created_at)), 'the plan is stamped');

    const planFile = path.join(dir, 'plan.json');
    fs.writeFileSync(planFile, planned.out);
    const files = planDoc.workers.map((w) => {
      const file = path.join(dir, 'worker-' + w.worker + '.json');
      fs.writeFileSync(file, JSON.stringify(w.tcs.map((tc, i) => entry(tc, 'PASS', i, i + 1, { screenshots: [shot] }))));
      return file;
    });
    const checked = cli(['verify', planFile, ...files]);
    assert.strictEqual(checked.code, 0, checked.err);
    assert.strictEqual(JSON.parse(checked.out).summary.rerun, 0);

    const noShot = cli(['verify', planFile, files[0]]);
    assert.strictEqual(noShot.code, 0, 'a worker that wrote no file is not an error');
    assert.strictEqual(JSON.parse(noShot.out).summary.by_reason['no-result'], planDoc.workers[1].tcs.length);

    const none = cli(['verify', planFile]);
    assert.strictEqual(none.code, 0, none.err);
    assert.strictEqual(JSON.parse(none.out).summary.kept, 0);

    fs.writeFileSync(files[1], '[ truncated');
    const broken = cli(['verify', planFile, ...files]);
    assert.strictEqual(broken.code, 0, broken.err);
    assert.match(JSON.parse(broken.out).warnings.join('\n'), /worker 2: .*unreadable/);

    fs.writeFileSync(files[1], JSON.stringify(planDoc.workers[1].tcs.map((tc, i) => entry(tc, 'PASS', i, i + 1, { screenshots: [shot] }))));
    fs.utimesSync(files[1], new Date('2020-01-01'), new Date('2020-01-01'));
    const stale = cli(['verify', planFile, ...files]);
    assert.match(JSON.parse(stale.out).warnings.join('\n'), /older than the plan/);

    const wrongName = path.join(dir, 'results.json');
    fs.writeFileSync(wrongName, '[]');
    assert.strictEqual(cli(['verify', planFile, wrongName]).code, 2);
    fs.writeFileSync(planFile, '{ not json');
    assert.strictEqual(cli(['verify', planFile]).code, 2);

    fs.writeFileSync(input, '{ not json');
    const bad = cli(['plan', input]);
    assert.strictEqual(bad.code, 2);
    assert.match(bad.err, /cannot read/);
    assert.strictEqual(cli([]).code, 2);
  } finally {
    fs.rmSync(dir, { recursive: true, force: true });
  }
});
