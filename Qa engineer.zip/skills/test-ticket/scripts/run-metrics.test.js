#!/usr/bin/env node
/**
 * Tests for run-metrics.js. Self-contained: node:test + node:assert, temp dirs under os.tmpdir().
 * Run: node plugins/qa-engineer/skills/test-ticket/scripts/run-metrics.test.js
 */
'use strict';

const test = require('node:test');
const assert = require('node:assert');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { spawnSync } = require('child_process');

const SCRIPT = path.join(__dirname, 'run-metrics.js');
const SENTINEL = 'ZZSENTINELZZ-secret-scenario-text';
const tmpRoots = [];

function mkTmp() {
  const d = fs.mkdtempSync(path.join(os.tmpdir(), 'run-metrics-test-'));
  tmpRoots.push(d);
  return d;
}

function run(args, env = {}) {
  const r = spawnSync(process.execPath, [SCRIPT, ...args], {
    encoding: 'utf8',
    env: { ...process.env, QA_ENGINEER_METRICS: '', RUN_METRICS_NOW: '', ...env },
  });
  return { code: r.status, out: r.stdout, err: r.stderr };
}
const at = (iso) => ({ RUN_METRICS_NOW: iso });
const readRec = (dir) => JSON.parse(fs.readFileSync(path.join(dir, 'run-metrics.json'), 'utf8'));

const RESULTS_MD = `# Execution Results — EPIC-1
Generated: 2026-10-14 10:00
Environment: https://acme-dev.maxxton.net/home/en-us/
Build / Version: 1.2.3

| TC_ID | Scenario | Verdict | Reason | Attempts |
|---|---|---|---|---|
| TC_01 | Verify ${SENTINEL} saves | ✅ PASS | Expected element found | 1 |
| TC_02 | Verify list loads | ✅ PASS | Passed on retry, flaky | 2 |
| TC_03 | Verify search for jane@example.com | ❌ FAIL (confirmed, 3/3) | Element missing at https://x.maxxton.net/a | 3 |
| TC_04 | Verify login | 🚫 BLOCKED (Environment unavailable — 503 on navigation) | n/a | 0 |
| TC_05 | Verify other | 🚫 BLOCKED 🚫 (Login dependency failed — session unavailable) | n/a | 0 |
| TC_06 | Verify timeout | 🚫 BLOCKED (timeout — step hung after 120s) | n/a | 1 |
| TC_07 | Verify data | 🚫 BLOCKED (Required test data missing — no reservation exists) | n/a | 0 |
| TC_08 | Verify flag | 🚫 BLOCKED (Feature not deployed in this environment) | n/a | 0 |
| TC_09 | Verify portal | 🚫 BLOCKED (Third-party portal check on Booking.com Extranet) | n/a | 0 |
| TC_10 | Verify budget | 🚫 BLOCKED (run budget exhausted) | n/a | 0 |
| TC_11 | Verify dep | 🚫 BLOCKED (Depends on TC_03 which failed) | n/a | 0 |
| TC_12 | Verify odd | 🚫 BLOCKED (something entirely different) | n/a | 0 |
| TC_13 | Verify review | 🔍 NEEDS REVIEW | Ambiguous result | 1 |
| TC_14 | Verify skip | ⏭️ SKIP | Already automated | 0 |
| TC_15 | Verify perm | 🚫 BLOCKED (Permission missing for role) | n/a | 0 |
`;

function makeRun(root, name, { mode, kind, startIso, endIso, results, events = [] }) {
  const dir = path.join(root, name);
  const first = ['phase', dir, 'preflight'];
  if (kind) first.push(`--kind=${kind}`);
  if (mode) first.push(`--mode=${mode}`);
  run(first, at(startIso));
  const t0 = Date.parse(startIso);
  run(['phase', dir, 'phase3a'], at(new Date(t0 + 60000).toISOString()));
  for (const e of events) run(['event', dir, ...e], at(new Date(t0 + 90000).toISOString()));
  if (results) fs.writeFileSync(path.join(dir, 'results.md'), results);
  run(['finish', dir], at(endIso));
  return dir;
}

test.after(() => { for (const d of tmpRoots) fs.rmSync(d, { recursive: true, force: true }); });

test('phase/event/finish happy path with timing', () => {
  const dir = path.join(mkTmp(), 'MXTS-12345');
  assert.strictEqual(run(['phase', dir, 'preflight', '--kind=execute-tests', '--mode=subagent'], at('2026-10-14T10:00:00.000Z')).code, 0);
  run(['phase', dir, 'preflight'], at('2026-10-14T10:00:05.000Z')); // no-op repeat
  run(['phase', dir, 'phase1'], at('2026-10-14T10:00:30.000Z'));
  run(['event', dir, 'resume_run'], at('2026-10-14T10:00:31.000Z'));
  run(['phase', dir, 'phase3a'], at('2026-10-14T10:02:30.000Z'));
  fs.writeFileSync(path.join(dir, 'run-state.json'), JSON.stringify({
    phase: 'phase3a', jira_write_path: 'mcp', screenshot_upload_enabled: false,
    stories: { 'MXTS-1': { results_comment_id: '99999', labels: ['x'], pause_count: 2, user_wait_seconds: 900 }, 'MXTS-2': { pause_count: 1, user_wait_seconds: 120 } },
    base_url: 'https://secret.maxxton.net', token: 'abcdefghijklmnopqrstuvwxyz0123456789',
  }));
  assert.strictEqual(run(['finish', dir], at('2026-10-14T10:05:00.000Z')).code, 0);

  const rec = readRec(dir);
  assert.strictEqual(rec.schema, 1);
  assert.match(rec.run_id, /^[0-9a-f]{8}$/);
  assert.strictEqual(rec.kind, 'execute-tests');
  assert.strictEqual(rec.execution_mode, 'subagent');
  assert.ok(rec.plugin_version, 'plugin_version read from plugin.json');
  assert.strictEqual(rec.started_at, '2026-10-14T10:00:00.000Z');
  assert.strictEqual(rec.finished_at, '2026-10-14T10:05:00.000Z');
  assert.strictEqual(rec.total_seconds, 300);
  assert.deepStrictEqual(rec.phases.map((p) => [p.name, p.seconds]), [['preflight', 30], ['phase1', 120], ['phase3a', 150]]);
  assert.strictEqual(rec.events.length, 1);
  assert.strictEqual(rec.events[0].code, 'resume_run');
  assert.strictEqual(rec.story_count, 2);
  assert.strictEqual(rec.jira_write_path_is_mcp, true);
  assert.strictEqual(rec.screenshot_upload_enabled, false);
  assert.strictEqual(rec.phase, 'phase3a');
  assert.strictEqual(rec.pause_count, 3, 'pauses are summed over the stories');
  assert.strictEqual(rec.paused_seconds, 1020);
  assert.strictEqual(rec.tcs, undefined, 'no results.md, no tcs');
  const allowed = new Set(['pause_count', 'paused_seconds', 'schema', 'run_id', 'kind', 'execution_mode', 'plugin_version', 'started_at', 'finished_at', 'total_seconds', 'phases', 'events', 'tcs', 'blocked_reasons', 'story_count', 'jira_write_path_is_mcp', 'screenshot_upload_enabled', 'phase']);
  for (const k of Object.keys(rec)) assert.ok(allowed.has(k), `unexpected key ${k}`);
  const raw = fs.readFileSync(path.join(dir, 'run-metrics.json'), 'utf8');
  for (const leak of ['MXTS', 'secret', 'maxxton.net', '99999', 'abcdefghijklmnop']) assert.ok(!raw.includes(leak), `leaked ${leak}`);
  assert.deepStrictEqual(fs.readdirSync(dir).filter((n) => n.endsWith('.tmp')), [], 'no temp file left behind');
});

test('default kind and bad --kind/--mode are handled fail-open', () => {
  const dir = path.join(mkTmp(), 'run');
  const r = run(['phase', dir, 'phase1', '--kind=bogus', '--mode=weird'], at('2026-10-14T10:00:00.000Z'));
  assert.strictEqual(r.code, 0);
  assert.match(r.err, /^\[run-metrics\]/m);
  const rec = readRec(dir);
  assert.strictEqual(rec.kind, 'test-ticket');
  assert.strictEqual(rec.execution_mode, undefined);
  const bad = run(['phase', dir, 'not-a-phase']);
  assert.strictEqual(bad.code, 0);
  assert.match(bad.err, /\[run-metrics\] unknown phase/);
  assert.strictEqual(run([]).code, 0);
  assert.strictEqual(run(['bogus', dir]).code, 0);
});

test('event sanitising: URL, host, email, token, paths, Bearer, Jira key, truncation', () => {
  const dir = path.join(mkTmp(), 'run');
  const evs = [
    ['env_degraded_transient', 'GET https://acme-dev.maxxton.net/home/en-us/ returned 503'],
    ['env_degraded_blocked', 'host acme-dev.maxxton.net and example.com and foo.nl unreachable'],
    ['session_recovery', 'user jane.doe@maxxton.com lost session'],
    ['early_abort', 'token ghp_abcdefghijklmnopqrstuvwxyz0123456789 leaked'],
    ['tc_timeout', 'file C:\\Users\\v.chauhan\\test-output\\MXTS-1\\x.png and /home/dev/secret/file.txt and test-output/EPIC/TC_01.png'],
    ['jira_write_path_mcp', 'Authorization: Bearer eyJhbGciOiJIUzI1NiJ9.payload.sig'],
    ['host_guard_stop', 'sent Bearer abc123 then Cookie: sid=zzz'],
    ['precondition_unconfirmed', 'depends on MXTS-80333 fix, TC_04 only'],
    ['budget_exhausted', 'x'.repeat(10) + ' ' + 'word '.repeat(60)],
  ];
  for (const e of evs) run(['event', dir, ...e]);
  const rec = readRec(dir);
  assert.strictEqual(rec.events.length, evs.length);
  const raw = JSON.stringify(rec);
  for (const leak of ['acme-dev', 'maxxton.net', 'example.com', 'foo.nl', 'jane', 'ghp_', 'v.chauhan', 'secret', 'eyJ', 'abc123', 'sid=zzz', 'MXTS', 'x.png', 'TC_01.png', 'home/en-us']) {
    assert.ok(!raw.includes(leak), `leaked: ${leak}\n${raw}`);
  }
  assert.ok(rec.events[0].detail.includes('[redacted]'));
  assert.ok(rec.events[0].detail.includes('returned 503'), 'harmless text survives');
  assert.ok(rec.events[7].detail.includes('TC_04'), 'TC ids are not secrets');
  assert.ok(rec.events[8].detail.length <= 120);
  for (const e of rec.events) assert.ok(!('detail' in e) || e.detail.length <= 120);
});

test('rejected event code warns on stderr, exits 0, writes nothing', () => {
  const dir = path.join(mkTmp(), 'run');
  const r = run(['event', dir, 'made_up_code', 'detail']);
  assert.strictEqual(r.code, 0);
  assert.match(r.err, /^\[run-metrics\] unknown event code/m);
  assert.ok(!fs.existsSync(path.join(dir, 'run-metrics.json')));
  run(['event', dir, 'resume_run']);
  run(['event', dir, 'nope']);
  assert.strictEqual(readRec(dir).events.length, 1);
});

test('QA_ENGINEER_METRICS=off is a silent no-op (any case)', () => {
  for (const v of ['off', 'OFF', 'Off']) {
    const dir = path.join(mkTmp(), 'run');
    for (const args of [['phase', dir, 'phase1'], ['event', dir, 'resume_run'], ['finish', dir], ['summarize', dir]]) {
      const r = run(args, { QA_ENGINEER_METRICS: v });
      assert.strictEqual(r.code, 0);
      assert.strictEqual(r.out, '');
      assert.strictEqual(r.err, '');
    }
    assert.ok(!fs.existsSync(dir), 'nothing created');
  }
});

test('corrupt run-metrics.json is moved aside and a fresh record started', () => {
  const dir = path.join(mkTmp(), 'run');
  fs.mkdirSync(dir, { recursive: true });
  fs.writeFileSync(path.join(dir, 'run-metrics.json'), '{ not json');
  const r = run(['phase', dir, 'phase1']);
  assert.strictEqual(r.code, 0);
  assert.match(r.err, /^\[run-metrics\] .*corrupt/m);
  assert.strictEqual(fs.readFileSync(path.join(dir, 'run-metrics.json.corrupt'), 'utf8'), '{ not json');
  const rec = readRec(dir);
  assert.strictEqual(rec.phases.length, 1);
  assert.strictEqual(rec.schema, 1);
  // wrong-shape JSON is also treated as corrupt
  fs.writeFileSync(path.join(dir, 'run-metrics.json'), JSON.stringify({ hello: 'world' }));
  assert.strictEqual(run(['event', dir, 'resume_run']).code, 0);
  assert.strictEqual(readRec(dir).events.length, 1);
});

test('unwritable target (a file where the dir should be) fails open', () => {
  const root = mkTmp();
  const blocker = path.join(root, 'blocker');
  fs.writeFileSync(blocker, 'x');
  const r = run(['phase', path.join(blocker, 'sub'), 'phase1']);
  assert.strictEqual(r.code, 0);
  assert.match(r.err, /^\[run-metrics\]/m);
});

test('results.md parsing: counts, blocked buckets, pass rate; no free text leaks', () => {
  const dir = path.join(mkTmp(), 'EPIC-1');
  run(['phase', dir, 'phase3a'], at('2026-10-14T10:00:00.000Z'));
  fs.writeFileSync(path.join(dir, 'results.md'), RESULTS_MD);
  run(['finish', dir], at('2026-10-14T10:10:00.000Z'));
  const rec = readRec(dir);
  assert.deepStrictEqual(rec.tcs, { total: 15, pass: 2, fail: 1, needs_review: 1, blocked: 10, skip: 1, flaky_pass: 1, pass_rate: 0.5 });
  assert.deepStrictEqual(rec.blocked_reasons, {
    environment: 1, session: 1, timeout: 1, test_data_precondition: 1, feature_flag_not_deployed: 1,
    third_party_portal: 1, run_budget: 1, dependency: 1, permission: 1, other: 1,
  });
  const raw = fs.readFileSync(path.join(dir, 'run-metrics.json'), 'utf8');
  for (const leak of [SENTINEL, 'ZZSENTINEL', 'jane@example', 'Booking', 'Extranet', 'reservation', 'Element missing', 'Expected element', 'acme-dev', 'maxxton.net']) {
    assert.ok(!raw.includes(leak), `leaked: ${leak}`);
  }
});

test('results.md: pass_rate is null when nothing was run, and results_*.md files are summed', () => {
  const dir = path.join(mkTmp(), 'EPIC-2');
  run(['phase', dir, 'phase3a']);
  fs.writeFileSync(path.join(dir, 'results.md'), '| TC_ID | Scenario | Verdict | Reason | Attempts |\n|---|---|---|---|---|\n| TC_01 | s | BLOCKED (environment down) | | 0 |\n| TC_02 | s | SKIP | | 0 |\n');
  run(['finish', dir]);
  let rec = readRec(dir);
  assert.strictEqual(rec.tcs.pass_rate, null);
  assert.strictEqual(rec.tcs.total, 2);

  fs.writeFileSync(path.join(dir, 'results_MXTS-9.md'), '| TC_ID | Scenario | Verdict | Reason | Attempts |\n|---|---|---|---|---|\n| TC_01 | s | PASS | ok | 1 |\n| TC_02 | s | FAIL | no | 3 |\n');
  run(['finish', dir]);
  rec = readRec(dir);
  assert.strictEqual(rec.tcs.total, 4);
  assert.strictEqual(rec.tcs.pass_rate, 0.5);
  assert.ok(!JSON.stringify(rec).includes('MXTS-9'), 'file name not stored');
});

test('results.md without a header still parses; BLOCKED reason falls back to the Reason column', () => {
  const dir = path.join(mkTmp(), 'EPIC-3');
  run(['phase', dir, 'phase3a']);
  fs.writeFileSync(path.join(dir, 'results.md'), '| TC_ID | Scenario | Verdict | Reason | Attempts |\n|---|---|---|---|---|\n| TC_01 | Blocked users cannot log in | BLOCKED | session expired | 0 |\n| TC_02 | Skip the intro | PASS | ok | 1 |\n');
  run(['finish', dir]);
  const rec = readRec(dir);
  assert.strictEqual(rec.tcs.blocked, 1);
  assert.strictEqual(rec.tcs.pass, 1);
  assert.strictEqual(rec.tcs.skip, 0, 'scenario words do not count as verdicts');
  assert.deepStrictEqual(rec.blocked_reasons, { session: 1 });
});

test('summarize: two runs, totals, reasons, phase averages, events, execution_mode grouping', () => {
  const root = mkTmp();
  makeRun(root, 'EPIC-A', { mode: 'inline', startIso: '2026-10-14T10:00:00.000Z', endIso: '2026-10-14T10:10:00.000Z', results: RESULTS_MD, events: [['tc_timeout', 'x'], ['resume_run']] });
  makeRun(root, 'EPIC-B', {
    mode: 'subagent', kind: 'execute-tests', startIso: '2026-10-14T11:00:00.000Z', endIso: '2026-10-14T11:05:00.000Z',
    results: '| TC_ID | Scenario | Verdict | Reason | Attempts |\n|---|---|---|---|---|\n| TC_01 | s | PASS | ok | 1 |\n| TC_02 | s | PASS | ok | 1 |\n| TC_03 | s | BLOCKED (Environment unavailable) | | 0 |\n',
    events: [['tc_timeout'], ['early_abort']],
  });

  const r = run(['summarize', root]); // root directory, searched one level deep
  assert.strictEqual(r.code, 0);
  const out = r.out;
  assert.match(out, /^# QA run metrics/m);
  assert.match(out, /2 run\(s\)/);
  assert.match(out, /\| EPIC-A \| test-ticket \| inline \|/);
  assert.match(out, /\| EPIC-B \| execute-tests \| subagent \|/);
  assert.match(out, /TCs: 18 \(pass 4, fail 1, needs review 1, blocked 11, skip 1, flaky pass 1\)/);
  assert.match(out, /BLOCKED rate: 61\.1%/);
  assert.match(out, /Mean run time: 7\.5 min/);
  assert.match(out, /## Top BLOCKED reasons[\s\S]*\| environment \| 2 \|/);
  assert.match(out, /\| preflight \| 60 \| 2 \|/);
  assert.match(out, /\| phase3a \| 390 \| 2 \|/);
  assert.match(out, /## Events[\s\S]*\| tc_timeout \| 2 \|/);
  assert.match(out, /## Execution mode comparison/);
  assert.match(out, /\| inline \| 1 \| 600 \| 10\.0 \|/);
  assert.match(out, /\| subagent \| 1 \| 300 \| 5\.0 \|/);

  // explicit dir + explicit file arguments give the same two runs
  const r2 = run(['summarize', path.join(root, 'EPIC-A'), path.join(root, 'EPIC-B', 'run-metrics.json')]);
  assert.match(r2.out, /2 run\(s\)/);
  // nothing found, and a corrupt file, are both survivable
  assert.strictEqual(run(['summarize', mkTmp()]).code, 0);
  fs.writeFileSync(path.join(root, 'EPIC-B', 'run-metrics.json'), 'garbage');
  const r3 = run(['summarize', root]);
  assert.strictEqual(r3.code, 0);
  assert.match(r3.out, /1 run\(s\)/);
  assert.match(r3.err, /^\[run-metrics\] skipping/m);
});

test('summarize: mode comparison averages several runs per mode', () => {
  const root = mkTmp();
  makeRun(root, 'r1', { mode: 'inline', startIso: '2026-10-14T10:00:00.000Z', endIso: '2026-10-14T10:10:00.000Z' });
  makeRun(root, 'r2', { mode: 'inline', startIso: '2026-10-14T11:00:00.000Z', endIso: '2026-10-14T11:20:00.000Z' });
  makeRun(root, 'r3', { mode: 'subagent', startIso: '2026-10-14T12:00:00.000Z', endIso: '2026-10-14T12:06:00.000Z' });
  makeRun(root, 'r4', { startIso: '2026-10-14T13:00:00.000Z', endIso: '2026-10-14T13:02:00.000Z' });
  const out = run(['summarize', root]).out;
  assert.match(out, /\| inline \| 2 \| 900 \| 15\.0 \|/);
  assert.match(out, /\| subagent \| 1 \| 360 \| 6\.0 \|/);
  assert.match(out, /\| unspecified \| 1 \| 120 \| 2\.0 \|/);
});

test('exported sanitize handles the empty / non-string cases', () => {
  const { sanitize } = require('./run-metrics.js');
  assert.strictEqual(sanitize(undefined), '');
  assert.strictEqual(sanitize(''), '');
  assert.strictEqual(sanitize('plain words only'), 'plain words only');
});

test('human-review: per-story slot, overwrite not double-count, validation, miss rate in summarize', () => {
  const d = mkTmp();
  run(['human-review', d, '1', '12', '4', '2', '1', '0', '1']);
  run(['human-review', d, '1', '12', '4', '2', '1', '0', '1']); // same slot again: must overwrite
  run(['human-review', d, '2', '8', '1', '1', '0', '0', '0']);
  const bad = run(['human-review', d, '3', '5', '9', '1', '1', '1', '1']); // requested != sum
  assert.strictEqual(bad.code, 0);
  assert.match(bad.err, /requested must equal/);
  const neg = run(['human-review', d, '3', '5', '-1', '0', '0', '0', '0']);
  assert.match(neg.err, /usage: human-review/);
  const rec = readRec(d);
  assert.deepStrictEqual(rec.human_review.map(h => h.slot), [1, 2]);
  assert.deepStrictEqual(rec.human_review[0], { slot: 1, generated: 12, requested: 4, accepted: 2, covered: 1, declined: 0, overridden: 1 });
  const s = run(['summarize', d]).out;
  assert.match(s, /## Human review \(how much Claude missed\)/);
  // generated 20; missed = accepted 3 + overridden 1 = 4; total 24 => 16.7%
  assert.match(s, /\| 2 \| 20 \| 5 \| 3 \| 1 \| 0 \| 1 \| 16\.7% \(4\/24\) \|/);
  assert.ok(!JSON.stringify(rec).match(/[A-Z]{2,}-\d+/), 'no Jira key in the record');
});

test('human-review: opt-out is a silent no-op', () => {
  const d = mkTmp();
  const r = run(['human-review', d, '1', '1', '1', '1', '0', '0', '0'], { QA_ENGINEER_METRICS: 'OFF' });
  assert.strictEqual(r.code, 0);
  assert.ok(!fs.existsSync(path.join(d, 'run-metrics.json')));
});

test('pauses: runs without pause data show "-", and summarize totals the pauses of the runs that have it', () => {
  const root = mkTmp();
  const a = path.join(root, 'A'), b = path.join(root, 'B');
  run(['phase', a, 'phase3a'], at('2026-10-14T10:00:00.000Z'));
  fs.writeFileSync(path.join(a, 'run-state.json'), JSON.stringify({ stories: { k1: { pause_count: 2, user_wait_seconds: 600 }, k2: { pause_count: 0, user_wait_seconds: 0 } } }));
  run(['finish', a], at('2026-10-14T10:10:00.000Z'));
  run(['phase', b, 'phase3a'], at('2026-10-14T11:00:00.000Z'));
  fs.writeFileSync(path.join(b, 'run-state.json'), JSON.stringify({ stories: { k1: { results_comment_id: '1' } } }));
  run(['finish', b], at('2026-10-14T11:10:00.000Z'));
  assert.strictEqual(readRec(a).pause_count, 2);
  assert.strictEqual(readRec(b).pause_count, undefined, 'no pause fields in run-state, none in the record');
  const out = run(['summarize', root]).out;
  assert.match(out, /\| Pauses \|/);
  assert.match(out, /- Pauses: 2 across 1 of 1 run\(s\), 10\.0 min paused/);
});

test('bucketOf: a BLOCKED reason from Control Discovery lands in control_not_found whatever places it lists', () => {
  const m = require('./run-metrics');
  assert.strictEqual(m.bucketOf('step "mark the unit Clean" — no matching control; checked: Operations Manager, session menu, permission tab'), 'control_not_found');
  assert.strictEqual(m.bucketOf('step "x" — no matching control found'), 'control_not_found');
  assert.strictEqual(m.bucketOf('Environment unavailable'), 'environment', 'other buckets are unchanged');
});
