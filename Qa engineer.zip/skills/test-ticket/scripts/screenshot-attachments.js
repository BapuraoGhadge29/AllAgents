/**
 * Are the screenshots a wiki-markup results comment shows really attached to the Jira issue?
 *
 * On the script path (Jira token) `!TC_01-slug.png!` renders as an image only when an attachment with that
 * file name exists on the issue; a plain `TC_01-slug.png` is the filename left behind by a failed upload.
 * Either way a screenshot that is not attached is not visible. post-comment.js runs this after every post
 * (and when it finds the comment already posted), so "posted" is never taken to mean "screenshots visible".
 *
 * `<name>-capture-failed.png` entries are plain on purpose (the capture itself failed) and are not counted.
 */
'use strict';

const NAME = /\bTC_\d+-[\w-]+\.(?:png|jpe?g)\b/gi;

function referencedImages(body) {
  const names = (String(body).match(NAME) || []).filter((n) => !/capture-failed/i.test(n));
  return [...new Set(names)];
}

function missingImages(names, attachmentNames) {
  const have = new Set(attachmentNames);
  return names.filter((n) => !have.has(n));
}

async function attachmentNames(issueUrl, headers, fetchFn) {
  const res = await fetchFn(`${issueUrl}?fields=attachment`, { headers });
  if (!res.ok) throw new Error(`GET attachments failed: ${res.status}`);
  const data = await res.json();
  const list = (data && data.fields && data.fields.attachment) || [];
  return list.map((a) => a.filename);
}

/** @returns {Promise<{expected:string[], missing:string[]}>} rejects when Jira cannot be asked */
async function check(body, issueUrl, headers, fetchFn = fetch) {
  const expected = referencedImages(body);
  if (expected.length === 0) return { expected, missing: [] };
  const have = await attachmentNames(issueUrl, headers, fetchFn);
  return { expected, missing: missingImages(expected, have) };
}

/** One stderr-ready line: the outcome of a check, or why it could not run. */
function describe(result, issueKey, commentId) {
  if (result.missing.length === 0) return `Screenshots: ${result.expected.length}/${result.expected.length} attached to ${issueKey}.`;
  const shown = result.missing.slice(0, 5).join(', ') + (result.missing.length > 5 ? ', …' : '');
  return (
    `⚠️  Screenshots: ${result.missing.length} of ${result.expected.length} referenced in comment ${commentId} are not attached to ${issueKey}: ${shown}. ` +
    `Upload them with upload-screenshot.js — the images appear without editing the comment — then run this same command again to check.`
  );
}

module.exports = { referencedImages, missingImages, check, describe };
