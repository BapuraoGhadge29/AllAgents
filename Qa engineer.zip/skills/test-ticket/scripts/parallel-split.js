#!/usr/bin/env node
/**
 * parallel-split.js — shares a ticket's TCs out across parallel browsers and decides which
 * worker verdicts can be trusted. The model labels each TC; this script does the grouping,
 * balancing and result checking so they are deterministic and testable.
 *
 *   node parallel-split.js plan   <input.json> [--max-workers=K] [--workers=N] [--min-tcs=N] [--min-saving=N] [--separate-users]
 *   node parallel-split.js verify <plan.json> [<worker-1.json> <worker-2.json>] [--grace=SECONDS]
 *
 * Both print one JSON document to stdout. Exit 2 = input the script cannot trust (reason on
 * stderr); the caller then runs the TCs one after another.
 * A missing, unreadable or stale worker file is not an error: its TCs simply count as unrun.
 *
 * The number of workers is automatic: up to --max-workers (the browsers that are available, at
 * most 2), and never so many that a worker gets fewer than 4 TCs on average. --workers=N is an
 * override that someone typed: N=1 means sequential, N=2 means two workers at most.
 *
 * plan input:
 *   { "max_workers": 2,
 *     "tcs": [ { "id": "TC_01", "risk": "High|Medium|Low",
 *                "class": "free | keyed | serial | user_scoped",
 *                "keys": ["seed:customer"],     shared records or pools the TC changes or depends on
 *                "writes": ["customer"],         entity types the TC creates or changes
 *                "lists": ["customer"],          entity types whose list, count or availability it reads
 *                "depends_on": ["TC_00"],        TCs whose created data it needs
 *                "weight": 1 } ] }
 *   keys, writes and lists are compared without regard to case; use singular entity type names.
 *
 *   serial  runs alone after the parallel phase (flags, permissions, user preferences, list-wide
 *           assertions, anything unsure). keyed/free TCs that share a key, or depend on each other,
 *           stay together on one worker in their original order. A group holding a serial TC is serial.
 *   user_scoped  runs alone while every worker shares one login, because the TC changes the logged-in user's own
 *           settings (language, saved filters, default view, a saved Card/Table choice) and the setting is kept per
 *           user. When the workers have their own users (--separate-users, or "separate_users": true in the input) it
 *           counts as free, or as keyed when it has keys. When a sequential result is down to such TCs, it carries
 *           `second_login` with the split a second login would give.
 *   The plan falls back to a sequential run (`mode: "serial"`) when it would not pay off: fewer than
 *   8 TCs, fewer than 2 independent groups, or a saving below max(3, 20% of the sequential time).
 *
 * worker file (`worker-<n>.json`, one per worker, n = the worker number):
 *   [ { "tc": "TC_01", "verdict": "PASS|FAIL|NEEDS REVIEW|BLOCKED|SKIP|UNRUN|DEFERRED",
 *       "blocked_kind": "other" (host guard, third-party portal, ticket-level precondition; any other BLOCKED is re-run),
 *       "start": "<ISO>", "end": "<ISO>", "screenshots": ["<path>"], "reason": "..." } ]
 *
 * verify output: `keep` (verdicts that stand), `rerun` (each with the reason it needs a solo run)
 * and `serial_queue` (plan.serial plus every rerun TC, High risk first, dependencies before dependents).
 *
 *   node parallel-split.js progress <parallel dir> [--watch]
 * A live table for the person watching, in the Step 3h format plus the worker: one row per TC a worker has finished
 * (`| TC | Worker | Result | Time taken | Pending |`, a reason line under every verdict but PASS). --watch keeps appending
 * rows every 5 seconds until every worker TC is in. Read-only; run it in a second terminal while the workers work.
 *
 * A PASS whose worker notes say the TC switched a saved per-user setting (a Card/Table view, a language, a filter), or
 * whose entry has "user_setting_write": true, is run again alone (reason `user-setting`): two browsers on one login overwrite it.
 *
 *   node parallel-split.js merge-check <plan.json> <verify.json> [<solo-results.json>]
 * The last check before results are written: every TC of the plan has one final verdict, a kept worker verdict or a
 * finished solo result. Prints `ok`, `missing` (no final verdict yet) and `extra`; exit 3 when not ok.
 *
 * Surviving a context compaction (the coordinator keeps nothing in memory that is not on disk):
 *   node parallel-split.js state  <dir> [key=value ...]       merge keys into <dir>/state.json (values are JSON when they parse)
 *   node parallel-split.js status <dir>                       say where a parallel run stands and what to do next
 *   node parallel-split.js now                                print the current UTC time as an ISO string (no `date` needed)
 * <dir> is the run's parallel folder. status works out `next` (plan | sequential | dispatch | verify | solo | merge | post | done)
 * from the files in it: plan.json, worker-<n>.json, verify.json, solo-results.json, state.json. A file older than
 * plan.json is a leftover of an earlier run and is ignored, so a finished run never makes a new one look done.
 */

'use strict';

const fs = require('fs');
const path = require('path');

const MAX_WORKERS = 2;
const DEFAULT_MIN_TCS = 8;
const MIN_TCS_PER_WORKER = 4;
const GRACE_SECONDS = 120;
const RISK_RANK = { high: 0, medium: 1, low: 2 };
// A worker that switched a saved per-user setting says so in its notes (a Card/Table view, a language, a filter).
// Two browsers on one login overwrite each other there, so such a PASS is run again alone. A false match only costs one solo run.
// The verb has to act on the setting right away ("switching Cards to Table", "switched to Table view"); a noun like "the toggle" or
// "switching the filter" is no switch of a saved setting.
const SETTING_SWITCH_RE = new RegExp(
  '\\b(?:switch(?:es|ed|ing)?|flip(?:s|ped|ping)?|toggl(?:es|ed|ing))\\s+(?:(?:from|to|between)\\s+)?(?:the\\s+)?(?:cards?|table)\\b' +
  '|\\b(?:switch(?:es|ed|ing)?|chang(?:es|ed|ing)|sets?|setting|toggl(?:es|ed|ing))\\s+(?:the\\s+|your\\s+|a\\s+)?(?:\\w+\\s+){0,2}?(?:language|locale|theme|layout|saved\\s+filters?|default\\s+view|view\\s+preference|preferences?)\\b',
  'i',
);
const CLASSES = ['free', 'keyed', 'serial', 'user_scoped'];
const VERDICT_RE = /^[^A-Za-z]*(NEEDS REVIEW|PASS|FAIL|BLOCKED|SKIP|UNRUN|DEFERRED)\b/i;
const NEEDS_EVIDENCE = ['PASS', 'FAIL', 'NEEDS REVIEW', 'BLOCKED'];

class InputError extends Error {}

function strList(value, what, id, fold) {
  if (value === undefined) return [];
  if (!Array.isArray(value) || value.some((x) => typeof x !== 'string' || !x.trim())) {
    throw new InputError(what + ' of ' + id + ' must be a list of non-empty strings');
  }
  return Array.from(new Set(value.map((x) => (fold ? x.trim().toLowerCase() : x.trim()))));
}

function normalize(input, warnings) {
  if (!input || !Array.isArray(input.tcs) || input.tcs.length === 0) {
    throw new InputError('input needs a non-empty "tcs" array');
  }
  const seen = new Set();
  return input.tcs.map((raw, index) => {
    if (!raw || typeof raw.id !== 'string' || !raw.id.trim()) throw new InputError('tcs[' + index + '] has no id');
    const id = raw.id.trim();
    if (seen.has(id)) throw new InputError('duplicate TC id ' + id);
    seen.add(id);

    let cls = raw.class;
    if (cls === undefined) {
      cls = 'serial';
      warnings.push(id + ': no class given, it runs alone');
    } else if (!CLASSES.includes(cls)) {
      throw new InputError(id + ': class must be one of ' + CLASSES.join(', '));
    }
    let riskName = String(raw.risk || 'Medium').trim().toLowerCase();
    if (!(riskName in RISK_RANK)) {
      warnings.push(id + ': unknown risk "' + raw.risk + '", treated as Medium');
      riskName = 'medium';
    }
    const weight = raw.weight === undefined ? 1 : raw.weight;
    if (!Number.isInteger(weight) || weight < 1) throw new InputError(id + ': weight must be a positive integer');

    return {
      id,
      index,
      cls,
      userScoped: cls === 'user_scoped',
      rank: RISK_RANK[riskName],
      weight,
      keys: strList(raw.keys, 'keys', id, true),
      writes: strList(raw.writes, 'writes', id, true),
      lists: strList(raw.lists, 'lists', id, true),
      depends_on: strList(raw.depends_on, 'depends_on', id, false),
    };
  });
}

function number(value, name, min, fallback) {
  if (value === undefined || value === '') return fallback;
  const n = Number(value);
  if (!Number.isInteger(n) || n < min) throw new InputError(name + ' must be an integer of ' + min + ' or more');
  return n;
}

const byRankThenIndex = (a, b) => a.rank - b.rank || a.index - b.index;

/** `compare` order, except that a TC always comes after the TCs of this list whose data it needs (a cycle falls back to `compare`). */
function dependencyOrder(members, compare) {
  const sorted = members.slice().sort(compare);
  const byId = new Map(sorted.map((m) => [m.id, m]));
  const emitted = new Set();
  const ordered = [];
  const emit = (member, trail) => {
    if (emitted.has(member.id) || trail.has(member.id)) return;
    trail.add(member.id);
    for (const dep of member.depends_on) if (byId.has(dep)) emit(byId.get(dep), trail);
    emitted.add(member.id);
    ordered.push(member);
  };
  for (const member of sorted) emit(member, new Set());
  return ordered;
}

/** Group the TCs that must stay together, balance the groups over the workers, set the rest aside to run alone. */
function planOnce(input, options) {
  const opts = options || {};
  const warnings = [];
  const tcs = normalize(input, warnings);
  const separate = opts.separateUsers !== undefined ? opts.separateUsers === true || opts.separateUsers === 'true' : input.separate_users === true;
  for (const t of tcs) {
    if (t.userScoped) t.cls = separate ? (t.keys.length > 0 ? 'keyed' : 'free') : 'serial';
  }
  const userScoped = tcs.filter((t) => t.userScoped).map((t) => t.id);
  const byId = new Map(tcs.map((t) => [t.id, t]));

  for (const t of tcs) {
    if (t.cls === 'keyed' && t.keys.length === 0) {
      t.cls = 'serial';
      warnings.push(t.id + ': keyed without keys, it runs alone');
    }
    for (const dep of t.depends_on) {
      if (!byId.has(dep)) {
        t.cls = 'serial';
        warnings.push(t.id + ': depends on unknown ' + dep + ', it runs alone');
      }
    }
  }

  const parent = tcs.map((_, i) => i);
  const find = (x) => {
    while (parent[x] !== x) { parent[x] = parent[parent[x]]; x = parent[x]; }
    return x;
  };
  const union = (a, b) => {
    const ra = find(a);
    const rb = find(b);
    if (ra !== rb) parent[Math.max(ra, rb)] = Math.min(ra, rb);
  };
  const keyOwner = new Map();
  for (const t of tcs) {
    for (const key of t.keys) {
      if (keyOwner.has(key)) union(t.index, keyOwner.get(key));
      else keyOwner.set(key, t.index);
    }
    for (const dep of t.depends_on) if (byId.has(dep)) union(t.index, byId.get(dep).index);
  }

  const groups = new Map();
  for (const t of tcs) {
    const root = find(t.index);
    if (!groups.has(root)) groups.set(root, []);
    groups.get(root).push(t);
  }
  const units = Array.from(groups.values()).map((group, n) => {
    const members = dependencyOrder(group, (a, b) => a.index - b.index);
    return {
      id: 'U' + (n + 1),
      members,
      tcs: members.map((m) => m.id),
      serial: members.some((m) => m.cls === 'serial'),
      weight: members.reduce((sum, m) => sum + m.weight, 0),
      rank: Math.min(...members.map((m) => m.rank)),
      first: Math.min(...members.map((m) => m.index)),
      keys: Array.from(new Set(members.flatMap((m) => m.keys))),
    };
  });

  // Automatic unless someone asked for a number: then every available browser (up to 2) is a candidate.
  const asked = opts.workers !== undefined ? opts.workers : input.workers;
  const auto = asked === undefined || asked === '';
  const capacity = Math.min(MAX_WORKERS, number(opts.maxWorkers !== undefined ? opts.maxWorkers : input.max_workers, 'max-workers', 1, MAX_WORKERS));
  const requested = auto ? capacity : Math.min(capacity, number(asked, 'workers', 1, 1));
  const minTcs = number(opts.minTcs !== undefined ? opts.minTcs : input.min_tcs, 'min-tcs', 1, DEFAULT_MIN_TCS);
  const totalWeight = tcs.reduce((sum, t) => sum + t.weight, 0);
  const minSaving = number(opts.minSaving !== undefined ? opts.minSaving : input.min_saving, 'min-saving', 0,
    Math.max(3, Math.ceil(totalWeight * 0.2)));
  const parallelUnits = units.filter((u) => !u.serial);
  const serialMembers = dependencyOrder(units.filter((u) => u.serial).flatMap((u) => u.members), byRankThenIndex);

  const footprints = {};
  for (const t of tcs) {
    footprints[t.id] = { class: t.cls, risk: t.rank, index: t.index, keys: t.keys, writes: t.writes, lists: t.lists, depends_on: t.depends_on };
  }
  const unitList = units.map((u) => ({ id: u.id, tcs: u.tcs, serial: u.serial, keys: u.keys }));
  const sequential = (reason) => ({
    mode: 'serial', reason, separate_users: separate, user_scoped: userScoped, requested_workers: requested, workers: [],
    serial: dependencyOrder(tcs, byRankThenIndex).map((t) => t.id),
    units: unitList, footprints,
    estimate: { serial_baseline: totalWeight },
    warnings,
  });

  if (requested < 2) return sequential(auto ? 'fewer than 2 worker browsers are available' : 'fewer than 2 workers asked for');
  if (tcs.length < minTcs) return sequential('only ' + tcs.length + ' TCs, fewer than ' + minTcs);
  if (parallelUnits.length < 2) return sequential('fewer than 2 independent groups of TCs');

  // Automatic: a worker has to be worth its startup, so each gets at least MIN_TCS_PER_WORKER TCs on average.
  const parallelWeight = parallelUnits.reduce((sum, u) => sum + u.weight, 0);
  const workerCount = auto
    ? Math.min(requested, parallelUnits.length, Math.floor(parallelWeight / MIN_TCS_PER_WORKER))
    : Math.min(requested, parallelUnits.length);
  if (workerCount < 2) return sequential('only ' + parallelWeight + ' TCs can run in parallel, too few for two workers');
  const workers = Array.from({ length: workerCount }, (_, i) => ({ worker: i + 1, load: 0, units: [] }));
  const biggestFirst = parallelUnits.slice().sort((a, b) => b.weight - a.weight || a.rank - b.rank || a.first - b.first);
  for (const unit of biggestFirst) {
    const target = workers.reduce((least, w) => (w.load < least.load ? w : least));
    target.units.push(unit);
    target.load += unit.weight;
  }
  for (const w of workers) w.units.sort((a, b) => a.rank - b.rank || a.first - b.first);

  const serialWeight = serialMembers.reduce((sum, t) => sum + t.weight, 0);
  const parallelPhase = Math.max(...workers.map((w) => w.load));
  const total = parallelPhase + serialWeight + 1;
  const saving = totalWeight - total;
  if (saving < minSaving) return sequential('would save only ' + saving + ' of ' + totalWeight + ' time units, needs ' + minSaving);

  return {
    mode: 'parallel', reason: null, auto, separate_users: separate, user_scoped: userScoped, requested_workers: requested,
    workers: workers.map((w) => ({ worker: w.worker, load: w.load, units: w.units.map((u) => u.id), tcs: w.units.flatMap((u) => u.tcs) })),
    serial: serialMembers.map((t) => t.id),
    units: unitList, footprints,
    estimate: { serial_baseline: totalWeight, parallel_phase: parallelPhase, serial_phase: serialWeight, merge_and_reruns: 1, total },
    warnings,
  };
}

/** planOnce, plus the answer to "would a second login help?" when the plan is sequential and user_scoped TCs held it back. */
function plan(input, options) {
  const result = planOnce(input, options);
  if (result.mode === 'serial' && !result.separate_users && result.user_scoped.length > 0) {
    const withSecondLogin = planOnce(input, Object.assign({}, options, { separateUsers: true }));
    if (withSecondLogin.mode === 'parallel') {
      result.second_login = {
        would_split: true,
        user_scoped: result.user_scoped,
        workers: withSecondLogin.workers.map((w) => ({ worker: w.worker, load: w.load, tcs: w.tcs })),
        serial: withSecondLogin.serial,
        estimate: withSecondLogin.estimate,
      };
    }
  }
  return result;
}

function verdictOf(entry) {
  const match = VERDICT_RE.exec(String(entry && entry.verdict || '').trim());
  return match ? match[1].toUpperCase() : null;
}

function windowOf(entry) {
  const start = Date.parse(entry && entry.start);
  const end = Date.parse(entry && entry.end);
  return Number.isFinite(start) && Number.isFinite(end) ? { start, end } : null;
}

/** The `user-setting` reason when a worker's own words say the TC switched a saved per-user setting, else null. */
function settingSwitchReason(entry) {
  if (entry.user_setting_write === true) return 'user-setting';
  const text = [entry.reason, entry.actual, entry.notes].filter((x) => typeof x === 'string').join(' ');
  const hit = SETTING_SWITCH_RE.exec(text);
  return hit ? 'user-setting:' + hit[0].replace(/\s+/g, ' ').slice(0, 60) : null;
}

/** A verdict needs screenshots that exist and were taken during this TC: a same-named file from an earlier run is no evidence. */
function hasEvidence(entry, stat, floor) {
  const shots = entry.screenshots;
  if (!Array.isArray(shots) || shots.length === 0 || shots.some((s) => typeof s !== 'string' || !s.trim())) return false;
  if (!stat) return true;
  const start = Date.parse(entry.start);
  const earliest = Number.isFinite(start) ? start - 2000 : floor;
  return shots.every((s) => {
    const modified = stat(s);
    return modified !== null && modified !== undefined && modified >= earliest;
  });
}

const intersects = (a, b) => a.some((x) => b.includes(x));

/**
 * Decide per assigned TC whether the worker's verdict stands or the TC needs a solo run.
 * workerDocs: [{ worker, entries, mtimeMs? }]. options: { stat(path) -> modified time in ms or null, graceSeconds }.
 */
function verify(planDoc, workerDocs, options) {
  const opts = options || {};
  if (!planDoc || !Array.isArray(planDoc.workers) || !planDoc.footprints) throw new InputError('plan.json is not a parallel plan');
  if (planDoc.mode && planDoc.mode !== 'parallel') throw new InputError('plan.json is a sequential plan, there is nothing to verify');
  const graceSeconds = Number.isFinite(Number(opts.graceSeconds)) ? Number(opts.graceSeconds) : GRACE_SECONDS;
  const graceMs = Math.max(0, graceSeconds) * 1000;
  const warnings = [];
  const planStart = Date.parse(planDoc.created_at);
  const evidenceFloor = Number.isFinite(planStart) ? planStart - 2000 : -Infinity;

  const assigned = new Map();
  for (const w of planDoc.workers) for (const id of w.tcs) assigned.set(id, w.worker);

  const entries = new Map();
  for (const doc of workerDocs) {
    if (!Array.isArray(doc.entries)) throw new InputError('worker ' + doc.worker + ' file must be a JSON array');
    if (Number.isFinite(planStart) && Number.isFinite(doc.mtimeMs) && doc.mtimeMs < planStart - 2000) {
      warnings.push('worker ' + doc.worker + ': file is older than the plan, ignored (its TCs count as unrun)');
      continue;
    }
    for (const entry of doc.entries) {
      if (!entry || typeof entry.tc !== 'string') { warnings.push('worker ' + doc.worker + ': an entry without a tc was ignored'); continue; }
      const owner = assigned.get(entry.tc);
      if (owner === undefined) { warnings.push(entry.tc + ': not assigned to any worker, ignored'); continue; }
      if (owner !== doc.worker) { warnings.push(entry.tc + ': reported by worker ' + doc.worker + ' but assigned to worker ' + owner + ', ignored'); continue; }
      entries.set(entry.tc, Object.assign({ worker: doc.worker }, entry));
    }
  }

  let keep = [];
  const rerun = [];
  const passes = [];
  for (const [tc, worker] of assigned) {
    const entry = entries.get(tc);
    if (!entry) { rerun.push({ tc, worker, reason: 'no-result' }); continue; }
    const verdict = verdictOf(entry);
    if (verdict === 'UNRUN' || verdict === 'DEFERRED') {
      rerun.push({ tc, worker, reason: verdict.toLowerCase() + (entry.reason ? ':' + entry.reason : '') });
    } else if (!verdict) {
      rerun.push({ tc, worker, reason: 'unknown-verdict' });
    } else if (verdict === 'SKIP') {
      rerun.push({ tc, worker, reason: 'skip-by-worker' });
    } else if (NEEDS_EVIDENCE.includes(verdict) && !hasEvidence(entry, opts.stat, evidenceFloor)) {
      rerun.push({ tc, worker, reason: 'no-evidence' });
    } else if (verdict === 'FAIL' || verdict === 'NEEDS REVIEW') {
      rerun.push({ tc, worker, reason: 'non-pass:' + verdict });
    } else if (verdict === 'BLOCKED') {
      if (entry.blocked_kind === 'other') keep.push({ tc, worker, verdict });
      else {
        if (entry.blocked_kind !== 'data') warnings.push(tc + ': BLOCKED without blocked_kind "other", it is run again');
        rerun.push({ tc, worker, reason: 'blocked-data' });
      }
    } else {
      const switched = settingSwitchReason(entry);
      if (switched) rerun.push({ tc, worker, reason: switched });
      else passes.push(entry);
    }
  }

  // Everything another worker may have written to while a PASS was running: TCs that ran, and TCs
  // that left no result at all (a crashed worker may still have changed data; its window is unknown).
  const writers = [];
  for (const [tc, worker] of assigned) {
    const entry = entries.get(tc);
    if (!entry) writers.push({ tc, worker, window: null });
    else if (verdictOf(entry) !== 'UNRUN') writers.push({ tc, worker, window: windowOf(entry) });
  }

  let missingTimes = false;
  for (const a of passes) {
    const fa = planDoc.footprints[a.tc] || { keys: [], writes: [], lists: [] };
    const wa = windowOf(a);
    let reason = null;
    for (const b of writers) {
      if (b.worker === a.worker || b.tc === a.tc) continue;
      const fb = planDoc.footprints[b.tc] || { keys: [], writes: [], lists: [] };
      const shared = intersects(fa.lists, fb.writes) ? 'lists:' + fa.lists.filter((x) => fb.writes.includes(x)).join(',')
        : intersects(fa.keys, fb.keys) ? 'keys:' + fa.keys.filter((x) => fb.keys.includes(x)).join(',') : null;
      if (!shared) continue;
      if (!wa || !b.window) { missingTimes = true; reason = 'overlap:' + b.tc + ' (' + shared + ', time unknown)'; break; }
      if (b.window.end + graceMs > wa.start && b.window.start < wa.end) { reason = 'overlap:' + b.tc + ' (' + shared + ')'; break; }
    }
    if (reason) rerun.push({ tc: a.tc, worker: a.worker, reason });
    else keep.push({ tc: a.tc, worker: a.worker, verdict: 'PASS' });
  }
  if (missingTimes) warnings.push('some entries had no usable start/end, treated as overlapping');

  // Every assigned TC is either kept or run again; one that is neither would slip through, so it goes to the solo run.
  const accounted = new Set(keep.map((k) => k.tc).concat(rerun.map((r) => r.tc)));
  for (const [tc, worker] of assigned) {
    if (accounted.has(tc)) continue;
    rerun.push({ tc, worker, reason: 'unaccounted' });
    warnings.push(tc + ': neither kept nor run again, added to the solo run');
  }

  // A TC run again alone needs the data its dependencies created, and those were torn down after their own TC.
  const keptById = new Map(keep.map((k) => [k.tc, k]));
  for (let grew = true; grew;) {
    grew = false;
    for (const r of rerun.slice()) {
      for (const dep of (planDoc.footprints[r.tc] || {}).depends_on || []) {
        if (keptById.has(dep)) {
          rerun.push({ tc: dep, worker: keptById.get(dep).worker, reason: 'dependency-of:' + r.tc });
          keptById.delete(dep);
          grew = true;
        }
      }
    }
  }
  keep = Array.from(keptById.values());

  const order = new Map(Array.from(assigned.keys()).map((id, i) => [id, i]));
  rerun.sort((x, y) => order.get(x.tc) - order.get(y.tc));
  keep.sort((x, y) => order.get(x.tc) - order.get(y.tc));

  const queueIds = Array.from(new Set((planDoc.serial || []).concat(rerun.map((r) => r.tc))));
  const info = (id) => planDoc.footprints[id] || { risk: 1, index: 0, depends_on: [] };
  queueIds.sort((x, y) => info(x).risk - info(y).risk || info(x).index - info(y).index);
  const inQueue = new Set(queueIds);
  const emitted = new Set();
  const serialQueue = [];
  const emit = (id, trail) => {
    if (emitted.has(id) || trail.has(id)) return;
    trail.add(id);
    for (const dep of info(id).depends_on || []) if (inQueue.has(dep)) emit(dep, trail);
    emitted.add(id);
    serialQueue.push(id);
  };
  for (const id of queueIds) emit(id, new Set());

  const byReason = {};
  for (const r of rerun) {
    const key = r.reason.split(/[:(]/)[0];
    byReason[key] = (byReason[key] || 0) + 1;
  }
  return {
    keep, rerun, serial_queue: serialQueue,
    summary: { assigned: assigned.size, kept: keep.length, rerun: rerun.length, by_reason: byReason },
    warnings,
  };
}

const VERDICT_LABELS = {
  PASS: 'PASS ✅', FAIL: 'FAIL ❌', BLOCKED: 'BLOCKED 🚫', 'NEEDS REVIEW': 'NEEDS REVIEW 🔍', SKIP: 'SKIP ⏭️', UNRUN: 'UNRUN ⏸️', DEFERRED: 'DEFERRED ↪️',
};

function formatDuration(seconds) {
  if (!Number.isFinite(seconds)) return '—';
  const whole = Math.max(0, Math.round(seconds));
  if (whole < 60) return whole + 's';
  if (whole < 3600) {
    const m = Math.floor(whole / 60);
    const s = whole % 60;
    return s ? m + 'm ' + s + 's' : m + 'm';
  }
  return Math.floor(whole / 3600) + 'h ' + Math.floor((whole % 3600) / 60) + 'm';
}

/** The finished TCs of all workers so far, oldest first: { tc, worker, verdict, seconds, reason }. A TC the plan gave to another worker is ignored. */
function progressRows(planDoc, workerDocs) {
  const assigned = new Map();
  for (const w of planDoc.workers || []) for (const id of w.tcs) assigned.set(id, w.worker);
  const rows = new Map();
  for (const doc of workerDocs) {
    for (const e of Array.isArray(doc.entries) ? doc.entries : []) {
      if (!e || typeof e.tc !== 'string' || assigned.get(e.tc) !== doc.worker) continue;
      const window = windowOf(e);
      rows.set(e.tc, {
        tc: e.tc,
        worker: doc.worker,
        verdict: verdictOf(e) || 'UNKNOWN',
        seconds: window ? (window.end - window.start) / 1000 : NaN,
        reason: String(e.reason || '').replace(/\s+/g, ' ').trim(),
        end: window ? window.end : 0,
      });
    }
  }
  return Array.from(rows.values()).sort((a, b) => a.end - b.end);
}

/** One line in the Step 3h table format, plus the worker; a verdict other than PASS gets its reason on a second line. */
function formatProgressRow(row, pending) {
  const label = VERDICT_LABELS[row.verdict] || row.verdict;
  const line = '| ' + row.tc + ' | ' + row.worker + ' | ' + label + ' | ' + formatDuration(row.seconds) + ' | ' + pending + ' |';
  if (row.verdict === 'PASS' || !row.reason) return line;
  return line + '\n↳ ' + row.reason.split(' ').slice(0, 15).join(' ');
}

/** `progress <parallel dir> [--watch]`: prints a table row for every TC the workers have finished; --watch keeps appending until all are in. */
function runProgress(args) {
  const dir = args.find((a) => !a.startsWith('--'));
  if (!dir) {
    process.stderr.write('usage: parallel-split.js progress <parallel dir> [--watch]\n');
    process.exit(2);
  }
  const printed = new Set();
  let headerShown = false;
  const tick = () => {
    let planDoc;
    try {
      planDoc = JSON.parse(fs.readFileSync(path.join(dir, 'plan.json'), 'utf8'));
    } catch (err) {
      process.stderr.write('progress: no readable plan.json in ' + dir + '\n');
      return false;
    }
    const docs = [];
    for (const w of planDoc.workers || []) {
      try {
        docs.push({ worker: w.worker, entries: JSON.parse(fs.readFileSync(path.join(dir, 'worker-' + w.worker + '.json'), 'utf8')) });
      } catch (err) { /* not written yet */ }
    }
    const total = Object.keys(planDoc.footprints || {}).length;
    for (const row of progressRows(planDoc, docs)) {
      if (printed.has(row.tc)) continue;
      if (!headerShown) {
        console.log('| TC | Worker | Result | Time taken | Pending |\n|---|---|---|---|---|');
        headerShown = true;
      }
      printed.add(row.tc);
      console.log(formatProgressRow(row, total - printed.size));
    }
    return printed.size >= (planDoc.workers || []).reduce((n, w) => n + w.tcs.length, 0);
  };
  if (tick() || !args.includes('--watch')) return;
  const timer = setInterval(() => {
    if (tick()) {
      clearInterval(timer);
      console.log('\nAll worker TCs are in. The coordinator now checks them and runs the rest alone.');
    }
  }, 5000);
}

/**
 * The last check before the results are written: every TC of the plan has exactly one final verdict, a kept worker
 * verdict or a finished solo result. A solo entry still marked RUNNING is not final. soloEntries: solo-results.json.
 */
function mergeCheck(planDoc, verifyDoc, soloEntries) {
  if (!planDoc || !planDoc.footprints) throw new InputError('plan.json is not a plan');
  if (!verifyDoc || !Array.isArray(verifyDoc.keep)) throw new InputError('verify.json has no "keep" list');
  const expected = Object.keys(planDoc.footprints);
  const known = new Set(expected);
  const kept = new Set(verifyDoc.keep.map((k) => k.tc));
  const solo = new Set();
  const running = new Set();
  for (const e of Array.isArray(soloEntries) ? soloEntries : []) {
    if (!e || typeof e.tc !== 'string') continue;
    if (verdictOf(e)) solo.add(e.tc);
    else running.add(e.tc);
  }
  const missing = expected.filter((id) => !kept.has(id) && !solo.has(id));
  const extra = Array.from(new Set([...kept, ...solo])).filter((id) => !known.has(id));
  const both = expected.filter((id) => kept.has(id) && solo.has(id));
  return {
    ok: missing.length === 0 && extra.length === 0,
    expected: expected.length,
    final: expected.length - missing.length,
    missing,
    not_final: missing.filter((id) => running.has(id)),
    extra,
    in_both: both,
  };
}

const isIso = (v) => typeof v === 'string' && Number.isFinite(Date.parse(v));
const isObject = (v) => Boolean(v) && typeof v === 'object' && !Array.isArray(v);
const STATE_CHECKS = {
  workers: [(v) => Array.isArray(v) && v.every((w) => isObject(w) && Number.isInteger(w.worker) && typeof w.prefix === 'string'), 'a JSON list of { "worker": n, "prefix": "mcp__…__" }'],
  flags_to_enable: [Array.isArray, 'a JSON list'],
  detected_flags: [Array.isArray, 'a JSON list'],
  seed: [Array.isArray, 'a JSON list'],
  options: [isObject, 'a JSON object'],
  flags_enabled: [(v) => typeof v === 'boolean', 'true or false'],
  deadline: [isIso, 'an ISO time'],
  step3_started_at: [isIso, 'an ISO time'],
  base_url: [(v) => typeof v === 'string' && /^https?:\/\//.test(v), 'an http(s) URL'],
  worker2_url: [(v) => typeof v === 'string' && /^https?:\/\//.test(v), 'an http(s) URL'],
  separate_users: [(v) => typeof v === 'boolean', 'true or false'],
  storage_state: [(v) => typeof v === 'string' && fs.existsSync(v), 'the path of a file that exists (quote a Windows path: the shell eats backslashes)'],
};

function checkStateValue(key, value) {
  const check = STATE_CHECKS[key];
  if (check && !check[0](value)) throw new InputError('state "' + key + '" must be ' + check[1] + ', got ' + JSON.stringify(value));
}

/** Merge key=value pairs into <dir>/state.json. The state is a hint (status derives the rest from files), so an unreadable file starts over. */
function setState(dir, pairs) {
  fs.mkdirSync(dir, { recursive: true });
  const file = path.join(dir, 'state.json');
  let state = {};
  try {
    state = JSON.parse(fs.readFileSync(file, 'utf8'));
    if (!state || typeof state !== 'object' || Array.isArray(state)) state = {};
  } catch (err) {
    state = {};
  }
  for (const pair of pairs) {
    const at = pair.indexOf('=');
    if (at < 1) throw new InputError('state arguments are key=value, got "' + pair + '"');
    const raw = pair.slice(at + 1);
    let value;
    try { value = JSON.parse(raw); } catch (err) { value = raw; }
    checkStateValue(pair.slice(0, at), value);
    state[pair.slice(0, at)] = value;
  }
  if (pairs.length) {
    state.updated_at = new Date().toISOString();
    const tmp = file + '.tmp';
    fs.writeFileSync(tmp, JSON.stringify(state, null, 2) + '\n');
    fs.renameSync(tmp, file);
  }
  return state;
}

/** Where a parallel run stands, worked out from the files in its folder, and what to do next. */
function status(dir) {
  const notes = [];
  const read = (name) => {
    const file = path.join(dir, name);
    try {
      return { value: JSON.parse(fs.readFileSync(file, 'utf8')), mtimeMs: fs.statSync(file).mtimeMs };
    } catch (err) {
      if (err.code !== 'ENOENT') notes.push(name + ' is unreadable (' + err.message + ')');
      return null;
    }
  };
  const planFile = read('plan.json');
  const planDoc = planFile && planFile.value;
  if (!planDoc || !planDoc.mode || !Array.isArray(planDoc.workers)) {
    return { dir, state: {}, next: 'plan', why: 'there is no plan.json', notes };
  }
  // Everything below belongs to this plan only: a file older than it is a leftover of an earlier run.
  const planStart = Date.parse(planDoc.created_at);
  const fresh = (file) => Boolean(file) && (!Number.isFinite(planStart) || file.mtimeMs >= planStart - 2000);

  const stateFile = read('state.json');
  let state = {};
  if (stateFile && stateFile.value && typeof stateFile.value === 'object') {
    if (fresh(stateFile)) state = stateFile.value;
    else notes.push('state.json is older than the plan, ignored');
  }
  const base = {
    dir, state,
    plan: { mode: planDoc.mode, created_at: planDoc.created_at, age_minutes: Number.isFinite(planStart) ? Math.round((Date.now() - planStart) / 60000) : null },
  };
  if (state.phase === 'done' || state.done === true) return Object.assign(base, { next: 'done', why: 'the run is finished', notes });

  // Results of the TCs run alone (or, after a fallback, of every TC), one entry per TC, rewritten after each TC.
  const soloFile = read('solo-results.json');
  if (soloFile && !fresh(soloFile)) notes.push('solo-results.json is older than the plan, ignored');
  const soloEntries = fresh(soloFile) && Array.isArray(soloFile.value) ? soloFile.value : [];
  if (soloEntries.some((e) => !e || typeof e.tc !== 'string')) notes.push('solo-results.json has entries without a "tc" key; they are ignored');
  const named = soloEntries.filter((e) => e && typeof e.tc === 'string');
  const isRunning = (e) => String(e.verdict || '').trim().toUpperCase() === 'RUNNING';
  const finished = new Set(named.filter((e) => !isRunning(e)).map((e) => e.tc));
  const interrupted = named.filter(isRunning).map((e) => e.tc);
  if (interrupted.length) {
    notes.push(interrupted.join(', ') + ' was running when the session ended: tear down its leftover QA-AUTO data before running it again');
  }
  const progress = (queue) => {
    const pending = queue.filter((tc) => !finished.has(tc));
    return { queued: queue.length, done: queue.length - pending.length, pending, interrupted };
  };

  if (planDoc.mode !== 'parallel') {
    const solo = progress(planDoc.serial || []);
    const why = solo.pending.length
      ? 'the plan says to run sequentially (' + (planDoc.reason || 'no reason given') + '); ' + solo.pending.length + ' of ' + solo.queued + ' TCs still have no result, run only those with the normal Step 3 loop'
      : 'the plan says to run sequentially and every TC has a result; continue after the Step 3 loop';
    return Object.assign(base, { next: 'sequential', why, solo, notes });
  }
  if (state.merged === true || state.phase === 'merged') {
    return Object.assign(base, { next: 'post', why: 'the results are merged and written; the post, the flag teardown and the confirmation are left', notes });
  }

  const workers = planDoc.workers.map((w) => {
    const file = read('worker-' + w.worker + '.json');
    let fileState = 'missing';
    let entries = [];
    if (file && !fresh(file)) fileState = 'stale';
    else if (file && !Array.isArray(file.value)) fileState = 'unreadable';
    else if (file) { fileState = 'ok'; entries = file.value; }
    const done = new Set(entries.map((e) => e && e.tc));
    return { worker: w.worker, assigned: w.tcs.length, file: fileState, done: w.tcs.filter((t) => done.has(t)).length, pending: w.tcs.filter((t) => !done.has(t)) };
  });
  const out = Object.assign(base, { workers, notes });

  const verifyFile = read('verify.json');
  if (fresh(verifyFile) && verifyFile.value && Array.isArray(verifyFile.value.serial_queue)) {
    const solo = progress(verifyFile.value.serial_queue);
    out.verify = { kept: (verifyFile.value.keep || []).length, rerun: (verifyFile.value.rerun || []).length };
    out.solo = solo;
    if (Array.isArray(state.flags_to_enable) && state.flags_to_enable.length && state.flags_enabled !== true) {
      notes.push('enable the flags in state.flags_to_enable before the first queued TC, then set flags_enabled=true');
    }
    if (solo.pending.length) return Object.assign(out, { next: 'solo', why: solo.pending.length + ' of ' + solo.queued + ' queued TCs have no solo result yet' });
    return Object.assign(out, { next: 'merge', why: 'every queued TC has a solo result' });
  }

  if (workers.some((w) => w.file === 'ok') || state.phase === 'dispatched') {
    return Object.assign(out, { next: 'verify', why: 'the workers were dispatched; check what they wrote' });
  }
  return Object.assign(out, { next: 'dispatch', why: 'a plan exists but no worker has written a result yet' });
}

function readJson(file) {
  try {
    return JSON.parse(fs.readFileSync(file, 'utf8'));
  } catch (err) {
    throw new InputError('cannot read ' + file + ': ' + err.message);
  }
}

function flag(args, name) {
  const hit = args.find((a) => a.startsWith('--' + name + '='));
  return hit ? hit.slice(name.length + 3) : undefined;
}

function readWorker(file, warnings) {
  const match = /worker-(\d+)\.json$/.exec(file.replace(/\\/g, '/'));
  if (!match) throw new InputError('worker file must be named worker-<n>.json: ' + file);
  const worker = Number(match[1]);
  try {
    const mtimeMs = fs.statSync(file).mtimeMs;
    const entries = JSON.parse(fs.readFileSync(file, 'utf8'));
    if (!Array.isArray(entries)) throw new Error('not a JSON array');
    return { worker, entries, mtimeMs };
  } catch (err) {
    warnings.push('worker ' + worker + ': ' + file + ' unreadable (' + err.message + '), its TCs count as unrun');
    return { worker, entries: [] };
  }
}

function main(argv) {
  const [command, ...rest] = argv;
  const files = rest.filter((a) => !a.startsWith('--'));
  if (command === 'plan' && files.length === 1) {
    const result = plan(readJson(files[0]), {
      workers: flag(rest, 'workers'), maxWorkers: flag(rest, 'max-workers'), minTcs: flag(rest, 'min-tcs'), minSaving: flag(rest, 'min-saving'),
      separateUsers: rest.includes('--separate-users') || flag(rest, 'separate-users') === 'true' ? true : undefined,
    });
    result.created_at = new Date().toISOString();
    return result;
  }
  if (command === 'verify' && files.length >= 1) {
    const warnings = [];
    const workerDocs = files.slice(1).map((file) => readWorker(file, warnings));
    const modified = (p) => { try { return fs.statSync(p).mtimeMs; } catch (err) { return null; } };
    const result = verify(readJson(files[0]), workerDocs, { stat: modified, graceSeconds: flag(rest, 'grace') });
    result.warnings = warnings.concat(result.warnings);
    return result;
  }
  if (command === 'merge-check' && (files.length === 2 || files.length === 3)) {
    let solo = [];
    if (files[2]) {
      try { solo = JSON.parse(fs.readFileSync(files[2], 'utf8')); } catch (err) { solo = []; }
    }
    return mergeCheck(readJson(files[0]), readJson(files[1]), solo);
  }
  if (command === 'now' && files.length === 0) return new Date().toISOString();
  if (command === 'state' && files.length >= 1) return setState(files[0], files.slice(1));
  if (command === 'status' && files.length === 1) return status(files[0]);
  throw new InputError('usage: parallel-split.js plan <input.json> [--workers=N] [--min-tcs=N] [--min-saving=N] [--separate-users] | verify <plan.json> [<worker-1.json> ...] [--grace=SECONDS] | merge-check <plan.json> <verify.json> [<solo-results.json>] | state <dir> [key=value ...] | status <dir>');
}

module.exports = { plan, verify, mergeCheck, progressRows, formatProgressRow, setState, status, InputError };

if (require.main === module && process.argv[2] === 'progress') {
  runProgress(process.argv.slice(3));
} else if (require.main === module) {
  try {
    const result = main(process.argv.slice(2));
    process.stdout.write((typeof result === 'string' ? result : JSON.stringify(result, null, 2)) + '\n');
    if (result && result.ok === false) process.exitCode = 3;
  } catch (err) {
    if (!(err instanceof InputError)) throw err;
    process.stderr.write('parallel-split: ' + err.message + '\n');
    process.exit(2);
  }
}
