#!/usr/bin/env node
/**
 * Safely remove a label from a Jira issue.
 * Reads current labels from the API, filters the target out, writes back in one call.
 * This prevents label array replacement (which wipes existing labels).
 *
 * Usage:
 *   node remove-label.js <issue_key> <label>
 *
 * Exits 0 on success (including when label was not present). Exits 1 on failure.
 */
const [, , issueKey, label] = process.argv;

if (!issueKey || !label) {
  process.stderr.write('Usage: node remove-label.js <issue_key> <label>\n');
  process.exit(1);
}

function loadCredentials() {
  const fs   = require('fs');
  const path = require('path');
  let email    = process.env.JIRA_EMAIL    || '';
  let apiToken = process.env.JIRA_API_TOKEN || '';
  if (!email || !apiToken) {
    try {
      const home = process.env.USERPROFILE || process.env.HOME || '';
      if (!home) throw new Error('no home dir');
      const settingsPath = path.join(home, '.claude', 'settings.json');
      const s = JSON.parse(fs.readFileSync(settingsPath, 'utf8'));
      if (s && s.env) {
        email    = email    || s.env.JIRA_EMAIL    || '';
        apiToken = apiToken || s.env.JIRA_API_TOKEN || '';
      }
    } catch { /* settings.json unreadable — fall through */ }
  }
  return { email, apiToken };
}
const { email, apiToken } = loadCredentials();

if (!email || !apiToken) {
  process.stderr.write('Missing JIRA_EMAIL or JIRA_API_TOKEN. Set them in ~/.claude/settings.json env block or as OS environment variables.\n');
  process.exit(1);
}

const auth    = Buffer.from(`${email}:${apiToken}`).toString('base64');
const headers = { Authorization: `Basic ${auth}`, 'Content-Type': 'application/json', Accept: 'application/json' };
const base    = 'https://maxxton.atlassian.net/rest/api/2/issue';

fetch(`${base}/${encodeURIComponent(issueKey)}?fields=labels`, { headers })
  .then(res => {
    if (!res.ok) throw new Error(`GET ${issueKey} failed: ${res.status}`);
    return res.json();
  })
  .then(data => {
    const current = (data.fields.labels || []);
    if (!current.includes(label)) {
      process.stdout.write(`Label "${label}" not present on ${issueKey} — nothing to remove\n`);
      return;
    }
    const updated = current.filter(l => l !== label);
    return fetch(`${base}/${encodeURIComponent(issueKey)}`, {
      method: 'PUT',
      headers,
      body: JSON.stringify({ fields: { labels: updated } }),
    }).then(res => {
      if (!res.ok) return res.text().then(t => { throw new Error(`PUT failed: ${res.status} ${t}`); });
      process.stdout.write(`Removed "${label}" from ${issueKey} (labels: ${updated.join(', ') || '(none)'})\n`);
    });
  })
  .catch(err => {
    process.stderr.write(`remove-label failed: ${err.message}\n`);
    process.exit(1);
  });
