#!/usr/bin/env node
/**
 * Tests for result-parts.js. Self-contained: node:test + node:assert.
 * Run: node plugins/qa-engineer/skills/test-ticket/scripts/result-parts.test.js
 */
'use strict';

const test = require('node:test');
const assert = require('node:assert');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { spawnSync } = require('child_process');
const rp = require('./result-parts');

const ids = (n, from = 1) => Array.from({ length: n }, (_, i) => `TC_${String(from + i).padStart(2, '0')}`);
const sizes = (parts) => parts.map(p => p.length);

// ─── planning ───────────────────────────────────────────────────────────────

test('plan: 45 or fewer TCs is never split', () => {
  for (const n of [1, 30, 44, 45]) assert.deepStrictEqual(sizes(rp.planParts(ids(n))), [n]);
});

test('plan: agreed sizes', () => {
  const cases = { 46: [23, 23], 50: [40, 10], 60: [40, 20], 85: [40, 23, 22], 100: [40, 40, 20], 48: [24, 24], 49: [25, 24] };
  for (const [n, want] of Object.entries(cases)) assert.deepStrictEqual(sizes(rp.planParts(ids(Number(n)))), want, `n=${n}`);
});

test('plan: every TC exactly once and in order, for every size from 1 to 300', () => {
  for (let n = 1; n <= 300; n++) {
    const all = ids(n);
    const parts = rp.planParts(all);
    assert.deepStrictEqual(parts.flat(), all, `n=${n}`);
    for (const p of parts) assert.ok(p.length >= 1 && p.length <= 40 || parts.length === 1, `n=${n} part size ${p.length}`);
  }
});

test('plan: multi-URL counts rows, not TCs', () => {
  // 30 TCs x 2 URLs = 60 rows -> batches of 20 TCs (40 rows)
  assert.deepStrictEqual(sizes(rp.planParts(ids(30), { urls: 2 })), [20, 10]);
  // 22 TCs x 2 URLs = 44 rows -> not split
  assert.deepStrictEqual(sizes(rp.planParts(ids(22), { urls: 2 })), [22]);
  // 16 TCs x 3 URLs = 48 rows -> 13 + 3 (tail 9 rows) -> rebalanced
  assert.deepStrictEqual(sizes(rp.planParts(ids(16), { urls: 3 })), [8, 8]);
});

test('plan: rejects duplicate, malformed and empty input', () => {
  assert.throws(() => rp.planParts([]), /no TC ids/);
  assert.throws(() => rp.planParts(['TC_01', 'TC_01']), /duplicate/);
  assert.throws(() => rp.planParts(['TC_01', 'EXTRA_01']), /not TC_<n>/);
});

test('assertPartition: catches missing, duplicated, unknown, empty and reordered parts', () => {
  const all = ids(5);
  assert.doesNotThrow(() => rp.assertPartition(all, [ids(3), ids(2, 4)]));
  assert.throws(() => rp.assertPartition(all, [ids(2), ids(2, 4)]), /missing \[TC_03\]/);
  assert.throws(() => rp.assertPartition(all, [ids(3), ids(3, 3)]), /duplicated \[TC_03\]/);
  assert.throws(() => rp.assertPartition(all, [ids(3), ['TC_04', 'TC_05', 'TC_99']]), /unknown \[TC_99\]/);
  assert.throws(() => rp.assertPartition(all, [ids(5), []]), /empty part/);
  assert.throws(() => rp.assertPartition(all, [['TC_02', 'TC_01', 'TC_03'], ids(2, 4)]), /order changed/);
});

// ─── bodies ─────────────────────────────────────────────────────────────────

const wikiRow = (id) => `| ${id} | scenario | expected | actual | PASS ✅ | !${id}-x.png! |`;
const wikiBlock = (list) => ['|| TC_ID || Test case scenario || Expected Result || Actual Result || Status || Test Proof ||', ...list.map(wikiRow)].join('\n');
const wikiBody = (list, { marker, impact } = {}) => ['h2. QA Test Results', marker || '', '', wikiBlock(list), impact ? '\nh2. Cross-Module Impact\nEvidence: graph only' : ''].join('\n');

test('tcIdsFromBody: wiki, markdown and html', () => {
  assert.deepStrictEqual(rp.tcIdsFromBody(wikiBody(ids(3))), ids(3));
  assert.deepStrictEqual(rp.tcIdsFromBody('## QA Test Results\n| TC_ID | a |\n|---|---|\n| TC_07 | x |\n| EXTRA_01 | y |'), ['TC_07']);
  const html = '<h2>QA Test Results</h2><table><thead><tr><th><p>TC_ID</p></th></tr></thead><tbody><tr><td><p>TC_01</p></td><td>x</td></tr><tr><td><p>TC_02</p></td></tr></tbody></table>';
  assert.deepStrictEqual(rp.tcIdsFromBody(html), ['TC_01', 'TC_02']);
  assert.strictEqual(rp.tcTableCount(html), 1);
});

test('partErrors: a correct part passes', () => {
  const body = wikiBody(ids(40), { marker: rp.markerLine(1, 2) });
  assert.deepStrictEqual(rp.partErrors(body, { n: 1, m: 2 }, ids(40)), []);
  const last = wikiBody(ids(20, 41), { marker: rp.markerLine(2, 2), impact: true });
  assert.deepStrictEqual(rp.partErrors(last, { n: 2, m: 2 }, ids(20, 41)), []);
});

test('partErrors: a missing TC, an extra TC and a duplicated TC are each reported', () => {
  const missing = rp.partErrors(wikiBody(ids(39), { marker: rp.markerLine(1, 2) }), { n: 1, m: 2 }, ids(40));
  assert.match(missing.join('\n'), /missing TC\(s\).*TC_40/);
  const extra = rp.partErrors(wikiBody(ids(41), { marker: rp.markerLine(1, 2) }), { n: 1, m: 2 }, ids(40));
  assert.match(extra.join('\n'), /another part.*TC_41/);
  const dup = rp.partErrors(wikiBody([...ids(40), 'TC_05'], { marker: rp.markerLine(1, 2) }), { n: 1, m: 2 }, ids(40));
  assert.match(dup.join('\n'), /exactly once.*TC_05 x2/);
});

test('partErrors: marker rules', () => {
  const noMarker = rp.partErrors(wikiBody(ids(2)), { n: 1, m: 2 }, ids(2));
  assert.match(noMarker.join('\n'), /exactly one marker, the line "_Part 1 of 2_"/);
  const wrongMarker = rp.partErrors(wikiBody(ids(2), { marker: rp.markerLine(2, 2) }), { n: 1, m: 2 }, ids(2));
  assert.match(wrongMarker.join('\n'), /exactly one marker/);
  const stray = rp.partErrors(wikiBody(ids(2), { marker: rp.markerLine(1, 2) }), null, null);
  assert.match(stray.join('\n'), /no --part was given/);
  assert.deepStrictEqual(rp.partErrors(wikiBody(ids(2)), null, null), []);
  assert.match(rp.partErrors(wikiBody(ids(2), { marker: rp.markerLine(1, 2) }), { n: 1, m: 2 }, null).join('\n'), /needs --tc-ids/);
  assert.match(rp.partErrors(wikiBody(ids(2)), { n: 3, m: 2 }, ids(2)).join('\n'), /1 <= n <= m/);
});

test('partErrors: Cross-Module Impact only in the last part', () => {
  const first = rp.partErrors(wikiBody(ids(2), { marker: rp.markerLine(1, 3), impact: true }), { n: 1, m: 3 }, ids(2));
  assert.match(first.join('\n'), /only in the last part/);
  const middle = rp.partErrors(wikiBody(ids(2), { marker: rp.markerLine(2, 3), impact: true }), { n: 2, m: 3 }, ids(2));
  assert.match(middle.join('\n'), /only in the last part/);
});

test('partErrors: multi-URL part needs every TC once per URL block', () => {
  const twoBlocks = ['h2. QA Test Results', rp.markerLine(1, 2), '', wikiBlock(ids(3)), '----', wikiBlock(ids(3))].join('\n');
  assert.deepStrictEqual(rp.partErrors(twoBlocks, { n: 1, m: 2 }, ids(3)), []);
  const lopsided = ['h2. QA Test Results', rp.markerLine(1, 2), '', wikiBlock(ids(3)), '----', wikiBlock(ids(2))].join('\n');
  assert.match(rp.partErrors(lopsided, { n: 1, m: 2 }, ids(3)).join('\n'), /TC_03 x1/);
});

test('reconcile: passes for a complete set, fails for a lost or doubled TC', () => {
  const plan = rp.planParts(ids(60)).map((tc_ids, i, a) => ({ part: i + 1, of: a.length, tc_ids, comment_id: String(100 + i) }));
  const bodies = plan.map((p, i) => wikiBody(p.tc_ids, { marker: rp.markerLine(i + 1, plan.length), impact: i === plan.length - 1 }));
  assert.deepStrictEqual(rp.reconcile(plan, bodies), []);
  assert.ok(rp.reconcile(plan, [bodies[0], wikiBody(ids(19, 41), { marker: rp.markerLine(2, 2) })]).join('\n').includes('TC_60'));
  assert.ok(rp.reconcile(plan, [bodies[0]]).join('\n').includes('part 2: no posted body'));
});

test('takePartArgs: removes the flags and leaves positional args intact', () => {
  const r = rp.takePartArgs(['MXTS-1', 'body.txt', '--part', '2/3', '--tc-ids', 'TC_41, TC_42', '', '2026-01-01T00:00:00Z']);
  assert.deepStrictEqual(r.rest, ['MXTS-1', 'body.txt', '', '2026-01-01T00:00:00Z']);
  assert.deepStrictEqual(r.part, { n: 2, m: 3 });
  assert.deepStrictEqual(r.tcIds, ['TC_41', 'TC_42']);
  assert.ok(Number.isNaN(rp.takePartArgs(['--part', 'x']).part.n));
});

// ─── CLI ────────────────────────────────────────────────────────────────────

test('cli plan prints the parts and cli reconcile checks body files', () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'result-parts-test-'));
  try {
    const script = path.join(__dirname, 'result-parts.js');
    const plan = spawnSync(process.execPath, [script, 'plan', '--ids', ids(60).join(',')], { encoding: 'utf8' });
    assert.strictEqual(plan.status, 0);
    const out = JSON.parse(plan.stdout);
    assert.strictEqual(out.split, true);
    assert.deepStrictEqual(out.parts.map(p => p.tc_ids.length), [40, 20]);

    const planFile = path.join(dir, 'plan.json');
    fs.writeFileSync(planFile, JSON.stringify(out.parts));
    const files = out.parts.map((p, i) => {
      const f = path.join(dir, `part${i + 1}.txt`);
      fs.writeFileSync(f, wikiBody(p.tc_ids, { marker: rp.markerLine(i + 1, 2), impact: i === 1 }));
      return f;
    });
    const ok = spawnSync(process.execPath, [script, 'reconcile', '--plan', planFile, '--body-file', files[0], '--body-file', files[1]], { encoding: 'utf8' });
    assert.strictEqual(ok.status, 0, ok.stderr);
    assert.match(ok.stdout, /60 TC\(s\) across 2 part\(s\)/);

    fs.writeFileSync(files[1], wikiBody(ids(19, 41), { marker: rp.markerLine(2, 2), impact: true }));
    const bad = spawnSync(process.execPath, [script, 'reconcile', '--plan', planFile, '--body-file', files[0], '--body-file', files[1]], { encoding: 'utf8' });
    assert.strictEqual(bad.status, 1);
    assert.match(bad.stderr, /TC_60/);

    const noIds = spawnSync(process.execPath, [script, 'plan', '--ids', 'TC_01,TC_01'], { encoding: 'utf8' });
    assert.strictEqual(noIds.status, 1);
    assert.match(noIds.stderr, /duplicate/);
  } finally {
    fs.rmSync(dir, { recursive: true, force: true });
  }
});

// ─── the three comment scripts ──────────────────────────────────────────────
// post-comment.js / update-comment.js validate before any network call. Sending them through a dead local proxy makes a
// body that PASSES validation end with "fetch failed" (exit 1, no CHECK output) instead of reaching Jira.

const STATS = ['Concern|MQA', 'Environment|Dev', 'Build / Version|1.0', 'Preconditions|None detected', 'Total TCs|2', 'Passed|2', 'Failed|0', 'Blocked|0',
  'Needs Review|0', 'Skipped|0', 'Pass rate|100%', 'QA Pipeline Version|2.12.0', 'Test Execution Timing|5m'].map(r => r.split('|'));
const RUN_TOTAL = 4;
const P12 = rp.markerLine(1, 2);
const tcNum = (id) => Number(id.slice(3));
// A part of a split results comment carries the story's TC count and its own TC range in Total TCs, and the whole story's
// counts in the other rows (every row of these test bodies is PASS, so the whole story passed: Passed = run).
const statsFor = (list, marker, run = RUN_TOTAL) => STATS.map(([a, b]) => {
  if (!marker) return [a, b];
  if (a === 'Total TCs') return [a, `${run} (${tcNum(list[0])}-${tcNum(list[list.length - 1])})`];
  return a === 'Passed' ? [a, String(run)] : [a, b];
});
const fullWiki = (list, marker, impact, run) => ['h2. QA Test Results', marker || '', '', ...statsFor(list, marker, run).map(([a, b]) => `| *${a}* | ${b} |`), '', wikiBlock(list),
  impact ? '\nh2. Cross-Module Impact\nEvidence: graph only' : ''].join('\n');
const fullMarkdown = (list, marker, impact, run) => ['## QA Test Results', marker || '', '', '| **Concern** | MQA |', '|---|---|', ...statsFor(list, marker, run).slice(1).map(([a, b]) => `| **${a}** | ${b} |`), '',
  '| TC_ID | Test case scenario | Expected Result | Actual Result | Status | Test Proof |', '|---|---|---|---|---|---|',
  ...list.map(id => `| ${id} | s | e | a | PASS ✅ | ${id}-x.png |`), impact ? '\n## Cross-Module Impact\n\nEvidence: graph only' : ''].join('\n');
const fullHtml = (list, marker, impact, run) => ['<h2>QA Test Results</h2>', marker ? `<p>${marker.replace(/_/g, '')}</p>` : '',
  '<table><tbody>' + statsFor(list, marker, run).map(([a, b]) => `<tr><td><p><strong>${a}</strong></p></td><td><p>${b}</p></td></tr>`).join('') + '</tbody></table>',
  '<table><thead><tr>' + ['TC_ID', 'Test case scenario', 'Expected Result', 'Actual Result', 'Status', 'Test Proof'].map(h => `<th><p>${h}</p></th>`).join('') + '</tr></thead><tbody>' +
    list.map(id => `<tr><td><p>${id}</p></td><td><p>s</p></td><td><p>e</p></td><td><p>a</p></td><td><p>PASS ✅</p></td><td><p>${id}-x.png</p></td></tr>`).join('') + '</tbody></table>',
  impact ? '<h2>Cross-Module Impact</h2><p>Evidence: graph only</p>' : ''].join('\n');

function inTmp(fn) {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'result-parts-scripts-'));
  try { return fn(dir); } finally { fs.rmSync(dir, { recursive: true, force: true }); }
}
const DEAD_NET = { JIRA_EMAIL: 'a@b.c', JIRA_API_TOKEN: 'x', NODE_USE_ENV_PROXY: '1', HTTPS_PROXY: 'http://127.0.0.1:9', HTTP_PROXY: 'http://127.0.0.1:9' };
const node = (script, args) => spawnSync(process.execPath, [path.join(__dirname, script), ...args], { encoding: 'utf8', env: { ...process.env, ...DEAD_NET } });
const passedValidation = (r) => r.status === 1 && /fetch failed/.test(r.stderr) && !/CHECK \d+\]/.test(r.stderr) && !/BLOCKED/.test(r.stderr);
const checks = (r) => (r.stderr.match(/\[CHECK \d+\][^\n]*/g) || []).join('\n');

test('post-comment.js: a correct split part passes validation; a single comment is unchanged', () => inTmp(dir => {
  const f = path.join(dir, 'b.txt');
  fs.writeFileSync(f, fullWiki(ids(2), rp.markerLine(1, 2)));
  assert.ok(passedValidation(node('post-comment.js', ['MXTS-1', f, '', new Date().toISOString(), '--part', '1/2', '--tc-ids', 'TC_01,TC_02', '--run-total', '4'])));
  fs.writeFileSync(f, fullWiki(ids(2)));
  assert.ok(passedValidation(node('post-comment.js', ['MXTS-1', f, '', new Date().toISOString()])), 'a normal comment must behave exactly as before');
}));

test('post-comment.js: a part with a missing TC, a wrong marker or an early Cross-Module Impact is blocked', () => inTmp(dir => {
  const f = path.join(dir, 'b.txt');
  const run = (body, extra) => { fs.writeFileSync(f, body); return node('post-comment.js', ['MXTS-1', f, '', new Date().toISOString(), ...extra]); };
  const flags = ['--part', '1/2', '--tc-ids', 'TC_01,TC_02', '--run-total', '4'];
  assert.match(checks(run(fullWiki(ids(1), rp.markerLine(1, 2)), flags)), /CHECK 14.*missing TC.*TC_02/);
  assert.match(checks(run(fullWiki(ids(2), rp.markerLine(2, 2)), flags)), /CHECK 14.*exactly one marker/);
  assert.match(checks(run(fullWiki(ids(2), rp.markerLine(1, 2), true), flags)), /CHECK 14.*only in the last part/);
  const stray = checks(run(fullWiki(ids(2), rp.markerLine(2, 2)), []));
  assert.match(stray, /CHECK 7/);
  assert.match(stray, /CHECK 14.*no --part/);
}));

test('post-comment.js: the last part may carry Cross-Module Impact', () => inTmp(dir => {
  const f = path.join(dir, 'b.txt');
  fs.writeFileSync(f, fullWiki(ids(2, 41), rp.markerLine(2, 2), true));
  assert.ok(passedValidation(node('post-comment.js', ['MXTS-1', f, '', new Date().toISOString(), '--part', '2/2', '--tc-ids', 'TC_41,TC_42', '--run-total', '4'])));
}));

test('update-comment.js: validates a part the same way', () => inTmp(dir => {
  const f = path.join(dir, 'b.txt');
  fs.writeFileSync(f, fullWiki(ids(2), rp.markerLine(1, 2)));
  const ok = node('update-comment.js', ['MXTS-1', '10001', f, '--part', '1/2', '--tc-ids', 'TC_01,TC_02', '--run-total', '4']);
  assert.ok(/Update failed: fetch failed/.test(ok.stderr) && !/CHECK \d+\]/.test(ok.stderr), ok.stderr);
  fs.writeFileSync(f, fullWiki(ids(1), rp.markerLine(1, 2)));
  assert.match(checks(node('update-comment.js', ['MXTS-1', '10001', f, '--part', '1/2', '--tc-ids', 'TC_01,TC_02', '--run-total', '4'])), /CHECK 14.*TC_02/);
}));

test('validate-results-comment.js: markdown and html parts (MCP path)', () => inTmp(dir => {
  const v = (body, name, extra) => { const f = path.join(dir, name); fs.writeFileSync(f, body); return spawnSync(process.execPath, [path.join(__dirname, 'validate-results-comment.js'), f, ...extra], { encoding: 'utf8' }); };
  const flags = ['--part', '1/2', '--tc-ids', 'TC_01,TC_02', '--run-total', '4'];
  for (const [name, build] of [['md.txt', fullMarkdown], ['h.html', fullHtml]]) {
    const ok = v(build(ids(2), rp.markerLine(1, 2)), name, flags);
    assert.strictEqual(ok.status, 0, `${name}: ${ok.stderr}`);
    assert.match(checks(v(build(ids(1), rp.markerLine(1, 2)), name, flags)), /CHECK 14.*TC_02/, name);
    assert.match(checks(v(build(ids(2), rp.markerLine(1, 2), true), name, flags)), /only in the last part/, name);
    assert.strictEqual(v(build(ids(2, 41), rp.markerLine(2, 2), true), name, ['--part', '2/2', '--tc-ids', 'TC_41,TC_42', '--run-total', '4']).status, 0, name);
    assert.strictEqual(v(build(ids(2)), name, []).status, 0, `${name}: unsplit body must pass exactly as before`);
    assert.match(checks(v(build(ids(2), rp.markerLine(1, 2)), name, [])), /CHECK 14.*no --part/, name);
  }
}));

// ─── Test Cases comment (Phase 2) ───────────────────────────────────────────

const TC10 = ['TC_ID', 'Test case scenario', 'Preconditions', 'Test steps', 'Expected Result', 'Actual result', 'Story number', 'Epic number', 'Automate', 'Risk'];
const tcWiki = (list, marker, pad = '') => ['h2. Test Cases — QA-1', marker || '', '', `|| ${TC10.join(' || ')} ||`, ...list.map(id => `| ${id} | scenario${pad} | pre | steps | expected | To be Tested | QA-1 | N/A | Yes | High |`), '',
  `_AC coverage: 2/2 | Automate: ${list.length} Yes / 0 No_`, ''].join('\n');
const tcMarkdown = (list, marker) => ['## Test Cases — QA-1', marker || '', '', `| ${TC10.join(' | ')} |`, '|---|---|---|---|---|---|---|---|---|---|', ...list.map(id => `| ${id} | scenario | pre | steps | expected | To be Tested | QA-1 | N/A | Yes | High |`), '',
  `_AC coverage: 2/2 | Automate: ${list.length} Yes / 0 No_`, ''].join('\n');
const tcPassed = (r) => r.status === 1 && /(duplicate check could not run|Update failed: fetch failed)/.test(r.stderr) && !/CHECK \d+\]/.test(r.stderr) && !/BLOCKED/.test(r.stderr);

test('post-tc-comment.js: a correct TC part passes; a missing TC, wrong marker or oversize body is blocked', () => inTmp(dir => {
  const f = path.join(dir, 'tc.txt');
  const run = (body, extra) => { fs.writeFileSync(f, body); return node('post-tc-comment.js', ['QA-1', f, ...extra]); };
  const flags = ['--part', '1/2', '--tc-ids', 'TC_01,TC_02', '--run-total', '4'];
  assert.ok(tcPassed(run(tcWiki(ids(2), rp.markerLine(1, 2)), flags)));
  assert.ok(tcPassed(run(tcWiki(ids(2)), [])), 'a normal TC comment must behave exactly as before');
  assert.match(checks(run(tcWiki(ids(1), rp.markerLine(1, 2)), flags)), /CHECK 14.*missing TC.*TC_02/);
  assert.match(checks(run(tcWiki(ids(2), rp.markerLine(2, 2)), flags)), /CHECK 14.*exactly one marker/);
  assert.match(checks(run(tcWiki(ids(2), rp.markerLine(1, 2)), [])), /CHECK 14.*no --part/);
  assert.match(checks(run(tcWiki(ids(60), null, ' x'.repeat(300)), [])), /CHECK 15.*characters/);
}));

test('update-tc-comment.js: validates a TC part the same way', () => inTmp(dir => {
  const f = path.join(dir, 'tc.txt');
  fs.writeFileSync(f, tcWiki(ids(2), rp.markerLine(2, 2)));
  assert.ok(tcPassed(node('update-tc-comment.js', ['QA-1', '10001', f, '--part', '2/2', '--tc-ids', 'TC_01,TC_02'])));
  assert.match(checks(node('update-tc-comment.js', ['QA-1', '10001', f, '--part', '1/2', '--tc-ids', 'TC_01,TC_02'])), /CHECK 14.*exactly one marker/);
}));

test('validate-results-comment.js --kind tc: markdown TC parts and the length guard', () => inTmp(dir => {
  const f = path.join(dir, 'tc.md');
  const v = (body, extra) => { fs.writeFileSync(f, body); return spawnSync(process.execPath, [path.join(__dirname, 'validate-results-comment.js'), f, '--kind', 'tc', '--story', 'QA-1', ...extra], { encoding: 'utf8' }); };
  assert.strictEqual(v(tcMarkdown(ids(2), rp.markerLine(1, 2)), ['--part', '1/2', '--tc-ids', 'TC_01,TC_02']).status, 0);
  assert.strictEqual(v(tcMarkdown(ids(2)), []).status, 0, 'unsplit TC comment unchanged');
  assert.match(checks(v(tcMarkdown(ids(1), rp.markerLine(1, 2)), ['--part', '1/2', '--tc-ids', 'TC_01,TC_02'])), /CHECK 14.*TC_02/);
  assert.match(checks(v(tcMarkdown(ids(2), rp.markerLine(1, 2)), [])), /CHECK 14.*no --part/);
}));

// (extended cases on split Test Cases comments: see extended-split.test.js)

test('plan --batch splits at a smaller size; length guard covers HTML', () => {
  assert.deepStrictEqual(sizes(rp.planParts(ids(40), { batch: 30 })), [30, 10]);
  assert.deepStrictEqual(sizes(rp.planParts(ids(33), { batch: 30 })), [17, 16], 'a tail under 10 is rebalanced');
  assert.deepStrictEqual(sizes(rp.planParts(ids(30), { batch: 30 })), [30]);
  assert.strictEqual(rp.lengthErrors('<p>' + 'x'.repeat(40000) + '</p>').length, 1, 'HTML bodies are measured too');
  assert.deepStrictEqual(rp.lengthErrors('<p>' + 'x'.repeat(100) + '</p>'), []);
  assert.strictEqual(rp.lengthErrors('x'.repeat(32001)).length, 1);
  assert.strictEqual(rp.lengthErrors('x'.repeat(32000)).length, 0);
});

// ─── review fixes: urls validation, marker form/position, data-alt, --validate-only ─────────────

test('plan: a batch that cannot hold one complete TC across all URL blocks is rejected, not clamped', () => {
  assert.throws(() => rp.planParts(ids(30), { urls: 3, batch: 2 }), /cannot hold one TC across 3 URL blocks/);
  assert.throws(() => rp.planParts(ids(1), { urls: 3, batch: 2 }), /use a batch of at least 3/);
  assert.throws(() => rp.planParts(ids(5), { urls: 50 }), /cannot hold one TC across 50 URL blocks/);
  const ok = rp.planParts(ids(30), { urls: 3, batch: 3 });
  assert.ok(ok.every(p => p.length * 3 <= 3), 'batch 3 with 3 URL blocks gives one TC per part');
  assert.deepStrictEqual(ok.flat(), ids(30));
  const r = spawnSync(process.execPath, [path.join(__dirname, 'result-parts.js'), 'plan', '--ids', ids(10).join(','), '--urls', '3', '--batch', '2'], { encoding: 'utf8' });
  assert.strictEqual(r.status, 1);
  assert.match(r.stderr, /cannot hold one TC/);
});

test('plan: urls must be a positive integer (no silent coercion, no empty part)', () => {
  for (const u of [0, -1, 1.5, NaN, 'x']) assert.throws(() => rp.planParts(ids(50), { urls: u }), /urls must be a positive integer/, String(u));
  const r = spawnSync(process.execPath, [path.join(__dirname, 'result-parts.js'), 'plan', '--ids', 'TC_01,TC_02', '--urls', 'nope'], { encoding: 'utf8' });
  assert.strictEqual(r.status, 1);
  assert.match(r.stderr, /urls must be a positive integer/);
});

test('partErrors: the marker must be the canonical form directly after the header', () => {
  const part = { n: 1, m: 2 };
  const wiki = (marker, where) => ['h2. QA Test Results', where === 'late' ? '' : marker, '', ...statsFor(ids(2), true).map(([a, b]) => `| *${a}* | ${b} |`), where === 'late' ? marker : '', '', wikiBlock(ids(2))].join('\n');
  assert.deepStrictEqual(rp.partErrors(wiki('_Part 1 of 2_'), part, ids(2), RUN_TOTAL), []);
  for (const bad of ['*Part 1 of 2*', 'Part 1 of 2', '_Part 1 of 2_ ']) {
    const errs = rp.partErrors(wiki(bad), part, ids(2), RUN_TOTAL).join('\n');
    if (bad.trim() === '_Part 1 of 2_') assert.strictEqual(errs, '', 'trailing space is trimmed, still canonical');
    else assert.match(errs, /CHECK 14.*directly after the header/, bad);
  }
  assert.match(rp.partErrors(wiki('_Part 1 of 2_', 'late'), part, ids(2), RUN_TOTAL).join('\n'), /directly after the header/, 'marker below the stats table is rejected');
  const html = (m) => `<h2>QA Test Results</h2>${m}<table><tbody><tr><td><p>x</p></td></tr></tbody></table>` + fullHtml(ids(2), P12).split('\n').slice(2).join('\n');
  assert.deepStrictEqual(rp.partErrors(html('<p>Part 1 of 2</p>'), part, ids(2), RUN_TOTAL), []);
  assert.match(rp.partErrors(html('<p><em>Part 1 of 2</em></p>'), part, ids(2), RUN_TOTAL).join('\n'), /directly after the header/);
  assert.match(rp.partErrors(`<h2>QA Test Results</h2><table><tbody><tr><td><p>x</p></td></tr></tbody></table><p>Part 1 of 2</p>` + fullHtml(ids(2), P12).split('\n').slice(2).join('\n'), part, ids(2), RUN_TOTAL).join('\n'), /directly after the header/);
});

test('validate-results-comment.js: a capture-failed filename in an HTML media alt is rejected (CHECK 13)', () => inTmp(dir => {
  const f = path.join(dir, 'h.html');
  const run = (body) => { fs.writeFileSync(f, body); return spawnSync(process.execPath, [path.join(__dirname, 'validate-results-comment.js'), f, '--format', 'html'], { encoding: 'utf8' }); };
  const good = fullHtml(ids(2));
  assert.strictEqual(run(good).status, 0);
  const bad = good.replace('data-alt="TC_01-demo-slug.png"', 'data-alt="TC_01-capture-failed.png"').replace('TC_01-slug.png', 'TC_01-capture-failed.png');
  const alt = good.replace(/<p>TC_01-x\.png<\/p>/, '<figure data-type="media-single"><div data-type="media" data-media-type="file" data-id="11111111-1111-1111-1111-111111111111" data-collection="c" data-alt="TC_01-capture-failed.png"></div></figure>');
  assert.notStrictEqual(alt, good, 'test body must actually contain the media node');
  const r = run(alt);
  assert.strictEqual(r.status, 1);
  assert.match(checks(r), /CHECK 13/);
  void bad;
}));

test('--validate-only: post scripts check the body offline and never post; update scripts refuse the flag', () => inTmp(dir => {
  const f = path.join(dir, 'b.txt');
  const noCreds = { ...process.env, JIRA_EMAIL: '', JIRA_API_TOKEN: '', HOME: dir, USERPROFILE: dir };
  const run = (script, args) => spawnSync(process.execPath, [path.join(__dirname, script), ...args], { encoding: 'utf8', env: noCreds });
  fs.writeFileSync(f, fullWiki(ids(2), rp.markerLine(1, 2)));
  const ok = run('post-comment.js', ['MXTS-1', f, '--part', '1/2', '--tc-ids', 'TC_01,TC_02', '--run-total', '4', '--validate-only']);
  assert.strictEqual(ok.status, 0, ok.stderr);
  assert.strictEqual(ok.stdout.trim(), 'OK');
  fs.writeFileSync(f, fullWiki(ids(1), rp.markerLine(1, 2)));
  const bad = run('post-comment.js', ['MXTS-1', f, '--part', '1/2', '--tc-ids', 'TC_01,TC_02', '--run-total', '4', '--validate-only']);
  assert.strictEqual(bad.status, 1);
  assert.match(checks(bad), /CHECK 14.*TC_02/);
  fs.writeFileSync(f, tcWiki(ids(2), rp.markerLine(2, 2)));
  const tcOk = run('post-tc-comment.js', ['QA-1', f, '--part', '2/2', '--tc-ids', 'TC_01,TC_02', '--validate-only']);
  assert.strictEqual(tcOk.status, 0, tcOk.stderr);
  assert.strictEqual(tcOk.stdout.trim(), 'OK');
  // without --validate-only and without credentials the post scripts still stop
  assert.match(run('post-comment.js', ['MXTS-1', f, '--part', '2/2', '--tc-ids', 'TC_01,TC_02', '--run-total', '4']).stderr, /Missing JIRA_EMAIL/);
  // update scripts must never silently drop the flag and send the PUT
  for (const s of ['update-comment.js', 'update-tc-comment.js']) {
    const r = run(s, ['MXTS-1', '10001', f, '--validate-only']);
    assert.strictEqual(r.status, 1, s);
    assert.match(r.stderr, /does not support --validate-only/, s);
  }
}));

// ─── Test Execution Timing value + shared stats across parts ────────────────

const timing = require('./timing-value');

test('timing-value: accepts a number with optional pause count, rejects N/A and free text', () => {
  for (const ok of ['0m', '42m', '59m', '1h 0m', '1h 12m', '12h 5m', '38m (1 pause)', '38m (2 pauses)', '1h 12m (11 pauses)', timing.GENERATION_ONLY]) {
    assert.strictEqual(timing.timingError(ok), null, ok);
  }
  for (const bad of ['', 'N/A', 'N/A (run spanned several sessions with tester pauses)', '120m', '1h', '1h 60m', '38 m', '38m (0 pauses)', '38m (1 pauses)',
    '38m (2 pause)', '38m (2 pauses', '38m, 2 pauses', '2 pauses (38m)', '38m 12s']) {
    assert.match(timing.timingError(bad) || '', /CHECK 16/, bad);
  }
});

test('Test Execution Timing is validated by post-comment.js, update-comment.js and validate-results-comment.js (wiki, markdown, html)', () => inTmp(dir => {
  const withTiming = (body, value) => body.replace('5m', value);
  const goodValues = ['38m (2 pauses)', '1h 12m (1 pause)', '42m'];
  const badValue = 'N/A (run spanned several sessions with tester pauses)';
  const wiki = path.join(dir, 'w.txt');
  const val = (name, body) => { const f = path.join(dir, name); fs.writeFileSync(f, body); return spawnSync(process.execPath, [path.join(__dirname, 'validate-results-comment.js'), f], { encoding: 'utf8' }); };
  for (const value of goodValues) {
    fs.writeFileSync(wiki, withTiming(fullWiki(ids(2)), value));
    assert.ok(passedValidation(node('post-comment.js', ['MXTS-1', wiki, '', new Date().toISOString()])), `post ${value}`);
    assert.ok(passedValidation(node('update-comment.js', ['MXTS-1', '10001', wiki])), `update ${value}`);
    assert.strictEqual(val('m.txt', withTiming(fullMarkdown(ids(2)), value)).status, 0, `markdown ${value}`);
    assert.strictEqual(val('h.html', withTiming(fullHtml(ids(2)), value)).status, 0, `html ${value}`);
  }
  fs.writeFileSync(wiki, withTiming(fullWiki(ids(2)), badValue));
  assert.match(checks(node('post-comment.js', ['MXTS-1', wiki, '', new Date().toISOString()])), /CHECK 16/);
  assert.match(checks(node('update-comment.js', ['MXTS-1', '10001', wiki])), /CHECK 16/);
  assert.match(checks(val('m.txt', withTiming(fullMarkdown(ids(2)), badValue))), /CHECK 16/);
  assert.match(checks(val('h.html', withTiming(fullHtml(ids(2)), badValue))), /CHECK 16/);
}));

test('reconcile: Concern, Build / Version and Test Execution Timing must be identical in every part', () => {
  const plan = rp.planParts(ids(60)).map((tc_ids, i, a) => ({ part: i + 1, of: a.length, tc_ids, comment_id: String(100 + i) }));
  const stats = (concern, build, timingValue) => ['', `| *Concern* | ${concern} |`, `| *Build / Version* | ${build} |`, `| *Test Execution Timing* | ${timingValue} |`].join('\n');
  const parts = (...s) => plan.map((p, i) => wikiBody(p.tc_ids, { marker: rp.markerLine(i + 1, plan.length), impact: i === plan.length - 1 }) + s[i]);
  assert.deepStrictEqual(rp.reconcile(plan, parts(stats('MQA', '1.0', '38m (2 pauses)'), stats('MQA', '1.0', '38m (2 pauses)'))), []);
  assert.match(rp.reconcile(plan, parts(stats('MQA', '1.0', '38m (2 pauses)'), stats('MQA', '1.0', '40m'))).join('\n'), /Test Execution Timing must be identical in every part/);
  assert.match(rp.reconcile(plan, parts(stats('MQA', '1.0', '38m'), stats('RCN', '1.0', '38m'))).join('\n'), /Concern must be identical/);
  assert.match(rp.reconcile(plan, parts(stats('MQA', '1.0', '38m'), stats('MQA', '1.1', '38m'))).join('\n'), /Build \/ Version must be identical/);
  // The same rows in HTML and markdown bodies are read too.
  assert.deepStrictEqual(rp.statValues(fullHtml(ids(1)), 'Build / Version'), ['1.0']);
  assert.deepStrictEqual(rp.statValues(fullMarkdown(ids(1)), 'Test Execution Timing'), ['5m']);
});

test('CHECK 17: a count with prose, a non-semver version or an empty Concern is rejected in wiki, markdown and html bodies', () => inTmp(dir => {
  const val = (name, body) => { const f = path.join(dir, name); fs.writeFileSync(f, body); return spawnSync(process.execPath, [path.join(__dirname, 'validate-results-comment.js'), f], { encoding: 'utf8' }); };
  const wiki = path.join(dir, 'w.txt');
  const variants = [
    [(b) => b.replace('Total TCs* | 2 |', 'Total TCs* | 13 (retest of the non-pass TCs) |'), (b) => b.replace('Total TCs** | 2 |', 'Total TCs** | 13 (retest of the non-pass TCs) |'),
      (b) => b.replace('Total TCs</strong></p></td><td><p>2<', 'Total TCs</strong></p></td><td><p>13 (retest)<'), /Total TCs = "13/],
    [(b) => b.replace('Version* | 2.12.0', 'Version* | latest'), (b) => b.replace('Version** | 2.12.0', 'Version** | latest'),
      (b) => b.replace('Version</strong></p></td><td><p>2.12.0<', 'Version</strong></p></td><td><p>latest<'), /QA Pipeline Version = "latest"/],
    [(b) => b.replace('Concern* | MQA', 'Concern* | '), (b) => b.replace('Concern** | MQA', 'Concern** | '),
      (b) => b.replace('Concern</strong></p></td><td><p>MQA<', 'Concern</strong></p></td><td><p><'), /Concern = \(empty\)/],
  ];
  for (const [toWiki, toMd, toHtml, expect] of variants) {
    fs.writeFileSync(wiki, toWiki(fullWiki(ids(2))));
    assert.match(checks(node('post-comment.js', ['MXTS-1', wiki, '', new Date().toISOString()])), /CHECK 17/, `post ${expect}`);
    assert.match(checks(node('update-comment.js', ['MXTS-1', '10001', wiki])), /CHECK 17/, `update ${expect}`);
    assert.match(checks(val('m.txt', toMd(fullMarkdown(ids(2))))), /CHECK 17/, `markdown ${expect}`);
    assert.match(checks(val('h.html', toHtml(fullHtml(ids(2))))), /CHECK 17/, `html ${expect}`);
    assert.match(val('m.txt', toMd(fullMarkdown(ids(2)))).stderr, expect);
  }
  assert.strictEqual(val('ok.txt', fullMarkdown(ids(2))).status, 0, 'a correct body still passes');
}));

test('reconcile: a part missing one of the shared stats rows is reported; Test Cases parts without stats are not', () => {
  const plan = rp.planParts(ids(60)).map((tc_ids, i, a) => ({ part: i + 1, of: a.length, tc_ids, comment_id: String(100 + i) }));
  const stats = ['', '| *Concern* | MQA |', '| *Build / Version* | 1.0 |', '| *Test Execution Timing* | 38m |'];
  const part = (i, rows) => wikiBody(plan[i].tc_ids, { marker: rp.markerLine(i + 1, plan.length), impact: i === plan.length - 1 }) + rows.join('\n');
  assert.deepStrictEqual(rp.reconcile(plan, [part(0, stats), part(1, stats)]), []);
  const noTiming = stats.filter((l) => !l.includes('Timing'));
  const errs = rp.reconcile(plan, [part(0, stats), part(1, noTiming)]).join('\n');
  assert.match(errs, /Test Execution Timing row is missing in part 2/);
  assert.match(rp.reconcile(plan, [part(0, noTiming), part(1, stats)]).join('\n'), /Test Execution Timing row is missing in part 1/);
  assert.deepStrictEqual(rp.reconcile(plan, [part(0, []), part(1, [])]), [], 'a comment with no stats table at all (a Test Cases comment) is not held to this check');
});

// ─── Total TCs of a part of a split results comment: "<story total> (<first>-<last>)" ───────────────────

const { statsErrors } = require('./dashboard-stats');
const setTotal = (body, value) => body
  .replace(/(\| \*Total TCs\* \| )[^|]*\|/, `$1${value} |`)
  .replace(/(\| \*\*Total TCs\*\* \| )[^|]*\|/, `$1${value} |`)
  .replace(/(Total TCs<\/strong><\/p><\/td><td><p>)[^<]*</, `$1${value}<`);

test('Total TCs of a part: the story total and the part range are required and checked against --run-total and --tc-ids', () => {
  const part = { n: 1, m: 2 };
  const body = (value) => setTotal(fullWiki(ids(2), P12), value);
  assert.deepStrictEqual(rp.partErrors(body('4 (1-2)'), part, ids(2), 4), []);
  assert.match(rp.partErrors(body('2'), part, ids(2), 4).join('\n'), /CHECK 14.*must read "4 \(1-2\)".*Found: "2"/);
  assert.match(rp.partErrors(body('5 (1-2)'), part, ids(2), 4).join('\n'), /must read "4 \(1-2\)".*"5 \(1-2\)"/);
  assert.match(rp.partErrors(body('4 (1-3)'), part, ids(2), 4).join('\n'), /must read "4 \(1-2\)"/);
  assert.match(rp.partErrors(body('4 (1-2)'), part, ids(2)).join('\n'), /needs --run-total/);
  assert.match(rp.partErrors(body('1 (1-2)'), part, ids(2), 1).join('\n'), /needs --run-total.*at least this part's 2/);
  assert.deepStrictEqual(rp.partErrors(fullWiki(ids(25, 31), rp.markerLine(2, 2), false, 55), { n: 2, m: 2 }, ids(25, 31), 55), [],
    'part 2 of 55 TCs reads 55 (31-55)');
  assert.ok(Number.isNaN(rp.takePartArgs(['--run-total', 'x']).runTotal));
  assert.strictEqual(rp.takePartArgs(['--run-total', '55']).runTotal, 55);
});

test('the Total TCs rule leaves unsplit results comments and other comment types alone', () => {
  assert.deepStrictEqual(rp.partErrors(fullWiki(ids(2)), null, null), []);
  const other = setTotal(fullWiki(ids(2), P12), '2').replace('h2. QA Test Results', 'h2. Execution Results');
  assert.deepStrictEqual(rp.partErrors(other, { n: 1, m: 2 }, ids(2)), [], 'an execute-tests comment keeps its own Total TCs');
});

test('CHECK 17: only a part of a split results comment may write "<total> (<first>-<last>)" in Total TCs', () => {
  for (const build of [fullWiki, fullMarkdown, fullHtml]) {
    assert.deepStrictEqual(statsErrors(build(ids(2), P12), { requireRows: true }), [], build.name);
    assert.match(statsErrors(setTotal(build(ids(2), P12), '2')).join('\n'), /CHECK 17[\s\S]*Total TCs = "2"/, `${build.name}: a part needs the form`);
    assert.match(statsErrors(setTotal(build(ids(2)), '4 (1-2)')).join('\n'), /CHECK 17[\s\S]*Total TCs = "4 \(1-2\)"/, `${build.name}: an unsplit body keeps a whole number`);
    assert.deepStrictEqual(statsErrors(build(ids(2))), [], `${build.name}: unsplit body unchanged`);
  }
});

test('validate-results-comment.js: a part needs --run-total and the right Total TCs (markdown and html)', () => inTmp(dir => {
  const v = (body, name, extra) => { const f = path.join(dir, name); fs.writeFileSync(f, body); return spawnSync(process.execPath, [path.join(__dirname, 'validate-results-comment.js'), f, ...extra], { encoding: 'utf8' }); };
  const flags = ['--part', '1/2', '--tc-ids', 'TC_01,TC_02'];
  for (const [name, build] of [['md.txt', fullMarkdown], ['h.html', fullHtml]]) {
    assert.strictEqual(v(build(ids(2), P12), name, [...flags, '--run-total', '4']).status, 0, name);
    assert.match(checks(v(build(ids(2), P12), name, flags)), /CHECK 14.*needs --run-total/, name);
    const plain = checks(v(setTotal(build(ids(2), P12), '2'), name, [...flags, '--run-total', '4']));
    assert.match(plain, /CHECK 17/, name);
    assert.match(plain, /CHECK 14.*must read "4 \(1-2\)"/, name);
    assert.match(checks(v(build(ids(2), P12), name, [...flags, '--run-total', '9'])), /CHECK 14.*must read "9 \(1-2\)"/, name);
  }
}));

test('post-comment.js and update-comment.js: the same Total TCs rule on a part', () => inTmp(dir => {
  const f = path.join(dir, 'b.txt');
  const flags = ['--part', '1/2', '--tc-ids', 'TC_01,TC_02'];
  fs.writeFileSync(f, setTotal(fullWiki(ids(2), P12), '2'));
  assert.match(checks(node('post-comment.js', ['MXTS-1', f, '', new Date().toISOString(), ...flags, '--run-total', '4'])), /CHECK 14.*must read "4 \(1-2\)"/);
  assert.match(checks(node('update-comment.js', ['MXTS-1', '10001', f, ...flags, '--run-total', '4'])), /CHECK 14.*must read "4 \(1-2\)"/);
  fs.writeFileSync(f, fullWiki(ids(2), P12));
  assert.match(checks(node('post-comment.js', ['MXTS-1', f, '', new Date().toISOString(), ...flags])), /CHECK 14.*needs --run-total/);
}));

test('reconcile: every part of a results comment carries the story total and its own TC range', () => {
  const plan = rp.planParts(ids(60)).map((tc_ids, i, a) => ({ part: i + 1, of: a.length, tc_ids, comment_id: String(100 + i) }));
  const part = (i, run = 60) => fullWiki(plan[i].tc_ids, rp.markerLine(i + 1, plan.length), i === plan.length - 1, run);
  assert.deepStrictEqual(rp.reconcile(plan, [part(0), part(1)]), []);
  const errs = rp.reconcile(plan, [part(0, plan[0].tc_ids.length), part(1)]).join('\n');
  assert.match(errs, new RegExp(`part 1: .*must read "60 \\(1-${plan[0].tc_ids.length}\\)"`));
});

// ─── the other stats rows of a part count the whole story ─────────────────────────────────────────────

const setRow = (body, label, value) => body
  .replace(new RegExp(`(\\| \\*${label}\\* \\| )[^|]*\\|`), `$1${value} |`)
  .replace(new RegExp(`(\\| \\*\\*${label}\\*\\* \\| )[^|]*\\|`), `$1${value} |`)
  .replace(new RegExp(`(${label}</strong></p></td><td><p>)[^<]*<`), `$1${value}<`);
const withRows = (body, rows) => Object.entries(rows).reduce((b, [label, value]) => setRow(b, label, value), body);

test('stats of a part: Passed, Failed, Blocked, Needs Review and Skipped add up to the story total, not to the part', () => {
  const part = { n: 1, m: 2 };
  const body = (rows) => withRows(fullWiki(ids(2), P12), rows);
  assert.deepStrictEqual(rp.partErrors(body({}), part, ids(2), 4), []);
  assert.match(rp.partErrors(body({ Passed: '2' }), part, ids(2), 4).join('\n'), /add up to the story's 4 TCs; they add up to 2/);
  assert.match(rp.partErrors(body({ Passed: '3', Failed: '2' }), part, ids(2), 4).join('\n'), /they add up to 5/);
  assert.deepStrictEqual(rp.partErrors(body({ Passed: '3', Blocked: '1', 'Pass rate': '100%' }), part, ids(2), 4), [], 'the other TCs of the story may be blocked');
});

test('stats of a part: no count may be below what this part alone holds', () => {
  const part = { n: 1, m: 2 };
  const errs = rp.partErrors(withRows(fullWiki(ids(2), P12), { Passed: '1', Failed: '3', 'Pass rate': '25%' }), part, ids(2), 4).join('\n');
  assert.match(errs, /Passed is 1, but this part alone has 2 PASS row/);
});

test('stats of a part: Pass rate is the whole story\'s, N/A only when nothing was verified', () => {
  const part = { n: 1, m: 2 };
  const rate = (rows) => rp.partErrors(withRows(fullWiki(ids(2), P12), rows), part, ids(2), 4).join('\n');
  assert.strictEqual(rate({ 'Pass rate': '100% (BLOCKED and Skipped excluded)' }), '');
  assert.strictEqual(rate({ 'Pass rate': '99%' }), '', 'one point of rounding is allowed');
  assert.match(rate({ 'Pass rate': '50% (BLOCKED and Skipped excluded)' }), /Pass rate must be the whole story's, 100% \(4 \/ \(4 - 0 - 0\)\), not this part's/);
  assert.match(rate({ 'Pass rate': 'N/A (no TC verified)' }), /Pass rate must be the whole story's, 100%/);
  const allBlocked = rp.partErrors(withRows(fullWiki(ids(2), P12), { Passed: '2', Blocked: '2', 'Pass rate': '50%' }), part, ids(2), 4).join('\n');
  assert.match(allBlocked, /Pass rate must be the whole story's, 100% \(2 \/ \(4 - 2 - 0\)\)/);
  const noneVerified = withRows(fullWiki(ids(2), P12).replace(/PASS ✅/g, 'BLOCKED 🚫'), { Passed: '0', Blocked: '4', 'Pass rate': 'N/A (no TC verified)' });
  assert.deepStrictEqual(rp.partErrors(noneVerified, part, ids(2), 4), []);
  assert.match(rp.partErrors(withRows(noneVerified, { 'Pass rate': '0%' }), part, ids(2), 4).join('\n'), /must be N\/A \(no TC verified\)/);
});

test('statusCounts reads the verdicts per URL block in wiki, markdown and html bodies', () => {
  const mixed = (b) => b.replace('PASS ✅', 'FAIL ❌');
  for (const build of [fullWiki, fullMarkdown, fullHtml]) {
    assert.deepStrictEqual(rp.statusCounts(mixed(build(ids(2), P12))), [{ PASS: 1, FAIL: 1, BLOCKED: 0, 'NEEDS REVIEW': 0, SKIP: 0 }], build.name);
  }
  const twoBlocks = fullWiki(ids(2), P12) + '\n' + fullWiki(ids(3)).split('\n').filter((l) => /^\s*\|\|? ?TC_|^\| TC_/.test(l)).join('\n');
  assert.deepStrictEqual(rp.statusCounts(twoBlocks).map((c) => c.PASS), [2, 3]);
});

test('reconcile proves every part\'s stats against the TC rows of all parts', () => {
  const plan = [{ part: 1, of: 2, tc_ids: ids(2), comment_id: '1' }, { part: 2, of: 2, tc_ids: ids(2, 3), comment_id: '2' }];
  // part 1: TC_01 PASS, TC_02 FAIL; part 2: TC_03 BLOCKED, TC_04 PASS  ->  Passed 2, Failed 1, Blocked 1, Pass rate 2/(4-1-0) = 67%
  const p1 = withRows(fullWiki(ids(2), P12).replace(/(TC_02 \| scenario \| expected \| actual \| )PASS ✅/, '$1FAIL ❌'), { Passed: '2', Failed: '1', Blocked: '1', 'Pass rate': '67% (BLOCKED and Skipped excluded)' });
  const p2 = withRows(fullWiki(ids(2, 3), rp.markerLine(2, 2), true).replace(/(TC_03 \| scenario \| expected \| actual \| )PASS ✅/, '$1BLOCKED 🚫'), { Passed: '2', Failed: '1', Blocked: '1', 'Pass rate': '67% (BLOCKED and Skipped excluded)' });
  const ok = (a, b) => rp.reconcile(plan, [withRows(a, { 'Total TCs': '4 (1-2)' }), withRows(b, { 'Total TCs': '4 (3-4)' })]);
  assert.deepStrictEqual(ok(p1, p2), []);
  const stale = withRows(p2, { Passed: '1', Failed: '0', Blocked: '1', 'Needs Review': '0', Skipped: '2' });
  const errs = ok(p1, stale).join('\n');
  assert.match(errs, /part 2: Passed says 1, but the TC rows of all parts add up to 2/);
  assert.match(errs, /part 2: Skipped says 2, but the TC rows of all parts add up to 0/);
  assert.match(ok(p1, withRows(p2, { 'Pass rate': '50%' })).join('\n'), /Pass rate must be identical in every part/);
});
