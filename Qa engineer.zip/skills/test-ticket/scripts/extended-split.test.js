#!/usr/bin/env node
/**
 * Tests for human-added ("extended") cases on a split Test Cases comment: planPartsExtended, extend-tc-comment.js on the
 * last part (--main-total), and the validators. Run: node plugins/qa-engineer/skills/test-ticket/scripts/extended-split.test.js
 */
'use strict';

const test = require('node:test');
const assert = require('node:assert');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { spawnSync } = require('child_process');
const rp = require('./result-parts');

const ids = (n, from = 1) => Array.from({ length: n }, (_, i) => `TC_${String(from + i).padStart(2, '0')}`);
const sizes = (plan) => plan.parts.map(x => x.length);
const TC10 = ['TC_ID', 'Test case scenario', 'Preconditions', 'Test steps', 'Expected Result', 'Actual result', 'Story number', 'Epic number', 'Automate', 'Risk'];
const row = (id) => `| ${id} | s | p | st | e | To be Tested | QA-1 | N/A | Yes | High |`;
const wiki = (list, marker) => ['h2. Test Cases — QA-1', '', marker || '', '', `|| ${TC10.join(' || ')} ||`,
  ...list.map(row), '', `_AC coverage: 2/2 | Automate: ${list.length} Yes / 0 No_`, ''].join('\n');
const markdown = (list, marker) => ['## Test Cases — QA-1', '', marker || '', '', `| ${TC10.join(' | ')} |`,
  '|---|---|---|---|---|---|---|---|---|---|', ...list.map(row), '', `_AC coverage: 2/2 | Automate: ${list.length} Yes / 0 No_`, ''].join('\n');
const entriesFor = (n) => ({ entries: Array.from({ length: n }, (_, k) => ({ decision: 'accepted', row: { scenario: `added ${k}`, expected: 'x', automated: 'No', risk: 'Medium', story: 'QA-1' } })) });
const checks = (r) => (r.stderr.match(/\[CHECK \d+\][^\n]*/g) || []).join('\n');
const noCreds = { ...process.env, JIRA_EMAIL: '', JIRA_API_TOKEN: '', EXTEND_TC_NOW: '2026-10-14' };

function inTmp(fn) {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'ext-split-'));
  try { return fn(dir); } finally { fs.rmSync(dir, { recursive: true, force: true }); }
}
function extend(dir, body, n, extra = []) {
  const b = path.join(dir, 'in.txt'), e = path.join(dir, 'e.json'), o = path.join(dir, 'out.txt');
  fs.writeFileSync(b, body);
  fs.writeFileSync(e, JSON.stringify(entriesFor(n)));
  const r = spawnSync(process.execPath, [path.join(__dirname, 'extend-tc-comment.js'), b, e, o, ...extra], { encoding: 'utf8', env: noCreds });
  return { r, out: r.status === 0 ? fs.readFileSync(o, 'utf8') : null };
}

test('planPartsExtended: extended rows count toward the limit and sit in the last part', () => {
  const p = rp.planPartsExtended(ids(60), 5);
  assert.deepStrictEqual(sizes(p), [40, 25]);
  assert.deepStrictEqual(p.extendedIds, ['TC_61', 'TC_62', 'TC_63', 'TC_64', 'TC_65']);
  assert.deepStrictEqual(p.parts[1].slice(-5), p.extendedIds);
  assert.deepStrictEqual(sizes(rp.planPartsExtended(ids(46), 5)), [23, 28]);
  assert.deepStrictEqual(sizes(rp.planPartsExtended(ids(40), 10)), [20, 30], '40 main + 10 extended = 50 rows -> split, the last part keeps main rows');
  assert.deepStrictEqual(sizes(rp.planPartsExtended(ids(40), 5)), [45], '45 rows in total stay one comment');
  assert.deepStrictEqual(sizes(rp.planPartsExtended(ids(45), 1)), [23, 23], '46 rows in total split');
  assert.strictEqual(rp.planPartsExtended(ids(40), 5).single, true);
  assert.throws(() => rp.planPartsExtended(ids(60), 40), /leave no room for main rows/);
  assert.throws(() => rp.planPartsExtended(ids(60), 0), /positive integer/);
});

test('planPartsExtended: for every size, every TC exactly once in order, parts within the limit, last part keeps a main row', () => {
  for (let m = 1; m <= 150; m++) for (const e of [1, 3, 5, 10, 20]) {
    const plan = rp.planPartsExtended(ids(m), e);
    assert.deepStrictEqual(plan.parts.flat(), ids(m).concat(plan.extendedIds), `m=${m} e=${e}`);
    assert.ok(plan.parts.every(x => x.length <= 45), `m=${m} e=${e} sizes ${sizes(plan)}`);
    if (plan.parts.length > 1) assert.ok(plan.parts[plan.parts.length - 1].length - e >= 1, `last part keeps a main row m=${m} e=${e}`);
  }
});

test('cli plan --extended prints the extended ids inside the last part', () => {
  const run = (args) => spawnSync(process.execPath, [path.join(__dirname, 'result-parts.js'), 'plan', ...args], { encoding: 'utf8' });
  const r = run(['--ids', ids(60).join(','), '--extended', '5']);
  assert.strictEqual(r.status, 0, r.stderr);
  const out = JSON.parse(r.stdout);
  assert.deepStrictEqual(out.parts.map(p => p.tc_ids.length), [40, 25]);
  assert.strictEqual(out.main_total, 60);
  assert.deepStrictEqual(out.extended_ids, ['TC_61', 'TC_62', 'TC_63', 'TC_64', 'TC_65']);
  const bad = run(['--ids', 'TC_01,TC_02', '--extended', '1', '--urls', '2']);
  assert.strictEqual(bad.status, 1);
  assert.match(bad.stderr, /--urls must be 1/);
});

test('extend-tc-comment.js: only the last part, with --main-total; "Claude generated" counts the whole story', () => inTmp(dir => {
  const last = wiki(ids(20, 41), rp.markerLine(2, 2));
  assert.match(extend(dir, wiki(ids(40), rp.markerLine(1, 2)), 1, ['--main-total', '60']).r.stderr, /only in the last part/);
  assert.match(extend(dir, last, 1).r.stderr, /pass --main-total/);
  assert.match(extend(dir, wiki(ids(2)), 1, ['--main-total', '2']).r.stderr, /only for the last part/);
  assert.match(extend(dir, last, 1, ['--main-total', 'x']).r.stderr, /positive integer/);
  const ok = extend(dir, last, 5, ['--main-total', '60']);
  assert.strictEqual(ok.r.status, 0, ok.r.stderr);
  assert.deepStrictEqual(JSON.parse(ok.r.stdout).added, ['TC_61', 'TC_62', 'TC_63', 'TC_64', 'TC_65']);
  assert.match(ok.out, /Claude generated 60 · Human requested 5 \(accepted 5/);
  assert.match(ok.out, /Miss rate 8% \(5\/65\)/);
  assert.match(ok.out, /^_Part 2 of 2_$/m, 'the marker survives');
}));

test('validators: the extended section is valid in the last part (with --main-total) and nowhere else', () => inTmp(dir => {
  const last = extend(dir, wiki(ids(20, 41), rp.markerLine(2, 2)), 5, ['--main-total', '60']).out;
  const lastIds = [...ids(20, 41), 'TC_61', 'TC_62', 'TC_63', 'TC_64', 'TC_65'].join(',');
  const f = path.join(dir, 'last.txt');
  const post = (part, tcIds, extra) => spawnSync(process.execPath, [path.join(__dirname, 'post-tc-comment.js'), 'QA-1', f, '--part', part, '--tc-ids', tcIds, '--validate-only', ...extra], { encoding: 'utf8', env: noCreds });
  fs.writeFileSync(f, last);
  const ok = post('2/2', lastIds, ['--main-total', '60']);
  assert.strictEqual(ok.status, 0, ok.stderr);
  assert.match(checks(post('2/2', lastIds, [])), /CHECK 8.*--main-total/, 'the part flag makes --main-total mandatory when the section is present');
  assert.match(checks(post('2/2', lastIds, ['--main-total', '59'])), /CHECK 8.*Claude generated 60.*59 main TCs/);
  // the same section inside a part that is not the last one
  fs.writeFileSync(f, wiki(ids(2), rp.markerLine(1, 2)).trimEnd() + '\n\n' + last.slice(last.indexOf('h3. Extended')));
  assert.match(checks(post('1/2', 'TC_01,TC_02', ['--main-total', '60'])), /CHECK 14.*belongs only in the last part/);
}));

test('markdown path (MCP): --kind tc and --kind gtc accept an extended last part', () => inTmp(dir => {
  const ext = extend(dir, markdown(ids(20, 41), rp.markerLine(2, 2)), 5, ['--main-total', '60']);
  assert.strictEqual(ext.r.status, 0, ext.r.stderr);
  const lastIds = [...ids(20, 41), 'TC_61', 'TC_62', 'TC_63', 'TC_64', 'TC_65'].join(',');
  const f = path.join(dir, 'l.md');
  const v = (kind, extra) => spawnSync(process.execPath, [path.join(__dirname, 'validate-results-comment.js'), f, '--kind', kind, '--story', 'QA-1', '--part', '2/2', '--tc-ids', lastIds, ...extra], { encoding: 'utf8' });
  fs.writeFileSync(f, ext.out);
  assert.strictEqual(v('tc', ['--main-total', '60']).status, 0, v('tc', ['--main-total', '60']).stderr);
  assert.match(v('tc', []).stderr, /CHECK 8.*--main-total/);
  // generating-test-cases: the standalone "QA Test Cases" comment has no italic footer and ends with Coverage Gaps
  const gtc = ext.out.replace('## Test Cases — QA-1', '## QA Test Cases — QA-1').replace(/\n_AC coverage:[^\n]*_\n/, '\n').trimEnd() + '\n\n## Coverage Gaps\n- none\n';
  fs.writeFileSync(f, gtc);
  const g = v('gtc', ['--main-total', '60']);
  assert.strictEqual(g.status, 0, g.stderr);
}));

test('update-tc-comment.js corrects the extended last part with the same checks (dead network: validation passes -> "fetch failed")', () => inTmp(dir => {
  const last = extend(dir, wiki(ids(20, 41), rp.markerLine(2, 2)), 5, ['--main-total', '60']).out;
  const lastIds = [...ids(20, 41), 'TC_61', 'TC_62', 'TC_63', 'TC_64', 'TC_65'].join(',');
  const f = path.join(dir, 'last.txt');
  fs.writeFileSync(f, last);
  const dead = { ...process.env, JIRA_EMAIL: 'a@b.c', JIRA_API_TOKEN: 'x', NODE_USE_ENV_PROXY: '1', HTTPS_PROXY: 'http://127.0.0.1:9', HTTP_PROXY: 'http://127.0.0.1:9' };
  const upd = (extra) => spawnSync(process.execPath, [path.join(__dirname, 'update-tc-comment.js'), 'QA-1', '10001', f, '--part', '2/2', '--tc-ids', lastIds, ...extra], { encoding: 'utf8', env: dead });
  const ok = upd(['--main-total', '60']);
  assert.ok(/Update failed: fetch failed/.test(ok.stderr) && !/CHECK \d+\]/.test(ok.stderr), ok.stderr);
  assert.match(checks(upd([])), /CHECK 8.*--main-total/);
}));

test('an extended row can never carry another issue\'s story key (builder and script-path validators)', () => inTmp(dir => {
  // builder: an explicit row.story that differs from the comment's story is rejected; the same story or none is fine
  const body = path.join(dir, 'in.txt'), e = path.join(dir, 'e.json'), out = path.join(dir, 'out.txt');
  fs.writeFileSync(body, wiki(ids(3)));
  const run = (story) => {
    fs.writeFileSync(e, JSON.stringify({ entries: [{ decision: 'accepted', row: { scenario: 's', expected: 'x', ...(story ? { story } : {}) } }] }));
    return spawnSync(process.execPath, [path.join(__dirname, 'extend-tc-comment.js'), body, e, out], { encoding: 'utf8', env: noCreds });
  };
  const bad = run('OTHER-1');
  assert.strictEqual(bad.status, 1);
  assert.match(bad.stderr, /row\.story "OTHER-1" differs from the comment's story "QA-1"/);
  assert.strictEqual(run('qa-1').status, 0, 'same key (any case) is accepted');
  assert.strictEqual(run(null).status, 0);
  assert.match(fs.readFileSync(out, 'utf8'), /\| TC_04 \|.*\| QA-1 \|/, 'the row carries the comment\'s story');
  // validators: a hand-built wiki body whose row names another story
  const f = path.join(dir, 'b.txt');
  fs.writeFileSync(f, wiki(ids(2)).replace('| TC_02 | s | p | st | e | To be Tested | QA-1 |', '| TC_02 | s | p | st | e | To be Tested | OTHER-1 |'));
  const post = spawnSync(process.execPath, [path.join(__dirname, 'post-tc-comment.js'), 'QA-1', f, '--validate-only'], { encoding: 'utf8', env: noCreds });
  assert.strictEqual(post.status, 1);
  assert.match(checks(post), /CHECK 0.*"Story number" must be QA-1.*TC_02=OTHER-1/);
  const dead = { ...process.env, JIRA_EMAIL: 'a@b.c', JIRA_API_TOKEN: 'x', NODE_USE_ENV_PROXY: '1', HTTPS_PROXY: 'http://127.0.0.1:9', HTTP_PROXY: 'http://127.0.0.1:9' };
  const upd = spawnSync(process.execPath, [path.join(__dirname, 'update-tc-comment.js'), 'QA-1', '10001', f], { encoding: 'utf8', env: dead });
  assert.match(checks(upd), /CHECK 0.*"Story number" must be QA-1/);
  fs.writeFileSync(f, wiki(ids(2)));
  assert.strictEqual(spawnSync(process.execPath, [path.join(__dirname, 'post-tc-comment.js'), 'QA-1', f, '--validate-only'], { encoding: 'utf8', env: noCreds }).status, 0, 'a correct body still passes');
}));

test('the Extended section header is not counted as another URL block (every TC once)', () => {
  const body = wiki(ids(2), rp.markerLine(1, 1)).replace(/\n_Part 1 of 1_\n/, '\n') + '\nh3. Extended cases added after Human review\n\n_Human review: …_\n\n' + `|| ${TC10.join(' || ')} ||\n` + row('TC_03') + '\n';
  assert.strictEqual(rp.tcTableCount(body), 1);
  assert.deepStrictEqual(rp.checkPartIds(body, ['TC_01', 'TC_02', 'TC_03']), []);
});
