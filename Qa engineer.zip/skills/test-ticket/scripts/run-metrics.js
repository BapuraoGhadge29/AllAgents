#!/usr/bin/env node
/**
 * Local-only run metrics for the QA pipeline (/test-ticket, /execute-tests).
 *
 * Records ONE small, privacy-scrubbed JSON record per run at <dir>/run-metrics.json so the team can
 * quantify BLOCKED-rate, where the time goes and where the friction is. Nothing is ever sent over the
 * network: this script has no network code and no dependencies.
 *
 * Usage:
 *   node run-metrics.js phase  <dir> <name> [--kind=test-ticket|execute-tests] [--mode=inline|subagent]
 *   node run-metrics.js event  <dir> <code> [detail...]
 *   node run-metrics.js finish <dir>
 *   node run-metrics.js human-review <dir> <slot> <generated> <requested> <accepted> <covered> <declined> <overridden>
 *   node run-metrics.js summarize <dir-or-file>...
 *
 *   phase      marks phase <name> started now and closes the previously open phase. Valid names:
 *              preflight, phase1, phase2, phase2.5, phase3a, evidence-review, phase3b, phase4, phase5,
 *              phase6, final. --kind / --mode are read on the FIRST call only (they create the record).
 *   event      appends {code, at, detail?}. Unknown codes are rejected with a warning. `detail` is joined
 *              with spaces, scrubbed (URLs, hosts, emails, tokens, paths, Jira keys, auth headers) and
 *              cut to 120 characters.
 *   finish     closes the open phase, sets finished_at / total_seconds and counts TCs from <dir>/results.md
 *              (and results_*.md) plus four flags and the summed pause_count / paused_seconds (the pauses
 *              behind the Jira Test Execution Timing row) from <dir>/run-state.json. Counts only: no scenario
 *              text, expected/actual result, selector, URL, Jira key or other free text is ever copied.
 *   human-review  records, for story number <slot> of the run (1-based position — never the Jira key), how many TCs Claude
 *              generated and what happened to the cases a human asked to add after review: requested, accepted
 *              (a real miss Claude agreed with), covered (already had a TC), declined, overridden (Claude said no, the human
 *              insisted). Overwrites that slot, so repeating a call never double-counts. summarize reports the miss rate.
 *   summarize  prints a compact markdown report over one or more run-metrics.json files. An argument may
 *              be a file, a run directory, or a root directory holding many run directories (searched
 *              one level deep).
 *
 * Privacy contract: every record is rebuilt from a fixed whitelist of keys on each write, so nothing
 * outside the schema (version 1) can ever land on disk. The directory name is not stored.
 *
 * Opt-out: QA_ENGINEER_METRICS=off (case-insensitive) turns every command into a silent no-op.
 * Fail-open: any error prints one `[run-metrics] ...` line to stderr and the exit code stays 0, so a
 * metrics problem can never break a QA run. A corrupt run-metrics.json is moved to
 * run-metrics.json.corrupt and a fresh record is started. process.exit() is never called: it crashes
 * Node on Windows after network work, and this script uses exitCode only (kept for consistency).
 *
 * Test hook: RUN_METRICS_NOW=<ISO timestamp> overrides the clock (used by run-metrics.test.js).
 */
'use strict';

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const FILE_NAME = 'run-metrics.json';
const SCHEMA = 1;
const PHASES = ['preflight', 'phase1', 'phase2', 'phase2.5', 'phase3a', 'evidence-review', 'phase3b', 'phase4', 'phase5', 'phase6', 'final'];
const EVENT_CODES = [
  'env_degraded_transient', 'env_degraded_blocked', 'env_flagged_broken', 'session_recovery',
  'playwright_prefix_fallback', 'playwright_unavailable', 'host_guard_stop', 'host_guard_third_party',
  'precondition_unconfirmed', 'early_abort', 'budget_exhausted', 'tc_timeout', 'jira_write_path_mcp',
  'evidence_review_downgrade', 'evidence_review_failed', 'evidence_review_skipped',
  'health_check_slack_unavailable', 'resume_run',
];
const KINDS = ['test-ticket', 'execute-tests'];
const MODES = ['inline', 'subagent'];
const MAX_DETAIL = 120;
const MAX_EVENTS = 500;
const MAX_PHASES = 200;
const MAX_SLOTS = 50;
const REDACTED = '[redacted]';

const BLOCKED_BUCKETS = [
  'environment', 'session', 'timeout', 'test_data_precondition', 'feature_flag_not_deployed',
  'dependency', 'third_party_portal', 'run_budget', 'permission', 'control_not_found', 'other',
];
// Order matters: the first matching bucket wins.
const BUCKET_RULES = [
  ['control_not_found', /no matching control/i], // Control Discovery found nothing; its "checked: <places>" list must not steer the bucket
  ['third_party_portal', /(?:third|3rd)[- ]?party|booking\.com|airbnb|extranet|developer portal|client portal|\bportal\b/i],
  ['run_budget', /run budget|budget exhausted|\bbudget\b/i],
  ['timeout', /time[- ]?out|timed out|\bhung\b/i],
  ['session', /\bsession\b|\blogin\b|log(?:ged)? ?in\b|logged out|expired|\bauth/i],
  ['permission', /permission|\brole\b|forbidden|access denied|unauthori[sz]ed|\b40[13]\b/i],
  ['feature_flag_not_deployed', /feature[- ]?flag|\bflag\b|not deployed|not yet deployed|undeployed|deployment|could not locate|not available in this env/i],
  ['test_data_precondition', /test data|\bdata\b|precondition|\bseed|fixture|prerequisite|does not exist|doesn't exist|no such|not found|missing/i],
  ['environment', /environment|\benv\b|unavailable|unreachable|\b50[0-4]\b|\b404\b|blank|outage|\bdown\b|degraded|navigation|offline/i],
  ['dependency', /depend|which failed|blocked by/i],
];

const warn = (msg) => { try { process.stderr.write(`[run-metrics] ${msg}\n`); } catch { /* nothing to do */ } };

// ─── clock ──────────────────────────────────────────────────────────────────

function nowDate() {
  const o = process.env.RUN_METRICS_NOW;
  if (o) { const d = new Date(o); if (!Number.isNaN(d.getTime())) return d; }
  return new Date();
}
const nowIso = () => nowDate().toISOString();
function secondsBetween(a, b) {
  const x = Date.parse(a), y = Date.parse(b);
  if (Number.isNaN(x) || Number.isNaN(y)) return 0;
  return Math.max(0, Math.round((y - x) / 1000));
}

// ─── sanitising ─────────────────────────────────────────────────────────────

/** Scrub free text before it is stored. Fails closed: anything that looks sensitive becomes [redacted]. */
function sanitize(input) {
  let s = String(input == null ? '' : input);
  s = s.replace(/[\u0000-\u001f\u007f]+/g, ' ');
  s = s.replace(/\b(?:authorization|set-cookie|cookie|proxy-authorization|x-api-key)\s*[:=]\s*.*/gi, REDACTED);
  s = s.replace(/\bBearer\s+\S+/gi, REDACTED);
  s = s.replace(/\b[a-z][a-z0-9+.-]{1,15}:\/\/\S+/gi, REDACTED);                       // any scheme://...
  s = s.replace(/\bwww\.\S+/gi, REDACTED);
  s = s.replace(/[\w.+%-]+@[\w-]+(?:\.[\w-]+)+/g, REDACTED);                            // emails
  s = s.replace(/\b(?:[\w-]+\.)+(?:maxxton\.net|com|nl)\b(?::\d+)?(?:\/\S*)?/gi, REDACTED); // hostnames
  s = s.replace(/\blocalhost(?::\d+)?(?:\/\S*)?/gi, REDACTED);
  s = s.replace(/\b\d{1,3}(?:\.\d{1,3}){3}(?::\d+)?\b/g, REDACTED);                     // IPv4
  s = s.replace(/(?:^|(?<=[\s("'=,;]))[A-Za-z]:[\\/][^\s"')]*/g, REDACTED);             // C:\dir\file
  s = s.replace(/(?:^|(?<=[\s("'=,;]))\\\\[^\s"')]+/g, REDACTED);                       // \\unc\share
  s = s.replace(/(?:^|(?<=[\s("'=,;]))(?:~|\.{1,2})?\/[^\s"')]*/g, REDACTED);           // /unix/path, ./rel, ~/x
  s = s.replace(/(?:^|(?<=[\s("'=,;]))[\w.@-]+(?:[\\/][\w.@-]+){2,}/g, REDACTED);       // rel/dir/file
  s = s.replace(/(?:^|(?<=[\s("'=,;]))[\w@-]+[\\/][\w@-]*\.[\w.-]+/g, REDACTED);        // dir/file.ext
  s = s.replace(/\b[A-Z][A-Z0-9]{1,9}-\d+\b/g, REDACTED);                               // Jira keys
  s = s.replace(/[A-Za-z0-9_+=-]{24,}/g, REDACTED);                                     // token-like strings
  s = s.replace(/\s+/g, ' ').trim();
  if (s.length > MAX_DETAIL) s = s.slice(0, MAX_DETAIL).trim();
  return s;
}

// ─── record handling ────────────────────────────────────────────────────────

function pluginVersion() {
  try {
    const p = path.join(__dirname, '..', '..', '..', '.claude-plugin', 'plugin.json');
    const v = JSON.parse(fs.readFileSync(p, 'utf8')).version;
    return typeof v === 'string' && /^[\w.+-]{1,32}$/.test(v) ? v : undefined;
  } catch { return undefined; }
}

const isIso = (v) => typeof v === 'string' && !Number.isNaN(Date.parse(v));
const int = (v) => (Number.isFinite(v) && v >= 0 ? Math.round(v) : 0);

/** Rebuild a record from the whitelist. Anything not named here is dropped. */
function whitelist(r) {
  const out = { schema: SCHEMA };
  if (typeof r.run_id === 'string' && /^[0-9a-f]{8}$/.test(r.run_id)) out.run_id = r.run_id;
  out.kind = KINDS.includes(r.kind) ? r.kind : 'test-ticket';
  if (MODES.includes(r.execution_mode)) out.execution_mode = r.execution_mode;
  if (typeof r.plugin_version === 'string' && /^[\w.+-]{1,32}$/.test(r.plugin_version)) out.plugin_version = r.plugin_version;
  if (isIso(r.started_at)) out.started_at = r.started_at;
  if (isIso(r.finished_at)) out.finished_at = r.finished_at;
  if (Number.isFinite(r.total_seconds)) out.total_seconds = int(r.total_seconds);

  out.phases = (Array.isArray(r.phases) ? r.phases : []).filter((p) => p && PHASES.includes(p.name) && isIso(p.started_at))
    .slice(0, MAX_PHASES).map((p) => {
      const o = { name: p.name, started_at: p.started_at };
      if (isIso(p.ended_at)) { o.ended_at = p.ended_at; o.seconds = int(p.seconds); }
      return o;
    });
  out.events = (Array.isArray(r.events) ? r.events : []).filter((e) => e && EVENT_CODES.includes(e.code) && isIso(e.at))
    .slice(0, MAX_EVENTS).map((e) => {
      const o = { code: e.code, at: e.at };
      const d = typeof e.detail === 'string' ? sanitize(e.detail) : '';
      if (d) o.detail = d;
      return o;
    });

  if (r.tcs && typeof r.tcs === 'object') {
    const t = r.tcs;
    out.tcs = {
      total: int(t.total), pass: int(t.pass), fail: int(t.fail), needs_review: int(t.needs_review),
      blocked: int(t.blocked), skip: int(t.skip), flaky_pass: int(t.flaky_pass),
      pass_rate: Number.isFinite(t.pass_rate) ? Math.round(t.pass_rate * 10000) / 10000 : null,
    };
  }
  if (r.blocked_reasons && typeof r.blocked_reasons === 'object') {
    const b = {};
    for (const k of BLOCKED_BUCKETS) if (Number.isFinite(r.blocked_reasons[k]) && r.blocked_reasons[k] > 0) b[k] = int(r.blocked_reasons[k]);
    out.blocked_reasons = b;
  }
  if (Array.isArray(r.human_review)) {
    const seen = new Set();
    out.human_review = [];
    for (const h of r.human_review) {
      if (!h || !Number.isFinite(h.slot) || h.slot < 1 || h.slot > MAX_SLOTS || seen.has(int(h.slot))) continue;
      seen.add(int(h.slot));
      out.human_review.push({
        slot: int(h.slot), generated: int(h.generated), requested: int(h.requested), accepted: int(h.accepted),
        covered: int(h.covered), declined: int(h.declined), overridden: int(h.overridden),
      });
    }
    out.human_review.sort((a, b) => a.slot - b.slot);
  }
  if (Number.isFinite(r.story_count)) out.story_count = int(r.story_count);
  if (typeof r.jira_write_path_is_mcp === 'boolean') out.jira_write_path_is_mcp = r.jira_write_path_is_mcp;
  if (typeof r.screenshot_upload_enabled === 'boolean') out.screenshot_upload_enabled = r.screenshot_upload_enabled;
  if (typeof r.phase === 'string' && /^[\w.-]{1,32}$/.test(r.phase)) out.phase = r.phase;
  if (Number.isFinite(r.pause_count) && r.pause_count >= 0) out.pause_count = int(r.pause_count);
  if (Number.isFinite(r.paused_seconds) && r.paused_seconds >= 0) out.paused_seconds = int(r.paused_seconds);
  return out;
}

function newRecord(kind, mode) {
  const r = { schema: SCHEMA, run_id: crypto.randomBytes(4).toString('hex'), kind: KINDS.includes(kind) ? kind : 'test-ticket' };
  if (MODES.includes(mode)) r.execution_mode = mode;
  const v = pluginVersion();
  if (v) r.plugin_version = v;
  r.started_at = nowIso();
  r.phases = [];
  r.events = [];
  return r;
}

function recordPath(dir) { return path.join(dir, FILE_NAME); }

/** Returns { rec, created }. A corrupt file is parked as run-metrics.json.corrupt and replaced. */
function loadRecord(dir, kind, mode) {
  const file = recordPath(dir);
  let raw;
  try { raw = fs.readFileSync(file, 'utf8'); }
  catch (e) {
    if (e.code === 'ENOENT') return { rec: newRecord(kind, mode), created: true };
    throw e;
  }
  try {
    const parsed = JSON.parse(raw);
    if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed) || parsed.schema !== SCHEMA || !Array.isArray(parsed.phases) || !Array.isArray(parsed.events)) {
      throw new Error('unexpected shape');
    }
    const rec = whitelist(parsed);
    if (!rec.run_id) rec.run_id = crypto.randomBytes(4).toString('hex');
    return { rec, created: false };
  } catch (e) {
    try { fs.renameSync(file, file + '.corrupt'); }
    catch { try { fs.copyFileSync(file, file + '.corrupt'); fs.unlinkSync(file); } catch { /* best effort */ } }
    warn(`${FILE_NAME} was corrupt (${e.message}); moved to ${FILE_NAME}.corrupt and started a fresh record`);
    return { rec: newRecord(kind, mode), created: true };
  }
}

function saveRecord(dir, rec) {
  fs.mkdirSync(dir, { recursive: true });
  const file = recordPath(dir);
  const tmp = `${file}.${process.pid}.${crypto.randomBytes(3).toString('hex')}.tmp`;
  const body = JSON.stringify(whitelist(rec), null, 2) + '\n';
  fs.writeFileSync(tmp, body, 'utf8');
  try { fs.renameSync(tmp, file); }
  catch (e) {
    // Windows can refuse to rename over a file another process just touched; fall back to a direct write.
    try { fs.writeFileSync(file, body, 'utf8'); } finally { try { fs.unlinkSync(tmp); } catch { /* gone */ } }
  }
}

function closeOpenPhase(rec, at) {
  const open = rec.phases[rec.phases.length - 1];
  if (open && !open.ended_at) {
    open.ended_at = at;
    open.seconds = secondsBetween(open.started_at, at);
  }
}

// ─── results.md parsing (counts only) ───────────────────────────────────────

function splitRow(line) {
  const body = line.trim().replace(/^\|/, '').replace(/\|$/, '');
  const cells = [];
  let cur = '';
  for (let i = 0; i < body.length; i++) {
    if (body[i] === '\\' && body[i + 1] === '|') { cur += '|'; i++; }
    else if (body[i] === '|') { cells.push(cur.trim()); cur = ''; }
    else cur += body[i];
  }
  cells.push(cur.trim());
  return cells;
}

const VERDICT_RE = /^(PASS|FAIL|NEEDS[ _-]?REVIEW|BLOCKED|SKIP(?:PED)?)\b/i;

/** Strip emoji / markdown decoration in front of the verdict word. */
function verdictOf(cell) {
  if (typeof cell !== 'string') return null;
  const t = cell.replace(/^[^A-Za-z]+/, '').replace(/^flaky[\s:-]*/i, '');
  const m = VERDICT_RE.exec(t);
  if (!m) return null;
  const v = m[1].toUpperCase().replace(/[ _-]/g, '');
  return v === 'NEEDSREVIEW' ? 'needs_review' : v === 'SKIPPED' ? 'skip' : v.toLowerCase();
}

function bucketOf(text) {
  const t = String(text || '');
  if (!t.trim()) return 'other';
  for (const [name, re] of BUCKET_RULES) if (re.test(t)) return name;
  return 'other';
}

function parenText(cell) {
  const i = cell.indexOf('(');
  if (i === -1) return '';
  const j = cell.lastIndexOf(')');
  return cell.slice(i + 1, j > i ? j : undefined);
}

/** Count verdicts in one results file. Returns {counts, reasons}; nothing but numbers leaves this function. */
function parseResults(text) {
  const rows = new Map();
  let idx = { verdict: -1, scenario: 1, reason: -1 };
  for (const line of text.split(/\r?\n/)) {
    if (!line.trim().startsWith('|')) continue;
    const cells = splitRow(line);
    if (cells.every((c) => /^:?-{2,}:?$/.test(c) || c === '')) continue;
    if (/^TC[_\s-]?ID$/i.test(cells[0].replace(/[*`]/g, ''))) {
      const find = (re) => cells.findIndex((c) => re.test(c.replace(/[*`]/g, '')));
      idx = { verdict: find(/^(verdict|status|result)$/i), scenario: Math.max(find(/scenario/i), 0) || 1, reason: find(/^(reason|notes?|actual result)$/i) };
      continue;
    }
    const id = cells[0].replace(/[*`]/g, '').match(/^TC[_-]?\d+[A-Za-z0-9_-]*/i);
    if (!id) continue;
    let vi = idx.verdict;
    let verdict = vi > 0 ? verdictOf(cells[vi]) : null;
    if (!verdict) {
      // No usable header: first cell after the scenario that starts with a verdict word in UPPER CASE.
      for (let i = 1; i < cells.length; i++) {
        if (i === idx.scenario) continue;
        if (/^[^A-Za-z]*(?:flaky[\s:-]*)?(PASS|FAIL|NEEDS[ _-]?REVIEW|BLOCKED|SKIP(?:PED)?)\b/.test(cells[i])) { verdict = verdictOf(cells[i]); vi = i; break; }
      }
    }
    if (!verdict) continue;
    const others = cells.filter((_, i) => i !== idx.scenario && i !== 0);
    const flaky = verdict === 'pass' && others.some((c) => /\bflaky\b/i.test(c));
    let bucket = null;
    if (verdict === 'blocked') {
      let reason = parenText(cells[vi]);
      if (!reason.trim() && idx.reason > 0 && cells[idx.reason]) reason = cells[idx.reason];
      bucket = bucketOf(reason);
    }
    rows.set(id[0].toUpperCase(), { verdict, flaky, bucket });
  }
  const counts = { total: 0, pass: 0, fail: 0, needs_review: 0, blocked: 0, skip: 0, flaky_pass: 0 };
  const reasons = {};
  for (const { verdict, flaky, bucket } of rows.values()) {
    counts.total++;
    counts[verdict]++;
    if (flaky) counts.flaky_pass++;
    if (bucket) reasons[bucket] = (reasons[bucket] || 0) + 1;
  }
  return { counts, reasons };
}

function computeTcs(dir) {
  let names;
  try { names = fs.readdirSync(dir).filter((n) => /^results(?:_[^\\/]*)?\.md$/i.test(n)).sort(); }
  catch { return null; }
  if (!names.length) return null;
  const tcs = { total: 0, pass: 0, fail: 0, needs_review: 0, blocked: 0, skip: 0, flaky_pass: 0, pass_rate: null };
  const reasons = {};
  for (const n of names) {
    let text;
    try { text = fs.readFileSync(path.join(dir, n), 'utf8'); } catch { continue; }
    const r = parseResults(text);
    for (const k of Object.keys(r.counts)) tcs[k] += r.counts[k];
    for (const [k, v] of Object.entries(r.reasons)) reasons[k] = (reasons[k] || 0) + v;
  }
  const denom = tcs.total - tcs.blocked - tcs.skip;
  tcs.pass_rate = denom > 0 ? Math.round((tcs.pass / denom) * 10000) / 10000 : null;
  return { tcs, reasons };
}

/** Copy ONLY phase, story_count and two booleans from run-state.json. */
function readRunState(dir) {
  let s;
  try { s = JSON.parse(fs.readFileSync(path.join(dir, 'run-state.json'), 'utf8')); } catch { return {}; }
  if (!s || typeof s !== 'object') return {};
  const out = {};
  if (typeof s.phase === 'string' && /^[\w.-]{1,32}$/.test(s.phase)) out.phase = s.phase;
  if (s.stories && typeof s.stories === 'object') out.story_count = Array.isArray(s.stories) ? s.stories.length : Object.keys(s.stories).length;
  if (typeof s.jira_write_path === 'string') out.jira_write_path_is_mcp = s.jira_write_path === 'mcp';
  if (typeof s.screenshot_upload_enabled === 'boolean') out.screenshot_upload_enabled = s.screenshot_upload_enabled;
  // Pauses the Jira "Test Execution Timing" row reports: summed over the stories of this run (counts and seconds only).
  const stories = Array.isArray(s.stories) ? s.stories : Object.values(s.stories && typeof s.stories === 'object' ? s.stories : {});
  let pauses = 0, paused = 0, seen = false;
  for (const st of stories) {
    if (!st || typeof st !== 'object') continue;
    if (Number.isFinite(st.pause_count) && st.pause_count >= 0) { pauses += st.pause_count; seen = true; }
    if (Number.isFinite(st.user_wait_seconds) && st.user_wait_seconds >= 0) { paused += st.user_wait_seconds; seen = true; }
  }
  if (seen) { out.pause_count = int(pauses); out.paused_seconds = int(paused); }
  return out;
}

// ─── commands ───────────────────────────────────────────────────────────────

function flagValue(args, name) {
  const hit = args.find((a) => a.startsWith(`--${name}=`));
  return hit ? hit.slice(name.length + 3) : undefined;
}

function cmdPhase(dir, args) {
  const flags = args.filter((a) => a.startsWith('--'));
  const pos = args.filter((a) => !a.startsWith('--'));
  const name = pos[0];
  if (!PHASES.includes(name)) { warn(`unknown phase "${sanitize(name || '')}" (valid: ${PHASES.join(', ')})`); return; }
  let kind = flagValue(flags, 'kind'), mode = flagValue(flags, 'mode');
  if (kind !== undefined && !KINDS.includes(kind)) { warn(`ignoring --kind=${sanitize(kind)} (allowed: ${KINDS.join(', ')})`); kind = undefined; }
  if (mode !== undefined && !MODES.includes(mode)) { warn(`ignoring --mode=${sanitize(mode)} (allowed: ${MODES.join(', ')})`); mode = undefined; }
  const { rec } = loadRecord(dir, kind, mode);
  const open = rec.phases[rec.phases.length - 1];
  if (open && !open.ended_at && open.name === name) return;
  const at = nowIso();
  closeOpenPhase(rec, at);
  rec.phases.push({ name, started_at: at });
  saveRecord(dir, rec);
}

function cmdEvent(dir, args) {
  const [code, ...detail] = args;
  if (!EVENT_CODES.includes(code)) { warn(`unknown event code "${sanitize(code || '')}" ignored`); return; }
  const { rec } = loadRecord(dir);
  const ev = { code, at: nowIso() };
  const d = sanitize(detail.join(' '));
  if (d) ev.detail = d;
  rec.events.push(ev);
  saveRecord(dir, rec);
}

function cmdHumanReview(dir, args) {
  const nums = args.slice(0, 7).map((a) => Number(a));
  if (args.length < 7 || nums.some((n) => !Number.isInteger(n) || n < 0)) {
    warn('usage: human-review <dir> <slot> <generated> <requested> <accepted> <covered> <declined> <overridden> (non-negative integers)');
    return;
  }
  const [slot, generated, requested, accepted, covered, declined, overridden] = nums;
  if (slot < 1 || slot > MAX_SLOTS) { warn(`slot must be 1..${MAX_SLOTS}`); return; }
  if (requested !== accepted + covered + declined + overridden) { warn('requested must equal accepted + covered + declined + overridden'); return; }
  const { rec } = loadRecord(dir);
  const list = Array.isArray(rec.human_review) ? rec.human_review.filter((h) => h.slot !== slot) : [];
  list.push({ slot, generated, requested, accepted, covered, declined, overridden });
  rec.human_review = list;
  saveRecord(dir, rec);
}

function cmdFinish(dir) {
  const { rec } = loadRecord(dir);
  const at = nowIso();
  closeOpenPhase(rec, at);
  rec.finished_at = at;
  // Phases are contiguous, so their sum equals wall-clock time within one session and excludes idle gaps on a resume.
  const phaseSum = rec.phases.reduce((n, p) => n + (p.seconds || 0), 0);
  rec.total_seconds = rec.phases.length ? phaseSum : secondsBetween(rec.started_at, at);
  const res = computeTcs(dir);
  if (res) { rec.tcs = res.tcs; rec.blocked_reasons = res.reasons; }
  Object.assign(rec, readRunState(dir));
  saveRecord(dir, rec);
}

// ─── summarize ──────────────────────────────────────────────────────────────

function collectFiles(arg) {
  let st;
  try { st = fs.statSync(arg); } catch { warn(`cannot read ${path.basename(arg)}`); return []; }
  if (st.isFile()) return [arg];
  const direct = recordPath(arg);
  if (fs.existsSync(direct)) return [direct];
  const out = [];
  let entries = [];
  try { entries = fs.readdirSync(arg, { withFileTypes: true }); } catch { /* unreadable */ }
  for (const e of entries) {
    if (!e.isDirectory()) continue;
    const f = path.join(arg, e.name, FILE_NAME);
    if (fs.existsSync(f)) out.push(f);
  }
  return out.sort();
}

const mean = (xs) => (xs.length ? xs.reduce((a, b) => a + b, 0) / xs.length : 0);
const pct = (v) => (v == null ? 'n/a' : `${(v * 100).toFixed(1)}%`);
const mins = (s) => (Number.isFinite(s) ? (s / 60).toFixed(1) : 'n/a');
const cell = (v) => String(v).replace(/\|/g, '/');

function cmdSummarize(args) {
  const runs = [];
  for (const a of args) {
    for (const f of collectFiles(a)) {
      try {
        const parsed = JSON.parse(fs.readFileSync(f, 'utf8'));
        if (!parsed || parsed.schema !== SCHEMA) throw new Error('not a schema 1 record');
        runs.push({ rec: whitelist(parsed), label: path.basename(path.dirname(f)) });
      } catch (e) { warn(`skipping unreadable ${path.basename(path.dirname(f))}/${FILE_NAME}: ${e.message}`); }
    }
  }
  if (!runs.length) { process.stdout.write('# QA run metrics\n\nNo run-metrics.json files found.\n'); return; }

  const L = [];
  L.push('# QA run metrics', '', `${runs.length} run(s).`, '', '## Runs', '',
    '| Run | Kind | Mode | Started | Total min | Pauses | TCs | Pass rate | Blocked |', '|---|---|---|---|---|---|---|---|---|');
  for (const { rec, label } of runs) {
    const t = rec.tcs;
    L.push(`| ${cell(label)} | ${rec.kind} | ${rec.execution_mode || '-'} | ${rec.started_at || '-'} | ${mins(rec.total_seconds)} | ${Number.isFinite(rec.pause_count) ? rec.pause_count : '-'} | ${t ? t.total : '-'} | ${t ? pct(t.pass_rate) : '-'} | ${t ? t.blocked : '-'} |`);
  }

  const agg = { total: 0, pass: 0, fail: 0, needs_review: 0, blocked: 0, skip: 0, flaky_pass: 0 };
  for (const { rec } of runs) if (rec.tcs) for (const k of Object.keys(agg)) agg[k] += rec.tcs[k] || 0;
  const denom = agg.total - agg.blocked - agg.skip;
  const timed = runs.filter((r) => Number.isFinite(r.rec.total_seconds));
  L.push('', '## Totals', '',
    `- TCs: ${agg.total} (pass ${agg.pass}, fail ${agg.fail}, needs review ${agg.needs_review}, blocked ${agg.blocked}, skip ${agg.skip}, flaky pass ${agg.flaky_pass})`,
    `- Pass rate: ${denom > 0 ? pct(agg.pass / denom) : 'n/a'}`,
    `- BLOCKED rate: ${agg.total > 0 ? pct(agg.blocked / agg.total) : 'n/a'}`,
    `- Mean run time: ${timed.length ? mins(mean(timed.map((r) => r.rec.total_seconds))) + ' min' : 'n/a'}`);
  const paused = runs.filter((r) => Number.isFinite(r.rec.pause_count));
  if (paused.length) {
    L.push(`- Pauses: ${paused.reduce((n, r) => n + r.rec.pause_count, 0)} across ${paused.filter((r) => r.rec.pause_count > 0).length} of ${paused.length} run(s), ` +
      `${mins(paused.reduce((n, r) => n + (r.rec.paused_seconds || 0), 0))} min paused (not part of Test Execution Timing)`);
  }

  const reasons = {};
  for (const { rec } of runs) for (const [k, v] of Object.entries(rec.blocked_reasons || {})) reasons[k] = (reasons[k] || 0) + v;
  const rr = Object.entries(reasons).sort((a, b) => b[1] - a[1] || a[0].localeCompare(b[0]));
  if (rr.length) {
    L.push('', '## Top BLOCKED reasons', '', '| Reason | TCs |', '|---|---|');
    for (const [k, v] of rr) L.push(`| ${k} | ${v} |`);
  }

  const perPhase = {};
  for (const { rec } of runs) {
    const mine = {};
    for (const p of rec.phases) if (p.ended_at) mine[p.name] = (mine[p.name] || 0) + (p.seconds || 0);
    for (const [k, v] of Object.entries(mine)) (perPhase[k] = perPhase[k] || []).push(v);
  }
  const pp = PHASES.filter((n) => perPhase[n]);
  if (pp.length) {
    L.push('', '## Average seconds per phase', '', '| Phase | Avg s | Runs |', '|---|---|---|');
    for (const n of pp) L.push(`| ${n} | ${Math.round(mean(perPhase[n]))} | ${perPhase[n].length} |`);
  }

  const hr = { generated: 0, requested: 0, accepted: 0, covered: 0, declined: 0, overridden: 0, stories: 0 };
  for (const { rec } of runs) for (const h of rec.human_review || []) {
    hr.stories += 1;
    for (const k of ['generated', 'requested', 'accepted', 'covered', 'declined', 'overridden']) hr[k] += h[k];
  }
  if (hr.stories) {
    const missed = hr.accepted + hr.overridden;
    const total = hr.generated + missed;
    L.push('', '## Human review (how much Claude missed)', '', '| Stories | Claude generated | Human requested | Accepted | Already covered | Declined | Added on request | Miss rate |', '|---|---|---|---|---|---|---|---|');
    L.push(`| ${hr.stories} | ${hr.generated} | ${hr.requested} | ${hr.accepted} | ${hr.covered} | ${hr.declined} | ${hr.overridden} | ${total ? pct(missed / total) : 'n/a'} (${missed}/${total}) |`);
  }

  const ev = {};
  for (const { rec } of runs) for (const e of rec.events) ev[e.code] = (ev[e.code] || 0) + 1;
  const er = Object.entries(ev).sort((a, b) => b[1] - a[1] || a[0].localeCompare(b[0]));
  if (er.length) {
    L.push('', '## Events', '', '| Event | Count |', '|---|---|');
    for (const [k, v] of er) L.push(`| ${k} | ${v} |`);
  }

  if (runs.some((r) => r.rec.execution_mode)) {
    const groups = {};
    for (const r of runs) (groups[r.rec.execution_mode || 'unspecified'] = groups[r.rec.execution_mode || 'unspecified'] || []).push(r.rec);
    L.push('', '## Execution mode comparison', '', '| Mode | Runs | Mean total s | Mean total min | Mean BLOCKED rate |', '|---|---|---|---|---|');
    for (const [m, recs] of Object.entries(groups).sort()) {
      const secs = recs.filter((r) => Number.isFinite(r.total_seconds)).map((r) => r.total_seconds);
      const br = recs.filter((r) => r.tcs && r.tcs.total > 0).map((r) => r.tcs.blocked / r.tcs.total);
      L.push(`| ${m} | ${recs.length} | ${secs.length ? Math.round(mean(secs)) : 'n/a'} | ${secs.length ? mins(mean(secs)) : 'n/a'} | ${br.length ? pct(mean(br)) : 'n/a'} |`);
    }
  }
  process.stdout.write(L.join('\n') + '\n');
}

// ─── main ───────────────────────────────────────────────────────────────────

function main(argv) {
  if (String(process.env.QA_ENGINEER_METRICS || '').trim().toLowerCase() === 'off') return;
  const [cmd, ...rest] = argv;
  if (cmd === 'summarize') {
    if (!rest.length) { warn('usage: summarize <dir-or-file>...'); return; }
    cmdSummarize(rest);
    return;
  }
  if (!['phase', 'event', 'finish', 'human-review'].includes(cmd)) { warn('usage: run-metrics.js <phase|event|finish|human-review|summarize> <dir> [args...]'); return; }
  const [dir, ...args] = rest;
  if (!dir) { warn(`usage: ${cmd} <dir> ...`); return; }
  if (cmd === 'phase') cmdPhase(dir, args);
  else if (cmd === 'event') cmdEvent(dir, args);
  else if (cmd === 'human-review') cmdHumanReview(dir, args);
  else cmdFinish(dir);
}

if (require.main === module) {
  try { main(process.argv.slice(2)); }
  catch (e) { warn(`${e && e.message ? e.message : 'unexpected error'} (metrics skipped)`); }
  process.exitCode = 0;
}

module.exports = { sanitize, parseResults, bucketOf, whitelist };
