#!/usr/bin/env node
/**
 * Tests for verify-screenshot-embeds.js. Self-contained: node:test + node:assert.
 * Run: node plugins/qa-engineer/skills/test-ticket/scripts/verify-screenshot-embeds.test.js
 */
'use strict';

const test = require('node:test');
const assert = require('node:assert');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { spawnSync } = require('child_process');
const { bodyOf, verify } = require('./verify-screenshot-embeds');

const SCRIPT = path.join(__dirname, 'verify-screenshot-embeds.js');
const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'verify-embeds-'));
test.after(() => fs.rmSync(tmp, { recursive: true, force: true }));
const write = (name, text) => {
  const f = path.join(tmp, name);
  fs.writeFileSync(f, text);
  return f;
};
const run = (args) => {
  const r = spawnSync(process.execPath, [SCRIPT, ...args], { encoding: 'utf8' });
  return { code: r.status, out: r.stdout.trim().split('\n'), err: r.stderr.trim() };
};

const figure = (name, readback = false) =>
  `<figure data-type="media-single" data-layout="center" data-width="100" data-width-type="percentage"><div data-type="media" data-media-type="file" data-id="id-${name}"${readback ? '' : ' data-collection="c"'} data-alt="${name}"></div></figure>`;
const row = (tc, proof) => `<tr><td>${tc}</td><td>${proof}</td></tr>`;
const table = (...rows) => `<table><tbody>${rows.join('')}</tbody></table>`;

test('every screenshot embedded: all counted, exit 0', () => {
  const html = table(row('TC_01', figure('TC_01-result.png')), row('TC_02', `<p>Before:</p>${figure('TC_02-a.png')}<p>After:</p>${figure('TC_02-b.png')}`));
  const r = verify(html);
  assert.deepStrictEqual(r.expected.sort(), ['TC_01-result.png', 'TC_02-a.png', 'TC_02-b.png']);
  assert.deepStrictEqual(r.missing, []);
  const f = write('ok.html', html);
  assert.deepStrictEqual(run([f]), { code: 0, out: ['embedded 3/3'], err: '' });
});

test('a plain filename is a missing screenshot', () => {
  const html = table(row('TC_01', figure('TC_01-result.png')), row('TC_02', '<p>TC_02-result.png</p>'));
  assert.deepStrictEqual(verify(html).missing, [{ name: 'TC_02-result.png', why: 'plain-filename' }]);
  const r = run([write('plain.html', html)]);
  assert.strictEqual(r.code, 1);
  assert.deepStrictEqual(r.out, ['MISSING TC_02-result.png plain-filename', 'embedded 1/2']);
});

test('--expect: a screenshot the posted body names but the comment lacks is absent', () => {
  const posted = table(row('TC_01', figure('TC_01-result.png')), row('TC_02', figure('TC_02-result.png')));
  const readback = table(row('TC_01', figure('TC_01-result.png', true)), row('TC_02', ''));
  assert.deepStrictEqual(verify(readback, posted).missing, [{ name: 'TC_02-result.png', why: 'absent' }]);
  const r = run([write('rb.html', readback), '--expect', write('posted.html', posted)]);
  assert.strictEqual(r.code, 1);
  assert.deepStrictEqual(r.out, ['MISSING TC_02-result.png absent', 'embedded 1/2']);
});

test('--expect: the body posted with plain names is the expectation too (upload skipped)', () => {
  const posted = table(row('TC_01', '<p>TC_01-result.png</p>'));
  const readback = table(row('TC_01', '<p>TC_01-result.png</p>'));
  assert.deepStrictEqual(verify(readback, posted).missing, [{ name: 'TC_01-result.png', why: 'plain-filename' }]);
});

test('capture-failed entries are plain on purpose and are not counted', () => {
  const html = table(row('TC_01', figure('TC_01-result.png')), row('TC_02', '<p>TC_02-capture-failed.png (screenshot capture failed — 3/3 attempts, timeout)</p>'));
  const r = verify(html);
  assert.deepStrictEqual(r.expected, ['TC_01-result.png']);
  assert.deepStrictEqual(r.missing, []);
});

test('a media node whose name Jira dropped still counts for one missing name', () => {
  const posted = table(row('TC_01', figure('TC_01-result.png')));
  const readback = table(row('TC_01', '<figure><div data-type="media" data-media-type="file" data-id="x"></div></figure>'));
  assert.deepStrictEqual(verify(readback, posted).missing, []);
});

test('entities in a name are decoded; no references at all is a failure', () => {
  assert.deepStrictEqual(verify(table(row('TC_01', figure('TC_01-a&amp;b.png')))).expected, ['TC_01-a&b.png']);
  const r = run([write('none.html', table(row('TC_01', '<p>no proof</p>')))]);
  assert.strictEqual(r.code, 1);
  assert.deepStrictEqual(r.out, ['NONE no screenshot references found', 'embedded 0/0']);
});

test('reads the JSON that listJiraIssueComments returns, wrapped or not, and picks the comment by id', () => {
  const a = table(row('TC_01', figure('TC_01-result.png', true)));
  const b = table(row('TC_02', '<p>TC_02-result.png</p>'));
  const list = { data: { comments: [{ id: '1', body: a }, { id: '2', body: b }] } };
  const wrapped = JSON.stringify([{ type: 'text', text: JSON.stringify(list) }]);
  assert.strictEqual(bodyOf(JSON.stringify(list), '1'), a);
  assert.strictEqual(bodyOf(wrapped, '2'), b);
  assert.throws(() => bodyOf(wrapped, '3'), /not found/);
  assert.throws(() => bodyOf(wrapped), /--comment-id/);
  assert.strictEqual(run([write('list.json', wrapped), '--comment-id', '1']).code, 0);
  assert.strictEqual(run([write('list2.json', wrapped), '--comment-id', '2']).code, 1);
  assert.strictEqual(bodyOf(JSON.stringify({ data: { commentId: '1', body: a } })), a);
});

test('usage errors exit 2', () => {
  assert.strictEqual(run([]).code, 2);
  assert.strictEqual(run([path.join(tmp, 'missing.html')]).code, 2);
});
