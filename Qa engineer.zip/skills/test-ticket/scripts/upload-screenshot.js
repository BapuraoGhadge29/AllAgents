#!/usr/bin/env node
/**
 * Upload a screenshot to a Jira issue as an attachment.
 * Uses Node.js 18+ native fetch + FormData — no npm dependencies.
 *
 * Credentials read from JIRA_EMAIL + JIRA_API_TOKEN environment variables.
 * Set them in ~/.claude/settings.json env block or as OS environment variables.
 * Claude never sees or passes the token — only issue_key and file_path are arguments.
 *
 * Usage:
 *   node upload-screenshot.js <issue_key> <file_path>
 *
 * Exits 0 on success (prints uploaded filename to stdout).
 * Exits 1 on failure (prints error to stderr).
 */

const [, , issueKey, filePath] = process.argv;

if (!issueKey || !filePath) {
  process.stderr.write('Usage: node upload-screenshot.js <issue_key> <file_path>\n');
  process.exit(1);
}

const fs   = require('fs');
const path = require('path');

if (path.extname(filePath).toLowerCase() !== '.png') {
  process.stderr.write('Only .png files are accepted\n');
  process.exit(1);
}

function loadCredentials() {
  let email    = process.env.JIRA_EMAIL    || '';
  let apiToken = process.env.JIRA_API_TOKEN || '';
  if (!email || !apiToken) {
    try {
      const home = process.env.USERPROFILE || process.env.HOME || '';
      if (!home) throw new Error('no home dir');
      const settingsPath = path.join(home, '.claude', 'settings.json');
      const s = JSON.parse(fs.readFileSync(settingsPath, 'utf8'));
      if (s && s.env) {
        email    = email    || s.env.JIRA_EMAIL    || '';
        apiToken = apiToken || s.env.JIRA_API_TOKEN || '';
      }
    } catch { /* settings.json unreadable — fall through */ }
  }
  return { email, apiToken };
}
const { email, apiToken } = loadCredentials();

if (!email || !apiToken) {
  process.stderr.write('Missing JIRA_EMAIL or JIRA_API_TOKEN. Set them in ~/.claude/settings.json env block or as OS environment variables.\n');
  process.exit(1);
}

if (!fs.existsSync(filePath)) {
  process.stderr.write(`File not found: ${filePath}\n`);
  process.exit(1);
}

const fileBytes = fs.readFileSync(filePath);
const fileName  = path.basename(filePath);

const form = new FormData();
form.append('file', new Blob([fileBytes], { type: 'image/png' }), fileName);

const auth = Buffer.from(`${email}:${apiToken}`).toString('base64');
const url  = `https://maxxton.atlassian.net/rest/api/3/issue/${encodeURIComponent(issueKey)}/attachments`;

fetch(url, {
  method:  'POST',
  headers: {
    Authorization:       `Basic ${auth}`,
    'X-Atlassian-Token': 'no-check',
  },
  body: form,
})
  .then(res => {
    if (!res.ok) {
      process.stderr.write(`Jira API error ${res.status} uploading to ${encodeURIComponent(issueKey)}\n`);
      process.exit(1);
    }
    return res.json();
  })
  .then(data => {
    const attachment = Array.isArray(data) ? data[0] : data;
    process.stdout.write(attachment.filename + '\n');
  })
  .catch(err => {
    process.stderr.write(`Upload failed: ${err.message}\n`);
    process.exit(1);
  });
