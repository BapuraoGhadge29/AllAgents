#!/usr/bin/env node
/**
 * Tests for bill-diff.js. Self-contained: node:test + node:assert.
 * Run: node plugins/qa-engineer/skills/test-ticket/scripts/bill-diff.test.js
 */
'use strict';

const test = require('node:test');
const assert = require('node:assert');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { spawnSync } = require('child_process');
const { diff, normalizeSnapshot, InputError } = require('./bill-diff');

const SCRIPT = path.join(__dirname, 'bill-diff.js');
const snap = (lines, totals) => normalizeSnapshot({ lines, totals }, 'snapshot');
const line = (description, extra) => Object.assign({ description, billLineType: 100, payerType: 'CUSTOMER' }, extra);
const mar = (extra) => line('minimum accommodation rate adjustment', Object.assign({ billLineType: 200, internal: true }, extra));

function run(from, to, args) {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'bill-diff-'));
  const fromFile = path.join(dir, 'from.json');
  const toFile = path.join(dir, 'to.json');
  fs.writeFileSync(fromFile, typeof from === 'string' ? from : JSON.stringify(from));
  fs.writeFileSync(toFile, typeof to === 'string' ? to : JSON.stringify(to));
  const r = spawnSync(process.execPath, [SCRIPT, fromFile, toFile].concat(args || []), { encoding: 'utf8' });
  fs.rmSync(dir, { recursive: true, force: true });
  return r;
}

test('identical snapshots: no change, nothing unexpected', () => {
  const a = snap([line('Accommodation', { total: 100, totalVat: 9 })], { Total: 109 });
  const r = diff(a, a);
  assert.strictEqual(r.identical, true);
  assert.strictEqual(r.summary, 'no change');
  assert.deepStrictEqual(r.unexpected, []);
});

test('a moved MAR line is one changed line with its amount and dates, not a removal plus an addition', () => {
  const from = snap([mar({ total: 407, startDate: '2026-11-02', endDate: '2026-11-06' })]);
  const to = snap([mar({ total: 347.82, startDate: '2026-11-03', endDate: '2026-11-06' })]);
  const r = diff(from, to, { expect: ['minimum accommodation'] });
  assert.strictEqual(r.changed.length, 1);
  assert.deepStrictEqual(r.added, []);
  assert.deepStrictEqual(r.removed, []);
  assert.deepStrictEqual(Object.keys(r.changed[0].fields).sort(), ['startDate', 'total']);
  assert.strictEqual(r.changed[0].fields.total.delta, -59.18);
  assert.deepStrictEqual(r.unexpected, []);
  assert.match(r.summary, /minimum accommodation rate adjustment \(Internal Bill\): total 407\.00 to 347\.82 \(-59\.18\), from 2026-11-02 to 2026-11-03/);
});

test('a total that moves without being expected is unexpected (the MXTS-81495 shape)', () => {
  const from = snap([mar({ total: 444 })], { Total: 947.72 });
  const to = snap([mar({ total: 338.08 })], { Total: 847.72 });
  const r = diff(from, to, { expect: ['minimum accommodation'] });
  assert.deepStrictEqual(r.unexpected, ['Total']);
  assert.match(r.summary, /^Total 947\.72 to 847\.72 \(-100\.00\)/);
});

test('with no --expect every change is unexpected', () => {
  const r = diff(snap([line('Rent', { total: 10 })]), snap([line('Rent', { total: 11 })]));
  assert.deepStrictEqual(r.unexpected, ['Rent']);
});

test('VAT changing while the total stays put is still a change', () => {
  const r = diff(snap([line('Rent', { total: 100, totalVat: 9, vatRate: 9 })]), snap([line('Rent', { total: 100, totalVat: 21, vatRate: 21 })]));
  assert.deepStrictEqual(Object.keys(r.changed[0].fields).sort(), ['totalVat', 'vatRate']);
  assert.match(r.summary, /VAT 9\.00 to 21\.00 \(\+12\.00\), VAT rate 9 to 21/);
});

test('a removed and an added line are reported, and an expected one is not unexpected', () => {
  const from = snap([line('Rent', { total: 100 }), line('Test Fixed Discount', { total: -100 })]);
  const to = snap([line('Rent', { total: 100 }), line('Towel package', { total: 12.75 })]);
  const r = diff(from, to, { expect: ['towel'] });
  assert.deepStrictEqual(r.removed.map((x) => x.line), ['Test Fixed Discount']);
  assert.deepStrictEqual(r.added.map((x) => x.line), ['Towel package']);
  assert.deepStrictEqual(r.unexpected, ['removed: Test Fixed Discount']);
  assert.match(r.summary, /added Towel package total 12\.75; removed Test Fixed Discount total -100\.00/);
});

test('tolerance: a difference under half a cent is equal, a cent is not', () => {
  const from = snap([line('Rent', { total: 100 })]);
  assert.strictEqual(diff(from, snap([line('Rent', { total: 100.004 })])).identical, true);
  assert.strictEqual(diff(from, snap([line('Rent', { total: 100.01 })])).identical, false);
  assert.strictEqual(diff(from, snap([line('Rent', { total: 100.01 })]), { tolerance: 0.05 }).identical, true);
});

test('lines with the same description pair by start date, so one night changing is one change', () => {
  const night = (d, total) => line('Accommodation', { startDate: d, total });
  const from = snap([night('2026-11-03', 90), night('2026-11-02', 80), night('2026-11-04', 100)]);
  const to = snap([night('2026-11-02', 80), night('2026-11-03', 90), night('2026-11-04', 300)]);
  const r = diff(from, to);
  assert.strictEqual(r.changed.length, 1);
  assert.strictEqual(r.changed[0].fields.total.from, 100);
  assert.strictEqual(r.changed[0].fields.total.to, 300);
});

test('the Internal Bill line and the customer line of the same name are different lines', () => {
  const from = snap([line('Rent', { total: 10 }), line('Rent', { total: 20, internal: true })]);
  const to = snap([line('Rent', { total: 10 }), line('Rent', { total: 25, internal: true })]);
  const r = diff(from, to);
  assert.deepStrictEqual(r.changed.map((c) => c.line), ['Rent (Internal Bill)']);
});

test('a field present on one side only counts as a change', () => {
  const r = diff(snap([line('Rent', { total: 100 })]), snap([line('Rent', { total: 100, totalVat: 9 })]));
  assert.deepStrictEqual(Object.keys(r.changed[0].fields), ['totalVat']);
  assert.match(r.summary, /VAT none to 9\.00/);
});

test('the summary has no pipe and no line break, and is capped by --max-lines', () => {
  const from = snap([line('A|B', { total: 1 }), line('C', { total: 1 }), line('D', { total: 1 })]);
  const to = snap([line('A|B', { total: 2 }), line('C', { total: 2 }), line('D', { total: 2 })]);
  const r = diff(from, to, { maxLines: 2 });
  assert.doesNotMatch(r.summary, /[|\r\n]/);
  assert.match(r.summary, /\(\+1 more\)$/);
});

test('input: a bare array is a list of lines; bad shapes are InputErrors', () => {
  assert.strictEqual(normalizeSnapshot([line('Rent', { total: 1 })], 's').lines.length, 1);
  assert.throws(() => normalizeSnapshot({ lines: [] }, 's'), InputError);
  assert.throws(() => normalizeSnapshot({ lines: [line('Rent', { total: 'abc' })] }, 's'), InputError);
  assert.throws(() => normalizeSnapshot({ lines: 'x' }, 's'), InputError);
  assert.throws(() => normalizeSnapshot({ totals: { Total: 'x' } }, 's'), InputError);
});

test('CLI: exit 0 when only expected lines moved, 2 when something unexpected moved, 1 on bad input', () => {
  const from = { lines: [line('Rent', { total: 100 }), mar({ total: 50 })], totals: { Total: 150 } };
  const expectedMove = { lines: [line('Rent', { total: 100 }), mar({ total: 30 })], totals: { Total: 150 } };
  const ok = run(from, expectedMove, ['--expect', 'minimum accommodation']);
  assert.strictEqual(ok.status, 0);
  assert.strictEqual(JSON.parse(ok.stdout).changed.length, 1);

  const bad = run(from, { lines: [line('Rent', { total: 100 }), mar({ total: 30 })], totals: { Total: 130 } }, ['--expect=minimum accommodation']);
  assert.strictEqual(bad.status, 2);
  assert.deepStrictEqual(JSON.parse(bad.stdout).unexpected, ['Total']);

  assert.strictEqual(run(from, 'not json').status, 1);
  assert.strictEqual(run(from, { lines: [] }).status, 1);
  assert.strictEqual(run(from, from, ['--tolerance', '-1']).status, 1);
  assert.strictEqual(run(from, from, ['--nope']).status, 1);
});
