#!/usr/bin/env node
/**
 * bill-diff.js — compares two snapshots of a reservation's bill (before and after a change, or before and after
 * "Recalculate reservation") line by line, VAT included. The model captures the snapshots; this script does the
 * arithmetic, so the Actual Result carries exact numbers instead of figures read off a screenshot.
 *
 *   node bill-diff.js <from.json> <to.json> [--expect <text>]... [--tolerance <amount>] [--max-lines <n>]
 *
 * snapshot: { "lines":  [ { "description": "...", "billLineType": 200, "payerType": "CUSTOMER", "internal": false,
 *                           "startDate": "2026-11-03", "endDate": "2026-11-06", "quantity": 1,
 *                           "value": 0, "total": 347.82, "totalVat": 0, "vatRate": 0, "overrideValue": null } ],
 *             "totals": { "Sub-total": 797.46, "Total": 847.72 } }
 *   A bare array is read as { "lines": [...] }. Every field of a line is optional: a field present on one side only
 *   counts as a change. `totals` holds the figures read off the screen (Sub-total, Total, First payment, header).
 *   Lines are paired by Bill type + Payer + description + Internal-Bill flag, then by start date within a group, so a
 *   line whose dates moved is one changed line, not one removed and one added.
 *
 * --expect <text>  (repeatable) a line description or total name, as a case-insensitive substring, that the TC's
 *                  Expected Result says may change. Anything else that changed is `unexpected`.
 * --tolerance      amounts closer than this are equal (default 0.005, half a cent).
 * --max-lines      how many entries the one-line `summary` spells out before "(+n more)" (default 8).
 *
 * Prints one JSON document: { identical, changed, added, removed, totals, unexpected, summary }.
 * `summary` is one line with no "|" and no line break, safe to paste into the Actual Result cell.
 * Exit 0 = nothing unexpected changed. Exit 2 = at least one unexpected change (`unexpected` lists them).
 * Exit 1 = input the script cannot trust (unreadable or non-JSON file, empty snapshot, bad option; reason on stderr).
 */

'use strict';

const fs = require('fs');

const NUMERIC = ['quantity', 'value', 'total', 'totalVat', 'vatRate', 'overrideValue'];
const TEXT = ['startDate', 'endDate'];
const FIELDS = ['total', 'totalVat', 'vatRate', 'value', 'quantity', 'overrideValue', 'startDate', 'endDate'];
const AMOUNTS = new Set(['total', 'totalVat', 'value', 'overrideValue']);
const FIELD_NAME = {
  total: 'total', totalVat: 'VAT', vatRate: 'VAT rate', value: 'value', quantity: 'quantity',
  overrideValue: 'override', startDate: 'from', endDate: 'to',
};
const DEFAULT_TOLERANCE = 0.005;
const DEFAULT_MAX_LINES = 8;

class InputError extends Error {}

function isNumber(x) { return typeof x === 'number' && Number.isFinite(x); }

function textOf(x) { return x === undefined || x === null ? '' : String(x).trim(); }

/** Turn one snapshot (parsed JSON) into { lines, totals } with every line normalised. */
function normalizeSnapshot(raw, name) {
  const doc = Array.isArray(raw) ? { lines: raw } : raw;
  if (!doc || typeof doc !== 'object') throw new InputError(name + ' must be a JSON object or array');
  const rawLines = doc.lines === undefined ? [] : doc.lines;
  if (!Array.isArray(rawLines)) throw new InputError(name + ': "lines" must be an array');
  const lines = rawLines.map((l, i) => {
    if (!l || typeof l !== 'object' || Array.isArray(l)) throw new InputError(name + ': lines[' + i + '] must be an object');
    const out = {
      description: textOf(l.description),
      billLineType: textOf(l.billLineType),
      payerType: textOf(l.payerType),
      internal: l.internal === true,
      index: i,
    };
    for (const f of NUMERIC) {
      const v = l[f];
      if (v === undefined || v === null || v === '') continue;
      const n = typeof v === 'string' ? Number(v) : v;
      if (!isNumber(n)) throw new InputError(name + ': lines[' + i + '].' + f + ' is not a number');
      out[f] = n;
    }
    for (const f of TEXT) {
      if (l[f] !== undefined && l[f] !== null && l[f] !== '') out[f] = String(l[f]);
    }
    return out;
  });
  const rawTotals = doc.totals === undefined ? {} : doc.totals;
  if (!rawTotals || typeof rawTotals !== 'object' || Array.isArray(rawTotals)) throw new InputError(name + ': "totals" must be an object');
  const totals = {};
  for (const [k, v] of Object.entries(rawTotals)) {
    const n = typeof v === 'string' ? Number(v) : v;
    if (!isNumber(n)) throw new InputError(name + ': totals["' + k + '"] is not a number');
    totals[k] = n;
  }
  if (lines.length === 0 && Object.keys(totals).length === 0) throw new InputError(name + ' is empty: no lines and no totals');
  return { lines, totals };
}

function loadSnapshot(file) {
  let text;
  try { text = fs.readFileSync(file, 'utf8'); } catch (e) { throw new InputError('cannot read ' + file + ': ' + e.message); }
  let raw;
  try { raw = JSON.parse(text.replace(/^﻿/, '')); } catch (e) { throw new InputError(file + ' is not valid JSON: ' + e.message); }
  return normalizeSnapshot(raw, file);
}

const keyOf = (l) => [l.internal ? 'internal' : 'customer', l.billLineType, l.payerType, l.description.toLowerCase()].join('|');
const labelOf = (l) => (l.description || (l.billLineType ? 'bill line type ' + l.billLineType : '(unnamed line)')) + (l.internal ? ' (Internal Bill)' : '');

function group(lines) {
  const groups = new Map();
  for (const l of lines) {
    const k = keyOf(l);
    if (!groups.has(k)) groups.set(k, []);
    groups.get(k).push(l);
  }
  for (const members of groups.values()) {
    members.sort((a, b) => (a.startDate || '').localeCompare(b.startDate || '') || a.index - b.index);
  }
  return groups;
}

function valuesDiffer(field, a, b, tolerance) {
  if (a === undefined && b === undefined) return false;
  if (a === undefined || b === undefined) return true;
  return NUMERIC.includes(field) ? Math.abs(a - b) > tolerance : a !== b;
}

function fmt(field, v) {
  if (v === undefined) return 'none';
  return AMOUNTS.has(field) ? v.toFixed(2) : String(v);
}

function signed(n) { return (n >= 0 ? '+' : '-') + Math.abs(n).toFixed(2); }

function fieldText(field, change, name) {
  const base = (name || FIELD_NAME[field]) + ' ' + fmt(field, change.from) + ' to ' + fmt(field, change.to);
  return AMOUNTS.has(field) && change.delta !== undefined ? base + ' (' + signed(change.delta) + ')' : base;
}

/** Compare two normalised snapshots. */
function diff(from, to, options) {
  const opts = options || {};
  const tolerance = opts.tolerance === undefined ? DEFAULT_TOLERANCE : opts.tolerance;
  const maxLines = opts.maxLines === undefined ? DEFAULT_MAX_LINES : opts.maxLines;
  const expects = (opts.expect || []).map((e) => String(e).trim().toLowerCase()).filter(Boolean);

  const changed = [];
  const added = [];
  const removed = [];
  const before = group(from.lines);
  const after = group(to.lines);

  for (const [k, members] of before) {
    const others = after.get(k) || [];
    members.forEach((a, i) => {
      const b = others[i];
      if (!b) { removed.push({ line: labelOf(a), total: a.total, totalVat: a.totalVat }); return; }
      const fields = {};
      for (const f of FIELDS) {
        if (!valuesDiffer(f, a[f], b[f], tolerance)) continue;
        fields[f] = { from: a[f], to: b[f] };
        if (NUMERIC.includes(f) && a[f] !== undefined && b[f] !== undefined) fields[f].delta = Math.round((b[f] - a[f]) * 1e6) / 1e6;
      }
      if (Object.keys(fields).length) changed.push({ line: labelOf(a), fields });
    });
  }
  for (const [k, members] of after) {
    const seen = (before.get(k) || []).length;
    members.slice(seen).forEach((b) => added.push({ line: labelOf(b), total: b.total, totalVat: b.totalVat }));
  }

  const totals = [];
  const names = new Set(Object.keys(from.totals).concat(Object.keys(to.totals)));
  for (const name of names) {
    const a = from.totals[name];
    const b = to.totals[name];
    if (!valuesDiffer('total', a, b, tolerance)) continue;
    const t = { name, from: a, to: b };
    if (a !== undefined && b !== undefined) t.delta = Math.round((b - a) * 1e6) / 1e6;
    totals.push(t);
  }

  const isExpected = (label) => expects.some((e) => label.toLowerCase().includes(e));
  const unexpected = []
    .concat(changed.map((c) => c.line), added.map((c) => 'added: ' + c.line), removed.map((c) => 'removed: ' + c.line), totals.map((t) => t.name))
    .filter((label) => !isExpected(label.replace(/^(added|removed): /, '')));

  const entries = []
    .concat(totals.map((t) => fieldText('total', t, t.name)))
    .concat(changed.map((c) => c.line + ': ' + FIELDS.filter((f) => c.fields[f]).map((f) => fieldText(f, c.fields[f])).join(', ')))
    .concat(added.map((a) => 'added ' + a.line + (a.total !== undefined ? ' total ' + a.total.toFixed(2) : '')))
    .concat(removed.map((r) => 'removed ' + r.line + (r.total !== undefined ? ' total ' + r.total.toFixed(2) : '')));
  const shown = entries.slice(0, maxLines);
  let summary = entries.length === 0 ? 'no change' : shown.join('; ') + (entries.length > shown.length ? ' (+' + (entries.length - shown.length) + ' more)' : '');
  summary = summary.replace(/[|\r\n]+/g, ' / ');

  return { identical: entries.length === 0, changed, added, removed, totals, unexpected, summary };
}

function parseArgs(argv) {
  const files = [];
  const opts = { expect: [] };
  for (let i = 0; i < argv.length; i++) {
    const arg = argv[i];
    const take = (name) => {
      if (arg.startsWith(name + '=')) return arg.slice(name.length + 1);
      if (arg === name) {
        if (i + 1 >= argv.length) throw new InputError(name + ' needs a value');
        return argv[++i];
      }
      return undefined;
    };
    let value;
    if ((value = take('--expect')) !== undefined) opts.expect.push(value);
    else if ((value = take('--tolerance')) !== undefined) {
      const n = Number(value);
      if (!isNumber(n) || n < 0) throw new InputError('--tolerance must be a number of 0 or more');
      opts.tolerance = n;
    } else if ((value = take('--max-lines')) !== undefined) {
      const n = Number(value);
      if (!Number.isInteger(n) || n < 1) throw new InputError('--max-lines must be an integer of 1 or more');
      opts.maxLines = n;
    } else if (arg.startsWith('--')) throw new InputError('unknown option ' + arg);
    else files.push(arg);
  }
  if (files.length !== 2) throw new InputError('usage: node bill-diff.js <from.json> <to.json> [--expect <text>]... [--tolerance <amount>] [--max-lines <n>]');
  return { files, opts };
}

module.exports = { diff, normalizeSnapshot, loadSnapshot, InputError };

if (require.main === module) {
  try {
    const { files, opts } = parseArgs(process.argv.slice(2));
    const result = diff(loadSnapshot(files[0]), loadSnapshot(files[1]), opts);
    process.stdout.write(JSON.stringify(result, null, 2) + '\n');
    process.exit(result.unexpected.length ? 2 : 0);
  } catch (e) {
    if (!(e instanceof InputError)) throw e;
    process.stderr.write('bill-diff: ' + e.message + '\n');
    process.exit(1);
  }
}
