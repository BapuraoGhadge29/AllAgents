#!/usr/bin/env node
/**
 * Idempotently create a Jira issue link via API v2. Checks for an existing link
 * of the same type between the same two issues before creating, so a re-run
 * (resume after crash, mid-run context compaction) can never create a duplicate link.
 *
 * Usage:
 *   node create-issue-link.js <outward_issue_key> <inward_issue_key> <link_type_name>
 *
 * Example:
 *   node create-issue-link.js MXTS-12346 MXTS-12345 Blocks
 *   → MXTS-12346 "Blocks" MXTS-12345 (MXTS-12346 is the fix task, MXTS-12345 is the story)
 *
 * Exits 0 in both of these cases (each prints a distinct marker on stdout):
 *   ALREADY_LINKED <link_type> <outward> -> <inward>  — matching link already exists; no-op
 *   LINKED <link_type> <outward> -> <inward>           — link created
 * Exits 1 on bad args or API error (failed closed).
 */

const [, , outwardKey, inwardKey, linkTypeName] = process.argv;

if (!outwardKey || !inwardKey || !linkTypeName) {
  process.stderr.write('Usage: node create-issue-link.js <outward_issue_key> <inward_issue_key> <link_type_name>\n');
  process.exit(1);
}

const fs   = require('fs');
const path = require('path');

function loadCredentials() {
  let email    = process.env.JIRA_EMAIL    || '';
  let apiToken = process.env.JIRA_API_TOKEN || '';
  if (!email || !apiToken) {
    try {
      const home = process.env.USERPROFILE || process.env.HOME || '';
      if (!home) throw new Error('no home dir');
      const settingsPath = path.join(home, '.claude', 'settings.json');
      const s = JSON.parse(fs.readFileSync(settingsPath, 'utf8'));
      if (s && s.env) {
        email    = email    || s.env.JIRA_EMAIL    || '';
        apiToken = apiToken || s.env.JIRA_API_TOKEN || '';
      }
    } catch { /* settings.json unreadable — fall through */ }
  }
  return { email, apiToken };
}

const { email, apiToken } = loadCredentials();
if (!email || !apiToken) {
  process.stderr.write('Missing JIRA_EMAIL or JIRA_API_TOKEN.\n');
  process.exit(1);
}

const auth    = Buffer.from(`${email}:${apiToken}`).toString('base64');
const headers = { Authorization: `Basic ${auth}`, 'Content-Type': 'application/json', Accept: 'application/json' };
const BASE    = 'https://maxxton.atlassian.net/rest/api/2';

(async () => {
  try {
    // Guard: check the outward issue's existing links for a matching type + target.
    const res = await fetch(`${BASE}/issue/${encodeURIComponent(outwardKey)}?fields=issuelinks`, { headers });
    if (!res.ok) throw new Error(`GET issuelinks failed: ${res.status}`);
    const data = await res.json();
    const links = data.fields?.issuelinks || [];
    const already = links.some(l =>
      (l.type?.name || '').toLowerCase() === linkTypeName.toLowerCase() &&
      (l.outwardIssue?.key === inwardKey || l.inwardIssue?.key === inwardKey)
    );
    if (already) {
      process.stdout.write(`ALREADY_LINKED ${linkTypeName} ${outwardKey} -> ${inwardKey}\n`);
      return;
    }

    const createRes = await fetch(`${BASE}/issueLink`, {
      method: 'POST', headers,
      body: JSON.stringify({
        type: { name: linkTypeName },
        outwardIssue: { key: outwardKey },
        inwardIssue: { key: inwardKey },
      }),
    });
    if (!createRes.ok) {
      const t = await createRes.text();
      throw new Error(`create link failed: ${createRes.status} ${t}`);
    }
    process.stdout.write(`LINKED ${linkTypeName} ${outwardKey} -> ${inwardKey}\n`);
  } catch (err) {
    process.stderr.write(`❌ create-issue-link.js — ${err.message}\nLink not confirmed (failed closed).\n`);
    process.exit(1);
  }
})();
