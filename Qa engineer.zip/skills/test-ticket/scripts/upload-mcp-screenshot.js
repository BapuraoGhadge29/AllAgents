#!/usr/bin/env node
/**
 * Upload screenshots to Atlassian Media on the MCP write path (no Jira token).
 *
 * The Atlassian MCP's `uploadAttachmentToJiraIssue` (phase 1) returns an `uploadCommand`: a `curl` that
 * carries a short-lived upload token (about 20 minutes, scoped to the user's whole upload collection). This
 * script checks that command, runs curl for it and records the resulting `fileId` in `uploaded-files.json`.
 * Claude never has to judge a command by eye, never runs it through a shell, and the token is never printed
 * or stored.
 *
 * A command is accepted only when all of these hold (anything else is `rejected`, curl is not started):
 *   - one `curl` command on one line; arguments are bare options or single-quoted with no `'` inside
 *   - exactly one URL: https://api.media.atlassian.com/file/binary?collection=...&name=... (plain characters only)
 *   - exactly one file argument, `--data-binary '@<file>'` or `-F|--form '<field>=@<file>'`, and that file is an
 *     existing .png/.jpg/.jpeg below --root whose basename equals the `name` in the URL
 *   - headers only Accept, Authorization and X-Client-Id
 *   - options only --location/-L, -X POST, -H/--header, --data-binary, -F/--form, -s, -S, --silent, --show-error
 *   - apart from the URL and the file path, none of $ ` ; & | < > ( ) or a line break appears
 * `--location`/`-L` is dropped before curl runs: a redirect would carry the Authorization header to another host.
 *
 * Two modes:
 *   per command (default)  stdin holds one command per line, each minted for its own file; one upload per line.
 *   batch (--dir <dir>)    stdin holds ONE command. Its token uploads every image below <dir> that has no
 *                          reusable entry in the state file: for each file the script swaps the URL's `name` and
 *                          the file argument and keeps the headers. An entry is reusable when the file is not
 *                          newer than its upload and either `embedded` is true or the media API still holds the
 *                          upload (GET /file/<fileId>?collection=... answers 200 with processingStatus succeeded;
 *                          how long an unembedded upload lives is not documented, so the script asks).
 *
 * Usage:
 *   node upload-mcp-screenshot.js --state test-output/<EPIC_ID>/uploaded-files.json [--root test-output] [--check-only] <<'EOF'
 *   <uploadCommand 1>
 *   <uploadCommand 2>
 *   EOF
 *   node upload-mcp-screenshot.js --state ... --root test-output --dir test-output/<STORY_KEY> [--budget <seconds>] <<'EOF'
 *   <uploadCommand>
 *   EOF
 *
 * stdout, one line per file (never the command or the token):
 *   OK <key> <fileId>                        uploaded and recorded; <key> is the file's path below --root
 *   FAIL <key|-> <class> <detail>            class: rejected | host-unreachable | token-expired | error
 *   STOP <class> <n> files not attempted     batch only: host-unreachable, token-expired or budget ended the run
 *   skipped <n>                              batch only: files that already have a reusable entry
 *   done <ok>/<total>                        total = files that needed an upload
 * Exit 0 when everything that needed an upload succeeded, 1 when anything failed or was not attempted,
 * 2 on a usage or state-file error. --check-only runs the checks, prints `OK <key> checked` and uploads nothing.
 */
'use strict';

const fs = require('fs');
const path = require('path');
const { spawnSync } = require('child_process');

const MEDIA_HOST = 'api.media.atlassian.com';
const SAFE_URL_CHARS = /^[A-Za-z0-9._~%/?=&:-]+$/;
const SAFE_QUERY_PART = /^[A-Za-z0-9._~%-]*$/;
const SHELL_META = /[$`;&|<>()\r\n]/;
const HEADER = /^(Accept|Authorization|X-Client-Id): [^\r\n]+$/;
const IMAGE_EXT = new Set(['.png', '.jpg', '.jpeg']);
const BATCH_NAME = /^[A-Za-z0-9_][A-Za-z0-9_.-]*\.(?:png|jpe?g)$/i;
const NETWORK_EXITS = new Set([6, 7, 28, 35]);
const DEFAULT_BUDGET_S = 480;

function reject(reason) {
  return { ok: false, reason };
}

function tokenize(cmd) {
  const tokens = [];
  const re = /\s+(?:'([^']*)'|([^\s']+))/y;
  let pos = 'curl'.length;
  while (pos < cmd.length) {
    re.lastIndex = pos;
    const m = re.exec(cmd);
    if (!m) return null;
    tokens.push(m[1] !== undefined ? { quoted: true, v: m[1] } : { quoted: false, v: m[2] });
    pos = re.lastIndex;
  }
  return tokens;
}

function checkUrl(raw) {
  if (!SAFE_URL_CHARS.test(raw)) return reject('url has unexpected characters');
  let u;
  try {
    u = new URL(raw);
  } catch (e) {
    return reject('url does not parse');
  }
  if (u.protocol !== 'https:' || u.hostname !== MEDIA_HOST || u.port || u.username || u.password || u.hash) {
    return reject('url is not the Atlassian media host');
  }
  if (u.pathname !== '/file/binary') return reject('url path is not /file/binary');
  for (const [k, v] of u.searchParams) {
    if (!SAFE_QUERY_PART.test(k) || !SAFE_QUERY_PART.test(v)) return reject('url query has unexpected characters');
  }
  const collection = u.searchParams.get('collection');
  const name = u.searchParams.get('name');
  if (!collection || !name) return reject('url has no collection or name');
  return { ok: true, collection, name };
}

function keyBelow(rootReal, fileReal) {
  const rel = path.relative(rootReal, fileReal);
  if (!rel || rel.startsWith('..') || path.isAbsolute(rel)) return null;
  return rel.split(path.sep).join('/');
}

function checkFile(argPath, root, urlName) {
  let file;
  let rootReal;
  try {
    file = fs.realpathSync(path.resolve(argPath));
    rootReal = fs.realpathSync(path.resolve(root));
  } catch (e) {
    return reject('file or root does not exist');
  }
  const key = keyBelow(rootReal, file);
  if (!key) return reject('file is outside the screenshot root');
  if (!fs.statSync(file).isFile()) return reject('file is not a regular file');
  if (!IMAGE_EXT.has(path.extname(file).toLowerCase())) return reject('file is not an image');
  if (path.basename(file) !== urlName) return reject('url name does not match the file name');
  return { ok: true, file, key };
}

/**
 * @returns {{ok:true, args:string[], key:string, collection:string, file:string, urlIndex:number, fileIndex:number, filePrefix:string}|{ok:false, reason:string}}
 */
function checkUploadCommand(cmd, root) {
  if (typeof cmd !== 'string' || !cmd.startsWith('curl ')) return reject('not a curl command');
  if (/[\r\n]/.test(cmd)) return reject('not a single line');
  const tokens = tokenize(cmd);
  if (!tokens) return reject('arguments do not parse');

  const args = [];
  let url = null;
  let urlIndex = -1;
  let filePath = null;
  let fileIndex = -1;
  let filePrefix = '';
  for (let i = 0; i < tokens.length; i++) {
    const t = tokens[i];
    if (t.quoted) {
      if (url !== null) return reject('more than one url');
      url = t.v;
      args.push(t.v);
      urlIndex = args.length - 1;
      continue;
    }
    const next = () => tokens[++i];
    switch (t.v) {
      case '--location':
      case '-L':
      case '-s':
      case '-S':
      case '--silent':
      case '--show-error':
        break;
      case '-X': {
        const n = next();
        if (!n || n.quoted || n.v !== 'POST') return reject('-X is not POST');
        args.push('-X', 'POST');
        break;
      }
      case '-H':
      case '--header': {
        const n = next();
        if (!n || !n.quoted || !HEADER.test(n.v) || SHELL_META.test(n.v)) return reject('header not allowed');
        args.push(t.v, n.v);
        break;
      }
      case '--data-binary':
      case '-F':
      case '--form': {
        const n = next();
        const m = n && n.quoted && (t.v === '--data-binary' ? /^@(.+)$/ : /^[A-Za-z]+=@(.+)$/).exec(n.v);
        if (!m) return reject('file argument is not @<file>');
        if (m[1] === '-') return reject('file argument reads stdin');
        if (filePath !== null) return reject('more than one file argument');
        filePath = m[1];
        filePrefix = n.v.slice(0, n.v.indexOf('@') + 1);
        args.push(t.v, n.v);
        fileIndex = args.length - 1;
        break;
      }
      default:
        return reject(`option not allowed: ${t.v.slice(0, 24)}`);
    }
  }
  if (url === null) return reject('no url');
  if (filePath === null) return reject('no file argument');

  const u = checkUrl(url);
  if (!u.ok) return u;
  const f = checkFile(filePath, root, u.name);
  if (!f.ok) return f;
  if (SHELL_META.test(cmd.split(url).join('').split(filePath).join(''))) return reject('forbidden character');
  return { ok: true, args, key: f.key, collection: u.collection, file: f.file, urlIndex, fileIndex, filePrefix };
}

function runCurl(args) {
  const r = spawnSync('curl', ['-sS', '--max-time', '120', '-w', '\n%{http_code}', ...args], {
    encoding: 'utf8',
    maxBuffer: 1 << 20,
  });
  return { exit: r.error ? -1 : r.status, stdout: r.stdout || '', stderr: r.stderr || '' };
}

function brief(text) {
  return String(text).split('\n')[0].replace(/Bearer\s+\S+/gi, 'Bearer ***').slice(0, 120);
}

function readResult(res) {
  if (res.exit !== 0) {
    const cls = NETWORK_EXITS.has(res.exit) ? 'host-unreachable' : 'error';
    return { cls, detail: `curl exit ${res.exit} ${brief(res.stderr)}`.trim() };
  }
  const lines = res.stdout.split('\n');
  const code = Number(lines.pop().trim());
  const body = lines.join('\n');
  if (/Host not in allowlist/i.test(body)) return { cls: 'host-unreachable', detail: 'Host not in allowlist' };
  if (code === 401 || code === 403) return { cls: 'token-expired', detail: `HTTP ${code}` };
  if (!(code >= 200 && code < 300)) return { cls: 'error', detail: `HTTP ${code || '?'} ${brief(body)}`.trim() };
  try {
    const id = JSON.parse(body).data.id;
    if (typeof id === 'string' && id) return { id };
  } catch (e) {
    /* falls through */
  }
  return { cls: 'error', detail: `no data.id in response ${brief(body)}` };
}

function readState(stateFile) {
  try {
    return JSON.parse(fs.readFileSync(stateFile, 'utf8'));
  } catch (e) {
    if (e.code === 'ENOENT') return {};
    throw e;
  }
}

function recordEntry(stateFile, key, entry) {
  const state = readState(stateFile);
  state[key] = entry;
  fs.mkdirSync(path.dirname(stateFile), { recursive: true });
  const tmp = `${stateFile}.tmp`;
  fs.writeFileSync(tmp, `${JSON.stringify(state, null, 2)}\n`);
  fs.renameSync(tmp, stateFile);
}

/** Runs curl for already-checked args and records the result: {ok, cls?, line}. */
function transfer(args, key, collection, opts, run) {
  const result = readResult(run(args));
  if (!result.id) return { ok: false, cls: result.cls, line: `FAIL ${key} ${result.cls} ${result.detail}` };
  recordEntry(opts.state, key, {
    fileId: result.id,
    collection,
    uploaded_at: new Date().toISOString(),
    embedded: false,
  });
  return { ok: true, line: `OK ${key} ${result.id}` };
}

function uploadOne(cmd, opts, run = runCurl) {
  const check = checkUploadCommand(cmd, opts.root);
  if (!check.ok) return { ok: false, line: `FAIL - rejected ${check.reason}` };
  if (opts.checkOnly) return { ok: true, line: `OK ${check.key} checked` };
  return transfer(check.args, check.key, check.collection, opts, run);
}

/** Does the media API still hold this upload and has it processed it? Read-only GET with the command's own headers. */
function stillThere(entry, headers, run) {
  if (!/^[0-9a-f-]{36}$/i.test(String(entry.fileId)) || !/^[A-Za-z0-9._-]+$/.test(String(entry.collection))) return false;
  const url = `https://${MEDIA_HOST}/file/${entry.fileId}?collection=${entry.collection}`;
  const res = run([...headers, url]);
  if (res.exit !== 0) return false;
  const lines = res.stdout.split('\n');
  if (Number(lines.pop().trim()) !== 200) return false;
  try {
    return JSON.parse(lines.join('\n')).data.processingStatus === 'succeeded';
  } catch (e) {
    return false;
  }
}

/**
 * An entry is reusable when its file is not newer than the upload and the upload is either embedded in a posted
 * comment (attached to the issue for good) or still present in the media store. How long an unembedded upload
 * lives is not documented, so it is asked, not assumed. --check-only cannot ask and treats those as not reusable.
 */
function reusable(entry, file, headers, opts, run) {
  if (!entry || !entry.uploaded_at) return false;
  const uploadedAt = Date.parse(entry.uploaded_at);
  if (Number.isNaN(uploadedAt) || fs.statSync(file).mtimeMs > uploadedAt) return false;
  if (entry.embedded === true) return true;
  return opts.checkOnly ? false : stillThere(entry, headers, run);
}

function imagesBelow(dir, rootReal) {
  const found = [];
  const walk = (d) => {
    for (const e of fs.readdirSync(d, { withFileTypes: true })) {
      const p = path.join(d, e.name);
      if (e.isDirectory()) walk(p);
      else if (IMAGE_EXT.has(path.extname(e.name).toLowerCase())) {
        const real = fs.realpathSync(p);
        const key = keyBelow(rootReal, real);
        if (key) found.push({ file: real, key });
      }
    }
  };
  walk(dir);
  return found.sort((a, b) => (a.key < b.key ? -1 : 1));
}

/** One command's token uploads every image below opts.dir that has no reusable entry. */
function uploadDir(cmd, opts, run = runCurl) {
  const out = { lines: [], ok: 0, total: 0, skipped: 0, failed: false };
  const check = checkUploadCommand(cmd, opts.root);
  if (!check.ok) {
    out.lines.push(`FAIL - rejected ${check.reason}`);
    out.failed = true;
    return out;
  }
  let rootReal;
  let dirReal;
  try {
    rootReal = fs.realpathSync(path.resolve(opts.root));
    dirReal = fs.realpathSync(path.resolve(opts.dir));
  } catch (e) {
    out.lines.push('FAIL - rejected directory or root does not exist');
    out.failed = true;
    return out;
  }
  if (dirReal !== rootReal && !keyBelow(rootReal, dirReal)) {
    out.lines.push('FAIL - rejected directory is outside the screenshot root');
    out.failed = true;
    return out;
  }
  const state = opts.state ? readState(opts.state) : {};
  const headers = [];
  check.args.forEach((a, i) => {
    if (a === '-H' || a === '--header') headers.push('-H', check.args[i + 1]);
  });
  const todo = [];
  for (const item of imagesBelow(dirReal, rootReal)) {
    if (reusable(state[item.key], item.file, headers, opts, run)) out.skipped++;
    else todo.push(item);
  }
  out.total = todo.length;
  const started = Date.now();
  for (let i = 0; i < todo.length; i++) {
    const { file, key } = todo[i];
    const left = todo.length - i;
    if (Date.now() - started > opts.budget * 1000) {
      out.lines.push(`STOP budget ${left} files not attempted`);
      out.failed = true;
      break;
    }
    if (!BATCH_NAME.test(path.basename(file))) {
      out.lines.push(`FAIL ${key} rejected unsupported file name`);
      out.failed = true;
      continue;
    }
    if (opts.checkOnly) {
      out.lines.push(`OK ${key} checked`);
      out.ok++;
      continue;
    }
    const args = check.args.slice();
    const u = new URL(args[check.urlIndex]);
    u.searchParams.set('name', path.basename(file));
    args[check.urlIndex] = u.toString();
    args[check.fileIndex] = `${check.filePrefix}${file}`;
    const r = transfer(args, key, check.collection, opts, run);
    out.lines.push(r.line);
    if (r.ok) {
      out.ok++;
      continue;
    }
    out.failed = true;
    if (r.cls === 'host-unreachable' || r.cls === 'token-expired') {
      if (left > 1) out.lines.push(`STOP ${r.cls} ${left - 1} files not attempted`);
      break;
    }
  }
  return out;
}

function parseArgs(argv) {
  const opts = { root: 'test-output', state: null, checkOnly: false, dir: null, budget: DEFAULT_BUDGET_S };
  for (let i = 0; i < argv.length; i++) {
    if (argv[i] === '--state') opts.state = argv[++i];
    else if (argv[i] === '--root') opts.root = argv[++i];
    else if (argv[i] === '--dir') opts.dir = argv[++i];
    else if (argv[i] === '--budget') opts.budget = Number(argv[++i]);
    else if (argv[i] === '--check-only') opts.checkOnly = true;
    else return null;
  }
  if (!opts.root || !(opts.budget > 0)) return null;
  return opts.state || opts.checkOnly ? opts : null;
}

function main() {
  const opts = parseArgs(process.argv.slice(2));
  if (!opts) {
    process.stderr.write('Usage: node upload-mcp-screenshot.js --state <uploaded-files.json> [--root <dir>] [--dir <dir> [--budget <seconds>]] [--check-only] < commands\n');
    process.exit(2);
  }
  const commands = fs.readFileSync(0, 'utf8').split(/\r?\n/).map((l) => l.trim()).filter(Boolean);
  try {
    if (opts.dir) {
      if (commands.length !== 1) {
        process.stdout.write('FAIL - rejected batch mode takes exactly one command on stdin\n');
        process.exit(1);
      }
      const r = uploadDir(commands[0], opts);
      for (const line of r.lines) process.stdout.write(`${line}\n`);
      if (r.skipped > 0) process.stdout.write(`skipped ${r.skipped}\n`);
      process.stdout.write(`done ${r.ok}/${r.total}\n`);
      process.exit(r.failed ? 1 : 0);
    }
    let ok = 0;
    for (const cmd of commands) {
      const r = uploadOne(cmd, opts);
      if (r.ok) ok++;
      process.stdout.write(`${r.line}\n`);
    }
    process.stdout.write(`done ${ok}/${commands.length}\n`);
    process.exit(ok === commands.length ? 0 : 1);
  } catch (e) {
    process.stdout.write(`FAIL - error state file not usable: ${brief(e.message)}\n`);
    process.exit(2);
  }
}

if (require.main === module) main();

module.exports = { checkUploadCommand, readResult, uploadOne, uploadDir };
