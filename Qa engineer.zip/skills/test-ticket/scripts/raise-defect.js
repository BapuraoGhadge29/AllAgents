#!/usr/bin/env node
/**
 * Create a Jira defect (Bug) or fix Task via API v2, behind mechanical guards so an
 * irreversible issue can never be created accidentally — including after context
 * compaction, when the confirmation gate or dedup step might otherwise be skipped.
 *
 * Guards (run before any issue is created — cannot be bypassed):
 *   1. Confirmation handshake — without --confirmed the script creates NOTHING; it
 *      prints the proposal and exits so the pipeline can show it and ask the user.
 *   2. Dedup re-check (Bug AND Task) — immediately before creating, re-runs an
 *      open-issue JQL of the same type for the issue's labels. If a matching open
 *      issue already carries any of these labels it REFUSES (never creates a
 *      duplicate). Fails closed if the check cannot run.
 *   3. Target/label validation — project required; every issue (Bug or Task) needs
 *      >=1 dedup label — Bug: <STORY_KEY>-<TC_ID> per TC in the cluster; Task: a single
 *      <STORY_KEY>-QA-FIX-TASK label — so a re-run (e.g. --retest after a crash) can
 *      never create a second Task for the same story's QA failures.
 *
 * Payload JSON file shape:
 *   { "project": "MXTS", "type": "Bug", "summary": "...", "description": "...",
 *     "labels": ["MXTS-123-TC_01", "MXTS-123-TC_07"],
 *     "extraLabels": ["QA_Pipeline_Bug"],
 *     "priority": "P2" }
 *
 * `priority` (optional) is the Jira priority *name* (Maxxton uses P1–P4). Omitted → the
 * project default applies. Phase 5 always sets it — the Exit Gate's open-P1/P2 count reads it.
 *
 * `labels` are the dedup-critical labels ONLY — every one of them is OR'd together
 * in the pre-create re-check (guard 2), so a duplicate-open-issue match on ANY one
 * of them blocks creation. Never put a label shared across unrelated defects (e.g.
 * a usage-tracking tag) in `labels` — the second such defect would falsely match
 * the first via that shared label and get blocked. `extraLabels` (optional) is for
 * exactly that case: applied to the created issue, excluded from the dedup query.
 *
 * Usage:
 *   node raise-defect.js <payload_json_file> [--confirmed]
 *
 * Exit 0  — created (prints issue key) | awaiting confirmation | duplicate blocked
 *           (each case prints a distinct marker on stdout)
 * Exit 1  — bad payload, dedup check failed (fail-closed), or API error
 */

const [, , payloadFile, ...flags] = process.argv;
const confirmed = flags.includes('--confirmed');

if (!payloadFile) {
  process.stderr.write('Usage: node raise-defect.js <payload_json_file> [--confirmed]\n');
  process.exit(1);
}

const fs   = require('fs');
const path = require('path');

function loadCredentials() {
  let email    = process.env.JIRA_EMAIL    || '';
  let apiToken = process.env.JIRA_API_TOKEN || '';
  if (!email || !apiToken) {
    try {
      const home = process.env.USERPROFILE || process.env.HOME || '';
      if (!home) throw new Error('no home dir');
      const settingsPath = path.join(home, '.claude', 'settings.json');
      const s = JSON.parse(fs.readFileSync(settingsPath, 'utf8'));
      if (s && s.env) {
        email    = email    || s.env.JIRA_EMAIL    || '';
        apiToken = apiToken || s.env.JIRA_API_TOKEN || '';
      }
    } catch { /* settings.json unreadable — fall through */ }
  }
  return { email, apiToken };
}

const { email, apiToken } = loadCredentials();
if (!email || !apiToken) {
  process.stderr.write('Missing JIRA_EMAIL or JIRA_API_TOKEN.\n');
  process.exit(1);
}

// ─── Load + validate payload ─────────────────────────────────────────────────

let payload;
try {
  payload = JSON.parse(fs.readFileSync(payloadFile, 'utf8'));
} catch (err) {
  process.stderr.write(`Cannot read/parse payload file: ${err.message}\n`);
  process.exit(1);
}

const project     = (payload.project || '').trim();
const type        = (payload.type || '').trim();
const summary     = (payload.summary || '').trim();
const description = payload.description || '';
const labels      = Array.isArray(payload.labels) ? payload.labels.filter(Boolean) : [];
const extraLabels = Array.isArray(payload.extraLabels) ? payload.extraLabels.filter(Boolean) : [];
const priority    = (payload.priority || '').trim();

const problems = [];
if (!project)                              problems.push('project is required');
if (!['Bug', 'Task'].includes(type))       problems.push('type must be "Bug" or "Task"');
if (!summary)                              problems.push('summary is required');
if (!description)                          problems.push('description is required');
if (labels.length === 0) problems.push('a dedup label is required — Bug: <STORY_KEY>-<TC_ID>; Task: <STORY_KEY>-QA-FIX-TASK');
if (problems.length > 0) {
  process.stderr.write(`❌ raise-defect.js BLOCKED — invalid payload:\n  - ${problems.join('\n  - ')}\n`);
  process.exit(1);
}

const auth    = Buffer.from(`${email}:${apiToken}`).toString('base64');
const headers = { Authorization: `Basic ${auth}`, 'Content-Type': 'application/json', Accept: 'application/json' };
const BASE    = 'https://maxxton.atlassian.net';

// ─── Guard 1: confirmation handshake (no network, creates nothing) ────────────

if (!confirmed) {
  process.stdout.write(
    `AWAITING_CONFIRMATION — nothing created.\n` +
    `Proposed ${type} on ${project}:\n` +
    `  Summary: ${summary}\n` +
    (priority ? `  Priority: ${priority}\n` : '') +
    (labels.length ? `  Labels:  ${labels.join(', ')}\n` : '') +
    (extraLabels.length ? `  Extra labels (not used for dedup): ${extraLabels.join(', ')}\n` : '') +
    `Show this proposal to the user. Only after they approve, re-run with --confirmed.\n`
  );
  process.exit(0);
}

// ─── Guard 2: dedup re-check immediately before creating (Bug and Task) ───────

async function dedupBlockers() {
  const labelClause = labels.map(l => `labels = ${JSON.stringify(l)}`).join(' OR ');
  const jql = `issuetype = ${JSON.stringify(type)} AND project = ${JSON.stringify(project)} AND statusCategory != Done AND (${labelClause}) ORDER BY created DESC`;
  // GET /rest/api/2/search is deprecated by Atlassian (returns 410 Gone) — replaced by
  // POST /rest/api/3/search/jql, which only exists on API v3, not v2.
  const res = await fetch(`${BASE}/rest/api/3/search/jql`, {
    method: 'POST',
    headers,
    body: JSON.stringify({ jql, fields: ['key'], maxResults: 5 }),
  });
  if (!res.ok) throw new Error(`dedup JQL failed: ${res.status}`);
  const data = await res.json();
  return (data.issues || []).map(i => i.key);
}

async function createIssue() {
  const fields = {
    project:   { key: project },
    summary,
    description,
    issuetype: { name: type },
  };
  if (priority) fields.priority = { name: priority };
  const allLabels = [...new Set([...labels, ...extraLabels])];
  if (allLabels.length) fields.labels = allLabels;
  const res = await fetch(`${BASE}/rest/api/2/issue`, {
    method: 'POST', headers, body: JSON.stringify({ fields }),
  });
  if (!res.ok) {
    const t = await res.text();
    throw new Error(`create failed: ${res.status} ${t}`);
  }
  return res.json();
}

(async () => {
  try {
    const blockers = await dedupBlockers();
    if (blockers.length > 0) {
      process.stdout.write(
        `DUPLICATE_BLOCKED — an open ${type} already carries these labels: ${blockers.join(', ')}.\n` +
        `No new issue created. Reference the existing ${type.toLowerCase()} instead.\n`
      );
      // process.exit() right after an HTTPS fetch aborts Node on Windows (libuv assertion, exit 127).
      process.exitCode = 0;
      return;
    }
    const created = await createIssue();
    process.stdout.write(`CREATED ${created.key}\n`);
  } catch (err) {
    // Fail closed — never create (or leave uncertain) a duplicate/irreversible issue silently.
    process.stderr.write(`❌ raise-defect.js — ${err.message}\nNo issue created (failed closed).\n`);
    process.exit(1);
  }
})();
