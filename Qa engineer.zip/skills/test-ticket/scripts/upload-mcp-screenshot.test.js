#!/usr/bin/env node
/**
 * Tests for upload-mcp-screenshot.js. Self-contained: node:test + node:assert, no network.
 * Run: node plugins/qa-engineer/skills/test-ticket/scripts/upload-mcp-screenshot.test.js
 */
'use strict';

const test = require('node:test');
const assert = require('node:assert');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { spawnSync } = require('child_process');
const { checkUploadCommand, readResult, uploadOne } = require('./upload-mcp-screenshot');

const SCRIPT = path.join(__dirname, 'upload-mcp-screenshot.js');
const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'upload-mcp-'));
const root = path.join(tmp, 'test-output');
const outsideDir = path.join(tmp, 'elsewhere');
fs.mkdirSync(path.join(root, 'MXTS-1'), { recursive: true });
fs.mkdirSync(outsideDir);
const shot = path.join(root, 'MXTS-1', 'TC_01-result.png');
const notes = path.join(root, 'MXTS-1', 'notes.txt');
const outside = path.join(outsideDir, 'TC_01-result.png');
for (const f of [shot, notes, outside]) fs.writeFileSync(f, 'x');
test.after(() => fs.rmSync(tmp, { recursive: true, force: true }));

const URL_OK = 'https://api.media.atlassian.com/file/binary?collection=upload-user-collection--1&name=TC_01-result.png';
const HEADERS = "--header 'Accept: application/json' --header 'Authorization: Bearer abc.def-ghi' --header 'X-Client-Id: 1234-abcd'";
const current = (file = shot, url = URL_OK) => `curl --location '${url}' ${HEADERS} --data-binary '@${file}'`;
const older = (file = shot) =>
  `curl -X POST '${URL_OK}' -H 'Accept: application/json' -H 'Authorization: Bearer abc' -H 'X-Client-Id: 1' -F 'file=@${file}' -s -S`;
const reason = (cmd) => {
  const r = checkUploadCommand(cmd, root);
  assert.strictEqual(r.ok, false, `expected a rejection for: ${cmd.slice(0, 80)}`);
  return r.reason;
};

test('accepts the connector shape (--location, --header, --data-binary) and drops --location', () => {
  const r = checkUploadCommand(current(), root);
  assert.strictEqual(r.ok, true);
  assert.strictEqual(r.key, 'MXTS-1/TC_01-result.png');
  assert.strictEqual(r.collection, 'upload-user-collection--1');
  assert.ok(!r.args.includes('--location'));
  assert.ok(r.args.includes('--data-binary'));
});

test('accepts the older shape (-X POST, -H, -F)', () => {
  const r = checkUploadCommand(older(), root);
  assert.strictEqual(r.ok, true);
  assert.deepStrictEqual(r.args.slice(0, 2), ['-X', 'POST']);
});

test('rejects a command that is not one curl line', () => {
  assert.match(reason('wget ' + URL_OK), /not a curl command/);
  assert.match(reason(current() + '\ncurl http://evil'), /single line/);
});

test('rejects any host or url shape other than the Atlassian media upload endpoint', () => {
  assert.match(reason(current(shot, URL_OK.replace('api.media.atlassian.com', 'evil.example.com'))), /media host/);
  assert.match(reason(current(shot, URL_OK.replace('https:', 'http:'))), /media host/);
  assert.match(reason(current(shot, URL_OK.replace('/file/binary', '/file/other'))), /path/);
  assert.match(reason(current(shot, URL_OK + '&x=a$b')), /unexpected characters/);
  assert.match(reason(`${current()} '${URL_OK}'`), /more than one url/);
});

test('rejects a file outside the screenshot root, a non-image, a missing file and a name mismatch', () => {
  assert.match(reason(current(outside)), /outside/);
  assert.match(reason(current(notes, URL_OK.replace('TC_01-result.png', 'notes.txt'))), /not an image/);
  assert.match(reason(current(path.join(root, 'MXTS-1', 'gone.png'), URL_OK.replace('TC_01-result.png', 'gone.png'))), /does not exist/);
  assert.match(reason(current(shot, URL_OK.replace('TC_01-result.png', 'TC_02-result.png'))), /does not match/);
  assert.match(reason(current(path.join(root, '..', 'elsewhere', 'TC_01-result.png'))), /outside/);
});

test('rejects stdin bodies, a second file, and every option outside the list', () => {
  assert.match(reason(`curl '${URL_OK}' ${HEADERS} --data-binary '@-'`), /reads stdin/);
  assert.match(reason(`${current()} --data-binary '@${shot}'`), /more than one file/);
  for (const extra of ["-o out.png", "--output out.png", "-K cfg", "-d x", "-T f", "-u a:b", "-x proxy", "--resolve a:1:2", "--location-trusted", "--connect-to a:1:b:2", "-k"]) {
    assert.match(reason(`${current()} ${extra}`), /option not allowed|file argument|does not parse/, extra);
  }
  assert.match(reason(`curl '${URL_OK}' ${HEADERS} -F 'file=@${shot};type=image/png'`), /file argument|does not exist/);
});

test('rejects headers outside Accept, Authorization and X-Client-Id, and shell metacharacters', () => {
  assert.match(reason(`${current()} --header 'Cookie: a=b'`), /header not allowed/);
  assert.match(reason(`${current()} --header 'Authorization: Bearer $(id)'`), /header not allowed/);
  assert.match(reason(`${current()} --header 'Accept: a;b'`), /header not allowed/);
  assert.match(reason(`${current()} --header "Accept: a"`), /header not allowed/);
});

test('uploadOne records fileId, collection and embedded:false under the path below the root', () => {
  const state = path.join(tmp, 'state', 'uploaded-files.json');
  const r = uploadOne(current(), { root, state }, () => ({ exit: 0, stdout: '{"data":{"id":"file-1"}}\n200', stderr: '' }));
  assert.deepStrictEqual(r, { ok: true, line: 'OK MXTS-1/TC_01-result.png file-1' });
  const saved = JSON.parse(fs.readFileSync(state, 'utf8'));
  assert.strictEqual(saved['MXTS-1/TC_01-result.png'].fileId, 'file-1');
  assert.strictEqual(saved['MXTS-1/TC_01-result.png'].collection, 'upload-user-collection--1');
  assert.strictEqual(saved['MXTS-1/TC_01-result.png'].embedded, false);
});

test('uploadOne keeps earlier entries and never prints the command or the token', () => {
  const state = path.join(tmp, 'state2.json');
  fs.writeFileSync(state, JSON.stringify({ 'K/old.png': { fileId: 'old', collection: 'c', uploaded_at: 't', embedded: true } }));
  const r = uploadOne(current(), { root, state }, () => ({ exit: 0, stdout: '{"data":{"id":"new"}}\n200', stderr: '' }));
  assert.ok(!r.line.includes('abc.def-ghi') && !r.line.includes('curl'));
  const saved = JSON.parse(fs.readFileSync(state, 'utf8'));
  assert.strictEqual(saved['K/old.png'].fileId, 'old');
  assert.strictEqual(saved['MXTS-1/TC_01-result.png'].fileId, 'new');
});

test('uploadOne writes nothing when the command is rejected or the upload fails', () => {
  const state = path.join(tmp, 'state3.json');
  let ran = false;
  const run = () => { ran = true; return { exit: 0, stdout: '{"errors":[]}\n401', stderr: '' }; };
  assert.deepStrictEqual(uploadOne(current(outside), { root, state }, run), { ok: false, line: 'FAIL - rejected file is outside the screenshot root' });
  assert.strictEqual(ran, false);
  assert.strictEqual(uploadOne(current(), { root, state }, run).line, 'FAIL MXTS-1/TC_01-result.png token-expired HTTP 401');
  assert.strictEqual(fs.existsSync(state), false);
});

test('--check-only validates without running curl or writing state', () => {
  const state = path.join(tmp, 'state4.json');
  const r = uploadOne(current(), { root, state, checkOnly: true }, () => { throw new Error('curl must not run'); });
  assert.strictEqual(r.line, 'OK MXTS-1/TC_01-result.png checked');
  assert.strictEqual(fs.existsSync(state), false);
});

test('readResult classifies the upload outcomes', () => {
  assert.deepStrictEqual(readResult({ exit: 0, stdout: '{"data":{"id":"abc"}}\n201', stderr: '' }), { id: 'abc' });
  assert.strictEqual(readResult({ exit: 0, stdout: '{}\n401', stderr: '' }).cls, 'token-expired');
  assert.strictEqual(readResult({ exit: 0, stdout: 'Host not in allowlist\n403', stderr: '' }).cls, 'host-unreachable');
  assert.strictEqual(readResult({ exit: 0, stdout: 'Bad\n500', stderr: '' }).cls, 'error');
  assert.strictEqual(readResult({ exit: 0, stdout: '{"data":{}}\n200', stderr: '' }).cls, 'error');
  for (const exit of [6, 7, 28, 35]) assert.strictEqual(readResult({ exit, stdout: '', stderr: 'x' }).cls, 'host-unreachable');
  assert.strictEqual(readResult({ exit: 22, stdout: '', stderr: 'Authorization: Bearer secret.value' }).detail.includes('secret'), false);
  assert.strictEqual(readResult({ exit: -1, stdout: '', stderr: '' }).cls, 'error');
});

test('CLI: --check-only prints one line per command, a summary, and exits 1 when one is rejected', () => {
  const input = `${current()}\n\n${current(outside)}\n`;
  const r = spawnSync(process.execPath, [SCRIPT, '--root', root, '--check-only'], { input, encoding: 'utf8' });
  assert.strictEqual(r.status, 1);
  assert.deepStrictEqual(r.stdout.trim().split('\n'), [
    'OK MXTS-1/TC_01-result.png checked',
    'FAIL - rejected file is outside the screenshot root',
    'done 1/2',
  ]);
  assert.ok(!r.stdout.includes('abc.def-ghi'));
});

test('CLI: usage error without --state exits 2', () => {
  const r = spawnSync(process.execPath, [SCRIPT, '--root', root], { input: '', encoding: 'utf8' });
  assert.strictEqual(r.status, 2);
  assert.match(r.stderr, /Usage/);
});

// ─── batch mode: one token, every image below --dir without a reusable entry ────────────────────────────

const { uploadDir } = require('./upload-mcp-screenshot');
const batchDir = path.join(root, 'batch');
fs.mkdirSync(path.join(batchDir, 'sub'), { recursive: true });
const batchFiles = ['a.png', 'b.png', path.join('sub', 'c.png')].map((f) => path.join(batchDir, f));
for (const f of batchFiles) fs.writeFileSync(f, 'x');
fs.writeFileSync(path.join(batchDir, 'notes.txt'), 'x');
const template = (file = batchFiles[0], name = 'a.png') =>
  `curl --location 'https://api.media.atlassian.com/file/binary?collection=col-1&name=${name}' ${HEADERS} --data-binary '@${file}'`;
const okRun = (calls) => (args) => {
  calls.push(args);
  return { exit: 0, stdout: `{"data":{"id":"id-${calls.length}"}}\n201`, stderr: '' };
};
let stateN = 0;
const freshState = (entries = {}) => {
  const f = path.join(tmp, `batch-state-${stateN++}.json`);
  if (Object.keys(entries).length) fs.writeFileSync(f, JSON.stringify(entries));
  return f;
};
const noRun = () => {
  throw new Error('curl must not run');
};

test('batch: one command uploads every image below the directory, swapping name and file and keeping the headers', () => {
  const calls = [];
  const state = freshState();
  const r = uploadDir(template(), { root, state, dir: batchDir, budget: 60 }, okRun(calls));
  assert.deepStrictEqual(r.lines, ['OK batch/a.png id-1', 'OK batch/b.png id-2', 'OK batch/sub/c.png id-3']);
  assert.strictEqual(r.failed, false);
  assert.strictEqual(calls.length, 3);
  const names = calls.map((args) => new URL(args[0]).searchParams.get('name'));
  assert.deepStrictEqual(names, ['a.png', 'b.png', 'c.png']);
  calls.forEach((args, i) => {
    assert.ok(args.includes('Authorization: Bearer abc.def-ghi'), 'same token for every file');
    assert.strictEqual(new URL(args[0]).searchParams.get('collection'), 'col-1');
    assert.ok(args.includes(`@${fs.realpathSync(batchFiles[i])}`));
    assert.ok(!args.includes('--location'));
  });
  const saved = JSON.parse(fs.readFileSync(state, 'utf8'));
  assert.deepStrictEqual(Object.keys(saved), ['batch/a.png', 'batch/b.png', 'batch/sub/c.png']);
  assert.strictEqual(saved['batch/sub/c.png'].fileId, 'id-3');
  assert.strictEqual(saved['batch/a.png'].collection, 'col-1');
});

const ID_A = '11111111-1111-4111-8111-111111111111';
const ID_B = '22222222-2222-4222-8222-222222222222';
const ID_C = '33333333-3333-4333-8333-333333333333';
const isUpload = (args) => args.includes('--data-binary');
const isoAgo = (ms) => new Date(Date.now() - ms).toISOString();
const touchAgo = (file, ms) => fs.utimesSync(file, new Date(Date.now() - ms), new Date(Date.now() - ms));
const HOUR = 3600 * 1000;

test('batch: an embedded entry is skipped; an unembedded one only when the media API still holds it', () => {
  for (const f of batchFiles) touchAgo(f, 6 * HOUR);
  const state = freshState({
    'batch/a.png': { fileId: ID_A, collection: 'col-1', uploaded_at: isoAgo(5 * 60 * 1000), embedded: false },
    'batch/b.png': { fileId: ID_B, collection: 'col-1', uploaded_at: isoAgo(5 * HOUR), embedded: true },
    'batch/sub/c.png': { fileId: ID_C, collection: 'col-1', uploaded_at: isoAgo(40 * 60 * 1000), embedded: false },
  });
  const calls = [];
  const run = (args) => {
    calls.push(args);
    if (isUpload(args)) return { exit: 0, stdout: '{"data":{"id":"new"}}\n201', stderr: '' };
    return args.some((a) => a.includes(ID_A))
      ? { exit: 0, stdout: '{"data":{"processingStatus":"succeeded"}}\n200', stderr: '' }
      : { exit: 0, stdout: '{"error":{}}\n404', stderr: '' };
  };
  const r = uploadDir(template(), { root, state, dir: batchDir, budget: 60 }, run);
  assert.deepStrictEqual(r.lines, ['OK batch/sub/c.png new']);
  assert.strictEqual(r.skipped, 2);
  assert.strictEqual(r.total, 1);
  const probes = calls.filter((a) => !isUpload(a));
  assert.strictEqual(probes.length, 2, 'a and c are asked about, the embedded b is not');
  assert.ok(probes[0].includes(`https://api.media.atlassian.com/file/${ID_A}?collection=col-1`));
  assert.ok(probes[0].includes('Authorization: Bearer abc.def-ghi'), 'the probe uses the command\'s own token');
  assert.ok(!probes[0].includes('POST') && !probes[0].includes('--location'));
});

test('batch: an unembedded entry whose file is unprocessed, gone or unanswered is uploaded again', () => {
  for (const f of batchFiles) touchAgo(f, 6 * HOUR);
  const entry = (id) => ({ fileId: id, collection: 'col-1', uploaded_at: isoAgo(60 * 1000), embedded: false });
  const state = freshState({ 'batch/a.png': entry(ID_A), 'batch/b.png': entry(ID_B), 'batch/sub/c.png': entry(ID_C) });
  const answers = { [ID_A]: '{"data":{"processingStatus":"pending"}}\n200', [ID_B]: 'not json\n200' };
  const run = (args) => {
    if (isUpload(args)) return { exit: 0, stdout: '{"data":{"id":"new"}}\n201', stderr: '' };
    const id = [ID_A, ID_B, ID_C].find((x) => args.some((a) => a.includes(x)));
    return id === ID_C ? { exit: 6, stdout: '', stderr: 'offline' } : { exit: 0, stdout: answers[id], stderr: '' };
  };
  const r = uploadDir(template(), { root, state, dir: batchDir, budget: 60 }, run);
  assert.deepStrictEqual(r.lines, ['OK batch/a.png new', 'OK batch/b.png new', 'OK batch/sub/c.png new']);
  assert.strictEqual(r.skipped, 0);
});

test('batch: a file changed after its upload is uploaded again, without asking the media API', () => {
  for (const f of batchFiles) touchAgo(f, 6 * HOUR);
  const state = freshState({ 'batch/a.png': { fileId: ID_A, collection: 'col-1', uploaded_at: isoAgo(HOUR), embedded: true } });
  touchAgo(batchFiles[0], 60 * 1000);
  const calls = [];
  const r = uploadDir(template(), { root, state, dir: batchDir, budget: 60 }, okRun(calls));
  assert.ok(r.lines.includes('OK batch/a.png id-1'));
  assert.ok(calls.every(isUpload), 'no probe calls');
  touchAgo(batchFiles[0], 6 * HOUR);
});

test('batch: an expired token or an unreachable host stops the run and says how many files were not attempted', () => {
  let i = 0;
  const expiresAfterOne = () => ({ exit: 0, stdout: ++i === 1 ? '{"data":{"id":"x"}}\n201' : '{}\n401', stderr: '' });
  const r = uploadDir(template(), { root, state: freshState(), dir: batchDir, budget: 60 }, expiresAfterOne);
  assert.deepStrictEqual(r.lines, ['OK batch/a.png x', 'FAIL batch/b.png token-expired HTTP 401', 'STOP token-expired 1 files not attempted']);
  assert.strictEqual(r.failed, true);
  const down = uploadDir(template(), { root, state: freshState(), dir: batchDir, budget: 60 }, () => ({ exit: 6, stdout: '', stderr: 'x' }));
  assert.deepStrictEqual(down.lines, ['FAIL batch/a.png host-unreachable curl exit 6 x', 'STOP host-unreachable 2 files not attempted']);
});

test('batch: a failed upload other than expiry or host does not stop the others; the budget does', () => {
  let i = 0;
  const flaky = () => (++i === 1 ? { exit: 0, stdout: 'oops\n500', stderr: '' } : { exit: 0, stdout: '{"data":{"id":"k"}}\n201', stderr: '' });
  const r = uploadDir(template(), { root, state: freshState(), dir: batchDir, budget: 60 }, flaky);
  assert.deepStrictEqual(r.lines, ['FAIL batch/a.png error HTTP 500 oops', 'OK batch/b.png k', 'OK batch/sub/c.png k']);
  const late = uploadDir(template(), { root, state: freshState(), dir: batchDir, budget: -1 }, noRun);
  assert.deepStrictEqual(late.lines, ['STOP budget 3 files not attempted']);
});

test('batch: rejects a bad command, a directory outside the root, and names the upload cannot carry', () => {
  const badCmd = uploadDir(template(outside, 'TC_01-result.png'), { root, state: freshState(), dir: batchDir, budget: 60 }, noRun);
  assert.deepStrictEqual(badCmd.lines, ['FAIL - rejected file is outside the screenshot root']);
  const badDir = uploadDir(template(), { root, state: freshState(), dir: outsideDir, budget: 60 }, noRun);
  assert.deepStrictEqual(badDir.lines, ['FAIL - rejected directory is outside the screenshot root']);
  const odd = path.join(batchDir, 'odd name.png');
  fs.writeFileSync(odd, 'x');
  const r = uploadDir(template(), { root, state: freshState(), dir: batchDir, budget: 60 }, okRun([]));
  assert.ok(r.lines.includes('FAIL batch/odd name.png rejected unsupported file name'));
  assert.strictEqual(r.failed, true);
  fs.rmSync(odd);
});

test('batch: --check-only lists what would upload and runs nothing; the CLI takes exactly one command', () => {
  const r = uploadDir(template(), { root, state: null, dir: batchDir, budget: 60, checkOnly: true }, noRun);
  assert.deepStrictEqual(r.lines, ['OK batch/a.png checked', 'OK batch/b.png checked', 'OK batch/sub/c.png checked']);
  const args = ['--root', root, '--dir', batchDir, '--check-only'];
  const two = spawnSync(process.execPath, [SCRIPT, ...args], { input: `${template()}\n${template()}\n`, encoding: 'utf8' });
  assert.strictEqual(two.status, 1);
  assert.match(two.stdout, /exactly one command/);
  const one = spawnSync(process.execPath, [SCRIPT, ...args], { input: `${template()}\n`, encoding: 'utf8' });
  assert.strictEqual(one.status, 0);
  assert.deepStrictEqual(one.stdout.trim().split('\n'), ['OK batch/a.png checked', 'OK batch/b.png checked', 'OK batch/sub/c.png checked', 'done 3/3']);
  assert.ok(!one.stdout.includes('abc.def-ghi'));
});
