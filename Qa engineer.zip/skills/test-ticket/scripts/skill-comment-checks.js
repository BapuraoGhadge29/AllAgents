'use strict';
/**
 * Format checks for the comments that the OTHER qa-engineer skills post through the Atlassian MCP (markdown), so the
 * same checks that guard /test-ticket also guard them, and so any of them can be split into parts (result-parts.js):
 *
 *   gtc      generating-test-cases Step 8: "## QA Test Cases — <KEY>" (optionally "(Updated)"), the 10-column table,
 *            "## Coverage Gaps" (last part only when split)
 *   exec     execute-tests Step 6c: "## QA Test Results — <KEY>", the 10-row stats table, the 6-column table
 *   gresults generating-test-cases Step 10: "## QA Test Results — <KEY>", the 6-column table (no stats table needed)
 *
 * sprint-planning posts "## Test Cases — <KEY>", which validate-results-comment.js --kind tc already checks.
 * Used by validate-results-comment.js (--kind gtc | exec | gresults --story <KEY>). Pure text checks, no network.
 */

const T = require('./tc-extended');

const TC10 = T.TC10_COLS;
const TC6 = ['TC_ID', 'Test case scenario', 'Expected Result', 'Actual Result', 'Status', 'Test Proof'];
const EXEC_STATS = ['Build / Version', 'Preconditions', 'Total TCs', 'Passed', 'Failed', 'Blocked', 'Needs Review', 'Skipped', 'Pass rate', 'QA Pipeline Version'];
const STATUS_RE = /^(PASS ✅|FAIL ❌|BLOCKED 🚫|NEEDS REVIEW 🔍|SKIP(?:PED)? ⏭️?)$/;
const VERDICT_RE = /(PASS ✅|FAIL ❌|BLOCKED 🚫|NEEDS REVIEW 🔍|SKIP(?:PED)? ⏭)/;
const PHASE_PATTERNS = [/phase\s*3a/i, /phase\s*1\b/i, /phase\s*2\b/i, /execution results/i, /execution summary/i, /pipeline summary/i];
const SUPPLEMENT_PATTERNS = [/supersedes/i, /supplement/i, /appendix/i, /part\s*2/i, /full evidence/i];
const BANNER_RE = /^>\s*⚠️?\s*This comment supersedes the previous test case comment \(IDs?: [\w, ]+\)/;

function mdRows(text) {
  return text.split('\n').map(l => l.trim()).filter(l => l.startsWith('|') && !/^\|\s*:?-{2,}/.test(l))
    .map(l => l.replace(/^\|/, '').replace(/\|$/, '').split('|').map(c => c.trim()));
}
const firstLine = (lines) => (lines.find(l => l.trim().length > 0) || '').trim();
const isLast = (part) => !part || part.n === part.m;

// ─── generating-test-cases Step 8 ───────────────────────────────────────────

function validateGtc(text, story, part, mainTotal = null) {
  const errors = [];
  const lines = text.split('\n');
  const first = firstLine(lines);
  const h = /^##\s*QA Test Cases —\s*(\S+?)(\s+\(Updated\))?\s*$/.exec(first);
  if (!h) {
    errors.push(`[CHECK 1] The body must start with exactly "## QA Test Cases — ${story}" (or "… (Updated)").\n  Found: "${first || '(empty)'}"`);
  } else if (h[1].toUpperCase() !== story.toUpperCase()) {
    errors.push(`[CHECK 0] Target mismatch. The header is for "${h[1]}" but the comment is for "${story}".`);
  }
  const updated = !!(h && h[2]);

  const heads = lines.map(l => l.trim()).filter(l => /^#{1,6}\s/.test(l)).slice(1)
    .filter(l => !/^##\s*Coverage Gaps\s*$/.test(l) && !T.HEADING_RE.test(l));
  if (heads.length) errors.push(`[CHECK 3] Extra headings — only "## Coverage Gaps" is allowed after the header.\n  Found: ${heads.slice(0, 3).map(l => `"${l}"`).join(', ')}`);

  const rows = mdRows(text);
  const headerIdx = rows.findIndex(r => r.length === TC10.length && r.every((c, i) => c === TC10[i]));
  if (headerIdx === -1) errors.push(`[CHECK 2] 10-column TC table header not found. Expected exactly: | ${TC10.join(' | ')} |`);
  const tcRows = rows.filter(r => /^TC_\d+$/.test(r[0] || ''));
  if (!tcRows.length) errors.push('[CHECK 7] The TC table has no TC_XX rows — an empty comment must not be posted.');
  const badCols = tcRows.filter(r => r.length !== TC10.length);
  if (badCols.length) errors.push(`[CHECK 5] ${badCols.length} TC row(s) do not have exactly 10 columns (a stray "|" inside a cell splits the row): ${badCols.slice(0, 3).map(r => r[0]).join(', ')}`);
  const wrongStory = tcRows.filter(r => r.length === TC10.length && r[6].toUpperCase() !== story.toUpperCase());
  if (wrongStory.length) errors.push(`[CHECK 0] "Story number" must be ${story} in every row. Found: ${wrongStory.slice(0, 3).map(r => `${r[0]}=${r[6]}`).join(', ')}`);
  const verdicts = tcRows.filter(r => r.length === TC10.length && VERDICT_RE.test(r[5]));
  if (verdicts.length) errors.push(`[CHECK 6] Execution verdicts in a test-case table (Actual result must be "To be Tested"): ${verdicts.slice(0, 3).map(r => r[0]).join(', ')}`);
  errors.push(...T.validateExtended(text, { markdown: true, requireFooter: false, mainTotal, split: !!part }));

  const gapsAt = lines.map((l, i) => (/^##\s*Coverage Gaps\s*$/.test(l.trim()) ? i : -1)).filter(i => i !== -1);
  if (isLast(part)) {
    if (gapsAt.length !== 1) errors.push(`[CHECK 9] The comment${part ? ` (the last part, ${part.n} of ${part.m})` : ''} must carry exactly one "## Coverage Gaps" section; found ${gapsAt.length}.`);
    else if (!lines.slice(gapsAt[0] + 1).some(l => l.trim())) errors.push('[CHECK 9] "## Coverage Gaps" is empty — write the gaps, or "No coverage gaps identified".');
  } else if (gapsAt.length) {
    errors.push(`[CHECK 9] "## Coverage Gaps" belongs only in the last part (${part.m} of ${part.m}); part ${part.n} must not carry it.`);
  }

  if (updated && (!part || part.n === 1) && !lines.some(l => BANNER_RE.test(l.trim()))) {
    errors.push('[CHECK 10] An "(Updated)" comment needs the banner line: "> ⚠️ This comment supersedes the previous test case comment (ID: <original-comment-id>). Please delete or ignore the earlier one." (in the first part when split).');
  }
  return errors;
}

// ─── execute-tests Step 6c / generating-test-cases Step 10 ──────────────────

function validateKeyedResults(text, story, { stats, requireProof, part }) {
  const errors = [];
  const lines = text.split('\n');
  const first = firstLine(lines);
  const h = /^##\s*QA Test Results —\s*(\S+)\s*$/.exec(first);
  if (!h) {
    errors.push(`[CHECK 1] The body must start with exactly "## QA Test Results — ${story}".\n  Found: "${first || '(empty)'}"`);
  } else if (h[1].toUpperCase() !== story.toUpperCase()) {
    errors.push(`[CHECK 0] Target mismatch. The header is for "${h[1]}" but the comment is for "${story}".`);
  }

  const rows = mdRows(text);
  const labelOf = (r) => (/^\*\*(.+)\*\*$/.exec(r[0] || '') || [])[1];
  const statRows = rows.filter(r => r.length === 2 && labelOf(r));
  if (stats === 'required' || statRows.length) {
    for (const label of EXEC_STATS) {
      const found = statRows.filter(r => labelOf(r) === label);
      if (found.length !== 1) errors.push(`[CHECK 2] Stats row **${label}** must appear exactly once; found ${found.length}.`);
    }
    const unexpected = statRows.filter(r => !EXEC_STATS.includes(labelOf(r)));
    if (unexpected.length) errors.push(`[CHECK 2] Unexpected stats row: ${unexpected.slice(0, 3).map(r => `"${r[0]}"`).join(', ')}`);
  }

  const headerIdx = rows.findIndex(r => r.length === TC6.length && r.every((c, i) => c === TC6[i]));
  if (headerIdx === -1) errors.push(`[CHECK 3] TC table header not found or wrong columns. Expected exactly: | ${TC6.join(' | ')} |`);
  const tcRows = rows.filter(r => /^(TC|EXTRA)_\d+$/.test(r[0] || ''));
  if (!tcRows.some(r => /^TC_/.test(r[0]))) errors.push('[CHECK 3] The table has no TC_XX rows.');
  const ids = tcRows.map(r => r[0]);
  const dup = ids.filter((id, i) => ids.indexOf(id) !== i);
  if (dup.length) errors.push(`[CHECK 4] Duplicate TC_ID(s) in one comment: ${[...new Set(dup)].join(', ')}`);
  const badCols = tcRows.filter(r => r.length !== TC6.length);
  if (badCols.length) errors.push(`[CHECK 10] Wrong column count (a stray "|" inside a cell splits the row): ${badCols.slice(0, 5).map(r => `${r[0]} (${r.length} cells)`).join(', ')}`);
  const full = tcRows.filter(r => r.length === TC6.length);
  const badStatus = full.filter(r => !STATUS_RE.test(r[4]));
  if (badStatus.length) errors.push(`[CHECK 8] Status must be PASS ✅ / FAIL ❌ / BLOCKED 🚫 / NEEDS REVIEW 🔍 / SKIP ⏭️. Affected: ${badStatus.slice(0, 5).map(r => `${r[0]}: "${r[4]}"`).join('; ')}`);
  if (requireProof) {
    const noProof = full.filter(r => !r[5]);
    if (noProof.length) errors.push(`[CHECK 8] Test Proof must not be empty (a screenshot filename for every TC). Affected: ${noProof.slice(0, 5).map(r => r[0]).join(', ')}`);
  }
  const extras = full.filter(r => /^EXTRA_/.test(r[0]));
  const extraBad = extras.filter(r => !/^\*\*\[EXTRA\]\*\*/.test(r[1]));
  if (extraBad.length) errors.push(`[CHECK 11] An EXTRA row's scenario must start with **[EXTRA]**: ${extraBad.slice(0, 3).map(r => r[0]).join(', ')}`);
  if (extras.length && !isLast(part)) errors.push(`[CHECK 11] EXTRA rows belong only in the last part (${part.m} of ${part.m}); part ${part.n} must not carry them.`);

  const outside = lines.filter(l => !l.trim().startsWith('|'));
  const phase = outside.filter(l => PHASE_PATTERNS.some(p => p.test(l)));
  if (phase.length) errors.push(`[CHECK 6] Internal pipeline labels found — they must never appear in Jira. Found: ${phase.slice(0, 3).map(l => `"${l.trim()}"`).join(', ')}`);
  const sup = outside.filter(l => !/^[_*]?Part \d+ of \d+[_*]?$/.test(l.trim()) && SUPPLEMENT_PATTERNS.some(p => p.test(l)));
  if (sup.length) errors.push(`[CHECK 7] Supplement/appendix markers found. Found: ${sup.slice(0, 3).map(l => `"${l.trim()}"`).join(', ')}`);
  return errors;
}

// ─── templates printed on failure ───────────────────────────────────────────

const TEMPLATE_GTC = [
  '## QA Test Cases — <STORY_KEY>   (or "## QA Test Cases — <STORY_KEY> (Updated)")', '',
  '(split comment only: the line "_Part <n> of <m>_" right here, directly after the header)', '',
  '(Updated only, first part only: > ⚠️ This comment supersedes the previous test case comment (ID: <original-comment-id>). Please delete or ignore the earlier one.)', '',
  `| ${TC10.join(' | ')} |`, '|---|---|---|---|---|---|---|---|---|---|',
  '| TC_01 | … | … | … | … | To be Tested | <STORY_KEY> | <EPIC_KEY or N/A> | No | High/Medium/Low |', '',
  '## Coverage Gaps   (exactly once; in the last part when split)', '- <gap> (or "No coverage gaps identified")',
].join('\n');

const TEMPLATE_EXEC = [
  '## QA Test Results — <STORY_KEY>', '', '(split comment only: the line "_Part <n> of <m>_" right here, directly after the header)', '',
  '| | |', '|---|---|', ...EXEC_STATS.map(l => `| **${l}** | <value> |`), '',
  `| ${TC6.join(' | ')} |`, '|---|---|---|---|---|---|',
  '| TC_01 | <scenario> | <expected> | <actual> | PASS ✅ | TC_01-result.png |',
  '| EXTRA_01 | **[EXTRA]** <scenario> | <expected> | <actual> | PASS ✅ | EXTRA_01-result.png |   (last part only)',
].join('\n');

const TEMPLATE_GRESULTS = [
  '## QA Test Results — <STORY_KEY>', '', '(split comment only: the line "_Part <n> of <m>_" right here, directly after the header)', '',
  `| ${TC6.join(' | ')} |`, '|---|---|---|---|---|---|',
  '| TC_01 | <scenario> | <expected> | <actual> | PASS ✅ | |',
].join('\n');

module.exports = { validateGtc, validateKeyedResults, TEMPLATE_GTC, TEMPLATE_EXEC, TEMPLATE_GRESULTS, EXEC_STATS, TC6 };
