#!/usr/bin/env node
/**
 * Column layouts of a "QA Test Results" comment, shared by post-comment.js, update-comment.js,
 * validate-results-comment.js and result-parts.js.
 *
 *   results  6 columns   TC_ID | Test case scenario | Expected Result | Actual Result | Status | Test Proof
 *            what a retest cycle or an older run posts as its own comment.
 *   merged  12 columns   the 10 Test Cases columns, Actual result filled in, then Status | Test Proof
 *            what the Test Cases comment becomes after execution: the same comment, edited in place, so a story
 *            carries one comment with the test cases and their results.
 *
 * lostFromTestCases() proves an in-place update dropped nothing the Test Cases comment already held.
 */
'use strict';

const RESULTS_COLS = ['TC_ID', 'Test case scenario', 'Expected Result', 'Actual Result', 'Status', 'Test Proof'];
const MERGED_COLS = [
  'TC_ID', 'Test case scenario', 'Preconditions', 'Test steps', 'Expected Result', 'Actual result',
  'Story number', 'Epic number', 'Automated', 'Risk', 'Status', 'Test Proof',
];
// The two spellings of the automation column: `Automate` before execution, `Automated` after it.
const AUTOMATE_NAMES = ['Automate', 'Automated'];

const LAYOUTS = [
  { name: 'results', cols: RESULTS_COLS },
  { name: 'merged', cols: MERGED_COLS },
].map(l => ({
  ...l,
  actual: l.cols.findIndex(c => /^Actual result$/i.test(c)),
  status: l.cols.indexOf('Status'),
  proof: l.cols.indexOf('Test Proof'),
}));

const wikiHeader = (cols) => `|| ${cols.join(' || ')} ||`;

/** The layout whose wiki header row appears in `lines`, or null. */
function wikiLayout(lines) {
  const trimmed = lines.map(l => l.trim());
  return LAYOUTS.find(l => trimmed.includes(wikiHeader(l.cols))) || null;
}

/** The layout for a header row given as cell texts (HTML or markdown), or null. */
function layoutOfCells(cells) {
  return LAYOUTS.find(l => l.cols.length === cells.length && l.cols.every((c, i) => c === cells[i])) || null;
}

// ─── reading Test Cases rows, wiki or HTML ──────────────────────────────────

const decode = (s) => s.replace(/&nbsp;/g, ' ').replace(/&quot;/g, '"').replace(/&#0?39;/g, "'").replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&amp;/g, '&');
const norm = (s) => decode(String(s).replace(/<[^>]+>/g, ' ')).replace(/\s+/g, ' ').trim();
const isHtml = (body) => /^\s*</.test(body);

/** Every TC row of the body as { id, cells } with whitespace-normalised cell text. Rows of any table, extended section included. */
function tcRows(body) {
  const text = String(body);
  const rows = [];
  if (isHtml(text)) {
    for (const tr of text.match(/<tr[\s\S]*?<\/tr>/gi) || []) {
      const cells = (tr.match(/<t[dh][^>]*>[\s\S]*?<\/t[dh]>/gi) || []).map(norm);
      if (/^TC_\d+$/.test(cells[0] || '')) rows.push({ id: cells[0], cells });
    }
    return rows;
  }
  for (const line of text.split('\n')) {
    if (!/^\s*\|\s*TC_\d+\s*\|/.test(line)) continue;
    const cells = line.trim().replace(/\[[^\]]*\|[^\]]*\]/g, '[LINK]').split('|').slice(1, -1).map(norm);
    rows.push({ id: cells[0], cells });
  }
  return rows;
}

// Test Cases columns that must come through an in-place update unchanged: everything except the Actual result (filled
// in by execution) and the Automate/Automated column (renamed, and set to its final value).
const KEPT_COLS = [0, 1, 2, 3, 4, 6, 7, 9];

/**
 * What the merged body lost from the existing Test Cases comment: a TC row that is gone, a kept column that changed
 * (in every row of that TC), or the AC-coverage footer. A TC that appears more or fewer times than before, or a TC
 * the existing comment does not have, is reported too: an in-place merge neither duplicates nor invents rows. `previous` is the comment as Jira returns it (same format as `merged`).
 * Returns a list of error strings, empty when nothing was lost. A previous body that is not a Test Cases / merged
 * table (fewer than 10 cells per row) is not comparable and reports itself.
 */
function lostFromTestCases(previous, merged) {
  const before = tcRows(previous);
  const after = tcRows(merged);
  const errors = [];
  if (!before.length) return ['[CHECK 18] The existing comment holds no TC rows: it is not the Test Cases comment of this story.'];
  const short = before.filter(r => r.cells.length < 10);
  if (short.length) return [`[CHECK 18] The existing comment is not a 10-column Test Cases table (rows ${short.slice(0, 3).map(r => r.id).join(', ')} have fewer cells).`];
  const seen = new Set();
  for (const old of before) {
    if (seen.has(old.id)) continue;
    seen.add(old.id);
    const rows = after.filter(r => r.id === old.id);
    if (!rows.length) { errors.push(`[CHECK 18] ${old.id} is in the existing comment but not in the merged body.`); continue; }
    const rowsBefore = before.filter(r => r.id === old.id).length;
    if (rows.length !== rowsBefore) {
      errors.push(`[CHECK 18] ${old.id} has ${rowsBefore} row(s) in the existing comment but ${rows.length} in the merged body.`);
      continue;
    }
    for (const col of KEPT_COLS) {
      if (rows.every(r => r.cells[col] !== old.cells[col])) {
        errors.push(`[CHECK 18] ${old.id}: column "${MERGED_COLS[col]}" changed.\n  Existing: ${old.cells[col]}\n  Merged:   ${(rows[0].cells[col] || '(missing)')}`);
      }
    }
  }
  for (const id of new Set(after.map(r => r.id))) {
    if (!seen.has(id)) errors.push(`[CHECK 18] ${id} is in the merged body but not in the existing comment.`);
  }
  const text = (b) => (isHtml(String(b)) ? norm(b) : String(b));
  if (/AC coverage:/.test(text(previous)) && !/AC coverage:/.test(text(merged))) {
    errors.push('[CHECK 18] The AC-coverage footer of the existing comment is missing from the merged body.');
  }
  return errors;
}

// ─── footer counts (CHECK 21) ───────────────────────────────────────────────

const FOOTER_RE = /AC coverage:\s*\d+\/\d+\s*\|\s*(Automated?):\s*(\d+) Yes \/ (\d+) No/;
const EXTENDED_HEADING_RE = /^(?:h[1-6]\.|#{1,6})\s*Extended cases added after Human review\s*$/;

// The body up to the "Extended cases added after Human review" section, which sits after the footer and is not counted in it.
function beforeExtendedSection(body) {
  const text = String(body);
  if (isHtml(text)) {
    const at = text.search(/<h[1-6][^>]*>\s*Extended cases added after Human review/i);
    return at === -1 ? text : text.slice(0, at);
  }
  const lines = text.split('\n');
  const cut = lines.findIndex(l => EXTENDED_HEADING_RE.test(l.trim()));
  return (cut === -1 ? lines : lines.slice(0, cut)).join('\n');
}

// The spelling of the automation column in the first TC table's header: "Automate" before execution, "Automated" after.
function automateHeader(body) {
  const text = String(body);
  let cells = [];
  if (isHtml(text)) {
    for (const tr of text.match(/<tr[\s\S]*?<\/tr>/gi) || []) {
      const c = (tr.match(/<t[dh][^>]*>[\s\S]*?<\/t[dh]>/gi) || []).map(norm);
      if (c[0] === 'TC_ID') { cells = c; break; }
    }
  } else {
    const line = text.split('\n').find(l => /^\s*\|\|?\s*TC_ID\s*\|/.test(l));
    if (line) cells = line.split(/\|+/).map(norm).filter(Boolean);
  }
  return cells.find(c => AUTOMATE_NAMES.includes(c)) || null;
}

/**
 * The footer "AC coverage: <c>/<t> | Automate: <n> Yes / <m> No" must say what the table says: <n> is the number of TCs
 * whose Automate/Automated cell is Yes, <m> the number that say No, over the main table (each TC once, so a multi-URL
 * comment's repeated blocks and the Extended section after the footer do not count). The footer's label is the column's
 * own name — "Automate" before execution, "Automated" once the results are merged in. A body with no footer, or with the
 * 6-column table that has no such column, has nothing to compare.
 */
function footerCountErrors(body) {
  const text = String(body);
  const visible = isHtml(text) ? text.replace(/<\/(p|li|h[1-6]|tr|table|details)>/gi, '\n').replace(/<[^>]+>/g, ' ').replace(/&nbsp;/g, ' ') : text;
  const footer = visible.split('\n').map(l => l.replace(/\s+/g, ' ').trim()).map(l => FOOTER_RE.exec(l)).filter(Boolean).pop();
  if (!footer) return [];
  const [, label, footerYes, footerNo] = footer;
  const seen = new Set();
  const rows = tcRows(beforeExtendedSection(body)).filter(r => r.cells.length >= 10 && !seen.has(r.id) && seen.add(r.id));
  if (!rows.length) return [];
  const yes = rows.filter(r => r.cells[8] === 'Yes').length;
  const no = rows.filter(r => r.cells[8] === 'No').length;
  const errors = [];
  const header = automateHeader(body);
  if (header && header !== label) {
    errors.push(`[CHECK 21] The footer label "${label}:" must be the column's name "${header}:" (before execution the column and the footer say "Automate", after execution "Automated").`);
  }
  if (yes + no !== rows.length) {
    const bad = rows.filter(r => r.cells[8] !== 'Yes' && r.cells[8] !== 'No').map(r => `${r.id}="${r.cells[8]}"`);
    errors.push(`[CHECK 21] The Automate/Automated column must be Yes or No in every row. Found: ${bad.slice(0, 5).join(', ')}`);
  }
  if (Number(footerYes) !== yes || Number(footerNo) !== no) {
    errors.push(`[CHECK 21] The footer says "${label}: ${footerYes} Yes / ${footerNo} No" but the table has ${yes} Yes / ${no} No in its Automate/Automated column (main table, each TC once). Recount the footer from the table.`);
  }
  return errors;
}

module.exports = {
  RESULTS_COLS, MERGED_COLS, AUTOMATE_NAMES, LAYOUTS, wikiHeader, wikiLayout, layoutOfCells, tcRows, lostFromTestCases, footerCountErrors,
};
