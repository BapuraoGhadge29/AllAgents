#!/usr/bin/env node
/**
 * Post a wiki-markup Phase 3b results comment to a Jira issue via API v2.
 * API v2 is required so !image.png! renders inline in Jira table cells.
 *
 * Built-in gates (run before posting — cannot be bypassed):
 *   1. Format validation — enforces h2. QA Test Results, stats table, 6-column TC table,
 *      no Markdown headers, no prose sections, no phase labels, screenshot in every TC row.
 *   2. Known-comment guard — each test cycle (a normal run, or a --retest/--force run after
 *      the story was reopened) gets its OWN results comment; prior cycles' comments are
 *      left in Jira as history and are never posted over. Three layers, cheapest first,
 *      each one a fallback for when the previous one couldn't confirm anything:
 *        a. <known_comment_id> — run-state.json's stories.<STORY_KEY>.results_comment_id
 *           for the CURRENT cycle. If it still exists, no-op (fast path, no Jira scan).
 *        b. <not_before_iso> — run-state.json's stories.<STORY_KEY>.cycle_started_at
 *           (recorded once, the moment Phase 3a starts this cycle). Covers the case where
 *           results_comment_id was never recorded — e.g. the agent crashed/compacted right
 *           after the Jira POST succeeded but before that id was persisted. Scans ALL
 *           comments (a small clock-skew buffer applied to the cutoff), filtering by
 *           created date — not an early-exit on order, so correctness never depends on the
 *           API actually honoring -created ordering. A prior (pre-reopen) cycle's comment
 *           is still never matched, since its `created` date is before the cutoff.
 *        c. Neither supplied — the caller has NO cycle-scoping info at all (e.g. Generation
 *           Only mode, which never runs Phase 3a and so never stamps cycle_started_at).
 *           Falls back to the original design: scan the issue's FULL comment history for
 *           any "h2. QA Test Results" comment and block if one exists. This trades away
 *           the new-comment-per-cycle behavior for such calls (a retest through this path
 *           still can't tell "prior cycle" from "this cycle", so it conservatively blocks,
 *           same as pre-this-feature) in exchange for NEVER silently posting an
 *           uncontrolled duplicate — correctness over completeness.
 *      Layer (c) is the only one that scans unconditionally; (a)/(b) are cycle-scoped and
 *      deliberately do NOT fall back to a full-history scan on their own — that's what
 *      would reintroduce the original bug of blocking a genuine new cycle after a reopen.
 *
 * Split results (more than 45 rows — see result-parts.js): pass --part <n>/<m>, --tc-ids <csv> (or
 * --tc-ids-file <file>). The body then carries the line "_Part n of m_" right after the header, must contain
 * exactly the TCs assigned to this part, and carries Cross-Module Impact only in the last part. The duplicate
 * guard below then matches on that part's own marker, so each part is posted once and a later part is never
 * mistaken for an earlier one; <known_comment_id> is that part's own id (result_parts[n-1].comment_id).
 *
 * Usage:
 *   node post-comment.js <issue_key> <comment_body_file> [<known_comment_id>] [<not_before_iso>]
 *   node post-comment.js <issue_key> --inline "<wiki markup string>" [<known_comment_id>] [<not_before_iso>]
 *
 * Exits 0 on success (prints comment ID) or when already-posted-this-cycle is detected
 * (prints warning). Exits 1 on validation failure or API error.
 *
 * Screenshot check (every post, and every already-posted-this-cycle detection): every TC_NN-*.png the body
 * names must be attached to the issue, otherwise it renders as a broken image or stays a plain filename.
 * The outcome goes to stderr (stdout stays the comment id). Exits 3 when a screenshot is not attached or
 * Jira could not be asked: the comment IS posted (its id is on stdout), the screenshots are not all visible.
 * Upload the missing files with upload-screenshot.js — the images appear without editing the comment — and
 * run the same command again: the already-posted detection then repeats the check.
 */

// Treats "" AND the literal strings "null"/"undefined" as omitted — a caller that
// stringifies a JSON `null` field verbatim into a shell arg (instead of passing "")
// must not accidentally send a real GET request for a comment literally named "null".
function optionalArg(v) {
  return (v && v !== 'null' && v !== 'undefined') ? v : null;
}

// Split results (> 45 rows, see result-parts.js): --part <n>/<m> --tc-ids <csv> | --tc-ids-file <file> may sit anywhere in the args.
const resultParts = require('./result-parts');
const resultsLayout = require('./results-layout');
const { statsErrors } = require('./dashboard-stats');
const screenshotAttachments = require('./screenshot-attachments');
// --validate-only: run every format check offline (no credentials, no Jira call) and print OK — used to validate all parts before posting the first.
const { rest: argv, part: partOpt, tcIds: partTcIds, validateOnly, runTotal } = resultParts.takePartArgs(process.argv.slice(2));
const partMarker = partOpt ? resultParts.markerLine(partOpt.n, partOpt.m) : null;

// A results comment of THIS target: the header, and — for a split comment — this part's own marker line.
function isTargetComment(commentBody) {
  if (typeof commentBody !== 'string' || !commentBody.trimStart().startsWith('h2. QA Test Results')) return false;
  return !partMarker || commentBody.split('\n').some(l => l.trim() === partMarker);
}

const issueKey = argv[0];
// Where the caller records this comment's id: a split part has its own slot, a single comment uses results_comment_id.
const idSlot = partOpt ? `result_parts[${partOpt.n - 1}].comment_id` : 'results_comment_id';
let bodyArg, inlineBody, knownCommentId, notBeforeIso;
if (argv[1] === '--inline') {
  bodyArg        = '--inline';
  inlineBody     = argv[2];
  knownCommentId = optionalArg(argv[3]);
  notBeforeIso   = optionalArg(argv[4]);
} else {
  bodyArg        = argv[1];
  knownCommentId = optionalArg(argv[2]);
  notBeforeIso   = optionalArg(argv[3]);
}

if (!issueKey || !bodyArg || (bodyArg === '--inline' && !inlineBody)) {
  process.stderr.write(
    'Usage: node post-comment.js <issue_key> <body_file> [<known_comment_id>] [<not_before_iso>] [--part <n>/<m> --tc-ids <csv> --run-total <n>]\n' +
    '       node post-comment.js <issue_key> --inline "<body>" [<known_comment_id>] [<not_before_iso>]\n'
  );
  process.exit(1);
}

// Fail loudly on a likely argument-order swap rather than silently misbehave — a real
// risk for an LLM-driven caller reconstructing the call after context compaction.
// Jira comment ids are digits-only; an ISO timestamp will never match that shape, and
// a bare id will never parse as a date.
if (knownCommentId && !/^\d+$/.test(knownCommentId)) {
  process.stderr.write(
    `Usage error: <known_comment_id> ("${knownCommentId}") doesn't look like a Jira comment id ` +
    `(expected digits only). Check argument order — did you swap it with <not_before_iso>?\n`
  );
  process.exit(1);
}
if (notBeforeIso) {
  const parsedNotBefore = Date.parse(notBeforeIso);
  // A bare id string like "10501" is NOT NaN under Date.parse (V8 reads it as a year far
  // in the future) — a plausibility bound catches that swap where the NaN check alone
  // wouldn't. cycle_started_at is always "now or in the recent past" relative to when
  // this script runs, so anything more than a day in the future cannot be genuine.
  const ONE_DAY_MS = 24 * 60 * 60 * 1000;
  if (Number.isNaN(parsedNotBefore) || parsedNotBefore > Date.now() + ONE_DAY_MS) {
    process.stderr.write(
      `Usage error: <not_before_iso> ("${notBeforeIso}") doesn't look like a real cycle_started_at timestamp. ` +
      `Check argument order — did you swap it with <known_comment_id>?\n`
    );
    process.exit(1);
  }
}

const fs   = require('fs');
const path = require('path');

// ─── Credentials ────────────────────────────────────────────────────────────

function loadCredentials() {
  let email    = process.env.JIRA_EMAIL    || '';
  let apiToken = process.env.JIRA_API_TOKEN || '';
  if (!email || !apiToken) {
    try {
      const home = process.env.USERPROFILE || process.env.HOME || '';
      if (!home) throw new Error('no home dir');
      const settingsPath = path.join(home, '.claude', 'settings.json');
      const s = JSON.parse(fs.readFileSync(settingsPath, 'utf8'));
      if (s && s.env) {
        email    = email    || s.env.JIRA_EMAIL    || '';
        apiToken = apiToken || s.env.JIRA_API_TOKEN || '';
      }
    } catch { /* settings.json unreadable — fall through */ }
  }
  return { email, apiToken };
}

const { email, apiToken } = loadCredentials();
if (!validateOnly && (!email || !apiToken)) {
  process.stderr.write('Missing JIRA_EMAIL or JIRA_API_TOKEN.\n');
  process.exit(1);
}

const auth    = Buffer.from(`${email}:${apiToken}`).toString('base64');
const headers = { Authorization: `Basic ${auth}`, 'Content-Type': 'application/json', Accept: 'application/json' };
const baseUrl = `https://maxxton.atlassian.net/rest/api/2/issue/${encodeURIComponent(issueKey)}`;

// ─── Load body ───────────────────────────────────────────────────────────────

const body = bodyArg === '--inline'
  ? inlineBody
  : fs.readFileSync(bodyArg, 'utf8');

// ─── Format validation ───────────────────────────────────────────────────────

function validateBody(text) {
  const lines  = text.split('\n');
  const errors = [];

  // 0. UTF-8 text decoded as Windows-1252 ("PASS âœ…", "â€”", "Â·") — what Windows PowerShell 5.1 Get-Content does to a
  // BOM-less UTF-8 file. KEEP IN SYNC with validate-results-comment.js and post-tc-comment.js.
  const garbled = [...new Set((text.match(/[ÂÃâ][\u0080-¿ŒœŠšŸŽžƒˆ˜–—‘-„†-•…‰‹›€™]|�/g) || []).map(h => `"${h}"`))].slice(0, 5);
  if (garbled.length) {
    errors.push(
      `[CHECK 0] Garbled characters (mojibake) in the body: ${garbled.join(', ')} — UTF-8 text was decoded as Windows-1252.\n` +
      `  The body file was read back with Windows PowerShell's Get-Content (default ANSI code page), or rebuilt from text read that way.\n` +
      `  Rebuild it from the template below and save it with the Write tool; read files with the Read tool or Get-Content -Encoding utf8.`
    );
  }

  // 1. First non-empty line must be exactly "h2. QA Test Results"
  const firstContent = lines.find(l => l.trim().length > 0);
  if (firstContent?.trim() !== 'h2. QA Test Results') {
    errors.push(
      `[CHECK 1] Wrong header. First line must be exactly "h2. QA Test Results".\n` +
      `  Found: "${firstContent?.trim() ?? '(empty)'}"\n` +
      `  Common mistakes: adding emoji, using "##", "QA Pipeline Results",\n` +
      `  "Phase 3a Execution Results", "QA Pipeline – Test Cases & Execution Evidence", etc.`
    );
  }

  // 2. Required stats table rows
  const REQUIRED_STATS = [
    '| *Concern*', '| *Environment*', '| *Build / Version*', '| *Preconditions*', '| *Total TCs*', '| *Passed*',
    '| *Failed*', '| *Blocked*', '| *Needs Review*', '| *Skipped*', '| *Pass rate*', '| *QA Pipeline Version*', '| *Test Execution Timing*',
  ];
  for (const row of REQUIRED_STATS) {
    if (!lines.some(l => l.includes(row))) {
      errors.push(`[CHECK 2] Missing stats table row: ${row}`);
    }
  }

  // 16/17. The stats rows the dashboard reads hold plain values: a timing number, whole counts, a version.
  // KEEP IN SYNC with validate-results-comment.js; the rules live in dashboard-stats.js.
  errors.push(...statsErrors(text));

  // 3. Exact TC table header: the 6-column results table, or the 12-column merged table (see results-layout.js)
  const layout = resultsLayout.wikiLayout(lines);
  if (!layout) {
    errors.push(
      `[CHECK 3] TC table header not found or wrong columns.\n` +
      `  Expected exactly: ${resultsLayout.wikiHeader(resultsLayout.RESULTS_COLS)}\n` +
      `  or (a retest of a story whose Test Cases comment was merged): ${resultsLayout.wikiHeader(resultsLayout.MERGED_COLS)}\n` +
      `  Do NOT add, remove, or rename columns (Verdict, Notes, Scenario are wrong).`
    );
  }
  const expectedCells = layout ? layout.cols.length : 6;

  // 4. No Markdown ## headers
  const mdHeaders = lines.filter(l => /^#{1,6}\s/.test(l.trim()));
  if (mdHeaders.length > 0) {
    errors.push(
      `[CHECK 4] Markdown headers (##) found — use wiki markup (h2. / h3.) only.\n` +
      `  This means the body was built for addOrEditJiraIssueComment (wrong API).\n` +
      `  Phase 3b results MUST use post-comment.js (API v2 wiki markup).\n` +
      `  Found: ${mdHeaders.slice(0, 3).map(l => `"${l.trim()}"`).join(', ')}`
    );
  }

  // 5. No per-TC prose sections
  const PROSE_PATTERNS = [/^\*\*Steps:\*\*/i, /^\*\*Expected:\*\*/i, /^\*\*Actual:\*\*/i, /^\*\*Screenshot:\*\*/i, /^Steps:/i, /^Expected:/i, /^Actual:/i, /^Screenshot:/i];
  const proseLines = lines.filter(l => PROSE_PATTERNS.some(p => p.test(l.trim())));
  if (proseLines.length > 0) {
    errors.push(
      `[CHECK 5] Per-TC prose sections detected. Each TC must be a single table row only.\n` +
      `  Found: ${proseLines.slice(0, 3).map(l => `"${l.trim()}"`).join(', ')}`
    );
  }

  // 6. No internal pipeline phase labels
  const PHASE_PATTERNS = [/phase\s*3a/i, /phase\s*1\b/i, /phase\s*2\b/i, /execution results/i, /test cases & execution evidence/i, /qa pipeline\s*[-–]/i, /execution summary/i, /pipeline summary/i, /tester:\s*qa pipeline/i];
  // In a merged table only the Actual result and Test Proof cells are pipeline text (scenario, preconditions and steps come
  // from the ticket). KEEP IN SYNC with update-comment.js.
  const scanLines = lines.map(l => {
    if (!layout || layout.name !== 'merged' || !/^\|\s*TC_\d+\s*\|/.test(l.trim())) return l;
    const cells = l.trim().split('|').slice(1, -1);
    return [cells[layout.actual], cells[layout.proof]].filter(Boolean).join(' ');
  });
  const phaseLines = scanLines.filter(l => PHASE_PATTERNS.some(p => p.test(l)));
  if (phaseLines.length > 0) {
    errors.push(
      `[CHECK 6] Internal pipeline labels found — these must never appear in Jira.\n` +
      `  Found: ${phaseLines.slice(0, 3).map(l => `"${l.trim()}"`).join(', ')}`
    );
  }

  // 7. No supplement/appendix markers. A split comment's own "_Part n of m_" line is the one sanctioned exception.
  const SUPPLEMENT_PATTERNS = [/supersedes/i, /supplement/i, /appendix/i, /part\s*2/i, /full evidence/i];
  const suppLines = scanLines.filter(l => !(partOpt && resultParts.isMarkerLine(l)) && SUPPLEMENT_PATTERNS.some(p => p.test(l)));
  if (suppLines.length > 0) {
    errors.push(
      `[CHECK 7] Supplement/appendix markers found — only ONE results comment per story per run.\n` +
      `  Found: ${suppLines.slice(0, 2).map(l => `"${l.trim()}"`).join(', ')}`
    );
  }

  // 8. Every TC row must have a screenshot in Test Proof column
  const tcRows = lines.filter(l => /^\|\s*TC_\d+\s*\|/.test(l.trim()));
  const badProof = [];
  // Use regex to extract the last cell — avoids wrong split when Actual Result contains "|"
  // Wiki markup row: | TC_01 | ... | ... | ... | PASS ✅ | !TC_01-slug.png! |
  // Capture last non-empty cell before trailing |
  const lastCellRe = /\|\s*([^|]+?)\s*\|\s*$/;
  const tcIdRe     = /^\|\s*(TC_\d+)\s*\|/;
  // Requires the actual naming convention (TC_XX-slug.png), not a bare ".png" substring —
  // fabricated text like "fake-TC01.png" or a stray ".png" in prose must not pass.
  // Optional trailing (\\ ...) allows FAIL/BLOCKED debug evidence appended after the image ref,
  // joined with Jira's forced line-break token \\ followed by a mandatory space (see Debug
  // Evidence Capture in references/phase-3a-execution.md, and the space-requirement note in
  // references/phase-3b-results-comment.md — confirmed in production, MXTS-77020, 2026-09-24: a
  // bare \\ with no trailing space is not recognized by Jira's wiki-markup renderer as a line
  // break inside a table cell, it renders as two literal visible backslash characters instead).
  // The evidence text itself must never contain a literal "|" — that would split the cell into
  // an extra column and this regex would (correctly) reject it.
  //
  // Three accepted shapes (see references/phase-3b-results-comment.md "Test Proof" rule):
  //   MXTS (single screenshot):   !TC_XX-slug.png!  or  TC_XX-slug.png
  //   MCMS (Before/After pair):   Before:\\ <TC_XX-slug-before.png>\\ After:\\ <TC_XX-slug-after.png>
  //   Multi-item (2+ named items, e.g. one screenshot per language actually verified):
  //     <Label 1>:\\ <TC_XX-slug-1.png>\\ <Label 2>:\\ <TC_XX-slug-2.png>[\\ <Label 3>:\\ ...]
  // — each optionally followed by (note) and/or a trailing \\ debug-evidence.
  const PROOF_RE       = /^(!TC_\d+-[\w-]+\.png!|TC_\d+-[\w-]+\.png)(\s*\([^|]*\))?(\\\\ [^|]+)?$/i;
  const PROOF_RE_MCMS  = /^Before:\\\\ (!TC_\d+-[\w-]+-before\.png!|TC_\d+-[\w-]+-before\.png)(\s*\([^|]*\))?\\\\ After:\\\\ (!TC_\d+-[\w-]+-after\.png!|TC_\d+-[\w-]+-after\.png)(\s*\([^|]*\))?(\\\\ [^|]+)?$/i;
  // A "label" is any non-empty run of characters that isn't a cell delimiter (|) or the
  // line-break token itself (\) — e.g. "Spanish", "English (US)" — followed by ": " and one
  // image reference. Requires at least 2 items; a single labeled item should use the plain
  // MXTS shape above instead, so this never accidentally accepts a malformed single-item cell.
  const PROOF_ITEM      = '[^|\\\\]+:\\\\\\\\ (?:!TC_\\d+-[\\w-]+\\.png!|TC_\\d+-[\\w-]+\\.png)(?:\\s*\\([^|]*\\))?';
  const PROOF_RE_MULTI  = new RegExp(`^(?:${PROOF_ITEM})(?:\\\\\\\\ ${PROOF_ITEM}){1,}(\\\\\\\\ [^|]+)?$`, 'i');
  for (const row of tcRows) {
    const tcId = (tcIdRe.exec(row.trim()) || [])[1] || '?';
    const lastCellMatch = lastCellRe.exec(row);
    const proof = lastCellMatch ? lastCellMatch[1].trim() : '';
    if (!PROOF_RE.test(proof) && !PROOF_RE_MCMS.test(proof) && !PROOF_RE_MULTI.test(proof)) {
      badProof.push(`${tcId}: "${proof}"`);
    }
  }
  if (badProof.length > 0) {
    errors.push(
      `[CHECK 8] Missing/malformed screenshot proof in Test Proof column for ${badProof.length} TC(s).\n` +
      `  MXTS needs exactly: !TC_XX-slug.png! (upload succeeded), TC_XX-slug.png (upload failed),\n` +
      `  or TC_XX-capture-failed.png (note) (capture itself failed).\n` +
      `  MCMS needs exactly: Before:\\\\ <before-file>\\\\ After:\\\\ <after-file> (note the space\n` +
      `  after each \\\\ — Jira's line-break token requires it, a bare \\\\ renders as literal text),\n` +
      `  each half using the same succeeded/failed/capture-failed forms as MXTS and named\n` +
      `  TC_XX-slug-before.png / TC_XX-slug-after.png.\n` +
      `  Multi-item (a TC covering 2+ named items, e.g. one screenshot per language actually\n` +
      `  verified) needs: <Label>:\\\\ <file>\\\\ <Label>:\\\\ <file>[\\\\ <Label>:\\\\ <file>...], each\n` +
      `  item using the same succeeded/failed/capture-failed forms as MXTS.\n` +
      `  Any shape may end with \\\\ <sanitized debug evidence, no "|" character> for FAIL/BLOCKED.\n` +
      `  No other text is accepted. Affected: ${badProof.slice(0, 5).join(', ')}`
    );
  }

  // 13. "-capture-failed.png" is only for a screenshot that really failed 3 attempts — never "skipped" or
  // "verified via API/DOM". KEEP IN SYNC with update-comment.js and validate-results-comment.js.
  const badCapture = tcRows.filter(row => {
    const m = lastCellRe.exec(row);
    return /[\w-]*capture-failed[\w-]*\.png(?!\s*\(screenshot capture failed — 3\/3 attempts, [^)|]+\))/i.test(m ? m[1] : '');
  }).map(row => (tcIdRe.exec(row.trim()) || [])[1] || '?');
  if (badCapture.length > 0) {
    errors.push(
      `[CHECK 13] Test Proof says the screenshot capture failed or was skipped without the required note.\n` +
      `  A screenshot is mandatory for every TC — API/DOM verification is never a substitute and capture is never skipped.\n` +
      `  Take the screenshot (retry up to 3 attempts, see Phase 3a). Only after 3 real failed attempts may the cell read:\n` +
      `  TC_XX-capture-failed.png (screenshot capture failed — 3/3 attempts, <error>)\n` +
      `  Affected: ${badCapture.slice(0, 5).join(', ')}`
    );
  }

  // 9. No "\|" anywhere in a TC row — this has happened in production (an Actual Result
  // describing an API condition as "offDuty>=today\|\|null" instead of writing "OR").
  // "\|" is NOT a recognized escape in Jira wiki markup — the backslash renders as a
  // literal character and the "|" still delimits the cell, corrupting the row either way.
  const badEscape = [];
  for (const row of tcRows) {
    if (row.includes('\\|')) {
      const tcId = (tcIdRe.exec(row.trim()) || [])[1] || '?';
      badEscape.push(tcId);
    }
  }
  if (badEscape.length > 0) {
    errors.push(
      `[CHECK 9] Literal "\\|" found in ${badEscape.length} TC row(s) — not a valid Jira wiki-markup\n` +
      `  escape. Rewrite the cell without "|" — spell out boolean/logical conditions in words\n` +
      `  ("OR"/"AND") instead of "||"/"&&", or use "/" as the substitution.\n` +
      `  Affected: ${badEscape.slice(0, 5).join(', ')}`
    );
  }

  // 10. Per-row column-count check — catches a bare, unescaped "|" inside any cell, not just
  // the "\|" escape attempt CHECK 9 targets. A stray "|" anywhere in a cell still splits the
  // row into extra columns and corrupts it. Strip legitimate Jira link syntax ([text|url]) first
  // — that's the one place "|" is structurally valid inside a cell — so it isn't a false positive.
  const badColumnCount = [];
  for (const row of tcRows) {
    if (row.includes('\\|')) continue; // already reported by CHECK 9 above
    const tcId = (tcIdRe.exec(row.trim()) || [])[1] || '?';
    const stripped = row.replace(/\[[^\]]*\|[^\]]*\]/g, '[LINK]');
    const segments = stripped.split('|');
    // Well-formed: "| c1 | ... | cN |" -> N + 2 segments (N cells + 2 boundary empties); N is 6, or 12 in a merged table.
    if (segments.length !== expectedCells + 2) {
      badColumnCount.push(`${tcId} (${segments.length - 2} cells found, expected ${expectedCells})`);
    }
  }
  if (badColumnCount.length > 0) {
    errors.push(
      `[CHECK 10] Wrong column count in ${badColumnCount.length} TC row(s) — a stray unescaped "|"\n` +
      `  inside a cell (not just "\\|") also corrupts a Jira wiki-markup row by splitting it into\n` +
      `  extra columns. Rewrite the cell without "|" — spell out boolean/logical conditions in\n` +
      `  words ("OR"/"AND") instead of "||"/"&&", or use "/" as the substitution.\n` +
      `  Affected: ${badColumnCount.slice(0, 5).join(', ')}`
    );
  }

  // 11. Cross-Module Impact "Team" value must be an exact canonical cf[10049] name — never a
  // paraphrase with "Frontend"/"Backend"/"FE"/"BE" appended. Confirmed in production (MXTS-81825,
  // Sep 2026): "Templates backend" was posted instead of "Templates", which — exactly as
  // analyzing-impact/SKILL.md's own warning predicts — silently blanked the QA mention cell
  // instead of failing loudly. Pattern check only (not a full canonical-list match, to avoid
  // duplicating/maintaining that list here) — catches the exact confirmed failure shape.
  const impactStart = lines.findIndex(l => l.trim() === 'h2. Cross-Module Impact');
  if (impactStart !== -1) {
    let impactEnd = lines.findIndex((l, i) => i > impactStart && /^h2\.\s/.test(l.trim()));
    if (impactEnd === -1) impactEnd = lines.length;
    const impactRows = lines.slice(impactStart, impactEnd)
      .filter(l => l.trim().startsWith('|') && !l.trim().startsWith('||'));
    const badTeamSuffix = [];
    for (const row of impactRows) {
      const cells = row.split('|').slice(1, -1).map(c => c.trim());
      const team = cells[1]; // | Module | Team | QA | Impact Type | What is affected |
      if (team && /\s(frontend|backend|fe|be)$/i.test(team)) {
        badTeamSuffix.push(team);
      }
    }
    if (badTeamSuffix.length > 0) {
      errors.push(
        `[CHECK 11] Cross-Module Impact "Team" value has a Frontend/Backend/FE/BE suffix —\n` +
        `  must be the exact canonical cf[10049] value (e.g. "Email Notifications", never "Email Notifications backend").\n` +
        `  A distorted value silently blanks the QA mention cell instead of failing loudly.\n` +
        `  Affected: ${badTeamSuffix.join(', ')}`
      );
    }

    // 12. A Team known (from analyzing-impact/SKILL.md's QA ownership reference) to have a
    // documented QA owner must actually carry a real "[~accountid:...]" mention in its QA cell —
    // not blank, not a plain/paraphrased name. Fixing the Team string alone (CHECK 11) forces the
    // lookup to succeed again, but nothing previously verified the mention itself made it into the
    // cell — the same class of gap the Slack-side "verify the mention is actually in the string"
    // audit already exists for (analyzing-impact/SKILL.md, MXTS-77438), just missing on this Jira
    // wiki-markup path. KEEP THIS LIST IN SYNC with the QA ownership reference table's row keys —
    // only the unambiguous single-cf[10049]-value rows are included; rows
    // without a confirmed cf[10049] value are left out to avoid a false positive on a mapping this
    // script doesn't own.
    const TEAMS_WITH_QA_OWNERS = [
      'Reservations/CCM/NM', 'Finance / Owner / Compliance', 'Content & Back Office', 'Channel Manager',
      'Revenue & Availability', 'Revenue & Channel', 'Third Parties - API', 'Third Parties - Connections',
      'Email Notifications', 'FrontOps', 'Web Manager - Development', 'Reporting & BI',
    ];
    const missingMention = [];
    for (const row of impactRows) {
      const cells = row.split('|').slice(1, -1).map(c => c.trim());
      const team = cells[1];
      const qa = cells[2] || '';
      if (team && TEAMS_WITH_QA_OWNERS.includes(team) && !/\[~accountid:[^\]\s][^\]]*\]/.test(qa)) {
        missingMention.push(team);
      }
    }
    if (missingMention.length > 0) {
      errors.push(
        `[CHECK 12] Cross-Module Impact QA cell has no real mention for team(s) with a documented\n` +
        `  QA owner: ${missingMention.join(', ')}. Use "[~accountid:<Jira Account ID>]" from the QA\n` +
        `  ownership reference (analyzing-impact/SKILL.md) — never leave it blank, and never write a\n` +
        `  plain name or email instead of the real mention token.`
      );
    }
  }

  // 21. The footer counts what the Automate/Automated column says (results-layout.js).
  errors.push(...resultsLayout.footerCountErrors(text));

  // 14. Split comment: the part marker, exactly the TCs assigned to this part, Cross-Module Impact only in the last part.
  errors.push(...resultParts.partErrors(text, partOpt, partTcIds, runTotal));

  return errors;
}

// Canonical template — printed on failure so the body can be rebuilt WITHOUT any
// context (e.g. after mid-run context compaction, when SKILL.md is no longer in
// the conversation). Keep byte-for-byte in sync with the Phase 3b template in SKILL.md.
const CANONICAL_TEMPLATE = [
  'h2. QA Test Results',
  '',
  '| *Concern* | <MQA / RCN / KRM-CMS / ... or "Generation only"> |',
  '| *Environment* | <Dev / Test or "Generation only"> |',
  '| *Build / Version* | <build_version> |',
  '| *Preconditions* | <summary from stories.<STORY_KEY>.preconditions_verified, or "None detected"> |',
  '| *Total TCs* | <n> |',
  '| *Passed* | <n> |',
  '| *Failed* | <n> |',
  '| *Blocked* | <n> |',
  '| *Needs Review* | <n> |',
  '| *Skipped* | <n> |',
  '| *Pass rate* | <n>% (BLOCKED and Skipped excluded), or N/A (no TC verified) if Total minus Blocked minus Skipped is 0 |',
  '| *QA Pipeline Version* | <qa-engineer plugin version, from plugin.json> |',
  '| *Test Execution Timing* | <n>m or <n>h <n>m, then " (<n> pause)" / " (<n> pauses)" when the run had pauses; N/A (generation only) only if Phase 3a never ran |',
  '',
  '|| TC_ID || Test case scenario || Expected Result || Actual Result || Status || Test Proof ||',
  '| TC_01 | <scenario> | <expected> | <actual> | PASS ✅ | !TC_01-slug.png! |',
  '(one row per TC — no prose sections, no phase labels, no Markdown ## headers)',
  '(MXTS Test Proof: !TC_XX-slug.png! — MCMS Test Proof: Before:\\\\ !TC_XX-slug-before.png!\\\\ After:\\\\ !TC_XX-slug-after.png! — note the space after each \\\\, a bare \\\\ renders as literal text in Jira)',
  '(no separate hostname heading in multi-URL comments — Concern/Environment inside each block already identify it)',
  '(split comment only: the line "_Part <n> of <m>_" right after the header, only this part\'s TCs, Cross-Module Impact only in the last part)',
].join('\n');

const validationErrors = validateBody(body);
if (validationErrors.length > 0) {
  process.stderr.write(
    `\n❌ post-comment.js BLOCKED — comment body failed validation (${validationErrors.length} issue(s)).\n` +
    `Discard this draft and rebuild by copying the exact template below — do NOT reconstruct\n` +
    `the format from memory (it may be stale after context compaction):\n\n` +
    `──────── COPY THIS TEMPLATE ────────\n${CANONICAL_TEMPLATE}\n────────────────────────────────────\n\n` +
    validationErrors.join('\n\n') + '\n'
  );
  process.exit(1);
}

if (validateOnly) {
  process.stdout.write('OK\n');
  process.exit(0);
}

// ─── Known-comment guard (cycle-scoped — checks only the ID the caller already knows
// about from run-state.json, never scans Jira's full comment history) ────────────────
// This is deliberate: a story that goes Reopened → fixed → retested must get a BRAND
// NEW results comment for that cycle, with the prior cycle's comment left untouched as
// history. Scanning all history for any "h2. QA Test Results" comment (the old design)
// would find that prior-cycle comment and wrongly block the new cycle's post.

async function verifyKnownComment(commentId) {
  const res = await fetch(`${baseUrl}/comment/${encodeURIComponent(commentId)}`, { headers });
  if (res.status === 404) return null; // recorded id no longer exists — safe to post fresh
  if (!res.ok) throw new Error(`GET comment ${commentId} failed: ${res.status}`);
  const data = await res.json();
  if (isTargetComment(data.body)) {
    return data;
  }
  return null; // id exists but isn't a results comment — fail open, allow the post
}

// Fallback safety net for when results_comment_id was never recorded (crash/compaction
// between the Jira POST succeeding and the id being persisted to run-state.json).
// Scoped to THIS cycle only via cycle_started_at — never treats an older, pre-reopen
// cycle's comment as a duplicate, because that comment's `created` predates the cutoff.
//
// Buffer is intentionally small (seconds, not minutes): cycle_started_at is stamped at
// the very start of Phase 3a, before any TC executes, so in the ordinary case there are
// several minutes of real execution time between the stamp and the eventual post — a
// wide buffer isn't needed for that gap and actively hurts a FAST retest: a large buffer
// pushes the cutoff backward far enough to wrongly match the PRIOR cycle's own results
// comment if the reopen+retest happens soon after it was posted. 30s comfortably covers
// realistic NTP clock drift without reaching back into the previous cycle's window.
const CLOCK_SKEW_BUFFER_MS = 30 * 1000;

async function findResultsCommentSince(isoTimestamp) {
  const parsedMs = Date.parse(isoTimestamp);
  if (Number.isNaN(parsedMs)) return null; // malformed timestamp — fail open, let the post proceed
  const cutoffMs = parsedMs - CLOCK_SKEW_BUFFER_MS;
  const pageSize = 100;
  let startAt = 0;
  let total   = Infinity;
  while (startAt < total) {
    const res = await fetch(`${baseUrl}/comment?startAt=${startAt}&maxResults=${pageSize}&orderBy=-created`, { headers });
    if (!res.ok) throw new Error(`GET comments failed: ${res.status}`);
    const data = await res.json();
    const page = data.comments || [];
    // Full scan of every comment on this page, filtered by date — deliberately NOT an
    // early-exit the moment one comment looks older than the cutoff. Correctness here
    // must not depend on the API actually honoring strict -created order; only the
    // pagination loop (identical to the original duplicate-guard's) relies on it.
    // A merged comment is the Test Cases comment edited in place, so it was CREATED in Phase 2, before this cycle began:
    // what shows it belongs to this cycle is that it was UPDATED at/after the cutoff.
    const hit = page.find(c => {
      if (!isTargetComment(c.body)) return false;
      const createdMs = Date.parse(c.created);
      if (!Number.isNaN(createdMs) && createdMs >= cutoffMs) return true;
      const updatedMs = Date.parse(c.updated);
      return !Number.isNaN(updatedMs) && updatedMs >= cutoffMs && isMergedBody(c.body);
    });
    if (hit) return hit;
    total = typeof data.total === 'number' ? data.total : Infinity;
    if (page.length === 0) break;
    startAt += page.length;
  }
  return null;
}

// Last-resort fallback — ONLY when the caller supplied NEITHER known_comment_id NOR
// not_before_iso (no cycle-scoping info at all, e.g. Generation Only mode, which never
// runs Phase 3a and so never stamps cycle_started_at). Restores the original design:
// scan the FULL comment history and block if any "h2. QA Test Results" comment exists.
// This deliberately sacrifices the new-comment-per-cycle behavior for such calls (a
// retest through this path can't distinguish "prior cycle" from "this cycle", so it
// conservatively blocks, same as before this feature existed) in exchange for NEVER
// silently posting an uncontrolled duplicate when we have zero signal to reason from.
async function findAnyResultsComment() {
  const pageSize = 100;
  let startAt = 0;
  let total   = Infinity;
  while (startAt < total) {
    const res = await fetch(`${baseUrl}/comment?startAt=${startAt}&maxResults=${pageSize}&orderBy=-created`, { headers });
    if (!res.ok) throw new Error(`GET comments failed: ${res.status}`);
    const data = await res.json();
    const page = data.comments || [];
    const hit = page.find(c => isTargetComment(c.body));
    if (hit) return hit;
    total = typeof data.total === 'number' ? data.total : Infinity;
    if (page.length === 0) break;
    startAt += page.length;
  }
  return null;
}

const isMergedBody = (commentBody) =>
  typeof commentBody === 'string' && resultsLayout.wikiLayout(commentBody.split('\n'))?.name === 'merged';

// Merge guard — reads only Jira, so it holds after a context compaction or a lost run-state.json. The first results of a
// story are written INTO its Test Cases comment (update-comment.js, merged layout); a separate results comment is only
// for a later cycle. So: an unmerged "h2. Test Cases —" comment (this part's, for a split) with no results comment
// beside it (this part's marker, for a split) means this post would be the duplicate. Older tickets that already have
// their separate results comment are not affected.
async function findUnmergedTestCases() {
  const pageSize = 100;
  let startAt = 0;
  let total = Infinity;
  let testCases = null;
  let hasResults = false;
  const hasMarker = (b) => !partMarker || b.split('\n').some(l => l.trim() === partMarker);
  while (startAt < total) {
    const res = await fetch(`${baseUrl}/comment?startAt=${startAt}&maxResults=${pageSize}&orderBy=-created`, { headers });
    if (!res.ok) throw new Error(`GET comments failed: ${res.status}`);
    const data = await res.json();
    const page = data.comments || [];
    for (const c of page) {
      if (typeof c.body !== 'string') continue;
      if (c.body.trimStart().startsWith('h2. Test Cases —') && hasMarker(c.body)) testCases = testCases || c;
      if (isTargetComment(c.body)) hasResults = true;
    }
    total = typeof data.total === 'number' ? data.total : Infinity;
    if (page.length === 0) break;
    startAt += page.length;
  }
  return testCases && !hasResults ? testCases : null;
}

// Prints the screenshot check on stderr and returns the exit code: 0 when every screenshot the body names is
// attached to the issue, 3 when one is not or when Jira could not be asked.
async function reportScreenshots(commentId) {
  try {
    const result = await screenshotAttachments.check(body, baseUrl, headers);
    process.stderr.write(`${screenshotAttachments.describe(result, issueKey, commentId)}\n`);
    return result.missing.length === 0 ? 0 : 3;
  } catch (err) {
    process.stderr.write(`⚠️  Screenshots: could not be checked for ${issueKey} (${err.message}). Run this same command again to check.\n`);
    return 3;
  }
}

(async () => {
  if (knownCommentId) {
    let existing;
    try {
      existing = await verifyKnownComment(knownCommentId);
    } catch (err) {
      // Fail closed only for the id we were explicitly told to check — never falls back
      // to scanning full history, so a transient GET failure cannot block a new cycle.
      process.stderr.write(
        `❌ post-comment.js — could not verify known comment ${knownCommentId}: ${err.message}\n` +
        `Not posting (failed closed) to avoid a same-cycle duplicate. Retry once the API is reachable.\n`
      );
      process.exit(1);
    }
    if (existing) {
      process.stdout.write(
        `⚠️  Already posted this cycle: results comment (id=${existing.id}) is still on ${issueKey}.\n` +
        `This is a resume/retry within the same cycle, not a new one — do NOT post again.\n` +
        `If it needs correcting, use update-comment.js instead.\n`
      );
      // process.exit() right after an HTTPS fetch aborts Node on Windows (libuv assertion, exit 127).
      process.exitCode = await reportScreenshots(existing.id);
      return;
    }
    // knownCommentId no longer resolves to a results comment (e.g. deleted) — fall through.
  }

  if (notBeforeIso) {
    let existingSince;
    try {
      existingSince = await findResultsCommentSince(notBeforeIso);
    } catch (err) {
      process.stderr.write(
        `❌ post-comment.js — could not verify no in-cycle comment exists: ${err.message}\n` +
        `Not posting (failed closed) to avoid a same-cycle duplicate. Retry once the API is reachable.\n`
      );
      process.exit(1);
    }
    if (existingSince) {
      process.stdout.write(
        `⚠️  Already posted this cycle: found results comment (id=${existingSince.id}, created ${existingSince.created}) ` +
        `on ${issueKey} at/after ${notBeforeIso} — ${idSlot} was likely lost before it could be recorded.\n` +
        `This is a resume, not a new cycle — do NOT post again. Persist stories["${issueKey}"].${idSlot} = ${existingSince.id} in run-state.json now.\n`
      );
      process.exitCode = await reportScreenshots(existingSince.id);
      return;
    }
  }

  if (!knownCommentId && !notBeforeIso) {
    // No cycle-scoping signal supplied at all — see findAnyResultsComment's header comment.
    let existingAny;
    try {
      existingAny = await findAnyResultsComment();
    } catch (err) {
      process.stderr.write(
        `❌ post-comment.js — no known_comment_id or cycle_started_at supplied, and the fallback duplicate ` +
        `check could not run: ${err.message}\nNot posting (failed closed). Retry once the API is reachable.\n`
      );
      process.exit(1);
    }
    if (existingAny) {
      process.stdout.write(
        `⚠️  Duplicate blocked: a results comment (id=${existingAny.id}) already exists on ${issueKey}, and no ` +
        `cycle-scoping info was passed to tell a prior cycle apart from this one.\n` +
        `If this is genuinely a new test cycle (e.g. after a reopen) and cycle_started_at is available in ` +
        `run-state.json, pass it instead of calling with no trailing args. If the existing comment just needs ` +
        `correcting, use update-comment.js instead.\n`
      );
      process.exitCode = 0;
      return;
    }
  }

  let unmerged;
  try {
    unmerged = await findUnmergedTestCases();
  } catch (err) {
    process.stderr.write(
      `❌ post-comment.js — could not check for an unmerged Test Cases comment: ${err.message}\n` +
      `Not posting (failed closed) to avoid a second comment. Retry once the API is reachable.\n`
    );
    process.exit(1);
  }
  if (unmerged) {
    process.stderr.write(
      `❌ post-comment.js BLOCKED — ${issueKey} still has its Test Cases comment (id=${unmerged.id}) and no results comment${partMarker ? ` for ${partMarker}` : ''}.\n` +
      `The first results of a story go INTO that comment, not into a new one. Persist stories["${issueKey}"].tc_comment_id = ${unmerged.id}, build the merged body\n` +
      `(h2. QA Test Results, stats table, the 12-column table: ${resultsLayout.wikiHeader(resultsLayout.MERGED_COLS)}) and run:\n` +
      `  node update-comment.js ${issueKey} ${unmerged.id} <body_file>${partOpt ? ` --part ${partOpt.n}/${partOpt.m} --tc-ids <csv> --run-total <n>` : ''}\n`
    );
    process.exit(1);
  }

  return postComment();
})();

// ─── Post ─────────────────────────────────────────────────────────────────────

function postComment() {
  return fetch(`${baseUrl}/comment`, {
    method:  'POST',
    headers,
    body:    JSON.stringify({ body }),
  })
    .then(res => {
      if (!res.ok) {
        return res.text().then(t => {
          process.stderr.write(`Jira API error ${res.status}: ${t}\n`);
          process.exit(1);
        });
      }
      return res.json();
    })
    .then(async data => {
      process.stdout.write(String(data.id) + '\n');
      process.exitCode = await reportScreenshots(data.id);
    })
    .catch(err => {
      process.stderr.write(`Post failed: ${err.message}\n`);
      process.exit(1);
    });
}
