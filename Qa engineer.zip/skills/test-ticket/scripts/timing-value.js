/**
 * Test Execution Timing cell of a results comment — the one shape the adoption dashboard parses.
 *
 *   `<m>m` or `<h>h <m>m`, minutes 0-59, hours only from 1h, then ` (<n> pause)` / ` (<n> pauses)` when the run
 *   was paused (n >= 1; no suffix at all for an uninterrupted run).
 *   `N/A (generation only)` is the single exception, for a run where Phase 3a never executed.
 *
 * Shared by post-comment.js, update-comment.js and validate-results-comment.js.
 */
const GENERATION_ONLY = 'N/A (generation only)';
const TIMING_RE = /^(?:\d+h [0-5]?\d|[0-5]?\d)m(?: \((?:1 pause|(?:[2-9]|[1-9]\d+) pauses)\))?$/;

function timingError(value, where = '') {
  const v = String(value ?? '').trim();
  if (v === GENERATION_ONLY || TIMING_RE.test(v)) return null;
  return `[CHECK 16] Test Execution Timing${where} must be a number: "<m>m" or "<h>h <m>m", with " (<n> pause)" / " (<n> pauses)" ` +
    `appended when the run had pauses (e.g. "38m (2 pauses)", "1h 12m (1 pause)", "42m"). Never N/A or free text — ` +
    `"${GENERATION_ONLY}" is the only exception.\n  Found: "${v || '(empty)'}"`;
}

// Seconds of active time + number of pauses -> the cell text. Rounds to total minutes first, then splits into h/m.
function formatTiming(seconds, pauses = 0) {
  const total = Math.max(0, Math.round((Number.isFinite(seconds) ? seconds : 0) / 60));
  const h = Math.floor(total / 60), m = total % 60;
  const n = Number.isInteger(pauses) && pauses > 0 ? pauses : 0;
  return `${h > 0 ? `${h}h ${m}m` : `${m}m`}${n > 0 ? ` (${n} ${n === 1 ? 'pause' : 'pauses'})` : ''}`;
}

module.exports = { GENERATION_ONLY, TIMING_RE, timingError, formatTiming };
