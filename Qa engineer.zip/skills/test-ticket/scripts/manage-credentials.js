#!/usr/bin/env node
/**
 * Manages Jira credential placeholder fields in ~/.claude/settings.json.
 * Claude calls this script instead of reading or editing settings.json directly —
 * actual credential values are never passed as args or printed to stdout/stderr.
 *
 * Usage:
 *   node manage-credentials.js add     — adds empty placeholder fields; prints JSON
 *                                        manifest of which KEY NAMES were added (no values)
 *   node manage-credentials.js remove  — removes only the empty fields added by the
 *                                        last 'add' call (reads manifest from temp file)
 *   node manage-credentials.js check   — idempotent probe: prints "present" or "missing"
 *                                        (no prompt, no write, no secret values). Safe to
 *                                        call any time — e.g. to re-derive upload status
 *                                        after context compaction without re-prompting.
 *   node manage-credentials.js probe   — "check" plus one read-only Jira call: prints "valid",
 *                                        "invalid", "unreachable" or "missing" (never a value).
 *
 * The pipeline itself only uses "check" and "probe": missing or unusable credentials make a run
 * use the Atlassian MCP write path silently; "add"/"remove" remain for people who want to set up
 * the token-based script path by hand.
 *
 * Exits 0 on success, 1 on failure.
 */

const fs   = require('fs');
const path = require('path');
const os   = require('os');

const SETTINGS_PATH = path.join(os.homedir(), '.claude', 'settings.json');
const MANIFEST_PATH = path.join(os.homedir(), '.claude', 'jira-evidence-setup.tmp');

const [, , command] = process.argv;

// Credentials come from the environment first, then from the env block of ~/.claude/settings.json.
// Shared by "check" and "probe" so the two can never disagree about whether credentials exist.
function loadCreds() {
  let email    = process.env.JIRA_EMAIL    || '';
  let apiToken = process.env.JIRA_API_TOKEN || '';
  if (!email || !apiToken) {
    try {
      const s = JSON.parse(fs.readFileSync(SETTINGS_PATH, 'utf8'));
      if (s && s.env) {
        email    = email    || s.env.JIRA_EMAIL    || '';
        apiToken = apiToken || s.env.JIRA_API_TOKEN || '';
      }
    } catch { /* no/unreadable settings file -> treat as missing */ }
  }
  return { email, apiToken };
}

if (command === 'add') {
  try {
    let settings = {};
    if (fs.existsSync(SETTINGS_PATH)) {
      settings = JSON.parse(fs.readFileSync(SETTINGS_PATH, 'utf8'));
    }

    let addedBlock = false;
    const addedKeys = [];

    if (!settings.env) {
      settings.env = {};
      addedBlock = true;
    }
    if (!settings.env.JIRA_EMAIL) {
      settings.env.JIRA_EMAIL = '';
      addedKeys.push('JIRA_EMAIL');
    }
    if (!settings.env.JIRA_API_TOKEN) {
      settings.env.JIRA_API_TOKEN = '';
      addedKeys.push('JIRA_API_TOKEN');
    }

    if (addedKeys.length > 0 || addedBlock) {
      try {
        fs.writeFileSync(SETTINGS_PATH, JSON.stringify(settings, null, 2), 'utf8');
      } catch (writeErr) {
        process.stderr.write(
          `PERMISSION_ERROR: Cannot write to ${SETTINGS_PATH}\n` +
          `Reason: ${writeErr.message}\n\n` +
          `Please add the credentials manually:\n` +
          `  1. Open ${SETTINGS_PATH} in a text editor (run as Administrator if needed)\n` +
          `     If the file does not exist yet, create it.\n` +
          `  2. Add or update the "env" block:\n` +
          `     {\n` +
          `       "env": {\n` +
          `         "JIRA_EMAIL": "your.name@maxxton.com",\n` +
          `         "JIRA_API_TOKEN": "your_atlassian_api_token"\n` +
          `       }\n` +
          `     }\n` +
          `  3. Get your API token at: https://id.atlassian.com/manage-profile/security/api-tokens\n` +
          `  4. Save the file and type "updated" to continue.\n`
        );
        process.exit(1);
      }
    }

    // Persist manifest of KEY NAMES only (no values) for the remove step
    const manifest = { addedKeys, addedBlock };
    try {
      fs.writeFileSync(MANIFEST_PATH, JSON.stringify(manifest), 'utf8');
    } catch { /* manifest write failure is non-fatal */ }

    // Print only key names + block flag — no credential values ever reach stdout
    process.stdout.write(JSON.stringify(manifest) + '\n');
  } catch (err) {
    process.stderr.write(`Failed to add placeholders: ${err.message}\n`);
    process.exit(1);
  }

} else if (command === 'remove') {
  try {
    if (!fs.existsSync(MANIFEST_PATH)) {
      process.stdout.write('nothing-to-remove\n');
      process.exit(0);
    }

    const manifest = JSON.parse(fs.readFileSync(MANIFEST_PATH, 'utf8'));
    const { addedKeys, addedBlock } = manifest;

    if (!fs.existsSync(SETTINGS_PATH)) {
      fs.unlinkSync(MANIFEST_PATH);
      process.stdout.write('settings-not-found\n');
      process.exit(0);
    }

    const settings = JSON.parse(fs.readFileSync(SETTINGS_PATH, 'utf8'));

    // Remove only keys that were newly added AND are still empty (user didn't fill them)
    for (const key of addedKeys) {
      if (settings.env && settings.env[key] === '') {
        delete settings.env[key];
      }
    }

    // Remove env block if it was created by add and is now empty
    if (addedBlock && settings.env && Object.keys(settings.env).length === 0) {
      delete settings.env;
    }

    fs.writeFileSync(SETTINGS_PATH, JSON.stringify(settings, null, 2), 'utf8');
    fs.unlinkSync(MANIFEST_PATH);

    process.stdout.write('removed\n');
  } catch (err) {
    process.stderr.write(`Failed to remove placeholders: ${err.message}\n`);
    process.exit(1);
  }

} else if (command === 'check') {
  // Idempotent probe — reports whether Jira credentials are available WITHOUT
  // prompting, writing, or printing any secret value. Safe to call any time,
  // including after context compaction, to re-derive upload status.
  const { email, apiToken } = loadCreds();
  process.stdout.write((email && apiToken) ? 'present\n' : 'missing\n');
  process.exit(0);

} else if (command === 'probe') {
  // Does the configured token actually work? One read-only call (GET /myself); prints exactly one of
  //   valid        - credentials present and Jira accepted them -> the script path can be used
  //   invalid      - credentials present but Jira rejected them (401/403: expired, revoked, wrong email)
  //   unreachable  - credentials present but Jira could not be reached (network, timeout, 5xx, no fetch)
  //   missing      - no credentials configured
  // A network failure or a non-auth error is tried twice before it is reported, so one blip does not
  // push a whole run onto the MCP path. Never prints a secret value. Always exits 0.
  (async () => {
    const { email, apiToken } = loadCreds();
    if (!email || !apiToken) { process.stdout.write('missing\n'); process.exit(0); }
    if (typeof fetch !== 'function') { process.stdout.write('unreachable\n'); process.exit(0); } // Node < 18: the scripts cannot run either

    // The token is sent to this URL, so the test override is honoured only for a loopback mock server;
    // any other value (an inherited or malicious environment variable) is ignored.
    const PROD = 'https://maxxton.atlassian.net';
    const override = process.env.JIRA_PROBE_BASE_URL || '';
    const base = /^http:\/\/(127\.0\.0\.1|localhost)(:\d+)?\/?$/.test(override) ? override.replace(/\/$/, '') : PROD;
    const auth = Buffer.from(`${email}:${apiToken}`).toString('base64');
    let outcome = 'unreachable';
    for (let attempt = 0; attempt < 2; attempt++) {
      const ctrl = new AbortController();
      const timer = setTimeout(() => ctrl.abort(), 8000);
      try {
        const res = await fetch(`${base}/rest/api/2/myself`, {
          headers: { Authorization: `Basic ${auth}`, Accept: 'application/json' },
          signal: ctrl.signal,
        });
        if (res.ok) { outcome = 'valid'; break; }
        if (res.status === 401 || res.status === 403) { outcome = 'invalid'; break; }
        outcome = 'unreachable';
      } catch {
        outcome = 'unreachable';
      } finally {
        clearTimeout(timer);
      }
    }
    process.stdout.write(outcome + '\n');
    // process.exit() right after an HTTPS fetch aborts Node on Windows (libuv assertion, exit 127).
    process.exitCode = 0;
  })();

} else {
  process.stderr.write('Usage: node manage-credentials.js <add|remove|check|probe>\n');
  process.exit(1);
}
