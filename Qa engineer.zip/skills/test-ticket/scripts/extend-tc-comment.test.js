/**
 * Tests for extend-tc-comment.js and the shared "Extended cases added after Human review" validation
 * (tc-extended.js) as enforced by post-tc-comment.js, update-tc-comment.js and validate-results-comment.js.
 *
 *   node plugins/qa-engineer/skills/test-ticket/scripts/extend-tc-comment.test.js
 */
const test = require('node:test');
const assert = require('node:assert');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { spawnSync } = require('child_process');

const dir = __dirname;
const EXTEND = path.join(dir, 'extend-tc-comment.js');
const POST = path.join(dir, 'post-tc-comment.js');
const UPDATE = path.join(dir, 'update-tc-comment.js');
const VALIDATE = path.join(dir, 'validate-results-comment.js');
const NOW = { ...process.env, EXTEND_TC_NOW: '2026-10-14' };
// Fake credentials only so the validators get past the credential check; validation runs before any network call.
// fetch is stubbed so a body that passes validation can never reach Jira.
const STUB = path.join(os.tmpdir(), 'extend-tc-no-network.js');
fs.writeFileSync(STUB, "globalThis.fetch = () => Promise.reject(new Error('network disabled in tests'));\n");
const FAKE = { ...process.env, JIRA_EMAIL: 'qa@example.test', JIRA_API_TOKEN: 'x', NODE_OPTIONS: '--require ' + JSON.stringify(STUB) };

const HDR_W = '|| TC_ID || Test case scenario || Preconditions || Test steps || Expected Result || Actual result || Story number || Epic number || Automate || Risk ||';
const HDR_M = '| TC_ID | Test case scenario | Preconditions | Test steps | Expected Result | Actual result | Story number | Epic number | Automate | Risk |';
const WIKI = [
  'h2. Test Cases — MXTS-1', '', HDR_W,
  '| TC_01 | Verify a | pre | 1. x | ok | To be Tested | MXTS-1 | MXTS-9 | Yes | High |',
  '| TC_02 | Verify b | pre | 1. y | ok | To be Tested | MXTS-1 | MXTS-9 | No | Low |', '',
  '_AC coverage: 2/2 | Automate: 1 Yes / 1 No_', '',
].join('\n');
const MD = [
  '## Test Cases — MXTS-1', '', HDR_M, '|---|---|---|---|---|---|---|---|---|---|',
  '| TC_01 | Verify a | pre | 1. x | ok | To be Tested | MXTS-1 | MXTS-9 | Yes | High |',
  '| TC_02 | Verify b | pre | 1. y | ok | To be Tested | MXTS-1 | MXTS-9 | No | Low |', '',
  '_AC coverage: 2/2 | Automate: 1 Yes / 1 No_', '',
].join('\n');
// A comment posted before the rename: the ninth column is still "Automated".
const WIKI_OLD = WIKI.replace('Automate ||', 'Automated ||').replace('| Automate:', '| Automated:');
const MD_OLD = MD.replace('Automate |', 'Automated |');
const STANDALONE = [
  '## QA Test Cases — MXTS-1', '', HDR_M, '|---|---|---|---|---|---|---|---|---|---|',
  '| TC_01 | Verify a | pre | 1. x | ok | To be Tested | MXTS-1 | MXTS-9 | No | High |', '',
  '## Coverage Gaps', '- none', '',
].join('\n');

function tmp() { return fs.mkdtempSync(path.join(os.tmpdir(), 'extend-tc-')); }
function write(d, name, content) { const p = path.join(d, name); fs.writeFileSync(p, content, 'utf8'); return p; }
function extend(d, body, entries, env = NOW) {
  const inF = write(d, 'in.txt', body);
  const en = write(d, 'entries.json', JSON.stringify({ entries: entries }));
  const outF = path.join(d, 'out.txt');
  const r = spawnSync('node', [EXTEND, inF, en, outF], { encoding: 'utf8', env });
  return { ...r, out: fs.existsSync(outF) ? fs.readFileSync(outF, 'utf8') : null, outF };
}
const ROW = { scenario: 'Verify c', expected: 'c works', risk: 'High' };
const ACC = { decision: 'accepted', row: ROW };

test('wiki: adds the section, assigns the next TC ids, computes the numbers', () => {
  const d = tmp();
  const r = extend(d, WIKI, [ACC, { decision: 'covered' }, { decision: 'declined' }, { decision: 'overridden', row: { scenario: 'Verify d', expected: 'd works' } }]);
  assert.strictEqual(r.status, 0, r.stderr);
  assert.deepStrictEqual(JSON.parse(r.stdout).added, ['TC_03', 'TC_04']);
  assert.match(r.out, /^h3\. Extended cases added after Human review$/m);
  assert.match(r.out, /_Human review: Claude generated 2 · Human requested 4 \(accepted 1, already covered 1, declined 1, added on request 1\) · Miss rate 50% \(2\/4\) · Last extended 2026-10-14_/);
  assert.match(r.out, /^\| TC_03 \| Verify c \|/m);
  assert.strictEqual(JSON.parse(r.stdout).missRatePct, 50);
});

test('the main table and footer are left exactly as they were', () => {
  const d = tmp();
  const r = extend(d, WIKI, [ACC]);
  assert.ok(r.out.startsWith(WIKI.trimEnd()), 'original body must be an untouched prefix');
});

test('markdown form uses ### and a separator row', () => {
  const d = tmp();
  const r = extend(d, MD, [ACC]);
  assert.strictEqual(r.status, 0, r.stderr);
  assert.match(r.out, /^### Extended cases added after Human review$/m);
  assert.match(r.out, /\|---\|---\|---\|---\|---\|---\|---\|---\|---\|---\|\n\| TC_03 \|/);
});

test('a second extend accumulates counts and continues ids without renumbering', () => {
  const d = tmp();
  const first = extend(d, WIKI, [ACC, { decision: 'declined' }]);
  const d2 = tmp();
  const second = extend(d2, first.out, [{ decision: 'accepted', row: { scenario: 'Verify e', expected: 'e works' } }, { decision: 'covered' }]);
  assert.strictEqual(second.status, 0, second.stderr);
  assert.deepStrictEqual(JSON.parse(second.stdout).added, ['TC_04']);
  assert.match(second.out, /Human requested 4 \(accepted 2, already covered 1, declined 1, added on request 0\) · Miss rate 50% \(2\/4\)/);
  assert.strictEqual((second.out.match(/^h3\. Extended cases/gm) || []).length, 1);
  assert.match(second.out, /^\| TC_03 \| Verify c \|/m);
});

test('only covered/declined: counts change, no rows, miss rate stays 0%', () => {
  const d = tmp();
  const r = extend(d, WIKI, [{ decision: 'covered' }, { decision: 'declined' }]);
  assert.strictEqual(r.status, 0, r.stderr);
  assert.match(r.out, /Human requested 2 \(accepted 0, already covered 1, declined 1, added on request 0\) · Miss rate 0% \(0\/2\)/);
  assert.ok(!/^\| TC_03/m.test(r.out));
});

test('standalone "QA Test Cases" comment: section goes before Coverage Gaps', () => {
  const d = tmp();
  const r = extend(d, STANDALONE, [ACC]);
  assert.strictEqual(r.status, 0, r.stderr);
  const iSec = r.out.indexOf('### Extended cases added after Human review');
  const iGap = r.out.indexOf('## Coverage Gaps');
  assert.ok(iSec > 0 && iGap > iSec, 'section must precede Coverage Gaps');
});

test('cell text: pipes and newlines are cleaned; story/epic default from the main table', () => {
  const d = tmp();
  const r = extend(d, WIKI, [{ decision: 'accepted', row: { scenario: 'a | b\nc', expected: 'x', steps: '1. a\n2. b' } }]);
  assert.match(r.out, /\| TC_03 \| a \/ b {2}c \| None \| 1\. a {2}2\. b \| x \| To be Tested \| MXTS-1 \| MXTS-9 \| No \| Medium \|/);
});

test('bad input is rejected: unknown decision, missing text, bad risk, no table, empty entries', () => {
  const d = tmp();
  assert.strictEqual(extend(d, WIKI, [{ decision: 'maybe' }]).status, 1);
  assert.strictEqual(extend(d, WIKI, [{ decision: 'accepted', row: { scenario: 'only' } }]).status, 1);
  assert.strictEqual(extend(d, WIKI, [{ decision: 'accepted', row: { ...ROW, risk: 'Huge' } }]).status, 1);
  assert.strictEqual(extend(d, 'no table here', [ACC]).status, 1);
  assert.strictEqual(extend(d, WIKI, []).status, 1);
});

function post(d, body) { return spawnSync('node', [POST, 'MXTS-1', write(d, 'b.txt', body)], { encoding: 'utf8', env: FAKE }); }
function update(d, body) { return spawnSync('node', [UPDATE, 'MXTS-1', '123', write(d, 'u.txt', body)], { encoding: 'utf8', env: FAKE }); }
function validateMd(d, body) { return spawnSync('node', [VALIDATE, write(d, 'v.md', body), '--kind', 'tc', '--story', 'MXTS-1'], { encoding: 'utf8' }); }
// Validation failures print "BLOCKED"; a body that passes goes on to the network call, which fails against the fake credentials.
const blocked = r => /BLOCKED/.test(r.stderr) || /failed validation/.test(r.stderr);

test('post/update validators accept an extended wiki body and a body without the section', () => {
  const d = tmp();
  const good = extend(d, WIKI, [ACC, { decision: 'declined' }]).out;
  assert.ok(!blocked(post(d, good)), 'post: valid extended body must pass validation');
  assert.ok(!blocked(update(d, good)), 'update: valid extended body must pass validation');
  assert.ok(!blocked(post(d, WIKI)), 'a body with no section is unchanged behaviour');
});

test('validators reject a tampered section', () => {
  const d = tmp();
  const good = extend(d, WIKI, [ACC, { decision: 'declined' }]).out;
  const tampered = [
    ['wrong miss rate', good.replace('Miss rate 33% (1/3)', 'Miss rate 5% (1/3)')],
    ['wrong generated', good.replace('Claude generated 2', 'Claude generated 9')],
    ['requested mismatch', good.replace('Human requested 2', 'Human requested 7')],
    ['stats line removed', good.replace(/^_Human review:.*_$/m, '')],
    ['duplicate id', good.replace('| TC_03 |', '| TC_02 |')],
    ['id not continuing', good.replace('| TC_03 |', '| TC_01 |')],
    ['heading twice', good + '\nh3. Extended cases added after Human review\n'],
    ['section before footer', good.replace('_AC coverage: 2/2 | Automate: 1 Yes / 1 No_\n', '')],
    ['stray stats line', WIKI + '\n_Human review: hand typed_\n'],
  ];
  for (const [name, body] of tampered) {
    assert.ok(blocked(post(d, body)), `post must block: ${name}`);
    assert.ok(blocked(update(d, body)), `update must block: ${name}`);
  }
});

test('validate-results-comment --kind tc (markdown / MCP path)', () => {
  const d = tmp();
  const good = extend(d, MD, [ACC, { decision: 'covered' }]).out;
  const ok = validateMd(d, good);
  assert.strictEqual(ok.status, 0, ok.stderr);
  assert.strictEqual(validateMd(d, MD).status, 0, 'no section still passes');
  const bad = validateMd(d, good.replace('Miss rate 33% (1/3)', 'Miss rate 1% (1/3)'));
  assert.strictEqual(bad.status, 1);
  assert.match(bad.stderr, /Miss rate/);
  assert.strictEqual(validateMd(d, MD + '\n## Something else\n').status, 1, 'other extra headings are still rejected');
});

test('execution verdicts inside the extended table are still rejected', () => {
  const d = tmp();
  const good = extend(d, WIKI, [ACC]).out.replace('| To be Tested | MXTS-1 | MXTS-9 | No | High |', '| PASS ✅ | MXTS-1 | MXTS-9 | No | High |');
  assert.ok(blocked(post(d, good)));
});

test('the section follows the main table spelling: Automate on a new comment, Automated on an older one', () => {
  const d = tmp();
  const fresh = extend(d, WIKI, [ACC]);
  assert.strictEqual(fresh.status, 0, fresh.stderr);
  assert.match(fresh.out, /\n\|\| TC_ID .* Epic number \|\| Automate \|\| Risk \|\|\n\| TC_03/);
  const old = extend(tmp(), WIKI_OLD, [ACC]);
  assert.strictEqual(old.status, 0, old.stderr);
  assert.ok(old.out.startsWith(WIKI_OLD.trimEnd()), 'an older comment is not converted');
  assert.match(old.out, /\n\|\| TC_ID .* Epic number \|\| Automated \|\| Risk \|\|\n\| TC_03/);
  assert.strictEqual(old.out.split('Automate ||').length - 1, 0, 'no Automate header sneaks in');
  const oldMd = extend(tmp(), MD_OLD, [ACC]);
  assert.strictEqual(oldMd.status, 0, oldMd.stderr);
  assert.match(oldMd.out, /\| Epic number \| Automated \| Risk \|\n\|---/);
});

test('a section whose header spelling differs from the main table is rejected', () => {
  const d = tmp();
  const good = extend(d, WIKI, [ACC]).out;
  const at = good.indexOf('h3. Extended');
  const mixed = good.slice(0, at) + good.slice(at).replace('Automate ||', 'Automated ||');
  assert.notStrictEqual(mixed, good, 'the section header was changed');
  assert.ok(blocked(update(d, mixed)), 'main Automate + section Automated must be blocked');
});

test('post-tc-comment needs Automate on a new comment; update-tc-comment also accepts Automated', () => {
  const d = tmp();
  assert.ok(!blocked(post(d, WIKI)), 'Automate passes');
  const p = post(d, WIKI_OLD);
  assert.ok(blocked(p), 'a new post with Automated is blocked');
  assert.match(p.stderr, /Automate/);
  assert.ok(!blocked(update(d, WIKI)), 'update with Automate passes');
  assert.ok(!blocked(update(d, WIKI_OLD)), 'update of an older comment keeps Automated and passes');
  const oldExt = extend(tmp(), WIKI_OLD, [ACC, { decision: 'declined' }]).out;
  assert.ok(!blocked(update(d, oldExt)), 'an extended older comment passes update');
});
