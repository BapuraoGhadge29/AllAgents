#!/usr/bin/env node
/**
 * Idempotently transition a Jira issue to a target status via API v2.
 * Replaces raw listJiraIssueTransitions + transitionJiraIssue calls so a re-run
 * (resume after crash, mid-run context compaction) can never double-transition or
 * error out on an issue that's already in the target status.
 *
 * Usage:
 *   node transition-issue.js <issue_key> "<target_name_1>,<target_name_2>,..." [--check-only]
 *
 * <target_name_*> — one or more acceptable target status names, tried in order
 * (e.g. "Reopened,Reopen,In Progress"). Matching is case-insensitive.
 *
 * --check-only — reports reachability WITHOUT applying the transition. Use this to
 * decide whether to ask the user for confirmation before re-running without the flag.
 *
 * Exits 0 in all of these cases (each prints a distinct marker on stdout):
 *   ALREADY_IN_STATUS <status>      — current status already matches a target name; no-op
 *   TRANSITION_AVAILABLE <to>       — (--check-only) reachable, not yet applied
 *   TRANSITIONED <from> -> <to>     — transition applied
 *   NO_MATCHING_TRANSITION          — none of the target names are reachable from current status
 * Exits 1 on bad args or API error (failed closed — never leaves the caller unsure
 * whether the transition happened).
 */

const [, , issueKey, targetsArg, ...flags] = process.argv;
const checkOnly = flags.includes('--check-only');

if (!issueKey || !targetsArg) {
  process.stderr.write('Usage: node transition-issue.js <issue_key> "<target_name_1>,<target_name_2>,..."\n');
  process.exit(1);
}

const targets = targetsArg.split(',').map(t => t.trim()).filter(Boolean);
if (targets.length === 0) {
  process.stderr.write('At least one target status name is required.\n');
  process.exit(1);
}

const fs   = require('fs');
const path = require('path');

function loadCredentials() {
  let email    = process.env.JIRA_EMAIL    || '';
  let apiToken = process.env.JIRA_API_TOKEN || '';
  if (!email || !apiToken) {
    try {
      const home = process.env.USERPROFILE || process.env.HOME || '';
      if (!home) throw new Error('no home dir');
      const settingsPath = path.join(home, '.claude', 'settings.json');
      const s = JSON.parse(fs.readFileSync(settingsPath, 'utf8'));
      if (s && s.env) {
        email    = email    || s.env.JIRA_EMAIL    || '';
        apiToken = apiToken || s.env.JIRA_API_TOKEN || '';
      }
    } catch { /* settings.json unreadable — fall through */ }
  }
  return { email, apiToken };
}

const { email, apiToken } = loadCredentials();
if (!email || !apiToken) {
  process.stderr.write('Missing JIRA_EMAIL or JIRA_API_TOKEN.\n');
  process.exit(1);
}

const auth    = Buffer.from(`${email}:${apiToken}`).toString('base64');
const headers = { Authorization: `Basic ${auth}`, 'Content-Type': 'application/json', Accept: 'application/json' };
const base    = `https://maxxton.atlassian.net/rest/api/2/issue/${encodeURIComponent(issueKey)}`;

const matchesTarget = name => targets.some(t => t.toLowerCase() === String(name || '').toLowerCase());

(async () => {
  try {
    // Guard 1: already in a target status — idempotent no-op.
    const issueRes = await fetch(`${base}?fields=status`, { headers });
    if (!issueRes.ok) throw new Error(`GET status failed: ${issueRes.status}`);
    const issueData = await issueRes.json();
    const currentStatus = issueData.fields?.status?.name || '';
    if (matchesTarget(currentStatus)) {
      process.stdout.write(`ALREADY_IN_STATUS ${currentStatus}\n`);
      return;
    }

    // Guard 2: find a transition reachable from the current status matching a target.
    const transRes = await fetch(`${base}/transitions`, { headers });
    if (!transRes.ok) throw new Error(`GET transitions failed: ${transRes.status}`);
    const transData = await transRes.json();
    const transitions = transData.transitions || [];
    const match = transitions.find(t => matchesTarget(t.to?.name) || matchesTarget(t.name));
    if (!match) {
      process.stdout.write(
        `NO_MATCHING_TRANSITION — none of [${targets.join(', ')}] reachable from "${currentStatus}".\n` +
        `Available: ${transitions.map(t => t.to?.name || t.name).join(', ') || '(none)'}\n`
      );
      return;
    }

    if (checkOnly) {
      process.stdout.write(`TRANSITION_AVAILABLE ${match.to?.name || match.name}\n`);
      return;
    }

    const doRes = await fetch(`${base}/transitions`, {
      method: 'POST', headers,
      body: JSON.stringify({ transition: { id: match.id } }),
    });
    if (!doRes.ok) {
      const t = await doRes.text();
      throw new Error(`transition failed: ${doRes.status} ${t}`);
    }
    process.stdout.write(`TRANSITIONED ${currentStatus} -> ${match.to?.name || match.name}\n`);
  } catch (err) {
    process.stderr.write(`❌ transition-issue.js — ${err.message}\nTransition not confirmed (failed closed).\n`);
    process.exit(1);
  }
})();
