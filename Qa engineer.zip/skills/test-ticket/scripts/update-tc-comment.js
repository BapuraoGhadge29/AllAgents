#!/usr/bin/env node
/**
 * Update an existing Phase 2 TC table comment in-place via Jira API v2 PUT.
 * Used when the Automate column needs updating after Gate 2 without creating a new comment.
 * The ninth column is spelled "Automate" (current) or "Automated" (comments posted before the rename); send back the spelling the comment already has.
 *
 * Built-in gates: same validation as post-tc-comment.js.
 *
 * Usage:
 *   node update-tc-comment.js <issue_key> <comment_id> <body_file>
 *
 * Exits 0 on success. Exits 1 on validation failure or API error.
 */

// Split Test Cases (see result-parts.js): --part <n>/<m> --tc-ids <csv> | --tc-ids-file <file> when correcting one part.
const resultParts = require('./result-parts');
const resultsLayout = require('./results-layout');
const { rest: positional, part: partOpt, tcIds: partTcIds, validateOnly, mainTotal } = resultParts.takePartArgs(process.argv.slice(2));
if (validateOnly) {
  process.stderr.write('update-tc-comment.js does not support --validate-only (it would still send the PUT). Use post-tc-comment.js --validate-only or validate-results-comment.js --kind tc.\n');
  process.exit(1);
}
const [issueKey, commentId, bodyFile] = positional;

if (!issueKey || !commentId || !bodyFile) {
  process.stderr.write('Usage: node update-tc-comment.js <issue_key> <comment_id> <body_file> [--part <n>/<m> --tc-ids <csv>]\n');
  process.exit(1);
}

const fs   = require('fs');
const path = require('path');

function loadCredentials() {
  let email    = process.env.JIRA_EMAIL    || '';
  let apiToken = process.env.JIRA_API_TOKEN || '';
  if (!email || !apiToken) {
    try {
      const home = process.env.USERPROFILE || process.env.HOME || '';
      if (!home) throw new Error('no home dir');
      const settingsPath = path.join(home, '.claude', 'settings.json');
      const s = JSON.parse(fs.readFileSync(settingsPath, 'utf8'));
      if (s && s.env) {
        email    = email    || s.env.JIRA_EMAIL    || '';
        apiToken = apiToken || s.env.JIRA_API_TOKEN || '';
      }
    } catch { /* settings.json unreadable — fall through */ }
  }
  return { email, apiToken };
}

const { email, apiToken } = loadCredentials();
if (!email || !apiToken) {
  process.stderr.write('Missing JIRA_EMAIL or JIRA_API_TOKEN.\n');
  process.exit(1);
}

const body = fs.readFileSync(bodyFile, 'utf8');

// ─── Validation ───────────────────────────────────────────────────────────────

const lines  = body.split('\n');
const errors = [];

// 0. UTF-8 text decoded as Windows-1252 ("â€”", "Â·") — what Windows PowerShell 5.1 Get-Content does to a BOM-less
//    UTF-8 file. KEEP IN SYNC with validate-results-comment.js and post-tc-comment.js.
const garbled = [...new Set((body.match(/[ÂÃâ][\u0080-¿ŒœŠšŸŽžƒˆ˜–—‘-„†-•…‰‹›€™]|�/g) || []).map(h => `"${h}"`))].slice(0, 5);
if (garbled.length) {
  errors.push(
    `[CHECK 0] Garbled characters (mojibake) in the body: ${garbled.join(', ')} — UTF-8 text was decoded as Windows-1252.\n` +
    `  The body file was read back with Windows PowerShell's Get-Content (default ANSI code page), or rebuilt from text read that way.\n` +
    `  Rebuild it from the template and save it with the Write tool; read files with the Read tool or Get-Content -Encoding utf8.`
  );
}

// 0b. Target guard — header story key must match the issue being updated. Blocks
//    updating one story's TC table onto another ticket (e.g. after context compaction).
const headerLine0    = lines.find(l => l.trim().length > 0)?.trim() || '';
const isTcHeader     = /^h2\.\s*Test Cases —/.test(headerLine0);
const headerKeyMatch = /^h2\.\s*Test Cases —\s*([A-Za-z][A-Za-z0-9]+-\d+)/.exec(headerLine0);
if (isTcHeader && !headerKeyMatch) {
  // Fail closed — a "Test Cases —" header with no parseable story key (e.g. a leftover
  // "<STORY_KEY>" placeholder) must NOT be posted, or the guard is silently bypassed.
  errors.push(
    `[CHECK 0] Cannot parse a story key from the header ("${headerLine0}").\n` +
    `  Refusing to update — the header must be "h2. Test Cases — ${issueKey}" (no placeholder).\n` +
    `  Re-read run-state.json after context compaction, then rebuild for ${issueKey}.`
  );
} else if (headerKeyMatch && headerKeyMatch[1].toUpperCase() !== issueKey.toUpperCase()) {
  errors.push(
    `[CHECK 0] Target mismatch. Body header is for "${headerKeyMatch[1]}" but updating "${issueKey}".\n` +
    `  Re-check the active story (re-read run-state.json after context compaction), then rebuild for ${issueKey}.`
  );
}

const firstContent = lines.find(l => l.trim().length > 0);
if (!firstContent?.trim().startsWith('h2. Test Cases —')) {
  errors.push(
    `[CHECK 1] Wrong header. First line must be "h2. Test Cases — <STORY_KEY>".\n` +
    `  Found: "${firstContent?.trim() ?? '(empty)'}"`
  );
}

// The ninth column is "Automate"; a comment posted before the rename keeps "Automated" and is sent back unchanged.
const TC10_HEADERS = ['Automate', 'Automated'].map(a => `|| TC_ID || Test case scenario || Preconditions || Test steps || Expected Result || Actual result || Story number || Epic number || ${a} || Risk ||`);
if (!lines.some(l => TC10_HEADERS.includes(l.trim()))) {
  errors.push(`[CHECK 2] 10-column TC table header not found.\n  Expected: ${TC10_HEADERS[0]}\n  (a comment posted before the rename keeps "Automated" as the ninth column: keep its spelling.)`);
}

const mdHeaders = lines.filter(l => /^#{1,6}\s/.test(l.trim()));
if (mdHeaders.length > 0) {
  errors.push(`[CHECK 3] Markdown ## headers found — use wiki markup (h2.) only.\n  Found: ${mdHeaders.slice(0, 3).map(l => `"${l.trim()}"`).join(', ')}`);
}

// 4. Italic AC-coverage footer must be present (SKILL.md: "Do NOT omit the italic footer")
const FOOTER_RE = /^_AC coverage:.*Automated?:.*_$/;
if (!lines.some(l => FOOTER_RE.test(l.trim()))) {
  errors.push(`[CHECK 4] Missing italic AC-coverage footer line.\n  Expected a line matching: _AC coverage: <covered>/<total> | Automate: <n> Yes / <m> No_ (an older comment: "Automated:")`);
}

// 5. TC rows must have exactly 10 columns — no extra/missing columns
const tcRowRe = /^\|\s*TC_\d+\s*\|/;
const tcRows  = lines.filter(l => tcRowRe.test(l.trim()));
const badCols = tcRows.filter(l => l.trim().split('|').length - 2 !== 10);
if (badCols.length > 0) {
  errors.push(`[CHECK 5] ${badCols.length} TC row(s) do not have exactly 10 columns.\n  Found: ${badCols.slice(0, 2).map(l => `"${l.trim()}"`).join(', ')}`);
}

// 5b. Every TC row's "Story number" must be the issue this comment is posted on — an extended row, or any row, can never
// carry another issue's key. (The markdown validator makes the same check.)
const wrongStory = tcRows.filter(l => {
  const cells = l.trim().split('|').slice(1, -1).map(c => c.trim());
  return cells.length === 10 && cells[6].toUpperCase() !== issueKey.toUpperCase();
});
if (wrongStory.length > 0) {
  errors.push(
    `[CHECK 0] "Story number" must be ${issueKey} in every row. Found: ${wrongStory.slice(0, 3).map(l => { const c = l.trim().split('|').slice(1, -1).map(x => x.trim()); return `${c[0]}=${c[6]}`; }).join(', ')}`
  );
}

// 6. This is a Phase 2 proposal table — no execution verdicts allowed yet.
const VERDICT_RE = /(PASS ✅|FAIL ❌|BLOCKED 🚫|NEEDS REVIEW 🔍|SKIP ⏭️)/;
const verdictRows = tcRows.filter(l => VERDICT_RE.test(l));
if (verdictRows.length > 0) {
  errors.push(
    `[CHECK 6] Execution verdicts found in a Phase 2 TC table (Actual result must be "To be Tested").\n` +
    `  This looks like a Phase 3b results comment mislabeled as Phase 2 — use update-comment.js instead.\n` +
    `  Found: ${verdictRows.slice(0, 2).map(l => `"${l.trim()}"`).join(', ')}`
  );
}

// 7. Optional "Extended cases added after Human review" section (human-requested cases, tracked separately).
//    Shared with extend-tc-comment.js and the other TC validators via tc-extended.js — never retype its numbers by hand.
errors.push(...require('./tc-extended').validateExtended(body, { mainTotal: Number.isNaN(mainTotal) ? null : mainTotal, split: !!partOpt }));

// 8. Split comment: the part marker and exactly the TCs assigned to this part; and the body must fit one Jira comment.
// The footer counts what the Automate/Automated column says (results-layout.js).
errors.push(...resultsLayout.footerCountErrors(body));
errors.push(...resultParts.partErrors(body, partOpt, partTcIds));

if (errors.length > 0) {
  // Canonical Phase 2 template — printed so the body survives context compaction.
  // Keep in sync with SKILL.md Phase 2 and post-tc-comment.js.
  const TC10_TEMPLATE = [
    'h2. Test Cases — <STORY_KEY>',
    '',
    '|| TC_ID || Test case scenario || Preconditions || Test steps || Expected Result || Actual result || Story number || Epic number || Automate || Risk ||   (older comment: keep "Automated")',
    '| TC_01 | … | … | … | … | To be Tested | <STORY_KEY> | <EPIC_KEY or N/A> | Yes/No | High/Medium/Low |',
    '',
    '_AC coverage: <covered>/<total> | Automate: <n> Yes / <m> No_',
    '',
    '(optional, appended by extend-tc-comment.js — do not type it by hand)',
    'h3. Extended cases added after Human review',
    '_Human review: Claude generated <N> · Human requested <R> (accepted <A>, already covered <C>, declined <D>, added on request <P>) · Miss rate <X>% (<A+P>/<N+A+P>) · Last extended <YYYY-MM-DD>_',
    '|| TC_ID || … 10 columns … ||',
  ].join('\n');
  process.stderr.write(
    `\n❌ update-tc-comment.js BLOCKED — ${errors.length} issue(s).\n` +
    `Rebuild by copying the exact template below — do NOT reconstruct from memory\n` +
    `(it may be stale after context compaction):\n\n` +
    `──────── COPY THIS TEMPLATE ────────\n${TC10_TEMPLATE}\n────────────────────────────────────\n\n` +
    errors.join('\n\n') + '\n'
  );
  process.exit(1);
}

// ─── PUT ──────────────────────────────────────────────────────────────────────

const auth = Buffer.from(`${email}:${apiToken}`).toString('base64');
const url  = `https://maxxton.atlassian.net/rest/api/2/issue/${encodeURIComponent(issueKey)}/comment/${encodeURIComponent(commentId)}`;

fetch(url, {
  method:  'PUT',
  headers: { Authorization: `Basic ${auth}`, 'Content-Type': 'application/json', Accept: 'application/json' },
  body:    JSON.stringify({ body }),
})
  .then(res => {
    if (!res.ok) return res.text().then(t => { process.stderr.write(`Jira API error ${res.status}: ${t}\n`); process.exit(1); });
    return res.json();
  })
  .then(data => { process.stdout.write(`Updated comment ${data.id}\n`); })
  .catch(err => { process.stderr.write(`Update failed: ${err.message}\n`); process.exit(1); });
