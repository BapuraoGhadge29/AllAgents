#!/usr/bin/env node
/**
 * Update an existing Phase 3b "QA Test Results" comment in-place via Jira API v2 PUT.
 * Companion to post-comment.js — used when the results comment already exists and
 * needs correction (e.g. wrong format, screenshots not yet attached at post time).
 *
 * Built-in gates (same as post-comment.js — cannot be bypassed):
 *   Format validation — enforces h2. QA Test Results, stats table, the 6-column TC table (or the 12-column merged
 *   table, see results-layout.js), no Markdown headers, no prose sections, no phase labels, screenshot in every TC row.
 *   A merged body also has to keep everything the existing Test Cases comment held (CHECK 18, read from Jira first).
 *
 * Usage:
 *   node update-comment.js <issue_key> <comment_id> <body_file>
 *
 * Exits 0 on success. Exits 1 on validation failure or API error.
 * Screenshot check after every update (same as post-comment.js): every TC_NN-*.png the body names must be
 * attached to the issue. The outcome goes to stderr; exit 3 = the comment IS updated but a screenshot is not
 * attached (or Jira could not be asked). Upload the named files with upload-screenshot.js and run it again.
 */

// Split results (see result-parts.js): --part <n>/<m> --tc-ids <csv> | --tc-ids-file <file> when correcting one part of a split comment.
const resultParts = require('./result-parts');
const resultsLayout = require('./results-layout');
const { statsErrors } = require('./dashboard-stats');
const screenshotAttachments = require('./screenshot-attachments');
const { rest: positional, part: partOpt, tcIds: partTcIds, validateOnly, runTotal } = resultParts.takePartArgs(process.argv.slice(2));
if (validateOnly) {
  process.stderr.write('update-comment.js does not support --validate-only (it would still send the PUT). Use post-comment.js --validate-only or validate-results-comment.js.\n');
  process.exit(1);
}
const [issueKey, commentId, bodyFile] = positional;

if (!issueKey || !commentId || !bodyFile) {
  process.stderr.write('Usage: node update-comment.js <issue_key> <comment_id> <body_file> [--part <n>/<m> --tc-ids <csv> --run-total <n>]\n');
  process.exit(1);
}

const fs   = require('fs');
const path = require('path');

// ─── Credentials ────────────────────────────────────────────────────────────

function loadCredentials() {
  let email    = process.env.JIRA_EMAIL    || '';
  let apiToken = process.env.JIRA_API_TOKEN || '';
  if (!email || !apiToken) {
    try {
      const home = process.env.USERPROFILE || process.env.HOME || '';
      if (!home) throw new Error('no home dir');
      const settingsPath = path.join(home, '.claude', 'settings.json');
      const s = JSON.parse(fs.readFileSync(settingsPath, 'utf8'));
      if (s && s.env) {
        email    = email    || s.env.JIRA_EMAIL    || '';
        apiToken = apiToken || s.env.JIRA_API_TOKEN || '';
      }
    } catch { /* settings.json unreadable — fall through */ }
  }
  return { email, apiToken };
}

const { email, apiToken } = loadCredentials();
if (!email || !apiToken) {
  process.stderr.write('Missing JIRA_EMAIL or JIRA_API_TOKEN.\n');
  process.exit(1);
}

const body = fs.readFileSync(bodyFile, 'utf8');

// ─── Format validation (identical to post-comment.js) ───────────────────────

function validateBody(text) {
  const lines  = text.split('\n');
  const errors = [];

  // 0. UTF-8 text decoded as Windows-1252 ("PASS âœ…", "â€”", "Â·") — what Windows PowerShell 5.1 Get-Content does to a
  // BOM-less UTF-8 file. KEEP IN SYNC with validate-results-comment.js and post-comment.js.
  const garbled = [...new Set((text.match(/[ÂÃâ][\u0080-¿ŒœŠšŸŽžƒˆ˜–—‘-„†-•…‰‹›€™]|�/g) || []).map(h => `"${h}"`))].slice(0, 5);
  if (garbled.length) {
    errors.push(
      `[CHECK 0] Garbled characters (mojibake) in the body: ${garbled.join(', ')} — UTF-8 text was decoded as Windows-1252.\n` +
      `  The body file was read back with Windows PowerShell's Get-Content (default ANSI code page), or rebuilt from text read that way.\n` +
      `  Rebuild it from the template below and save it with the Write tool; read files with the Read tool or Get-Content -Encoding utf8.`
    );
  }

  const firstContent = lines.find(l => l.trim().length > 0);
  if (firstContent?.trim() !== 'h2. QA Test Results') {
    errors.push(
      `[CHECK 1] Wrong header. First line must be exactly "h2. QA Test Results".\n` +
      `  Found: "${firstContent?.trim() ?? '(empty)'}"\n` +
      `  Common mistakes: adding emoji, using "##", "QA Pipeline Results",\n` +
      `  "Phase 3a Execution Results", "QA Pipeline – Test Cases & Execution Evidence", etc.`
    );
  }

  const REQUIRED_STATS = [
    '| *Concern*', '| *Environment*', '| *Build / Version*', '| *Preconditions*', '| *Total TCs*', '| *Passed*',
    '| *Failed*', '| *Blocked*', '| *Needs Review*', '| *Skipped*', '| *Pass rate*', '| *QA Pipeline Version*', '| *Test Execution Timing*',
  ];
  for (const row of REQUIRED_STATS) {
    if (!lines.some(l => l.includes(row))) {
      errors.push(`[CHECK 2] Missing stats table row: ${row}`);
    }
  }

  // 16/17. The stats rows the dashboard reads hold plain values: a timing number, whole counts, a version.
  // KEEP IN SYNC with validate-results-comment.js; the rules live in dashboard-stats.js.
  errors.push(...statsErrors(text));

  // Two layouts: the 6-column results table, or the 12-column merged table (the Test Cases comment edited in place).
  const layout = resultsLayout.wikiLayout(lines);
  if (!layout) {
    errors.push(
      `[CHECK 3] TC table header not found or wrong columns.\n` +
      `  Expected exactly: ${resultsLayout.wikiHeader(resultsLayout.RESULTS_COLS)}\n` +
      `  or (the Test Cases comment after execution): ${resultsLayout.wikiHeader(resultsLayout.MERGED_COLS)}\n` +
      `  Do NOT add, remove, or rename columns (Verdict, Notes, Scenario are wrong).`
    );
  }
  const expectedCells = layout ? layout.cols.length : 6;

  const mdHeaders = lines.filter(l => /^#{1,6}\s/.test(l.trim()));
  if (mdHeaders.length > 0) {
    errors.push(
      `[CHECK 4] Markdown headers (##) found — use wiki markup (h2. / h3.) only.\n` +
      `  This means the body was built for addOrEditJiraIssueComment (wrong API).\n` +
      `  Phase 3b results MUST use wiki markup (API v2).\n` +
      `  Found: ${mdHeaders.slice(0, 3).map(l => `"${l.trim()}"`).join(', ')}`
    );
  }

  const PROSE_PATTERNS = [/^\*\*Steps:\*\*/i, /^\*\*Expected:\*\*/i, /^\*\*Actual:\*\*/i, /^\*\*Screenshot:\*\*/i, /^Steps:/i, /^Expected:/i, /^Actual:/i, /^Screenshot:/i];
  const proseLines = lines.filter(l => PROSE_PATTERNS.some(p => p.test(l.trim())));
  if (proseLines.length > 0) {
    errors.push(
      `[CHECK 5] Per-TC prose sections detected. Each TC must be a single table row only.\n` +
      `  Found: ${proseLines.slice(0, 3).map(l => `"${l.trim()}"`).join(', ')}`
    );
  }

  const PHASE_PATTERNS = [/phase\s*3a/i, /phase\s*1\b/i, /phase\s*2\b/i, /execution results/i, /test cases & execution evidence/i, /qa pipeline\s*[-–]/i, /execution summary/i, /pipeline summary/i, /tester:\s*qa pipeline/i];
  // In a merged table only the Actual result and Test Proof cells are pipeline text; scenario, preconditions and steps come
  // from the ticket and may legitimately say "Phase 1" or "part 2".
  const scanLines = lines.map(l => {
    if (!layout || layout.name !== 'merged' || !/^\|\s*TC_\d+\s*\|/.test(l.trim())) return l;
    const cells = l.trim().split('|').slice(1, -1);
    return [cells[layout.actual], cells[layout.proof]].filter(Boolean).join(' ');
  });
  const phaseLines = scanLines.filter(l => PHASE_PATTERNS.some(p => p.test(l)));
  if (phaseLines.length > 0) {
    errors.push(
      `[CHECK 6] Internal pipeline labels found — these must never appear in Jira.\n` +
      `  Found: ${phaseLines.slice(0, 3).map(l => `"${l.trim()}"`).join(', ')}`
    );
  }

  const SUPPLEMENT_PATTERNS = [/supersedes/i, /supplement/i, /appendix/i, /part\s*2/i, /full evidence/i];
  const suppLines = scanLines.filter(l => !(partOpt && resultParts.isMarkerLine(l)) && SUPPLEMENT_PATTERNS.some(p => p.test(l)));
  if (suppLines.length > 0) {
    errors.push(
      `[CHECK 7] Supplement/appendix markers found — only ONE results comment per story per run.\n` +
      `  Found: ${suppLines.slice(0, 2).map(l => `"${l.trim()}"`).join(', ')}`
    );
  }

  const tcRows = lines.filter(l => /^\|\s*TC_\d+\s*\|/.test(l.trim()));
  const badProof = [];
  const lastCellRe = /\|\s*([^|]+?)\s*\|\s*$/;
  const tcIdRe     = /^\|\s*(TC_\d+)\s*\|/;
  // Requires the actual naming convention (TC_XX-slug.png), not a bare ".png" substring —
  // fabricated text like "fake-TC01.png" or a stray ".png" in prose must not pass.
  // Optional trailing (\\ ...) allows FAIL/BLOCKED debug evidence appended after the image ref,
  // joined with Jira's forced line-break token \\ followed by a mandatory space (see Debug
  // Evidence Capture in references/phase-3a-execution.md, and the space-requirement note in
  // references/phase-3b-results-comment.md — confirmed in production, MXTS-77020, 2026-09-24: a
  // bare \\ with no trailing space is not recognized by Jira's wiki-markup renderer as a line
  // break inside a table cell, it renders as two literal visible backslash characters instead).
  // The evidence text itself must never contain a literal "|" — that would split the cell into
  // an extra column and this regex would (correctly) reject it.
  // Three accepted shapes (see references/phase-3b-results-comment.md "Test Proof" rule):
  //   MXTS (single screenshot):   !TC_XX-slug.png!  or  TC_XX-slug.png
  //   MCMS (Before/After pair):   Before:\\ <TC_XX-slug-before.png>\\ After:\\ <TC_XX-slug-after.png>
  //   Multi-item (2+ named items, e.g. one screenshot per language actually verified):
  //     <Label 1>:\\ <TC_XX-slug-1.png>\\ <Label 2>:\\ <TC_XX-slug-2.png>[\\ <Label 3>:\\ ...]
  // — each optionally followed by (note) and/or a trailing \\ debug-evidence.
  const PROOF_RE       = /^(!TC_\d+-[\w-]+\.png!|TC_\d+-[\w-]+\.png)(\s*\([^|]*\))?(\\\\ [^|]+)?$/i;
  const PROOF_RE_MCMS  = /^Before:\\\\ (!TC_\d+-[\w-]+-before\.png!|TC_\d+-[\w-]+-before\.png)(\s*\([^|]*\))?\\\\ After:\\\\ (!TC_\d+-[\w-]+-after\.png!|TC_\d+-[\w-]+-after\.png)(\s*\([^|]*\))?(\\\\ [^|]+)?$/i;
  // A "label" is any non-empty run of characters that isn't a cell delimiter (|) or the
  // line-break token itself (\) — e.g. "Spanish", "English (US)" — followed by ": " and one
  // image reference. Requires at least 2 items; a single labeled item should use the plain
  // MXTS shape above instead, so this never accidentally accepts a malformed single-item cell.
  const PROOF_ITEM      = '[^|\\\\]+:\\\\\\\\ (?:!TC_\\d+-[\\w-]+\\.png!|TC_\\d+-[\\w-]+\\.png)(?:\\s*\\([^|]*\\))?';
  const PROOF_RE_MULTI  = new RegExp(`^(?:${PROOF_ITEM})(?:\\\\\\\\ ${PROOF_ITEM}){1,}(\\\\\\\\ [^|]+)?$`, 'i');
  for (const row of tcRows) {
    const tcId = (tcIdRe.exec(row.trim()) || [])[1] || '?';
    const lastCellMatch = lastCellRe.exec(row);
    const proof = lastCellMatch ? lastCellMatch[1].trim() : '';
    if (!PROOF_RE.test(proof) && !PROOF_RE_MCMS.test(proof) && !PROOF_RE_MULTI.test(proof)) {
      badProof.push(`${tcId}: "${proof}"`);
    }
  }
  if (badProof.length > 0) {
    errors.push(
      `[CHECK 8] Missing/malformed screenshot proof in Test Proof column for ${badProof.length} TC(s).\n` +
      `  MXTS needs exactly: !TC_XX-slug.png! (upload succeeded), TC_XX-slug.png (upload failed),\n` +
      `  or TC_XX-capture-failed.png (note) (capture itself failed).\n` +
      `  MCMS needs exactly: Before:\\\\ <before-file>\\\\ After:\\\\ <after-file> (note the space\n` +
      `  after each \\\\ — Jira's line-break token requires it, a bare \\\\ renders as literal text),\n` +
      `  each half using the same succeeded/failed/capture-failed forms as MXTS and named\n` +
      `  TC_XX-slug-before.png / TC_XX-slug-after.png.\n` +
      `  Multi-item (a TC covering 2+ named items, e.g. one screenshot per language actually\n` +
      `  verified) needs: <Label>:\\\\ <file>\\\\ <Label>:\\\\ <file>[\\\\ <Label>:\\\\ <file>...], each\n` +
      `  item using the same succeeded/failed/capture-failed forms as MXTS.\n` +
      `  Any shape may end with \\\\ <sanitized debug evidence, no "|" character> for FAIL/BLOCKED.\n` +
      `  No other text is accepted. Affected: ${badProof.slice(0, 5).join(', ')}`
    );
  }

  // 13. "-capture-failed.png" is only for a screenshot that really failed 3 attempts — never "skipped" or
  // "verified via API/DOM". KEEP IN SYNC with post-comment.js and validate-results-comment.js.
  const badCapture = tcRows.filter(row => {
    const m = lastCellRe.exec(row);
    return /[\w-]*capture-failed[\w-]*\.png(?!\s*\(screenshot capture failed — 3\/3 attempts, [^)|]+\))/i.test(m ? m[1] : '');
  }).map(row => (tcIdRe.exec(row.trim()) || [])[1] || '?');
  if (badCapture.length > 0) {
    errors.push(
      `[CHECK 13] Test Proof says the screenshot capture failed or was skipped without the required note.\n` +
      `  A screenshot is mandatory for every TC — API/DOM verification is never a substitute and capture is never skipped.\n` +
      `  Take the screenshot (retry up to 3 attempts, see Phase 3a). Only after 3 real failed attempts may the cell read:\n` +
      `  TC_XX-capture-failed.png (screenshot capture failed — 3/3 attempts, <error>)\n` +
      `  Affected: ${badCapture.slice(0, 5).join(', ')}`
    );
  }

  // 9. No "\|" anywhere in a TC row — this has happened in production (an Actual Result
  // describing an API condition as "offDuty>=today\|\|null" instead of writing "OR").
  // "\|" is NOT a recognized escape in Jira wiki markup — the backslash renders as a
  // literal character and the "|" still delimits the cell, corrupting the row either way.
  const badEscape = [];
  for (const row of tcRows) {
    if (row.includes('\\|')) {
      const tcId = (tcIdRe.exec(row.trim()) || [])[1] || '?';
      badEscape.push(tcId);
    }
  }
  if (badEscape.length > 0) {
    errors.push(
      `[CHECK 9] Literal "\\|" found in ${badEscape.length} TC row(s) — not a valid Jira wiki-markup\n` +
      `  escape. Rewrite the cell without "|" — spell out boolean/logical conditions in words\n` +
      `  ("OR"/"AND") instead of "||"/"&&", or use "/" as the substitution.\n` +
      `  Affected: ${badEscape.slice(0, 5).join(', ')}`
    );
  }

  // 10. Per-row column-count check — catches a bare, unescaped "|" inside any cell, not just
  // the "\|" escape attempt CHECK 9 targets. A stray "|" anywhere in a cell still splits the
  // row into extra columns and corrupts it. Strip legitimate Jira link syntax ([text|url]) first
  // — that's the one place "|" is structurally valid inside a cell — so it isn't a false positive.
  const badColumnCount = [];
  for (const row of tcRows) {
    if (row.includes('\\|')) continue; // already reported by CHECK 9 above
    const tcId = (tcIdRe.exec(row.trim()) || [])[1] || '?';
    const stripped = row.replace(/\[[^\]]*\|[^\]]*\]/g, '[LINK]');
    const segments = stripped.split('|');
    // Well-formed: "| c1 | ... | cN |" -> N + 2 segments (N cells + 2 boundary empties); N is 6, or 12 in a merged table.
    if (segments.length !== expectedCells + 2) {
      badColumnCount.push(`${tcId} (${segments.length - 2} cells found, expected ${expectedCells})`);
    }
  }
  if (badColumnCount.length > 0) {
    errors.push(
      `[CHECK 10] Wrong column count in ${badColumnCount.length} TC row(s) — a stray unescaped "|"\n` +
      `  inside a cell (not just "\\|") also corrupts a Jira wiki-markup row by splitting it into\n` +
      `  extra columns. Rewrite the cell without "|" — spell out boolean/logical conditions in\n` +
      `  words ("OR"/"AND") instead of "||"/"&&", or use "/" as the substitution.\n` +
      `  Affected: ${badColumnCount.slice(0, 5).join(', ')}`
    );
  }

  // 11. Cross-Module Impact "Team" value must be an exact canonical cf[10049] name — never a
  // paraphrase with "Frontend"/"Backend"/"FE"/"BE" appended. Confirmed in production (MXTS-81825,
  // Sep 2026): "Templates backend" was posted instead of "Templates", which — exactly as
  // analyzing-impact/SKILL.md's own warning predicts — silently blanked the QA mention cell
  // instead of failing loudly. Pattern check only (not a full canonical-list match, to avoid
  // duplicating/maintaining that list here) — catches the exact confirmed failure shape.
  const impactStart = lines.findIndex(l => l.trim() === 'h2. Cross-Module Impact');
  if (impactStart !== -1) {
    let impactEnd = lines.findIndex((l, i) => i > impactStart && /^h2\.\s/.test(l.trim()));
    if (impactEnd === -1) impactEnd = lines.length;
    const impactRows = lines.slice(impactStart, impactEnd)
      .filter(l => l.trim().startsWith('|') && !l.trim().startsWith('||'));
    const badTeamSuffix = [];
    for (const row of impactRows) {
      const cells = row.split('|').slice(1, -1).map(c => c.trim());
      const team = cells[1]; // | Module | Team | QA | Impact Type | What is affected |
      if (team && /\s(frontend|backend|fe|be)$/i.test(team)) {
        badTeamSuffix.push(team);
      }
    }
    if (badTeamSuffix.length > 0) {
      errors.push(
        `[CHECK 11] Cross-Module Impact "Team" value has a Frontend/Backend/FE/BE suffix —\n` +
        `  must be the exact canonical cf[10049] value (e.g. "Email Notifications", never "Email Notifications backend").\n` +
        `  A distorted value silently blanks the QA mention cell instead of failing loudly.\n` +
        `  Affected: ${badTeamSuffix.join(', ')}`
      );
    }

    // 12. A Team known (from analyzing-impact/SKILL.md's QA ownership reference) to have a
    // documented QA owner must actually carry a real "[~accountid:...]" mention in its QA cell —
    // not blank, not a plain/paraphrased name. Fixing the Team string alone (CHECK 11) forces the
    // lookup to succeed again, but nothing previously verified the mention itself made it into the
    // cell — the same class of gap the Slack-side "verify the mention is actually in the string"
    // audit already exists for (analyzing-impact/SKILL.md, MXTS-77438), just missing on this Jira
    // wiki-markup path. KEEP THIS LIST IN SYNC with the QA ownership reference table's row keys —
    // only the unambiguous single-cf[10049]-value rows are included; rows
    // without a confirmed cf[10049] value are left out to avoid a false positive on a mapping this
    // script doesn't own.
    const TEAMS_WITH_QA_OWNERS = [
      'Reservations/CCM/NM', 'Finance / Owner / Compliance', 'Content & Back Office', 'Channel Manager',
      'Revenue & Availability', 'Revenue & Channel', 'Third Parties - API', 'Third Parties - Connections',
      'Email Notifications', 'FrontOps', 'Web Manager - Development', 'Reporting & BI',
    ];
    const missingMention = [];
    for (const row of impactRows) {
      const cells = row.split('|').slice(1, -1).map(c => c.trim());
      const team = cells[1];
      const qa = cells[2] || '';
      if (team && TEAMS_WITH_QA_OWNERS.includes(team) && !/\[~accountid:[^\]\s][^\]]*\]/.test(qa)) {
        missingMention.push(team);
      }
    }
    if (missingMention.length > 0) {
      errors.push(
        `[CHECK 12] Cross-Module Impact QA cell has no real mention for team(s) with a documented\n` +
        `  QA owner: ${missingMention.join(', ')}. Use "[~accountid:<Jira Account ID>]" from the QA\n` +
        `  ownership reference (analyzing-impact/SKILL.md) — never leave it blank, and never write a\n` +
        `  plain name or email instead of the real mention token.`
      );
    }
  }

  // 21. The footer counts what the Automate/Automated column says (results-layout.js).
  errors.push(...resultsLayout.footerCountErrors(text));

  // 14. Split comment: the part marker, exactly the TCs assigned to this part, Cross-Module Impact only in the last part.
  errors.push(...resultParts.partErrors(text, partOpt, partTcIds, runTotal));

  return errors;
}

// Canonical Phase 3b template — printed on failure so the body can be rebuilt WITHOUT
// context (e.g. after mid-run context compaction). Keep in sync with post-comment.js.
const CANONICAL_TEMPLATE = [
  'h2. QA Test Results',
  '',
  '| *Concern* | <MQA / RCN / KRM-CMS / ... or "Generation only"> |',
  '| *Environment* | <Dev / Test or "Generation only"> |',
  '| *Build / Version* | <build_version> |',
  '| *Preconditions* | <summary from stories.<STORY_KEY>.preconditions_verified, or "None detected"> |',
  '| *Total TCs* | <n> |',
  '| *Passed* | <n> |',
  '| *Failed* | <n> |',
  '| *Blocked* | <n> |',
  '| *Needs Review* | <n> |',
  '| *Skipped* | <n> |',
  '| *Pass rate* | <n>% (BLOCKED and Skipped excluded), or N/A (no TC verified) if Total minus Blocked minus Skipped is 0 |',
  '| *QA Pipeline Version* | <qa-engineer plugin version, from plugin.json> |',
  '| *Test Execution Timing* | <n>m or <n>h <n>m, then " (<n> pause)" / " (<n> pauses)" when the run had pauses; N/A (generation only) only if Phase 3a never ran |',
  '',
  '|| TC_ID || Test case scenario || Expected Result || Actual Result || Status || Test Proof ||',
  '| TC_01 | <scenario> | <expected> | <actual> | PASS ✅ | !TC_01-slug.png! |',
  '(one row per TC — no prose sections, no phase labels, no Markdown ## headers)',
  '(MXTS Test Proof: !TC_XX-slug.png! — MCMS Test Proof: Before:\\\\ !TC_XX-slug-before.png!\\\\ After:\\\\ !TC_XX-slug-after.png! — note the space after each \\\\, a bare \\\\ renders as literal text in Jira)',
  '(no separate hostname heading in multi-URL comments — Concern/Environment inside each block already identify it)',
  '',
  'After execution the Test Cases comment itself is edited in place; its table then has 12 columns — the 10 Test Cases columns, unchanged except Actual result and Automated, then Status and Test Proof:',
  resultsLayout.wikiHeader(resultsLayout.MERGED_COLS),
  '| TC_01 | <scenario> | <preconditions> | <steps> | <expected> | <actual> | <STORY_KEY> | <EPIC_KEY or N/A> | Yes/No | High | PASS ✅ | !TC_01-slug.png! |',
].join('\n');

const validationErrors = validateBody(body);
if (validationErrors.length > 0) {
  process.stderr.write(
    `\n❌ update-comment.js BLOCKED — comment body failed validation (${validationErrors.length} issue(s)).\n` +
    `Discard this draft and rebuild by copying the exact template below — do NOT reconstruct\n` +
    `the format from memory (it may be stale after context compaction):\n\n` +
    `──────── COPY THIS TEMPLATE ────────\n${CANONICAL_TEMPLATE}\n────────────────────────────────────\n\n` +
    validationErrors.join('\n\n') + '\n'
  );
  process.exit(1);
}

// ─── PUT ──────────────────────────────────────────────────────────────────────

const auth     = Buffer.from(`${email}:${apiToken}`).toString('base64');
const headers  = { Authorization: `Basic ${auth}`, 'Content-Type': 'application/json', Accept: 'application/json' };
const issueUrl = `https://maxxton.atlassian.net/rest/api/2/issue/${encodeURIComponent(issueKey)}`;
const url      = `${issueUrl}/comment/${encodeURIComponent(commentId)}`;

// Prints the screenshot check on stderr and returns the exit code: 0 when every screenshot the body names is
// attached to the issue, 3 when one is not or when Jira could not be asked.
async function reportScreenshots(id) {
  try {
    const result = await screenshotAttachments.check(body, issueUrl, headers);
    process.stderr.write(`${screenshotAttachments.describe(result, issueKey, id)}\n`);
    return result.missing.length === 0 ? 0 : 3;
  } catch (err) {
    process.stderr.write(`⚠️  Screenshots: could not be checked for ${issueKey} (${err.message}). Run this same command again to check.\n`);
    return 3;
  }
}

// A merged body replaces the Test Cases comment itself, so before the PUT the live comment is read and compared:
// every TC row, the kept columns and the AC-coverage footer must come through unchanged. Fails closed when the
// comment cannot be read.
const mergedBody = resultsLayout.wikiLayout(body.split('\n'))?.name === 'merged';

async function assertNothingLost() {
  if (!mergedBody) return;
  const res = await fetch(url, { headers });
  if (!res.ok) throw new Error(`GET comment ${commentId} failed: ${res.status}`);
  const existing = await res.json();
  const lost = resultsLayout.lostFromTestCases(String(existing.body || ''), body);
  if (lost.length) {
    process.stderr.write(
      `\n❌ update-comment.js BLOCKED — the merged body would lose data from the existing comment ${commentId} (${lost.length} issue(s)).\n` +
      `Rebuild the body from the live comment (read it again, keep every Test Cases cell as it is, fill only Actual result,\n` +
      `${resultsLayout.AUTOMATE_NAMES[1]}, Status and Test Proof):\n\n` + lost.join('\n\n') + '\n'
    );
    process.exit(1);
  }
}

assertNothingLost().then(() => fetch(url, {
  method:  'PUT',
  headers,
  body:    JSON.stringify({ body }),
}))
  .then(res => {
    if (!res.ok) return res.text().then(t => { process.stderr.write(`Jira API error ${res.status}: ${t}\n`); process.exit(1); });
    return res.json();
  })
  .then(async data => {
    process.stdout.write(`Updated comment ${data.id}\n`);
    process.exitCode = await reportScreenshots(data.id);
  })
  .catch(err => { process.stderr.write(`Update failed: ${err.message}\n`); process.exit(1); });
