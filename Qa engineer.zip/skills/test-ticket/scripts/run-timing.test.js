#!/usr/bin/env node
/**
 * Tests for run-timing.js and timing-value.js formatTiming. Self-contained: node:test + node:assert.
 * Run: node plugins/qa-engineer/skills/test-ticket/scripts/run-timing.test.js
 */
'use strict';

const test = require('node:test');
const assert = require('node:assert');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { spawnSync } = require('child_process');
const { formatTiming, timingError } = require('./timing-value');

const SCRIPT = path.join(__dirname, 'run-timing.js');
const tmpRoots = [];
function stateFile(story) {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'run-timing-'));
  tmpRoots.push(dir);
  const file = path.join(dir, 'run-state.json');
  fs.writeFileSync(file, JSON.stringify({ phase: 'phase3a', jira_write_path: 'mcp', stories: { K: story || {} } }));
  return file;
}
const read = (file) => JSON.parse(fs.readFileSync(file, 'utf8'));
const run = (args, now) => {
  const r = spawnSync(process.execPath, [SCRIPT, ...args], { encoding: 'utf8', env: { ...process.env, RUN_TIMING_NOW: now || '' } });
  return { code: r.status, out: r.stdout.trim(), err: r.stderr.trim() };
};
test.after(() => { for (const d of tmpRoots) fs.rmSync(d, { recursive: true, force: true }); });

test('formatTiming: rounds to total minutes first, then splits; pause suffix; clamps negatives', () => {
  assert.strictEqual(formatTiming(42 * 60), '42m');
  assert.strictEqual(formatTiming(72 * 60, 1), '1h 12m (1 pause)');
  assert.strictEqual(formatTiming(38 * 60, 2), '38m (2 pauses)');
  assert.strictEqual(formatTiming(1 * 3600 + 59 * 60 + 31), '2h 0m', '1h 59m 31s must carry into the hour, not "1h 60m"');
  assert.strictEqual(formatTiming(3600), '1h 0m');
  assert.strictEqual(formatTiming(-500, 3), '0m (3 pauses)');
  assert.strictEqual(formatTiming(NaN), '0m');
  for (const s of [0, 29, 31, 3599, 7200, 86399]) for (const p of [0, 1, 5]) assert.strictEqual(timingError(formatTiming(s, p)), null, `${s}/${p}`);
});

test('init: sets what is missing, never overwrites, last_activity_at follows a fresh stamp', () => {
  const f = stateFile();
  assert.strictEqual(run(['init', f, 'K'], '2026-10-14T09:00:00.000Z').out, 'OK');
  const s = read(f).stories.K;
  assert.deepStrictEqual([s.cycle_started_at, s.user_wait_seconds, s.pause_count, s.last_activity_at, s.url_timing],
    ['2026-10-14T09:00:00.000Z', 0, 0, '2026-10-14T09:00:00.000Z', {}]);
  assert.strictEqual(read(f).jira_write_path, 'mcp', 'other run-state content is kept');
  run(['init', f, 'K'], '2026-10-14T12:00:00.000Z');
  assert.deepStrictEqual(read(f).stories.K, s, 'a second init changes nothing');
  const g = stateFile({ cycle_started_at: '2026-10-14T08:00:00.000Z' });
  run(['init', g, 'K'], '2026-10-14T10:00:00.000Z');
  assert.strictEqual(read(g).stories.K.last_activity_at, '2026-10-14T10:00:00.000Z', 'resume of an old state: heartbeat starts now');
  assert.strictEqual(read(g).stories.K.cycle_started_at, '2026-10-14T08:00:00.000Z');
});

test('gap-check: over 600 s is one pause, 600 s or less is not, missing heartbeat is not; always refreshes', () => {
  const f = stateFile({ cycle_started_at: '2026-10-14T10:00:00.000Z', user_wait_seconds: 0, pause_count: 0, last_activity_at: '2026-10-14T10:30:00.000Z' });
  assert.match(run(['gap-check', f, 'K'], '2026-10-14T14:00:00.000Z').out, /pause counted: gap 12600s/);
  let s = read(f).stories.K;
  assert.deepStrictEqual([s.user_wait_seconds, s.pause_count, s.last_activity_at], [12600, 1, '2026-10-14T14:00:00.000Z']);
  assert.match(run(['gap-check', f, 'K'], '2026-10-14T14:00:00.000Z').out, /no pause: gap 0s/, 'the same gap is never counted twice');
  assert.match(run(['gap-check', f, 'K'], '2026-10-14T14:10:00.000Z').out, /no pause: gap 600s/);
  assert.match(run(['gap-check', f, 'K'], '2026-10-14T14:20:01.000Z').out, /pause counted: gap 601s/);
  assert.strictEqual(read(f).stories.K.pause_count, 2);
  const g = stateFile({ cycle_started_at: '2026-10-14T10:00:00.000Z' });
  assert.match(run(['gap-check', g, 'K'], '2026-10-14T14:00:00.000Z').out, /no valid last_activity_at/);
  s = read(g).stories.K;
  assert.deepStrictEqual([s.user_wait_seconds, s.pause_count, s.last_activity_at], [undefined, undefined, '2026-10-14T14:00:00.000Z']);
});

test('pause: a Session Recovery wait counts one pause and moves the heartbeat to the wait end', () => {
  const f = stateFile({ cycle_started_at: '2026-10-14T09:00:00.000Z', user_wait_seconds: 0, pause_count: 0 });
  run(['pause', f, 'K', '2026-10-14T09:30:00.000Z', '2026-10-14T09:38:00.000Z']);
  const s = read(f).stories.K;
  assert.deepStrictEqual([s.user_wait_seconds, s.pause_count, s.last_activity_at], [480, 1, '2026-10-14T09:38:00.000Z']);
});

test('render single URL: the eval examples (35m (1 pause), 1h 12m (1 pause), 42m) and the clamp', () => {
  const f = stateFile({ cycle_started_at: '2026-10-14T10:00:00.000Z', user_wait_seconds: 12600, pause_count: 1 });
  assert.strictEqual(run(['render', f, 'K', '2026-10-14T14:05:00.000Z']).out, '35m (1 pause)');
  const g = stateFile({ cycle_started_at: '2026-10-14T09:00:00.000Z', user_wait_seconds: 480, pause_count: 1 });
  assert.strictEqual(run(['render', g, 'K', '2026-10-14T10:20:00.000Z']).out, '1h 12m (1 pause)');
  const h = stateFile({ cycle_started_at: '2026-10-14T09:00:00.000Z' });
  assert.strictEqual(run(['render', h, 'K', '2026-10-14T09:42:00.000Z']).out, '42m', 'missing wait/pause fields count as 0');
  const c = stateFile({ cycle_started_at: '2026-10-14T09:00:00.000Z', user_wait_seconds: 7200, pause_count: 2 });
  assert.strictEqual(run(['render', c, 'K', '2026-10-14T09:10:00.000Z']).out, '0m (2 pauses)');
});

test('render multi-URL: per-URL start/end, the last URL ends at cycle_ended_at, pauses are per URL', () => {
  const f = stateFile({
    cycle_started_at: '2026-10-14T09:00:00.000Z', user_wait_seconds: 600, pause_count: 1,
    url_timing: {
      'mqa-dev.maxxton.net': { ended_at: '2026-10-14T09:30:00.000Z', user_wait_seconds: 0, pauses: 0 },
      'rcn-dev.maxxton.net': { ended_at: '2026-10-14T09:50:00.000Z', user_wait_seconds: 600, pauses: 1 },
    },
  });
  assert.strictEqual(run(['render', f, 'K', '2026-10-14T10:00:00.000Z', '--url', 'mqa-dev.maxxton.net']).out, '30m');
  assert.strictEqual(run(['render', f, 'K', '2026-10-14T10:00:00.000Z', '--url', 'rcn-dev.maxxton.net']).out, '20m (1 pause)', 'last URL: 09:30 to 10:00 minus 10 min wait');
  assert.match(run(['render', f, 'K', '2026-10-14T10:00:00.000Z', '--url', 'nope.maxxton.net']).err, /no entry for "nope/);
});

test('url-begin / url-end build url_timing in run order', () => {
  const f = stateFile({ cycle_started_at: '2026-10-14T09:00:00.000Z' });
  run(['url-begin', f, 'K', 'a.maxxton.net']);
  run(['url-end', f, 'K', 'a.maxxton.net'], '2026-10-14T09:20:00.000Z');
  run(['url-begin', f, 'K', 'b.maxxton.net']);
  run(['pause', f, 'K', '2026-10-14T09:25:00.000Z', '2026-10-14T09:30:00.000Z', '--url', 'b.maxxton.net']);
  const s = read(f).stories.K;
  assert.deepStrictEqual(Object.keys(s.url_timing), ['a.maxxton.net', 'b.maxxton.net']);
  assert.deepStrictEqual(s.url_timing['a.maxxton.net'], { user_wait_seconds: 0, pauses: 0, ended_at: '2026-10-14T09:20:00.000Z' });
  assert.deepStrictEqual(s.url_timing['b.maxxton.net'], { user_wait_seconds: 300, pauses: 1 });
  assert.strictEqual(run(['render', f, 'K', '2026-10-14T09:50:00.000Z', '--url', 'b.maxxton.net']).out, '25m (1 pause)');
});

test('render: a null cycle_started_at falls back to the earliest screenshot; without one it fails instead of printing N/A', () => {
  const f = stateFile({ cycle_started_at: null, user_wait_seconds: 0, pause_count: 0 });
  assert.strictEqual(run(['render', f, 'K', '2026-10-14T10:00:00.000Z']).code, 1);
  const shots = path.join(path.dirname(f), 'shots');
  fs.mkdirSync(path.join(shots, 'sub'), { recursive: true });
  const early = new Date('2026-10-14T09:15:00.000Z'), late = new Date('2026-10-14T09:40:00.000Z');
  fs.writeFileSync(path.join(shots, 'TC_02-b.png'), 'x');
  fs.utimesSync(path.join(shots, 'TC_02-b.png'), late, late);
  fs.writeFileSync(path.join(shots, 'sub', 'TC_01-a.png'), 'x');
  fs.utimesSync(path.join(shots, 'sub', 'TC_01-a.png'), early, early);
  assert.strictEqual(run(['render', f, 'K', '2026-10-14T10:00:00.000Z', '--screenshots-dir', shots]).out, '45m');
});

test('errors: unknown story, missing file, bad time, unknown command all exit 1 and leave the file alone', () => {
  const f = stateFile({ cycle_started_at: '2026-10-14T09:00:00.000Z' });
  const before = fs.readFileSync(f, 'utf8');
  assert.strictEqual(run(['init', f, 'NOPE']).code, 1);
  assert.strictEqual(run(['init', path.join(path.dirname(f), 'missing.json'), 'K']).code, 1);
  assert.strictEqual(run(['pause', f, 'K', 'garbage', '2026-10-14T09:38:00.000Z']).code, 1);
  assert.strictEqual(run(['render', f, 'K', 'garbage']).code, 1);
  assert.strictEqual(run(['frobnicate', f, 'K']).code, 1);
  assert.strictEqual(fs.readFileSync(f, 'utf8'), before);
  assert.deepStrictEqual(fs.readdirSync(path.dirname(f)).filter((n) => n.endsWith('.tmp')), []);
});

test('fractional seconds: a 600.4 s gap is a pause, and rounding happens once, to minutes', () => {
  const f = stateFile({ cycle_started_at: '2026-10-14T10:00:00.000Z', user_wait_seconds: 0, pause_count: 0, last_activity_at: '2026-10-14T10:00:00.000Z' });
  assert.match(run(['gap-check', f, 'K'], '2026-10-14T10:10:00.400Z').out, /pause counted: gap 600s/, 'over the threshold even though it rounds to 600');
  assert.strictEqual(read(f).stories.K.user_wait_seconds, 600.4);
  assert.match(run(['gap-check', f, 'K'], '2026-10-14T10:20:00.400Z').out, /no pause: gap 600s/, 'exactly 600.0 s is not over the threshold');
  const g = stateFile({ cycle_started_at: '2026-10-14T10:00:00.000Z' });
  assert.strictEqual(run(['render', g, 'K', '2026-10-14T10:00:29.600Z']).out, '0m', '29.6 s must not become 30 s and then 1m');
  assert.strictEqual(run(['render', g, 'K', '2026-10-14T10:00:30.000Z']).out, '1m');
});

test('gap-check: an unreadable last_activity_at is treated as missing, not as a crash', () => {
  const f = stateFile({ cycle_started_at: '2026-10-14T09:00:00.000Z', last_activity_at: 'garbage' });
  const r = run(['gap-check', f, 'K'], '2026-10-14T14:00:00.000Z');
  assert.strictEqual(r.code, 0);
  assert.match(r.out, /no valid last_activity_at/);
  assert.strictEqual(read(f).stories.K.last_activity_at, '2026-10-14T14:00:00.000Z');
  assert.strictEqual(read(f).stories.K.pause_count, undefined);
});

test('render: cycle_ended_at defaults to now', () => {
  const f = stateFile({ cycle_started_at: '2026-10-14T09:00:00.000Z', user_wait_seconds: 480, pause_count: 1 });
  assert.strictEqual(run(['render', f, 'K'], '2026-10-14T10:20:00.000Z').out, '1h 12m (1 pause)');
});

test('pause-start / pause-end count one pause without typing any time', () => {
  const f = stateFile({ cycle_started_at: '2026-10-14T09:00:00.000Z', user_wait_seconds: 0, pause_count: 0, url_timing: { 'a.maxxton.net': { user_wait_seconds: 0, pauses: 0 } } });
  assert.strictEqual(run(['pause-start', f, 'K'], '2026-10-14T09:30:00.000Z').out, 'OK');
  assert.match(run(['pause-end', f, 'K', '--url', 'a.maxxton.net'], '2026-10-14T09:38:00.000Z').out, /pause counted \(pause_count 1\)/);
  const s = read(f).stories.K;
  assert.deepStrictEqual([s.user_wait_seconds, s.pause_count, s.last_activity_at, s.pause_started_at], [480, 1, '2026-10-14T09:38:00.000Z', undefined]);
  assert.deepStrictEqual(s.url_timing['a.maxxton.net'], { user_wait_seconds: 480, pauses: 1 });
  const again = run(['pause-end', f, 'K'], '2026-10-14T09:50:00.000Z');
  assert.match(again.out, /no pause was started/);
  assert.strictEqual(read(f).stories.K.pause_count, 1, 'a second pause-end never double-counts');
});
