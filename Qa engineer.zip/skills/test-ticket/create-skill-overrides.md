# create-skill overrides — test-ticket

## Ungated routine Jira writes (Phase 2 TC comments, Phase 3b results comment)

**Decision:** Routine pipeline writes (Phase 2 TC table, Phase 3b results) fire without a per-write confirmation gate.

**Justification:**
- **Explicit invocation only.** `disable-model-invocation: true` means this skill runs only when the user types `/test-ticket EPIC-ID` — that command is the consent signal. The user is consciously starting a pipeline whose documented deliverables include Jira comments; they are not side effects of ambient reasoning.
- **High-stakes actions are individually gated.** Defect creation (Phase 5), Playwright spec generation (Phase 3b decision), and triage classification (Phase 4) each have explicit yes/no gates before any irreversible Jira write. PROD URLs, NEEDS REVIEW verdicts, and the `--retest` regression path are all gated too.
- **Routine writes are the expected output.** A TC table comment on the story and a results comment are the primary deliverables of the command — gating them would require 3–5 prompts per story per run, destroying the "runs automatically" UX that is the skill's core value proposition.
- **`--unattended` opt-in is available.** Users who want zero prompts (CI, overnight runs) pass `--unattended`; users who want maximum control can review output between phases using `--from=phase<N>` to resume.
- **Slack notification** is opt-in via the `slack_channel` config field — blank by default, so it fires only when the team explicitly enables it.
