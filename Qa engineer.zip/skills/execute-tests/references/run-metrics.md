# Run Metrics

Every `/test-ticket` and `/execute-tests` run writes one small record, **local only** — nothing is sent anywhere. It exists so the team can put numbers on recurring complaints (how many TCs end BLOCKED and why, where the time goes, what keeps getting in the way) instead of arguing from anecdotes. Collect the files by hand from the `test-output/` folders and summarise them with the script.

**Never recorded:** code, diffs, TC/scenario/expected/actual text, selectors, URLs, hostnames, file paths, Jira keys, comment bodies, customer data, tokens, secrets. The script enforces this — it writes a fixed set of keys and strips URL-, e-mail-, path- and token-shaped text from every free-text detail. **Opt out:** set `QA_ENGINEER_METRICS=off` (every command becomes a silent no-op).

## The script

```
node "$CLAUDE_PLUGIN_ROOT/skills/test-ticket/scripts/run-metrics.js" <command> <dir> [args]
```

`<dir>` is the run's output folder: `test-output/<EPIC_ID>` for `/test-ticket`, `test-output/<STORY_KEY>` for `/execute-tests`. The record is `<dir>/run-metrics.json`.

| Command | When | What it does |
|---|---|---|
| `phase <dir> <name> [--kind=execute-tests] [--mode=inline]` | At the start of each phase (below); the first call creates the record | Closes the previous phase, opens `<name>`. Names: `preflight`, `phase1`, `phase2`, `phase2.5`, `phase3a`, `evidence-review`, `phase3b`, `phase4`, `phase5`, `phase6`, `final` |
| `event <dir> <code> [detail]` | At the friction points below | Appends a timestamped event. `detail` is optional, short, and sanitised |
| `finish <dir>` | Once, at the very end (Final Summary / Step 7) | Closes the open phase, computes TC counts, BLOCKED-reason buckets and pass rate from `results.md` |
| `human-review <dir> <slot> <generated> <requested> <accepted> <covered> <declined> <overridden>` | After human-requested cases were added to a story ([Extended Cases](${CLAUDE_PLUGIN_ROOT}/skills/generating-test-cases/references/extended-cases.md)) | Records how many TCs Claude generated and what happened to the cases a human asked for; `slot` = the story's 1-based position in the Epic (never its key). Overwrites that slot. `summarize` reports the miss rate |
| `summarize <dir-or-root>...` | Manually, whenever someone wants the numbers | Markdown report across runs: duration per phase, BLOCKED reasons, friction ranking, `execution_mode` comparison |

**Fail-open, always.** Append `|| true` to every call. A metrics failure must never change a verdict, block a phase, or print anything the user has to act on. The script exits 0 on any error.

`/execute-tests` passes `--kind=execute-tests` on its first `phase` call and uses only `phase3a`-equivalent phases: call `phase <dir> phase3a` at Step 3 start, `phase <dir> evidence-review` at Step 3i-2, `phase <dir> final` at Step 6, `finish` at Step 7. `/test-ticket` calls `phase` at each phase heading it already logs (`[Phase N complete]` lines) and `finish` after the Final Summary is printed.

## Event codes — run `event` whenever the pipeline logs the matching line

| Code | When |
|---|---|
| `playwright_unavailable` | Playwright MCP absent under every prefix (Phase 3a MCP availability check fails) |
| `playwright_prefix_fallback` | Run continues on `mcp__playwright__*` / `mcp__playwright-headed__*` instead of the bundled server |
| `jira_write_path_mcp` | `jira_write_path` resolved to `mcp` |
| `env_degraded_transient` | Health check failed once, cleared on the 30 s retry |
| `env_degraded_blocked` | Health check failed twice → all TCs BLOCKED |
| `env_flagged_broken` | [Environment-Down Check](environment-down-check.md) result `broken` |
| `health_check_slack_unavailable` | Environment-Down Check could not read Slack |
| `session_recovery` | Login page detected mid-run (Session Recovery started) |
| `host_guard_stop` / `host_guard_third_party` | [Host Guard](host-guard.md) stopped a TC / allowed a named third-party hop |
| `precondition_unconfirmed` | Precondition Evidence Check could not confirm a ticket-level precondition |
| `tc_timeout` | A TC hit `--tc-timeout` (BLOCKED timeout) |
| `budget_exhausted` | `--max-time` exhausted |
| `early_abort` | 3 consecutive High-risk FAILs auto-stop |
| `evidence_review_downgrade` / `evidence_review_failed` / `evidence_review_skipped` | [Evidence Review](evidence-review.md) outcomes |
| `resume_run` | The invocation resumed a previous run instead of starting fresh |

An unknown code is rejected by the script (warning on stderr, exit 0) — never invent one.

## `execution_mode`

Always `inline` today (the executor drives the browser itself). The field exists so a future experiment that runs each TC's browser steps in a subagent can be compared against inline runs of the same Epic with `summarize` — mean total seconds per mode — before anyone decides whether it is worth shipping. Do not pass `--mode=subagent` outside such an experiment.
