# Bill Snapshots (Before / After Recalculation)

Shared by `/execute-tests` and `/test-ticket` Phase 3a — one procedure, read by both. Names differ per skill and are given in each step.

**Why this exists:** MXTS-81495 (Oct 2026) — every TC passed on the MAR line (407.00 → 347.82), but the customer total moved 947.72 → 847.72 after "Recalculate reservation". A tester and a second team found it by hand. The TCs only asserted one line, and the proof was one small screenshot after the change. A bill-changing TC now records the whole bill, VAT included, before the change and after the recalculation, and the exact differences go into the Actual Result.

## When it applies

A TC that **saves a change to what a reservation is charged** — override rates, add or remove an add-on, apply or remove an offer/voucher/discount, change dates, accommodation, unit, guests or status in a way that reprices — and whose observation is on the reservation's Finance/Bill screen (or whose Scenario or Expected Result names the bill, a rate, a price, VAT or a total). A TC that discards the change (Cancel, close without saving) or only re-reads the bill (reload, API check) saves nothing: it keeps its ordinary single screenshot. A multi-item or comparison TC keeps its own rules and applies this once per item.

## Procedure

1. **Before the first changing step** — capture snapshot `before` and the **Before** screenshot (below).
2. Run the changing steps as the TC writes them.
3. **The TC has a "Recalculate reservation" step** — right before it, capture snapshot `changed` (the saved state, still unrecalculated). Perform the recalculation like any domain-action step (control not on screen → Control Discovery). Wait for the page to be ready, then capture snapshot `after` and the **After** screenshot.
   **The TC has no recalculate step** (a TC comment from before this rule, or a hand-added case) — do not invent one. Capture `after` once the last step is done and log `[bill] <TC_ID> — no Recalculate step in this TC; After taken without one`; the Actual Result says so.
4. **Diff** (script below). Verdict rules after the diff.
5. A retry attempt (3g) repeats all of it from step 1 and overwrites the files.

## Capturing a snapshot

Files go in `test-output/<STORY_KEY>/bill-snapshots/<TC_ID>-before.json`, `-changed.json`, `-after.json` (amounts only; never paste them into a narration table).

1. **Find the bill requests once per TC:** `browser_network_requests(filter: "/bills")` on the Finance tab (none listed → reload the tab and look again). Take the exact URL of every GET whose path ends in `/bills` — the customer bill and the Internal Bill are separate; note which is which. (`POST …/bills/recalculate` is the recalculation itself, not a bill.)
2. **Read them with the session** — one short `browser_evaluate`, URLs filled in:
   ```js
   async () => {
     const sources = [{ url: '<customer bill url>', internal: false }, { url: '<internal bill url>', internal: true }];
     const lines = [];
     for (const s of sources) {
       const body = await (await fetch(s.url, { credentials: 'include' })).json();
       for (const l of (Array.isArray(body) ? body : (body.content || body.reservationBillLines || []))) {
         lines.push({ internal: s.internal, description: l.description, billLineType: l.billLineType, payerType: l.payerType, startDate: l.startDate, endDate: l.endDate, quantity: l.quantity, value: l.value, total: l.total, totalVat: l.totalVat, vatRate: l.vatRate, overrideValue: l.overrideValue });
       }
     }
     return lines;
   }
   ```
3. **Read the totals the screen shows** (Sub-total, Total, First payment, the header total, and each VAT-per-rate figure when listed) with `browser_snapshot`, as plain numbers (currency symbol and thousands separator removed, discounts negative).
4. **Write** `{ "lines": [...], "totals": { "Total": 847.72 } }` with the Write tool.

The API spec does not say whether `total` includes VAT, so both `total` and `totalVat` are kept as returned; the large-viewport screenshot shows Total/Due as the app presents it. **No `/bills` request found, or the response has no `total`** → read the visible bill rows from `browser_snapshot` into `lines` and say "read from screen" in the Actual Result. **Nothing readable at all** → no snapshot: the TC runs with its ordinary single screenshot, the Actual Result says `bill snapshot unavailable: <reason>`, and the verdict is unchanged.

## Screenshots

Each capture is the Finance/Bill large-viewport capture of [the Finance/Bill Screenshots reference](finance-bill-screenshots.md) — resize, zero-scroll check, capture, restore — run once for Before and once for After; the viewport is back to normal between them.

| Skill | Before | After |
|---|---|---|
| `/execute-tests` | `<TC_ID>-bill-before.png` (never `<TC_ID>-before.png`: Step 3a uses that for a retry's before-screenshot) | `<TC_ID>-bill-after.png` |
| `/test-ticket` | `<TC_ID>-<slug>-before.png` | `<TC_ID>-<slug>-after.png` |

These replace the TC's single result screenshot — never take a third one. Without a recalculate step the After is simply the end-of-TC screenshot, so the pair is still Before + After.

## Diff and verdict

```bash
node "${CLAUDE_PLUGIN_ROOT}/skills/test-ticket/scripts/bill-diff.js" <from.json> <to.json> [--expect "<line or total>"]...
```

Exit 0 = nothing unexpected moved, 2 = something unexpected moved (`unexpected` lists it), 1 = unusable input. `summary` is one line with no `|`, ready for a table cell. `--expect` names what the TC's Expected Result says may change (a line description or total name, case-insensitive substring). A total follows its lines, so name it only when an expected line is customer-facing; a total that moves with nothing expected to explain it is exactly what this check exists to catch.

- **`before` → `after`**, no `--expect`: informational only, its exit code is ignored. It is the "what changed overall" sentence.
- **`changed` → `after`** (when `changed` exists), with `--expect` for what the recalculation is meant to rebuild: the verdict check. Exit 2 → the recalculation moved something the Expected Result does not name → `NEEDS REVIEW 🔍`, or `FAIL ❌` when the Expected Result says that line, total or bill stays unchanged. Exit 0 → verdict from the Expected Result as usual.
- The diff never turns a FAIL or NEEDS REVIEW into PASS, and the Expected Result's own numbers (e.g. "MAR reduced by one night's share") are still judged on the exact values.

## Reporting

- **Actual Result** (no `|` in the cell): `Before to after: <summary>. Recalculation alone: <summary>.` — the second sentence only when `changed` exists. The Actual Result lists the lines that moved, not the whole bill.
- **Test Proof:** the labeled pair — `/test-ticket`: per [the Phase 3b results reference](${CLAUDE_PLUGIN_ROOT}/skills/test-ticket/references/phase-3b-results-comment.md) (`Before:\\ !…-before.png!\\ After:\\ !…-after.png!`); `/execute-tests`: `Before: TC_01-bill-before.png; After: TC_01-bill-after.png`.

## Parallel runs

A bill-changing TC mutates a reservation, so two workers must never change the same one: classify it `keyed` with `reservation:<id or number>` (or `serial` when unsure) — see [Parallel Execution](parallel-execution.md) section 2.
