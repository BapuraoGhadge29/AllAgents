# Debug Evidence Capture

Runs after the final verdict from 3f/3g, before Record Result in 3h. A bare screenshot often isn't enough to diagnose *why* something failed — this adds the technical context a screenshot can't show. Applies to `FAIL`, `BLOCKED`, and `NEEDS REVIEW` (including a PASS downgraded by PASS Corroboration in 3f). Skip entirely for a plain `PASS` with no downgrade — capturing this for every passing TC would be noise, not evidence.

1. `browser_network_requests` → look for the request tied to this TC's failing action (status `4xx`/`5xx`).
2. `browser_console_messages` → check for `error`-level messages since this TC started.
3. **Nothing relevant found** → stop here, the screenshot stands alone as before.
4. **Found** → build a short 3–4 line plain-text snippet — the failing request/error only, not a raw dump:
   ```
   POST /api/v1/reservations/12345/confirm
   Status: 500 Internal Server Error
   Response: {"error":"NullPointerException","path":"/api/v1/reservations/12345/confirm"}
   ```
5. **Sanitize before it goes anywhere near this TC's Reason or Jira:**
   - Strip `Authorization`, `Cookie`, `Set-Cookie` header values → `[REDACTED]`.
   - Strip query/body params matching (case-insensitive) `token`, `api_key`, `access_token`, `secret`, `password`.
   - Replace any literal `|` with `/` — an unescaped pipe splits a results-table cell into an extra column and corrupts the row.
   - Truncate the whole snippet to ~300 characters — this is evidence, not a log dump.

**`FAIL` or `BLOCKED`** → append the sanitized snippet to this TC's `Reason` in 3h, semicolon-joined on one line (never a literal newline — the results table is a single markdown row): `Reason: <existing reason>; evidence: <snippet>`.

**`NEEDS REVIEW`** → do NOT fold it into the Jira-bound `Reason`/Actual Result. Save it locally instead — `test-output/<STORY_KEY>/<TC_ID>-console.txt` / `<TC_ID>-network.txt` (skip writing a file if that capture came back empty) — for manual attachment if wanted. `NEEDS REVIEW` already routes to a human via the gate in 3j; the raw evidence sits alongside the screenshot locally rather than crowding the Jira comment.
