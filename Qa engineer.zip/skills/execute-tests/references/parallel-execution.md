# Parallel Execution (automatic)

<!-- ⚠️ MUST KEEP IN SYNC with test-ticket/references/parallel-execution.md — that file lists only what differs in Phase 3a and leans on this one for the rest. -->

The TCs run on two isolated browsers at once instead of one after another. It is automatic: nobody has to ask for it, and this procedure decides by itself whether it pays off (section 1 and the split in section 3) and otherwise falls back to the normal sequential Step 3. `--workers=1` turns it off; `--workers=2` is the most there is. The coordinator (this session) does the setup, the split, the checking and the report. Up to 2 worker subagents, each on its own browser, run their share of the TCs. Anything a worker cannot be trusted with, or that shares data with another TC, runs afterwards alone in this session.

Worker 1 is this session's own browser. Worker 2 is the `playwright-w2` server (`npx @playwright/mcp@latest --isolated`), the one shape the managed MCP allowlist lets this plugin declare for a second browser. The worker browser starts empty, so it gets this session's login from a file (sections 4 and 5); it cannot log in itself.

Files live in `test-output/<STORY_KEY>/parallel/`: `plan-input.json`, `plan.json`, `state.json`, `brief-w<n>.md`, `worker-<n>.json`, `tc-timer-w<n>.json`, `verify.json`, `solo-results.json`.

## After a context compaction or a restart — do this first

Nothing a parallel run needs lives only in the conversation. When you are unsure where the run stands (the clearest sign is a summary of the conversation), run this before anything else and do what `next` says. It reads the files, so it is right even when the summary is not.

```bash
node "$CLAUDE_PLUGIN_ROOT/skills/test-ticket/scripts/parallel-split.js" status test-output/<STORY_KEY>/parallel
```

Trust the answer only when `plan.created_at` is after this run began (your summary says when it started; `plan.age_minutes` helps). An older plan belongs to an earlier run that was never finished: ignore that folder and start at section 1.

| `next` | What to do |
|---|---|
| `plan` | No plan yet: sections 1 to 3. |
| `sequential` | The plan fell back to a sequential run. Run the normal Step 3 loop for `solo.pending` only, rewrite `solo-results.json` after each TC as section 7 says, and go on with 3i-2, 3j, 3k and Step 5 when nothing is pending. |
| `dispatch` | A plan exists and no worker has written anything: sections 4 and 5. |
| `verify` | The workers were dispatched. Do not dispatch again. They run in the background and a compaction does not stop them, so one may still be running: when `workers[].pending` in the answer is not empty, start the live watch again (section 5, "Wait and live view"), wait as it says, then do section 6 on what they wrote. After a restart no worker is running: a `worker-<n>.json` that has not changed for 10 minutes (`ls -l`) belongs to a worker that is gone, so go to section 6 at once. A TC a worker did not finish has no entry and is re-run alone. |
| `solo` | Section 7 for `solo.pending` only. `state.json` says whether the flags were already enabled. |
| `merge` | Section 8. |
| `post` | The results are merged and written; Steps 6, 6e and 7 are left. Step 6a reads the story's comments: post only when no results comment from this run exists yet. Then 6e and 7, then section 8's last paragraph. |
| `done` | Nothing left. |

`state.json` in the same folder holds what the files cannot show. Re-apply `options` as if they had been typed on the command line (`max_tcs`, `retest`, `unattended`, `skip_review`, `tc_timeout`, `max_time`, `screenshots`, `workers` when typed); the rest is `story`, `step3_started_at`, `base_url`, `worker2_url`, `separate_users`, `detected_flags`, `seed` (the QA-SEED names), `storage_state`, `deadline`, `workers` (worker → tool prefix), `flags_to_enable`, `flags_enabled` and `phase`. Write it with `parallel-split.js state <dir> key=value …`: a value that is valid JSON is stored as JSON (quote it in the shell), and a value of the wrong shape is refused. A worker is a separate agent and is not affected by this session's compaction: it keeps its own progress in `worker-<n>.json`.

## 1. Check that parallel mode can run — otherwise run sequentially

Run these after Steps 2–2e and before Step 3. The first failure ends the check: log `[parallel] sequential run — <reason>` and use the normal Step 3.

1. A `<base URL>` was given and `--workers=1` was not (that is the opt-out). Without `--workers` the run is automatic; `--workers=2` is the ceiling someone typed (there are two browsers at most).
2. This session's browser tools are the bundled `mcp__plugin_qa-engineer_playwright__*`, `mcp__playwright__*` or `mcp__playwright-headed__*`. That prefix is worker 1. Any other prefix → sequential.
3. Step 2c did not find an Integration Manager ticket (variable-duration jobs and credential prompts need one browser and the tester), and `--retest` was not passed (reason `scoped retest`).
4. Call `browser_snapshot` once on `mcp__plugin_qa-engineer_playwright-w2__*`. A prefix that errors or is not registered is dropped. This session's own browser is worker 1 and `-w2` is worker 2, so K is at most 2 (or the number typed after `--workers=`). K below 2 → sequential.
5. The split in section 3 may still answer `mode: "serial"`, with its reason (fewer than 8 TCs, fewer than 2 independent groups, too few parallel TCs for two workers, or a saving under 20%).

When the answer is sequential after step 4 opened them, close the probed browser (`browser_close` on `-w2`).

## 2. Classify every TC in scope

In scope = the TC table after `--max-tcs` (and `--retest` order). Read each row's Scenario, Preconditions and Steps together with the Step 2d seed list and Step 2e `detected_flags`, and write `plan-input.json`:

```json
{ "tcs": [ { "id": "TC_01", "risk": "High", "class": "free", "keys": [], "writes": ["customer"], "lists": [], "depends_on": [] } ] }
```

- **`serial`** when the TC: changes a feature flag or a permission; needs a flag that Step 2e found disabled, or is about a flag; checks a whole-list result (counts, totals, pagination, empty state, sort order, availability, occupancy, dashboards); changes environment-wide settings. A flag found already enabled is no constraint. **Unsure → `serial`.** A ticket whose TCs nearly all sit behind a disabled flag ends up almost entirely `serial`, and the split then falls back to a sequential run, which is right: it has little to gain.
- **`user_scoped`** when its only reason to run alone is that it changes, or depends on, the logged-in user's own settings that the app keeps per user (language, saved filters, default view, a saved Card/Table choice, password). Find out where such a setting lives: toggle it once and read `browser_network_requests`. A request to a user or client endpoint (`POST /api/…/clients/<id>/preferences`) means it is kept per user; no request means it stays in the browser, and the TC is `free` or `keyed` as usual. Switching the setting counts as changing it even when the TC is about something else (a selection that must survive a switch between Card and Table is `user_scoped`), and so does reloading the page to check what was kept. A TC that also has a `serial` reason (flag, permission, whole-list check) is `serial`. While every worker shares one login a `user_scoped` TC runs alone; once the workers have their own users (section 3a) it is split like a `free` TC, or a `keyed` one when it changes a shared record.
- **`keyed`** when it edits, archives, deletes, links or changes the status of a shared `QA-SEED-` record, or uses up a shared pool (availability, allotment, stock, price tables), or saves a change to, or recalculates, the bill of a reservation another TC also uses ([Bill Snapshots](bill-snapshot.md)). `keys` names what is shared: `seed:<entity type>`, `pool:<resource and dates>`, `reservation:<number>`. TCs with a common key stay together.
- **`free`** otherwise: it creates its own `QA-AUTO-<STORY_KEY>-<TC_ID>-` data, or only reads a specific record.
- `writes` = entity types the TC creates or changes. `lists` = entity types whose list, count or search results it reads without being list-wide. Both feed the overlap check in section 6. Use singular entity type names (`customer`, not `Customers`); `keys`, `writes` and `lists` are compared without regard to case.
- `depends_on` = TCs whose created data it needs. Only an explicit reference counts, the same rule as 3b Level 2.

## 3. Split

```bash
node "$CLAUDE_PLUGIN_ROOT/skills/test-ticket/scripts/parallel-split.js" plan test-output/<STORY_KEY>/parallel/plan-input.json --max-workers=<K> > test-output/<STORY_KEY>/parallel/plan.json
```

`K` is the number of worker browsers that answered in section 1. Add `--workers=<N>` only when someone typed `--workers=N`; without it the script picks the number itself (every available browser, but at least 4 TCs per worker on average).

Then, whatever the plan says, do these two things at once:

1. Delete what an earlier run left in the folder: everything except `plan-input.json` and `plan.json` (`state.json`, `solo-results.json`, `verify.json`, `worker-*.json`, `brief-w*.md`, `tc-timer-w*.json`). `status` also ignores files older than `plan.json`, but do not rely on that alone.
2. Record the run so that a resume needs no memory: `node "$CLAUDE_PLUGIN_ROOT/skills/test-ticket/scripts/parallel-split.js" state test-output/<STORY_KEY>/parallel phase=planned story=<STORY_KEY> step3_started_at=<ISO> base_url=<URL> detected_flags='[…]' seed='[…]' options='{"max_tcs":…,"retest":…,"unattended":…,"skip_review":…,"tc_timeout":…,"max_time":…,"screenshots":…}'`.

Exit 2 or `mode: "serial"` → sequential run, log the reason, and keep `solo-results.json` current as section 7 says; but when `plan.json` has `second_login.would_split`, do section 3a first. Otherwise print the plan to the user: one line per worker (`Worker 2 · 8 tests: TC_09, TC_14, …`), the TCs that run alone, and `estimate.total` against `estimate.serial_baseline`. Log `[parallel] plan: <n> workers, loads <a>/<b>/<c>, <m> TCs run alone`.

### 3a. Offer a second login (only when `plan.json` has `second_login.would_split`)

The plan is sequential and the one thing in the way is that every worker would share one user: the `user_scoped` TCs (`second_login.user_scoped`) change a setting that the app keeps per user. A second login with its own settings lets them run on two browsers. Skip this section, and run sequentially without a word, when `--unattended` was given or `--workers=1` was typed. Otherwise print this and wait for the answer, the way the early-abort prompt does:

```
⚠️ All <N> test cases run one after another: <M> of them change the logged-in user's own settings (<which>), and both browsers would share this login.
With a second login that has its own settings they could run on 2 browsers: about <second_login.estimate.total> time units instead of <second_login.estimate.serial_baseline>.
Reply with a URL to sign in at, or `sequential`:
  • the same site with another test user: <BASE_URL>
  • or another environment, for example https://<concern>-dev.maxxton.net/home/en-us/
```

1. Read `host-guard.md` for the URL: only `*-dev.maxxton.net` and `*-test.maxxton.net`. Anything else: say why, ask once more, then run sequentially.
2. The same host as `<BASE_URL>` is a second user on this concern. Another host is another concern: print this once and wait for `yes`: "Worker 2 will run its share on <host2>, with that tenant's data and flags. Its verdicts are about <host2>, not <host1>. A PASS stands; a FAIL, a NEEDS REVIEW, a missing screen or missing data is re-run alone here, and every TC it ran starts its Actual Result with `(ran on <host2>)`. Continue? (yes / sequential)". Anything but `yes` → sequential.
3. Open worker 2's browser: `browser_navigate` to the URL with the `-w2` prefix, then `browser_snapshot`. Tell the user: "Sign in in the window that just opened (worker 2), then reply `done`." Never type credentials. After `done` take a `browser_snapshot` on `-w2`: a login form still on the screen → say so, offer one more try, then run sequentially.
4. Run the plan again with `--separate-users --max-workers=2` on the same input file, writing over `plan.json`, then do the two steps of section 3 again (clean the folder, record the run) and add `worker2_url=<URL> separate_users=true` to the `state` call. Continue with the printed plan. Worker 2 keeps its own login: it loads no saved login (sections 4 and 5), and its base URL is `worker2_url`.

## 4. Prepare

1. **Feature flags (Step 2e) change in this mode.** Run its Startup Restore as written. Proactive Detection only reads each flag's state; it enables nothing yet. A flag switched on now would sit in the flags file while the workers run, and that file counts as abandoned after 30 minutes without a heartbeat (feature-flag-check.md line 7), which only a finished TC refreshes. Another session could then switch the flag off again in the middle of the run. The flags found disabled are enabled when the solo phase starts (section 7).
2. Save the login unconditionally (skip this when `separate_users` is true: worker 2 has its own login and nobody else needs the file): `node "$CLAUDE_PLUGIN_ROOT/mcp/run-playwright.js" --storage-state-path` prints the path (outside the repository, with forward slashes in the code below). Then, with this session's own prefix, call `browser_run_code_unsafe` with `async (page) => { await page.context().storageState({ path: '<PATH>' }); return 'saved'; }`. The file holds live session cookies: never print, read or paste its content, and never return anything but that word. Steps 2a–2e may have logged out (the permission toggle does), so an earlier save can be stale.
3. `deadline` = Step 3 start + the run budget (`--max-time`, default 90 min), as an ISO time.
4. Keep this session's browser idle from now until the workers return: worker 1 is using it.
5. Record what a resume needs: `parallel-split.js state test-output/<STORY_KEY>/parallel phase=prepared storage_state=<path> deadline=<ISO> workers='[{"worker":1,"prefix":"<this session's prefix>"},{"worker":2,"prefix":"mcp__plugin_qa-engineer_playwright-w2__"},…]' flags_to_enable='["<flag>",…]' flags_enabled=false`.

## 5. Dispatch

Send **one message with one `Agent` call per worker** (`subagent_type: general-purpose`), each with the brief below. The calls return at once (`Async agent launched`): the workers run in the background and each one's completion arrives later as a notice, so Step 6 never starts straight after the calls (see "Wait and live view" below). Fill every `<…>` from the plan and the run, and write the absolute path of the plugin (`echo "$CLAUDE_PLUGIN_ROOT"`) wherever the template shows `<ROOT>`: a worker's shell may not have that variable. Put each TC's full row (id, scenario, preconditions, steps, expected result, risk) in the brief. Save each brief as `brief-w<n>.md` in the parallel folder first (a worker re-reads it after its own context was shortened), run `state … phase=dispatched`, then send the calls.

```
You are worker <n> of <K> running live test cases for <STORY_KEY> on <BASE_URL>. Other workers run other test cases at the same time in other browsers. Use the Bash tool for every command below.

Browser: use ONLY tools whose names start with `<PREFIX>`. If one is not callable yet, load its schema with ToolSearch first.

Your instructions are also saved in `test-output/<STORY_KEY>/parallel/brief-w<n>.md`. If your earlier messages are no longer in front of you (your context was shortened), read that file, `test-output/<STORY_KEY>/parallel/worker-<n>.json` and Steps 3a to 3h of <ROOT>/skills/execute-tests/SKILL.md, skip every TC that already has an entry in the worker file, and carry on with the next one. Make the same check before your first TC.

Start:
1. Worker 1, and a worker with its own login (`separate_users`: worker 2, whose <BASE_URL> is then its own URL), are already logged in: load nothing. Any other worker: browser_run_code_unsafe with `async (page) => { await page.context().setStorageState('<STORAGE_STATE_PATH>'); return 'loaded'; }`, and never read or print that file. Then browser_navigate to <BASE_URL> and browser_snapshot. A login form means the saved login did not carry over: write every TC as UNRUN with reason `login` and stop. Never type credentials. Never ask the user.
2. Read <ROOT>/skills/execute-tests/references/host-guard.md and obey it for the whole run.

Your test cases, in this order:
<TC ROWS>
Seeded data (reuse it, never create or delete it): <QA-SEED NAMES>. On another host than the coordinator's, look for these names there; when one is absent, write the TC as UNRUN with reason `data`.
Known routes (read only): <NAV CACHE ROUTES FOR THIS HOST>
Deadline <ISO> · per-TC timeout <S> s · screenshots on every attempt: <yes|no>

For each TC follow Steps 3a, 3b, 3d, 3e, 3f and 3h of <ROOT>/skills/execute-tests/SKILL.md, its Debug Evidence Capture section for FAIL, BLOCKED and NEEDS REVIEW, Step 4 between TCs, and the references they name, with these changes:
- One attempt. Do not retry a FAIL; the coordinator re-runs it alone.
- Never record SKIP. A clearly absent expected result is a FAIL here; the solo run decides whether a developer's comment makes it a SKIP.
- Never change a feature flag or a permission and never run the Reactive Feature Flag Check. A screen or element you cannot find after correct navigation is DEFERRED with reason `element-missing`, never BLOCKED or FAIL.
- If the login page shows up in the middle of the run (the session was lost, or someone closed this browser and it came back empty), write this TC as UNRUN with reason `login`. A worker that loaded the saved login (not worker 1, not a worker with its own login) then restores it once per run: the `setStorageState` call of start step 1, then browser_navigate and browser_snapshot. When the login form is gone, carry on with the next TC. When it shows again, or you are worker 1 or have your own login, write every TC after this one as UNRUN with reason `login` and stop. Step 3b's Level 1 rule (block everything, post to Jira) is not yours to apply.
- Do not add EXTRA test cases. Put anything worth testing in `notes`.
- Never prompt. After 3 FAILs in a row on High-risk TCs, or once the deadline has passed, stop and write the rest as UNRUN (reason `early-abort` or `budget`).
- Created data is named `QA-AUTO-<STORY_KEY>-<TC_ID>-…` and torn down after the TC (Rules 1 and 2).
- Screenshots: `test-output/<STORY_KEY>/<TC_ID>-result.png` with fullPage true, plus the per-item, per-source and per-state names of 3h. Put these rules into the brief as 3h states them and never shorten them to "one screenshot per TC": a TC that needs two states (a switch between views, a choice kept after a reload, a before and after, a bar pinned while scrolling) or that is a negative assertion takes one screenshot per state, or the Evidence Review sends its PASS back.
- Time stamps: `node "<ROOT>/skills/test-ticket/scripts/parallel-split.js" now` prints the current UTC time. Take one when a TC starts and one when it ends.
- Timer: `node "<ROOT>/skills/test-ticket/scripts/run-timing.js" tc-start test-output/<STORY_KEY>/parallel/tc-timer-w<n>.json <TC_ID>`, and `tc-end` with the same file. Give no --state and no --story option.
- Print no result tables.

After EACH TC write `test-output/<STORY_KEY>/parallel/worker-<n>.json` in one step: write the whole file as `worker-<n>.json.tmp`, then `mv` it over `worker-<n>.json`. It is a JSON array with one object per finished TC:
{ "tc", "verdict": "PASS|FAIL|NEEDS REVIEW|BLOCKED|SKIP|UNRUN|DEFERRED", "blocked_kind": "other" (see below), "reason" (one line), "actual" (the Actual Result cell, no pipe character), "start", "end" (the time stamps above), "screenshots": [paths as saved], "selectors": [...], "routes": { "<route-key>": "<url>" }, "notes", "user_setting_write": true (only when a step of this TC switched a saved per-user setting such as a Card/Table view, a language or a filter; say what in `notes`; otherwise leave it out) }
`blocked_kind` is `other` only for a host-guard stop, a third-party portal and a ticket-level precondition that is not confirmed. Any other BLOCKED (missing data, unmet precondition, a failed TC it depends on, a 404, 500 or blank page, no matching control, a timeout) leaves `blocked_kind` out: shared data or the load of several browsers can cause those, so the coordinator re-runs them alone.
Your final reply is at most 5 lines: how many TCs ended in each verdict and the file path.
```

**Wait and live view.** Right before you send the calls, print this line with the absolute plugin path, for a tester who wants the same table in a second terminal: `Live view (second terminal): node "<ROOT>/skills/test-ticket/scripts/parallel-split.js" progress test-output/<STORY_KEY>/parallel --watch`. Right after the calls, start the live view in this session with `Monitor` (`description`: `live rows from the workers`, `timeout_ms`: `600000`, `command`: that same `node … progress … --watch` command). It prints one line per event: a row per finished TC (`| TC | Worker | Result | Time taken | Pending |`), or a `↳` reason line under a verdict that is not PASS, and it ends with `All worker TCs are in` when every worker TC has an entry. Ignore its two header lines. On each event print the Step 3h running table ([Progress Reporting](progress-reporting.md)) with a `Worker` column added: one row per TC finished so far, `Pending` as the script gives it, and each reason as `↳ <TC_ID>: <reason>` under the table. Then wait: do nothing else in this session, because worker 1 is using its browser, and let the next event or completion notice resume you. The Monitor runs 10 minutes. When it expires, start it again if a new row appeared during those 10 minutes (it lists every finished row from the top, so show only the rows you have not shown yet); if none did and a worker's completion notice is still missing, that worker is silent. Read-only.

Start Step 6 only when a completion notice has arrived for every worker and the watch has ended with `All worker TCs are in` (or `parallel-split.js status` shows every worker TC with an entry). A silent worker (no completion notice by `deadline`, or the 10-minute case above): go to Step 6, its TCs without an entry run alone. A worker that waits on a permission prompt it cannot answer never finishes, so its notice never arrives and no row appears for it. Whether workers can use Bash, Write and the browser tools unprompted is part of the first live trial.

## 6. Check what came back

Only after the wait in section 5. A worker's reply is a claim, not proof. Read the files.

1. From the project root (the `screenshots` paths are relative to it):
   ```bash
   node "$CLAUDE_PLUGIN_ROOT/skills/test-ticket/scripts/parallel-split.js" verify test-output/<STORY_KEY>/parallel/plan.json test-output/<STORY_KEY>/parallel/worker-1.json [worker-2.json] > test-output/<STORY_KEY>/parallel/verify.json
   ```
   Name every worker file, whether or not it exists. The script checks that each verdict's screenshots are on disk and were saved during that TC (an old file of the same name is no evidence), ignores a worker file older than the plan (a leftover) and counts a missing or truncated file as unrun TCs. A worker that errored or went silent is not dispatched again: its TCs go to the solo queue. Exit 2 means `plan.json` itself is unreadable: run every TC of the plan sequentially.
2. Close the worker browser first (`browser_close` on `-w2`): its worker is done and nothing needs that browser any more. `keep` = verdicts that stand. `rerun` = TCs that need a solo run, each with a reason: `non-pass` (FAIL or NEEDS REVIEW), `blocked-data` (any BLOCKED except the three `other` kinds, timeouts included), `unrun` and `deferred` (with the worker's reason), `no-result`, `no-evidence` (a verdict without screenshots saved during it), `skip-by-worker`, `unknown-verdict` (a verdict word the script does not know), `dependency-of:<TC>` (a TC whose data a re-run TC needs) `overlap:<TC>` (a PASS that read data another worker was changing in the same minutes or the two minutes before it) and `user-setting` (a PASS whose notes say the TC switched a saved per-user setting such as the Card/Table view, or whose entry has `user_setting_write`: two browsers on one login overwrite it, so it runs again alone and that result is final). A kept BLOCKED is only a host-guard stop, a third-party portal or an unconfirmed ticket-level precondition.
3. Print the Step 3h running table with a row for every kept TC (time taken from `start`/`end`; `Pending` counts down in the order the TCs finished), then one line per rerun TC: `↳ TC_07 → solo run (overlap:TC_12)`. Log `[parallel] workers done — <kept> kept, <rerun> to run alone, <serial> run alone by plan`.
4. A worker that stopped with `early-abort` is the same signal as Step 3c's early abort. Before the solo phase print that step's prompt (`⚠️ 3 consecutive High-risk failures — possible environment issue. Continue remaining <n> tests? (yes / no)`); on `no`, stop here and continue as a user-stopped run.
5. Read each entry's `notes`. A worthwhile extra check becomes an EXTRA test case in the solo phase (3i).
6. Run `state … phase=verified`.
7. The worker browser was closed in step 2; if `-w2` is still open for any reason, close it now.
8. Reset this session's browser, which worker 1 used and may have left anywhere: `browser_snapshot`; a dialog → `browser_handle_dialog`; extra tabs → close them with `browser_tabs`; then `browser_navigate` to the base URL. A login page means the workers' session was lost (every worker reporting `UNRUN` with reason `login` says the same): log in again as Step 2 describes, and log `[parallel] session lost during the workers' run`. The solo phase does not start on a login page.

## 7. Solo phase

First enable the flags that Step 2e found disabled and that a queued TC needs (its Proactive Detection step 4, including writing the flags file before the toggle), unless `state.json` already says `flags_enabled`, then run `state … flags_enabled=true phase=solo`. Then run `serial_queue` from `verify.json` in this session and browser with the normal loop: Steps 3a–3i for each TC as written, so a failed TC gets its 3 attempts, EXTRA test cases are allowed, and the flag and permission checks run here. 3i-2, 3j and 3k run once at the merge, not per TC. The solo result replaces the worker's verdict and screenshots. Log `[parallel] <TC_ID> worker: <verdict> → solo: <verdict> (<reason>)`.

Keep `solo-results.json` in the parallel folder current so that a resume knows what is done: a JSON array with the shape of a worker entry plus `attempts`, written as `.tmp` and then `mv`-ed over it. Write a TC's entry with `"verdict": "RUNNING"` before it starts and replace it when it ends; `status` then reports a TC that was interrupted, and its leftover `QA-AUTO-…R-` data must be torn down before it runs again.

Data a solo run creates for a TC a worker already attempted is named `QA-AUTO-<STORY_KEY>-<TC_ID>R-…`, so leftovers of the worker's attempt cannot collide with it. The run budget and early abort of Step 3c keep counting from the start of Step 3; when the budget is already used up, the queue is marked `BLOCKED (run budget exhausted)` as 3c says.

## 8. Merge and continue

Combine the kept worker verdicts (`keep` in `verify.json`, the details in the worker files) and the solo verdicts (`solo-results.json`) in the TC table's original order. When worker 2 ran on another host (`worker2_url` on a different host than `base_url`), start the Actual Result of each of its kept TCs with `(ran on <host2>)` and add one line to the results comment's Preconditions cell: `Worker 2 ran <n> TCs on <host2>`. Before writing anything run `node "$CLAUDE_PLUGIN_ROOT/skills/test-ticket/scripts/parallel-split.js" merge-check test-output/<STORY_KEY>/parallel/plan.json test-output/<STORY_KEY>/parallel/verify.json test-output/<STORY_KEY>/parallel/solo-results.json`: `ok: false` (exit 3) names the TCs that have no final verdict in `missing` (a solo entry still `RUNNING` counts as missing). Run each of them now, alone, then run the check again; write the results only when it says `ok: true`. Write `execution-log.json` and `results.md` as Step 5 says (selectors from the worker entries and the solo runs), and merge every worker's `routes` into the in-memory navigation cache before its Step 5 write. Then continue unchanged: the retest cross-reference of 3c, 3i-2 (every High-risk PASS, including workers'), 3j, 3k (re-read the Jira table; a missing TC runs now, alone), Step 5 and on. Once Step 5's files are written, run `state … phase=merged`: a compaction after this point resumes at the post, not at the merge.

After Step 7 run `state … phase=done`, then move the folder out of the way so that no later run of this story mistakes it for its own: `rm -rf test-output/<STORY_KEY>/parallel-last && mv test-output/<STORY_KEY>/parallel test-output/<STORY_KEY>/parallel-last`.

## Limits

- Which group a TC belongs to is the model's reading of its text. A TC filed under the wrong group that still passes and is not caught by the overlap check could pass wrongly. Unsure → `serial` is the guard.
- Windows are headed by default: two Chrome windows open (worker 1's is this session's own browser). Leave them alone during the run; both are closed when it ends ([Browser Close](browser-close.md)). A headless setting (`QA_ENGINEER_PLAYWRIGHT_EXTRA_ARGS=--headless`) exists only for the bundled server and changes the default page size; the worker browser is always headed.
- The plugin ships one worker browser, so a run has two workers at most, typically about 1.5x faster than a sequential run (an estimate, not measured). A third browser would need another server that the managed MCP allowlist permits.
- The worker browser gets the login by `setStorageState` from a file. Cookies and local storage carry over; session storage and IndexedDB do not, so an app that keeps its login there shows the login form and the worker reports `UNRUN` (`login`).
- A second login splits `user_scoped` TCs only when it is another user or another concern: the same user in a second browser would share the saved setting. On another concern only a PASS stands and the results keep the ticket's own Concern; the data and flags of that tenant decide what worker 2 can do, so missing data comes back as `UNRUN` and runs alone here.
- A browser that someone closes comes back empty at the next tool call (checked on an isolated server: no error, an `about:blank` page and no cookies). Worker 1's keeps its login because its profile is on disk. The worker browser loses it, and the restore in the brief puts it back once. A TC cut off by this ends as `UNRUN` and the coordinator re-runs it alone.
- Resuming never repeats sections 3 to 5 once workers have written anything: that would clear their files. `status` decides, from the files, which section is next.
- A run that fell back to sequential before the split ran (checks 1 to 4 in section 1) has no saved progress, like any run without `--workers`.
- `--retest` always runs sequentially (`[parallel] sequential run — scoped retest`): its stop rule needs the serial order ([Scoped Retest](scoped-retest.md)).
- Run metrics keep recording `execution_mode: inline`.
