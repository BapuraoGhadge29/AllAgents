# Precondition Evidence (Ticket-Level Dependency Verification)

<!-- ⚠️ MUST KEEP IN SYNC with the "Precondition Evidence Check" procedure in test-ticket/references/phase-3a-execution.md — same detection signals, same automated-check + manual-gate tiering, same evidence shape. execute-tests has no Jira Phase 1 step, so detection here scans the ticket's `description`/`comment`/`issuelinks` directly instead of `story.preconditions`. Both skills are self-contained — prompt-based skills cannot import each other's steps at runtime. -->

**Why this exists:** some tickets depend on a companion ticket, PR, or fix being deployed to the environment before any TC can be meaningfully tested — not a per-TC data precondition (see [Test Data Setup](test-data-setup.md)), a ticket-level one. Confirmed necessary (MXTS-79013, Sep 2026): the ticket shipped once ("closest level wins"), QA found a real failure, the dev corrected the algorithm ("date-valid union", a superseding PR) and that correction had to reach the test environment before retesting meant anything — but nothing in the pipeline's own output ever recorded that the correction was confirmed live *before* the retest ran. A test run that passes without ever evidencing its own precondition proves nothing.

## Proactive Detection (runs once, before Step 3's per-TC loop — before Test Data Setup and Feature Flag Check, so an unconfirmed precondition blocks the story before either spends any effort)

Scan the Jira `description` and every comment (already fetched in Step 1 — its `fields` list includes `description` and `issuelinks` for exactly this) for ticket-level precondition signals:

1. A `Dependencies` / `Blocked by` section in the description — extract every ticket key (`[A-Z]{2,}-[0-9]+`) it names.
2. `issuelinks` entries of type "is blocked by" — extract the linked ticket key directly, no text parsing needed.
3. Comment language naming a required prior deployment — phrasing like "must be deployed/shipped first", "supersedes", "before testing/QA can verify", "pending deploy", or a design correction/revision to an already-tested behaviour ("rev 2", "corrected design") — paired with a ticket key or PR reference where one is present in the same comment.

Build `detected_preconditions` — one entry per distinct signal: `{ description: <one-line summary>, linked_ticket: <key or null> }`. **No signal found → stays empty.** This is expected for most tickets; only a minority carry a ticket-level (not per-TC) precondition.

Log: `[Precondition] Detection complete — <n> found.` (or skip the log line entirely when `detected_preconditions` is empty — nothing to report).

## Verification (once per entry, before Step 3)

For each entry in `detected_preconditions`:

1. **`linked_ticket` is set** → call `getJiraIssue` on it (`fields: ["status"]`).
   - Status is done-like (`Done`, `Closed`, `Checked by QA`, `Resolved`, or `statusCategory` = `Done`) → **confirmed automatically**. Log `[Precondition] <linked_ticket>: <status> — confirmed before this run.`
   - Not done-like → a ticket's own status can lag reality — a merged PR routinely outruns its ticket's transition (MXTS-79013 sat "pending QA verification; status not transitioned" for days after merge). This does **not** mean the precondition is unmet, only that the automated check can't confirm it — fall through to the manual gate below.
2. **No `linked_ticket`, or the automated check above didn't confirm** → manual gate. Ask the tester:
   ```
   Precondition: "<description>"<, dependency <linked_ticket> currently <status>, if applicable> — confirmed satisfied on <base URL>? (yes/no)
   ```
   - `yes` → log `[Precondition] "<description>" — confirmed by tester before this run.`
   - `no` → not confirmed.
   - **`--unattended`** → skip the prompt entirely; default to **not confirmed** (fail closed — same convention as every other uncertain-verdict rule in this pipeline; never assume "yes" just because no one was there to ask). Log `[Precondition] "<description>" — unattended mode, no tester confirmation available; treating as not confirmed.`

## Evidence (write before Step 3, regardless of outcome — this is the audit trail)

Write `test-output/<STORY_KEY>/preconditions-verified.json` (array, one entry per `detected_preconditions` item, overwritten fresh each run so a retest re-evidences rather than trusting a stale file):

```json
[
  {
    "description": "Rev 2 fix (date-valid union) must be deployed before retest",
    "linked_ticket": "MXTS-79012",
    "status_at_check": "Checked by QA",
    "confirmed": true,
    "confirmed_by": "automated",
    "confirmed_at": "2026-09-21T08:30:00Z"
  }
]
```

`confirmed_by` is one of `automated` / `tester` / `unattended-default`.

## Not confirmed → block

Any entry with `confirmed: false` blocks **every TC in this run** — a ticket-level precondition has no reliable per-TC attribution to narrow the blast radius the way a data precondition does. Mark each TC `BLOCKED 🚫 (precondition not confirmed: "<description>")` and skip straight to the results table — do not attempt any TC. Log: `[Precondition] "<description>" not confirmed — all TCs blocked.`

## Results comment (Step 6c)

Add one `Preconditions` row to the stats block, summarizing every entry from `preconditions-verified.json`, semicolon-joined:

- `MXTS-79012: Checked by QA ✅ (confirmed 2026-09-21T08:30Z)` — automated confirmation
- `"rev 2 fix deployed" ✅ (tester-confirmed 2026-09-21T08:30Z)` — manual confirmation
- `⚠️ "rev 2 fix deployed" — NOT CONFIRMED` — unresolved (the run's TCs are BLOCKED as a result; this row is why)

No entries detected → `None detected`.
