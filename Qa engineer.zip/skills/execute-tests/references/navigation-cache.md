# Navigation Cache

Persists discovered page URLs across runs and stories so future runs can navigate directly to feature pages instead of clicking through the sidebar every time. Gets faster the more this skill (or `/test-ticket`) is used against the same environment.

**Cache file:** `test-output/nav-cache.json` — shared across all stories, Epics, and tickets (this is the same file `/test-ticket`'s Phase 3a writes; running either skill against this environment improves both). Created on first run; updated after every run.

Route key = URL path after `#/`, trailing slash stripped — e.g. `https://mqa-dev.maxxton.net/#/reservations/list` → key `reservations/list`.

```json
{
  "mqa-dev.maxxton.net": {
    "reservations": { "url": "https://mqa-dev.maxxton.net/#/reservations", "last_verified": "2026-06-23" }
  },
  "_meta": { "run_count": 7, "last_updated": "2026-06-23", "max_entries": 200 }
}
```

**Load (right after Step 2 Login, before Step 2b):**
1. Read `test-output/nav-cache.json`. Missing → start with an empty cache (no error).
2. Invalid JSON → start empty, log `[Cache] nav-cache.json corrupted — starting fresh.` Never crash or block execution over this.
3. Keep the valid cache in memory as `nav_cache[<hostname>]`.

**Per-TC navigation — cache-first (applies to Step 3e's "navigate / go to / open" steps):**
1. Infer the target route key from the TC scenario text (e.g. "Verify reservation is created" → `reservations`).
2. Check `nav_cache[<hostname>][<route-key>]`:
   - **Not cached** → sidebar navigation as normal. After landing on the correct page, record the URL + today's date. Log: `[Cache] Nav miss — discovered <url>, cached for next run.`
   - **Cached, `last_verified` ≤ 30 days ago** → `browser_navigate(<cached_url>)` directly. Log: `[Cache] Nav hit — <route-key> → <url>`
   - **Cached, `last_verified` > 30 days ago** → navigate to the cached URL, then run the sanity check below (soft-stale). Log: `[Cache] Nav stale — re-verifying <route-key>.`
3. **Post-navigate sanity check (cache hits only):** after `browser_navigate`, check the resulting URL/page title actually matches the route key. Mismatch → fall back to sidebar navigation immediately, update the cache with the correct URL. Log: `[Cache] Nav hit led to wrong page — invalidated <route-key>, re-discovered.` Never retry a cached URL that led to the wrong page.

**Eviction:** before writing, if a hostname's entry count exceeds 200 route keys, evict the oldest `last_verified` entries down to 200.

**`--clear-nav-cache` flag:** delete `test-output/nav-cache.json` before loading (use after a major app restructure where routes changed). Log: `[Cache] nav-cache.json cleared by --clear-nav-cache flag.`

**Write (immediately after `execution-log.json` in Step 5) — under an exclusive lock, never a blind overwrite.** This file is shared across every concurrent story/ticket run against the same repo (that's the whole point of it). A re-read-then-write without a lock still loses updates: two sessions can both read the same fresh copy before either writes, merge their own dirty entries onto it, and the second write erases the first session's routes. Only a real mutual-exclusion lock around the whole read-merge-write closes that gap.

**Acquire the lock** — `test-output/nav-cache.lock/` is a *directory*, not a file: creating a directory is atomic on both Windows and POSIX, so two sessions racing to create it can never both succeed.
1. Try to create it (Bash: `mkdir "test-output/nav-cache.lock" 2>/dev/null && echo acquired`; PowerShell: `New-Item -ItemType Directory -Path "test-output/nav-cache.lock" -ErrorAction SilentlyContinue`). Succeeded (it did not already exist) → lock held, go to step 4.
2. Already exists → check its age. Older than 15 seconds → an abandoned lock from a crashed session; remove it and retry step 1 once. 15 seconds or younger → another session is actively writing; wait ~500ms and retry step 1.
3. **Give up after ~10 seconds of retrying** (~20 attempts) rather than block this run indefinitely on a stuck lock — but do NOT fall through to steps 4–9 without the lock; that would be the exact unprotected read-merge-write the lock exists to prevent. **Skip the cache write entirely for this run instead** — this run's own newly-discovered routes are lost for next time (a speed regression only, `browser_navigate` still worked fine via the sidebar this run), never a correctness problem, and never worth risking another session's already-recorded routes to save. Log: `[Cache] Could not acquire nav-cache.lock after 10s — skipping this run's cache write (routes discovered this run will not be persisted).` Do not retry further and do not proceed to step 4.

**Only once the lock is actually held:**
4. Track only the route keys *this run itself* discovered or re-verified this session as a small "dirty" set, not the whole in-memory cache.
5. Read `test-output/nav-cache.json` from disk again, fresh, right now (missing/corrupt → treat as empty, same as Load).
6. Merge this run's dirty set onto that fresh read — only the specific `[hostname][route-key]` entries this run touched get overwritten; every other route already on disk (written by any other session) is kept as-is.
7. Apply eviction on the merged result if needed.
8. Increment `_meta.run_count` on the merged result.
9. Write the merged result back.

**Release the lock immediately after** (Bash: `rmdir "test-output/nav-cache.lock"`; PowerShell: `Remove-Item "test-output/nav-cache.lock" -Force`) — attempt this even if a step above errored, so a genuine failure never leaves a stale lock for the next run to wait out.

Log: `[Cache] Nav cache updated — <n> routes for <hostname>.`
