# Missing-Field API Cross-Check

Runs once per TC, on the **final attempt**, when the Expected Result says a field, column or element is shown and it is clearly absent from the UI — right before `FAIL` is recorded. It does not change the verdict: it adds evidence of **which side** is missing it, so the developer starts on the right one.

Not for a negative assertion ("is hidden", "is not shown"), and it comes after the paths that already explain an absence: the Known-Limitation `SKIP`, the Reactive Feature Flag Check and a permission toggle.

**Why:** a field that is not on screen is either not sent by the backend or sent and not rendered by the frontend. Both used to end as the same `FAIL`, and the Jira comment gave no hint which one it was.

**Procedure (at most 3 extra tool calls, counted in the TC's time):**
1. `browser_network_requests` — pick the request that loaded the data of the screen the field belongs to: the XHR/fetch after the navigation, whose path names the entity (reservations, customers, invoices, …). When two requests fit, take the one whose response is largest.
2. `browser_network_request(index, part: "response-body")` — look through the whole JSON, at every depth, for the field's key. Take the key name from the ticket, the linked PR diff (Phase 1 step 3g) or the TC text, and also try its camelCase, snake_case and plural/singular forms (label "Awaiting check-in" → `awaitingCheckIn`, `awaiting_check_in`).
3. Write it into the TC's Actual Result, after the observation:
   - `API response (GET /api/<path with ids as {id}>) contains "<key>" — the field is sent but not shown.`
   - `API response (GET /api/<path with ids as {id}>) does not contain "<key>" — the field is not sent (backend, a feature flag or a permission).`
   - `API response not checked (<reason: no matching request / response is not JSON / field key unknown>).`
4. Never put a value from the response in the comment — only the path pattern and the key, so no customer data reaches Jira. Apply the sanitising of the Debug Evidence Capture (no tokens or cookies, no `|`).

The verdict stays `FAIL` (after the usual retries). A contained-but-not-shown field points to the frontend; a missing one points to the backend, a flag or a permission — the Phase 4 triage can use the sentence as a classification hint.
