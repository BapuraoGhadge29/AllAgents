# Split Results Comment (more than 45 TC rows)

Jira rejects a comment over 32,767 characters. A results table of more than 45 TC rows is therefore posted as several comments (parts) instead of one. **45 TC rows or fewer → post one comment exactly as Step 6c says and ignore this file.** EXTRA rows do not count toward the 45; they go in the last part.

The scripts live in the `test-ticket` skill of this plugin and are called through `${CLAUDE_PLUGIN_ROOT}`; they need no credentials and no Jira call.

## 1. Plan once and save it

Write the TC_IDs that have a verdict (never the EXTRA ids), in table order, one per line to a temp file, then:

```bash
node "${CLAUDE_PLUGIN_ROOT}/skills/test-ticket/scripts/result-parts.js" plan --ids-file <ids.txt>
```

`"split": false` → one comment, stop reading. `"split": true` → save `{ "planned_at": "<ISO now>", "parts": <the printed parts array> }` to `test-output/<STORY_KEY>/result-parts.json` **before posting anything**. The file already exists (resume) → reuse it, never plan again. Rule: parts of at most 40 rows in TC order; a last part under 10 rows is rebalanced with the one before it (60 → 40 + 20, 46 → 23 + 23).

## 2. Build and validate every part before posting part 1

For part `n` of `m`, build the normal Step 6c body with these differences only:

- The first non-empty line after the header is exactly `_Part n of m_` (any other form or position is rejected).
- The TC table holds only this part's `tc_ids`; the stats table (Total TCs, Passed, Failed, Blocked, Needs Review, Skipped, Pass rate) counts only this part's TCs. Build / Version, Preconditions and QA Pipeline Version are the same in every part.
- EXTRA rows only in the last part.

Validate each part (save the body with the Write tool, read it back only with the Read tool):

```bash
node "${CLAUDE_PLUGIN_ROOT}/skills/test-ticket/scripts/validate-results-comment.js" <body_file> --kind exec --story <STORY_KEY> --part n/m --tc-ids TC_01,TC_02,…
```

Exit 1 → rebuild from the template it prints. A part over 32,000 characters fails with `CHECK 15`: re-plan with `plan … --batch 30`, replace `result-parts.json`, rebuild. Because every part is checked before part 1 is posted, this is safe; once any part is posted the plan is frozen.

## 3. Post the parts in order

For each part without a `comment_id` (the comment target lock of Step 6 applies: only `<STORY_KEY>`):

1. **Duplicate guard:** `listJiraIssueComments` on `<STORY_KEY>`; a comment whose first line is `## QA Test Results — <STORY_KEY>` and that carries this part's `_Part n of m_` line, created at or after `planned_at`, is this part (a crash happened before the id was saved) → record its id and do not post again.
2. Otherwise `addOrEditJiraIssueComment` with the validated body, then save the returned id as the part's `comment_id` in `result-parts.json` immediately.
3. A part that fails after one retry stops the run of posts: do not post later parts, report which parts are posted, and a re-run resumes at the first part without an id.

## 4. Reconcile

After the last part, read the posted part comments back (`listJiraIssueComments`), save each part's body to a temp file in part order, write the `parts` array of `result-parts.json` to `parts.json`, and run:

```bash
node "${CLAUDE_PLUGIN_ROOT}/skills/test-ticket/scripts/result-parts.js" reconcile --plan parts.json --body-file <part1> --body-file <part2>
```

It must print `OK — <n> TC(s) across <m> part(s), each exactly once.` Anything else means a TC is missing or doubled in Jira: report it in the Step 7 message. `--retest` starts a new plan (delete `result-parts.json`); the earlier comments stay in Jira as history.
