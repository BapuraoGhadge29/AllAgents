# Host Guard

The environment check in `/test-ticket` pre-flight only looks at the URL the user typed. A dev site can still end up on a production host after the browser starts — a prod→dev database sync can leave a site bound to its live hostname, so a "Login" button, a redirect, or a link opens production. This guard closes that gap for both `/execute-tests` and `/test-ticket`: the browser must stay on dev/test hosts for the whole run, not just at the start.

## Allowed hosts

A host is **allowed** when it matches `*-dev.maxxton.net` or `*-test.maxxton.net` (any concern, MXTS or MCMS, including the SSO host `login-dev.maxxton.net`). No other pattern is allowed — in particular not `-qa.` hosts and not any host without `-dev` / `-test` in its name.

## Where it runs

1. **Standalone `/execute-tests` base URL (once, in Step 1, before any browser call).** Same hard stop as `/test-ticket` pre-flight: a base URL whose host is not allowed → stop immediately, no prompt, no override:
   ```
   ⛔ <URL> is not a dev/test environment (*-dev.maxxton.net / *-test.maxxton.net only). Execution runs against dev/test only — re-run with a dev or test URL.
   ```
   Do not call any Playwright tool and do not mark any TC.
2. **After every `browser_navigate` and after every click, key press or submit that can change the page URL** (a link, a menu item, a Login/Save button, a redirect). Read the current URL from the next `browser_snapshot` (already required after each step) and take its host. No extra browser call is needed — the snapshot you already take carries the URL.

## When the host is not allowed

1. **Stop interacting.** Do not click, type, select, upload or submit on that page. Reading it (snapshot, screenshot) is fine.
2. Take the result screenshot of what the browser landed on (it is the evidence), then navigate back to the last allowed URL (`browser_navigate_back`, or `browser_navigate` to the base URL if back does not land on an allowed host).
3. Record the TC as `BLOCKED 🚫 (browser left dev/test — landed on <host>)`. Never `FAIL` (it is not a product verdict) and never retry the click that caused it.
4. Log: `[HostGuard] <TC_ID> — navigation led to <host>, not a dev/test host. Stopped; no action taken there.` and run `node "$CLAUDE_PLUGIN_ROOT/skills/test-ticket/scripts/run-metrics.js" event <metrics dir> host_guard_stop` (see [Run Metrics](run-metrics.md)).
5. Surface it in the final report under ACTION REQUIRED: `⚠️ <TC_ID> navigated to <host> (not dev/test). If this was a site bound to a production hostname, fix the site host in the webmanager before re-running — do not follow the link.`

## Exception — a third-party hop the TC itself names

A TC's own steps can legitimately leave the Maxxton hosts — a payment provider's hosted test page, the SSO provider. When the TC's Steps or Expected Result **explicitly name** that provider or host, it is allowed to *observe and complete that named step only*, then it must return to an allowed host. Log `[HostGuard] <TC_ID> — third-party hop to <host> (named in the TC).` and run the metrics event `host_guard_third_party`. A third-party host the TC does **not** name is treated exactly like any other disallowed host above. A Maxxton-owned host (`*.maxxton.net`, `*.maxxton.com`) that is not `-dev` / `-test` is never covered by this exception.

## Why it fails closed

Unknown → disallowed. The only cost of a false stop is one BLOCKED TC with a clear reason and an obvious fix; the cost of a false allow is a write against production data.
