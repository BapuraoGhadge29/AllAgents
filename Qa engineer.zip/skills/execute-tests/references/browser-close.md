# Browser Close

Shared by `/execute-tests` (after Step 6e) and `/test-ticket` (in the Final Summary, after its feature flag teardown). When the live run is over, close the browsers it opened so that no Chrome window is left behind.

1. **When.** Last of all: after the feature flag teardown, which navigates to Maxxton Admin and so still needs the browser. Make no browser call after the close: any later call opens a fresh, empty browser.
2. **What to close.**
   - This session's own Playwright browser, with the `browser_close` tool of the server used all run: `mcp__plugin_qa-engineer_playwright__browser_close`, or the `mcp__playwright__` / `mcp__playwright-headed__` equivalent when the run used one of those.
   - The second worker browser, `mcp__plugin_qa-engineer_playwright-w2__browser_close`, when parallel mode opened it and it is still open. Step 6 of the parallel reference closes it after the workers; skip it then.
3. **Which exits.** Every way the run ends once a browser was opened: normal completion, a run the tester stops, an early abort, an error, a connector outage. Do it before the last message each of those prints. Nothing to close when no browser was opened (Generation only, a run that stopped before its first browser call).
4. **Only these browsers.** The Playwright MCP servers' own browsers. Never end Chrome processes or close windows by any other means: the tester's own Chrome windows are not ours.
5. **If the close call fails**, say so in one line in the run summary (`Could not close the browser: <error>`) and carry on. A failed close never fails the run.
