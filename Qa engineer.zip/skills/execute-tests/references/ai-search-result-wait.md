# Search Result Wait (mandatory after ANY search or filter submit — AI search and normal search/filter alike)

<!-- Single source of truth shared by execute-tests and test-ticket (test-ticket references it via ${CLAUDE_PLUGIN_ROOT}). Do NOT mirror or copy it. -->

The generic Page-ready wait cannot see a search finish. Two modes share one script: `mode: 'ai'` (the "Find reservations in the system" bar — model latency, optional clarification) and `mode: 'search'` (the normal search box and filter panel). Measured live (SAN dev, Reservation Manager):
- `reservations with postcode 1234AB` — after submit the page sits unchanged for ~2.7 s while the model runs (old total `526,917`, no chip, no spinner). The chip appears at ~2.7 s, the total changes at ~3.1 s (to a legitimate `0`).
- `reservation set krim` — the first answer is not a result but a **clarification question**: "Which resort did you mean?" with numbered options. Total, chips and URL are all unchanged. After an option is clicked the question disappears within ~0.25 s, yet the total and the `resortIds` filter only change ~3.2 s later.

- **Normal search** — typing `Hoeks` with slow typing finished at ~0.9 s; the URL `searchQueries` parameter and the total (`527,681` → `104`) changed together ~2.4 s after the last keystroke (debounce + request); no chip appears for a text search. Reading, screenshotting or clearing inside that window sees the old list.

A DOM-stability wait returns `ready` inside any of these quiet windows, so a reload, reset, next repeat run or screenshot lands on the old count. A wait that only watches count/chip/URL reports "no answer" on a clarification. The AI search is a two-stage flow: submit → (optional clarification → pick) → result.

**1. Baseline before submit.** Wait until `Total reservations` is non-zero and unchanged for 2 polls (a freshly loaded search page shows a transient `0` — never use it as the baseline). Record the chip texts and the `reservation-search-filter` URL parameter (`browser_evaluate`: `() => ({ chips: Array.from(document.querySelectorAll('mat-chip, .mat-mdc-chip')).map(e => e.innerText.trim()).join('|'), filter: new URLSearchParams(location.search).get('reservation-search-filter') })`) and paste them, plus `mode`, into the `BASELINE` literal of step 2. **The baseline must be clean:** no chip left from an earlier run, no no-match callout, no "no results" text and no clarification question visible. If any is present (repeat runs, a reset that did not clear), reset by navigating to the base URL and re-baseline — otherwise an identical result looks like "no signal" and a stale callout looks like an instant answer.

**2. Submit, then wait — `browser_evaluate`, not `browser_wait_for`.** The result signal is a chip change, a `reservation-search-filter` change (that one parameter is a JSON object that also carries `searchQueries` and `resortIds`, so comparing it covers normal text search and clarification picks), a no-match callout (`ai`) or a "no results" text (`search`). A bare change of the total is NOT a signal — dev data is live (the total drifted `526,917` → `526,918` between two runs); the total is only used to see that the page has stopped moving, and it must be unchanged for 5 polls (~1 s) after the signal — measured live, the total lands ~0.4 s after the chip, so a shorter window returns the old total. Call this after the submit and again after every clarification pick (re-record the baseline right before the pick, because the question disappearing is not a result):

```js
async () => {
  const BASELINE = { mode: 'ai', chips: '', filter: null }; // paste the values from step 1 here before running — `browser_evaluate` passes no arguments; mode is 'ai' or 'search'
  const { mode, chips, filter } = BASELINE;
  const ai = mode === 'ai';
  const readCount = () => (document.body.innerText.match(/Total reservations:\s*([\d.,]+)/) || [])[1];
  const readChips = () => Array.from(document.querySelectorAll('mat-chip, .mat-mdc-chip')).map(e => e.innerText.trim()).join('|');
  const readFilter = () => new URLSearchParams(location.search).get('reservation-search-filter');
  const callout = () => /couldn.t find a way to search|could not resolve|no units available/i.test(document.body.innerText);
  const noResults = () => /no results found|no reservations found|nothing found/i.test(document.body.innerText);
  const questionEl = () => Array.from(document.querySelectorAll('*')).find(e => e.children.length === 0 && e.offsetParent !== null && (e.textContent || '').length < 120 && e.parentElement?.parentElement && /did you mean|do you mean/i.test(e.textContent || ''));
  const loading = () => Array.from(document.querySelectorAll('mat-progress-bar, mat-progress-spinner, [class*="loading"]:not([class*="not-visible"]):not([class*="hidden"])')).some(e => e.offsetParent !== null);
  const deadline = Date.now() + (ai ? 60000 : 20000);
  let kind = null, last = null, stable = 0, sawLoading = false;
  while (Date.now() < deadline) {
    const c = readCount(), q = ai ? questionEl() : null;
    if (loading()) sawLoading = true;
    const changed = (ai ? callout() : noResults()) || readChips() !== chips || readFilter() !== filter;
    const now = changed ? 'result' : q ? 'clarification' : null;
    if (now !== kind) { kind = now; last = null; stable = 0; }
    if (kind) {
      const sig = c + '|' + (q ? q.parentElement.parentElement.innerText : '');
      stable = (sig === last && !loading()) ? stable + 1 : 0;
      last = sig;
      if (stable >= 5) return kind === 'clarification'
        ? { result: 'clarification', question: q.textContent.trim(), options: q.parentElement.parentElement.innerText.slice(0, 400) }
        : { result: 'settled', count: c, callout: ai && callout() };
    }
    await new Promise(r => setTimeout(r, 200));
  }
  if (!ai && !kind && sawLoading && !loading()) return { result: 'settled-unchanged', count: readCount() };   // the app's own loading indicator came and went but nothing visible changed: the search legitimately returned the same list
  return { result: kind ? 'timeout-after-signal' : 'timeout-no-signal', count: readCount() };
}
```


**3. Never touch the page until step 2 returns.** No `page.reload()`, no navigation, no clearing chips, no next repeat run, no screenshot while the wait is pending. A model call can take 10+ s on a busy environment — the 60 s ceiling exists for that.

**4. Read the outcome.**
- `clarification` → the app asked a question instead of searching. Record the question and its options as evidence. If the TC names the answer (or one option is clearly the intended one), re-record the baseline, click that option, and run step 2 again for the result. If the TC does not say which option to pick, pick the first, log the choice, and say so in the Actual Result. A TC that expects the search to apply directly and gets a clarification question is `FAIL` (or `NEEDS REVIEW` if the TC is ambiguous), not "no result".
- `settled` → run the normal Page-ready wait, take the screenshot, then read the applied chips from a fresh `browser_snapshot` (the script only proves the answer landed, not which chip it is) and judge the result.
- `settled-unchanged` (`search` mode only) → the app's own loading indicator appeared and finished (measured on SAN dev: it shows ~1.1 s to ~1.9 s after the last keystroke) but the list, URL and chips did not change: the search returned the same list as the baseline. Judge the TC on that (e.g. a filter that matches everything); if the TC expected the list to narrow, retry the submit once (re-typing per Search/Filter Input Typing), then `FAIL`.
- `timeout-after-signal` → the outcome appeared but never stopped moving; record what is on screen as `NEEDS REVIEW`.
- `timeout-no-signal` → in `search` mode: no loading indicator and no change within 20 s — the typed text did not trigger a search; verify the field value (Search/Filter Input Typing step 3), retry once, then `FAIL`. In `ai` mode: the AI search never answered. Seen live on SAN dev: roughly 1 in 4 submits of the same prompt got no response at all within 60 s. Check the input still holds the prompt, retry the submit once (the `Go` button, not only Enter); if it still gives no signal, `FAIL` with "AI search returned no result within 60 s".
- A total of `0` after `settled` is a valid result (the chip proves the filter applied), not a failed load.

**5. Repeat runs ("Repeat 3 times").** Record run N's outcome and screenshot first. Only then reset (clear the chip or navigate to the base URL), run the baseline wait of step 1 again, and submit run N+1. Never reset to save time while run N is still pending.
