# Environment-Down Check

Distinguishes "the dev environment is broken" from "the product is broken". A dev concern whose nightly patch failed looks exactly like a product defect from inside the browser: 5xx pages, empty lists, missing data. The Oracle Bot posts every concern's patch status in `#guild-development`; a `:x:` line for the concern under test means that environment is known-broken.

Read-only. This check never writes to Slack and never changes any verdict by itself — it only changes the **reason** recorded and whether defects are proposed.

## Inputs

- **Concern code** — the host prefix before `-dev` / `-test` / `-cms-dev` / `-cms-test` (`rcn-dev.maxxton.net` → `rcn`; `krm-cms-test.maxxton.net` → `krm`). Computed from the run's base URL host (standalone `/triage-defect`: from the `Environment:` line of `results.md`; no such line → skip the check). More than one URL → check each.
- **Channel** — `C06LVM1HKLJ` (`#guild-development`). The check needs the Slack connector with read access to it; without that it is skipped (see `unavailable` below). There is no other switch.

## Procedure

1. Call `mcp__claude_ai_Slack__slack_read_channel` with that channel ID and `limit: 100`. **Never pass an `oldest` argument** — the API then returns the oldest messages first and buries the current ones.
2. From the result keep only messages from the Oracle Bot (`oracle bot` / `Oracle Bot`) posted in the last 24 hours that are patch-status messages (they contain `:x:`, `:warning:` or `:white_check_mark:` lines naming concerns).
3. For the concern code, find its status line in the **newest** such message that names it:
   - `:x:` → **broken** (hard failure; the patch or repair script failed).
   - `:warning:` → warnings, the patch passed. **Not broken** — do not escalate.
   - `:white_check_mark:` or no line at all → **not flagged**.
4. Result: `broken` | `not_flagged` | `unavailable` (the Slack tool is not registered, not authorised, errored, or returned nothing usable). `unavailable` is never an error: log one line `[EnvCheck] Slack unavailable — skipped.`, run the metrics event `health_check_slack_unavailable`, and continue exactly as if the check did not exist.
5. Persist to `run-state.json` per Epic: `env_check: { "checked_at": "<ISO>", "concern": "<code>", "status": "broken|not_flagged|unavailable" }` (standalone: a local variable is enough). Do not re-check the same concern again in the same run.

## Where it is used

| Moment | Effect when `broken` |
|---|---|
| `/test-ticket` Environment Health Check still degraded after its 30-second retry (Phase 3a reference) | Add the cause to the existing mass-block message: `BLOCKED 🚫 (Environment unavailable — Oracle Bot reports <concern> broken, <indicator summary>)`. The run is blocked exactly as before; only the reason is more precise. Run the metrics event `env_flagged_broken`. |
| Phase 4 triage (`/test-ticket`) and `/triage-defect`, before classifying — only when **half or more** of a story's executed TCs ended `FAIL`/`BLOCKED` | Classify those TCs `needs review` with the reason `Environment flagged broken by Oracle Bot (<concern>) — not a confirmed product defect` and propose **no** defects from them in Phase 5. TCs that passed are untouched. If the status is not `broken`, triage runs exactly as before. |

A `not_flagged` or `unavailable` result changes nothing anywhere.

## Never

- Treat `:warning:` as a failure.
- Block a run, or classify a defect as environmental, on a Slack message older than 24 hours.
- Ask the user anything about it. The check is automatic; a missing Slack connector is not an error.
