# Progress Reporting

Three rules for the person watching a run. They live here so SKILL.md stays under the 500-line body limit; test-ticket's Phase 3a carries the same rules (KEEP IN SYNC with its Per-TC Execution Loop Step 0, Step 6 and the `browser_evaluate` rule).

## Short `browser_evaluate` calls

⛔ **Every `browser_evaluate` call is short: at most 60 seconds, and the script bounds itself. Any wait or polling loop inside a script has its own deadline (the Page-ready wait uses 10 s) and returns `'timeout'`, `'pending'` or what it found — it never loops until a condition that may never come true. The per-TC timeout (`--tc-timeout`, default 180 s) is only checked between tool calls, so one runaway call bypasses it and freezes the progress list too (a 19-minute `browser_evaluate` was seen on MXTS-81060, TC_20 setup). A longer wait is repeated short calls — evaluate, decide, evaluate — with the cap counted in wall-clock time.**

## Start the TC timer (Step 3e)

Start the TC timer first: `node "$CLAUDE_PLUGIN_ROOT/skills/test-ticket/scripts/run-timing.js" tc-start test-output/<STORY_KEY>/tc-timer.json <TC_ID>` once per TC (a retry attempt that calls it again keeps the first start). Its `tc-end` is in 3h.

## Show the result after every TC (Step 3h)

**Show the user the running table: every TC finished so far, and what is still pending.** After the final verdict is recorded (retries, the screenshot and the `execution-log.json` write done), run `node "$CLAUDE_PLUGIN_ROOT/skills/test-ticket/scripts/run-timing.js" tc-end test-output/<STORY_KEY>/tc-timer.json <TC_ID>` — it prints how long the TC took as wall-clock time (`/execute-tests` keeps no pause record, so a tester wait inside a TC is included; `n/a` when no timer was running) — and print the table as plain text between tool calls. It is cumulative: each time it holds one row per TC finished so far, in the order they finished, so it grows by one row after every TC:

```
| TC | Result | Time taken | Pending |
|---|---|---|---|
| TC_01 | PASS ✅ | 2m 10s | 2 |
| TC_02 | PASS ✅ | 3m | 1 |
```

`Pending` is the number of this run's TCs not finished yet at the moment that row's TC finished (`N` minus the TCs done then, so the column counts down 2, 1, 0; `N` respects `--max-tcs`, and TCs a `--retest` carries over unchanged are not counted). A printed row never changes. For `FAIL ❌`, `BLOCKED 🚫`, `NEEDS REVIEW 🔍` and `SKIP ⏭️` add, under the table, one line per such TC finished so far: `↳ <TC_ID>: <reason in under 15 words>`, e.g. `↳ TC_07: no matching control; checked: reservation, unit, Housekeeping`. Keep these lines under the table, never between rows, so it stays one table. After the last TC the table printed for it is the final one: add one tally line below it, `Run done — 26 TCs: 20 PASS, 3 FAIL, 2 BLOCKED, 1 NEEDS REVIEW`. One row per TC and only for its final verdict, never one per retry attempt; no file paths; never a customer name or amount from the app; on a multi-URL run put the hostname in front of the TC id (`rcn-dev · TC_01`). The same moment updates the progress list's TC count (when the session has one). This is narration for the person watching: it never replaces the verdict and log writes and never delays the next TC. KEEP IN SYNC with test-ticket's Phase 3a Step 6.
