# Integration Manager Setup (Supplier / Reseller Tickets)

<!-- ⚠️ MUST KEEP IN SYNC with the "Integration Manager Setup" procedure in test-ticket/references/phase-3a-execution.md — same detection, same credential flow, same external-portal boundary. Both skills are self-contained — prompt-based skills cannot import each other's steps at runtime. -->

**Scope decision (2026-09, per QA feedback on Supplier/Reseller pipeline coverage):**
- **Supplier tickets** (test setup → import → verify data landed in Integration Manager / Content Manager (Availability) / Revenue Manager (Rates)) — **in scope**, gated on the credential + polling procedure below.
- **Reseller tickets' internal half** (test setup → export → verify Content/Rates/Reservations) — **in scope**, same procedure.
- **Reseller tickets' external-portal half** (verifying the same export landed correctly on the client's own portal — Booking.com Extranet, Airbnb Developer Portal, etc.) — **permanently out of scope.** This pipeline has no live session capability into a third-party system, and building one is a materially different (and much larger) undertaking than anything else this plugin does — separate auth, separate ToS, separate security review. Never attempt it; see "External Portal Boundary" below for the exact verdict a TC needing this gets.

## Detection (Proactive — runs once, before Step 3's per-TC loop)

Scan the ticket's summary, description, and comments for Integration Manager language: "Supplier", "Reseller", "Integration Manager", a named third-party system (e.g. "MaxxtonLink", "Booking.com", "Airbnb", "Expedia"), or an import/export job. Found → extract the specific integration name (`integration_name` — e.g. "MaxxtonLink", "BookingCom"). Not found → skip this whole file; the ticket isn't an Integration Manager ticket.

**Ambiguous or multiple candidates named:**
- Normal run → ask the tester once: `Which integration does this ticket test — <candidate list>?`
- `--unattended` → skip the prompt (fail closed, same convention as [Precondition Evidence](precondition-evidence.md)'s manual gate). Leave `integration_name` unresolved, log `[IntegrationSetup] Ambiguous integration ("<candidate list>") — unattended mode, no tester available to disambiguate.`, and mark every TC whose own steps/preconditions explicitly name Integration Manager setup `BLOCKED 🚫 (integration name ambiguous — could not auto-detect in unattended mode)`. TCs that don't depend on this setup still run normally.

## Credential Setup

Once a single `integration_name` is resolved:

1. Probe: `node "$CLAUDE_PLUGIN_ROOT/skills/test-ticket/scripts/manage-integration-credentials.js" check "<integration_name>"` (add `--fields=F1,F2,...` if the ticket names a different credential shape than username+password — e.g. `--fields=API_KEY`).
2. `present` → proceed to Test Setup below.
3. `missing` → run `add`:
   ```bash
   node "$CLAUDE_PLUGIN_ROOT/skills/test-ticket/scripts/manage-integration-credentials.js" add "<integration_name>" [--fields=...]
   ```
   Tell the user exactly this:
   > 📎 **Test credentials for `<integration_name>` not configured.**
   >
   > I've added placeholder fields to your `~/.claude/settings.json`. Please fill in the values now:
   > 1. Open `~/.claude/settings.json`
   > 2. Find the `"env"` block and fill in the `QA_INTEGRATION_<INTEGRATION_NAME>_*` fields with this integration's test-environment credentials (never production credentials)
   > 3. Save the file, then type **`updated`** to continue.
   >
   > Type **`skip`** to proceed without them — every TC needing this integration's setup will be `BLOCKED`.
4. `updated` → re-run `check`. `present` → proceed. Still `missing` → ask again or `skip`.
5. `skip`, or `--unattended` → run `remove "<integration_name>"` to clean up the empty placeholders, then mark every TC that needs this integration's setup `BLOCKED 🚫 (integration test credentials not configured for <integration_name>)` and skip Test Setup below for this story.

**Never** print, log, or paste a credential value anywhere in the conversation — the script only ever reports `present`/`missing`, exactly like the Jira credential probe.

## Test Setup (once credentials are confirmed present)

Via Playwright, in the app's own Supplier/Reseller connection admin screen (found by navigating the sidebar the same way any other TC does — no hardcoded path, this varies by which integration is named):
1. Add the test credentials from the `QA_INTEGRATION_<INTEGRATION_NAME>_*` env vars into the connection's own credential fields.
2. Configure any test-specific IDs the ticket's Preconditions/setup notes name (e.g. a test supplier ID, a test property/listing ID).
3. Unlink/link existing connections where the ticket's setup notes require it.

Log: `[IntegrationSetup] "<integration_name>" — credentials applied, <n> test ID(s) configured, <n> link/unlink action(s) applied.`

**Setup step fails** (form error, permission denied, control not found) → log the specific reason. Mark only the TCs that depend on this integration's setup `BLOCKED 🚫 (integration test setup failed: <reason>)` — do not attempt the import/export TCs against unconfigured setup.

## Variable-Duration Job Wait (Supplier import / Reseller export)

Import and export jobs do not complete on a fixed schedule — different suppliers/resellers and different data volumes take different amounts of time. Do not assume completion after a fixed pause; poll:

```js
async () => {
  // Adjust the status selector to the job/queue screen's own status column or badge.
  const statusSel = '[class*="job-status"], [class*="import-status"], .status-badge';
  const doneStates = /completed|success|finished/i;
  const failStates = /failed|error/i;
  const deadline = Date.now() + 60 * 1000; // one call never runs longer than 60 s; the 15 min cap is counted by the agent across repeated calls
  while (Date.now() < deadline) {
    const el = document.querySelector(statusSel);
    const text = el ? el.textContent.trim() : '';
    if (doneStates.test(text)) return { state: 'done', text };
    if (failStates.test(text)) return { state: 'failed', text };
    await new Promise(r => setTimeout(r, 5000)); // re-check every 5s — a job takes minutes, not milliseconds, so this is cheap
  }
  return { state: 'pending' };
}
```

Run via `browser_evaluate` (not `browser_wait_for` — it has no selector support, same limitation documented for the Page-ready wait elsewhere in this pipeline). Refresh/re-navigate to the job status screen before each call if the app doesn't auto-refresh it. A call that returns `pending` is simply called again, until 15 minutes of wall-clock time have passed since the job was started (override if the ticket names a longer expected duration) — one call must never run for minutes, because the per-TC timeout and the progress list only move between tool calls.

- `done` → proceed to Cross-Module Verification below.
- `failed` → `FAIL ❌` (a real job failure is a product finding, not a setup problem) — capture the job's own error message/log as evidence.
- still `pending` after the 15-minute cap → `BLOCKED 🚫 (import/export job did not complete within 15 min — verify manually or re-run with a longer wait)`. Do not guess at a partial result.

## Cross-Module Verification

Once the job reports done:
- **Supplier import** → verify the imported data is reflected correctly in Integration Manager's own view, then in Content Manager (Availability) and Revenue Manager (Rates) — navigate to each via the normal sidebar/nav-cache flow and compare against the ticket's stated expected values, the same way any other multi-screen TC is verified.
- **Reseller export (internal half only — see External Portal Boundary)** → verify the exported data is reflected correctly across Content, Rates, and Reservations, and — where the ticket asks for it — against a previous export for comparison (e.g. a saved prior export file/screenshot, if the ticket provides one; do not invent a "previous export" baseline that wasn't given).

## External Portal Boundary

Any TC step that requires observing the result on a third-party client portal (Booking.com Extranet, Airbnb Developer Portal, or equivalent) — **do not attempt it.** Mark that TC `BLOCKED 🚫 (external portal verification — <portal name> — out of pipeline scope, requires manual QA)`. This is a permanent scope boundary, not a missing-credential or missing-setup situation — never retry it, and never mark it `NEEDS REVIEW` hoping a human resolves it inside this run. The internal half of the same TC (data correct up to the point of export) still gets tested normally per Cross-Module Verification above.
