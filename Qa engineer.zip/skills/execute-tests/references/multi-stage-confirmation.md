# Multi-Stage Inline Confirmation

Some destructive actions (Unlink, Delete, Remove, Deactivate) confirm via a button that morphs its own label **in place** through 2–3 stages instead of opening a modal dialog — e.g. Channel Manager's "Unlink commission" → "Are you sure?" → "Confirm" (confirmed live, MXTS-81997, Sep 2026). Each stage is a genuinely different element (a new accessible name, and a new DOM ref) rendered in the same visual slot — not the same button clicked repeatedly.

**Never:**
- Reuse a cached ref/selector from an earlier stage for a later click.
- Click "the same visual position" without re-reading the element's current label — an unrelated card loading or expanding elsewhere on the page can shift this button's position between clicks, and a stale-position click can land on a completely different control. (Confirmed real-world consequence: a stale-position click during a multi-stage confirmation deleted the wrong record entirely — a rentability rule, not the intended target.)
- Assume one click "does the confirm" for a TC step that reads as a single instruction (e.g. "3. Confirm in the confirmation dialog") — the step's own wording can abstract away that this requires 2–3 real clicks.

**Always:**
1. Click the initiating button (e.g. "Unlink commission").
2. Call `browser_snapshot` again — do not reuse the pre-click snapshot or its refs.
3. Read the button's *current* accessible name in the same slot. If it names a confirmation stage (e.g. "Are you sure?", "Confirm") — click it, then repeat from step 2.
4. Stop once the action has actually executed (the row disappears, a success toast appears, or the button reverts to its original label/disabled state) — verify this via a fresh snapshot before recording the verdict.
5. **Cap at 5 clicks total.** A real confirmation sequence is 2–3 stages; still cycling after 5 means something is stuck (a rendering bug, or the label pattern wasn't actually recognized) — stop and mark `NEEDS REVIEW` rather than clicking indefinitely.
6. **If the re-read label doesn't match any expected confirmation-stage wording** — stop clicking blindly. Re-snapshot, reassess against the DOM, and if still ambiguous mark `NEEDS REVIEW` rather than guessing which element to click next.

This applies to any step-verb ending in an irreversible action — Unlink, Delete, Remove, Deactivate, Cancel booking — regardless of whether the TC table's own wording calls out the multiple stages.

## Related pattern: a list of cards/rows, not one morphing button

The same root cause — trusting position/index instead of re-verifying identity right before a destructive click — also shows up in a *list* of separate cards or rows, each with its own destructive action (e.g. a rules list where every card has its own Delete/confirm control). If a card loads asynchronously and inserts itself above the target between the time it was identified and the time its action is clicked, a position/index-based click (e.g. "click the 3rd card's Delete button") lands on whatever card now occupies that position — not the intended one. **Never click a list item's destructive action by position/index alone.** Immediately before the click, re-snapshot and confirm the target element's own identifying text (name, code, ID — whatever the TC actually names) matches the intended record, not just its ordinal position in the list.

