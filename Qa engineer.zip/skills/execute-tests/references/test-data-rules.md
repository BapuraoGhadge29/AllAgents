# Test Data Rules (Step 3d)

Apply before executing any write operation, within the per-TC execution loop.

> ⛔ **Which data rules apply to live execution.** These rules govern the live TCs on dev/test. A `CLAUDE.md` of the repo the session was opened in (typically `mxts-qa-automation` or `mcms-qa-automation`) may say regression specs use dummy data only and create their own uniquely suffixed records — that rule is for committed spec files, not for these live TCs. In live execution an existing record may be **read** (searched, opened, viewed, or used as proof of a status precondition) but never edited, deleted or changed (the exceptions are the setup actions in `test-data-setup.md`: link a customer, fill fields, add or remove guests, add-ons and children on a spare record, create records — all logged in `seed_records` and put back after the story); records a TC creates are `QA-AUTO-<STORY_KEY>-<TC_ID>-…` records (Rule 1, torn down after that TC), and a TC that edits data edits only a record this run created or seeded (Step 2d) — never an existing one. Never refuse a TC, or mark it `BLOCKED`, because an existing record is used read-only. KEEP IN SYNC with test-ticket's Test Data Setup in `phase-3a-execution.md`.

**Rule 1 — Unique prefix for all created data:**
Any entity created during a test must be prefixed with `QA-AUTO-<STORY_KEY>-<TC_ID>-` to namespace by story run and test case. This allows targeted cleanup of all data from a single story run.

Examples:
- Customer name: `QA-AUTO-MXTS-12345-TC05-John Doe`
- Reservation: `QA-AUTO-MXTS-12345-TC08-Test Booking`
- Document: `QA-AUTO-MXTS-12345-TC11-Upload Test`

This ensures re-runs never fail due to "already exists" errors from prior state, and stale data from previous runs can be identified by story prefix for manual cleanup.

**Rule 2 — Best-effort teardown after each write test:**
After a test case that created data, attempt to delete/archive/undo the created entity before moving to the next TC. Log the outcome:
- Deleted successfully → `[teardown TC_05] QA-AUTO-TC05-John Doe deleted`
- Could not delete (no delete UI / permission) → `[teardown TC_05] skipped — no delete available; manual cleanup may be needed`

Teardown is best-effort only — a teardown failure must NOT fail the test result. Move to the next TC regardless.

**Rule 3 — Read-only tests are unaffected:**
TCs that only navigate, search, view, or verify (no create/edit/delete) skip both rules above entirely.

**Rule 4 — Open a record only when the TC needs it:**
Never open the first or initial row of a list, or any other existing record, to look around (to learn the UI, to see whether a control exists, to see what a state looks like). Open a record only when a TC step or precondition needs that exact record: one found by searching or filtering on what the precondition names, or one this run created. See Test Data Setup (`test-data-setup.md`) for the full wording.
