# Evidence Review

A PASS rests on the screenshot and snapshot the executor itself judged. A fresh reviewer that never saw the executor's reasoning catches the cases the executor talked itself into: a control the TC names that is not actually in the image, an empty list taken as proof that something was hidden, a screenshot taken one step before the outcome. The reviewer can only **downgrade** a PASS to `NEEDS REVIEW`; it never creates a PASS, a FAIL, or a Jira write.

## When it runs

Once per story, after the last TC has a verdict and before results are posted — `/execute-tests` Step 3i-2 (before the NEEDS REVIEW gate); `/test-ticket` right after the Phase 3a Completeness Gate, before Phase 3b. Skipped when:
- `--skip-review` was passed — log `[EvidenceReview] skipped (--skip-review).` and run the metrics event `evidence_review_skipped`.
- No TC qualifies (below).
- Phase 3a was skipped (Generation only mode) — there is nothing to review.

## Which TCs qualify

Every TC whose final verdict is `PASS` (including `PASS (flaky …)`) **and** whose Risk column is `High` (after the `critical_paths` override). All other verdicts and risks are out of scope. Cap the batch at **15 TCs**, in execution order; if more qualify, review the first 15 and log `[EvidenceReview] <n> High-risk PASS TCs, reviewed the first 15.` — never split into several reviewer calls.

## Build the review packet (before the call)

For each qualifying TC write one entry to `test-output/<EPIC_ID or STORY_KEY>/evidence-review-input.json`:

```json
[{ "tc_id": "TC_03", "scenario": "<scenario>", "expected_result": "<expected>", "actual_result": "<what the executor recorded>", "screenshots": ["<absolute path>", "..."] }]
```

`screenshots` are the absolute paths already resolved after capture (see "Resolve and verify the screenshot path" in the Phase 3a reference) — every file for a multi-item, comparison or two-state TC, and both halves of a Before/After pair (MCMS, or a bill-changing TC), not only one. A TC with no reachable screenshot is **not** sent and cannot keep its PASS — record it as `NEEDS REVIEW 🔍 (no screenshot to review)` immediately.

## The reviewer call

Dispatch **one** subagent (`subagent_type: "Explore"` — read-only; fall back to `general-purpose` only if `Explore` is unavailable). Give it paths, never your conclusions or reasoning. Prompt:

```
You are reviewing QA evidence before it is posted to Jira. You have no context on this run.
Packet: <path to evidence-review-input.json>
Open the packet, then open every screenshot listed for each TC with the Read tool and look at it.
For each TC decide whether its screenshots actually prove its Expected Result. Return FAIL for a TC when ANY of these is true:
1. Something the Expected Result or Scenario names (a button, field, label, message, column, state) is not visible in that TC's own screenshots.
2. The Expected Result says something is hidden / absent / removed / disabled, and no screenshot of the SAME TC shows the positive state first (the thing present / enabled). An empty list or a missing element alone proves nothing — it looks the same as a broken page.
3. The last screenshot shows an intermediate state (a filled-in box, a changed URL, a dialog just opened) instead of the outcome the action exists for (filtered results, saved record, sent confirmation), or shows an empty or blank result area.
4. A screenshot shows a log or console dump, a token, a password, or an Authorization header.
5. The screenshots contradict the recorded Actual Result.
Do not judge anything you cannot see; do not use outside knowledge of the product. Return ONLY a JSON array, one object per TC in the packet:
[{"tc_id":"TC_03","verdict":"PASS"|"FAIL","reason":"<one short sentence, empty when PASS>"}]
```

## Apply the result

- Parse the reply as JSON. Anything else — not parseable, a TC missing from the array, a subagent error or timeout — means **the review did not run for those TCs**: keep their PASS, log `[EvidenceReview] reviewer returned no usable result for <TC_IDs> — kept PASS.`, run the metrics event `evidence_review_failed`, and say so in the final report under ACTION REQUIRED (`Evidence review did not run for <TC_IDs>`). Never retry the same call; never treat a failed review as a passed one.
- `FAIL` → set that TC's verdict to `NEEDS REVIEW 🔍` and append to its Actual Result: `Evidence review: <reason>.` Update `results.md` and `execution-log.json` for that TC at once (same incremental rule as any verdict). Run the metrics event `evidence_review_downgrade` with the TC count. Log `[EvidenceReview] <TC_ID> PASS → NEEDS REVIEW — <reason>`.
- `PASS` → no change. Log `[EvidenceReview] <n> reviewed, <m> downgraded.`
- A downgraded TC follows the normal NEEDS REVIEW path from then on (human resolution gate in `/execute-tests`; posted as-is in `/test-ticket`).
- Delete `evidence-review-input.json` once applied.

## Positive-control rule (applies during execution, not only here)

The reviewer's check 2 is also a rule for the executor: **never record `PASS` on a negative assertion** ("is hidden", "is not shown", "is no longer visible", "is disabled", "cannot be…") **without having observed the positive state first in the same TC** — the element present or enabled before the action, or on a comparable record where it should appear. Take that observation as its own screenshot named per the multi-item convention (`<TC_ID>-<slug>.png` for the positive state, the usual result screenshot for the negative one). When the positive state cannot be reached, record `NEEDS REVIEW` and say so — do not record PASS from an empty result alone.

For a bug-fix retest (`--retest`), the same rule applies in the other direction: a TC that previously FAILed is only trusted as fixed when this run's screenshot shows the corrected outcome, not merely the absence of the earlier error text.
