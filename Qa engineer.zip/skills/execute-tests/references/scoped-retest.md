# Scoped Retest (`--retest`)

A retest validates a fix, checks for regressions and stops early. It never re-runs the whole suite. `test-ticket` and `execute-tests` follow this procedure for `--retest`.

## Baseline

The baseline is each TC's latest verdict: the previous results comments of this story (every `_Part n of m_` part), overlaid by any later retest. Read each verdict from the `Status` column by its header name, not by position: the first cycle's comment is the merged 12-column table (Status is the 11th column), a retest's comment is the 6-column table (Status is the 5th). `test-ticket` takes it from the in-memory snapshot captured before `results.md` is deleted; `execute-tests` reads the Jira comments. On the first retest also persist the story's `run1_verdicts` entry under `stories` (`{ "TC_01": "FAIL", … }`) from that baseline. Never overwrite it afterwards; `--force` clears it.

No `FAIL`, `NEEDS REVIEW` or `BLOCKED` in the baseline → nothing to retest. Log `[retest] no non-pass TC in the previous run — nothing to retest` and stop without posting.

## Scope and order

1. **Stage A — every non-pass TC.** Baseline `FAIL` first, then `NEEDS REVIEW`, then `BLOCKED`; within each bucket High → Medium → Low risk.
2. **Stage B — regression check.** Runs only when every baseline `FAIL` TC ended `PASS` and no Stage A TC ended `FAIL`. Scope: baseline `PASS` TCs with Risk `High`. Other PASS TCs are not re-run. A Stage A TC that is still `NEEDS REVIEW` or `BLOCKED` does not block Stage B.
3. **Stop rule.** The first baseline `FAIL` TC that still fails after the normal retry attempts ends the run at once: no further TC runs, no Stage B. A later baseline `FAIL` that fails again does not stop Stage A, but Stage B is skipped. A `NEEDS REVIEW` or `BLOCKED` TC never triggers the stop; if it now ends `FAIL`, Stage A continues and Stage B is skipped.

TCs outside the executed set keep their baseline verdict. They get no row in this cycle's comment, no screenshot and no verdict change.

Log: `[retest] scope: <n> FAIL → <n> NEEDS REVIEW → <n> BLOCKED → <m> High-risk PASS (stage B <runs | skipped>)`.

## Recording

- Cross-reference as in Retest Cross-Reference ([phase-3a-execution.md](${CLAUDE_PLUGIN_ROOT}/skills/test-ticket/references/phase-3a-execution.md)): `FAIL → PASS` = fixed, `PASS → FAIL` = regression.
- `results.md` keeps one row per TC: this cycle's verdict where it ran, the carried-forward baseline verdict otherwise (marked `carried`). Phase 4 triages only the TCs that ran. Phase 5's Exit Gate reads these merged verdicts, so an unfixed TC still fails the story. A stop-rule stop is not a `partial_run`.
- The completeness gate checks the executed set, not the whole Phase 2 table.

## Jira comment

One **new** results comment on the same ticket, in the fixed Phase 3b template. The Run 1 comment stays untouched as history. The template allows no new rows, columns or sections, so mark the two runs in the cells it already has:

- **Preconditions row** starts with `Retest of Run 1 — <n> non-pass TC(s) re-run<, <m> High-risk passed TC(s) re-checked | , regression check skipped>; ` then the usual preconditions. A stop adds `stopped after <TC_ID> failed again; <k> TC(s) not executed`.
- **Actual Result cell** of every row ends with `Run 1: <verdict>` from `run1_verdicts`, plus `— fixed`, `— still failing` or `— REGRESSION` for a previous FAIL or PASS, and `— now verified` or `— still blocked` / `— still needs review` for a previous BLOCKED or NEEDS REVIEW. A previously BLOCKED TC that now runs gets a normal verdict from this run's own evidence; the missing configuration is not repeated as the reason.
- **Total TCs, Passed, Failed, …** count only the TCs executed in this cycle. Pass rate follows the same basis.
- A split comment (more than 45 rows) applies the same marking to every part.

The evidence rules are unchanged: a screenshot per executed TC, and a previously failed TC counts as fixed only when this run's screenshot shows the corrected outcome.
