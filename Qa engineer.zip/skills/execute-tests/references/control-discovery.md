# Control Discovery (before "no matching control found")

Runs when a step names a domain action (mark a unit Clean, complete a task, reissue an invoice, …) and the control is not on the screen you are on. A control missing from that screen is not evidence the action cannot be done: the app usually puts it on the screen of the thing the action acts on, not in the module the TC names.

**Why this exists (MXTS-81060, Oct 2026):** TCs said "In Housekeeping, mark the reservation's unit as Clean". Only the Operations Manager planning dashboard and the FOM unit view were checked (both read-only) and 10 TCs ended `BLOCKED` ("the Clean event cannot be driven"). The working path was the reservation → its unit → set the status to "Done", which marks the unit Clean. It was one click away from a screen the run had already opened.

**Procedure (bounded — stop at the first control that does the job):**
1. **The thing the step acts on.** Open that entity the way a user reaches it (the reservation, the customer, the invoice), then the row, unit or item inside it. `browser_snapshot` every screen on the way and read the row actions, overflow ("⋮") menus, status dropdowns and detail tabs.
2. **The step's own words.** Look through those snapshots, with `browser_find`, for the verb and the target of the step and their near-synonyms (clean, done, complete, status, mark, set).
3. **Other modules that own the object.** Sidebar search by those words, then the module the TC names, then the module that normally owns the object (Housekeeping, Operations, Front Office, …).
4. **Time-box.** At most 10 `browser_snapshot` calls or 5 minutes for one missing control. The outcome counts for the whole run: a control that was found is reused by every later TC that needs the same action, and one that was not found is not searched for again TC after TC.
5. **Found.** Perform it — a destructive action goes through [Multi-Stage Confirmation](multi-stage-confirmation.md). It changes only the state the TC itself asks for; everything else stays under the [Test Data Rules](test-data-rules.md). Log `[Control] "<step text>" → <path taken>` and keep the path in the TC's Actual Result.
6. **Not found.** Mark the TC `BLOCKED 🚫 (step "<step text>" — no matching control; checked: <screen 1>, <screen 2>, …)`, listing every place that was checked, so the reader sees what was tried and not just that it failed.
7. **Asking the tester.** Never ask "how do I do X" before steps 1–4 have run. With `--unattended` never ask: go to step 6. Otherwise ask once, after step 6's list exists, and reuse the answer for every TC that needs the same action.
