# Permission Toggle (TCs that need a user WITHOUT a permission)

<!-- Single source of truth shared by execute-tests and test-ticket (test-ticket references it via ${CLAUDE_PLUGIN_ROOT}). Do NOT mirror or copy it: the marker and lock formats must stay identical across both skills. -->

A TC such as "Verify we are not able to filter by invoice reservation type without the invoice permission" needs a restricted user. The tester's own user holds **Maxxton Admin** (all permissions), so a restricted user never exists by itself — and a new employee cannot be used, because the create form has no password (invite email only). Do not mark these TCs `BLOCKED` for "no restricted user". Disable the permission on the tester's **Maxxton Admin** role, run the TC, and restore it. (Mechanics verified live, SAN dev, Back Office Manager, 2026-10-06.)

**Dev/test environments only:** run this only when the base URL host is a dev/test/QA environment (`-dev.`, `-test.` or `-qa.` in the host, e.g. `san-dev.maxxton.net`). On any other host → `BLOCKED 🚫 (permission toggle is restricted to dev/test environments)` and no change. The step-0 confirmation names the host.

**Never toggle a permission the restore itself depends on:** anything in the Back Office Manager module (`backofficemanager.*`), role, permission or security configuration, employee management, or the right to save role rights. Removing one of those can leave the shared Maxxton Admin role unreachable for the restore step and restricted for everyone on the concern. Such a TC is `BLOCKED 🚫 (permission <key> is needed to restore the role — manual QA only)` and nothing is changed.

**Scope:** only when the TC names a permission key (e.g. `reservationmanager.reservation.finance.invoices`) or an equivalent "without permission / not authorised" scenario. Never for any other kind of precondition.

**0. Confirm first.** Maxxton Admin is shared by everyone on the concern, so ask the user once per run before changing it (`AskUserQuestion`: role, permission label, "restored right after the TC"). No answer or "no" → `BLOCKED 🚫 (restricted-user precondition: permission toggle not approved)`. **Unattended runs (`--unattended`) fail closed:** no prompt, no toggle — every restricted-user TC is `BLOCKED 🚫 (restricted-user precondition: permission toggle needs interactive approval)`. The prompt must also state that the lock below is local to this workspace: no other QA session may toggle this concern's Maxxton Admin role at the same time.

**1. Resolve the role id (read-only), acquire the lock, then persist a restore marker — all BEFORE changing anything.** First open `<base>/backofficemanager/en-gb/configuration/roles`, click the visible `Maxxton Admin` and read `<role_id>` from the URL (`.../roles/role/<role_id>`) — viewing changes nothing. The role is shared, so scope both files to the environment and role under `test-output/permission-toggle/` (create that directory first if it does not exist — the startup check must tolerate it being absent):
- `<host>-<role_id>.lock` — `{ "run_id": "<EPIC/STORY key + start time>", "started_at": "<ISO time>", "heartbeat_at": "<ISO time>" }`, created **atomically** (exclusive create — it must fail if the file exists). Refresh `heartbeat_at` in the lock after every step of this procedure and after every TC that runs while the permission is disabled. A lock whose `heartbeat_at` is more than 30 minutes old is stale and may be reclaimed — a live run never goes that long without a heartbeat. A fresh lock owned by another `run_id` means busy: wait up to 5 minutes, then `BLOCKED 🚫 (permission toggle busy: role in use by another run)`.
- `<host>-<role_id>.json` — `{ "host": "san-dev.maxxton.net", "run_id": "...", "role_id": <n>, "role_name": "Maxxton Admin", "module_label": "Reservation Manager", "permission_label": "Reservation Manager - Invoices", "original_levels": ["READ","CREATE","EDIT","DELETE","EXECUTE"], "applied": false }`. Set `"applied": true` only after step 2.5 verified the disable.
Hold the lock for the whole disable → execute → restore window; delete it only after restore is verified. The lock is workspace-local — it cannot stop another machine from toggling the same role, which is why step 0 asks the user.

**Startup check (every run, before any environment-writing step — `/execute-tests` right after login, `/test-ticket` before Precondition Evidence Check):** list `test-output/permission-toggle/*.json`. For each marker whose `host` is the current environment: acquire its lock atomically (reclaim it if stale; if a fresh lock belongs to another live run, skip this marker), run step 5 (restore), then delete the marker and the lock. A marker that cannot be restored stays in place and is reported under ACTION REQUIRED.

**2. Disable.**
1. `<base>/backofficemanager/en-gb/configuration/roles`, click the **visible** `Maxxton Admin` (`getByText('Maxxton Admin', { exact: true }).locator('visible=true').first()` — the first DOM match is a hidden header span). The URL becomes `.../roles/role/<role_id>`.
2. Expand the module section whose header reads `<Module> (n/m)`.
3. Permission label: the hidden element `#permission.name.<permission.key>` holds the UI label (`reservationmanager.reservation.finance.invoices` → `Reservation Manager - Invoices`). Row: `tr.cdk-row` with that text, excluding look-alikes (`Energy invoices`, `Generate energy invoices`). Record its active levels (`.permission-type.active`, `title` = READ/CREATE/EDIT/DELETE/EXECUTE) into the marker. The selector is cumulative (clicking a level activates it and every lower one — observed READ…EXECUTE). Proceed only if the recorded set is a prefix of READ, CREATE, EDIT, DELETE, EXECUTE; otherwise `BLOCKED 🚫 (permission levels <levels> cannot be restored through the cumulative selector)` and change nothing.
4. Click the row's `[title="No rights"]`, then the page-level same-button 3-click cycle `Save rights` → `Are you sure?` → `Confirm`. Only the third click sends `PUT /api/v1/permissions/groups/<role_id>/permissions` (204). A single click on `Save rights` saves nothing and a reload shows the old state.
5. Reload and verify: the row shows `No rights` active and the module header count dropped by one (e.g. 107/107 → 106/107).

**3. Fresh session.** An open session keeps its old permissions. Log out via the current environment's own login host and realm (read both from the login page URL, `https://<login-host>/authenticate/realms/<realm>/...`): `https://<login-host>/authenticate/realms/<realm>/protocol/openid-connect/logout?client_id=maxxton-software-development&post_logout_redirect_uri=<base>`, open the app, click `Maxxton Employee`.

**4. Prove the restriction is effective before judging the TC.** Check the restricted behaviour first (the filter/action is hidden, rejected or shows a no-access message). If the feature still works as for an admin, re-login once and re-check. Still unrestricted → record `BLOCKED 🚫 (permission disabled on role <name> but not effective in this session — <what was seen>)` and never `PASS`. Seen on SAN dev right after a disable and re-login: the AI search still applied `reservationKindId=INVOICE_RESERVATION`, so the effect is not guaranteed — the TC verdict needs this gate.

**5. Restore — always** (after the TC, on FAIL/BLOCKED, and on any abort). Open the role, expand the module and read the row's levels first: if they already equal `original_levels` (e.g. the marker is from a run that crashed before step 2 changed anything, `applied: false`), the role is safe — skip the click and save (a no-op click never shows `Save rights`) and go straight to the verification. Otherwise click the button of the highest level in `original_levels` (the selector is cumulative, so `[title="EDIT"]` restores READ, CREATE and EDIT and nothing above — never click `EXECUTE` unless it was in the original set, that would over-grant the shared role), run the same 3-click save, reload, and verify the row's levels equal `original_levels` and the header count is back (106/107 → 107/107). Then log out and back in again (step 3) so every later TC runs with the restored permission, not the session that had it removed. Delete the marker and the lock only after that check passes; if restore fails, keep the marker and the lock, log `[Permission] RESTORE FAILED — role <name> still missing <label>` and tell the user in the final summary.

Log each step as `[Permission] disabled <label> on <role>` / `[Permission] restored <label> on <role>`.

## Tested snippet (`browser_run_code_unsafe`) — disable and restore share one function

Run on `<base>/backofficemanager/en-gb/configuration/roles/role/<role_id>` (open it via the visible `Maxxton Admin` link on the roles list the first time to learn `role_id`). `level` is `'No rights'` to disable, or the highest level in `original_levels` to restore (for example `'EDIT'`; never a higher level than the original). It returns the row's levels and the module count after a reload, plus the PUT status — assert `put` is `204` and the state matches before continuing. `Save rights` only appears after a real change — clicking a level that is already active saves nothing (and the `waitFor` for the button times out), so a no-op can never be used to "test" the snippet. Verified end to end on SAN dev (disable → 106/107, restore → 107/107, both `204`).

```js
async (page) => {
  const MODULE = 'Reservation Manager', LABEL = 'Reservation Manager - Invoices', LEVEL = 'No rights'; // restore: the highest level in original_levels, e.g. 'EDIT'
  await page.getByText(`${MODULE} (`).locator('visible=true').first().click();   // module header reads "<Module> (n/m)"
  await page.waitForTimeout(2500);
  const rowOf = () => page.locator('tr.cdk-row').filter({ hasText: LABEL }).filter({ hasNotText: /Energy|Generate/ }).locator('visible=true').first();
  const levels = (row) => row.evaluate(r => Array.from(r.querySelectorAll('.permission-type')).map(d => d.getAttribute('title') + (d.classList.contains('active') ? '*' : '')).join(' '));
  const before = await levels(rowOf());
  let put = null;
  page.on('response', r => { if (r.request().method() === 'PUT' && /\/api\/v1\/permissions\/groups\/\d+\/permissions/.test(r.url())) put = r.status(); });
  await rowOf().locator(`[title="${LEVEL}"]`).click();
  for (const name of ['Save rights', 'Are you sure?', 'Confirm']) {   // only the 3rd click sends the PUT
    const b = page.getByRole('button', { name, exact: true });
    await b.waitFor({ state: 'visible', timeout: 8000 });
    await b.click();
    await page.waitForTimeout(1200);
  }
  await page.waitForTimeout(2500);
  await page.reload();
  await page.waitForTimeout(5000);
  const header = await page.evaluate((m) => document.body.innerText.split('\n').find(l => l.startsWith(m + ' (')), MODULE);
  await page.getByText(`${MODULE} (`).locator('visible=true').first().click();   // module header reads "<Module> (n/m)"
  await page.waitForTimeout(2500);
  return { before, after: await levels(rowOf()), header, put };   // disable: after = 'No rights* READ CREATE ...', header n-1; restore: all levels active, header back
}
```
