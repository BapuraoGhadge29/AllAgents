# Output Formats

## Step 5 results table

After all test cases are executed, output a results table in this shape:

```
TEST EXECUTION RESULTS
======================
| | |
|---|---|
| Story | <STORY_KEY> |
| Environment | <base URL> |
| Run date | <date> |
| Original TCs | <n> |
| Passed | <n> |
| Failed (confirmed) | <n> |
| Needs Review | <n> |
| Blocked | <n> |
| Skipped | <n> |
| Flaky (passed on retry) | <n> |
| Pass rate | <percentage>% (BLOCKED and Skipped excluded, original TCs only) — or `N/A (no TC verified)` when Original TCs − Blocked − Skipped is 0 (every TC ended up BLOCKED/SKIP); never a computed percentage against a zero denominator |
| Extra TCs found | <n> |

RESULTS
-------
| TC_ID | Scenario | Result | Reason |
|---|---|---|---|
| TC_01 | Verify we are able to ... | PASS | Expected element found in snapshot |
| TC_02 | Verify we are not able to ... | FAIL | Error message not displayed — snapshot shows blank page |
| TC_03 | Verify ... | BLOCKED | No reservation without linked customer available in environment |
...

EXTRA TEST CASES (discovered during execution)
----------------------------------------------
| EXTRA_01 | Verify we are able to ... | PASS | ... |
...

FAILURES
--------
[FAIL] TC_02 — <scenario>
Expected: <expected result>
Actual: <what snapshot showed>
Screenshot: test-output/<STORY_KEY>/TC_02-result.png

BLOCKED
-------
[BLOCKED] TC_03 — <scenario>
Reason: <precondition could not be met>
```


## NEEDS REVIEW Resolution Block

Printed by Step 3j (human resolution gate):

```
NEEDS REVIEW — Human Resolution Required
=========================================
<n> test case(s) could not be automatically verified.
Review each one and reply with: pass <TC_ID> / fail <TC_ID> / skip <TC_ID>

TC_01 — Verify we are able to save customer record
  Expected: "Record saved" confirmation message
  Observed: Page reloaded but confirmation message was unclear
  Screenshot: test-output/<STORY_KEY>/<TC_ID>-result.png

TC_07 — Verify error is shown for duplicate name
  Expected: Inline validation error under Name field
  Observed: Form submitted without visible error — behaviour ambiguous
  Screenshot: test-output/<STORY_KEY>/<TC_ID>-result.png
  ...

Reply with your verdicts (e.g. "pass TC_01, fail TC_07"):
```
