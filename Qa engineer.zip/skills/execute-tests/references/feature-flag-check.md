# Feature Flag Check (Proactive Detection + Reactive Safety Net)

<!-- ⚠️ Mirrors the "Feature Flag Setup" + "Reactive Feature Flag Check" procedure in test-ticket/references/phase-3a-execution.md — execute-tests has no Jira Phase 1 step, so proactive detection here scans the TC table directly instead of `story.feature_flags`. Both skills are self-contained — prompt-based skills cannot import each other's steps at runtime. -->

## Startup Restore (before anything else in this file)

Feature flags are environment-global, so a crash during story A must be repaired even when the next run targets story B. Scan **every** story folder: `test-output/*/flags-enabled.json` and `test-output/*/flags-disabled.json`. Each file is `{ "host": "<base host>", "run_id": "<STORY_KEY + start time>", "heartbeat_at": "<ISO time>", "flags": ["<flag>", ...] }`; the owning run rewrites `heartbeat_at` after every toggle and after every TC while the file holds flags. Only a **stale** file is restored: its `heartbeat_at` (for a file without one — a legacy array included — its modified time) is more than 30 minutes old, or its `run_id` is this run's own (resuming the same run). A fresh file of another run means that run is still using this environment: leave it alone and log it. For each stale file whose `host` is the current environment, an earlier run crashed or failed mid-teardown and the environment still carries its changes: run the Teardown procedure below on it **now**, before proactive detection and before any TC work, so the flag states you read next are the original ones. Files for other hosts are left alone. A file whose content is a flat JSON array (written by an earlier plugin version, no `host`) is a legacy marker: treat it as `{ "host": <current environment>, "flags": <the array> }` and restore it too — never skip it for lacking a host.

## Proactive Detection (cheap head start — runs once, before Step 3's per-TC loop)

Scan every TC row's Scenario, Preconditions, Test steps, and Expected Result text for feature-flag language — "feature flag", "toggle", "flag", a flag name in backticks/code formatting, or phrasing like "must only be shown when X is enabled/disabled". Extract each distinct flag name into a run-level list `detected_flags`.

*No flag language found → `detected_flags` stays empty. This is expected and does NOT mean flags don't matter for this run — the Reactive Check below is mandatory regardless (confirmed necessary, MXTS-80992/TC_08, Sep 2026: the ticket never named `home.owner.association.enabled` anywhere, and the screen it gated was still missed without a reactive check catching it).*

For each flag name in `detected_flags`:
1. Navigate to Maxxton Admin's feature flag section and search for the flag by name.
2. **Not found** → log `[FeatureFlag] "<flag>" not found in Maxxton Admin — proceeding without toggling.`
3. **Found, already enabled** → log `[FeatureFlag] "<flag>" already enabled — leaving as-is.`
4. **Found, disabled** → **first** append `<flag>` to `flags` in `test-output/<STORY_KEY>/flags-enabled.json` (create it as `{ "host": "<base host>", "run_id": "<STORY_KEY + start time>", "heartbeat_at": "<ISO time>", "flags": [] }` if missing) and write it to disk, **then** enable it and save, then re-read to confirm; if the enable fails, re-read the flag and remove the entry only when that read confirms it is still OFF — a save can reach the server although its response or the confirming read failed. If the state cannot be read, keep the entry and report the restore need under ACTION REQUIRED. The entry must exist before the toggle — a crash between the two would otherwise lose the only record that makes Feature Flag Teardown (Step 6e) and the Startup Restore possible. Log `[FeatureFlag] "<flag>" was disabled — enabled for this run.`
5. **Enable attempt failed** → log the reason. Do not block the run — the Reactive Check below still applies per-TC.

> ⛔ **Never disable a flag found already enabled — except for a TC that explicitly verifies the flag-OFF state (see Flag State Reconciliation and Teardown below, which re-enable it).** Only flags this run itself switched on — proactively here, or reactively below — go into `flags-enabled.json` and get torn down at Step 6e.

Log: `[FeatureFlag] Proactive detection complete — <n> already enabled, <n> newly enabled, <n> not found, <n> failed.`

## Reactive Check (mandatory, per-TC — independent of Proactive Detection above)

**Trigger:** during Step 3e/3f, a TC's target element/screen genuinely cannot be found after confirmed-correct navigation — the moment the verdict is about to become `BLOCKED` ("Feature not deployed") or `FAIL` ("Element not found"). Run this **before** recording that verdict.

1. Derive keywords (≥4 characters, split on whitespace/case boundaries) from the missing screen/module/entity's own name as the TC states it — e.g. "Home owner association Create/update" → `home`, `owner`, `association`, `homeowner`.
2. Navigate to Maxxton Admin's feature flag section; search/filter using each keyword (case-insensitive substring against flag names/descriptions).
3. **No match** → log `[FeatureFlag] Reactive check — no matching flag found for "<missing element>"; concluding <verdict> as genuine.` Record the original verdict — the ambiguity is now closed and auditable, not assumed.
4. **Match, already enabled** → same as above; record the original verdict.
5. **Match, disabled** → append to `flags-enabled.json` first (persist-before-toggle, same as Proactive step 4), then enable it, log `[FeatureFlag] Reactive check found "<flag>" disabled — enabled, retrying TC now.`, then retry this TC's navigation/element lookup **once**. Found now → continue normal verdict determination (PASS/FAIL on actual behaviour), with a note in Reason: `flag "<flag>" was disabled and enabled during this run`. Still not found → record the original verdict; do not retry a second time.
6. **Enable attempt failed** → log the reason and record the original verdict.

Runs once per TC that hits the trigger — never loop across multiple keyword/flag combinations beyond the first match found.

## Flag State Reconciliation (per-TC — before executing a TC that needs a specific flag state)

**Flag state reconciliation** — before every TC that depends on a flag being ON or OFF, bring the flag to the state that TC needs. A flag has at most one entry, recorded as the net change from the state it was found in: in the *enabled* record (found OFF, now ON), in the *disabled* record (found ON, now OFF), or none (untouched). Switch ON: if it is in `flags-disabled.json` → switch ON, re-read to confirm, and only then remove it from there (it is back to its original state, no entry); otherwise (found OFF) → add it to `flags-enabled.json` and write it to the file **before** the toggle, then switch ON. Switch OFF: if it is in `flags-enabled.json` → switch OFF, re-read to confirm, and only then remove it from there (back to original); otherwise (found ON) → add it to `flags-disabled.json` and write it to the file **before** the toggle, then switch OFF. Already in the needed state → change nothing and record nothing. After every toggle re-read the flag to confirm it saved; if the switch fails, mark the TC `BLOCKED 🚫 (could not set flag "<flag>" to <ON|OFF>)` — never run a flag-dependent TC against the wrong state. Teardown restores every remaining entry; an entry is removed only after the restored state is verified. A TC that explicitly verifies the flag-OFF state is the only reason to switch a flag OFF. **Another active run owns the flag?** Before every toggle, look at the other `flags-enabled.json` / `flags-disabled.json` files for the same host: when one that is fresh (`heartbeat_at` within 30 minutes, different `run_id`) already holds this flag, do not flip it — mark the TC `BLOCKED 🚫 (flag "<flag>" is in use by another active run)`; a stale file is restored by Startup Restore first.

## Feature Flag Teardown (Step 6e — after results are posted)

Read this story's `test-output/<STORY_KEY>/flags-enabled.json` and `test-output/<STORY_KEY>/flags-disabled.json` (the `flags` array of each; leftovers from other stories are handled by Startup Restore). Skip this whole step only when **neither** file exists — nothing was changed this run. Process each file that exists independently:

- `flags-enabled.json` (flags this run switched ON because it found them disabled): navigate to Maxxton Admin, disable each one, log `[FeatureFlag] "<flag>" disabled — teardown complete.`
- `flags-disabled.json` (flags this run switched OFF — found enabled, only to verify a TC that explicitly tests the flag-OFF state): navigate to Maxxton Admin, enable each one, log `[FeatureFlag] "<flag>" re-enabled — teardown complete.` A flag is appended to this file **before** the toggle.

Best-effort only — a teardown failure must NOT fail the run; log and continue. Delete each file only after every flag in it was restored successfully (a failed flag keeps the file so the next run can retry). Never disable a flag for any other reason; a flag this run never changed is left exactly as found.

The two files record the net change from the state the flag was found in, and a flag is in at most one of them: when the run switches a flag back, remove it from the file it is currently in (see Flag State Reconciliation) instead of adding it to the other — otherwise teardown flips it twice and leaves the shared environment in the wrong state.
