# Finance/Bill Page Screenshots

`fullPage: true` only captures `document.documentElement.scrollHeight` — it does NOT reach content that scrolls inside a nested container. The Reservation Manager Finance/Bill details panel (confirmed — MXTS-76681, 2026-08-07) renders its real content inside a fixed-height `overflow-y: auto` div sized off the viewport, while the outer page itself has zero scroll (`documentHeight === viewportHeight`). On this page `fullPage: true` silently captures only the first visible slice of that inner box and permanently misses everything below the fold — no error, no blank-image signal, just a screenshot that looks fine but proves nothing. This was confirmed to be the root cause of screenshots that were cropped before the relevant row AND of multiple TCs on the same story producing byte-identical screenshots (the inner box was never scrolled between captures, so every shot showed the same default slice regardless of which TC ran). **Finance/Bill pages need the Large-Viewport Capture step below — every other page is unaffected and needs no special handling.**

## Large-viewport capture — scoped to Finance/Bill pages ONLY (mandatory when the TC's observation is on a reservation's Finance/Bill screen, or when a comparison TC's source is an invoice/bill view)

Confirmed working approach (MXTS-76681, 2026-08-10): the Finance/Bill panel's internal scroll container is sized relative to the viewport, so simply resizing the browser window bigger before screenshotting eliminates the internal scroll entirely — no DOM manipulation needed. This is the "zoom out" a human gets from a bigger monitor, reproduced via `browser_resize`.

1. **Before screenshotting**, note the current viewport size (so it can be restored), then:
   ```
   browser_resize(width: 1920, height: 2700)
   ```
   1920×2700 is confirmed sufficient for this panel; if a future page still shows remaining scroll (check below), grow the height further rather than falling back to DOM tricks.
2. **Verify zero scroll remains** before capturing:
   ```js
   () => Array.from(document.querySelectorAll('*')).filter(el => {
     const cs = getComputedStyle(el);
     return (cs.overflowY === 'auto' || cs.overflowY === 'scroll') && el.scrollHeight > el.clientHeight + 5;
   }).length
   ```
   Must return `0`. If not, increase the resize height and re-check rather than screenshotting with content still hidden.
3. **Take the screenshot** (`fullPage: true`), saved directly as the TC's own actual result filename — `test-output/<STORY_KEY>/<TC_ID>-result.png` for an ordinary TC, or `<TC_ID>-<source-slug>.png` for a comparison-TC source (see the calling skill's naming rule) — this now captures Bill details (including VAT and Total/Due amount), Internal Bill, and Instalments in one image, unconditionally, even if the TC's own claim is about only one line in it. **This capture *is* the result screenshot — never take a second, separate screenshot for this TC/source at the restored (normal) viewport.** Taking a generic screenshot afterward at normal viewport would silently replace this one with the cropped version, defeating the whole point of resizing first.
4. **Restore the viewport to its noted size unconditionally** — on a successful capture, on a capture that errors or times out, and after every retry attempt. Every other page/TC in the run must continue at the normal viewport; a failed or retried capture must never leave the shared browser sitting at 1920×2700. This resize is a targeted step for Finance/Bill screenshots only, never a global setting for the run. **If the calling skill's retry logic re-runs this TC** (a failed capture, or a `FAIL` verdict retry), repeat steps 1–2 (resize + zero-scroll check) again before re-screenshotting — the viewport was just restored to normal in this same step, so a retry that jumps straight to `browser_take_screenshot` without redoing the resize will silently capture the cropped image again.

> ⛔ **Scope this to Finance/Bill pages explicitly.** Do not resize the viewport for any other page — other TCs already work correctly at the normal viewport size and must stay untouched by this step.

A bill-changing TC ([Bill Snapshots](bill-snapshot.md)) runs steps 1–4 twice, once for its Before capture and once for its After capture; the viewport is back at its normal size in between, so the After capture repeats the resize and the zero-scroll check.

**Fallback only if a Finance/Bill page still shows remaining scroll after a reasonably large resize** (not expected — not seen in testing, but don't screenshot with hidden content if it happens): expand the container's overflow directly via `browser_evaluate`, take the screenshot (same rule as step 3 above — save it directly as the TC's own actual result filename, never a separate generic capture afterward), then restore the overflow immediately after so later TC steps on the same page aren't affected by the layout change:
```js
() => {
  const targets = Array.from(document.querySelectorAll('*')).filter(el => {
    const cs = getComputedStyle(el);
    return (cs.overflowY === 'auto' || cs.overflowY === 'scroll') && el.scrollHeight > el.clientHeight + 5;
  });
  targets.forEach(el => {
    el.dataset.qaOrigStyle = el.getAttribute('style') || '';
    el.style.maxHeight = 'none';
    el.style.height = 'auto';
    el.style.overflow = 'visible';
  });
  return { expandedCount: targets.length };
}
```
Restore after the screenshot:
```js
() => {
  const restored = document.querySelectorAll('[data-qa-orig-style]');
  restored.forEach(el => {
    el.setAttribute('style', el.dataset.qaOrigStyle);
    delete el.dataset.qaOrigStyle;
  });
  return restored.length;
}
```

## Invoice screenshots (comparison TCs whose "invoice" source is a downloaded PDF, not a page)

An invoice is often only reachable as a PDF download (the in-app print/preview icon can be disabled), not a live page — `browser_take_screenshot` cannot capture a downloaded file directly. Convert the relevant PDF page to a PNG instead of skipping the invoice-side screenshot. **Never hardcode `python`/`python3`** — resolve the interpreter first (a bare `python3`/`python` can be the Windows Store's no-op alias stub; see CLAUDE.md → "Invoking Python from shell scripts"):
```bash
resolve_python() {
  local _cand
  for _cand in python3 python "py -3"; do
    if $_cand -c 'import sys; sys.exit(0 if sys.version_info[0] == 3 else 1)' >/dev/null 2>&1; then
      printf '%s\n' "$_cand"; return 0
    fi
  done
  return 1
}

PY=$(resolve_python) || { echo "no Python 3 found (tried python3, python, py -3)" >&2; exit 1; }
read -r -a PY_CMD <<< "$PY"      # split "py -3" into argv; quote on use

"${PY_CMD[@]}" -c "import fitz" 2>/dev/null || "${PY_CMD[@]}" -m pip install --quiet pymupdf

"${PY_CMD[@]}" -c "
import fitz
doc = fitz.open('<downloaded-invoice-path>.pdf')
page = doc[<page_index>]  # 0-indexed
pix = page.get_pixmap(dpi=200)
pix.save('test-output/<STORY_KEY>/<output-filename>')
"
```
`<output-filename>` is `<TC_ID>-invoice.png` for an ordinary comparison TC, or `<TC_ID>-<item-slug>-invoice.png` when the comparison TC is also multi-item (see the naming rule in Step 3h) — **never the bare `<TC_ID>-invoice.png` for a multi-item TC**, or each item's conversion overwrites the previous item's invoice image on disk. `pymupdf` is pure-Python — no external Poppler binary needed, unlike `pdf2image`. Identify `<page_index>` from the PDF's own text content (e.g. search for "Total des prestations par taux de TVA" / "VAT by rate") rather than guessing the last page.

**Verify the conversion actually succeeded before treating it as done** — a failed `pip install`, an unreadable/corrupt PDF, a wrong `<page_index>`, or a `pix.save` error all leave no `<output-filename>` on disk, with no non-zero exit guaranteed from the inline `python -c` block:
```bash
test -f "test-output/<STORY_KEY>/<output-filename>" || echo "CONVERSION_FAILED"
```
**File missing** → mark this source `BLOCKED 🚫 (invoice source unreachable — PDF conversion failed: <error/reason>)` rather than posting the comparison row without it; the TC's other source(s) still get their own screenshot. **File present** → proceed as normal.
