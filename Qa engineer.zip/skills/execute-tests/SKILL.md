---
name: execute-tests
description: Executes the test case table for a Jira story autonomously using the Playwright MCP browser. Logs into the target environment, runs each test step, records pass/fail with screenshot evidence, and posts results as a Jira comment. Use for a live test run (e.g. "execute-tests MXTS-12345").
disable-model-invocation: true
argument-hint: "[Jira story ID] [base URL] [--retest] [--max-tcs=N] [--tc-timeout=N] [--max-time=N] [--screenshots] [--unattended] [--clear-nav-cache] [--skip-review] [--workers=N]"
allowed-tools:
- Bash
- AskUserQuestion
- Agent
- Monitor
- mcp__claude_ai_Slack__slack_read_channel
- mcp__plugin_qa-engineer_playwright__browser_navigate
- mcp__plugin_qa-engineer_playwright__browser_navigate_back
- mcp__plugin_qa-engineer_playwright__browser_click
- mcp__plugin_qa-engineer_playwright__browser_fill_form
- mcp__plugin_qa-engineer_playwright__browser_snapshot
- mcp__plugin_qa-engineer_playwright__browser_find
- mcp__plugin_qa-engineer_playwright__browser_take_screenshot
- mcp__plugin_qa-engineer_playwright__browser_select_option
- mcp__plugin_qa-engineer_playwright__browser_press_key
- mcp__plugin_qa-engineer_playwright__browser_type
- mcp__plugin_qa-engineer_playwright__browser_hover
- mcp__plugin_qa-engineer_playwright__browser_drag
- mcp__plugin_qa-engineer_playwright__browser_drop
- mcp__plugin_qa-engineer_playwright__browser_file_upload
- mcp__plugin_qa-engineer_playwright__browser_handle_dialog
- mcp__plugin_qa-engineer_playwright__browser_wait_for
- mcp__plugin_qa-engineer_playwright__browser_resize
- mcp__plugin_qa-engineer_playwright__browser_tabs
- mcp__plugin_qa-engineer_playwright__browser_close
- mcp__plugin_qa-engineer_playwright__browser_network_requests
- mcp__plugin_qa-engineer_playwright__browser_network_request
- mcp__plugin_qa-engineer_playwright__browser_evaluate
- mcp__plugin_qa-engineer_playwright__browser_run_code_unsafe
- mcp__plugin_qa-engineer_playwright__browser_console_messages
- mcp__plugin_qa-engineer_playwright__browser_storage_state
- mcp__plugin_qa-engineer_playwright__browser_set_storage_state
- mcp__plugin_qa-engineer_playwright-w2__browser_navigate
- mcp__plugin_qa-engineer_playwright-w2__browser_navigate_back
- mcp__plugin_qa-engineer_playwright-w2__browser_click
- mcp__plugin_qa-engineer_playwright-w2__browser_fill_form
- mcp__plugin_qa-engineer_playwright-w2__browser_snapshot
- mcp__plugin_qa-engineer_playwright-w2__browser_find
- mcp__plugin_qa-engineer_playwright-w2__browser_take_screenshot
- mcp__plugin_qa-engineer_playwright-w2__browser_select_option
- mcp__plugin_qa-engineer_playwright-w2__browser_press_key
- mcp__plugin_qa-engineer_playwright-w2__browser_type
- mcp__plugin_qa-engineer_playwright-w2__browser_hover
- mcp__plugin_qa-engineer_playwright-w2__browser_drag
- mcp__plugin_qa-engineer_playwright-w2__browser_drop
- mcp__plugin_qa-engineer_playwright-w2__browser_file_upload
- mcp__plugin_qa-engineer_playwright-w2__browser_handle_dialog
- mcp__plugin_qa-engineer_playwright-w2__browser_wait_for
- mcp__plugin_qa-engineer_playwright-w2__browser_resize
- mcp__plugin_qa-engineer_playwright-w2__browser_tabs
- mcp__plugin_qa-engineer_playwright-w2__browser_close
- mcp__plugin_qa-engineer_playwright-w2__browser_network_requests
- mcp__plugin_qa-engineer_playwright-w2__browser_network_request
- mcp__plugin_qa-engineer_playwright-w2__browser_evaluate
- mcp__plugin_qa-engineer_playwright-w2__browser_run_code_unsafe
- mcp__plugin_qa-engineer_playwright-w2__browser_console_messages
- mcp__plugin_qa-engineer_playwright-w2__browser_storage_state
- mcp__plugin_qa-engineer_playwright-w2__browser_set_storage_state
- mcp__playwright__browser_navigate
- mcp__playwright__browser_navigate_back
- mcp__playwright__browser_click
- mcp__playwright__browser_fill_form
- mcp__playwright__browser_snapshot
- mcp__playwright__browser_find
- mcp__playwright__browser_take_screenshot
- mcp__playwright__browser_select_option
- mcp__playwright__browser_press_key
- mcp__playwright__browser_type
- mcp__playwright__browser_hover
- mcp__playwright__browser_drag
- mcp__playwright__browser_drop
- mcp__playwright__browser_file_upload
- mcp__playwright__browser_handle_dialog
- mcp__playwright__browser_wait_for
- mcp__playwright__browser_resize
- mcp__playwright__browser_tabs
- mcp__playwright__browser_close
- mcp__playwright__browser_network_requests
- mcp__playwright__browser_network_request
- mcp__playwright__browser_evaluate
- mcp__playwright__browser_run_code_unsafe
- mcp__playwright__browser_console_messages
- mcp__playwright__browser_storage_state
- mcp__playwright-headed__browser_navigate
- mcp__playwright-headed__browser_navigate_back
- mcp__playwright-headed__browser_click
- mcp__playwright-headed__browser_fill_form
- mcp__playwright-headed__browser_snapshot
- mcp__playwright-headed__browser_find
- mcp__playwright-headed__browser_take_screenshot
- mcp__playwright-headed__browser_select_option
- mcp__playwright-headed__browser_press_key
- mcp__playwright-headed__browser_type
- mcp__playwright-headed__browser_hover
- mcp__playwright-headed__browser_drag
- mcp__playwright-headed__browser_drop
- mcp__playwright-headed__browser_file_upload
- mcp__playwright-headed__browser_handle_dialog
- mcp__playwright-headed__browser_wait_for
- mcp__playwright-headed__browser_resize
- mcp__playwright-headed__browser_tabs
- mcp__playwright-headed__browser_close
- mcp__playwright-headed__browser_network_requests
- mcp__playwright-headed__browser_network_request
- mcp__playwright-headed__browser_evaluate
- mcp__playwright-headed__browser_run_code_unsafe
- mcp__playwright-headed__browser_console_messages
- mcp__playwright-headed__browser_storage_state
- mcp__claude_ai_Atlassian_MCP__getAccessibleAtlassianResources
- mcp__claude_ai_Atlassian_MCP__getJiraIssue
- mcp__claude_ai_Atlassian_MCP__addOrEditJiraIssueComment
- mcp__claude_ai_Atlassian_MCP__discover
- mcp__claude_ai_Atlassian_MCP__executeRead
---

# Execute Tests

Autonomously executes the test case table for a Jira story using the Playwright MCP browser. No human interaction required after launch — opens the browser, logs in, runs every test step, records evidence, and posts results back to Jira.

**After a context compaction:** if `test-output/<STORY_KEY>/parallel/` exists (the story key is not in your summary: look for `test-output/*/parallel/state.json`), the run may use parallel workers. Run `node "$CLAUDE_PLUGIN_ROOT/skills/test-ticket/scripts/parallel-split.js" status test-output/<STORY_KEY>/parallel` and follow [Parallel Execution](references/parallel-execution.md) from the step it names, but only when its `plan.created_at` is after this run began (an older plan is an earlier run's: ignore it).

> ⛔ **Always use `fullPage: true`.** Every `browser_take_screenshot` call in this skill MUST include the `fullPage: true` parameter. Viewport-only screenshots cut off content below the fold and miss critical evidence — always capture the full scrollable page.

## Step 1: Resolve Inputs

Accept the following arguments:
- `<Jira story ID>` — e.g. `MXTS-74297` (required)
- `<base URL>` — optional; if not provided, browser execution is skipped
- `--skip-review` — optional; skips the batched evidence review in Step 3l
- `--workers=N` — optional override of the automatic parallel mode: `1` turns it off, `2` or `3` limits the browsers — [Parallel Execution](references/parallel-execution.md)

**Host guard (before any browser call):** a `<base URL>` whose host is not `*-dev.maxxton.net` / `*-test.maxxton.net` stops the run here — no prompt, no override — and the browser must stay on dev/test hosts for the whole run (re-check after every navigation and URL-changing click): [Host Guard](references/host-guard.md). **Run metrics:** a local, privacy-scrubbed record at `test-output/<STORY_KEY>/run-metrics.json` (opt out: `QA_ENGINEER_METRICS=off`); start at Step 3, finish at Step 7, every call fail-open (`|| true`): [Run Metrics](references/run-metrics.md).

**No credentials needed.** Log in to the target app in your browser before running — the skill detects your existing session automatically.

Call `getAccessibleAtlassianResources` to get `cloudId`.

Call `getJiraIssue` on the story (with `fields: ["summary", "fixVersions", "status", "assignee", "description", "issuelinks"]`) for the story metadata, then `mcp__claude_ai_Atlassian_MCP__executeRead` (find an unknown operation name first with `mcp__claude_ai_Atlassian_MCP__discover`) with `name: listJiraIssueComments` to retrieve the test case table (v2 `getJiraIssue` does not return comments). `description` and `issuelinks` feed Step 2b's precondition detection.

**Status gate (right after that call, before Step 2 or any browser call):** read the live `status.name` from this response, never from an earlier run's notes. Only `Ready for QA`, `In QA`, `Testing`, `QA in Progress` and `Ready for Testing` run. Any other status (`Reopened`, `Resolved`, `In Progress`, `Open`, …) or an unreadable one ends the run here, with no browser, no environment change and no Jira write. Log: `[execute-tests] <STORY_KEY> is <status> — not QA-stage, nothing executed. Run again once it is Ready for QA or Testing.` This holds for `--retest` too.

**Capture build / version (for audit trail):**

Follow the detection order in `test-ticket/references/preflight-detail.md` → **Build / Version Auto-Detection Script**:
1. Read `fixVersions` from the already-fetched Jira story data (zero extra API calls)
2. Assistance button popup via Playwright MCP
3. DOM heuristic via `browser_evaluate`
4. Ask the user (optional, press Enter to skip) → default: `"Not provided"`

Parse all rows from the TC table comment grouped by functional area — the main table **and**, when present, the **Extended cases added after Human review** table (cases a human asked to add); every row is executed.

**Completeness check (mandatory, immediately after parsing):** Count the TC rows in the raw table text directly (count `TC_ID` cells / row separators in the comment body, not from the parsed object) and compare to the number of TCs extracted. If they don't match, re-parse — **max 2 attempts.** If the count still doesn't match after 2 re-parses (e.g. malformed wiki markup, an unexpected table shape), stop and fail closed: ask the user to paste the raw TC table comment body directly rather than guessing or proceeding with a partial table. Never loop re-parsing beyond 2 attempts. Log: `[execute-tests] Parsed <n> TC rows from Jira comment (functional areas: <list>).` or, on fallback: `[execute-tests] TC row count mismatch after 2 re-parse attempts — asked user to paste the raw table.`

If no test case table is found in Jira comments, ask the user to paste it directly.

---

## Step 2: Login

**Browser availability check (run first):** Call `browser_snapshot` on the bundled Playwright MCP (`mcp__plugin_qa-engineer_playwright__*`).

If those tools are not registered at all but `mcp__playwright__*` or `mcp__playwright-headed__*` is — both enumerated in `allowed-tools` above for exactly this case — use whichever is registered for the whole run instead of stopping: both are the same `@playwright/mcp` server, just under the name the user's own `claude mcp add` gave it. Log `[execute-tests] Bundled Playwright MCP absent; executing on <prefix> instead.` and mention it in the final report so the user still fixes their install. A Playwright MCP registered under some other name is not usable here — a tool call under a prefix not in `allowed-tools` is silently rejected, not routed — so either rename the user's server to one of the two above, or add its tool names to this file's `allowed-tools`. Never substitute a non-Playwright browser tool (claude.ai Chrome tools, Puppeteer, `WebFetch`) — those cannot drive the app.

If **no** Playwright MCP is registered under any prefix, or the call returns a connection error, run the launcher's diagnostic — its output is the diagnosis, so do not guess:

```bash
node "$CLAUDE_PLUGIN_ROOT/mcp/run-playwright.js" --doctor
```

Then stop and print:

```
⚠️ No Playwright MCP available — live execution cannot run.

Diagnosis (from run-playwright.js --doctor):
<paste the BLOCKERS section, or "No blockers found">

Fix:
- Blockers listed → fix those; they are concrete (Chrome missing, Node broken).
- No blockers → fully QUIT and reopen Claude Code (a window reload is not enough —
  MCP tool lists are built once at session start).
- Doctor script not found → your installed plugin predates this fix. Run /plugin list,
  then: /plugin install qa-engineer@maxxton-marketplace --scope user

Re-run after restart: /execute-tests <STORY_KEY> <URL>
Phases 1–2 (test case generation) work without Playwright.
```

Do NOT mark any TCs as BLOCKED — just stop and show the message above.

Call `browser_snapshot` to inspect the current browser state.

- **Current URL starts with `<base URL>` AND no login form visible** → session active, reuse. Log: `[Session] Existing session detected — reusing.` **No human input needed — continue immediately.**
- **Current URL starts with `<base URL>` AND login form visible** → print: `Please log in to the app in the browser window. Reply here once you are logged in.` Wait for confirmation, then save the login (see below). *(This is the only step that requires human input — one time only, per repo — see the saved-login step.)*
- **No match** → call `browser_navigate` to `<base URL>`. Print: `Browser navigated to <base URL>. Please log in, then reply to continue.` Wait for confirmation, then save the login (see below).

**Save the login (only after a fresh login just above — skip when the session was reused):** run `node "$CLAUDE_PLUGIN_ROOT/mcp/run-playwright.js" --storage-state-path` to get this repo's save path, then call `browser_storage_state` with that path as `filename`. This is what lets a second `/execute-tests` or `/test-ticket` run — in a second Claude Code session, testing a different story at the same time — start already authenticated in its own isolated browser instead of prompting for another login or waiting on this one. No further action needed here; the launcher picks the saved file up automatically the next time this repo's profile is locked.

Take a `browser_take_screenshot` (`fullPage: true`) after session confirmed — save as `test-output/<story-key>/session.png`.

If session cannot be confirmed after login, stop and report:
> Could not confirm active session at <base URL>. Please check the URL and try again.

---

## Step 2a: Navigation Cache

First, right after login and before any other setup step (2b–2e) that writes to the environment, run the permission-toggle startup check ([Permission Toggle](references/permission-toggle.md)) so a crashed earlier run cannot leave the shared Maxxton Admin role restricted, and then the feature-flag Startup Restore ([Feature Flag Check](references/feature-flag-check.md)) so a crashed earlier run cannot leave a host-global flag altered while 2b–2d write to the environment. Then, before executing any TC, load the navigation cache — it lets repeat runs against the same environment jump straight to a feature page instead of clicking through the sidebar every time. Follow the full load/lookup/write procedure in [the Navigation Cache reference](references/navigation-cache.md) before starting Step 3; Step 3e's navigate steps apply it cache-first.

---

## Step 2b: Precondition Evidence Check

Before executing any TC, scan the ticket's description/comments/issuelinks for a **ticket-level** precondition — e.g. a companion ticket or fix that must be deployed to this environment before any TC result means anything — distinct from the per-TC data preconditions Step 2d handles. Detect, verify (automated Jira-status check, falling back to an explicit tester confirmation when status can't settle it), and evidence the outcome — including in the Step 6c results comment — before Step 3 starts. Runs first among Steps 2b–2e, ahead of Test Data Setup and Feature Flag Check, so a story about to be blocked wholesale isn't seeded or flag-toggled first. Follow the full procedure in [the Precondition Evidence reference](references/precondition-evidence.md) before starting Step 3.

---

## Step 2c: Integration Manager Setup (Supplier / Reseller Tickets)

Before executing any TC, check whether this ticket is a Supplier/Reseller (Integration Manager) ticket — test credentials, test IDs, link/unlink setup, variable-duration import/export jobs, and cross-module verification all need dedicated handling distinct from a normal TC, and a permanent scope boundary applies to anything needing a third-party client portal. Not an Integration Manager ticket → skip this file entirely, nothing changes. Follow the full procedure, including the credential prompt flow, in [the Integration Manager Setup reference](references/integration-manager-setup.md) before starting Step 3.

---

## Step 2d: Test Data Setup (Seed Required Preconditions)

Before executing any TC, scan the `Preconditions` column of every row in the TC table for entities that must exist — including one needing a specific **state** (e.g. "1+ archived <entity>"), a **quantity** (e.g. "enough <entity> to span 2+ pages"), or a **combination of attributes together on one record** (e.g. "an allotment reservation on a fully-booked accommodation"), not just plain existence. Follow the full seed/reuse/teardown procedure, covering all four precondition shapes, in [the Test Data Setup reference](references/test-data-setup.md) before starting Step 3.

---

## Step 2e: Feature Flag Check

Before executing any TC, scan the TC table for feature-flag language and check Maxxton Admin for any flag found (proactive — cheap head start). Then, per-TC during Step 3, a screen/element that genuinely can't be found after correct navigation always gets one more check against Maxxton Admin, using keywords from the missing element's own name — this reactive check is **mandatory regardless of whether proactive detection found anything explicit in the ticket**. Follow the full procedure in [the Feature Flag Check reference](references/feature-flag-check.md) before starting Step 3 — including its Flag State Reconciliation before any TC that needs a flag ON or OFF.

---

## Step 3: Execute Each Test Case

**Parallel execution is automatic (`--workers=1` turns it off):** run [Parallel Execution](references/parallel-execution.md) first. It decides by itself whether it pays off and falls back to the loop below when it does not. Its workers and its solo phase run Steps 3a–3h for each TC; 3i-2 to 3k and Steps 4–7 then run once on the merged results.

For each test case row in the table, execute the following loop:

### 3a — Setup
Note the TC_ID, scenario, preconditions, steps, and expected result.

**Before-screenshot:** Only take a `browser_take_screenshot` (`fullPage: true`) before starting (save as `test-output/<STORY_KEY>/<TC_ID>-before.png`) on **retry attempts (attempt 2+)**, not on first attempt — saves ~1.5s per TC. Exception: if `--screenshots` flag is passed, capture before+after on every attempt.

### 3b — BLOCKED Criteria and Dependency Model

**BLOCKED vs FAIL — strict definitions:**

| Situation | Verdict | Reason |
|---|---|---|
| Login step fails / session expired | `BLOCKED` | Session dependency — all TCs depend on this |
| Navigation returns 404 / 500 / blank | `BLOCKED` | Environment dependency |
| Required test data missing (entity doesn't exist) | `BLOCKED` | Precondition not met. **Exception:** a TC that needs a user WITHOUT a permission is never `BLOCKED` for "no restricted user" — toggle the permission on the tester's Maxxton Admin role, see [Permission Toggle](references/permission-toggle.md) |
| Ticket-level precondition not confirmed (see [Precondition Evidence](references/precondition-evidence.md)) | `BLOCKED` | Dependency/fix not confirmed deployed to this environment — every TC in the run |
| TC step requires verifying data on a third-party client portal (Booking.com Extranet, Airbnb Developer Portal, etc.) | `BLOCKED` | Permanent scope boundary — see [Integration Manager Setup](references/integration-manager-setup.md). Never retry, never NEEDS REVIEW — manual QA only. |
| Feature not deployed in this environment | `BLOCKED` | Deployment dependency — only reach this after the Reactive Check in [Feature Flag Check](references/feature-flag-check.md) has run for the missing element; a still-missing element after that check genuinely means "not deployed," not "disabled behind an unnamed flag" |
| Domain-specific action step (e.g. "trigger a bill refresh/recalculation") has no matching UI control **after** [Control Discovery](references/control-discovery.md) | `BLOCKED` | Precondition step could not be performed — see Step 3e |
| Step executes but outcome is wrong | `FAIL` | Real bug |
| Element not found after correct navigation | `FAIL` | Real bug |
| Element found but content is incorrect | `FAIL` | Real bug |

**Never mark as FAIL when the root cause is a missing dependency — always BLOCKED.**

**Dependency model — two levels:**

**Level 1 — Login dependency (global):**
If the browser login step (Step 2) fails or the session is lost mid-run:
- Mark **all remaining unrun TCs as `BLOCKED`** with reason: `"Login dependency failed — session unavailable"`
- Stop execution immediately
- Post partial results to Jira
- Do NOT attempt to run any further TCs

**Level 2 — Functional area dependency:**
Within a functional area (e.g. "Create flow"), if the first/setup TC fails completely (not NEEDS REVIEW — an actual FAIL):
- The next TC in the same area that explicitly depends on data created by the failed TC → mark as `BLOCKED` with reason: `"Depends on <TC_ID> which failed"`
- Independent TCs in other functional areas → still run normally

Dependency rule is conservative: only block when the scenario text **explicitly** references the entity that the failed TC was supposed to create. Do not cascade BLOCKED speculatively.

---

### 3c — Execution Scope + Timeouts

**Scope:**
- **No `--max-tcs` flag** → run all TCs in the active order (see below)
- **`--max-tcs=N` flag** → run only the top N TCs by the active order; skip the rest. Log: `[execute-tests] Running top <N> of <total> TCs.`

**Execution order — normal run:** High risk → Medium risk → Low risk

**Scope and order — `--retest` mode:**

`--retest` is a scoped retest, not a full re-run. Read the previous Jira results comments to get each TC's last verdict (a results comment split into parts, each carrying a `_Part n of m_` line, is several comments: read every part). Run the previous `FAIL`, then `NEEDS REVIEW`, then `BLOCKED` TCs first (High → Medium → Low within each); only when every previous `FAIL` now passes, run the High-risk TCs that passed before; the first previous `FAIL` that fails again stops the run. Everything else keeps its previous verdict. Procedure, recording and the Jira comment marking: [Scoped Retest](references/scoped-retest.md). Log: `[execute-tests] --retest scope: <n> failed → <m> High-risk PASS`

After each verdict in retest mode, cross-reference with the previous result:
- Previous `FAIL` → now `PASS` → record as `PASS (previously FAIL — verified fixed)`
- Previous `PASS` → now `FAIL` → record as `FAIL ⚠️ REGRESSION (previously PASS)` — list separately at end of results

**Per-test timeout (default: 3 minutes):**
If a single TC's steps have not completed within 3 minutes (override with `--tc-timeout=N` in seconds):
- Mark the TC as `🚫 BLOCKED (timeout — step hung after <elapsed>s)`
- Do NOT retry — move immediately to the next TC
- Log: `[timeout] <TC_ID> exceeded <N>s — skipping`. This timeout is only checked between tool calls, so every `browser_evaluate` call must stay at most 60 s — see [Progress Reporting](references/progress-reporting.md).

**Global run budget (`--max-time=N` minutes, default 90):**
If the total elapsed time for Phase 3a exceeds the run budget (`--max-time` value if passed, else the 90-minute default):
- Stop execution after the current TC completes
- Mark all remaining unrun TCs as `🚫 BLOCKED (run budget exhausted)`
- Post partial results to Jira with a note: `Run stopped after <N> mins — <n> TCs not executed`
- Continue to Phase 4 with collected results

**Early abort on consecutive failures:**
After **3 consecutive High-risk FAILs**, pause:
```
⚠️ 3 consecutive High-risk failures — possible environment issue.
Continue remaining <n> tests? (yes / no)
```
Only High-risk TCs count toward the counter.

---

### 3d — Test Data Rules (apply before executing any write operation)

Unique `QA-AUTO-<STORY_KEY>-<TC_ID>-` prefix on every entity created, best-effort teardown after each write TC (never fails the result), read-only TCs skip both. Existing records may be read, never edited (the exceptions are the setup actions in the Test Data Setup reference: fill, add, remove and create what a TC needs, logged and put back) — and a repo `CLAUDE.md`'s dummy-data rule for committed specs does not apply to live TCs. Full rules, examples, and log format: [the Test Data Rules reference](references/test-data-rules.md).

---

### 3e — Execute Steps
Start the TC timer first (`tc-start`, see [Progress Reporting](references/progress-reporting.md)), then read the test steps from the table. For each step:

- If the step says **navigate / go to / open**: apply the navigation cache from Step 2a cache-first (see [the Navigation Cache reference](references/navigation-cache.md)) — cache hit → `browser_navigate` straight to the cached URL; cache miss → sidebar navigation as before, then cache the discovered URL
- If the step says **click**: call `browser_click` using the element description — use `browser_snapshot` first to locate the correct accessible element. **A destructive action (Unlink/Delete/Remove/Deactivate) whose confirm control morphs its own label in place** (e.g. "Unlink" → "Are you sure?" → "Confirm" — not a modal) → see [Multi-Stage Confirmation](references/multi-stage-confirmation.md): re-snapshot and re-verify the current label before every click in the sequence, never reuse a stale ref or click by position alone A click that submits a search or applies a filter also follows [Search Result Wait](references/ai-search-result-wait.md) (see the fill bullet below).
- If the step says **fill / enter / type**: call `browser_fill_form` or `browser_type` — for a search/filter/autocomplete field specifically, follow [Search/Filter Input Typing](references/search-input-typing.md) (slow typing, clear-before-type, verify-before-negative-verdict) instead of a plain fill. **Whichever step submits a search — an AI prompt (`mode: 'ai'`) or a normal search/filter (`mode: 'search'`: the debounce after typing, Enter, a `click` on Go/Search/Apply, or a key press)**, follow [Search Result Wait](references/ai-search-result-wait.md) — the count/chip land seconds after submit while the page looks idle, so never reload, reset, screenshot or start the next repeat run until that wait returns
- If the step says **select**: call `browser_select_option`
- If the step says **press / hit key**: call `browser_press_key`
- If the step says **observe / check / verify**: call `browser_snapshot` and inspect the output
- If the step says **verify API / check endpoint / validate response / network call**: use the API validation patterns below — do NOT mark as BLOCKED
- If the step names a **domain action that doesn't match any of the above** (e.g. "trigger a recalculation", "refresh the bill", "reissue the invoice", "cancel booking"): locate the specific control for it (a button/menu item named accordingly) via `browser_snapshot` and perform it — never silently skip a step just because its wording doesn't fit navigate/click/fill/select/press. **The action is destructive/irreversible** (cancel, unlink, delete, remove, deactivate — regardless of whether the step text contains the word "click") → route it through [Multi-Stage Confirmation](references/multi-stage-confirmation.md) exactly like a click step would; a domain-action step name doesn't exempt it from re-snapshotting between confirmation stages. **The control is not on the current screen** → run [Control Discovery](references/control-discovery.md) first (the entity's own screens, the step's own words, the owning module — time-boxed); a control missing from one screen is not proof it does not exist (MXTS-81060). **Still nothing after Control Discovery** → the precondition it sets up is unmet: mark the TC `BLOCKED` with the places checked, rather than proceeding to the assertion as if the action happened. Log `[execute-tests] <TC_ID> step "<step text>" — performed via <control found>` or `— BLOCKED, no matching control (checked: <places>)`.
- If the TC **saves a change to what a reservation is charged** (override rates, add-on, offer/voucher, dates, accommodation, unit, guests, status that reprices): capture the whole bill before the change and again after "Recalculate reservation", VAT included — [Bill Snapshots](references/bill-snapshot.md): `before` snapshot and Before screenshot ahead of the first changing step, a `changed` snapshot right before the recalculation, an `after` snapshot and After screenshot once it is done, then the diff. The recalculation is the TC's own step (Phase 2 puts it there); a TC without one runs as written — no step is added.

**API validation patterns (use instead of marking BLOCKED for network TCs):**

| TC step intent | Tool to use | How |
|---|---|---|
| Verify correct API was called after a UI action | `browser_network_requests(filter: "/api/your-endpoint")` → `browser_network_request(index)` | Trigger the action, then inspect the captured request/response |
| Validate API response body | `browser_network_request(index, part: "response-body")` | Check response matches expected JSON structure |
| Validate API request payload | `browser_network_request(index, part: "request-body")` | Verify the correct data was sent |
| Call an API directly (authenticated) | `browser_evaluate(() => fetch('/api/endpoint', { credentials: 'include' }).then(r => r.json()))` | Uses the existing browser session — no separate auth needed |
| Check response status code | `browser_network_request(index, part: "response-headers")` | Inspect the `status` header |

**API TC verdict rules:**

| Result | Verdict |
|---|---|
| API called, response matches expected body/status | `PASS` |
| API called, response does not match expected | `FAIL` → retry |
| API not called at all after the UI action | `FAIL` — action did not trigger the expected request |
| Response structure ambiguous or partially matches | `NEEDS REVIEW` |

> **Never mark a network/API TC as BLOCKED just because it involves API inspection.** `browser_network_requests` and `browser_evaluate` make API validation fully feasible via Playwright MCP.

After each step, call `browser_snapshot` to verify the page state and detect unexpected errors (error toasts, 500 pages, broken layouts). **If any step above changed price, an addon, or the accommodation type/unit on a reservation** (not other edits like memo/status): run [Resource Reindex](references/resource-reindex.md) before asserting — the search index can lag behind the write and produce a false negative on any check that reads it.

### 3f — Assert Expected Result

After all steps are complete, call `browser_snapshot`.

**The "Expected Result" column from the TC table drives the verdict — but snapshot matching is itself model interpretation, not a deterministic check.** Apply these rules conservatively:

| Snapshot state | Verdict |
|---|---|
| Expected text/element is **clearly present** | `PASS` |
| Expected text/element is **clearly absent** (unambiguous) | Exactly matches a developer's own Jira comment stating this specific behavior is "NOT implemented" with a technical reason → `SKIP` (cite the comment — author, date, reason; no retry); otherwise → `FAIL` → trigger retry (on the final attempt run the [Missing-Field API Cross-Check](references/missing-field-api-check.md) first) |
| Cannot confirm presence or absence with confidence | `NEEDS REVIEW` — do not retry; flag for human |
| Precondition data missing or prerequisite step failed | `BLOCKED` — do not retry; note the blocker |

**When in doubt, use `NEEDS REVIEW`.** Do not force a PASS or FAIL verdict when the snapshot is ambiguous — the human reviewer is the real authority. `NEEDS REVIEW` is not a failure; it is the correct signal for uncertain observations.  **Negative assertions need the positive state first:** never `PASS` a "hidden / not shown / no longer visible / disabled" expectation unless the same TC also showed the positive state in its own screenshot (an empty result looks identical to a broken page); unreachable → `NEEDS REVIEW` — [Evidence Review](references/evidence-review.md).

**PASS corroboration (applies only when snapshot verdict is PASS):**

**Default (no flag):** Applies only to **High-risk write TCs** — TC involves a write operation (form submit, save, create, delete, update), verdict is PASS, and the TC's Risk column is `High`. Skip for Medium/Low-risk write TCs and all read-only/view TCs.

When corroboration applies:

1. `browser_network_requests` → scan requests triggered by this TC's final action. If any response has status `4xx` or `5xx`:
   → Downgrade to `NEEDS REVIEW 🔍 — UI showed success but API returned <status>; verify data was actually saved`

2. `browser_console_messages` → check for `error`-level console messages since the last TC started. If any found:
   → Downgrade to `NEEDS REVIEW 🔍 — UI passed but console errors detected: <error summary>`

If both checks are clean → keep `PASS`.

### 3g — Retry Logic (FAIL only)

On a `FAIL` verdict, re-run the TC from step 3a before recording the final result:

- **Attempt 2:** Re-execute all steps from scratch. Re-assert.
  - Passes → record `PASS (flaky — passed on attempt 2)`, flag in triage
  - Fails again → attempt 3
- **Attempt 3:** Re-execute all steps from scratch. Re-assert.
  - Passes → record `PASS (flaky — passed on attempt 3)`, flag in triage
  - Fails again → record `FAIL (confirmed, 3/3 attempts)`

Do NOT retry `NEEDS REVIEW`, `BLOCKED`, or `SKIP` — the first two require human intervention, and a `SKIP` already has its answer. **Never blindly retry a failed [multi-stage destructive confirmation](references/multi-stage-confirmation.md)** without first confirming the prior attempt had no side effect (re-executing re-runs the destructive click sequence too, risking a second wrong record) — verify the intended target's actual state first, and mark `NEEDS REVIEW` instead of retrying if unclear.

### Debug Evidence Capture (after the final verdict above, before Record Result in 3h)

For `FAIL`, `BLOCKED`, and `NEEDS REVIEW` verdicts (including a PASS downgraded by PASS Corroboration above) — a bare screenshot often isn't enough to diagnose *why* something failed. Follow [the Debug Evidence Capture reference](references/debug-evidence-capture.md) to pull in sanitized network/console context before recording the result below. Skip entirely for a plain `PASS` with no downgrade.

### 3h — Record Result

**TC's observation is on a reservation's Finance/Bill screen** → apply [the Finance/Bill Screenshots reference](references/finance-bill-screenshots.md) first — its VAT/total rows sit in an internally-scrolling table that `fullPage: true` silently crops out.

Take a `browser_take_screenshot` (`fullPage: true`) — save as `test-output/<STORY_KEY>/<TC_ID>-result.png`. Once the verdict is final, show the user the running table: every TC finished so far, and what is still pending (`tc-end`, see [Progress Reporting](references/progress-reporting.md)).

**Exception — multi-item TCs: one screenshot per item actually verified, never a single sample standing in for the rest.** If this TC's Scenario or Expected Result names 2+ discrete items to verify individually (e.g. "each remaining supported language: Spanish, Italian, English (US)", "every user role") — execute and observe **every** named item, not a subset, and take one screenshot per item as `test-output/<STORY_KEY>/<TC_ID>-<item-slug>.png` (e.g. `TC_12-spanish.png`, `TC_12-italian.png`, `TC_12-english-us.png`). Never generalize one item's clean result to the others and mark PASS on a single sample. If time constraints mean not every named item could actually be tested this run, record `NEEDS REVIEW` and state exactly which items were verified and which weren't — not a PASS on partial coverage. If any one item fails while others pass, the TC's verdict is `FAIL` — keep the screenshot for every item checked, passing or failing.

**Exception — two-state TCs: one screenshot per state the Expected Result needs to see.** When the Expected Result can only be proven by two states (a switch between two views or modes such as Cards and Table, a choice that must survive a reload or leaving the page, a before and after of a delete or save, an element that must stay visible while scrolling) or is a negative assertion (positive state first, see [Evidence Review](references/evidence-review.md)), treat the states as items of a multi-item TC: `test-output/<STORY_KEY>/<TC_ID>-<state-slug>.png` (e.g. `TC_10-cards.png`, `TC_10-table.png`, `TC_16-after-reload.png`). One end-state shot is not enough: the Evidence Review sends that PASS back to `NEEDS REVIEW`.

**Exception — comparison TCs: one screenshot per source, showing the specific value read, not a single end-state shot.** If the Scenario/Expected Result requires reading a value on one screen/document and checking it against a value on a **different** one — e.g. "the Reservation Manager's Total VAT per rate match the invoice's VAT-by-rate summary" — treat it as a comparison TC: screenshot each source separately with the value clearly in frame (scroll/zoom it into view — a pass/fail-icon thumbnail is not evidence), named `test-output/<STORY_KEY>/<TC_ID>-<source-slug>.png` (e.g. `TC_01-widget.png`, `TC_01-invoice.png`). **A TC that is also multi-item** (2+ named items, each compared across the same sources) → qualify by item too: `<TC_ID>-<item-slug>-<source-slug>.png` (e.g. `TC_12-spanish-widget.png`, `TC_12-spanish-invoice.png`, `TC_12-italian-widget.png`, `TC_12-italian-invoice.png`) — a bare source label collides across items the same way a bare `<TC_ID>` collides across sources. **A Finance/Bill or invoice source** → see [the Finance/Bill Screenshots reference](references/finance-bill-screenshots.md) above (large-viewport capture, plus converting a downloaded invoice PDF to PNG when it isn't a live page). State the literal value read from each source in the Actual Result, not just "confirmed match" (e.g. `RM widget: EUR 5,311.08; Invoice: EUR 5,311.08 — match`). **A TC that is also multi-item** → state every item's own pair of values, not just one (e.g. `Spanish — widget: 5,311.08, invoice: 5,311.08, match. Italian — widget: 128.10, invoice: 128.08, mismatch.`) — never collapse multiple items' values down to a single pair as if only one item existed. Values don't match → `FAIL`, keep both screenshots.

**Exception — bill-changing TCs: a Before/After screenshot pair, not one result screenshot.** A TC that saves a change to a reservation's bill takes `test-output/<STORY_KEY>/<TC_ID>-bill-before.png` before the first changing step and `<TC_ID>-bill-after.png` after the recalculation — each a Finance/Bill large-viewport capture — instead of `<TC_ID>-result.png`. [Bill Snapshots](references/bill-snapshot.md) has when this applies, how the snapshots are taken and how the diff can set `NEEDS REVIEW` or `FAIL`. Put the exact before-to-after differences in the Actual Result.

Record:

```
TC_ID:    <TC_ID>
Scenario: <scenario text>
Result:   ✅ PASS | ❌ FAIL | 🔍 NEEDS REVIEW | 🚫 BLOCKED | ⏭️ SKIP
Reason:   <one line — what matched, what went wrong, or why ambiguous>
Attempts: <1 / 2 / 3> (only shown for FAIL or flaky PASS)
```

Status rules:
- ✅ `PASS` — expected result clearly present in snapshot, or `PASS (flaky)` if it failed on attempt 1 and passed on retry
- ❌ `FAIL (confirmed, 3/3)` — failed all 3 attempts
- 🔍 `NEEDS REVIEW` — snapshot ambiguous; human must verify
- 🚫 `BLOCKED` — precondition could not be met; test could not run
- ⏭️ `SKIP` — matches a developer's own documented "NOT implemented" comment; cite it, no retry


### 3i — Capture Extra Test Cases

During execution, if you encounter a behaviour worth testing that is NOT covered by any row in the original test case table — for example, an adjacent validation, an edge case exposed by the current state, or a related UI interaction — execute it immediately and record it as an extra test case.

Assign the TC_ID as `EXTRA_01`, `EXTRA_02`, etc. (continuous across the run).

Take a `browser_take_screenshot` (`fullPage: true`) — save as `test-output/<STORY_KEY>/EXTRA_<n>-result.png`.

Record using the same format as 3h (including emoji and screenshot reference):

```
TC_ID:    EXTRA_01
Scenario: <specific "Verify we are [not] able to..." statement>
Result:   ✅ PASS | ❌ FAIL | 🚫 BLOCKED
Reason:   <one line>
```

Keep a running list of all extra test cases throughout the run.

---

### 3i-2 — Evidence Review (High-risk PASS TCs, before the NEEDS REVIEW gate)

After the last TC and before 3j, unless `--skip-review` was passed, hand every `High`-risk TC that finished `PASS` to one fresh reviewer subagent that looks at the screenshots without seeing your reasoning. It can only downgrade a PASS to `NEEDS REVIEW` (a missing control, an empty result taken as proof, a screenshot that stops before the outcome) — which then goes through 3j like any other NEEDS REVIEW. A reviewer that fails or returns nothing usable leaves the PASS in place and is reported, never counted as a pass. Packet format, reviewer prompt, the 15-TC cap and failure handling: [the Evidence Review reference](references/evidence-review.md).

### 3j — NEEDS REVIEW Resolution Gate

After all TCs complete (and 3i-2 has run), collect every TC with verdict `NEEDS REVIEW`.

**If none** → skip this gate, proceed to 3k.

**If any exist** → print the structured review block (format: [the output formats reference](references/output-formats.md) → NEEDS REVIEW Resolution Block) and wait for explicit human verdicts.

**Commands:**
- `pass <TC_ID>` → update verdict to `PASS ✅ — confirmed by human review`
- `fail <TC_ID>` → update verdict to `FAIL ❌ — confirmed by human review` (enters retry + triage flow)
- `skip <TC_ID>` → keep as `NEEDS REVIEW 🔍` (will appear in triage for manual follow-up)

**`--unattended` flag:** Skip this gate entirely. All NEEDS REVIEW verdicts stay as-is and flow into triage.

**User-aborted run:** If the user explicitly stopped the run mid-way (said "stop" or answered "no" at the consecutive-fails early-abort prompt), skip this gate — all NEEDS REVIEW verdicts pass through as-is. Do not prompt for human verdicts on a stopped run.

---

### 3k — Completeness Gate (mandatory, before declaring the run complete)

Before printing the results table (Step 5) or telling the user the run is done, verify 100% coverage:

1. Re-read the original TC table comment (from Jira, not from memory) and list every `TC_ID` it contains.
2. Cross-check against the TC_IDs that received a recorded verdict in this run.
3. **Any `TC_ID` present in the table but missing a verdict** → execute it now (Steps 3a–3h) before continuing. Do not defer it and do not report the run as finished until it has a verdict.
4. Exception: if `--max-tcs=N` was passed, TCs beyond the top-N cap are expected to be missing — they are not gaps.
5. **Any `TC_ID` currently verdict `BLOCKED` for "not deployed"/"could not locate"** → confirm the Reactive Check in [Feature Flag Check](references/feature-flag-check.md) actually ran for it (a `[FeatureFlag] Reactive check` log line naming that TC's missing element). No such line → run it now before finalizing. This is the last checkpoint before results are posted.

Log: `[Completeness] <n>/<n> in-scope TCs verified — 0 missing.` or, if gaps were found and fixed: `[Completeness] <n> TC(s) were missing a verdict — executed now: <TC_IDs>.`

> **Why this exists:** long TC tables (multiple functional areas, 20+ rows) are the case most likely to get silently under-parsed at Step 1. This gate re-checks mechanically against the source table rather than trusting the running count, so gaps get caught and closed automatically instead of surfacing only when the user asks "are you sure you got everything?".

---

## Step 4: Reset Between Tests

After each test case, navigate back to the base URL or a neutral starting page to avoid state leaking between tests. For TCs with repeated runs of a search (AI prompt or normal search/filter), apply the same reset between runs only after the previous run's result has settled ([Search Result Wait](references/ai-search-result-wait.md)).

If a test requires a specific precondition (e.g. a workflow to exist, or a reservation with a linked customer), and that data cannot be created via the UI in a reasonable number of steps, mark the test as **BLOCKED** and move to the next one.

---

## Step 5: Output Results Table

After all test cases are executed, output a results table — exact shape in [the output formats reference](references/output-formats.md).

**Write results to disk:** After printing the table above, write two files — a local record of the run, and the selector source `/generate-playwright-tests` reads ("Real selectors from execute-tests log"). These are per-story files under `test-output/<STORY_KEY>/`; `/test-ticket` keeps its own per-Epic state under `test-output/<EPIC_ID>/` in a different shape and does not read these:

- `test-output/<STORY_KEY>/results.md` — the full results table above (verbatim)
- `test-output/<STORY_KEY>/execution-log.json` — one entry per TC:
  ```json
  [
    {
      "tc_id": "TC_01",
      "verdict": "PASS",
      "selectors": ["[aria-label='Save customer']", "#customer-name"],
      "scenario": "<scenario text>"
    }
  ]
  ```
  `selectors` lists every CSS/aria selector successfully interacted with during the TC steps. Leave as `[]` for BLOCKED TCs.

**Write the navigation cache:** immediately after `execution-log.json`, merge the in-memory cache from Step 2a into `test-output/nav-cache.json` — see the Write section of [the Navigation Cache reference](references/navigation-cache.md).

---

## Step 6: Post Results to Jira

> **Comment target lock:** Every `addOrEditJiraIssueComment` call in this step MUST use the exact `<STORY_KEY>` provided as the argument to this skill (e.g. `MXTS-76746`). Never post to a sub-task, parent Epic, linked issue, or any other ticket key — regardless of what `getJiraIssue` returns in `subtasks`, `parent`, or `issuelinks` fields.

### 6a — Fetch the original test case comment

Read the comments on `<STORY_KEY>` with `mcp__claude_ai_Atlassian_MCP__executeRead` with `name: listJiraIssueComments`. Find the most recent comment containing the test case table (look for a comment with `TC_ID` and `Test case scenario`). Note its comment ID. A test case table split into parts (each part carries a `_Part n of m_` line) is several comments: read every part and merge the rows.

### 6b — Build the results table

Build a 6-column results table from the execution record:

| Column | Source |
|---|---|
| **TC_ID** | TC_ID from the original TC table (e.g. TC_01) |
| **Test case scenario** | Scenario text from the original TC table |
| **Expected Result** | Expected result from the original TC table |
| **Actual Result** | One-line description of what actually happened. Never write a literal pipe character (`|`) in this cell, escaped or not — it corrupts the table row either way. Describe boolean/logical conditions in words ("OR"/"AND") instead of `||`/`&&` symbols. A bill-changing TC (see 3h) writes `Before to after: <summary>. Recalculation alone: <summary>.` using the `summary` line of `bill-diff.js` (it never contains a pipe). |
| **Status** | `PASS ✅` / `FAIL ❌` / `NEEDS REVIEW 🔍` / `BLOCKED 🚫` / `SKIP ⏭️` |
| **Test Proof** | Screenshot filename — `<TC_ID>-result.png` (e.g. `TC_01-result.png`). Tester attaches from `test-output/<STORY_KEY>/` manually. **Multi-item TC** (see the exception in 3h) → list every item's filename **on one line**, separated by `; ` — never a literal line break inside the cell, that ends the table row instead of breaking within it (this table is posted as a plain GFM markdown table via `addOrEditJiraIssueComment`, not Jira wiki markup, so there is no forced-line-break token available here the way `/test-ticket` has): `Spanish: TC_12-spanish.png; Italian: TC_12-italian.png; English (US): TC_12-english-us.png` — never fewer filenames than items actually verified. **Comparison TC** (see the exception in 3h) → same one-line, semicolon-joined format, labeled by source instead of item: `Widget: TC_01-widget.png; Invoice: TC_01-invoice.png`. **Comparison TC that is also multi-item** → qualify each label by item: `Spanish Widget: TC_12-spanish-widget.png; Spanish Invoice: TC_12-spanish-invoice.png; Italian Widget: TC_12-italian-widget.png; Italian Invoice: TC_12-italian-invoice.png` — a bare source label alone (`Widget:`/`Invoice:`) is ambiguous once 2+ items repeat the same sources. **Bill-changing TC** (see the exception in 3h) → `Before: TC_01-bill-before.png; After: TC_01-bill-after.png`, same one-line, semicolon-joined format |

If extra test cases were recorded in Step 3i, append them after the original rows with the scenario prefixed with `**[EXTRA]**`.

### 6c — Post the results comment

Call `addOrEditJiraIssueComment` with the following format. **Pass rate = Passed / (Total TCs − Blocked − Skipped).** If that denominator is `0` (every TC ended up BLOCKED and/or SKIP — nothing was actually pass/fail-tested) → write `N/A (no TC verified)` for Pass rate instead of a computed percentage; never divide by zero or leave the cell blank.

```
## QA Test Results — <STORY_KEY>

| | |
|---|---|
| **Build / Version** | <build_version> |
| **Preconditions** | <semicolon-joined summary from `preconditions-verified.json` — see [Precondition Evidence](references/precondition-evidence.md) — or "None detected"> |
| **Total TCs** | <n> |
| **Passed** | <n> |
| **Failed** | <n> |
| **Blocked** | <n> |
| **Needs Review** | <n> |
| **Skipped** | <n> |
| **Pass rate** | <n>% (BLOCKED and Skipped excluded) |
| **QA Pipeline Version** | <`version` field read from `${CLAUDE_PLUGIN_ROOT}/.claude-plugin/plugin.json` — the qa-engineer plugin's own version, distinct from the app's Build/Version above> |

| TC_ID | Test case scenario | Expected Result | Actual Result | Status | Test Proof |
|---|---|---|---|---|---|
<all rows — Test Proof cell per 6b's rules: plain <TC_ID>-result.png for an ordinary TC, or the semicolon-joined multi-item/comparison format for one>
| EXTRA_01 | **[EXTRA]** Verify we are able to ... | <expected> | <what happened> | PASS ✅ | EXTRA_01-result.png |
<remaining EXTRA rows if any>
```

If there are no extra test cases, omit the EXTRA rows entirely.

**Validate before every post, and split long tables.** Save the body with the Write tool and run `node "${CLAUDE_PLUGIN_ROOT}/skills/test-ticket/scripts/validate-results-comment.js" <body_file> --kind exec --story <STORY_KEY>` (exit 1 → rebuild from the template it prints). More than 45 TC rows → Jira would reject one comment (32,767 characters), so post it in parts instead: [the split results reference](references/split-results.md). 45 or fewer → one comment as above.

### 6d — Screenshot filenames in Test Proof column

Screenshots are saved locally at `test-output/<STORY_KEY>/<TC_ID>-result.png` for an ordinary TC — or, for a multi-item/comparison TC (see 3h), one file per item/source under the same directory, named per 3h's convention (e.g. `TC_01-widget.png` + `TC_01-invoice.png`) — and for a bill-changing TC the pair `TC_01-bill-before.png` + `TC_01-bill-after.png`. Every filename referenced in the Test Proof column is already populated in the results comment (Step 6c) — no upload needed. Tester attaches whichever files that TC's Test Proof cell lists from `test-output/<STORY_KEY>/` when needed — a multi-item/comparison TC needs every listed file attached, not just one.

### 6e — Feature Flag Teardown

Restore every flag this run itself changed — disable the ones it switched on, re-enable the ones it switched off — see the Teardown procedure in [the Feature Flag Check reference](references/feature-flag-check.md). Skip entirely if neither `test-output/<STORY_KEY>/flags-enabled.json` nor `test-output/<STORY_KEY>/flags-disabled.json` exists. Whether or not that teardown ran, then, last of all and on every way the run ends, close the browsers this run opened: [Browser Close](references/browser-close.md).

---

## Step 7: Confirm

Confirm to the user:
> Test run complete. <n> passed, <n> failed, <n> blocked. <n> extra test cases discovered during execution. Results posted to <STORY_KEY>.

If called standalone (not via `/test-ticket`):
> Run `/triage-defect` to classify failures and raise defects.

If called via the `/test-ticket` pipeline, Phase 4 (triage) runs automatically — skip this prompt.
