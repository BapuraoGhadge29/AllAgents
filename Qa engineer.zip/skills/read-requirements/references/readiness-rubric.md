# Requirements Readiness Rubric

Score 1 point per criterion met:

| Criterion | Score |
|---|---|
| At least 2 specific, non-vague ACs (not "system should work correctly") | +1 |
| At least one AC states an explicit expected outcome (what exactly happens) | +1 |
| At least one negative/error/edge case covered | +1 |
| User role or permission context mentioned | +1 |

**Score 3–4** → sufficient — proceed to test case generation.

**Score 0–2** → insufficient — block generation, output kickback report, post to Jira.
