---
name: generate-reports
description: Generates a QA test run report from triage and defect data. Creates a Confluence page with full results and outputs DOCX-ready Markdown plus a PPT slide script to paste into Word or PowerPoint (no binary files). Use when producing QA documentation after a test run is complete.
disable-model-invocation: true
argument-hint: "[Jira story ID] and paste triage report"
allowed-tools:
- mcp__claude_ai_Atlassian_MCP__getAccessibleAtlassianResources
- mcp__claude_ai_Atlassian_MCP__getJiraIssue
- mcp__claude_ai_Atlassian_MCP__createConfluenceContent
- mcp__claude_ai_Atlassian_MCP__searchConfluence
- mcp__claude_ai_Atlassian_MCP__discover
- mcp__claude_ai_Atlassian_MCP__executeRead
---

# Generate Reports

Produces a QA test run report: a Confluence page with detailed results, DOCX-ready Markdown output (copy into Word), and a PPT slide script (copy into PowerPoint or Copilot). No binary files are created.

## Step 1: Resolve Inputs

Call `getAccessibleAtlassianResources` to get `cloudId`.

Collect:
- Jira story key (from argument)
- Triage report (pasted by user or from `triage-defect` output). If the report includes API-focused TCs (network response validation, HTTP status assertions), classify their failures under "Tooling Misreads" or "Product Defects" as applicable — describe the failure using the API endpoint and response code, not a DOM element.
- List of raised Jira defect keys (from `raise-defect` output)

Call `getJiraIssue` on the story to extract:
- Summary, Epic key, description, acceptance criteria, status, assignee, sprint, **issue type**

---

## Step 2: Generate Confluence Page

**Only perform this step if the Jira issue type is `Story` or `New Feature`.** For `Bug`, `Task`, `Improvement`, or any other type, skip to Step 3.

> Reasoning: Confluence QA pages document new functionality for future reference. Bug fixes and tasks do not produce new feature documentation.

Call `searchConfluence` to find if a QA space or parent page exists (search for "QA Reports" or "Test Reports" in the space).

Call `mcp__claude_ai_Atlassian_MCP__executeRead` (find an unknown operation name first with `mcp__claude_ai_Atlassian_MCP__discover`) with `name: getContentFormatGuide` (inputs `{toolName: "createConfluenceContent"}`) once, then call `createConfluenceContent` with `body: {format: markdown, value}` using the following content:

**Title:** `QA Test Report — <STORY_KEY>: <Story Summary>`

**Content:**

```
# QA Test Report

| Field | Value |
|---|---|
| Story | <STORY_KEY>: <story summary> |
| Epic | <EPIC_KEY> |
| Test run date | <date> |
| Environment | <environment or "Not specified"> |
| Tested by | QA Bot (automated) |
| Status | <PASS / FAIL / PARTIAL> |

---

## Test Execution Summary

| Metric | Count |
|---|---|
| Total test cases | <n> |
| Passed | <n> |
| Failed | <n> |
| Tooling misreads / test case issues (excluded) | <n> |
| Real product defects | <n> |
| Needs manual review | <n> |
| Pass rate | <percentage> |

---

## Failed Tests — Product Defects

| TC_ID | Test Case | Defect Raised | Severity |
|---|---|---|---|
| <TC_ID> | <test case scenario> | <BUG_KEY> | <priority> |
...

---

## Tooling Misreads / Test Case Issues (Not Product Defects)

| TC_ID | Classification | Recommended Fix |
|---|---|---|
| <TC_ID> | <Tooling Misread | Test Case Issue> | <recommended fix> |
...

---

## Coverage Gaps

<coverage gaps from generating-test-cases output, or "None identified">

---

## Acceptance Criteria Coverage

| Acceptance Criterion | Covered by Test Case | Status |
|---|---|---|
| <criterion> | <TC_ID> | Pass / Fail / Not covered |
...

---

## Linked Artefacts

- Jira story: <STORY_KEY>
- Defects raised: <comma-separated BUG_KEYs>
- Playwright spec PR: <PR URL if available>
- Triage report: Attached below

---

## Raw Triage Report

~~~
<full triage report text>
~~~
```

---

## Step 3: Generate DOCX Report Content

Output a formatted DOCX-ready document as structured Markdown the user can copy into Word or export:

```
# QA Test Report
## <STORY_KEY>: <Story Summary>
### Test Run Date: <date>

---

## Executive Summary
<2–3 sentence summary of the test run outcome, pass rate, and defects found>

## Test Results
| TC_ID | Test Case | Result | Defect |
|---|---|---|---|
| TC_01 | <scenario> | Pass | — |
| TC_02 | <scenario> | Fail | <BUG_KEY> |
...

## Defects Summary
| Defect Key | Summary | Severity | Status |
|---|---|---|---|
| <BUG_KEY> | <summary> | <priority> | Open |

## Coverage Gaps
<gaps or "None identified">

## Recommendations
- <actionable recommendation 1>
- <actionable recommendation 2>
```

---

## Step 4: Generate PPT Deck Content

Output a slide-by-slide PowerPoint deck script (structured text, ready for Copilot or PowerPoint Designer to render):

```
SLIDE 1 — TITLE
Title: QA Test Report
Subtitle: <STORY_KEY>: <Story Summary>
Date: <date>

SLIDE 2 — SUMMARY
Heading: Test Execution Summary
Bullet 1: Total tests run: <n>
Bullet 2: Pass rate: <percentage>
Bullet 3: Product defects found: <n>
Bullet 4: Tooling misreads / test case issues (excluded): <n>

SLIDE 3 — DEFECTS
Heading: Defects Raised
Table:
| Defect | Summary | Severity |
| <BUG_KEY> | <summary> | <priority> |
...

SLIDE 4 — COVERAGE GAPS
Heading: Coverage Gaps
<bullet list of gaps, or "No gaps identified">

SLIDE 5 — RECOMMENDATIONS
Heading: Recommendations & Next Steps
Bullet 1: <recommendation>
Bullet 2: <recommendation>

SLIDE 6 — LINKS
Heading: Artefacts
Bullet 1: Jira story: <STORY_KEY>
Bullet 2: Confluence report: <page URL>
Bullet 3: Playwright PR: <PR URL>
```

---

---

## Step 5: Confirm

Confirm to the user:
> Reports generated:
> - Confluence page: <URL> *(only if Story or New Feature — omit for Bug/Task)*
> - DOCX content: displayed above (copy into Word)
> - PPT deck: displayed above (paste into PowerPoint or Copilot Designer)
> If a Playwright spec PR was created in Phase 6 of `/test-ticket`, run `/review-pr` to review and merge it.
