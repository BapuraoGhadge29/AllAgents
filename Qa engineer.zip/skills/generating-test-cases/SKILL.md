---
name: generating-test-cases
description: Generates structured manual test cases and identifies coverage gaps from a requirement summary produced by read-requirements, or directly from a Jira story. Produces a Jira-ready test case table. Use when generating manual test cases from a requirements summary or Jira story.
disable-model-invocation: true
argument-hint: "[Jira story ID] [--extend] or paste requirement summary"
allowed-tools:
- Bash
- mcp__claude_ai_Atlassian_MCP__getAccessibleAtlassianResources
- mcp__claude_ai_Atlassian_MCP__getJiraIssue
- mcp__claude_ai_Atlassian_MCP__discover
- mcp__claude_ai_Atlassian_MCP__executeRead
- mcp__claude_ai_Atlassian_MCP__addOrEditJiraIssueComment
- mcp__claude_ai_Atlassian_MCP__editJiraIssue
- mcp__claude_ai_GitHub__search_pull_requests
- mcp__claude_ai_GitHub__pull_request_read
---

# Generate Test Cases

**Extend mode (`--extend`):** `/generating-test-cases <STORY_KEY> --extend` regenerates nothing. A human lists the cases or validations Claude missed; Claude answers each one (accepted / already covered / declined), and the accepted ones go into a separate section of the existing Test Cases comment — **Extended cases added after Human review** — with the counts and miss rate. Skip Steps 1–9 and follow [the Extended Cases reference](references/extended-cases.md).

## Configuration
<!-- Edit once for your team's Jira workflow — the skill reads from this block -->

```yaml
# ⚠️ MUST KEEP IN SYNC with test-ticket Configuration block (same status buckets, same critical_paths).
# When you change status_mapping or critical_paths here, update test-ticket/SKILL.md too.
status_mapping:
  development_stage:
    - Open
    - In Progress
    - To Do
    - In Development
    - Resolved
    - Reopened
    - Waiting for support
    # Done statuses — test cases only; test-ticket --force promotes these to qa_stage
    - Checked by QA
    - Cannot Test
    - Closed

  qa_stage:
    - Ready for QA
    - In QA
    - Testing
    - QA in Progress
    - Ready for Testing

# Fallback bucket for any status not listed above
# Options: development_stage | qa_stage
default_bucket: development_stage

# Critical business paths — any TC whose scenario matches a keyword below is
# automatically assigned High risk, overriding the LLM heuristic.
# Derived from Maxxton MCMS service graph (reservation-service, payment-manager-service,
# customer-service, frontoffice-manager-client, finance-manager-service).
# ⚠️  Word-boundary match — keywords must match as whole words, not substrings.
# "login" matches "Login form submission TC" but must NOT match "verify-login-page-font".
# Prefer multi-word phrases (e.g. "down payment") for single words that appear in unrelated TCs.
critical_paths:
  - reservation
  - booking
  - payment
  - invoice
  - down payment
  - customer creation
  - customer contact
  - check-in
  - check-out
  - arrival
  - departure
  - authentication
  - login
  - logout
  - finance
  - work order
  - supplier
  - distribution channel
  - resort
  - resource allocation
  - reallocation
  - loyalty points
  - reseller
```

---

Generates a complete, structured manual test case suite from requirements. Input can be a Jira story ID or a requirement summary from `read-requirements`.

## Step 1: Resolve Input

If a Jira story ID is provided:
- Call `getAccessibleAtlassianResources` to get `cloudId`
- Call `getJiraIssue` with `fields: ["summary", "description", "subtasks", "issuelinks", "fixVersions", "components", "labels", "priority", "status", "assignee", "reporter"]`
- **Label guard (run immediately after fetching):** Inspect the `labels` array. If `HL-Scenarios_Covered` is present → stop and inform the user:
  > Test cases already generated for `<story key>` (`HL-Scenarios_Covered` label present). Re-run is skipped. If you want to regenerate, remove the label first.
- Extract: summary, description, acceptance criteria, status, Epic key, `components[].name`, `fixVersions[].name`
- **All comments:** Read them with `mcp__claude_ai_Atlassian_MCP__executeRead` (find an unknown operation name first with `mcp__claude_ai_Atlassian_MCP__discover`) with `name: listJiraIssueComments` (v2 `getJiraIssue` does not return comments), then scan every comment in full regardless of author or format — extract any text naming UI locations, flows, API endpoints, edge cases, out-of-scope statements, or implementation scope details. Do not skip a comment because it lacks a "Quick summary" heading.
- **Subtasks:** For each entry in `subtasks[]`, call `getJiraIssue` with `fields: ["summary", "description", "status"]` (comments via `listJiraIssueComments` as above). Each subtask summary is a discrete test area — treat it as a separate functional area in Step 4.
- **Linked issues:** For each Bug-type entry in `issuelinks[]`, call `getJiraIssue` to read the description. Each linked Bug names a regression scenario — include it in Step 4 under a "Regression" functional area.
- **Linked PR:** Jira remote-links are frequently empty even when a PR exists — do not rely on `mcp__claude_ai_Atlassian_MCP__executeRead` with `name: listJiraIssueRemoteIssueLinks` alone. Also call `search_pull_requests` for `<story key>`. If a PR is found, call `pull_request_read` (`get_diff`) and extract concrete implementation facts — error codes/messages, business-rule branching, field/type exclusions. Set `story.has_pr = true`; otherwise `false`.
- **Out-of-scope sections:** Extract any `Out of scope`, `Known limitations`, `Assumptions` sections from the description. These are explicit TC exclusions — do NOT generate TCs for these items.
- **Feature flag references:** Scan the description and every comment for feature-flag language — "feature flag", "toggle", "flag", a flag name in backticks/code formatting, or phrasing like "must only be shown when X is enabled/disabled". Extract each distinct flag name into `story.feature_flags` (a list — a story can reference more than one). No flag language found → `story.feature_flags` stays empty; Step 4 generates no flag-gating group.

- **Developer QA template and change types:** Follow sub-steps 3l (the developer's "For QA:" comment — Major Impact, Main Tests, Concerns, Additional Notes, including following a "re-test this QA template: <link>" or "requirements found in <link>" pointer one hop) and 3m (change-type signals: `i18n`, `api_only`, `multi_repo`, `widget`) in [the Phase 1 context extraction reference](${CLAUDE_PLUGIN_ROOT}/skills/test-ticket/references/phase-1-context-extraction.md) — same rules, same `story.dev_qa` / `story.change_types` results. No such comment → `story.dev_qa` is null; no signals → `story.change_types` is empty and Step 4 generates none of the change-type groups.

If a requirement summary is pasted directly:
- Use the summary as-is, including any `SUBTASK SCOPE`, `LINKED BUG CONTEXT`, `OUT OF SCOPE`, `FEATURE FLAGS`, `DEVELOPER QA NOTES` and `CHANGE TYPES` sections if present — these map directly to separate functional areas, TC exclusions, `story.feature_flags`, `story.dev_qa` and `story.change_types` in Step 4.

**Source priority & grounding rule — applies from here through Step 6:**
- **`story.has_pr = false`:** Generate strictly from `description` + `priority`. Comments still set business scope (which flows/fields are in play), but their unconfirmed technical claims — exact error codes/messages, internal method/branch names, field/type exclusion rules — must NOT be written into Expected Result as fact. State the behavioral outcome only (e.g. "a validation error is shown"), never an invented specific, unless the ticket text quotes it directly.
- **`story.has_pr = true`:** Use description + comments + PR together. Implementation facts confirmed in the PR diff (error codes, exact messages, business-rule branches) may be written into Expected Result directly, grounded in the code.
- **AC vs comment reconciliation (runs before Step 4, both `has_pr` values):** A newer developer/PM/BA comment that contradicts an acceptance criterion **overrides that AC** — same rule a manual tester follows. Compare every AC line against every comment, oldest to newest; the latest comment on the same behaviour wins. Applies to observable behaviour (enabled/disabled, selected/deselected, visible/hidden, ordering, defaults) even when `has_pr = false`; the `has_pr = false` restriction above still covers only unconfirmed technical specifics (error codes, internal names). Generate TCs from the overriding behaviour only — never one TC from the AC and another from the comment for the same behaviour. Record each override as `{ ac, overridden_by: "<author>, <date>", new_behaviour }` in `story.ac_overrides` (the TC table has no Notes column, so the override is not restated inside a TC). A comment that only *adds* scope is not an override. Unclear whether a comment overrides or only adds → keep the AC behaviour and flag it as a Phase 2 coverage gap for the user to confirm.
- **`priority` calibrates scope when there is no PR:** `Highest`/`P1` → generate the full set of applicable Step 4 mandatory groups even where only loosely implied — a missed edge case costs more than an extra TC. `Low`/`P3` and below → keep to scenarios directly traceable to the stated ACs/description; skip speculative edge cases that would need code confirmation you don't have.

  > ⛔ **This calibration narrows depth, never breadth — do not let it delete whole mandatory groups.** A `Low`/`P3` ticket is NOT exempt from a mandatory group whose own trigger in Step 4 is unconditional ("generate for **every** create/edit flow", "generate for **every** write operation"): Data persistence (save → navigate away → reopen), API payload spot-check (network-tab inspection), and a basic cancel/discard-without-saving check are black-box, no-code-confirmation-needed checks that apply to any edit/create flow regardless of priority — **always generate them.** Search is likewise still mandatory whenever the field is a dropdown/typeahead component (the default Maxxton pattern for such fields, per the `maxxton-angular.md` reference bundled with the `generate-playwright-tests` skill), even if the ticket text never uses the word "search". What the calibration actually trims at `Low`/`P3` is genuinely speculative *content* — guessed error text/codes not stated anywhere in the ticket, internal business-rule branching, or extra field/entity combinations the ticket never implies — never an entire group whose trigger condition already fired. Treating "skip speculative detail" as "skip whole mandatory groups" is a confirmed failure mode (MXTS-80907, Sep 2026): it silently produced roughly half the coverage a `Highest`/`P1` or PR-backed ticket would get, on the exact same feature.

---

## Step 2: Status Gate

Only applies when input was a Jira story ID (has live `status.name` from `getJiraIssue`). Skip this gate if a requirement summary was pasted directly.

Bucket the story using the **Configuration** block above:
- Match `status.name` against `status_mapping.development_stage` → development bucket
- Match against `status_mapping.qa_stage` → QA bucket
- **No match** → use `default_bucket`, log a warning:
  > ⚠️ Unrecognized status `"<status>"` on `<STORY_KEY>` — defaulting to `<default_bucket>`. Add it to the Configuration block to remove this warning.

### If status is a development-stage status:
Proceed normally — continue to Step 3.

### If status is a QA-stage status:
First verify whether test cases already exist: read the comments with `mcp__claude_ai_Atlassian_MCP__executeRead` with `name: listJiraIssueComments` and search for a comment containing `TC_01`.

**Test cases found (comment with TC_01 exists):**
- Skip Steps 3–6.
- Apply `HL-Scenarios_Covered` label if missing (Step 8 logic).
- Inform the user:
  > Skipped test case generation — `<story key>` is in `<status>` and test cases already exist. `HL-Scenarios_Covered` label applied (or was already present).
- Stop — do not continue to Steps 3–8.

**No test cases found (no TC_01 comment):**
- Do NOT skip — proceed normally through Steps 3–8.
- Log:
  > `<story key>` is in `<status>` but has no test cases — generating before execution.

---

## Step 3: Derive Steps and Preconditions

### Steps
Look for explicitly numbered or bulleted steps in the input. If not present, derive logical high-level steps from the feature description and acceptance criteria. Only derive steps directly implied by the content — do not invent functionality.

### Preconditions
Write preconditions as **explicit, checkable state** — not vague descriptions. Each precondition must name the exact entity type and state required so the test data setup step can verify or seed it automatically.

**Rules:**
- Name the entity type explicitly: `"At least one active Customer must exist"` — not `"customer data is available"`
- For edit/link/view TCs: `"<Entity> named QA-SEED-<story> must exist"` — the seed entity will be created automatically if missing
- For a TC that needs a distinct customer or guest name (search, sort, overflow): `"a guest with a first name no other guest has (a customer found by searching a common first name such as Charlie or Frank, linked to the reservation)"` — never an invented literal such as `QA-Search-Guest`; the run picks any existing customer from the search results
- For duplicate/unique-constraint TCs: `"<Entity> with <field value> already exists"`
- Role-based TCs: `"Logged in as <role>"`
- Always include: `"Authenticated user with access to <module>"`

Do NOT write `"Test data is set up"` or `"Environment is ready"` — these are not checkable.

---

## Step 4: Generate High-Level Scenarios

Break the requirements into logical functional areas (e.g. Create, Edit, Search, Pagination, Linking, Translations, Working Hours). For each area generate a high-level scenario table:

| TC_ID | Test Scenarios |
|---|---|
| TC_01 | Verify we are not able to create <entity> without <required field> |
| TC_02 | Verify we are able to create <entity> without <optional field> |

TC_ID format: `TC_01`, `TC_02` — continuous across all functional areas, always two digits, no upper limit.

**Language rules (strictly enforced):**
- Capability statements: `Verify we are able to <action>` / `Verify we are not able to <action>`
- Validation / error visibility: `Verify error is shown when <condition>` / `Verify <element> is shown/not shown when <condition>`
- Existence / state: `Verify <thing> is <state> when <condition>`
- Never use "Verify that..." — always use one of the patterns above
- Reference specific field names, button labels, and actions from the ticket — never write generic scenarios

**Mandatory scenario groups (generate every group that is relevant to the feature):**

*Subtask areas (always generate when subtasks were found in Step 1)* — for each subtask identified in Step 1, generate a dedicated functional area. Use the subtask summary as the area name. Generate TCs scoped to exactly that implementation unit — do not merge multiple subtasks into a single area. This ensures every discrete implementation unit has at least one TC.
- Example: subtask `[MXTS-77620] Email reply flow` → functional area "Email Reply" with its own create/edit/boundary TCs
- Example: subtask `[MXTS-77621] WhatsApp chat reply` → separate "WhatsApp Reply" area — not merged with email

*Regression (always generate when linked Bugs were found in Step 1)* — for each linked Bug identified in Step 1, generate at least one TC that verifies the reported broken flow no longer occurs after the fix:
- Verify we are able to \<correct behaviour from bug description\> after the fix
- Verify error is not shown when \<condition that triggered the original bug\>

*Create flow* — missing each required field individually; optional fields omitted; duplicate-key / already-used-code; optional UI interactions during creation (e.g. color picker, checkboxes)

*Edit flow* — edit each editable field; attempt duplicate value; cancel without saving; verify unchanged fields remain intact

*Search* — search with valid term returns results; search with non-existent term shows empty state; search clears / resets correctly

*Pagination* — pagination element absent when ≤ threshold (usually 10); pagination shown when > threshold; navigate pages correctly

*Sorting (if applicable — the list/table has sortable columns)* — ascending on first click, descending on second click, and (if Pagination also applies) sort order holding across page navigation

*Bulk actions (if applicable — the table supports checkbox/multi-select)* — selecting multiple entities, a bulk action applying to every selected entity, "select all" selecting every row on the current page, and the bulk action going through the same Confirmation dialog gating pattern (below) as its single-entity equivalent when the single-entity action does

*Empty-list / zero-state view (if applicable — the list/table can start with zero records independent of any search filter)* — distinct from Search's "non-existent term shows empty state", which only covers a filtered-to-empty result: this covers the list never having had any record at all

*Working hours (if applicable)* — add/edit normal working hours; overlapping hours rejected; close a working day; add special hours; delete special hours; duplicate date rejected; multi-day range; date filter on special hours

*Translations (if applicable)* — add / edit translation per locale; reset / discard translation changes

*Link / Unlink (if applicable)* — link an entity; unlink an entity; already-linked items not shown in picker; search within picker; filter by group/category; pagination in picker; pagination of linked list

*Archive / Deactivate (if applicable)* — archive entity; verify archived entity no longer appears in active list

*Confirmation dialog gating (generate whenever an irreversible/destructive action — delete, archive, cancel-with-unsaved-changes, bulk-delete — shows a confirmation dialog)* — the dismiss path is a distinct, easily-forgotten assertion, not just the confirm path:
- Verify \<action\> is NOT performed when the confirmation dialog is dismissed/cancelled
- Verify \<action\> completes when the confirmation dialog is confirmed

*View / Open (if applicable)* — open detail view; verify all fields displayed correctly

*Boundary inputs (always generate for any feature with text/number fields)* — maximum allowed length for each text field; input exceeding max length is rejected or truncated; empty string where field is required; whitespace-only input rejected; zero and negative values for numeric fields; very large numbers for numeric fields; special characters in name/title fields (if not already covered by a feature-specific scenario)

*Authorization (generate when user roles are mentioned in requirements)* — one row per restricted action per role:
- Verify we are not able to \<perform action\> as \<role without permission\>
- Verify we are able to \<perform action\> as \<role with permission\>

*IDOR / URL manipulation (generate for any entity that has an ID in the URL)* — verify that changing the ID in the URL to another entity's ID does not expose unauthorized data:
- Verify we are not able to access \<entity\> belonging to another \<user/tenant\> by modifying the URL ID

*Conditional mandatory field / control-state gating (generate whenever a field's required-ness, or a submit/action control's enabled state, depends on another field's value or selection)* — a control gated by conditional validation needs its own state-transition checks, not just a pass/fail on the final submit:
- Verify \<control\> is disabled while \<newly-mandatory field\> has no value
- Verify \<control\> transitions from disabled to enabled once \<newly-mandatory field\> is given a value — the transition itself is the assertion, not just the end state already covered by the happy-path submit TC
- Verify \<control\> stays disabled if any OTHER mandatory field in the same form is left empty, not only the one that triggered this check

*Feature flag gating (generate when `story.feature_flags` is non-empty)* — a flag-gated feature needs its own visibility/enablement checks, independent of its normal functional TCs:
- Verify \<feature\> is not visible/enabled when \<flag\> is disabled
- Verify \<feature\> is visible/enabled and behaves as specified when \<flag\> is enabled
Do not guess the flag's current default state in this environment — write it as a precondition to set up (e.g. "Flag `<flag>` is enabled for the test tenant"), never assert today's environment state as fact.

*Data persistence (generate for every create and edit flow)* — after saving, verify data actually
persisted. **How many navigation paths depends on what kind of field is being checked:**

- **Derived-display fields — dropdown/select/multi-select, or any field whose shown label is mapped
  from an underlying stored code/enum/id (not the raw value itself)** — **two distinct navigation
  paths are mandatory, never just one**: (1) full page reload, and (2) the app's own in-page
  navigation (a back arrow, closing/reopening a panel, or collapsing and re-expanding the same view,
  without a full reload). A value can survive a reload but still render wrong via the app's own
  back/collapse navigation — confirmed in production (MXTS-81144, Sep 2026): a Notification Manager
  condition's Trigger field (a dropdown mapped from a `TriggerType` enum) correctly read "Bill
  updated" after a full reload, but showed the wrong value ("Bill changed") when reached via the
  in-app back arrow instead — a bug a reload-only check would never catch, and a class of bug that is
  specific to *that field's own* component, not provably true or false for any other field just
  because one dropdown happened to pass or fail. Generate one row per navigation path, never one row
  vaguely covering both:
  - Verify \<entity\>/edited \<field\> persists after a full page reload
  - Verify \<entity\>/edited \<field\> persists after navigating away and back via the app's own
    back/collapse control (not a page reload)
- **Plain scalar fields — free-text, number, date, toggle, anything displayed as the raw stored value
  with no lookup/mapping step** — a single full-page-reload check is sufficient; there is no
  display-mapping layer for in-app back-navigation to render stale, so the second path adds cost
  without a plausible failure mode to catch:
  - Verify \<entity\>/edited \<field\> persists after saving and reopening the record

*API payload spot-check (generate for every write operation — create, edit, delete)* — using `browser_network_requests`, verify the correct API call was made with the expected payload structure after the UI action. This TC is marked `Automate = No` and executed via the API validation patterns in `execute-tests`:
- Verify API request is made with correct payload when \<entity\> is created
- Verify API request is made with correct payload when \<entity\> is edited

*Bill recalculation (generate whenever a TC's steps save a change to what a reservation is charged — override rates, add or remove an add-on, apply or remove an offer/voucher/discount, change dates, accommodation, unit, guests, or a status that reprices)* — the line the ticket is about can be right while the total, an offer or an add-on moves after "Recalculate reservation" (MXTS-81495: every MAR check passed, the customer total still changed). This is not a new row: it adds steps to **every** bill-changing TC, so the recalculation and a whole-bill comparison are never left to chance:
- Preconditions end with: the full bill (every line, VAT per rate, Sub-total, Total, Internal Bill) is noted before the change.
- Steps: right after the step that saves the change, add `Click "Recalculate reservation"`, then `Compare every bill line, the VAT and the Total with the values noted before the change`.
- Expected Result names the lines that are supposed to move and the VAT and Total change that follows from them (an add-on or a date change moves the Total; a price-neutral change leaves it as it was), and states that every other line stays as it was. One checkable outcome, no "if present".
- A TC whose point is the state *before* recalculation (e.g. "the header updates immediately after saving") keeps that assertion first; the recalculate and compare steps go after it.
- Skip a TC that discards the change (Cancel, close without saving) or only re-reads the bill (reload, API check) — nothing was saved. `execute-tests` and `test-ticket` capture the before and after bill at run time: [the Bill Snapshots reference](${CLAUDE_PLUGIN_ROOT}/skills/execute-tests/references/bill-snapshot.md).

*UI text localisation (generate when `story.change_types` contains `i18n`)* — new or changed labels, tabs, buttons or messages must resolve to real copy in more than the default locale:
- Verify <new/changed label> is shown as translated text, not a raw translation key (`namespace.key`), in the primary locale
- Verify <label> is shown in <second locale, e.g. NL or FR> on a concern/site that uses that language — write the concern as a precondition
- Verify <label> falls back to English when its translation is empty for a non-English locale *(only when the ticket or PR names a fallback)*

*API / backend-only change (generate when `story.change_types` contains `api_only`)* — there is no new UI to assert on, so the check is the call itself and its consumers; marked `Automate = No` and executed via the API validation patterns in `execute-tests`, like the API payload group:
- Verify the <flow> that calls <endpoint> returns the expected response structure when triggered from the UI
- Verify <endpoint> is rejected with 401 or 403 when called without the session credentials
- Verify the existing screen that consumes <endpoint> still shows correct data

*Cross-service change (generate when `story.change_types` contains `multi_repo`)* — one end-to-end row; its Preconditions state that every PR of the ticket is deployed to the environment under test:
- Verify we are able to complete <end-to-end flow> across <service A> and <service B>

*Widget / admin-configured display (generate when `story.change_types` contains `widget`)* — admin configuration on one side, front-end result on the other:
- Verify <widget> displays as configured on the front end after setting <option> in the admin
- Verify a page that already uses <widget> on another concern is unaffected — name that second page/concern as a precondition

> **Out of scope for this skill:** Performance/load testing, cross-browser compatibility, accessibility audits (a11y), and security penetration testing require dedicated tools outside Playwright MCP. Do NOT generate TCs for these — note them as manual/specialist coverage if required.

Do NOT impose a maximum scenario count — generate as many concrete, specific scenarios as the feature requires.

---

## Step 5: Expand Into Detailed Test Cases

**Critical rule:** Each high-level scenario group from Step 3 expands into MULTIPLE individual test case rows — one row per specific variation. The number of rows in the detailed table will always be significantly larger than the number of high-level scenarios. Never produce a 1-to-1 mapping between high-level scenarios and detailed rows.

The "Test case scenario" column in each row is itself a standalone, specific "Verify we are [not] able to..." / "Verify error is shown when..." statement — NOT a group label. Think of the detailed table as the exhaustive flat list of every checkable behaviour, where the high-level scenarios are just the grouping headings.

**How to expand each scenario group** (one row per specific variation — use these exact "Verify" row formats):

- Required fields → `Verify we are not able to create <entity> without <Field X>` (one row per field)
- Optional fields → `Verify we are able to create <entity> without <optional Field X>` (one row per field)
- Duplicate value → `Verify error is shown when we try to create <entity> with an already used <field>`
- Create happy path → `Verify we are able to create <entity> with all fields filled` + one row per optional UI interaction (color picker, checkbox, toggle)
- Working hours → `Verify we are able to edit normal working hours` / `Verify we are not able to add overlapping working hours` / `Verify we are able to close working day` / `Verify we are able to add special working hours` / `Verify we are able to delete special working hours` / `Verify we should not be able to add special working hours for already added date` / `Verify we are able to add multiple day date special working hours at once` / `Verify we are able to apply date filter and view special working hours`
- Translations → `Verify we are able to add or edit translation of the <entity>` / `Verify we are able to reset the changes which are made while adding translation`
- Search → `Verify we are able to search all <entities>` / `Verify <entity> which does not exist shows empty state`
- View / Open → `Verify we are able to view and open <entities>`
- Edit flow → `Verify we are able to edit <Field X> of <entity>` (one row per editable field) / `Verify we are not able to edit <Field X> if we use an already used value` / `Verify we are able to cancel without saving`
- Archive → `Verify we are able to archive <entity>`
- Confirmation dialog gating → `Verify <action> is not performed when the confirmation dialog is cancelled` / `Verify <action> completes when the confirmation dialog is confirmed`
- Sorting → `Verify <column> sorts ascending on first click` / `Verify <column> sorts descending on second click` / `Verify sort order holds when navigating to the next page` (only if Pagination also applies)
- Bulk actions → `Verify multiple <entities> can be selected via checkboxes` / `Verify bulk <action> applies to every selected <entity>` / `Verify select-all selects every row on the current page`
- Empty-list / zero-state → `Verify an empty-state message is shown when <entity> list has no records` / `Verify the empty state is replaced by the list once at least one <entity> exists`
- Link / Unlink → repeat for each linked entity type: link, unlink, already-linked not shown, search in picker, filter by group, pagination of linked list, pagination while linking, sequence change (if applicable)
- Boundary inputs → one row per field per boundary: max length exceeded / whitespace-only / zero / negative / special characters / max length accepted
- Authorization → `Verify we are not able to <action> as <restricted role>` / `Verify we are able to <action> as <permitted role>` (only when roles defined)
- IDOR → `Verify we are not able to access <entity> of another <user/tenant> by modifying the URL ID`
- Conditional mandatory field / control-state gating → `Verify <control> is disabled while <field> has no value` / `Verify <control> transitions from disabled to enabled once <field> is given a value` / `Verify <control> stays disabled when any other mandatory field in the form is empty`
- Feature flag gating → `Verify <feature> is hidden/disabled when <flag> is off` / `Verify <feature> is visible/enabled and functions correctly when <flag> is on`
- Data persistence → **derived-display fields (dropdown/select/multi-select/lookup-mapped) get two rows, never one** — `Verify <entity>/<field> persists after a full page reload` AND `Verify <entity>/<field> persists after navigating away and back via the app's own back/collapse control (not a page reload)`; **plain scalar fields (text/number/date/toggle) get one row** — `Verify <entity>/<field> persists after saving and reopening the record`
- API payload spot-check → `Verify API request is sent with the correct payload when <entity> is created/edited`
- Bill recalculation → no extra rows: every row that saves a change to a reservation's bill gets the `Click "Recalculate reservation"` and `Compare every bill line, the VAT and the Total with the values noted before the change` steps, and an Expected Result that names the lines that move and says everything else stays
- UI text localisation (only when `i18n`) → `Verify <label> is shown as translated text, not a raw translation key, in the primary locale` / `Verify <label> is shown in <second locale>` / `Verify <label> falls back to English when its translation is empty` (the last only when a fallback is named)
- API / backend-only (only when `api_only`) → `Verify the <flow> that calls <endpoint> returns the expected response structure` / `Verify <endpoint> is rejected with 401 or 403 without the session credentials` / `Verify the screen that consumes <endpoint> still shows correct data`
- Cross-service (only when `multi_repo`) → `Verify we are able to complete <end-to-end flow> across <service A> and <service B>`
- Widget / admin-configured (only when `widget`) → `Verify <widget> displays as configured on the front end after setting <option>` / `Verify a page that already uses <widget> on another concern is unaffected`

Only skip a row if the variation genuinely cannot apply to the content in the ticket.

**Pre-output self-check (mandatory, run before Step 6 — do not skip even when confident):** For each of these unconditional-trigger groups, confirm at least one row was actually produced if the trigger condition applies to this ticket: **Data persistence** (for any derived-display field checked — dropdown/select/multi-select/lookup-mapped — confirm at least one *pair*: a full-reload row AND a back/collapse-navigation row for the same value; a single row covering only one path is itself a self-check failure for that field, not a passing minimum. Plain scalar fields need only the single reload row.), **API payload spot-check**, **Cancel/discard without saving** (part of Edit flow), **Search** (applies whenever a dropdown/typeahead/searchable list is involved), **Conditional mandatory field / control-state gating** (applies whenever any field/control is conditionally required), **Feature flag gating** (applies whenever `story.feature_flags` is non-empty), **Confirmation dialog gating** (applies whenever any irreversible/destructive action shows a confirm dialog), **Bill recalculation** (applies whenever any TC saves a change to what a reservation is charged — every such TC must carry the recalculate and compare steps; a bill-changing TC without them is a self-check failure), and the change-type groups **UI text localisation** (`i18n`), **API / backend-only** (`api_only`), **Cross-service** (`multi_repo`), **Widget / admin-configured** (`widget`) whenever `story.change_types` contains their type. A group whose trigger fired but produced zero rows is a self-check failure — go back and generate it now, before proceeding to Step 6. Do not rationalize the omission (e.g. "this ticket is low priority so it's fine to skip") — the priority-calibration rule in Step 1 already narrows *depth*, not whether these groups fire at all; a passed self-check is what makes that distinction real instead of aspirational. Log the result of every check, applicable or not:
```
[Self-check] persistence: 2 | API-payload: 2 | cancel: 1 | search: 0 (n/a — no searchable field) | control-gating: 3 | flag-gating: 0 (n/a — no flag detected) | confirm-dialog: 0 (n/a — no destructive action) | bill-recalc: 0 (n/a — no bill-changing TC) | i18n: 0 (n/a) | api-only: 0 (n/a) | cross-service: 0 (n/a) | widget: 0 (n/a)
```
`bill-recalc` is the number of bill-changing TCs that carry the recalculate and compare steps (`4` when all 4 do).

---

## Step 6: Output Test Case Table

Output one table per issue in this exact structure:

| TC_ID | Test case scenario | Preconditions | Test steps | Expected Result | Actual result | Story number | Epic number | Automate | Risk |
|---|---|---|---|---|---|---|---|---|---|

Column rules:
- TC_ID: TC_01, TC_02 … restart from TC_01 per issue; **order rows by Risk descending (High first, then Medium, then Low)**
- Test case scenario: exact label and text from high-level scenarios
- Preconditions: intelligently adapted per variation — single sentence if one, numbered list if multiple distinct; no API-related preconditions
- Test steps: inline numbered, two spaces between steps, no line breaks inside cell
- Expected Result: specific, traceable to requirement — never generic
- Actual result: always "To be Tested"
- Story number: Jira story key (e.g. MXTS-12345)
- Epic number: Epic key extracted from ticket or summary (e.g. MXTS-60001); N/A if not present
- Automate: `"No"` *(standalone default — `/test-ticket` Gate 2 updates this to `"Yes"` for TCs not excluded from automation; leave as `"No"` when running this skill standalone)*
- Risk: `High` / `Medium` / `Low` — assign using these rules **in this priority order**:
  - **Step 1 — Critical path override (check first):** If the TC scenario contains any keyword from the `critical_paths` list in the Configuration block → **always `High`**, regardless of the rules below. This is a business-defined override, not a model heuristic.
  - **Step 1b — Same-feature-area inheritance (check second, before falling to Step 2):** If the TC is a structural variation — search, cancel/discard, persistence-after-save, boundary, API-payload spot-check, control-state gating/transition, or similar — of another TC in the same functional area that already got `High` from Step 1's keyword match → **inherit `High`**, even though this TC's own scenario text doesn't repeat the keyword. The whole feature area carries the criticality the keyword identified, not only the literal row containing the word — a search box for selecting a `work order` is exactly as high-risk as the create/save flow it feeds into, and a cancel-without-saving check on a `payment` form is as high-risk as the payment submit itself. Only fall through to Step 2 when the TC is genuinely unrelated to any Step-1-flagged scenario in the same functional area.
  - **Step 2 — Standard heuristic (apply only if no critical_path match and no Step 1b inheritance applies):**
    - **High** — core business flow (create/save/submit), data loss risk, explicitly in AC, authorization check, duplicate/unique constraint
    - **Medium** — edit flows, search, pagination, error messages, boundary inputs
    - **Low** — optional fields, UI cosmetics, translations, sequence/ordering, view-only TCs
  - **Step 3 — Developer-flagged major impact (after Steps 1–2):** If `story.dev_qa.major_impact` is `Yes`, raise every TC that ended `Low` to `Medium`; never lower a risk, never touch `High`/`Medium`.

---

## Step 7: Identify Coverage Gaps

After generating test cases, compare against the requirement summary. List any:
- Requirements or acceptance criteria with no corresponding test case
- Vague acceptance criteria that could not be made into a testable case
- Functional areas mentioned in Confluence docs but not covered by any test case
- When `story.dev_qa` is non-null: each developer Main Tests bullet that no generated TC covers (check by meaning, not wording) — list it as `Developer QA bullet not covered: <bullet>`; and a `Developer QA template points at <KEY> comment <ID>, which could not be read` gap when a followed link failed
- When `story.has_pr = false`: implementation-specific facts that could not be confirmed (exact error codes/messages, internal business-rule branching) — flag them as needing a linked PR or engineering confirmation before being treated as fact

Output:
```
COVERAGE GAPS
-------------
- <gap description>
(or "No coverage gaps identified")
```

---

## Step 8: Post to Jira

If the input was a Jira story ID:

**Label guard:** Inspect the `labels` array from the `getJiraIssue` response in Step 1.
- If `HL-Scenarios_Covered` is **present** → skip Steps 7 and 8. Inform the user:
  > Test cases generated but not posted — `HL-Scenarios_Covered` label already present on <story key>. Test cases are displayed above for reference.
- If `HL-Scenarios_Covered` is **not present** → continue below.

Read the comments with `mcp__claude_ai_Atlassian_MCP__executeRead` with `name: listJiraIssueComments` to check for an existing test cases comment.
Look for a comment authored by the current user containing "QA Test Cases". A comment that carries a `_Part n of m_` line is one part of a split comment: the parts together are the existing comment (all `m` must be present).

**If no existing comment found:**
Post a comment using `addOrEditJiraIssueComment` containing the detailed test case table:

```
## QA Test Cases — <STORY_KEY>

| TC_ID | Test case scenario | Preconditions | Test steps | Expected Result | Actual result | Story number | Epic number | Automate | Risk |
|---|---|---|---|---|---|---|---|---|---|
...

## Coverage Gaps
...
```

Confirm to the user:
> Test cases generated and posted to <story key>. Run `/generate-playwright-tests` to automate these cases, or `/test-ticket <EPIC_ID> <URL>` for the full pipeline.

**If an existing comment is found:**
Post a new comment with the detailed test case table, clearly marked as superseding the old one:

```
## QA Test Cases — <STORY_KEY> (Updated)

> ⚠️ This comment supersedes the previous test case comment (ID: <original-comment-id>). Please delete or ignore the earlier one.

| TC_ID | Test case scenario | Preconditions | Test steps | Expected Result | Actual result | Story number | Epic number | Automate | Risk |
|---|---|---|---|---|---|---|---|---|---|
...

## Coverage Gaps
...
```

Do NOT ask the user — always post the full updated comment automatically and note the superseded comment ID.

**Validate before every post, and split long tables.** Save the body with the Write tool and run `node "${CLAUDE_PLUGIN_ROOT}/skills/test-ticket/scripts/validate-results-comment.js" <body_file> --kind gtc --story <STORY_KEY>` (exit 1 → rebuild from the template it prints). More than 45 TC rows → Jira would reject one comment (32,767 characters), so post it in parts: [the split comments reference](references/split-comments.md). 45 or fewer → one comment as above.

---

## Step 9: Apply Label

After posting the comment, call `editJiraIssue` to add the label `HL-Scenarios_Covered` to the ticket.

- Read the existing `labels` array from the `getJiraIssue` response in Step 1
- Append `HL-Scenarios_Covered` to the array (do not remove any existing labels)
- Call `editJiraIssue` with the full updated labels array

```json
{
  "fields": {
    "labels": ["<existing_label_1>", "<existing_label_2>", "HL-Scenarios_Covered"]
  }
}
```

If the label is already present, skip the call — do not duplicate it.

---

## Step 10: Post Results (Post-Execution)

When the user has completed test execution and wants to post results:

1. Receive verdicts per TC (PASS / FAIL / BLOCKED / NEEDS REVIEW / SKIPPED + one-line reason)
2. Build a **6-column results comment** — the same format used by `execute-tests` Step 6c and `test-ticket` Phase 3b:

```
## QA Test Results — <STORY_KEY>

| TC_ID | Test case scenario | Expected Result | Actual Result | Status | Test Proof |
|---|---|---|---|---|---|
| TC_01 | Verify we are able to... | <expected> | <what happened> | PASS ✅ | |
| TC_02 | Verify error is shown when... | <expected> | <what happened> | FAIL ❌ | |
```

Status column values: `PASS ✅`, `FAIL ❌`, `BLOCKED 🚫`, `NEEDS REVIEW 🔍`, `SKIPPED ⏭️`.

3. Validate the body (`--kind gresults --story <STORY_KEY>`, same script as Step 8), then call `addOrEditJiraIssueComment` to post the results comment on `<STORY_KEY>`. More than 45 TC rows → post it in parts: [the split comments reference](references/split-comments.md).

> **Note:** To edit an existing comment in Jira, use the Jira UI directly:
> Open the comment → click `⋯` → Edit. The MCP only supports adding new comments.
