# Split Comments (more than 45 TCs)

Jira rejects a comment over 32,767 characters. This skill posts two comments that can get that long: the **QA Test Cases** comment (Step 8) and the **QA Test Results** comment (Step 10). Either one with **more than 45 TC rows** is posted as several comments (parts). **45 rows or fewer → post one comment exactly as the step says and ignore this file.**

The scripts live in the `test-ticket` skill of this plugin and are called through `${CLAUDE_PLUGIN_ROOT}`; they need no credentials and no Jira call. Save every body with the Write tool and read it back only with the Read tool (PowerShell's plain `Get-Content` garbles `—` and `✅`).

## 1. Plan once and save it

Write the TC_IDs of the table (never EXTRA ids), in table order, one per line to a temp file, then:

```bash
node "${CLAUDE_PLUGIN_ROOT}/skills/test-ticket/scripts/result-parts.js" plan --ids-file <ids.txt>
```

`"split": false` → one comment, stop reading. `"split": true` → save `{ "planned_at": "<ISO now>", "parts": <the printed parts array> }` to `test-output/<STORY_KEY>/tc-parts.json` (Step 8) or `test-output/<STORY_KEY>/result-parts.json` (Step 10) **before posting anything**. The file already exists (resume) → reuse it, never plan again. Rule: parts of at most 40 rows in TC order; a last part under 10 rows is rebalanced with the one before it (60 → 40 + 20, 46 → 23 + 23).

## 2. What each part looks like

Header exactly as in the step (`## QA Test Cases — <STORY_KEY>`, `… (Updated)`, or `## QA Test Results — <STORY_KEY>`), then:

- The first non-empty line after the header is exactly `_Part n of m_` (any other form or position is rejected).
- Only this part's TC rows, in the same table format.
- **QA Test Cases:** `## Coverage Gaps` goes **only in the last part** (never in the others). The "(Updated)" banner (`> ⚠️ This comment supersedes the previous test case comment (ID: …)`) goes only in part 1; when the earlier comment was itself split, list every earlier comment id in it (`IDs: 1, 2`). Step 8's "Do NOT ask the user" still applies.
- **QA Test Results:** only this part's rows; EXTRA rows only in the last part.

## 3. Validate every part before posting part 1

```bash
node "${CLAUDE_PLUGIN_ROOT}/skills/test-ticket/scripts/validate-results-comment.js" <body_file> --kind gtc --story <STORY_KEY> --part n/m --tc-ids TC_01,TC_02,…
# Step 10 results comment:  --kind gresults   (no stats table is required; an empty Test Proof is allowed)
```

Run the same command without `--part … --tc-ids …` for a single (not split) comment: every comment of this skill is validated before it is posted. Exit 1 → rebuild from the template it prints. A part over 32,000 characters fails with `CHECK 15`: re-plan with `plan … --batch 30`, replace the saved plan, rebuild. Because all parts are checked before part 1 is posted this is safe; once any part is posted the plan is frozen.

## 4. Post the parts in order

For each part without a `comment_id`:

1. **Duplicate guard:** `listJiraIssueComments` on `<STORY_KEY>`; a comment whose first line is this skill's header for `<STORY_KEY>` and that carries this part's `_Part n of m_` line, created at or after `planned_at`, is this part (a crash happened before the id was saved) → record its id and do not post again.
2. Otherwise `addOrEditJiraIssueComment` with the validated body, then save the returned id as the part's `comment_id` immediately.
3. A part that fails after one retry stops the run of posts: do not post later parts, tell the user which parts are posted, and a re-run resumes at the first part without an id.

An already-posted part is corrected by editing that comment (`addOrEditJiraIssueComment` with its `commentId`), validated the same way. **Extended cases (`--extend`)** go in the **last part** of a split QA Test Cases comment: run `extend-tc-comment.js` on that part's body with `--main-total <number of main TCs of the whole story>`, append the new ids it prints to that part's `tc_ids` in the saved plan, and correct the comment in place (validator: `--part m/m --tc-ids <updated ids> --main-total <n>`). The script refuses any other part. If the longer last part trips `CHECK 15`, the case cannot be added to this comment: tell the user. Details: item 6 of the "Test Cases comment" section in the `test-ticket` split reference (`${CLAUDE_PLUGIN_ROOT}/skills/test-ticket/references/phase-3b-split-results.md`).

## 5. Reconcile after the last part

Read the posted part comments back (`listJiraIssueComments`), save each part's body to a temp file in part order, write the `parts` array of the saved plan to `parts.json`, and run:

```bash
node "${CLAUDE_PLUGIN_ROOT}/skills/test-ticket/scripts/result-parts.js" reconcile --plan parts.json --body-file <part1> --body-file <part2>
```

It must print `OK — <n> TC(s) across <m> part(s), each exactly once.` Anything else means a TC is missing or doubled in Jira: tell the user which part to correct.

Readers: anything that reads the QA Test Cases comment back (the Step 8 "existing comment" check, `/test-ticket`'s resume check, `/execute-tests` Step 6a) must read every part (`Part 1 of m` … `Part m of m`) and merge the rows; a part missing from Jira means the comment is incomplete.
