# Extended Cases — human-requested additions, tracked separately

After Claude generates test cases, a human reviewer often spots cases or validations Claude missed. Those are **not** silently merged into the main table. Claude first says yes or no to each one, and the accepted ones go into a separate section of the same Jira comment — **Extended cases added after Human review** — with counts, so the team can see how much Claude missed compared to the human.

## Two ways a human adds cases

| Entry point | When | How |
|---|---|---|
| `/generating-test-cases <STORY_KEY> --extend` | After the TCs are already posted | The human lists the missing cases/validations in the same message, or Claude asks once: `List the cases or validations you want added.` |
| Gate 1 `add <description>` in `/test-ticket` Phase 2 | Before the TC comment is posted | Same decision step below; accepted cases are collected and appear under the Extended heading in the re-displayed table and in the posted comment |

Never add a human-requested case to the main table. The main table stays what Claude generated.

## 1 — Find the comment (`--extend` only)

Read the story's comments (`mcp__claude_ai_Atlassian_MCP__executeRead` `listJiraIssueComments`, every page). Pick the **newest** comment whose first line is `h2. Test Cases — <KEY>`, `## Test Cases — <KEY>` (pipeline) or `## QA Test Cases — <KEY>` (this skill's standalone post), for **this** story's key. None → stop: `No Test Cases comment exists for <KEY> yet — generate the cases first.` A comment carrying a `_Part n of m_` line is one part of a split comment: the Extended section lives in the **last part** (`n = m`), so work on that one, count the story's main TCs over all parts (`--main-total <n>`), and pass `--main-total` to `extend-tc-comment.js`; the added ids must also be appended to that part's `tc_ids` in the saved plan (see the split comments reference). Note its comment id and which form it is (`h2.` = wiki, written by the script path; `##` = markdown, written through the MCP).

## 2 — Decide each requested case

Take the cases one by one. Ground every decision in the ticket itself (description, ACs, comments, `story.impl_context`, the linked PR when there is one, `story.ac_overrides`, `story.known_limitations`) — the same Source priority & grounding rule as the rest of this skill. Compare against **every** existing TC (main table and any earlier extended rows) **by meaning, not wording**.

| Answer | When | Counted as a miss? |
|---|---|---|
| **accepted** | The ticket supports the behaviour and no existing TC checks it | Yes |
| **covered** | An existing TC already checks the same behaviour — name it (`TC_07`) | No |
| **declined** | Out of scope (explicit `Out of scope` / known limitation), contradicts an AC or a later developer comment, or cannot be tested in this pipeline (performance, accessibility audit, penetration test, third-party client portal) — give the one-line reason | No |
| **overridden** | Claude said `declined` or `covered`, the human replied `insist <n>` | Yes — "added on request" |

Cannot tell whether it is in scope, or what the expected result is → ask **one** focused question and wait; the case is not counted until answered. An accepted case needs an Expected Result: take it from the ticket; if only the human's wording states it, use that wording (never invent a specific the ticket does not support).

Show the decisions **before** touching Jira, as a table:

```
| # | Requested case | Answer | Why |
|---|---|---|---|
| 1 | <the human's words> | accepted | <what in the ticket supports it, not covered by any TC> |
| 2 | <…> | covered | Already checked by TC_07 |
| 3 | <…> | declined | <reason> — reply "insist 3" to add it anyway |
```

Accepted cases are added right away; there is no second approval. `insist <n>` turns a declined/covered case into `overridden` (add it, still counted as a miss, no argument).

## 3 — Build the new body (never type the numbers)

For each accepted/overridden case fill `row` (scenario in the usual `Verify we are [not] able to …` wording, preconditions, steps, expected result, risk by the normal Risk rules, `automated` — `No` unless Gate 2 already ran and says otherwise). Covered/declined cases need only the decision. Write the entries and run the builder — it assigns the next TC ids, keeps the main table and footer untouched, adds the section, computes the counts and miss rate, and refuses to write anything its own validator would reject:

```bash
# entries.json: { "entries": [ { "decision": "accepted", "row": { "scenario": "...", "preconditions": "...", "steps": "...", "expected": "...", "risk": "High" } }, { "decision": "covered" }, { "decision": "declined" }, { "decision": "overridden", "row": { ... } } ] }
node "$CLAUDE_PLUGIN_ROOT/skills/test-ticket/scripts/extend-tc-comment.js" <current_body_file> <entries.json> <new_body_file>
# prints {"added":["TC_13"],"stats":{...},"missRatePct":20}
```

Save the files with the Write tool (not PowerShell redirection — it garbles `—`). The current body is the comment's body exactly as read from Jira. A second call on an already-extended comment accumulates the counts and continues the ids; ids are never renumbered.

## 4 — Post it in place

Never post a second comment and never use the "superseding comment" path of Step 8 — update the existing one:
- Created by the script path (`h2.` form) → `node "$CLAUDE_PLUGIN_ROOT/skills/test-ticket/scripts/update-tc-comment.js" "<KEY>" "<comment id>" <new_body_file>` (it validates the section), or the MCP replace-body path when no Jira token is usable — see the same-path rule in `${CLAUDE_PLUGIN_ROOT}/skills/test-ticket/references/jira-mcp-write-path.md`.
- Created through the MCP (`##` form) → `addOrEditJiraIssueComment` with that `commentId` and `contentFormat: markdown`. For the pipeline form run `node "$CLAUDE_PLUGIN_ROOT/skills/test-ticket/scripts/validate-results-comment.js" <new_body_file> --kind tc --story "<KEY>"` first.
- Gate 1 (before posting): the builder runs on the freshly written main body and the result is what gets posted by the normal Phase 2 step 9.

## 5 — Local record and report

Run `node "$CLAUDE_PLUGIN_ROOT/skills/test-ticket/scripts/run-metrics.js" human-review "<metrics dir>" <story slot> <generated> <requested> <accepted> <covered> <declined> <overridden> || true` with the numbers from the builder's `stats` (`slot` = the story's 1-based position in the Epic, never its key; `/test-ticket`: `test-output/<EPIC_ID>`; standalone: `test-output/<STORY_KEY>`). It is local only and fail-open.

Report in plain words: `Added TC_13, TC_14 under "Extended cases added after Human review". Claude generated 12; the human asked for 4: 2 accepted, 1 already covered (TC_07), 1 declined. Miss rate 14% (2/14).` The same line is in the Jira comment.

## What the section looks like

```
h3. Extended cases added after Human review          (markdown form: ### …)

_Human review: Claude generated 12 · Human requested 4 (accepted 2, already covered 1, declined 1, added on request 0) · Miss rate 14% (2/14) · Last extended 2026-10-14_

|| TC_ID || Test case scenario || Preconditions || Test steps || Expected Result || Actual result || Story number || Epic number || Automate || Risk ||
| TC_13 | … | … | … | … | To be Tested | <KEY> | <EPIC or N/A> | No | High |
```

Miss rate = (accepted + added on request) ÷ (Claude generated + accepted + added on request). The extended TCs are ordinary TCs from then on: `/execute-tests` and `/test-ticket` execute them with the main ones, and the Phase 3a Completeness Gate counts both tables.
