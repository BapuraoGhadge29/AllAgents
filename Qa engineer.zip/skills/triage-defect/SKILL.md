---
name: triage-defect
description: Classifies live MCP execution failures from the test-ticket or execute-tests pipeline into product defects, tooling misreads, test case issues, or needs-review cases. Produces a structured triage report for raise-defect. Use when classifying Phase 3a FAIL and NEEDS REVIEW verdicts.
disable-model-invocation: true
argument-hint: "[paste Phase 3a output or path to execution-log.json or triage.md]"
allowed-tools:
- mcp__claude_ai_Atlassian_MCP__getAccessibleAtlassianResources
- mcp__claude_ai_Atlassian_MCP__getJiraIssue
- mcp__claude_ai_Slack__slack_read_channel
---

# Triage Defect

Classifies live MCP execution failures — FAIL, BLOCKED, and NEEDS REVIEW verdicts produced by Phase 3a — into four classes and produces a structured triage report.

## Step 1: Resolve Input

Accept one of:
- Phase 3a execution output pasted by the user (contains PASS/FAIL/BLOCKED/NEEDS REVIEW rows)
- Path to `test-output/<EPIC_ID>/execution-log.json` — read with the Read tool
- Path to `test-output/<EPIC_ID>/triage.md` — read existing partial triage and continue

Extract for each FAIL, BLOCKED, or NEEDS REVIEW verdict:
- TC_ID, scenario text, expected result, observed result (what the snapshot/screenshot showed), story key, screenshot path (if any), network evidence (if any)

**Environment-Down Check (before classifying):** when half or more of a story's executed TCs in the input ended `FAIL`/`BLOCKED`, run the read-only [Environment-Down Check](${CLAUDE_PLUGIN_ROOT}/skills/execute-tests/references/environment-down-check.md) once per concern. Use `env_check` from `test-output/<EPIC_ID>/run-state.json` when `/test-ticket` already persisted it; otherwise take the concern from the `Environment:` line of `results.md` (no such line → skip) and look it up in `#guild-development` exactly as that reference describes. `broken` feeds the "Environment flagged broken" rule in Step 2; `not_flagged` and `unavailable` change nothing and never stop the triage.

---

## Step 2: Classify Each Failure

Apply the rules below in order — stop at the first match.

### Product Defect — the app returned wrong behavior
- Snapshot or screenshot clearly shows wrong text, wrong state, or wrong value vs the Expected Result column
- Action succeeded (click, fill, navigate) but the system response is wrong — wrong page, wrong message, or no response
- `browser_network_requests` shows an unexpected 4xx or 5xx on a business operation (create, save, submit)
- Feature is absent from the UI — page 404, required element never renders after correct navigation
- Behavior differs from what the Acceptance Criteria states
- Regression: verdict was PASS in a prior run (`--retest` mode, scenario marked `previously PASS`)

### Tooling Misread — MCP tool returned misleading or incomplete state
- Snapshot captured a loading spinner, skeleton screen, or empty container — app may have loaded correctly after the snapshot was taken
- Screenshot taken immediately after an action — async page update had not completed at capture time (race between MCP call and DOM update)
- `browser_network_requests` filter was too broad or too narrow — captured the wrong request, or the target request was not captured
- `browser_snapshot` accessibility tree did not reflect the live DOM — dynamic content in canvas, SVG, custom web components, or cross-origin iframes is invisible to the snapshot
- Observed "element not found" on a standard accessible element (button, input, link) — likely a stale accessibility tree, not a missing UI element; re-run with explicit `browser_wait_for` before snapshot
- `browser_fill_form` confirmed field was filled, but async validation had not resolved — success or error state was still ambiguous at the moment of assertion

### Test Case Issue — the TC steps or expected result are wrong
- Expected result in the TC does not match what the Acceptance Criteria actually specifies — TC was authored incorrectly
- TC steps navigate to the wrong screen, use wrong preconditions, or skip a required setup step
- TC asserts an outcome that is intentionally out of scope for the story

### Needs Review — insufficient signal for automated classification
- BLOCKED due to MCP timeout — unclear if the app hung or if navigation was slower than the 3-minute per-TC budget; re-run before classifying
- NEEDS REVIEW verdict passed through from Phase 3a — model flagged ambiguity that requires a human decision
- Test data absent — failure may be due to missing seed data (`QA-SEED-` prefix not set up), not a product bug
- External integration unavailable during the run — failure may be environment noise, not a product regression
- **Environment flagged broken** — half or more of a story's executed TCs ended `FAIL`/`BLOCKED` **and** the read-only [Environment-Down Check](${CLAUDE_PLUGIN_ROOT}/skills/execute-tests/references/environment-down-check.md) reports the concern `broken` (Oracle Bot `:x:` in the last 24 h). Classify those TCs here with the reason `Environment flagged broken by Oracle Bot (<concern>) — not a confirmed product defect`, and do not propose defects from them. Status `not_flagged`/`unavailable` (including no Slack connector) changes nothing — never treat a missing check as evidence either way

---

## Step 3: Output Triage Report

```
TRIAGE REPORT
=============
Story: <story key>
Test run date: <date>
Source: <"Phase 3a live execution" | "execution-log.json" | "triage.md">
Verdicts reviewed: <n>  |  FAIL: <n>  |  BLOCKED: <n>  |  NEEDS REVIEW: <n>

CLASSIFICATIONS
---------------

[PRODUCT DEFECT] <TC_ID> — <scenario>
Expected: <expected result from TC>
Observed: <what the snapshot/screenshot showed>
Evidence: <screenshot path or network response summary>
Action: Raise Jira defect

[TOOLING MISREAD] <TC_ID> — <scenario>
Signal: <what the MCP tool returned>
Why misread: <one-line explanation — e.g. "snapshot captured loading state before content rendered">
Action: Re-run with browser_wait_for before snapshot, or verify manually

[TEST CASE ISSUE] <TC_ID> — <scenario>
Reason: <what is wrong in the TC — e.g. "Expected result contradicts AC #2">
Action: Update the TC and re-run

[NEEDS REVIEW] <TC_ID> — <scenario>
Reason: <why automated classification is not possible>
Action: Re-run manually / fix test data / re-execute after environment stabilises

SUMMARY
-------
Product defects:   <n>
Tooling misreads:  <n>
Test case issues:  <n>
Needs review:      <n>

NEXT STEP
---------
Run /raise-defect for the following confirmed product defects:
- <TC_ID>: <scenario>
- <TC_ID>: <scenario>
```

---

## Step 4: Enrich Product Defects with Jira Context

For each confirmed product defect, call `getAccessibleAtlassianResources` then `getJiraIssue` on the story to retrieve its summary and acceptance criteria — this becomes evidence in the defect report raised by `raise-defect`.

---

## Step 5: Confirm

Display the triage report and confirm:
> Triage complete. <n> product defect(s) identified. Run `/raise-defect` to create Jira issues with full evidence.
