# Maxxton Angular (Material + MXTS Patterns)

> **When to use**: Every Maxxton spec. Part 1 covers generic Angular testing (Material, reactive forms, Router, signals, Zone.js). Part 2 covers MXTS-specific gotchas that differ from stock Angular — read both.
>
> **Maxxton context**: All MXTS apps are Angular. These patterns are mandatory for all Maxxton E2E tests.

## Table of Contents

1. [Locator Strategies](#locator-strategies)
2. [Reactive Forms](#reactive-forms)
3. [Angular Material Components](#angular-material-components)
4. [Router Navigation](#router-navigation)
5. [Lazy-Loaded Modules](#lazy-loaded-modules)
6. [Signals and Observables](#signals-and-observables)
7. [Zone.js and Change Detection](#zonejs-and-change-detection)
8. [Protractor Migration Reference](#protractor-migration-reference)
9. [CDK Overlay Container](#cdk-overlay-container)
10. [Anti-Patterns](#anti-patterns)

## Locator Strategies

Angular generates internal attributes (`_ngcontent-*`, `_nghost-*`, `ng-reflect-*`) that change every build. Always use semantic locators.

```javascript
test('use semantic locators for Angular apps', async ({ page }) => {
  await page.goto('/projects');

  // Role-based locators work with Angular Material and native HTML
  await page.getByRole('button', { name: 'New project' }).click();
  await expect(page.getByRole('heading', { name: 'Create Project' })).toBeVisible();

  // Label-based for form fields
  await page.getByLabel('Project title').fill('Alpha');

  // Test IDs for complex components without semantic roles
  const chart = page.getByTestId('metrics-chart');
  await expect(chart).toBeVisible();

  // Scope locators within component boundaries
  const projectTable = page.getByRole('table', { name: 'Projects' });
  const activeRow = projectTable.getByRole('row').filter({
    has: page.getByRole('cell', { name: 'Active' }),
  });
  await activeRow.getByRole('button', { name: 'Edit' }).click();
});
```

## Reactive Forms

Playwright interacts with the rendered DOM, so reactive forms (`FormGroup`, `FormControl`, `FormArray`) are transparent.

```javascript
test.describe('form validation', () => {
  test.beforeEach(async ({ page }) => {
    await page.goto('/signup');
  });

  test('displays validation errors on blur', async ({ page }) => {
    const emailField = page.getByLabel('Email');
    await emailField.click();
    await emailField.blur();
    await expect(page.getByText('Email is required')).toBeVisible();

    await emailField.fill('invalid');
    await emailField.blur();
    await expect(page.getByText('Invalid email format')).toBeVisible();
  });

  test('handles FormArray add/remove', async ({ page }) => {
    await page.goto('/contacts/edit');

    await page.getByRole('button', { name: 'Add email' }).click();
    const emailInputs = page.getByLabel(/Email address/);
    await expect(emailInputs).toHaveCount(2);

    await emailInputs.nth(1).fill('backup@example.com');
    await page.getByRole('button', { name: 'Remove email 1' }).click();

    await expect(emailInputs).toHaveCount(1);
    await expect(emailInputs.first()).toHaveValue('backup@example.com');
  });

  test('disables submit until form is valid', async ({ page }) => {
    const submitBtn = page.getByRole('button', { name: 'Register' });
    await expect(submitBtn).toBeDisabled();

    await page.getByLabel('Name').fill('Alice');
    await page.getByLabel('Email').fill('alice@test.com');
    await page.getByLabel('Password', { exact: true }).fill('Secret123!');
    await page.getByLabel('Confirm password').fill('Secret123!');
    await page.getByLabel('Accept terms').check();

    await expect(submitBtn).toBeEnabled();
  });
});
```

## Angular Material Components

Angular Material uses proper ARIA attributes. Use role-based locators instead of CSS classes like `.mat-mdc-button`.

```javascript
test.describe('Material components', () => {
  test('mat-select dropdown', async ({ page }) => {
    await page.goto('/preferences');

    await page.getByRole('combobox', { name: 'Language' }).click();
    await page.getByRole('option', { name: 'Spanish' }).click();
    await expect(page.getByRole('combobox', { name: 'Language' })).toContainText('Spanish');
  });

  test('mat-autocomplete suggestions', async ({ page }) => {
    await page.goto('/members/add');

    const roleField = page.getByRole('combobox', { name: 'Role' });
    await roleField.fill('dev');

    await expect(page.getByRole('option', { name: 'Developer' })).toBeVisible();
    await page.getByRole('option', { name: 'Developer' }).click();
    await expect(roleField).toHaveValue('Developer');
  });

  test('mat-dialog interaction', async ({ page }) => {
    await page.goto('/items');

    await page.getByRole('button', { name: 'Remove item' }).first().click();

    const dialog = page.getByRole('dialog');
    await expect(dialog).toBeVisible();
    await expect(dialog.getByText('Confirm deletion?')).toBeVisible();

    await dialog.getByRole('button', { name: 'Cancel' }).click();
    await expect(dialog).toBeHidden();
  });

  test('mat-table sorting', async ({ page }) => {
    await page.goto('/members');

    await page.getByRole('columnheader', { name: 'Name' }).click();
    const header = page.getByRole('columnheader', { name: 'Name' });
    await expect(header).toHaveAttribute('aria-sort', 'ascending');

    await page.getByRole('columnheader', { name: 'Name' }).click();
    await expect(header).toHaveAttribute('aria-sort', 'descending');
  });

  test('mat-paginator navigation', async ({ page }) => {
    await page.goto('/members');

    await expect(page.getByText('1 - 10 of 100')).toBeVisible();
    await page.getByRole('button', { name: 'Next page' }).click();
    await expect(page.getByText('11 - 20 of 100')).toBeVisible();
  });

  test('mat-snack-bar notification', async ({ page }) => {
    await page.goto('/preferences');

    await page.getByRole('button', { name: 'Save' }).click();
    await expect(page.getByText('Changes saved')).toBeVisible();
  });

  test('mat-stepper wizard', async ({ page }) => {
    await page.goto('/wizard');

    await expect(page.getByText('Step 1 of 3')).toBeVisible();
    await page.getByLabel('Name').fill('Bob');
    await page.getByRole('button', { name: 'Next' }).click();

    await expect(page.getByText('Step 2 of 3')).toBeVisible();
    await page.getByLabel('Organization').fill('Acme');
    await page.getByRole('button', { name: 'Next' }).click();

    await expect(page.getByText('Step 3 of 3')).toBeVisible();
    await expect(page.getByText('Bob')).toBeVisible();
  });
});
```

## Router Navigation

```javascript
test.describe('Angular Router', () => {
  test('lazy-loaded module loads on navigation', async ({ page }) => {
    await page.goto('/');

    await page.getByRole('link', { name: 'Reports' }).click();
    await page.waitForURL('/reports');

    await expect(page.getByRole('heading', { name: 'Reports Dashboard' })).toBeVisible();
  });

  test('route guard redirects unauthorized users', async ({ page }) => {
    await page.goto('/admin/settings');
    await expect(page).toHaveURL(/\/login/);
  });

  test('query parameters drive filters', async ({ page }) => {
    await page.goto('/products?type=hardware&page=3');

    await expect(page.getByRole('heading', { name: 'Hardware' })).toBeVisible();
    await expect(page.getByText('Page 3')).toBeVisible();
  });

  test('browser back navigates history', async ({ page }) => {
    await page.goto('/');
    await page.getByRole('link', { name: 'Products' }).click();
    await page.waitForURL('/products');
    await page.getByRole('link', { name: 'About' }).click();
    await page.waitForURL('/about');

    await page.goBack();
    await expect(page).toHaveURL(/\/products/);
  });
});
```

## Lazy-Loaded Modules

```javascript
test('lazy module loads without chunk errors', async ({ page }) => {
  const consoleErrors = [];
  page.on('console', (msg) => {
    if (msg.type() === 'error') consoleErrors.push(msg.text());
  });

  await page.goto('/');

  const chunkRequest = page.waitForResponse((r) =>
    r.url().includes('.js') && r.status() === 200
  );
  await page.getByRole('link', { name: 'Analytics' }).click();
  await chunkRequest;

  await page.waitForURL('/analytics');
  await expect(page.getByRole('heading', { name: 'Analytics' })).toBeVisible();

  const chunkErrors = consoleErrors.filter(
    (e) => e.includes('ChunkLoadError') || e.includes('Loading chunk')
  );
  expect(chunkErrors).toEqual([]);
});
```

## Signals and Observables

Playwright cannot subscribe to observables or read signals directly. Test through the rendered output.

```javascript
test('signal-based counter updates DOM', async ({ page }) => {
  await page.goto('/counter');

  await expect(page.getByTestId('value')).toHaveText('0');
  await page.getByRole('button', { name: 'Increment' }).click();
  await expect(page.getByTestId('value')).toHaveText('1');
  await page.getByRole('button', { name: 'Reset' }).click();
  await expect(page.getByTestId('value')).toHaveText('0');
});

test('debounced search batches API calls', async ({ page }) => {
  await page.goto('/search');

  const apiCalls = [];
  await page.route('**/api/search*', async (route) => {
    apiCalls.push(route.request().url());
    await route.continue();
  });

  await page.getByRole('textbox', { name: 'Search' }).pressSequentially('playwright', {
    delay: 50,
  });

  await expect(page.getByRole('listitem')).toHaveCount(5);
  expect(apiCalls.length).toBeLessThanOrEqual(2);
});
```

## Zone.js and Change Detection

Angular uses Zone.js for change detection. Playwright does not depend on Zone.js and interacts with the DOM directly.

- **Change detection timing**: After interactions, Angular schedules change detection via Zone.js. Playwright's auto-waiting handles this — no `waitForAngular()` needed.
- **Zoneless Angular**: Angular 17+ supports zoneless change detection. Tests work identically.
- **Long-running async**: `setInterval` or long-running observables do not affect Playwright (unlike Protractor).

## Protractor Migration Reference

| Protractor | Playwright |
|---|---|
| `element(by.css('.btn'))` | `page.getByRole('button', { name: '...' })` |
| `element(by.id('login'))` | `page.getByTestId('login')` |
| `element(by.buttonText('Submit'))` | `page.getByRole('button', { name: 'Submit' })` |
| `element(by.model('user.name'))` | `page.getByLabel('Name')` |
| `browser.waitForAngular()` | Not needed — Playwright auto-waits |
| `browser.sleep(3000)` | `await expect(locator).toBeVisible()` |
| `browser.get('/path')` | `await page.goto('/path')` |
| `protractor.ExpectedConditions` | `await expect(locator).toBeVisible()` |

## CDK Overlay Container

Angular Material and CDK render overlays (dialogs, menus, selects) in a special container outside the component tree. Playwright sees these as regular DOM elements:

```javascript
const dialog = page.getByRole('dialog');
const menu = page.getByRole('menu');
const listbox = page.getByRole('listbox');
```

## Anti-Patterns

| Anti-Pattern | Problem | Solution |
|---|---|---|
| `page.locator('[_ngcontent-xyz]')` | Scoped style attributes change every build | Use `getByRole`, `getByLabel`, `getByTestId` |
| `page.locator('[ng-reflect-model]')` | Only exists in dev mode | Test rendered value: `expect(input).toHaveValue()` |
| `page.locator('app-my-component')` | Component selectors are implementation details | Target rendered content with semantic locators |
| `page.locator('.mat-mdc-button')` | Material classes change between versions | `page.getByRole('button', { name: '...' })` |
| `await page.waitForTimeout(500)` | Zone.js timing varies | Use auto-retrying assertions |
| `browser.waitForAngular()` | Does not exist in Playwright | Remove entirely |

---

# MXTS-Specific Patterns

All Maxxton apps are Angular, but MXTS has gotchas that differ from stock Angular. Apply every pattern
below to every spec.

## Pagination — Filter before asserting rows

If a snapshot shows pagination (`1-10 of N`, `chevron_right`, page spinbutton), the table shows only a
subset of rows. Any code that finds or asserts a specific row by name — in a helper OR a verify step —
MUST first filter using the search box. Never rely on `getByRole('row', { name: /.../ })` directly on a
paginated table, even for `not.toBeVisible()` checks — a row absent from page 1 might be on page 4, not
actually gone.

## Search-Dropdown Pattern — Click the field option after typing

Some MXTS list pages use a **field-selector search**: typing opens a dropdown showing `"Name : <query>"`
and `"Topic : <query>"`. The table does NOT filter until you click one of these options:

```js
await page.getByRole('textbox', { name: 'Search' }).pressSequentially(name, { delay: 30 });
const nameOption = page.locator('li').filter({ hasText: 'Name :' });
await expect(nameOption).toBeVisible({ timeout: 5000 });
await nameOption.click();
await expect(page.getByRole('row', { name: new RegExp(name) })).toBeVisible({ timeout: 10000 });
```

## `fill()` Anti-Pattern — Use `pressSequentially` for ALL search/filter inputs

`fill()` bypasses keyboard events (`keydown`, `keyup`, `input`) that Angular reactive forms rely on to
trigger change detection. In MXTS this silently fails for list search boxes, filter panel inputs,
autocomplete fields, and any input driving live filtering. **Rule:** `pressSequentially(text, { delay: 30 })`
for ALL search and filter inputs. `fill()` is only safe for static form fields.

## Sidebar Toggle-Safe Navigation

MXTS sidebar items are toggle buttons — clicking an already-open item collapses it. Guard every nav click:

```js
const targetLink = page.getByRole('link', { name: '<SubPage>' });
if (!(await targetLink.isVisible())) {
  await page.getByText('<iconName><MenuLabel>').click();
  await expect(targetLink).toBeVisible({ timeout: 5000 });
}
await targetLink.click();
```

## Sidebar DOM Detach — Use `page.goto()` as fallback

If a sidebar link keeps throwing "detached from DOM" (Angular re-renders the sidebar during route
transitions), skip the click and navigate by URL:

```js
const targetUrl = page.url().replace(/\/module-a\/.*$/, '/module-b/sub-page');
await page.goto(targetUrl);
```

## `<tr>` Click Anti-Pattern on Unfiltered Paginated Tables

Clicking `getByRole('row').first()` on an unfiltered MXTS list does NOT trigger Angular router navigation
— `<tr>` has no click handler; navigation is bound to a child cell or link. The click fires silently and
the URL never changes. Always navigate to a specific row via the field-selector search or a
`createEntity` + `openEntity` helper. Never use `.first()` on an unfiltered table to navigate.

## Angular Component Reuse — Filter Chips Persist on Same-URL Navigation

When a test action (archive, save) redirects to the SAME route it started on (e.g. `/caseworkflows` →
detail → `/caseworkflows`), Angular reuses the component instance — filter chips and search text are NOT
reset. If the next step needs a clean search state, call `await page.reload()` before using the search
box, followed by `await expect(searchBox).toBeVisible({ timeout: 10000 })` before typing.

## MXTS Selector Anti-Patterns

| Anti-pattern | Why it breaks | Correct approach |
|---|---|---|
| `locator('.cdk-overlay-container').getByText(...)` without checking | Maxxton uses custom `auto-complete-search`/`data-list` components — CDK overlay may not be the container | Run `browser_evaluate` after opening dropdown to find the real parent |
| `getByRole('option')` inside Angular dropdowns | Custom Angular list items are `<li>`, not `role="option"` | Use `locator('auto-complete-search li')` or the verified container |
| `locator('span').filter({ hasText: '...' })` on generic spans | Matches multiple elements → strict mode violation | Narrow with a CSS class: `locator('span.open-select')`, verify count = 1 |
| `locator('.align-right > div:nth-child(2)')` or positional CSS | Fragile — position changes break the test | Find the accessible name, prefer `getByRole('button', { name: '...' })` |
| Assuming Next/Submit button state | Angular disabler component blocks clicks when form is incomplete | Fill ALL required fields, verify `isDisabled: false` before clicking |
| Using `browser_evaluate` to verify clicks | JS `.click()` bypasses Angular `disabler`/guards — a passing JS click is NOT proof the locator works | Always use `browser_click`; observe the actual page change |
| Archive/delete steps without real click verification | Test account may lack permission — evaluate-click bypasses guards, spec fails in CI | Use `browser_click` on the real element; if it fails, tell the user the account lacks permission |
| `page.getByText('archive Archive')` / icon+label buttons | Material icon names are part of text — multiple ancestors share it → strict mode violation | Scope to the leaf: `page.locator('a.menu-item__option').filter({ hasText: '...' })` |
| `page.getByText('more_vert')` | Matches 2 elements (`PAGE-HEADER-MENU` + `icon-button`) → strict mode violation | `page.locator('icon-button').filter({ hasText: 'more_vert' })` |
| Assuming app stays on list after create/save | Multi-step wizards redirect to the detail page | After the final create button, navigate back explicitly |
| Checking status text to verify archive state | Archive is separate from the Active/Inactive toggle — toggle stays "Active" | Check the item has class `menu-item--disabled` after archive |

## MXTS Failure Diagnosis

Use this table when a burn-in run fails (burn-in: SKILL.md Step 7):

| Symptom | Root cause | Fix |
|---|---|---|
| `toHaveURL` unchanged after row click | `<tr>` click doesn't trigger Angular router | Use `createWorkflow` + `openWorkflow` instead of `.first().click()` |
| `Name :` dropdown never appears after typing | `fill()` used instead of `pressSequentially` | Replace `fill()` with `pressSequentially(text, { delay: 30 })` |
| Row not found on paginated table | No search filter applied | Use field-selector search before asserting row visibility |
| `Name :` dropdown appears on run 1, not run 2 | Angular component reuse — filter chip still active | `await page.reload()` before searching, then `await expect(searchBox).toBeVisible()` |
| Link `detached from DOM` during click | Sidebar re-rendering after route change | Replace sidebar link click with `page.goto(targetUrl)` |
| Same test fails identically every run | Real selector or logic bug | Fix the locator or assertion |
| Test fails only on run 2 or 3 | Flaky state leak | Check for missing `page.reload()`, leftover filter chips, or shared state |

---

## Related

- [locators-and-assertions.md](locators-and-assertions.md) — locators + auto-waiting assertions
- [interactions.md](interactions.md) — form & drag-drop patterns
- [flaky-tests.md](flaky-tests.md) — debugging flaky runs
