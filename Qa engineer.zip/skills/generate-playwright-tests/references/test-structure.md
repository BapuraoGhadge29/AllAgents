# Test Structure, Annotations & Tags

Covers how to **structure** a suite (config, describe/beforeEach, isolation, directory layout) and how
to **declare** tests (steps, skip/fixme/fail/slow, tags).

> **Maxxton import:** Examples below use the generic `require('@playwright/test')` for reference. All Maxxton module specs must use `import { test, expect } from '#mxts-test'` instead — see SKILL.md Step 6 Import section.

## Table of Contents

1. [Configuration](#configuration)
2. [E2E Tests](#e2e-tests)
3. [API Mocking](#api-mocking)
4. [Visual Regression Tests](#visual-regression-tests)
5. [Directory Structure](#directory-structure)
6. [Tagging & Filtering](#tagging--filtering)

## Configuration

### Essential Configuration

```javascript
// playwright.config.js
const { defineConfig, devices } = require("@playwright/test");

module.exports = defineConfig({
  testDir: "./tests",
  fullyParallel: true,
  forbidOnly: !!process.env.CI,
  retries: process.env.CI ? 2 : 0,
  workers: process.env.CI ? 1 : undefined,
  reporter: [["html"], ["list"]],
  use: {
    baseURL: "http://localhost:3000",
    trace: "on-first-retry",
    screenshot: "only-on-failure",
  },
  projects: [
    {
      name: "chromium",
      use: { ...devices["Desktop Chrome"] },
    },
  ],
});
```

## E2E Tests

Full user journey tests through the browser.

### Structure

```javascript
// tests/e2e/checkout.spec.js
const { test, expect } = require("@playwright/test");

test.describe("Checkout Flow", () => {
  test.beforeEach(async ({ page }) => {
    await page.goto("/products");
  });

  test("complete purchase as guest", async ({ page }) => {
    // Add to cart
    await page.getByRole("button", { name: "Add to Cart" }).first().click();
    await expect(page.getByTestId("cart-count")).toHaveText("1");

    // Go to checkout
    await page.getByRole("link", { name: "Cart" }).click();
    await page.getByRole("button", { name: "Checkout" }).click();

    // Fill shipping
    await page.getByLabel("Email").fill("guest@example.com");
    await page.getByLabel("Address").fill("123 Test St");
    await page.getByRole("button", { name: "Continue" }).click();

    // Confirmation
    await expect(page.getByRole("heading")).toHaveText("Order Confirmed");
  });

  test("apply discount code", async ({ page }) => {
    await page.getByRole("button", { name: "Add to Cart" }).first().click();
    await page.getByRole("link", { name: "Cart" }).click();

    await page.getByLabel("Discount Code").fill("SAVE10");
    await page.getByRole("button", { name: "Apply" }).click();

    await expect(page.getByText("10% discount applied")).toBeVisible();
  });
});
```

### Best Practices

- Test critical user journeys
- Keep tests independent
- Use realistic data
- Clean up test data in teardown

## API Mocking

For E2E tests that need to mock API responses:

```javascript
// Mock single endpoint
test("displays mocked users", async ({ page }) => {
  await page.route("**/api/users", (route) =>
    route.fulfill({
      status: 200,
      json: [{ id: 1, name: "Test User" }],
    })
  );

  await page.goto("/users");
  await expect(page.getByText("Test User")).toBeVisible();
});

// Mock with different responses
test("handles API errors", async ({ page }) => {
  await page.route("**/api/users", (route) =>
    route.fulfill({
      status: 500,
      json: { error: "Server error" },
    })
  );

  await page.goto("/users");
  await expect(page.getByText("Server error")).toBeVisible();
});

// Mock with delay (simulate slow network)
test("handles slow API", async ({ page }) => {
  await page.route("**/api/data", (route) =>
    route.fulfill({
      json: { data: "test" },
      delay: 2000,
    })
  );

  await page.goto("/dashboard");
  await expect(page.getByText("Loading...")).toBeVisible();
  await expect(page.getByText("test")).toBeVisible();
});
```

## Visual Regression Tests

```javascript
// tests/visual/homepage.spec.js
const { test, expect } = require("@playwright/test");

test("homepage visual", async ({ page }) => {
  await page.goto("/");
  await expect(page).toHaveScreenshot("homepage.png");
});

test("dashboard visual", async ({ page }) => {
  await page.goto("/dashboard");

  await expect(page).toHaveScreenshot("dashboard.png", {
    fullPage: true,
    maxDiffPixels: 100,
    animations: "disabled",
    mask: [page.getByTestId("date")],
  });
});
```

## Directory Structure

```
tests/
├── modules/                # Feature module tests (Maxxton convention)
│   └── <module>/
│       └── <sub_menu>/
│           └── <feature>/
│               └── <name>.spec.js
├── fixtures/               # Custom fixtures
│   └── auth.fixture.js
└── pages/                  # Page objects
    ├── login.page.js
    └── dashboard.page.js
```

## Anti-Patterns to Avoid

| Anti-Pattern                          | Problem                            | Solution                  |
| ------------------------------------- | ---------------------------------- | ------------------------- |
| Long test files                       | Hard to maintain, slow to navigate | Split by feature, use POM |
| Tests depend on execution order       | Flaky, hard to debug               | Keep tests independent    |
| Testing multiple features in one test | Hard to debug failures             | One feature per test      |

---

# Annotations, Steps & Tags

## Skip Annotations

```javascript
// Skip unconditionally
test.skip("feature not implemented", async ({ page }) => {});

// Conditional skip
test("webkit-specific feature", async ({ page, browserName }) => {
  test.skip(browserName !== "webkit", "This feature only works in WebKit");
});

// Skip in CI
test("local only feature", async ({ page }) => {
  test.skip(!!process.env.CI, "Uses local resources");
});
```

## Fixme & Fail

```javascript
// Mark as needing fix (skips the test)
test.fixme("broken after refactor", async ({ page }) => {});

// Expected failure (runs but expects failure)
test("known bug", async ({ page }) => {
  test.fail();
});
```

| Annotation     | Runs? | Use Case                         |
| -------------- | ----- | -------------------------------- |
| `test.skip()`  | No    | Feature not applicable           |
| `test.fixme()` | No    | Known bug, needs investigation   |
| `test.fail()`  | Yes   | Expected to fail, tracking a bug |

## Slow Tests

```javascript
test("large data import", async ({ page }) => {
  test.slow();             // Triple the default timeout
});

test("very long operation", async ({ page }) => {
  test.setTimeout(120000); // Specific timeout
});
```

## Test Steps — MANDATORY for Maxxton specs

Wrap every logical group of actions in a named `test.step()`. Required in all Maxxton spec files.

```javascript
test("Add_Case [@customercare @casesmodule]", async ({ page }) => {
  await test.step("Navigate to Cases", async () => {
    await page.getByText("assignmentCases").click();
    await page.getByRole("link", { name: "All cases" }).click();
    await expect(page).toHaveURL(/\/cases\/allcases/);
  });

  await test.step("Open create dialog", async () => {
    await page.getByText("New case").click();
    await expect(page.getByRole("dialog", { name: "Create case" })).toBeVisible();
  });

  await test.step("Verify success", async () => {
    await expect(page.locator("snackbar#snackbar")).toContainText("Created successfully");
  });
});
```

### Steps with Return Values

```javascript
const orderId = await test.step("Create order", async () => {
  await page.getByRole("button", { name: "Place Order" }).click();
  return await page.getByTestId("order-id").textContent();
});
```

## Test Tags

Tags are **mandatory** in every Maxxton spec. They go **inside square brackets at the end of the test
name**. Derive from the file path:

```javascript
// tests/modules/customer_care/cases_menu/... → [@customercare @casesmodule]
// tests/modules/reservation_manager/...      → [@reservationmanager]

test("Add_Case [@customercare @casesmodule]", async ({ page }) => { ... });
```

**Never use `@migrated`.**

### Standard Playwright Tagging

```javascript
test("user login @smoke @auth", async ({ page }) => { ... });
test("test login page", { tag: "@fast" }, async ({ page }) => { ... });
test.describe("report tests", { tag: "@report" }, () => { ... });
```

### Running Tagged Tests

```bash
npx playwright test --grep @smoke                        # only @smoke
npx playwright test --grep-invert @slow                  # all except @slow
npx playwright test --grep "@smoke|@critical"            # OR
npx playwright test --grep "(?=.*@smoke)(?=.*@critical)" # AND
```

### Common Tag Categories

| Category | Tags | Purpose |
|---|---|---|
| **Speed** | `@fast`, `@slow` | Execution time |
| **Priority** | `@critical`, `@p0`, `@p1`, `@p2` | Business importance |
| **Type** | `@smoke`, `@regression`, `@e2e` | Suite categorization |
| **Module** | `@customercare`, `@reservationmanager` | Module grouping (Maxxton) |
| **Pipeline** | `@pr`, `@nightly` | CI/CD timing |

## Annotation & Tag Anti-Patterns

| Anti-Pattern | Problem | Solution |
|---|---|---|
| Skipping without reason | Hard to track why | Always provide a description |
| Using skip instead of fixme | Loses intent | `fixme` for bugs, `skip` for N/A |
| Not using steps | Hard to debug failures | Group logical actions in steps |
| Missing `@` prefix on tags | Tags won't match `--grep` | Always prefix with `@` |
| Too many tags per test | Hard to maintain | Limit to 2-3 relevant tags |
