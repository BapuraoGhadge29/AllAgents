# Interaction Patterns: Forms & Drag-and-Drop

> **When to use**: Testing form filling, submission, validation, multi-step wizards, auto-complete, and drag-and-drop interactions (sortable lists, kanban boards, file drop zones).

This file covers two interaction areas:
1. [Form Testing Patterns](#form-testing-patterns)
2. [Drag and Drop Testing](#drag-and-drop-testing)

---

# Form Testing Patterns

## Quick Reference

```javascript
// Text input
await page.getByLabel("Username").fill("john_doe");

// Select dropdown (native <select>)
await page.getByLabel("Region").selectOption("EU");
await page.getByLabel("Region").selectOption({ label: "Europe" });

// Checkbox
await page.getByLabel("Subscribe").check();

// Date input
await page.getByLabel("Departure").fill("2025-08-20");

// Clear a field
await page.getByLabel("Username").clear();

// Submit
await page.getByRole("button", { name: "Register" }).click();

// Verify validation error
await expect(page.getByText("Username is required")).toBeVisible();
```

## Auto-Complete and Typeahead Fields

```javascript
test("select from typeahead suggestions", async ({ page }) => {
  const searchBox = page.getByRole("combobox", { name: "Find product" });
  await searchBox.pressSequentially("lapt", { delay: 100 });

  const suggestionList = page.getByRole("listbox");
  await expect(suggestionList).toBeVisible();

  await suggestionList.getByRole("option", { name: "Laptop Pro" }).click();
  await expect(searchBox).toHaveValue("Laptop Pro");
});

// Typeahead with API-driven suggestions
test("address lookup", async ({ page }) => {
  const streetField = page.getByLabel("Street");
  const responsePromise = page.waitForResponse("**/api/address-lookup*");
  await streetField.pressSequentially("456 Elm", { delay: 50 });

  await responsePromise;

  await page.getByRole("option", { name: /456 Elm St/ }).click();
  await expect(page.getByLabel("Town")).toHaveValue("Austin");
});
```

## Dynamic Forms — Conditional Fields

```javascript
test("conditional fields appear based on selection", async ({ page }) => {
  await page.getByLabel("Applicant type").selectOption("corporate");

  await expect(page.getByLabel("Business name")).toBeVisible();
  await expect(page.getByLabel("EIN")).toBeVisible();

  await page.getByLabel("Applicant type").selectOption("individual");
  await expect(page.getByLabel("Business name")).not.toBeVisible();
});

test("dependent dropdown chains", async ({ page }) => {
  await page.getByLabel("Country").selectOption("CA");

  const provinceDropdown = page.getByLabel("Province");
  await expect(provinceDropdown.getByRole("option")).not.toHaveCount(0);

  await provinceDropdown.selectOption("ON");
});
```

## Multi-Step Forms and Wizards

```javascript
test("complete a multi-step booking wizard", async ({ page }) => {
  await page.goto("/booking");

  await test.step("enter guest information", async () => {
    await expect(page.getByRole("heading", { name: "Guest Info" })).toBeVisible();
    await page.getByLabel("Full name").fill("Alice Smith");
    await page.getByLabel("Email").fill("alice@test.com");
    await page.getByRole("button", { name: "Next" }).click();
  });

  await test.step("select room options", async () => {
    await expect(page.getByRole("heading", { name: "Room Selection" })).toBeVisible();
    await page.getByLabel("Room type").selectOption("suite");
    await page.getByLabel("Check-in").fill("2025-09-01");
    await page.getByRole("button", { name: "Next" }).click();
  });

  await test.step("confirm booking", async () => {
    await expect(page.getByRole("heading", { name: "Confirmation" })).toBeVisible();
    await expect(page.getByText("Alice Smith")).toBeVisible();
    await page.getByRole("button", { name: "Confirm booking" }).click();
  });

  await expect(page.getByRole("heading", { name: "Booking complete" })).toBeVisible();
});

// Wizard validates each step before proceeding
test("wizard validates step", async ({ page }) => {
  await page.goto("/booking");
  await page.getByRole("button", { name: "Next" }).click();

  // Should NOT advance — required fields missing
  await expect(page.getByRole("heading", { name: "Guest Info" })).toBeVisible();
  await expect(page.getByText("Full name is required")).toBeVisible();
});

// Going back preserves data
test("wizard back button preserves data", async ({ page }) => {
  await page.goto("/booking");
  await page.getByLabel("Full name").fill("Alice Smith");
  await page.getByRole("button", { name: "Next" }).click();
  await page.getByRole("button", { name: "Previous" }).click();

  await expect(page.getByLabel("Full name")).toHaveValue("Alice Smith");
});
```

## Form Submission and Response Handling

```javascript
// Success flow
test("successful form submission", async ({ page }) => {
  await page.goto("/feedback");
  await page.getByLabel("Subject").fill("Feature request");
  await page.getByLabel("Email").fill("user@test.com");
  await page.getByLabel("Details").fill("Please add dark mode");

  const responsePromise = page.waitForResponse("**/api/feedback");
  await page.getByRole("button", { name: "Submit feedback" }).click();
  const response = await responsePromise;

  expect(response.status()).toBe(200);
  await expect(page.getByText("Feedback received")).toBeVisible();
});

// Server-side validation errors
test("server-side validation errors", async ({ page }) => {
  await page.goto("/signup");
  await page.getByLabel("Email").fill("existing@test.com");
  await page.getByRole("button", { name: "Sign up" }).click();

  await expect(page.getByText("Email address already registered")).toBeVisible();
});

// Loading state during submission
test("loading state during submission", async ({ page }) => {
  const submit = page.getByRole("button", { name: /Submit|Submitting/ });
  await submit.click();

  await expect(submit).toHaveText(/Submitting/);
  await expect(submit).toBeDisabled();
});
```

## Required Field Validation

```javascript
test("shows validation errors for empty required fields", async ({ page }) => {
  await page.goto("/inquiry");
  await page.getByRole("button", { name: "Send inquiry" }).click();

  await expect(page.getByText("Name is required")).toBeVisible();
  await expect(page.getByText("Email is required")).toBeVisible();
});

test("clears validation errors when fields are filled", async ({ page }) => {
  await page.goto("/inquiry");
  await page.getByRole("button", { name: "Send inquiry" }).click();
  await expect(page.getByText("Name is required")).toBeVisible();

  await page.getByLabel("Name").fill("Carol Brown");
  await page.getByLabel("Email").focus(); // Trigger blur

  await expect(page.getByText("Name is required")).not.toBeVisible();
});
```

## Format Validation

```javascript
test("validates email format", async ({ page }) => {
  const emailField = page.getByLabel("Email");
  const invalidEmails = ["invalid", "missing@", "@nodomain.com"];

  for (const email of invalidEmails) {
    await emailField.fill(email);
    await emailField.blur();
    await expect(page.getByText("Enter a valid email address")).toBeVisible();
  }

  await emailField.fill("correct@domain.com");
  await emailField.blur();
  await expect(page.getByText("Enter a valid email address")).not.toBeVisible();
});
```

## Decision Guide

| Scenario                             | Approach                                          | Key API                                               |
| ------------------------------------ | ------------------------------------------------- | ----------------------------------------------------- |
| Standard text input                  | `fill()` (clears, then types)                     | `page.getByLabel('Field').fill('value')`              |
| Need keystroke events (autocomplete) | `pressSequentially()` with delay                  | `locator.pressSequentially('text', { delay: 100 })`   |
| Native `<select>` dropdown           | `selectOption()` by value or label                | `locator.selectOption('US')`                          |
| Custom dropdown (ARIA listbox)       | Click trigger, then select option role            | `getByRole('option', { name: '...' }).click()`        |
| Checkbox                             | `check()` / `uncheck()` (idempotent)              | `locator.check()`                                     |
| Date input (native)                  | `fill()` with ISO format                          | `locator.fill('2025-03-15')`                          |
| Validation errors                    | Submit, then assert error text                    | `expect(page.getByText('Required')).toBeVisible()`    |
| Multi-step wizard                    | `test.step()` per step, assert heading            | `await test.step('Step 1', async () => { ... })`      |
| Form submission                      | `waitForResponse` + click submit                  | Register response listener BEFORE click               |

## Anti-Patterns

| Don't Do This                              | Problem                                   | Do This Instead                                        |
| ------------------------------------------ | ----------------------------------------- | ------------------------------------------------------ |
| `locator.type('value')`                    | Appends to existing content; no clear     | `locator.fill('value')`                                |
| `locator.click()` on checkbox              | Toggles — if already checked, it unchecks | `locator.check()`                                      |
| `page.fill('#email', 'test@test.com')`     | CSS selector is fragile                   | `page.getByLabel('Email').fill('test@test.com')`       |
| `expect(await input.inputValue()).toBe(v)` | No auto-retry, race condition             | `await expect(input).toHaveValue('value')`             |
| `page.evaluate()` to fill fields          | Bypasses event handlers (no `input` event)| Use `fill()` or `pressSequentially()`                  |
| Hardcoding wait after selecting dropdown   | `waitForTimeout(500)` is flaky           | Wait for the dependent element to appear               |

## Troubleshooting

### `fill()` does nothing or clears but doesn't type

Likely a `contenteditable` div (rich text editor):

```javascript
const isContentEditable = await page.getByTestId("editor")
  .evaluate((el) => el.getAttribute("contenteditable"));

if (isContentEditable) {
  await page.getByTestId("editor").click();
  await page.getByTestId("editor").pressSequentially("Hello world");
}
```

### Validation errors do not appear after `fill()`

Validation may trigger on `blur`, but `fill()` doesn't trigger blur:

```javascript
await page.getByLabel("Email").fill("invalid");
await page.getByLabel("Email").blur(); // Explicitly trigger blur
await expect(page.getByText("Enter a valid email")).toBeVisible();
```

### `selectOption()` throws "not a select element"

The dropdown is a custom ARIA component, not a native `<select>`:

```javascript
await page.getByRole("combobox", { name: "Country" }).click();
await page.getByRole("option", { name: "United States" }).click();
```

---

# Drag and Drop Testing

## Kanban Board (Cross-Column Movement)

```javascript
const { test, expect } = require('#mxts-test');

test('moves card between columns', async ({ page }) => {
  await page.goto('/board');

  const backlog = page.locator('[data-column="backlog"]');
  const active = page.locator('[data-column="active"]');

  const ticket = backlog.getByText('Update API docs');
  await expect(ticket).toBeVisible();

  const backlogCountBefore = await backlog.getByRole('article').count();
  const activeCountBefore = await active.getByRole('article').count();

  await ticket.dragTo(active);

  await expect(active.getByText('Update API docs')).toBeVisible();
  await expect(backlog.getByText('Update API docs')).not.toBeVisible();

  await expect(backlog.getByRole('article')).toHaveCount(backlogCountBefore - 1);
  await expect(active.getByRole('article')).toHaveCount(activeCountBefore + 1);
});

test('verifies drag persists via API', async ({ page }) => {
  await page.goto('/board');

  const backlog = page.locator('[data-column="backlog"]');
  const active = page.locator('[data-column="active"]');

  const responsePromise = page.waitForResponse(
    (r) => r.url().includes('/api/tickets') && r.request().method() === 'PATCH'
  );

  await backlog.getByText('Update API docs').dragTo(active);

  const response = await responsePromise;
  expect(response.status()).toBe(200);

  const body = await response.json();
  expect(body.column).toBe('active');

  await page.reload();
  await expect(active.getByText('Update API docs')).toBeVisible();
});
```

## Sortable Lists (Reordering)

```javascript
test('reorders list items', async ({ page }) => {
  await page.goto('/priorities');

  const list = page.getByRole('list', { name: 'Priority list' });

  const initial = await list.getByRole('listitem').allTextContents();
  expect(initial[0]).toContain('Priority A');

  const priorityC = list.getByRole('listitem').filter({ hasText: 'Priority C' });
  const priorityA = list.getByRole('listitem').filter({ hasText: 'Priority A' });

  await priorityC.dragTo(priorityA);

  const reordered = await list.getByRole('listitem').allTextContents();
  expect(reordered[0]).toContain('Priority C');
});
```

### Incremental Mouse Movement for Custom Libraries

Some drag libraries (react-beautiful-dnd, dnd-kit) require incremental mouse movements:

```javascript
test('reorders with incremental mouse movements', async ({ page }) => {
  await page.goto('/priorities');

  const list = page.getByRole('list', { name: 'Priority list' });
  const source = list.getByRole('listitem').filter({ hasText: 'Priority C' });
  const target = list.getByRole('listitem').filter({ hasText: 'Priority A' });

  const sourceBox = await source.boundingBox();
  const targetBox = await target.boundingBox();

  await source.hover();
  await page.mouse.down();

  const steps = 10;
  for (let i = 1; i <= steps; i++) {
    await page.mouse.move(
      sourceBox.x + sourceBox.width / 2,
      sourceBox.y + (targetBox.y - sourceBox.y) * (i / steps),
      { steps: 1 }
    );
  }

  await page.mouse.up();

  const items = await list.getByRole('listitem').allTextContents();
  expect(items[0]).toContain('Priority C');
});
```

## Native HTML5 Drag and Drop

```javascript
test('drags item to drop zone', async ({ page }) => {
  await page.goto('/drag-example');

  const source = page.getByText('Movable Element');
  const dropArea = page.locator('#target-zone');

  await source.dragTo(dropArea);
  await expect(dropArea).toContainText('Movable Element');
});

test('verifies drag visual feedback', async ({ page }) => {
  await page.goto('/drag-example');

  const source = page.getByText('Movable Element');
  const dropArea = page.locator('#target-zone');

  await source.hover();
  await page.mouse.down();

  const dropBox = await dropArea.boundingBox();
  await page.mouse.move(dropBox.x + dropBox.width / 2, dropBox.y + dropBox.height / 2);

  await expect(dropArea).toHaveClass(/drag-over|highlight/);
  await page.mouse.up();

  await expect(dropArea).not.toHaveClass(/drag-over|highlight/);
  await expect(dropArea).toContainText('Movable Element');
});
```

## File Drop Zone

```javascript
const path = require('path');

test('uploads file via drop zone', async ({ page }) => {
  await page.goto('/upload');

  const fileInput = page.locator('input[type="file"]');
  await fileInput.setInputFiles(path.resolve(__dirname, '../fixtures/report.pdf'));

  await expect(page.getByText('report.pdf')).toBeVisible();
  await expect(page.getByText(/\d+ KB/)).toBeVisible();
});

test('simulates drag-over visual feedback', async ({ page }) => {
  await page.goto('/upload');

  const dropZone = page.locator('[data-testid="file-drop-zone"]');

  await dropZone.dispatchEvent('dragenter', {
    dataTransfer: { types: ['Files'] },
  });

  await expect(dropZone).toHaveClass(/drag-active|drop-highlight/);

  await dropZone.dispatchEvent('dragleave');
  await expect(dropZone).not.toHaveClass(/drag-active|drop-highlight/);
});

test('rejects invalid file types', async ({ page }) => {
  await page.goto('/upload');

  const fileInput = page.locator('input[type="file"]');
  await fileInput.setInputFiles({
    name: 'script.exe',
    mimeType: 'application/x-msdownload',
    buffer: Buffer.from('fake-content'),
  });

  await expect(page.getByRole('alert')).toContainText(/not allowed|invalid file type/i);
});
```

## Canvas Coordinate-Based Dragging

```javascript
test('drags element to specific coordinates', async ({ page }) => {
  await page.goto('/design-tool');

  const canvas = page.locator('#editor-canvas');
  const shape = page.locator('[data-testid="shape-1"]');

  const canvasBox = await canvas.boundingBox();
  const targetX = canvasBox.x + 300;
  const targetY = canvasBox.y + 200;

  await shape.hover();
  await page.mouse.down();
  await page.mouse.move(targetX, targetY, { steps: 10 });
  await page.mouse.up();

  const newBox = await shape.boundingBox();
  expect(newBox.x).toBeCloseTo(targetX - newBox.width / 2, -1);
  expect(newBox.y).toBeCloseTo(targetY - newBox.height / 2, -1);
});
```

## Drag-and-Drop Tips

1. **Start with `dragTo()`, fall back to manual mouse events.** Playwright's `dragTo()` handles most HTML5 drag-and-drop. Use `page.mouse.down()` / `move()` / `up()` only for custom libraries (react-beautiful-dnd, dnd-kit) that need specific event sequences.

2. **Add intermediate mouse steps for drag libraries.** Use `{ steps: 10 }` or a manual loop — a single jump often fails silently.

3. **Assert final state, not just the drop event.** Verify DOM reflects the change — item order, column contents, position coordinates.

4. **Use `boundingBox()` for coordinate assertions.** Compare with `toBeCloseTo()` for tolerance.

5. **Test undo after drag operations.** If your app supports Ctrl+Z, verify the drag is reversible — this catches state management bugs.
