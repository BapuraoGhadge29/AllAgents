# Test Architecture Decisions

> **When to use**: Deciding how to structure reusable test code (page objects, fixtures, helpers) and whether to mock services or hit them for real.

> **Maxxton import:** Examples below use `require('@playwright/test')` for reference. All Maxxton module specs must use `import { test, expect } from '#mxts-test'` instead — see SKILL.md Step 6 Import section.

This file covers two architecture decisions:
1. [Organizing Reusable Test Code](#organizing-reusable-test-code) — POM vs fixtures vs helpers
2. [Mocking Strategy: Real vs Mock Services](#mocking-strategy-real-vs-mock-services)

---

# Organizing Reusable Test Code

Use all three patterns together. Most projects benefit from a hybrid approach:

- **Page objects** for UI interaction (pages/components with 5+ interactions)
- **Custom fixtures** for test infrastructure (auth state, database, API clients)
- **Helper functions** for stateless utilities (generate data, format values)

## Pattern Comparison

| Aspect | Page Objects | Custom Fixtures | Helper Functions |
|---|---|---|---|
| **Purpose** | Encapsulate UI interactions | Provide resources with setup/teardown | Stateless utilities |
| **Lifecycle** | Manual (constructor/methods) | Built-in (`use()` with automatic teardown) | None |
| **Best for** | Pages with many reused interactions | Resources needing setup AND teardown | Simple logic with no side effects |

## Selection Flowchart

```text
What kind of reusable code?
|
+-- Interacts with browser page/component?
|   +-- Has 5+ interactions?
|   |   +-- YES: Used in 3+ test files? → PAGE OBJECT
|   |   +-- NO → Inline or small helper
|   +-- Needs setup before AND cleanup after test?
|       +-- YES → CUSTOM FIXTURE
|
+-- Manages resource with lifecycle (create/destroy)?
|   +-- auth state, DB connection, API client → CUSTOM FIXTURE
|
+-- Stateless utility? (no browser, no side effects)
|   +-- YES → HELPER FUNCTION
|
+-- Not sure? → Start with HELPER FUNCTION
```

## Page Objects

Best for pages/components with 5+ interactions appearing in 3+ test files.

```javascript
// page-objects/booking.page.js
class BookingPage {
  constructor(page) {
    this.page = page;
    this.dateField = page.getByLabel('Check-in date');
    this.guestCount = page.getByLabel('Guests');
    this.roomType = page.getByLabel('Room type');
    this.reserveBtn = page.getByRole('button', { name: 'Reserve' });
    this.totalPrice = page.getByTestId('total-price');
  }

  async goto() {
    await this.page.goto('/booking');
  }

  async fillDetails(opts) {
    await this.dateField.fill(opts.date);
    await this.guestCount.fill(String(opts.guests));
    await this.roomType.selectOption(opts.room);
  }

  async reserve() {
    await this.reserveBtn.click();
    await this.page.waitForURL('**/confirmation');
  }

  async expectPrice(amount) {
    await expect(this.totalPrice).toHaveText(amount);
  }
}

module.exports = { BookingPage };
```

```javascript
// tests/booking/reservation.spec.js
const { test, expect } = require('#mxts-test');
const { BookingPage } = require('../page-objects/booking.page');

test('complete reservation with standard room', async ({ page }) => {
  const booking = new BookingPage(page);
  await booking.goto();
  await booking.fillDetails({ date: '2026-03-15', guests: 2, room: 'standard' });
  await booking.reserve();
  await expect(page.getByText('Reservation confirmed')).toBeVisible();
});
```

**Page object principles:**
- One class per logical page/component, not per URL
- Constructor takes `page`
- Locators defined in constructor
- Methods represent user intent (`reserve`, `fillDetails`), not low-level clicks

## Custom Fixtures

Best for resources needing setup before and teardown after tests.

```javascript
// fixtures/base.fixture.js
const { test: base, expect } = require('@playwright/test');
const { BookingPage } = require('../page-objects/booking.page');

exports.test = base.extend({
  bookingPage: async ({ page }, use) => {
    await use(new BookingPage(page));
  },

  member: async ({ request }, use) => {
    const email = `member-${Date.now()}@test.local`;
    const res = await request.post('/api/test/members', {
      data: { email, password: 'SecurePass456!' }
    });
    const member = await res.json();
    await use(member);
    await request.delete(`/api/test/members/${member.id}`);
  },

  loggedInPage: async ({ page, member }, use) => {
    await page.goto('/login');
    await page.getByLabel('Email').fill(member.email);
    await page.getByLabel('Password').fill(member.password);
    await page.getByRole('button', { name: 'Sign in' }).click();
    await expect(page).toHaveURL('/dashboard');
    await use(page);
  },
});
```

**Fixture principles:**
- Use `test.extend()` — never module-level variables
- `use()` callback separates setup from teardown
- Teardown runs even if test fails
- Fixtures compose: one can depend on another

## Helper Functions

Best for stateless utilities — generating test data, formatting values, building URLs.

```javascript
// helpers/data.js
function generateEmail(prefix = 'user') {
  return `${prefix}-${Date.now()}@test.local`;
}

function generateMember(overrides = {}) {
  return {
    email: generateEmail(),
    password: 'SecurePass456!',
    name: 'Test Member',
    ...overrides,
  };
}

function formatPrice(cents) {
  return `$${(cents / 100).toFixed(2)}`;
}

module.exports = { generateEmail, generateMember, formatPrice };
```

```javascript
// helpers/assertions.js
async function expectNotification(page, message) {
  const notification = page.getByRole('alert').filter({ hasText: message });
  await expect(notification).toBeVisible();
  await expect(notification).toBeHidden({ timeout: 10000 });
}

module.exports = { expectNotification };
```

**Helper principles:**
- Pure functions with no side effects
- Take `page` as parameter if needed
- Promote to fixture if setup/teardown needed
- Keep small and focused

## Anti-Patterns

### Page object managing resources

```javascript
// BAD: page object handling API calls
class LoginPage {
  async createUser() { /* API call */ }
  async deleteUser() { /* API call */ }
}
// Resource lifecycle belongs in fixtures. Keep only signIn in the page object.
```

### Monolithic fixtures

```javascript
// BAD: one fixture doing everything
test.extend({
  everything: async ({ page, request }, use) => {
    const user = await createUser(request);
    const products = await seedProducts(request, 50);
    await page.goto('/dashboard');
    await use({ user, products, page });
    // massive teardown...
  },
});
// Break into small, composable fixtures. Each fixture does one thing.
```

### Helpers with side effects

```javascript
// BAD: module-level state leaks between tests
let createdUserId;
export async function createTestUser(request) {
  const user = await request.post('/api/users', ...);
  createdUserId = user.id; // shared across parallel tests!
  return user;
}
// If it has side effects and needs cleanup, make it a fixture.
```

---

# Mocking Strategy: Real vs Mock Services

## Core Principle

**Mock at the boundary, test your stack end-to-end.** Mock third-party services you don't own (payment gateways, email providers, OAuth). Never mock your own frontend-to-backend communication. Tests should prove YOUR code works, not that third-party APIs are available.

## Decision Matrix

| Scenario | Mock? | Strategy |
| --- | --- | --- |
| Your own REST/GraphQL API | Never | Hit real API against staging or local dev |
| Your database (through your API) | Never | Seed via API or fixtures |
| Authentication (your auth system) | Mostly no | Use `storageState` to skip login |
| Stripe / payment gateway | Always | `route.fulfill()` with expected responses |
| SendGrid / email service | Always | Mock the API call, verify request payload |
| OAuth providers (Google, GitHub) | Always | Mock token exchange, test your callback handler |
| Analytics (Segment, Mixpanel) | Always | `route.abort()` or `route.fulfill()` |
| Feature flags (LaunchDarkly) | Usually | Mock to force specific flag states |
| Flaky external dependency | CI: mock, local: real | Conditional mocking based on environment |

## Decision Flowchart

```text
Is this service part of YOUR codebase?
├── YES → Do NOT mock. Test the real integration.
│   ├── Is it slow? → Optimize the service, not the test.
│   └── Is it flaky? → Fix the service. Flaky infra is a bug.
└── NO → It's a third-party service.
    ├── Is it paid per call? → ALWAYS mock.
    ├── Is it rate-limited? → ALWAYS mock.
    ├── Is it slow or unreliable? → ALWAYS mock.
    └── Is it a complex multi-step flow? → Mock with HAR recording.
```

## Mocking Techniques

### Blocking Unwanted Requests

```javascript
test.beforeEach(async ({ page }) => {
  await page.route('**/{analytics,tracking,segment,hotjar}.{com,io}/**', (route) => {
    route.abort();
  });
});
```

### Full Mock (route.fulfill)

```javascript
test('order flow with mocked payment service', async ({ page }) => {
  await page.route('**/api/charge', (route) => {
    route.fulfill({
      status: 200,
      contentType: 'application/json',
      body: JSON.stringify({ transactionId: 'txn_mock_abc', status: 'completed' }),
    });
  });

  await page.goto('/order/confirm');
  await page.getByRole('button', { name: 'Complete Purchase' }).click();
  await expect(page.getByText('Order confirmed')).toBeVisible();
});

test('display error on payment decline', async ({ page }) => {
  await page.route('**/api/charge', (route) => {
    route.fulfill({
      status: 402,
      contentType: 'application/json',
      body: JSON.stringify({ error: { code: 'insufficient_funds', message: 'Card declined.' } }),
    });
  });

  await page.goto('/order/confirm');
  await page.getByRole('button', { name: 'Complete Purchase' }).click();
  await expect(page.getByRole('alert')).toContainText('Card declined');
});
```

### Partial Mock (Modify Responses)

```javascript
test('display low inventory warning', async ({ page }) => {
  await page.route('**/api/inventory/*', async (route) => {
    const response = await route.fetch();
    const data = await response.json();

    data.quantity = 1;
    data.lowStock = true;

    await route.fulfill({ response, body: JSON.stringify(data) });
  });

  await page.goto('/products/widget-pro');
  await expect(page.getByText('Only 1 remaining')).toBeVisible();
});
```

### Record and Replay (HAR Files)

```javascript
// Recording:
test('capture API traffic', async ({ page }) => {
  await page.routeFromHAR('tests/fixtures/admin-panel.har', {
    url: '**/api/**',
    update: true,
  });

  await page.goto('/admin');
});

// Replaying:
test('admin panel loads with recorded data', async ({ page }) => {
  await page.routeFromHAR('tests/fixtures/admin-panel.har', {
    url: '**/api/**',
    update: false,
  });

  await page.goto('/admin');
  await expect(page.getByRole('heading', { name: 'Reports' })).toBeVisible();
});
```

## Hybrid Approach: Fixture-Based Mock Control

```javascript
// tests/fixtures/service-mocks.js
exports.test = base.extend({
  mockPayments: [true, { option: true }],
  mockAnalytics: [true, { option: true }],

  page: async ({ page, mockPayments, mockAnalytics }, use) => {
    if (mockPayments) {
      await page.route('**/api/billing/**', (route) => {
        route.fulfill({
          status: 200,
          contentType: 'application/json',
          body: JSON.stringify({ status: 'paid', id: 'inv_mock_789' }),
        });
      });
    }

    if (mockAnalytics) {
      await page.route('**/{segment,mixpanel,amplitude}.**/**', (route) => {
        route.abort();
      });
    }

    await use(page);
  },
});
```

## Validating Mock Accuracy

Guard against mock drift from real APIs:

```javascript
test.describe('contract validation', () => {
  test('billing mock matches real API shape', async ({ request }) => {
    const realResponse = await request.post('/api/billing/charge', {
      data: { amount: 5000, currency: 'usd' },
    });
    const realBody = await realResponse.json();

    const mockBody = { status: 'paid', id: 'inv_mock_789' };

    expect(Object.keys(mockBody).sort()).toEqual(Object.keys(realBody).sort());
  });
});
```

## Anti-Patterns

| Don't Do This | Problem | Do This Instead |
| --- | --- | --- |
| Mock your own API | Tests pass, app breaks. Zero integration coverage. | Hit your real API. Mock only third-party services. |
| Mock everything for speed | You test a fiction. Frontend and backend may be incompatible. | Mock only external boundaries. |
| Never mock anything | Tests are slow, flaky, fail when third parties have outages. | Mock third-party services. |
| Use outdated mocks | Mock returns different shape than real API. | Run contract validation tests. Re-record HAR files. |
| Copy-paste mocks across files | One API change requires updating many files. | Centralize mocks in fixtures. |

---

# Page Object Model — Components & Composition

The "Page Objects" subsection above covers the basics. For larger UIs, also use **component objects**
and **composition**.

## Component Objects

For reusable UI components, scope the object to a container locator:

```javascript
// components/modal.component.js
class ModalComponent {
  constructor(container) {
    this.container = container;
    this.title = container.getByRole("heading");
    this.closeButton = container.getByRole("button", { name: "Close" });
    this.confirmButton = container.getByRole("button", { name: "Confirm" });
  }

  async expectTitle(title) {
    await expect(this.title).toHaveText(title);
  }

  async close() {
    await this.closeButton.click();
  }

  async confirm() {
    await this.confirmButton.click();
  }
}

module.exports = { ModalComponent };
```

## Composition — Page Returns Components

A page method that opens a dialog returns the component object for it:

```javascript
// pages/dashboard.page.js
const { ModalComponent } = require("../components/modal.component");

class DashboardPage {
  constructor(page) {
    this.page = page;
    this.newProjectButton = page.getByRole("button", { name: "New Project" });
  }

  async goto() {
    await this.page.goto("/dashboard");
  }

  async createProject() {
    await this.newProjectButton.click();
    return new ModalComponent(this.page.getByRole("dialog"));
  }
}

module.exports = { DashboardPage };
```

## POM Best Practices

**Do:**
- Keep locators in page objects — single source of truth
- Return new page/component objects when navigation occurs
- Expose elements for custom assertions in tests
- Use descriptive method names — `submitOrder()` not `clickButton()`
- Keep methods focused — one action per method

**Don't:**
- Include assertions in page methods (usually) — keep them in tests
- Expose implementation details — hide complex interactions
- Make page objects too large — split into components

**Directory structure:**

```
tests/
├── pages/          (login.page.js, dashboard.page.js)
├── components/     (modal.component.js, table.component.js)
└── specs/          (login.spec.js, dashboard.spec.js)
```

---

# Test Data & Factories

## Factory Pattern

```javascript
// factories/user.factory.js
let userIdCounter = 0;

function createUser(overrides = {}) {
  userIdCounter++;
  return {
    id: `user-${userIdCounter}`,
    email: `user${userIdCounter}@test.com`,
    name: `Test User ${userIdCounter}`,
    role: "user",
    ...overrides,
  };
}

module.exports = { createUser };
```

### Factory with Traits

```javascript
const traits = {
  outOfStock: { stock: 0 },
  featured: { featured: true },
  expensive: { price: 999.99 },
};

let productIdCounter = 0;

function createProduct(overrides = {}, ...traitNames) {
  productIdCounter++;
  const appliedTraits = traitNames.reduce(
    (acc, trait) => ({ ...acc, ...traits[trait] }),
    {}
  );
  return {
    id: `prod-${productIdCounter}`,
    name: `Product ${productIdCounter}`,
    price: 29.99,
    stock: 100,
    featured: false,
    ...appliedTraits,
    ...overrides,
  };
}

const featuredProduct = createProduct({}, "featured");
const soldOut = createProduct({}, "outOfStock");

module.exports = { createProduct };
```

## Data-Driven Testing

```javascript
const loginScenarios = [
  { email: "user@example.com", password: "pass123", expected: "Dashboard" },
  { email: "admin@example.com", password: "admin123", expected: "Admin Panel" },
  { email: "invalid@example.com", password: "wrong", expected: "Invalid credentials" },
];

for (const { email, password, expected } of loginScenarios) {
  test(`login with ${email}`, async ({ page }) => {
    await page.goto("/login");
    await page.getByLabel("Email").fill(email);
    await page.getByLabel("Password").fill(password);
    await page.getByRole("button", { name: "Sign In" }).click();
    await expect(page.getByText(expected)).toBeVisible();
  });
}
```

## Unique Data for Parallel Runs

When creating records in tests, append a `randomString()` suffix (from `#utils/account-data`) to keep names
unique and avoid conflicts between parallel runs (the MXTS suite runs in parallel by default). Do not use
`Date.now()`: two workers can call it in the same millisecond and collide.

```javascript
import { randomString } from "#utils/account-data";

test("create case", async ({ page }) => {
  const suffix = randomString();
  await page.getByRole("textbox", { name: "Name" }).fill(`Test Case ${suffix}`);
  // Each run creates a distinct record
});
```

## Fixture with Factory

```javascript
// fixtures/data.fixture.js
const { test: base } = require("@playwright/test");
const { createUser } = require("../factories/user.factory");

exports.test = base.extend({
  testUser: async ({}, use) => {
    const user = createUser({ name: "E2E Test User" });
    await use(user);
  },
});
```

## Test Data Anti-Patterns

| Anti-Pattern | Problem | Solution |
|---|---|---|
| Hardcoded test data | Brittle, repetitive | Use factories |
| Shared mutable test data | Tests interfere with each other | Create fresh data per test |
| Static names without uniqueness | Parallel run conflicts | Append a `randomString()` suffix |

---

## Related

- **Locator strategies**: See [locators-and-assertions.md](locators-and-assertions.md)
- **Advanced network interception** (GraphQL, conditional mocks, throttling): See [advanced.md](advanced.md)
