# Locators & Assertions

Covers how to **locate** elements and how to **assert/wait** on them — the two halves of every step.

## Table of Contents

1. [Priority Order](#priority-order)
2. [User-Facing Locators](#user-facing-locators)
3. [Filtering & Chaining](#filtering--chaining)
4. [Dynamic Content](#dynamic-content)
5. [Shadow DOM](#shadow-dom)
6. [Iframes](#iframes)

## Priority Order

Use locators in this order of preference:

1. **Role-based** (most resilient): `getByRole`
2. **Label-based**: `getByLabel`, `getByPlaceholder`
3. **Text-based**: `getByText`, `getByTitle`
4. **Test IDs** (when semantic locators aren't possible): `getByTestId`
5. **CSS/XPath** (last resort): `locator('css=...')`, `locator('xpath=...')`

## User-Facing Locators

### getByRole

Most robust approach - matches how users and assistive technology perceive the page.

```javascript
// Buttons
page.getByRole("button", { name: "Submit", exact: true }); // exact accessible name
page.getByRole("button", { name: /submit/i }); // flexible case-insensitive match

// Links
page.getByRole("link", { name: "Home" });

// Form elements
page.getByRole("textbox", { name: "Email" });
page.getByRole("checkbox", { name: "Remember me" });
page.getByRole("combobox", { name: "Country" });
page.getByRole("radio", { name: "Option A" });

// Headings
page.getByRole("heading", { name: "Welcome", level: 1 });

// Lists & items
page.getByRole("list").getByRole("listitem");

// Navigation & regions
page.getByRole("navigation");
page.getByRole("main");
page.getByRole("dialog");
page.getByRole("alert");
```

### getByLabel

For form elements with associated labels.

```javascript
// Input with <label for="email">
page.getByLabel("Email address");

// Input with aria-label
page.getByLabel("Search");

// Exact match
page.getByLabel("Email", { exact: true });
```

### getByPlaceholder

```javascript
page.getByPlaceholder("Enter your email");
page.getByPlaceholder(/email/i);
```

### getByText

```javascript
// Partial match (default)
page.getByText("Welcome");

// Exact match
page.getByText("Welcome to our site", { exact: true });

// Regex
page.getByText(/welcome/i);
```

### getByTestId

Configure custom test ID attribute in `playwright.config.js`:

```javascript
use: {
  testIdAttribute: "data-testid" // default
}
```

Usage:

```javascript
// HTML: <button data-testid="submit-btn">Submit</button>
page.getByTestId("submit-btn");
```

## Filtering & Chaining

### filter()

Narrow down locators:

```javascript
// Filter by text
page.getByRole("listitem").filter({ hasText: "Product" });

// Filter by NOT having text
page.getByRole("listitem").filter({ hasNotText: "Out of stock" });

// Filter by child locator
page.getByRole("listitem").filter({
  has: page.getByRole("button", { name: "Buy" }),
});

// Combine filters
page
  .getByRole("listitem")
  .filter({ hasText: "Product" })
  .filter({ has: page.getByText("$9.99") });
```

### Chaining

```javascript
// Navigate down the DOM tree
page.getByRole("article").getByRole("heading");

// Get parent/ancestor
page.getByText("Child").locator("..");
page.getByText("Child").locator("xpath=ancestor::article");
```

### nth() and first()/last()

```javascript
page.getByRole("listitem").first();
page.getByRole("listitem").last();
page.getByRole("listitem").nth(2); // 0-indexed
```

## Dynamic Content

### Waiting for Elements

Locators auto-wait for actionability by default. For explicit state waiting:

```javascript
await page.getByRole("button").waitFor({ state: "visible" });
await page.getByText("Loading").waitFor({ state: "hidden" });
```

### Lists with Dynamic Items

```javascript
// Wait for specific count
await expect(page.getByRole("listitem")).toHaveCount(5);

// Get all matching elements
const items = await page.getByRole("listitem").all();
for (const item of items) {
  await expect(item).toBeVisible();
}
```

## Shadow DOM

Playwright pierces shadow DOM by default:

```javascript
// Automatically finds elements inside shadow roots
page.getByRole("button", { name: "Shadow Button" });
```

## Iframes

```javascript
// By frame name or URL
const frame = page.frameLocator('iframe[name="content"]');
await frame.getByRole("button").click();

// By index
const frame = page.frameLocator("iframe").first();

// Nested iframes
const nestedFrame = page.frameLocator("#outer").frameLocator("#inner");
await nestedFrame.getByText("Content").click();
```

## Debugging Locators

```javascript
// Highlight element in headed mode
await page.getByRole("button").highlight();

// Count matches
const count = await page.getByRole("listitem").count();

// Check if exists without waiting
const exists = (await page.getByRole("button").count()) > 0;

// Use Playwright Inspector
// PWDEBUG=1 npx playwright test
```

## Common Issues & Solutions

| Issue                   | Solution                                         |
| ----------------------- | ------------------------------------------------ |
| Multiple elements match | Add filters or use `nth()`, `first()`, `last()`  |
| Element not found       | Check visibility, wait for load, verify selector |
| Stale element           | Locators are lazy; re-query if DOM changes       |
| Dynamic IDs             | Use stable attributes like role, text, test-id   |
| Hidden elements         | Use `{ force: true }` only when necessary        |

## Locator Anti-Patterns to Avoid

| Anti-Pattern                      | Problem                           | Solution                                          |
| --------------------------------- | --------------------------------- | ------------------------------------------------- |
| `page.locator('.btn-primary')`    | Brittle, implementation-dependent | `page.getByRole('button', { name: 'Submit' })`    |
| `page.locator('#dynamic-id-123')` | Breaks when IDs change            | Use stable attributes like role, text, or test-id |
| Testing implementation details    | Breaks on refactoring             | Test user-visible behavior                        |

---

# Assertions & Waiting

## Web-First Assertions

Auto-retry until condition is met or timeout. Always prefer these over generic assertions.

### Locator Assertions

```javascript
const { expect } = require("@playwright/test");

// Visibility
await expect(page.getByRole("button")).toBeVisible();
await expect(page.getByRole("button")).toBeHidden();
await expect(page.getByRole("button")).not.toBeVisible();

// Enabled/Disabled
await expect(page.getByRole("button")).toBeEnabled();
await expect(page.getByRole("button")).toBeDisabled();

// Text content
await expect(page.getByRole("heading")).toHaveText("Welcome");
await expect(page.getByRole("heading")).toHaveText(/welcome/i);
await expect(page.getByRole("heading")).toContainText("Welcome");

// Count
await expect(page.getByRole("listitem")).toHaveCount(5);

// Attributes
await expect(page.getByRole("link")).toHaveAttribute("href", "/home");

// CSS
await expect(page.getByRole("button")).toHaveClass(/primary/);
await expect(page.getByRole("button")).toHaveCSS("color", "rgb(0, 0, 255)");

// Input values
await expect(page.getByLabel("Email")).toHaveValue("user@example.com");
await expect(page.getByLabel("Email")).toBeEmpty();

// Focus
await expect(page.getByLabel("Email")).toBeFocused();

// Checked state
await expect(page.getByRole("checkbox")).toBeChecked();
await expect(page.getByRole("checkbox")).not.toBeChecked();
```

### Page Assertions

```javascript
await expect(page).toHaveURL("/dashboard");
await expect(page).toHaveURL(/\/dashboard/);
await expect(page).toHaveTitle("Dashboard - MyApp");
await expect(page).toHaveTitle(/dashboard/i);
```

### Response Assertions

```javascript
const response = await page.request.get("/api/users");
await expect(response).toBeOK();
```

## Generic Assertions

Use for non-UI values. Do NOT retry — execute immediately.

```javascript
expect(value).toBe(5);
expect(object).toEqual({ name: "Test" });
expect(array).toContain("item");
expect(value).toBeTruthy();
expect(value).toBeNull();
expect(value).toBeGreaterThan(5);
expect(string).toMatch(/pattern/);
expect(array).toHaveLength(3);
expect(object).toHaveProperty("key", "value");
```

## Soft Assertions

Continue test execution after failure, report all failures at end.

```javascript
test("check multiple elements", async ({ page }) => {
  await page.goto("/dashboard");

  await expect.soft(page.getByRole("heading")).toHaveText("Dashboard");
  await expect.soft(page.getByRole("button", { name: "Save" })).toBeEnabled();
  await expect.soft(page.getByText("Welcome")).toBeVisible();
  // Test continues; all failures reported at end
});
```

## Waiting Strategies

### Auto-Waiting (Default)

Actions automatically wait for the element to be attached, visible, stable, enabled, and able to
receive events:

```javascript
// These auto-wait — no need for explicit waits
await page.getByRole("button").click();
await page.fill("input", "text");
```

### Wait for Navigation

```javascript
await page.waitForURL("/dashboard");

const urlPromise = page.waitForURL("**/dashboard");
await page.click("a");
await urlPromise;
```

### Wait for Network

```javascript
const responsePromise = page.waitForResponse("**/api/users");
await page.click("button");
const response = await responsePromise;
expect(response.status()).toBe(200);

await page.waitForLoadState("networkidle");
```

### Wait for Element State

```javascript
await page.getByRole("dialog").waitFor({ state: "visible" });
await page.getByText("Loading...").waitFor({ state: "hidden" });
await page.getByTestId("result").waitFor({ state: "attached" });
await page.getByTestId("modal").waitFor({ state: "detached" });
```

## Polling & Retrying

### toPass() for Polling

```javascript
await expect(async () => {
  const response = await page.request.get("/api/status");
  expect(response.status()).toBe(200);
  const data = await response.json();
  expect(data.ready).toBe(true);
}).toPass({ intervals: [1000, 2000, 5000], timeout: 30000 });
```

### expect.poll()

```javascript
await expect
  .poll(async () => {
    const response = await page.request.get("/api/job/123");
    return (await response.json()).status;
  }, { intervals: [1000, 2000, 5000], timeout: 30000 })
  .toBe("completed");
```

## Timeouts

```javascript
// playwright.config.js
module.exports = defineConfig({
  timeout: 30000,        // Test timeout
  expect: { timeout: 5000 }, // Assertion timeout
});

// Per-test / per-assertion
test.setTimeout(60000);
await expect(page.getByRole("button")).toBeVisible({ timeout: 10000 });
```

## Assertion & Waiting Best Practices

| Do                             | Don't                          |
| ------------------------------ | ------------------------------ |
| Use web-first assertions       | Use generic assertions for DOM |
| Let auto-waiting work          | Add unnecessary explicit waits |
| Use `toPass()` for polling     | Write manual retry loops       |
| Configure appropriate timeouts | Use `waitForTimeout()`         |

## Assertion Anti-Patterns to Avoid

| Anti-Pattern                          | Problem                       | Solution                              |
| ------------------------------------- | ----------------------------- | ------------------------------------- |
| `await page.waitForTimeout(5000)`     | Slow, flaky, arbitrary timing | Use auto-waiting or `waitForResponse` |
| Generic assertions on DOM elements    | No auto-retry, flaky          | Use web-first assertions              |
