# Advanced: Multi-Context & Network Interception

> **When to use**: Testing multiple tabs/windows/popups, OAuth flows, and advanced network interception (GraphQL, HAR, conditional mocking, throttling).

This file covers two advanced areas:
1. [Multi-Tab, Window & Popup Testing](#multi-tab-window--popup-testing)
2. [Advanced Network Interception](#advanced-network-interception)

---

# Multi-Tab, Window & Popup Testing

## Popup Handling

### Basic Popup

```javascript
test("handle popup window", async ({ page }) => {
  await page.goto("/");

  // Start waiting for popup BEFORE triggering it
  const popupPromise = page.waitForEvent("popup");
  await page.getByRole("button", { name: "Open Support Chat" }).click();
  const popup = await popupPromise;

  await popup.waitForLoadState();

  await popup.getByLabel("Message").fill("Need help");
  await popup.getByRole("button", { name: "Send" }).click();
  await expect(popup.getByText("Message sent")).toBeVisible();

  await popup.close();
});
```

### Popup with Authentication

```javascript
test("popup login flow", async ({ page }) => {
  await page.goto("/dashboard");

  const popupPromise = page.waitForEvent("popup");
  await page.getByRole("button", { name: "Connect Account" }).click();
  const popup = await popupPromise;

  await popup.waitForLoadState();

  await popup.getByLabel("Email").fill("user@example.com");
  await popup.getByLabel("Password").fill("password123");
  await popup.getByRole("button", { name: "Log In" }).click();

  // Popup should close automatically after auth
  await popup.waitForEvent("close");

  await expect(page.getByText("Account connected")).toBeVisible();
});
```

### Handle Blocked Popups

```javascript
test("handle popup blocker", async ({ page }) => {
  await page.goto("/share");

  const popupPromise = page.waitForEvent("popup").catch(() => null);
  await page.getByRole("button", { name: "Share to Twitter" }).click();
  const popup = await popupPromise;

  if (!popup) {
    // Popup blocked — app should show fallback
    await expect(page.getByText("Copy share link instead")).toBeVisible();
  }
});
```

## New Tab Navigation

### Link Opens in New Tab

```javascript
test("external link opens in new tab", async ({ page, context }) => {
  await page.goto("/resources");

  const pagePromise = context.waitForEvent("page");
  await page.getByRole("link", { name: "Documentation" }).click();
  const newPage = await pagePromise;

  await newPage.waitForLoadState();
  expect(newPage.url()).toContain("docs.example.com");

  // Original page still there
  expect(page.url()).toContain("/resources");
  await newPage.close();
});
```

### Intercept New Tab

```javascript
test("prevent new tab for testing", async ({ page }) => {
  await page.goto("/links");

  // Remove target="_blank" to keep navigation in same tab
  await page.evaluate(() => {
    document.querySelectorAll('a[target="_blank"]').forEach((a) => {
      a.removeAttribute("target");
    });
  });

  await page.getByRole("link", { name: "External Site" }).click();
  await expect(page).toHaveURL(/external-site\.com/);
});
```

## OAuth Flows

### Mock OAuth (Recommended)

```javascript
test("mock OAuth flow", async ({ page, context }) => {
  await page.route("**/auth/callback**", async (route) => {
    await route.fulfill({
      status: 302,
      headers: { Location: "/dashboard" },
    });
  });

  await page.route("**/api/auth/token", (route) =>
    route.fulfill({
      json: {
        access_token: "mock-token",
        user: { name: "Test User", email: "test@example.com" },
      },
    }),
  );

  await page.goto("/login");
  await page.getByRole("button", { name: "Sign in with Google" }).click();

  await expect(page).toHaveURL("/dashboard");
  await expect(page.getByText("Welcome, Test User")).toBeVisible();
});
```

## Multiple Windows

### Test Across Multiple Windows

```javascript
test("sync between windows", async ({ context }) => {
  const page1 = await context.newPage();
  const page2 = await context.newPage();

  await page1.goto("/dashboard");
  await page2.goto("/dashboard");

  // Make change in first window
  await page1.getByRole("button", { name: "Add Item" }).click();
  await page1.getByLabel("Name").fill("New Item");
  await page1.getByRole("button", { name: "Save" }).click();

  // Should sync to second window (if app supports real-time sync)
  await expect(page2.getByText("New Item")).toBeVisible({ timeout: 10000 });
});
```

## Tab Coordination

### Switch Between Tabs

```javascript
test("manage multiple tabs", async ({ context }) => {
  const page1 = await context.newPage();
  await page1.goto("/editor");

  const page2 = await context.newPage();
  await page2.goto("/preview");

  // Edit in first tab
  await page1.bringToFront();
  await page1.getByLabel("Content").fill("Hello World");

  // Check preview in second tab
  await page2.bringToFront();
  await page2.reload();
  await expect(page2.getByText("Hello World")).toBeVisible();
});
```

### Close All Tabs Except One

```javascript
test("cleanup tabs after test", async ({ context }) => {
  const mainPage = await context.newPage();
  await mainPage.goto("/");

  for (let i = 0; i < 3; i++) {
    const popup = await context.newPage();
    await popup.goto(`/popup/${i}`);
  }

  for (const page of context.pages()) {
    if (page !== mainPage) {
      await page.close();
    }
  }

  expect(context.pages()).toHaveLength(1);
});
```

## Anti-Patterns to Avoid

| Anti-Pattern            | Problem                        | Solution                                   |
| ----------------------- | ------------------------------ | ------------------------------------------ |
| Not waiting for popup   | Race condition                 | Use `waitForEvent("popup")` before trigger |
| Testing real OAuth      | Slow, flaky, needs credentials | Mock OAuth endpoints                       |
| Assuming popup opens    | May be blocked                 | Handle both open and blocked cases         |
| Not closing extra pages | Resource leak                  | Close pages in cleanup                     |

---

# Advanced Network Interception

## Request Modification

### Modify Request Headers

```javascript
test("add auth header to requests", async ({ page }) => {
  await page.route("**/api/**", (route) => {
    const headers = {
      ...route.request().headers(),
      Authorization: "Bearer test-token",
    };
    route.continue({ headers });
  });

  await page.goto("/dashboard");
});
```

### Transform Response

```javascript
test("modify API response", async ({ page }) => {
  await page.route("**/api/products", async (route) => {
    const response = await route.fetch();
    const json = await response.json();

    const modified = json.map((product) => ({
      ...product,
      price: product.price * 0.9, // 10% discount
    }));

    await route.fulfill({ response, json: modified });
  });

  await page.goto("/products");
});
```

## GraphQL Mocking

### Mock by Operation Name

```javascript
test("mock GraphQL query", async ({ page }) => {
  await page.route("**/graphql", async (route) => {
    const postData = route.request().postDataJSON();

    if (postData.operationName === "GetUser") {
      return route.fulfill({
        json: {
          data: {
            user: { id: "1", name: "Test User", email: "test@example.com" },
          },
        },
      });
    }

    if (postData.operationName === "GetProducts") {
      return route.fulfill({
        json: {
          data: {
            products: [
              { id: "1", name: "Product A", price: 29.99 },
              { id: "2", name: "Product B", price: 49.99 },
            ],
          },
        },
      });
    }

    // Pass through unmocked operations
    return route.continue();
  });

  await page.goto("/dashboard");
});
```

## HAR Recording & Playback

### Record HAR File

```javascript
test("record HAR", async ({ page, context }) => {
  await context.routeFromHAR("./recordings/checkout.har", {
    update: true, // Create/update HAR file
    url: "**/api/**",
  });

  await page.goto("/checkout");
  await page.getByRole("button", { name: "Place Order" }).click();
});
```

### Playback HAR File

```javascript
test("playback HAR", async ({ page, context }) => {
  await context.routeFromHAR("./recordings/checkout.har", {
    url: "**/api/**",
    update: false, // Don't update, just playback
  });

  await page.goto("/checkout");
  await expect(page.getByText("Order confirmed")).toBeVisible();
});
```

## Conditional Mocking

### Mock Based on Request Body

```javascript
test("conditional mock by body", async ({ page }) => {
  await page.route("**/api/search", async (route) => {
    const body = route.request().postDataJSON();

    if (body.query === "error") {
      return route.fulfill({
        status: 500,
        json: { error: "Search failed" },
      });
    }

    if (body.query === "empty") {
      return route.fulfill({ json: { results: [] } });
    }

    return route.fulfill({
      json: { results: [{ id: 1, title: `Result for: ${body.query}` }] },
    });
  });
});
```

### Mock Nth Request (Retry Simulation)

```javascript
test("different response on retry", async ({ page }) => {
  let callCount = 0;

  await page.route("**/api/status", (route) => {
    callCount++;

    if (callCount < 3) {
      return route.fulfill({ status: 503, json: { error: "Service unavailable" } });
    }

    return route.fulfill({ json: { status: "ok" } });
  });

  await page.goto("/dashboard");
  await expect(page.getByText("Connected")).toBeVisible();
});
```

### Mock with Delay

```javascript
test("slow network simulation", async ({ page }) => {
  await page.route("**/api/data", async (route) => {
    await new Promise((resolve) => setTimeout(resolve, 2000)); // 2s delay
    return route.fulfill({ json: { data: "loaded" } });
  });

  await page.goto("/dashboard");

  await expect(page.getByText("Loading...")).toBeVisible();
  await expect(page.getByText("loaded")).toBeVisible();
});
```

## Network Throttling

### Slow 3G Simulation

```javascript
test("slow network experience", async ({ page, context }) => {
  const client = await context.newCDPSession(page);

  await client.send("Network.emulateNetworkConditions", {
    offline: false,
    downloadThroughput: (500 * 1024) / 8, // 500 Kbps
    uploadThroughput: (500 * 1024) / 8,
    latency: 400, // 400ms
  });

  await page.goto("/");
  await expect(page.getByTestId("skeleton-loader")).toBeVisible();
});
```

### Offline Mode

```javascript
test("offline mode", async ({ page, context }) => {
  await context.setOffline(true);
  await page.goto("/dashboard");

  await expect(page.getByText("No internet connection")).toBeVisible();

  await context.setOffline(false);
});
```

## Anti-Patterns to Avoid

| Anti-Pattern             | Problem                        | Solution                         |
| ------------------------ | ------------------------------ | -------------------------------- |
| Mocking all requests     | Tests don't reflect reality    | Mock only what's necessary       |
| No cleanup of routes     | Routes persist across tests    | Use fixtures with cleanup        |
| Ignoring request method  | Mock applies to wrong requests | Check `route.request().method()` |
| Hardcoded mock responses | Brittle, hard to maintain      | Use factories for mock data      |

## Related References

- **Mocking strategy** (when to mock vs hit real): See [architecture.md](architecture.md)
- **Assertions & Waiting**: See [locators-and-assertions.md](locators-and-assertions.md)
