# Config Memory

Persists the base URL and per-functional-area selector maps discovered during live DOM exploration, across stories and tickets, so a functional area explored once for one story doesn't need full re-exploration for a later, unrelated story against the same app. This is separate from (and complements) the existing execution-log.json selector hand-off, which only covers TCs within the *same* run — config memory is what makes the *next* story on a *different* ticket start from cached selectors instead of a blank slate.

**Cache file:** `test-output/qa-config-memory.json` — local to this repo checkout, keyed by hostname, shared across all stories/tickets tested against that host. Created on first use; updated after every exploration.

```json
{
  "mqa-test.maxxton.net": {
    "base_url": "https://mqa-test.maxxton.net",
    "last_used": "2026-09-17",
    "modules": {
      "customer-care-cases": {
        "selector_map": {
          "sidebar_nav": "page.getByText('assignmentCases')",
          "sub_page": "page.getByRole('link', { name: 'All cases' })",
          "url_pattern": "/cases/allcases",
          "create_btn": "page.getByText('New case')",
          "dialog_name": "Create case",
          "fields": { "Topic": "getByRole('textbox', { name: 'Topic' })" },
          "submit": "locator('a[flat-button]').filter({ hasText: 'Create case' })",
          "snackbar": "Created successfully"
        },
        "confirmed_runs": 3,
        "last_verified": "2026-09-17"
      }
    }
  },
  "_meta": { "run_count": 5, "last_updated": "2026-09-17", "max_modules_per_host": 100 }
}
```

## Load (Step 1, before asking for base URL)

1. Read `test-output/qa-config-memory.json`. Missing → empty cache, no error.
2. Invalid JSON → empty cache, log `[ConfigMemory] qa-config-memory.json corrupted — starting fresh.` Never crash or block generation over this.
3. Keep the valid cache in memory as `config_cache`.

## Base URL default (Step 1)

If no base URL was provided as an argument and `config_cache` has at least one host entry, pick the one with the most recent `last_used` and offer it as a default instead of a bare ask:

> Please provide the base URL (e.g. `https://test.maxxton.com`) — press Enter to reuse the last one used, `<cached base_url>` (`<hostname>`, last used `<last_used>`) — without it, selectors will have to be guessed.

Empty reply → use the cached `base_url`. Any other reply → use what the user typed (a new host, or the same one). If `config_cache` has no entries, ask exactly as before with no default mentioned.

After the base URL resolves (whichever way), update `config_cache[<hostname>].base_url` and `.last_used` to today — this keeps the "most recent" pick meaningful on the next run even if the user re-types the same URL.

## Selector map — cache-first (Step 5, per functional area, before Step 5b)

For each functional area about to be explored:

1. Derive `area-slug` from the functional area name used to group TCs in Step 3 (lowercase, hyphenated — e.g. "Customer Care — Cases" → `customer-care-cases`).
2. Check `config_cache[<hostname>].modules[<area-slug>]`:
   - **Not cached** → run Steps 5b/5c in full (live exploration, as today). Once the selector map for this area is finalized, write it to `config_cache[<hostname>].modules[<area-slug>]` with `confirmed_runs: 1` and `last_verified` = today. Log: `[ConfigMemory] <area-slug> — no cached selectors, explored live and cached.`
   - **Cached** (any age) → run the **lightweight verify** below instead of full exploration. The selector map holds two different shapes of locator (see Step 5b/5c and the map format below), and each needs a different check — neither `browser_evaluate` nor `browser_find` alone covers both:
     1. **`getByText('X')` / `getByRole('role', { name: 'X' })` / `getByLabel('X')` / `.filter({ hasText: 'X' })` locators (has embedded human-readable text):** extract the plain text `'X'` from the locator's own argument and call `browser_find` with it (case-insensitive substring match — the tool's own matching behavior, not something to configure). `browser_evaluate` cannot be used here — it runs the given function *inside the page* (like `page.evaluate()`), and Playwright's own locator API is a Node-side construct that doesn't exist in that context, so a locator can never verify itself there.
     2. **Raw CSS locators (`input[name="..."]`, `.filter(...)` on a CSS container, dropdown containers from 5c — no embedded human-readable text to search for):** these ARE valid inside `browser_evaluate`, because they're plain CSS, not Playwright API calls — run `browser_evaluate` → `document.querySelectorAll('<the cached CSS string>').length === 1` (the same uniqueness check Step 5b already runs during live discovery).
     3. Skip `url_pattern` entirely (it's a URL, not a locator). `dialog_name` and `snackbar` are checked via `browser_find` (plain text, same as case 1).
     4. **All checked entries pass** (found via `browser_find`, or resolve to exactly 1 via `browser_evaluate`) → reuse the cached map as-is, skip Steps 5b/5c entirely for this area. Bump `confirmed_runs` by 1, set `last_verified` to today. Log: `[ConfigMemory] <area-slug> — cache hit (confirmed_runs=<n>), skipped live exploration.`
     5. **Any entry fails its check** (text not found, or CSS selector resolves to 0 or 2+ elements) → the app changed under this area. Fall back to full Steps 5b/5c exploration for this area only (never for other areas), then overwrite `config_cache[<hostname>].modules[<area-slug>]` with the freshly discovered map, reset `confirmed_runs: 1`, `last_verified` = today. Log: `[ConfigMemory] <area-slug> — cache stale (<selector/text> no longer verifies), re-explored live.`

The lightweight verify is a handful of cheap `browser_find` text searches and/or `browser_evaluate` uniqueness checks, not a full sidebar-to-dialog walkthrough — that's the actual time saved. It is deliberately less strict than Step 5b's own live-discovery check for the text-based case (existence, not exact-1-match uniqueness — the CSS case above still checks exact-1) — full rigor happens for real the first time a functional area is explored, and again whenever Step 7 runs the generated spec 3 times; the cache-verify step's job is only to catch "did this area visibly change," not to re-prove everything on every single story.

## Eviction

Before writing, if a hostname's `modules` object exceeds 100 entries, evict the entries with the oldest `last_verified` down to 100.

## `--clear-config-memory` flag

If passed, delete `test-output/qa-config-memory.json` before loading (use after a significant UI redesign where cached selectors would all be wrong anyway). Log: `[ConfigMemory] qa-config-memory.json cleared by --clear-config-memory flag.`

## Write

**Under an exclusive lock — never a blind overwrite, and never a re-read without one.** This file is shared across every concurrent story/ticket run against the same repo (that's the whole point of it). A re-read-then-write without a lock still loses updates: two sessions can both read the same fresh copy before either writes, merge their own dirty entries onto it, and the second write erases the first session's discoveries. Only a real mutual-exclusion lock around the whole read-merge-write closes that gap.

Immediately after Step 5 completes for all functional areas (same timing as when the selector map would otherwise just be discarded after Step 6 consumes it):

**Acquire the lock** — `test-output/qa-config-memory.lock/` is a *directory*, not a file: creating a directory is atomic on both Windows and POSIX, so two sessions racing to create it can never both succeed.
1. Try to create it (Bash: `mkdir "test-output/qa-config-memory.lock" 2>/dev/null && echo acquired`; PowerShell: `New-Item -ItemType Directory -Path "test-output/qa-config-memory.lock" -ErrorAction SilentlyContinue`). Succeeded (it did not already exist) → lock held, go to step 4.
2. Already exists → check its age. Older than 15 seconds → an abandoned lock from a crashed session; remove it and retry step 1 once. 15 seconds or younger → another session is actively writing; wait ~500ms and retry step 1.
3. **Give up after ~10 seconds of retrying** (~20 attempts) rather than block this run indefinitely on a stuck lock — but do NOT fall through to steps 4–9 without the lock; that would be the exact unprotected read-merge-write the lock exists to prevent. **Skip the cache write entirely for this run instead** — this run's own newly-discovered selectors/base-URL are lost for next time (a speed regression only, the generated spec still used verified real selectors this run), never a correctness problem, and never worth risking another session's already-recorded modules to save. Log: `[ConfigMemory] Could not acquire qa-config-memory.lock after 10s — skipping this run's cache write (selectors discovered this run will not be persisted).` Do not retry further and do not proceed to step 4.

**Only once the lock is actually held:**
4. Track only what *this run itself* discovered or re-verified this session — new/updated entries under `config_cache[<hostname>].modules[<area-slug>]`, and the `base_url`/`last_used` update from Step 1 — as a small "dirty" set, not the whole cache.
5. Read `test-output/qa-config-memory.json` from disk again, fresh, right now (missing/corrupt → treat as empty, same as the Load step).
6. Merge this run's dirty set onto that fresh read — only the specific `[hostname]`/`[hostname].modules[area-slug]` keys this run touched get overwritten; every other host/module already on disk (written by any other session) is kept as-is.
7. Apply eviction on the merged result if needed.
8. Increment `_meta.run_count` on the merged result.
9. Write the merged result back.

**Release the lock immediately after** (Bash: `rmdir "test-output/qa-config-memory.lock"`; PowerShell: `Remove-Item "test-output/qa-config-memory.lock" -Force`) — attempt this even if a step above errored, so a genuine failure never leaves a stale lock for the next run to wait out.

Log: `[ConfigMemory] Cache updated — <n> module(s) for <hostname>.`
