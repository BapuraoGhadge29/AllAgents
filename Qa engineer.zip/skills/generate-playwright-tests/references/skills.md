---
name: playwright-best-practices
description: Routing index for the bundled Playwright reference library used by generate-playwright-tests. Maps the activity you're doing to the reference file(s) that cover it. Use when writing or debugging Maxxton Playwright specs.
license: MIT
metadata:
  author: currents.dev
  version: "3.0"
---

# Playwright Best Practices — Routing Index

Routing index for the bundled reference library. All files live flat in `references/` — every link
below resolves. Read the files relevant to what you're doing.

## Generic baseline for Maxxton specs

For Maxxton specs the target repo's own files (SKILL.md Step 4) are the authority and win over everything in
this library. These files are generic Playwright and Angular guidance: read one only for a topic the repo's
files do not cover. The core set:

| File | Covers |
|---|---|
| [locators-and-assertions.md](locators-and-assertions.md) | Locator priority & anti-patterns; web-first assertions, waiting strategies, polling, timeouts |
| [test-structure.md](test-structure.md) | Config, describe/beforeEach, isolation, directory layout; `test.step()` (mandatory), skip/fixme/fail/slow, tags |
| [maxxton-angular.md](maxxton-angular.md) | Angular Material, reactive forms, CDK overlays **+** MXTS-specific patterns (pagination, search-dropdown, `fill()` anti-pattern, sidebar, `<tr>` click, component reuse) and the failure-diagnosis table |

## On-demand (read only when the scenario needs it)

| Activity | Reference file |
|---|---|
| Forms, wizards, validation, auto-complete, drag-and-drop | [interactions.md](interactions.md) |
| Multi-tab / popup / OAuth popups; network interception, GraphQL, HAR, throttling, offline | [advanced.md](advanced.md) |
| POM vs fixtures vs helpers, component objects, mock-vs-real decision, test-data factories | [architecture.md](architecture.md) |
| Flaky tests, race conditions, state leaks | [flaky-tests.md](flaky-tests.md) |

## Quick decision tree

```
What are you doing?
│
├─ Writing a Maxxton E2E test (always)
│  └─ locators-and-assertions.md + test-structure.md + maxxton-angular.md
│
├─ Testing a specific interaction?
│  └─ Form / wizard / validation / autocomplete / drag-drop → interactions.md
│
├─ Advanced scenario?
│  └─ Multi-tab / popup / OAuth / network mocking / GraphQL / HAR → advanced.md
│
├─ Architecture or data?
│  └─ POM vs fixtures, mock-vs-real, test-data factories → architecture.md
│
└─ Test failing / flaky? → flaky-tests.md (+ locators-and-assertions.md for waiting)
```

## Test Validation Loop

After writing or modifying tests, run the burn-in the target repo requires (SKILL.md Step 7: five clean passes through the repo's `playwright-burnin` skill):

1. Run: `npx playwright test <spec> --project=chromium --reporter=list`
2. If tests fail — reproduce live, find the real root cause, fix locators/waits/assertions, re-run.
3. Only proceed when the five-pass burn-in is clean.
