# Debugging and Managing Flaky Tests

## Flakiness Decision Tree

```
Test fails intermittently
├─ Fails locally too?
│  ├─ YES → Timing/async issue → Check waits and assertions
│  └─ NO → CI-specific → Check environment differences
│
├─ Fails only with multiple workers?
│  └─ YES → Parallelism issue → Check data isolation
│
├─ Fails only when run after specific tests?
│  └─ YES → State leak → Check fixtures and cleanup
│
└─ Fails randomly regardless of conditions?
   └─ External dependency → Check network/API stability
```

## Detection

```bash
# Run test multiple times to confirm instability
npx playwright test tests/checkout.spec.js --repeat-each=20

# Run with single worker to isolate parallelism issues
npx playwright test --workers=1

# Run in CI-like conditions locally
CI=true npx playwright test --repeat-each=10
```

## Fixing by Type

### UI-Driven Flakiness

```javascript
// ❌ BAD: No wait for element state
await page.click("#submit");
await page.fill("#username", "test");

// ✅ GOOD: Actions + assertions pattern (auto-waiting built-in)
await page.getByRole("button", { name: "Submit" }).click();
await expect(page.getByRole("heading", { name: "Dashboard" })).toBeVisible();
```

```javascript
// ❌ BAD: Fragile CSS chain
await page.click("div.container > div:nth-child(2) > button.btn-primary");

// ✅ GOOD: Semantic selectors
await page.getByRole("button", { name: "Continue" }).click();
```

### Async/Timing Flakiness

```javascript
// ❌ BAD: Arbitrary sleep
await page.click("#load-data");
await page.waitForTimeout(3000);

// ✅ GOOD: Wait for specific condition
await page.click("#load-data");
await expect(page.locator(".data-row")).toHaveCount(10, { timeout: 10000 });

// ✅ BETTER: Wait for network response, then assert
const responsePromise = page.waitForResponse(
  (r) => r.url().includes("/api/data") && r.request().method() === "GET" && r.ok()
);
await page.click("#load-data");
await responsePromise;
await expect(page.locator(".data-row")).toHaveCount(10);
```

### Data/Parallelism-Driven Flakiness

```javascript
// ❌ BAD: All workers use same user
const testUser = { email: "test@example.com" };

// ✅ GOOD: Unique data per worker
exports.test = base.extend({
  testUser: [
    async ({}, use, workerInfo) => {
      const email = `test-${workerInfo.workerIndex}-${Date.now()}@example.com`;
      const user = await createTestUser(email);
      await use(user);
      await deleteTestUser(user.id);
    },
    { scope: "worker" },
  ],
});
```

### State Leaks Between Tests

```javascript
// ❌ BAD: Shared mutable state
let sharedPage;
test.beforeAll(async ({ browser }) => {
  sharedPage = await browser.newPage(); // Shared across tests!
});

// ✅ GOOD: Use Playwright's default isolation (fresh context per test)
test("first test", async ({ page }) => { /* Fresh page */ });
test("second test", async ({ page }) => { /* Fresh page */ });
```

## CI-Specific Flakiness

| CI Condition       | Impact                                | Solution                                 |
| ------------------ | ------------------------------------- | ---------------------------------------- |
| Slower CPU         | Actions complete later                | Use auto-waiting, not timeouts           |
| Cold browser start | Slower initial load                   | Add explicit waits for first navigation  |
| Headless mode      | Different rendering behavior          | Test locally in headless mode            |
| Network latency    | API calls slower                      | Mock external APIs, increase timeouts    |

### Network Stubbing for External APIs

```javascript
test.beforeEach(async ({ page }) => {
  // Stub unstable third-party APIs
  await page.route("**/api.analytics.com/**", (route) =>
    route.fulfill({ body: "" })
  );
});
```

## Quarantine and Management

```javascript
// Mark flaky tests with annotations
test("intermittent checkout issue", async ({ page }, testInfo) => {
  testInfo.annotations.push({
    type: "flaky",
    description: "Investigating payment API timing - JIRA-1234",
  });
});

// Skip flaky test in CI
test("known CI flaky", async ({ page }) => {
  test.skip(!!process.env.CI, "Flaky in CI - investigating JIRA-5678");
});
```

## Prevention Strategies

```bash
# Run new tests many times before merging (burn-in)
npx playwright test tests/new-feature.spec.js --repeat-each=50

# Run in parallel to expose race conditions
npx playwright test tests/new-feature.spec.js --repeat-each=20 --workers=4
```

## Anti-Patterns to Avoid

| Anti-Pattern                              | Problem                             | Solution                         |
| ----------------------------------------- | ----------------------------------- | -------------------------------- |
| `waitForTimeout()` as primary wait        | Arbitrary, hides real timing issues | Use auto-waiting assertions      |
| Increasing global timeout to "fix" flakes | Masks root cause                    | Find and fix actual timing issue |
| Shared test data across workers           | Race conditions, collisions         | Isolate data per worker          |
| Testing real external APIs                | Network variability                 | Mock external dependencies       |
| Module-level mutable state                | Leaks between tests                 | Use fixtures with proper cleanup |
| Ignoring flaky tests                      | Problem compounds over time         | Quarantine and track for fixing  |

## Related References

- **Assertions**: See [locators-and-assertions.md](locators-and-assertions.md)
- **MXTS failure diagnosis**: See [maxxton-angular.md](maxxton-angular.md)
