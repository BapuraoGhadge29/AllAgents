---
name: generate-playwright-tests
description: Generates Playwright JavaScript test scripts from a test case table. Navigates the live app with the Playwright MCP browser to discover real selectors, then writes production-ready spec files. Use when converting a test case table into automated Playwright spec files.
disable-model-invocation: true
argument-hint: "[Jira story ID or paste test table] [base URL] [--clear-config-memory]"
allowed-tools:
- mcp__claude_ai_Atlassian_MCP__getAccessibleAtlassianResources
- mcp__claude_ai_Atlassian_MCP__getJiraIssue
- mcp__claude_ai_Atlassian_MCP__discover
- mcp__claude_ai_Atlassian_MCP__executeRead
- mcp__claude_ai_Atlassian_MCP__addOrEditJiraIssueComment
- mcp__claude_ai_GitHub__get_file_contents
- mcp__claude_ai_GitHub__search_code
- mcp__plugin_qa-engineer_playwright__browser_navigate
- mcp__plugin_qa-engineer_playwright__browser_snapshot
- mcp__plugin_qa-engineer_playwright__browser_click
- mcp__plugin_qa-engineer_playwright__browser_wait_for
- mcp__plugin_qa-engineer_playwright__browser_close
- mcp__plugin_qa-engineer_playwright__browser_press_key
- mcp__plugin_qa-engineer_playwright__browser_evaluate
- mcp__plugin_qa-engineer_playwright__browser_find
- mcp__playwright__browser_navigate
- mcp__playwright__browser_snapshot
- mcp__playwright__browser_click
- mcp__playwright__browser_wait_for
- mcp__playwright__browser_close
- mcp__playwright__browser_press_key
- mcp__playwright__browser_evaluate
- mcp__playwright__browser_find
- mcp__playwright-headed__browser_navigate
- mcp__playwright-headed__browser_snapshot
- mcp__playwright-headed__browser_click
- mcp__playwright-headed__browser_wait_for
- mcp__playwright-headed__browser_close
- mcp__playwright-headed__browser_press_key
- mcp__playwright-headed__browser_evaluate
- mcp__playwright-headed__browser_find
- mcp__claude_ai_GitHub__create_branch
- mcp__claude_ai_GitHub__push_files
- mcp__claude_ai_GitHub__create_pull_request
---

# Generate Playwright Tests

Generates production-ready Playwright spec files by combining the test case table with live DOM inspection of the actual app, written to the rules of the target test-automation repo (`mxts-qa-automation` or `mcms-qa-automation`), which are read fresh from that repo on every run (Step 4). Navigates each feature area to discover real element roles, labels, and accessible names — no TODO placeholders.

---

## Step 1: Confirm Intent

Before doing anything, ask the user:

> Do you want me to generate Playwright test scripts for this story?
> - **yes** — generate scripts (browser exploration + real selectors)
> - **no** — skip

If the user says **no**, stop immediately. Do not proceed.

**Load config memory now** (before asking for the base URL below): if `--clear-config-memory` was passed, follow the reference's own "`--clear-config-memory` flag" step first (delete the cache file before loading); then follow the "Load" and "Base URL default" steps in [the Config Memory reference](references/config-memory.md) — if a base URL was used before against this repo, the ask below offers it as a default instead of a bare prompt.

If the user says **yes**, ask for any missing inputs:
- If no Jira story ID or test table was provided → ask for it
- If no base URL was provided → ask (per Config Memory's "Base URL default" — offers a cached default when one exists): `Please provide the base URL (e.g. https://test.maxxton.com) — a spec cannot be written without it, because the repo requires every locator to be verified in the live app.` If the user cannot provide one, stop and say so; never write a spec with unverified selectors.
- If no local project path was provided → ask: `Please provide the absolute path to your local test-automation project — mxts-qa-automation for MXTS URLs, or mcms-qa-automation for MCMS/CMS URLs (hostname contains "cms", e.g. krm-cms-test.maxxton.net) — needed to read the repo's writing rules, write the spec and run the burn-in.`

Then proceed.

---

## Step 2: Resolve Input

Accept arguments:
- `<Jira story ID or test table>` — required
- `<base URL>` — optional but strongly recommended (e.g. `https://test.maxxton.com`)

**Target repo detection** — derive `target_repo` from the base URL's hostname: contains `cms` (e.g. `krm-cms-test.maxxton.net`, `fmc-cms-dev.maxxton.net`, `ons-cms-test.maxxton.net`) → `mcms-qa-automation`; otherwise → `mxts-qa-automation` (also the default when no base URL was provided). Use `<target_repo>` for every GitHub call and local-project reference below — never the hardcoded `mxts-qa-automation` name.

If a Jira story ID is provided:
- Call `mcp__claude_ai_Atlassian_MCP__getAccessibleAtlassianResources` to get `cloudId`
- Call `mcp__claude_ai_Atlassian_MCP__getJiraIssue` to retrieve the story
- Read the story's comments with `mcp__claude_ai_Atlassian_MCP__executeRead` with `name: listJiraIssueComments`, then find the most recent comment containing the test case table (posted by `generating-test-cases`)
- If no table found, ask the user to paste it

If a test case table is pasted directly, use it as-is.

---

## Step 3: Parse Test Cases

From the test case table, extract for each row:
- TC_ID
- Scenario (category + description)
- Preconditions
- Test steps
- Expected Result
- Story number

Group test cases by functional area — each group becomes one `test.describe` block.

**If an execution log from `execute-tests` is also provided**, extract per TC:
- Navigation paths used
- Selectors that were validated
- Verdict (PASS / FAIL / BLOCKED / NEEDS REVIEW)

When an execution log is available, use its selectors directly for PASS/FAIL TCs and skip browser exploration for those TCs.

---

## Step 3a: Duplicate Automation Check

Prevents generating a second spec for a TC someone already automated in `target_repo` (resolved in Step 2). Skip this step entirely if no base URL was provided (`target_repo` unresolved — nothing to search against).

1. For each TC parsed in Step 3, call `search_code` scoped to `repo:MaxxtonGroup/<target_repo> extension:js path:tests/modules <keywords>`, using 2–3 distinguishing keywords from the TC's scenario/entity name (the entity + action, e.g. `archive case`, not generic words like "verify" or "test"). **Use `extension:js`, never `extension:spec.js`** — GitHub's `extension:` qualifier matches only the final file extension, so `TC_01.spec.js` has extension `js`, not `spec.js`; the wrong qualifier silently matches nothing and this check would always report zero existing automation.
2. A search hit is a **candidate**, not a confirmed duplicate — fetch it with `get_file_contents` only if the snippet is ambiguous, and compare its test name / `test.step()` descriptions against this TC's scenario text for a genuine semantic match (same entity, same action, same condition), not just keyword co-occurrence.
3. A genuine match → mark the TC as already automated (note the matched file path) and exclude it from Step 5 (Live DOM Exploration) and Step 6 (spec generation) — do not write a `test()` for it. List it separately in Step 8's output instead: `<TC_ID> — already automated: <matched file path> (skipped, no duplicate generated)`.
4. `search_code` unreachable/erroring → log a warning and treat every TC as not-yet-found (fail open on availability — do not block generation over a search outage).

> A manually-maintained "Automated?" tracking sheet is a second candidate signal for this same check — not wired in yet, pending a decision on where it lives (Google Sheet / Excel / Confluence). Until then, this repo search is the only duplicate-detection source.

**All TCs already automated → stop here, do not proceed to Steps 4–8.** If every TC parsed in Step 3 was matched as already automated, there is nothing left to write a spec for — continuing would produce a file with no `test()` blocks (or none at all) and still prompt to open a PR for it. Instead, report directly:

```
All <n> TC(s) in this table already have a Playwright spec in <target_repo> — no new spec file needed.
<TC_ID> — already automated: <matched file path>
...
```

Skip Steps 4 through 8 entirely — no style guide load, no DOM exploration, no file written, no PR prompt.

---

## Step 4: Read the Target Repo's Writing Rules — Every Run

**MANDATORY GATE — on every invocation, no exceptions.** Do not write test code, and do not start Step 5, until this step has been done *in this run*. Read the repo again every time, even if it was read earlier in this conversation or in a past session. Never write from memory or from this skill's own text: the repo changes daily and its rules are the authority. Where `<target_repo>`'s files disagree with this skill, the bundled `references/`, or an older example inside a reference file, the repo's `CLAUDE.md` hard rules win.

**4a — Fetch the latest merged version.** The local clone can be behind `origin/develop` and can carry uncommitted edits, so read the merged version, not the working tree:

```bash
git -C <local-project-path> fetch origin develop
git -C <local-project-path> rev-parse --short origin/develop
git -C <local-project-path> show origin/develop:<file>
```

Find section boundaries in the large reference files with `git show … | grep -n '^## '` and read a range with `sed -n '<from>,<to>p'`. If the local path is unavailable, use `get_file_contents` on `MaxxtonGroup/<target_repo>` — it returns whole files, so prefer ranges through git for the big ones.

**4b — Read, in this order (`mxts-qa-automation`):**

| # | File on `origin/develop` | What to read |
|---|---|---|
| 1 | `CLAUDE.md` | In full: hard rules, tag taxonomy, test-data rules, CRUD-combining rule, comments policy, the merge conditions for pipeline-generated specs, and the "Required reading" table that maps each module folder to its reference file |
| 2 | `TEST_WRITING_REFERENCE_MAIN.md` | Everything before the first `(§4.73)` section, in full. Then list the remaining headings and read every section that is general framework (shared grid/filter framework, shared-session stabilising, locale helpers, locator and assertion gotchas) or matches the TC's feature. For a `customer_care` spec, read that feature's Customer Care sections in full |
| 3 | `TEST_WRITING_REFERENCE_<MODULE>.md` | The file `CLAUDE.md` maps to the target module: its intro and every section for the entity or feature under test. MAIN alone is never enough outside Customer Care |
| 4 | `docs/PLAYWRIGHT_BEST_PRACTICES.md` | Only the sections that match the TC: dialogs, dropdowns, TinyMCE, flaky handling |
| 5 | Existing specs and POM | `git ls-tree -r --name-only origin/develop -- tests/modules/<module>/<sub_menu>/ pages/<module>/`; read the one or two closest specs and the POM for this entity, and extend them rather than writing parallel code |
| 6 | `fixtures/mxts-test.js` | The `MODULE_URLS` keys and subfolder overrides: the module folder must be one of them |

**4c — State what you read.** Before Step 5, write one line with the `origin/develop` short SHA and the files and sections read. A run without that line has skipped this step.

**4d — `mcms-qa-automation`.** List its root first: it has no `CLAUDE.md` or `TEST_WRITING_REFERENCE_*` files. Read its `README.md` and the closest existing specs and POM in the target folder from its latest default branch, and treat those as the house style. The MXTS rules in this skill (fixture import, `MODULE_URLS`, tag taxonomy) apply to it only where its own files confirm them.

**4e — Bundled references.** The files in this skill's own `references/` folder are generic Playwright and Angular guidance, not Maxxton's rules. Read one only for a topic the repo's files do not cover (`flaky-tests.md`, `advanced.md`, `interactions.md`, `architecture.md`), routed through `references/skills.md`. When one conflicts with the repo, follow the repo.

---

## Step 5: Live DOM Exploration

Navigate the live app in one continuous pass — session check and selector capture happen together from the very first snapshot.

**MANDATORY: Every selector written into the spec MUST be verified by executing it in the live browser — no assumptions, no guessing based on Angular patterns or prior knowledge. If you cannot verify a selector, do not emit it — see the end of this step.**

**MANDATORY: Use `browser_click` (the MCP Playwright tool) to verify ALL click interactions — NEVER use `browser_evaluate` to trigger clicks. `browser_evaluate` with `.click()` bypasses Angular event handling, `disabler` components, and other guards. A JS click working in evaluate does NOT mean the Playwright locator will work — they are different execution paths. The only valid way to verify a click is `browser_click` → observe the result.**

**MANDATORY: If a click-based action (archive, delete, publish, etc.) fails in the browser because of permissions or a locked state — STOP. Do not write code that assumes the action works. Ask the user to either (1) log in with an account that has the required permission, or (2) confirm the exact element they click manually so the selector can be verified.**

### 5a — Navigate + capture in one pass

**Browser availability (run before the first navigate):** the bundled Playwright MCP is `mcp__plugin_qa-engineer_playwright__*`. If those tools are not registered, fall back to whichever of `mcp__playwright__*` or `mcp__playwright-headed__*` is registered instead — both are enumerated in `allowed-tools` above for exactly this case, and both are the same `@playwright/mcp` server, just under the name the user's own `claude mcp add` gave it. Use that prefix for the whole run. A Playwright MCP registered under some other name is not usable here — a tool call under a prefix not in `allowed-tools` is silently rejected, not routed — so either rename the user's server to one of the two above, or add its tool names to this file's `allowed-tools`. Never substitute a non-Playwright browser tool; selectors discovered through anything else are not trustworthy, which defeats the point of this step. If no Playwright MCP under any of the three names is registered, stop before writing any spec file, run `node "$CLAUDE_PLUGIN_ROOT/mcp/run-playwright.js" --doctor`, and report its output — live DOM inspection is mandatory here, so a spec written without it would be exactly the guessed-selector output this skill exists to prevent.

Call `browser_navigate` to `<base URL>` if not already there, then call `browser_snapshot`.

**From this first snapshot, immediately capture:**
- Session state (login form visible → ask user to login and confirm, then re-snapshot)
- Sidebar navigation: exact icon+text for every visible menu item
- Top-level URL pattern and app structure

Do not take a separate "session check" snapshot — the first snapshot serves both purposes.

### 5b — Drill into each functional area

**Config memory gate (check before drilling into each area):** follow the "Selector map — cache-first" procedure in [the Config Memory reference](references/config-memory.md). Cache hit (all cached selectors verify) → skip steps 1–8 below entirely for this area, reuse the cached selector map, and move to the next functional area. Cache miss or stale → continue with the full drill-down below, then write the resulting map back to config memory per that same reference.

For each unique functional area in the test case table, continue from the current browser state:

1. **Click the sidebar menu item** (use exact text captured in 5a) — `browser_click`.
2. `browser_snapshot` — record from this snapshot:
   - Sub-menu links and their exact text
   - URL pattern after navigation
3. **Click the sub-page link** — `browser_click`.
4. `browser_snapshot` — record from this snapshot:
   - Page heading
   - Table column headers and row selector pattern
   - Action buttons (New / Create / Add etc.) — exact text and element type
5. **Click the create/edit button** to open the form or dialog.
6. `browser_snapshot` — record from this snapshot:
   - Dialog accessible name (`role="dialog"` name)
   - Every input field: label text, `name` attribute, element type
   - Submit/cancel buttons: text, `<a>` vs `<button>`, any `flat-button` attribute
   - Dropdown triggers: `.open-select` text or `getByText` label
7. For **multi-step wizards**: navigate through every step in sequence. Capture field selectors at each step before proceeding — do not skip ahead. After each step transition, take a `browser_snapshot` and record all new fields. Use `browser_wait_for` to let each transition settle before snapshotting.
8. Press `Escape` (via `browser_press_key`) or navigate away — do NOT submit the form.

**Exception — complete the action when post-action DOM state must be verified:**
If any test case asserts DOM state that only exists AFTER a side-effect action completes (e.g. an archived item shown with a strikethrough class, a record removed from the list, a status badge changing after a transition), you MUST complete that action during exploration — do NOT dismiss or cancel. Record the resulting CSS classes, element visibility, and URL in the selector map before continuing. Failure to complete the action forces a `test.fixme()` placeholder that cannot be resolved without re-exploration.

**Apply the patterns from the repo files read in Step 4** (MAIN and the module file) throughout this exploration — they record how this app's dropdowns, dialogs, confirm buttons, filters, pagination and sidebar actually behave.

**For every selector candidate**, before adding it to the map, run `browser_evaluate` to verify:
- The locator resolves to **exactly 1** element (strict mode: >1 match causes a runtime error)
- For button/link states: check disabled class, `aria-disabled`, or Angular `disabled-style`

```js
// Example uniqueness check — run this for every non-trivial selector:
document.querySelectorAll('<css-selector>').length
```

### 5c — Verify every dropdown

Do NOT assume any dropdown uses `.cdk-overlay-container`. After clicking the dropdown trigger:

1. Run `browser_evaluate` to inspect the actual DOM parent of the rendered options:
   ```js
   // Find where the dropdown options actually live:
   document.querySelector('<option-text>').closest('ul, data-list, auto-complete-search, .cdk-overlay-container, .dropdown')?.tagName
   ```
2. Identify the **real** container — common patterns:
   - Angular CDK: `.cdk-overlay-container` wraps `.cdk-overlay-pane` → use `locator('.cdk-overlay-container').getByText(...)`
   - Custom component: `auto-complete-search` → `data-list` → `ul` → `li` → use `locator('auto-complete-search li').filter({ hasText: '...' })`
   - Native `<select>`: use `getByRole('combobox')` / `selectOption()`
3. Write the selector using the **verified** container — never emit `.cdk-overlay-container` without step 1 confirming it.

Build a selector map from all snapshots for this area:

```
Feature area: <name>
Sidebar nav:  page.getByText('<iconName><MenuLabel>')
Sub-page:     page.getByRole('link', { name: '<Sub Page>' })
URL pattern:  /module/<locale>/sub-path   (never hardcode the locale in the spec — use the repo's locale helper)
List table:   page.getByRole('table')
Create btn:   page.getByText('<exact text>') OR locator('a[flat-button]').filter(...)
Dialog name:  '<accessible name>'
Fields:       { '<label>': 'input[name="<name>"]' | getByRole('textbox',{name:'<label>'}) }
Submit:       locator('<a|button>[flat-button]').filter({ hasText: '<text>' })
Dropdown:     verified container selector (see 5c)
Snackbar:     '<expected success message text>'
```

Explore each functional area once — reuse captured selectors for all TCs in the same area. When all areas are captured, call `browser_close` to release the browser before writing the spec, then write the config memory cache per [the Config Memory reference](references/config-memory.md)'s "Write" step — this is what lets the next story against this same app reuse today's selectors instead of exploring from scratch.

**If a selector cannot be verified** (a click or navigation fails, or the element is not found), do not guess and do not write a TODO comment — the repo bans both (`CLAUDE.md` "Verify first" and its comments policy). Re-investigate with `browser_snapshot`; if it is still unresolved, leave that TC out of the spec and report it in Step 8 as `<TC_ID> — not automated: <reason>`. The other TCs are still generated.

---

## Step 6: Generate Playwright Script

**Pre-flight — confirm before writing the first line of code:**

- [ ] Step 4 was completed in this run and its `origin/develop` SHA line was written
- [ ] The `CLAUDE.md` hard rules and the module file's sections for this entity are fresh in context — re-read them now if Step 5 ran long

If either box is unchecked, go back to Step 4. Do not generate code without it.

Order of authority when writing: (1) `CLAUDE.md` hard rules → (2) `TEST_WRITING_REFERENCE_MAIN.md` and the module file (an older example inside them, such as a template with `waitForTimeout` or a bare `[@tag]`, loses to a `CLAUDE.md` hard rule) → (3) the selector map from Step 5, or the `execute-tests` log → (4) bundled references.

Generate the spec from the Step 5 selector map (or the execution log's selectors).

### File path

```
tests/modules/<module>/<sub_menu>/<feature_area>/<name>.spec.js
```

`<name>` is a descriptive snake_case name for the feature (for example `case_details_page.spec.js`), never the Jira key. `<module>` must be a `MODULE_URLS` key in `fixtures/mxts-test.js`. Take the sub-menu and feature-area folders from the app navigation captured in Step 5 and from the folder layout already on `origin/develop`. If a spec for the same entity already exists there, extend it instead of adding a second file, and combine Create → Edit → Delete of one entity into one test when they share state (`CLAUDE.md`, "Combine CRUD test cases"). One test in a file → a bare `test()`; several → one `test.describe`.

### Hard rules come from the repo, not from this skill

Apply every hard rule in the `CLAUDE.md` read in Step 4. These are the ones this skill used to get wrong; the list is not complete, the repo's file is:

- import `{ test, expect }` from `#mxts-test`, never from `@playwright/test`
- no `page.waitForTimeout()`, no inline `{ timeout }`, no `page.screenshot()` inside a test
- a visibility assertion before every `.click()` and `.fill()`
- unique data from `randomString()` in `#utils/account-data`, never `Date.now()`; dummy data only
- no comments except a non-obvious rule, invariant or bug workaround; no TODO comments
- the shared `MxtsDataTable` / `MxtsDynamicFilter` framework in `pages/components/core/` for any `<datatable>` or `<advanced-dynamic-filter>`

### Serial vs parallel

This skill does not decide it. Read the serial-describe and shared-session sections of MAIN and the module file, and check `playwright.config.js` on `origin/develop` for the forced-serial trigger that covers the target folder. Follow the repo's pattern when the file's tests share one entity's lifecycle; otherwise keep the default.

### Test naming and tags

`Action_Description [@<module> @<submodule>]`, in square brackets inside the title. The module tag and the submodule tag are both mandatory, `@regression` is optional, and ticket tags are not used. Take the tag values from the tag tables in MAIN and the module file; never invent one. Never use `@migrated`.

### Steps — always use `test.step()`

Wrap every logical group of actions in a named step:

```js
import { test, expect } from '#mxts-test';
import { randomString } from '#utils/account-data';

test('Add_Case [@customercare @casesmodule]', async ({ page }) => {
  const suffix = randomString();

  await test.step('Navigate to Cases', async () => {
    await expect(page.getByText('assignmentCases')).toBeVisible();
    await page.getByText('assignmentCases').click();
    await expect(page.getByRole('link', { name: 'All cases' })).toBeVisible();
    await page.getByRole('link', { name: 'All cases' }).click();
    await expect(page).toHaveURL(/\/cases\/allcases/);
    await expect(page.getByRole('table')).toBeVisible();
  });

  await test.step('Open create case dialog', async () => {
    await expect(page.getByText('New case')).toBeVisible();
    await page.getByText('New case').click();
    await expect(page.getByRole('dialog', { name: 'Create case' })).toBeVisible();
  });

  await test.step('Fill and submit', async () => {
    await expect(page.getByRole('textbox', { name: 'Topic' })).toBeVisible();
    await page.getByRole('textbox', { name: 'Topic' }).fill(`Automation case ${suffix}`);
    await page.locator('a[flat-button]').filter({ hasText: 'Create case' }).click();
  });

  await test.step('Verify success', async () => {
    await expect(page.locator('snackbar#snackbar')).toContainText('Created successfully');
  });
});
```

### Selectors

Use only selectors verified in Step 5 or taken from the `execute-tests` log, in the repo's locator priority: `getByRole` → `getByLabel` → `getByText` → `getByTestId` → simple CSS. Never XPath, `nth-child` or Angular Material internals. Where the repo documents a locator for a known component (confirm button, CDK select, snackbar, `<tr>` click), use the documented one, after verifying it on the live page.

**Tests must be end-to-end and immediately runnable** — no half-written tests, no TODO placeholders, no manual intervention.

**If the page has no data** (empty table, empty state message), do NOT skip or stub the test. **First check whether the empty result is the actual thing this TC is testing** — if the TC's precondition or steps name the filter/tab itself (e.g. "Verify empty state is shown when no archived `<entity>` exists"), the filtered empty view is the required precondition, not an obstacle; preserve it and write the test asserting that empty state, skip the rest of this rule entirely. **Otherwise**, rule out a filter hiding existing data — check for an active Status/Type filter, a default "Active only" view, or a different tab, and clear/switch it before concluding the list is genuinely empty (an applied filter reading as "no data" produces a test seeded against a record that didn't need to exist). After clearing/switching, wait for the page to finish loading (Angular lists render asynchronously and can show an empty state transiently while the request is in flight — re-check with a fresh look at the DOM before trusting it) and only then re-read the list. Only once the unfiltered, fully-loaded view is also empty:
1. Use the app's own create/add flow to seed the required record as part of the test setup
2. Capture the create form selectors during that flow
3. Proceed to test the target feature on the created record
4. Clean up or leave as-is — never leave the test incomplete because data was missing

If DOM exploration genuinely failed for a specific TC, do not write that TC: see the end of Step 5, and list it in Step 8.

### Selector rules and anti-patterns

See the anti-pattern lists in the repo's MAIN (Anti-Patterns section) and the module file, read in Step 4. Never emit any selector without browser verification via `browser_evaluate`.

**Before writing any locator into the spec**: run `browser_evaluate` → `document.querySelectorAll('<css>').length`. If the result is not 1, the locator will throw a strict mode violation at runtime — fix it before continuing.

---

## Step 7: Validate — Burn-in per the Repo's Rules

**Skip this step if no local project path was provided in Step 1.** Display the spec and note: `Spec generated — burn-in skipped (no local project path provided). Run it before merging: npx playwright test <spec> --repeat-each=5 --project chromium`

> Note: validation uses the built-in Bash tool (always available — not an MCP tool). The spec must be in the actual project directory so `#mxts-test` and the path aliases resolve.

Write the spec to `<local-project-path>/tests/modules/<derived-path>/<name>.spec.js` and run everything from the project root. If `node_modules` is missing run `npm ci`; if there is no `.env`, copy `.env.example` and ask the user to fill in the credentials — never write credentials yourself (`CLAUDE.md` hard rule 6).

**7a — Clean up before the first burn-in run.** Read `.claude/skills/create-pr/SKILL.md` on `origin/develop` and apply its comment-cleanup and locator-hygiene steps to the new spec and any POM touched: read each file in full, remove debugging, narration and TODO comments, and replace any banned locator (XPath, `nth-child`, `.mat-mdc-*`, `_ngcontent-*`). `CLAUDE.md` requires this pass before burn-in, not after.

**7b — Burn-in.** Read `.claude/skills/playwright-burnin/SKILL.md` on `origin/develop` and follow it with `N=5` on the spec's folder: five clean passes, serial or parallel, run in the background, `--max-failures=1`, no `--workers` flag, and a `--list` file-count cross-check against the project that claims the file. Fewer than five clean passes never counts, and a pass containing a failure never counts toward the five.

**On any failure**, stop at the first one and follow `CLAUDE.md` "Verify first": reproduce it live with the Playwright MCP, find the real root cause, apply the minimal fix, re-run only the failed test once, then restart the five passes from zero. Never widen a timeout or add a sleep or a retry to get a green run. For the headless → delete `playwright/.auth/user.json` → headed confirmation sequence, follow MAIN's "Test Fix Workflow".

Report only the real numbers the run produced.

---

## Step 8: Display Output

```
**File:** `tests/modules/<path>/<name>.spec.js`
**Rules read:** `<target_repo>` `origin/develop` @ `<short SHA>` (Step 4)
**Tests:** <n> tests across <n> describe blocks
**Selectors:** live DOM ✅ | execution log ✅
**Already automated (skipped):** <n> TC(s) — see list below, or "none"
**Not automated:** <n> TC(s) — selector could not be verified, or "none"

<per-test selector source summary>
<TC_ID> — already automated: <matched file path> (skipped, no duplicate generated)   ← one line per TC from Step 3a, if any
<TC_ID> — not automated: <reason>   ← one line per TC left out in Step 5, if any
```

Then print the complete spec file in a code block, along with the burn-in result (e.g. "5/5 clean passes on attempt 2 after fixing X").

Finally, ask the user **once**:
> The spec passed 5 clean burn-in passes and is written to `<local-project-path>/tests/modules/<path>/<name>.spec.js`. Do you want me to open a draft PR in `MaxxtonGroup/<target_repo>` and comment on the Jira ticket with the PR link?
> - **yes** — open the PR and post the comment
> - **no** — skip

**If yes:** read `.claude/skills/create-pr/SKILL.md` on `origin/develop` and follow it. It owns the repo's PR flow: the scope check, branch `feature/QA-<id>_<short-slug>`, base `develop`, always a **draft**, title `QA-<id>: <summary>`, the PR body with its execution summary and the repo's PR template, the Jira comment (posted with `mcp__claude_ai_Atlassian_MCP__addOrEditJiraIssueComment`, then re-read from the ticket to verify it landed), and the reference-file update for any new reusable pattern. `<id>` is the QA Jira ticket: if only an MXTS story key is known, ask the user for the QA ticket — never invent one. If the local `gh` CLI is unavailable, use `create_branch`, `push_files` and `create_pull_request` (with `draft: true`) with the same branch name, base, title and body. Print the PR URL.

**To run locally:**
```
npx playwright test <path-to-spec> --project chromium
```
