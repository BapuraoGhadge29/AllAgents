#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
FIXTURES_DIR="$SCRIPT_DIR/fixtures"
SOURCE_SCRIPT="$SCRIPT_DIR/../session-start.sh"
GIT="git -c user.email=test@test.local -c user.name=test-suite"

RED='\033[0;31m'; GREEN='\033[0;32m'; NC='\033[0m'
pass=0; fail=0

# Resolve a Python 3 interpreter (python3 → python → py -3), executing each
# candidate so the Windows Store-alias stub is rejected. Inlined (not sourced)
# so the script survives being copied/relocated. See CLAUDE.md "Invoking Python
# from shell scripts".
resolve_python() {
  local _cand
  for _cand in python3 python "py -3"; do
    if $_cand -c 'import sys; sys.exit(0 if sys.version_info[0] == 3 else 1)' >/dev/null 2>&1; then
      printf '%s\n' "$_cand"; return 0
    fi
  done
  return 1
}
PY=$(resolve_python) || { echo "no Python 3 found (tried python3, python, py -3)" >&2; exit 1; }
read -r -a PY_CMD <<< "$PY"

WORKDIR=$(mktemp -d)
trap 'rm -rf "$WORKDIR"' EXIT

# --- "GitHub" stand-ins: each is a real local git repo on branch main with a
# single commit, holding the marketplace.json content the real GitHub repo
# would serve. session-start.sh never knows these are local — it only ever
# talks to whatever 'origin' resolves to.
make_fixture_repo() {
  local dir="$1" fixture_file="$2"
  mkdir -p "$dir/.claude-plugin"
  cp "$FIXTURES_DIR/$fixture_file" "$dir/.claude-plugin/marketplace.json"
  $GIT -c core.autocrlf=false init --quiet "$dir" 2>/dev/null
  $GIT -C "$dir" -c core.autocrlf=false add .claude-plugin/marketplace.json 2>/dev/null
  $GIT -C "$dir" commit --quiet -m fixture 2>/dev/null
  $GIT -C "$dir" branch -M main 2>/dev/null
}
make_fixture_repo "$WORKDIR/remote-newer" marketplace-newer.json
make_fixture_repo "$WORKDIR/remote-same" marketplace-same.json
make_fixture_repo "$WORKDIR/remote-older" marketplace-older.json
make_fixture_repo "$WORKDIR/remote-malformed" marketplace-malformed.json
make_fixture_repo "$WORKDIR/remote-no-qa-engineer" marketplace-no-qa-engineer.json
UNREACHABLE_REMOTE="$WORKDIR/does-not-exist"

# --- The "installed plugin" side: mirrors the real layout
# (<marketplace root>/plugins/qa-engineer/hooks/session-start.sh, with a
# .claude-plugin/plugin.json two levels up) so the script's own
# SCRIPT_DIR/../.. resolution lands on a real git checkout with an 'origin'.
MOCK_ROOT="$WORKDIR/local-checkout"
mkdir -p "$MOCK_ROOT/plugins/qa-engineer/hooks" "$MOCK_ROOT/plugins/qa-engineer/.claude-plugin"
cp "$SOURCE_SCRIPT" "$MOCK_ROOT/plugins/qa-engineer/hooks/session-start.sh"
chmod +x "$MOCK_ROOT/plugins/qa-engineer/hooks/session-start.sh"
$GIT init --quiet "$MOCK_ROOT"
$GIT -C "$MOCK_ROOT" remote add origin "$WORKDIR/remote-newer"

set_local_version() {
  printf '{"version": "%s"}' "$1" > "$MOCK_ROOT/plugins/qa-engineer/.claude-plugin/plugin.json"
}

set_remote() {
  $GIT -C "$MOCK_ROOT" remote set-url origin "$1"
}

CACHE_FILE="$WORKDIR/version-check-cache.json"

has_system_message() {
  # stdin: hook stdout. Exit 0 iff it parses as JSON with a non-empty systemMessage.
  "${PY_CMD[@]}" -c "
import json, sys
try:
    d = json.load(sys.stdin)
except Exception:
    sys.exit(1)
sys.exit(0 if d.get('systemMessage', '') else 1)
" 2>/dev/null
}

message_contains() {
  # $1: substring. stdin: hook stdout. Exit 0 iff systemMessage contains it.
  "${PY_CMD[@]}" -c "
import json, sys
d = json.load(sys.stdin)
sys.exit(0 if sys.argv[1] in d.get('systemMessage', '') else 1)
" "$1" 2>/dev/null
}

run_hook() {
  QA_ENGINEER_VERSION_CACHE_FILE="$CACHE_FILE" \
    bash "$MOCK_ROOT/plugins/qa-engineer/hooks/session-start.sh" 2>/dev/null
}

# expect_message: "yes"/"no" whether a systemMessage should appear.
# expect_contains: substring the systemMessage must contain (ignored if expect_message=no).
run_case() {
  local desc="$1" expect_message="$2" expect_contains="$3" remote="$4"
  rm -f "$CACHE_FILE"
  set_remote "$remote"
  local stdout exit_code=0
  stdout=$(run_hook) || exit_code=$?

  local ok=1
  [[ $exit_code -ne 0 ]] && ok=0

  local has_message=0
  if [[ -n "$stdout" ]] && printf '%s' "$stdout" | has_system_message; then
    has_message=1
  fi

  if [[ "$expect_message" == "yes" ]]; then
    [[ $has_message -eq 1 ]] || ok=0
    if [[ $has_message -eq 1 && -n "$expect_contains" ]]; then
      printf '%s' "$stdout" | message_contains "$expect_contains" || ok=0
    fi
  else
    [[ $has_message -eq 0 ]] || ok=0
  fi

  if [[ $ok -eq 1 ]]; then
    printf "  ${GREEN}PASS${NC} %s\n" "$desc"; pass=$(( pass + 1 ))
  else
    printf "  ${RED}FAIL${NC} %s (exit=%d stdout=%s)\n" "$desc" "$exit_code" "$stdout"
    fail=$(( fail + 1 ))
  fi
}

echo "Fresh run (no cache) — origin fetch decides"
set_local_version "1.0.0"
run_case "newer version available -> systemMessage with both versions" \
  yes "v1.0.0" "$WORKDIR/remote-newer"
run_case "same version -> silent" \
  no "" "$WORKDIR/remote-same"
run_case "local ahead of remote -> silent, no false warning" \
  no "" "$WORKDIR/remote-older"
run_case "malformed remote marketplace.json -> fails open, silent" \
  no "" "$WORKDIR/remote-malformed"
run_case "remote marketplace.json has no qa-engineer entry -> silent" \
  no "" "$WORKDIR/remote-no-qa-engineer"
run_case "origin does not resolve -> fails open, silent" \
  no "" "$UNREACHABLE_REMOTE"

echo ""
echo "Caching behaviour"

rm -f "$CACHE_FILE"
set_local_version "1.0.0"
set_remote "$WORKDIR/remote-newer"
run_hook >/dev/null 2>&1 || true

if [[ -f "$CACHE_FILE" ]]; then
  printf "  ${GREEN}PASS${NC} %s\n" "cache file written after a fresh check"; pass=$(( pass + 1 ))
else
  printf "  ${RED}FAIL${NC} %s\n" "cache file written after a fresh check"; fail=$(( fail + 1 ))
fi

set_remote "$UNREACHABLE_REMOTE"
stdout=$(run_hook) || true
has_message=0
if [[ -n "$stdout" ]] && printf '%s' "$stdout" | has_system_message; then
  has_message=1
fi
if [[ $has_message -eq 1 ]]; then
  printf "  ${GREEN}PASS${NC} %s\n" "fresh cache is reused without hitting a (now-broken) origin"; pass=$(( pass + 1 ))
else
  printf "  ${RED}FAIL${NC} %s\n" "fresh cache is reused without hitting a (now-broken) origin"; fail=$(( fail + 1 ))
fi

# Path passed as an argv token (sys.argv[1]), not interpolated into the
# script text — an interpolated path skips the MSYS auto-translation that
# Windows-native Python needs to resolve a posix-style path like /tmp/....
"${PY_CMD[@]}" - "$CACHE_FILE" <<'PYEOF'
import json, sys
with open(sys.argv[1]) as f:
    d = json.load(f)
d['checked_at'] = 0
with open(sys.argv[1], 'w') as f:
    json.dump(d, f)
PYEOF
stdout=$(run_hook) || true
if [[ -z "$stdout" ]]; then
  printf "  ${GREEN}PASS${NC} %s\n" "stale cache (checked_at=0) triggers a re-fetch, not the old cached value"; pass=$(( pass + 1 ))
else
  printf "  ${RED}FAIL${NC} %s (expected silent re-fetch failure, got: %s)\n" "stale cache (checked_at=0) triggers a re-fetch, not the old cached value" "$stdout"; fail=$(( fail + 1 ))
fi

echo ""
echo "Local version changed since last cache entry"
rm -f "$CACHE_FILE"
set_local_version "1.0.0"
set_remote "$WORKDIR/remote-same"
run_hook >/dev/null 2>&1 || true
# Cache now says "1.0.0 is up to date". Bump the local version without
# touching the cache — it must NOT be reused for a different local version.
set_local_version "0.5.0"
stdout=$(run_hook) || true
has_message=0
if [[ -n "$stdout" ]] && printf '%s' "$stdout" | message_contains "v0.5.0"; then
  has_message=1
fi
if [[ $has_message -eq 1 ]]; then
  printf "  ${GREEN}PASS${NC} %s\n" "cache keyed to a different local version is not reused"; pass=$(( pass + 1 ))
else
  printf "  ${RED}FAIL${NC} %s (stdout=%s)\n" "cache keyed to a different local version is not reused" "$stdout"; fail=$(( fail + 1 ))
fi

echo ""
echo "Hung git fetch is capped, not left to hang"
# ext:: lets a remote URL run an arbitrary command as its "transport" — used
# here to build a remote that never responds, simulating a stuck network
# call. protocol.ext.allow=always is needed because git disables ext:: by
# default (it can run arbitrary commands) — safe here, it's our own throwaway
# test repo, never the production script's config.
rm -f "$CACHE_FILE"
set_local_version "1.0.0"
set_remote "ext::sleep 30"
$GIT -C "$MOCK_ROOT" config protocol.ext.allow always

run_hook_timed() {
  local start end
  start=$(date +%s)
  run_hook >/dev/null || true
  end=$(date +%s)
  echo $((end - start))
}

elapsed=$(run_hook_timed)
# Generous upper bound (script's own cap is 8s) — this only needs to prove
# the run finished well short of the remote's 30s, not measure it precisely.
if [[ "$elapsed" -lt 20 ]]; then
  printf "  ${GREEN}PASS${NC} %s (%ss)\n" "hung fetch (timeout binary path) capped, did not wait the remote's 30s" "$elapsed"; pass=$(( pass + 1 ))
else
  printf "  ${RED}FAIL${NC} %s (%ss)\n" "hung fetch (timeout binary path) capped, did not wait the remote's 30s" "$elapsed"; fail=$(( fail + 1 ))
fi

rm -f "$CACHE_FILE"
# Time the forced-bash-watchdog path explicitly (the case with no 'timeout'
# binary available, e.g. default macOS) — this is the path Copilot's review
# flagged as unguarded before this fix.
start=$(date +%s)
QA_ENGINEER_FORCE_BASH_WATCHDOG=1 QA_ENGINEER_VERSION_CACHE_FILE="$CACHE_FILE" \
  bash "$MOCK_ROOT/plugins/qa-engineer/hooks/session-start.sh" >/dev/null 2>&1 || true
end=$(date +%s)
elapsed=$((end - start))
if [[ "$elapsed" -lt 20 ]]; then
  printf "  ${GREEN}PASS${NC} %s (%ss)\n" "hung fetch (forced bash-watchdog path) capped, did not wait the remote's 30s" "$elapsed"; pass=$(( pass + 1 ))
else
  printf "  ${RED}FAIL${NC} %s (%ss)\n" "hung fetch (forced bash-watchdog path) capped, did not wait the remote's 30s" "$elapsed"; fail=$(( fail + 1 ))
fi

# Restore a normal remote for any tests that might run after this block.
set_remote "$WORKDIR/remote-newer"
$GIT -C "$MOCK_ROOT" config --unset protocol.ext.allow 2>/dev/null || true

echo ""
echo "No git checkout to check against"
NO_GIT_ROOT="$WORKDIR/no-git-checkout"
mkdir -p "$NO_GIT_ROOT/plugins/qa-engineer/hooks" "$NO_GIT_ROOT/plugins/qa-engineer/.claude-plugin"
cp "$SOURCE_SCRIPT" "$NO_GIT_ROOT/plugins/qa-engineer/hooks/session-start.sh"
chmod +x "$NO_GIT_ROOT/plugins/qa-engineer/hooks/session-start.sh"
printf '{"version": "1.0.0"}' > "$NO_GIT_ROOT/plugins/qa-engineer/.claude-plugin/plugin.json"
stdout=$(QA_ENGINEER_VERSION_CACHE_FILE="$WORKDIR/no-git-cache.json" \
  bash "$NO_GIT_ROOT/plugins/qa-engineer/hooks/session-start.sh" 2>/dev/null) || true
if [[ -z "$stdout" ]]; then
  printf "  ${GREEN}PASS${NC} %s\n" "no .git at the marketplace root -> fails open, silent"; pass=$(( pass + 1 ))
else
  printf "  ${RED}FAIL${NC} %s (stdout=%s)\n" "no .git at the marketplace root -> fails open, silent" "$stdout"; fail=$(( fail + 1 ))
fi

echo ""
echo "Installed layout (plugin under cache/, marketplace clone under marketplaces/)"
INSTALL_BASE="$WORKDIR/claude-plugins"
CACHE_PLUGIN="$INSTALL_BASE/cache/mkt/qa-engineer/1.0.0"
CLONE_DIR="$INSTALL_BASE/marketplaces/mkt"
mkdir -p "$CACHE_PLUGIN/hooks" "$CACHE_PLUGIN/.claude-plugin" "$CLONE_DIR"
cp "$SOURCE_SCRIPT" "$CACHE_PLUGIN/hooks/session-start.sh"
chmod +x "$CACHE_PLUGIN/hooks/session-start.sh"
printf '{"version": "1.0.0"}' > "$CACHE_PLUGIN/.claude-plugin/plugin.json"
$GIT init --quiet "$CLONE_DIR"
$GIT -C "$CLONE_DIR" remote add origin "$WORKDIR/remote-newer"

run_installed() {
  QA_ENGINEER_VERSION_CACHE_FILE="$WORKDIR/installed-cache.json" \
    bash "$CACHE_PLUGIN/hooks/session-start.sh" 2>/dev/null
}

rm -f "$WORKDIR/installed-cache.json"
stdout=$(run_installed) || true
has_message=0
if [[ -n "$stdout" ]] && printf '%s' "$stdout" | message_contains "v1.0.0"; then
  has_message=1
fi
if [[ $has_message -eq 1 ]]; then
  printf "  ${GREEN}PASS${NC} %s\n" "behind the remote -> systemMessage, read from the marketplace clone"; pass=$(( pass + 1 ))
else
  printf "  ${RED}FAIL${NC} %s (stdout=%s)\n" "behind the remote -> systemMessage, read from the marketplace clone" "$stdout"; fail=$(( fail + 1 ))
fi

rm -rf "$CLONE_DIR" "$WORKDIR/installed-cache.json"
stdout=$(run_installed) || true
if [[ -z "$stdout" ]]; then
  printf "  ${GREEN}PASS${NC} %s\n" "no marketplace clone next to the cache -> fails open, silent"; pass=$(( pass + 1 ))
else
  printf "  ${RED}FAIL${NC} %s (stdout=%s)\n" "no marketplace clone next to the cache -> fails open, silent" "$stdout"; fail=$(( fail + 1 ))
fi

echo ""
total=$((pass + fail))
echo "Results: ${pass}/${total} passed"
[[ $fail -eq 0 ]]
