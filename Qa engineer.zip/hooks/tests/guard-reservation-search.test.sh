#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
HOOK="$SCRIPT_DIR/../guard-reservation-search.js"

RED='\033[0;31m'; GREEN='\033[0;32m'; NC='\033[0m'
pass=0; fail=0

command -v node >/dev/null 2>&1 || { echo "node is required to run this test" >&2; exit 1; }

# type_payload <tool_name> <element> <text> — a browser_type PreToolUse payload, built with node so quoting is exact.
type_payload() {
  node -e 'process.stdout.write(JSON.stringify({ hook_event_name: "PreToolUse", tool_name: process.argv[1], tool_input: { element: process.argv[2], target: "e15", text: process.argv[3] } }))' "$@"
}

# form_payload <tool_name> <field name> <value> — a browser_fill_form payload with one field.
form_payload() {
  node -e 'process.stdout.write(JSON.stringify({ hook_event_name: "PreToolUse", tool_name: process.argv[1], tool_input: { fields: [{ name: process.argv[2], type: "textbox", target: "e9", value: process.argv[3] }] } }))' "$@"
}

OUT=""
LAST_EXIT=0
run_hook() {
  LAST_EXIT=0
  OUT=$(printf '%s' "$1" | node "$HOOK" 2>/dev/null) || LAST_EXIT=$?
}

check() { # check <name> <condition-exit-code>
  if [ "$2" -eq 0 ]; then pass=$((pass + 1)); printf "${GREEN}PASS${NC} %s\n" "$1"
  else fail=$((fail + 1)); printf "${RED}FAIL${NC} %s\n  hook output: %s\n" "$1" "$OUT"; fi
}
denied() { case "$OUT" in *'"permissionDecision":"deny"'*) return 0 ;; *) return 1 ;; esac; }
silent() { [ -z "$OUT" ] && [ "$LAST_EXIT" -eq 0 ]; }

HEADED="mcp__playwright-headed__browser_type"
BUNDLED="mcp__plugin_qa-engineer_playwright__browser_type"
WORKER="mcp__plugin_qa-engineer_playwright-w2__browser_type"
FORM="mcp__playwright-headed__browser_fill_form"

run_hook "$(type_payload "$HEADED" 'Search reservations textbox' 'QA-SEED-MXTS-79611')"
denied && rc=0 || rc=1; check "a QA-SEED name typed into the reservation search is denied" "$rc"

run_hook "$(type_payload "$BUNDLED" 'Search reservations textbox' 'QA-SEED-MXTS-79611')"
denied && rc=0 || rc=1; check "denied on the bundled server too" "$rc"

run_hook "$(type_payload "$WORKER" 'Search reservations textbox' 'QA-SEED-MXTS-79611')"
denied && rc=0 || rc=1; check "denied on the worker server too" "$rc"

run_hook "$(type_payload "$HEADED" 'Reservation filter textbox' 'qa-seed-mxts-79611-group')"
denied && rc=0 || rc=1; check "a reservation filter field is covered and the match ignores case" "$rc"

run_hook "$(form_payload "$FORM" 'Search reservations' 'QA-SEED-MXTS-79611')"
denied && rc=0 || rc=1; check "browser_fill_form with the same text is denied" "$rc"

run_hook "$(type_payload "$HEADED" 'Search reservations textbox' '8331748')"
silent && rc=0 || rc=1; check "a reservation number in the reservation search passes" "$rc"

run_hook "$(type_payload "$HEADED" 'Search reservations textbox' 'Smith')"
silent && rc=0 || rc=1; check "a guest name in the reservation search passes" "$rc"

run_hook "$(type_payload "$HEADED" 'Search group reservations textbox' 'QA-SEED-MXTS-79611')"
silent && rc=0 || rc=1; check "a group reservation list is left alone (its TCs name it)" "$rc"

run_hook "$(type_payload "$HEADED" 'Customer name textbox' 'QA-SEED-MXTS-79611-Customer')"
silent && rc=0 || rc=1; check "the QA-SEED customer name in a customer field passes" "$rc"

run_hook "$(type_payload "$HEADED" 'Reservation notes textbox' 'QA-SEED-MXTS-79611-Reservation')"
silent && rc=0 || rc=1; check "a creation form's reference or notes field passes" "$rc"

run_hook "$(form_payload "$FORM" 'Customer search' 'QA-SEED-MXTS-79611-Customer')"
silent && rc=0 || rc=1; check "browser_fill_form into a customer search passes" "$rc"

run_hook "$(type_payload "mcp__playwright-headed__browser_click" 'Search reservations textbox' 'QA-SEED-MXTS-79611')"
silent && rc=0 || rc=1; check "another browser tool is left alone" "$rc"

run_hook "$(type_payload "mcp__claude_ai_Atlassian_MCP__addOrEditJiraIssueComment" 'Search reservations textbox' 'QA-SEED-MXTS-79611')"
silent && rc=0 || rc=1; check "another server's tool is left alone" "$rc"

run_hook 'this is not json'
silent && rc=0 || rc=1; check "an unreadable payload fails open" "$rc"

run_hook ''
silent && rc=0 || rc=1; check "an empty payload fails open" "$rc"

run_hook '{"tool_name":"mcp__playwright-headed__browser_type","tool_input":{"text":"QA-SEED-X"}}'
silent && rc=0 || rc=1; check "a call without an element description passes (the rule in Test Data Setup stays the control)" "$rc"

printf '\n%s passed, %s failed\n' "$pass" "$fail"
[ "$fail" -eq 0 ]
