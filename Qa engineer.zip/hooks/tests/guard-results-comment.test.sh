#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
HOOK="$SCRIPT_DIR/../guard-results-comment.js"

RED='\033[0;31m'; GREEN='\033[0;32m'; NC='\033[0m'
pass=0; fail=0

command -v node >/dev/null 2>&1 || { echo "node is required to run this test" >&2; exit 1; }

# payload <tool_name> <commentBody> [contentFormat] — the hook's stdin JSON, built with node so quoting is exact.
payload() {
  node -e 'process.stdout.write(JSON.stringify({ hook_event_name: "PreToolUse", tool_name: process.argv[1], tool_input: { cloudId: "c", issueIdOrKey: "MXTS-1", commentBody: process.argv[2], contentFormat: process.argv[3] || "markdown" } }))' "$@"
}

# stats_md <timing> [total] — a markdown results comment with every dashboard row filled in.
stats_md() {
  printf '## QA Test Results\n\n| **Concern** | RVP |\n|---|---|\n| **Environment** | Dev |\n| **Build / Version** | 1.0.0 |\n| **Preconditions** | None detected |\n| **Total TCs** | %s |\n| **Passed** | 1 |\n| **Failed** | 0 |\n| **Blocked** | 0 |\n| **Needs Review** | 0 |\n| **Skipped** | 0 |\n| **Pass rate** | 100%% |\n| **QA Pipeline Version** | 2.12.0 |\n| **Test Execution Timing** | %s |\n' "${2:-1}" "$1"
}

stats_html() {
  local rows="" label value
  while IFS='|' read -r label value; do
    rows="${rows}<tr><td><p><strong>${label}</strong></p></td><td><p>${value}</p></td></tr>"
  done <<EOF2
Concern|RVP
Environment|Dev
Build / Version|1.0.0
Total TCs|1
Passed|1
Failed|0
Blocked|0
Needs Review|0
Skipped|0
Pass rate|100%
QA Pipeline Version|2.12.0
Test Execution Timing|$1
EOF2
  printf '<h2>QA Test Results</h2><table><tbody>%s</tbody></table>' "$rows"
}

# run_hook <stdin-text> — sets OUT (hook stdout) and LAST_EXIT.
OUT=""
LAST_EXIT=0
run_hook() {
  LAST_EXIT=0
  OUT=$(printf '%s' "$1" | node "$HOOK" 2>/dev/null) || LAST_EXIT=$?
}

check() { # check <name> <condition-exit-code>
  if [ "$2" -eq 0 ]; then pass=$((pass + 1)); printf "${GREEN}PASS${NC} %s\n" "$1"
  else fail=$((fail + 1)); printf "${RED}FAIL${NC} %s\n  hook output: %s\n" "$1" "$OUT"; fi
}
denied() { case "$OUT" in *'"permissionDecision":"deny"'*) return 0 ;; *) return 1 ;; esac; }
silent() { [ -z "$OUT" ] && [ "$LAST_EXIT" -eq 0 ]; }

TOOL="mcp__claude_ai_Atlassian_MCP__addOrEditJiraIssueComment"

run_hook "$(payload "$TOOL" "$(stats_md '38m (2 pauses)')")"
silent && rc=0 || rc=1; check "a results comment with a numeric timing passes (markdown)" "$rc"

run_hook "$(payload "$TOOL" "$(stats_md '42m')")"
silent && rc=0 || rc=1; check "a plain timing passes" "$rc"

run_hook "$(payload "$TOOL" "$(stats_md 'N/A (generation only)')")"
silent && rc=0 || rc=1; check "N/A (generation only) passes" "$rc"

run_hook "$(payload "$TOOL" "$(stats_md 'Not tracked')")"
denied && rc=0 || rc=1; check "'Not tracked' timing is denied" "$rc"

run_hook "$(payload "$TOOL" "$(stats_md 'N/A (run spanned several sessions with tester pauses)')")"
denied && rc=0 || rc=1; check "the improvised N/A sentence is denied" "$rc"

run_hook "$(payload "$TOOL" "$(stats_md '10m' '13 (retest of the non-pass TCs from the previous run)')")"
denied && rc=0 || rc=1; check "a Total TCs cell with prose is denied" "$rc"

run_hook "$(payload "$TOOL" "$(stats_html 'Not tracked')" html)"
denied && rc=0 || rc=1; check "'Not tracked' timing is denied (HTML body)" "$rc"

run_hook "$(payload "$TOOL" "$(stats_html '1h 12m (1 pause)')" html)"
silent && rc=0 || rc=1; check "a numeric timing passes (HTML body)" "$rc"

run_hook "$(payload "$TOOL" "$(stats_md '38m' | grep -v 'Test Execution Timing')")"
denied && rc=0 || rc=1; check "a results comment without the Timing row is denied (markdown)" "$rc"

run_hook "$(payload "$TOOL" "$(stats_html '38m' | sed 's#<tr><td><p><strong>Test Execution Timing</strong></p></td><td><p>38m</p></td></tr>##')" html)"
denied && rc=0 || rc=1; check "a results comment without the Timing row is denied (HTML)" "$rc"

run_hook "$(payload "$TOOL" "$(printf '## QA Test Results

All TCs were blocked.
')")"
denied && rc=0 || rc=1; check "a results comment without any stats table is denied" "$rc"

run_hook "$(payload "$TOOL" '## QA Test Results — MXTS-1

| **Test Execution Timing** | Not tracked |')"
silent && rc=0 || rc=1; check "a different comment type (execute-tests header) is left alone" "$rc"

run_hook "$(payload "$TOOL" 'Retest passed, timing not tracked.')"
silent && rc=0 || rc=1; check "an ordinary comment is left alone" "$rc"

run_hook "$(payload "mcp__claude_ai_Atlassian_MCP__createJiraIssue" "$(stats_md 'Not tracked')")"
silent && rc=0 || rc=1; check "another tool is left alone" "$rc"

run_hook 'this is not json'
silent && rc=0 || rc=1; check "an unreadable payload fails open" "$rc"

run_hook ''
silent && rc=0 || rc=1; check "an empty payload fails open" "$rc"

printf '\n%s passed, %s failed\n' "$pass" "$fail"
[ "$fail" -eq 0 ]
