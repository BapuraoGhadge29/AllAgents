#!/usr/bin/env node
/**
 * PreToolUse guard for the Atlassian MCP write path (`jira_write_path = mcp`).
 *
 * The script path cannot post a results comment without passing post-comment.js. The MCP path can: its
 * validator (validate-results-comment.js) only runs when the agent remembers to call it. This hook closes that
 * gap for the stats rows the adoption dashboard reads. When `addOrEditJiraIssueComment` is about to write a
 * "QA Test Results" comment whose stats table lacks a row the dashboard reads, whose Test Execution Timing is not a number (e.g. "Not tracked", "N/A (run spanned
 * several sessions…)"), whose counts are not whole numbers, or whose version is not major.minor.patch, the call
 * is denied with the reason, and the agent rebuilds the row (`run-timing.js render` for the timing) and posts again.
 *
 * Only this narrow check runs here, never the full validator: a split-result part needs --part flags the hook
 * cannot know, and a wrong deny on a legitimate post is worse than the gap.
 *
 * Failure mode: any other comment, and any error reading the payload, passes through untouched (no output,
 * exit 0). The validators stay the primary gate; this is the backstop.
 */
'use strict';

const path = require('path');
const { statsErrors } = require(path.join(__dirname, '..', 'skills', 'test-ticket', 'scripts', 'dashboard-stats'));

/** True when the body is a test-ticket results comment: header exactly "QA Test Results" (HTML, markdown or wiki). */
function isResultsComment(body) {
  const text = String(body).trimStart();
  if (text.startsWith('<')) return /^<h2[^>]*>\s*QA Test Results\s*<\/h2>/i.test(text);
  const first = text.split('\n', 1)[0].trim();
  return first === '## QA Test Results' || first === 'h2. QA Test Results';
}

/** The deny payload for a payload that breaks the rules, or null to let the call through. */
function check(payload) {
  const toolName = payload && payload.tool_name;
  const input = payload && payload.tool_input;
  if (typeof toolName !== 'string' || !toolName.endsWith('__addOrEditJiraIssueComment')) return null;
  if (!input || typeof input.commentBody !== 'string' || !isResultsComment(input.commentBody)) return null;
  const errors = statsErrors(input.commentBody, { requireRows: true });
  if (!errors.length) return null;
  return {
    hookSpecificOutput: {
      hookEventName: 'PreToolUse',
      permissionDecision: 'deny',
      permissionDecisionReason:
        'Blocked: this QA Test Results comment has stats rows the dashboard cannot read.\n' + errors.join('\n') +
        '\nGet the Timing cell from `run-timing.js render` (see phase-3b-results-comment.md), fix the rows, run validate-results-comment.js and post again.',
    },
  };
}

function main() {
  let input = '';
  process.stdin.setEncoding('utf8');
  process.stdin.on('data', (chunk) => { input += chunk; });
  process.stdin.on('end', () => {
    try {
      const deny = check(JSON.parse(input));
      if (deny) process.stdout.write(JSON.stringify(deny) + '\n');
    } catch { /* fail open: not our payload */ }
  });
}

if (require.main === module) main();
module.exports = { isResultsComment, check };
