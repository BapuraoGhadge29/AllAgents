#!/usr/bin/env bash
set -euo pipefail

# SessionStart hook — warns once a day if the installed qa-engineer plugin
# version is behind the version published on the marketplace repo's main
# branch. This is a convenience notice only: any missing dependency, network
# failure, or parse error along the way skips silently. It never blocks or
# slows down session start beyond a capped, cached git fetch.
#
# The marketplace repo is private, so raw.githubusercontent.com (unauthenticated)
# 404s on it — this reads the version via `git fetch` + `git show` against the
# plugin's own git checkout instead, reusing whatever credentials the user
# already has for that repo (the same ones that got the plugin installed).
#
# Env overrides (tests only — production always uses the default):
#   QA_ENGINEER_VERSION_CACHE_FILE   — where the last check result is cached
#   QA_ENGINEER_FORCE_BASH_WATCHDOG  — skip the `timeout` binary and force the
#                                      pure-bash fallback in run_with_timeout,
#                                      so that path is exercised even on a
#                                      machine where `timeout` happens to exist

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PLUGIN_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"
MARKETPLACE_ROOT="$(cd "$PLUGIN_ROOT/../.." && pwd)"
DEFAULT_BRANCH="main"
CACHE_FILE="${QA_ENGINEER_VERSION_CACHE_FILE:-$HOME/.claude/.qa-engineer-version-check.json}"
CACHE_TTL_SECONDS=86400  # re-check at most once a day

# Resolve a Python 3 interpreter (python3 → python → py -3), executing each
# candidate so the Windows Store-alias stub is rejected. Inlined (not sourced)
# so the script survives being copied/relocated. See CLAUDE.md "Invoking Python
# from shell scripts".
resolve_python() {
  local _cand
  for _cand in python3 python "py -3"; do
    if $_cand -c 'import sys; sys.exit(0 if sys.version_info[0] == 3 else 1)' >/dev/null 2>&1; then
      printf '%s\n' "$_cand"; return 0
    fi
  done
  return 1
}
PY=$(resolve_python) || exit 0

# Portable command timeout: uses the `timeout` binary when available (fast,
# exact); otherwise falls back to a pure-bash background-process watchdog so
# the cap is enforced unconditionally — `timeout` isn't preinstalled on
# default macOS (no GNU coreutils there), and a cap that silently disappears
# on some platforms isn't a cap.
run_with_timeout() {
  local secs="$1"; shift
  if [ -z "${QA_ENGINEER_FORCE_BASH_WATCHDOG:-}" ] && command -v timeout >/dev/null 2>&1; then
    timeout "$secs" "$@"
    return $?
  fi
  "$@" &
  local pid=$! waited=0
  while kill -0 "$pid" 2>/dev/null; do
    if [ "$waited" -ge "$secs" ]; then
      kill "$pid" 2>/dev/null
      wait "$pid" 2>/dev/null
      return 124
    fi
    sleep 1
    waited=$((waited + 1))
  done
  wait "$pid"
}

LOCAL_PLUGIN_JSON="$PLUGIN_ROOT/.claude-plugin/plugin.json"
[ -f "$LOCAL_PLUGIN_JSON" ] || exit 0

LOCAL_VERSION=$($PY - "$LOCAL_PLUGIN_JSON" <<'PYEOF'
import json, sys
try:
    with open(sys.argv[1]) as f:
        print(json.load(f).get('version', ''))
except Exception:
    print('')
PYEOF
) || exit 0
[ -n "$LOCAL_VERSION" ] || exit 0

# Reuse a cached comparison if it's fresh and still about this same local
# version — avoids a git fetch on every single session start. Emits "stale"
# (meaning: go check) or the cached latest-version string.
NOW=$(date +%s 2>/dev/null) || exit 0
CACHE_RESULT="stale"
if [ -f "$CACHE_FILE" ]; then
  CACHE_RESULT=$($PY - "$CACHE_FILE" "$NOW" "$CACHE_TTL_SECONDS" "$LOCAL_VERSION" <<'PYEOF'
import json, sys
cache_path, now, ttl, local_version = sys.argv[1], int(sys.argv[2]), int(sys.argv[3]), sys.argv[4]
try:
    with open(cache_path) as f:
        d = json.load(f)
except Exception:
    print("stale")
    sys.exit(0)
# Installed version changed since the last check (e.g. user just updated) —
# force a fresh comparison instead of trusting a cache keyed to the old one.
if d.get('checked_local_version') != local_version:
    print("stale")
    sys.exit(0)
if now - int(d.get('checked_at', 0)) > ttl:
    print("stale")
    sys.exit(0)
print(d.get('latest_version', 'stale') or 'stale')
PYEOF
  ) || CACHE_RESULT="stale"
fi

if [ "$CACHE_RESULT" = "stale" ]; then
  # Needs a git checkout with an 'origin' remote: either the plugin root's own
  # (a developer's local clone of this repo) or, for an installed plugin that
  # runs from <plugins>/cache/<marketplace>/<plugin>/<version>, the
  # marketplace's clone at <plugins>/marketplaces/<marketplace>. Anything else
  # (a completely detached copy) can't be checked — skip silently.
  CHECKOUT_ROOT="$MARKETPLACE_ROOT"
  if [ ! -d "$CHECKOUT_ROOT/.git" ]; then
    CLONE_ROOT="$MARKETPLACE_ROOT/../../marketplaces/${MARKETPLACE_ROOT##*/}"
    [ -d "$CLONE_ROOT/.git" ] || exit 0
    CHECKOUT_ROOT="$(cd "$CLONE_ROOT" && pwd)"
  fi
  git -C "$CHECKOUT_ROOT" remote get-url origin >/dev/null 2>&1 || exit 0

  # 8s cap (via run_with_timeout — enforced even without the `timeout` binary)
  # — never let a slow/offline network hold up session start. GIT_TERMINAL_PROMPT=0
  # stops git from blocking on an interactive credential prompt instead of
  # failing fast. This only updates remote-tracking refs (origin/main); it
  # never touches the working tree, the checked-out branch, or any local changes.
  (
    export GIT_TERMINAL_PROMPT=0
    run_with_timeout 8 git -C "$CHECKOUT_ROOT" fetch origin "$DEFAULT_BRANCH" --quiet
  ) >/dev/null 2>&1 || exit 0

  REMOTE_JSON_FILE=$(mktemp) || exit 0
  trap 'rm -f "$REMOTE_JSON_FILE"' EXIT
  # cd instead of 'git -C', and MSYS_NO_PATHCONV=1 (harmless no-op outside
  # Git Bash on Windows): the 'ref:path' colon syntax otherwise gets mangled
  # by MSYS's argv path-list conversion (origin/main:file -> origin\main;file).
  (cd "$CHECKOUT_ROOT" && MSYS_NO_PATHCONV=1 git show "origin/${DEFAULT_BRANCH}:.claude-plugin/marketplace.json") \
    > "$REMOTE_JSON_FILE" 2>/dev/null || exit 0
  [ -s "$REMOTE_JSON_FILE" ] || exit 0

  LATEST_VERSION=$($PY - "$REMOTE_JSON_FILE" <<'PYEOF'
import json, sys
try:
    with open(sys.argv[1]) as f:
        data = json.load(f)
    for p in data.get('plugins', []):
        if p.get('name') == 'qa-engineer':
            print(p.get('version', ''))
            break
except Exception:
    print('')
PYEOF
  ) || exit 0
  [ -n "$LATEST_VERSION" ] || exit 0

  mkdir -p "$(dirname "$CACHE_FILE")" 2>/dev/null || true
  $PY - "$CACHE_FILE" "$NOW" "$LOCAL_VERSION" "$LATEST_VERSION" <<'PYEOF' 2>/dev/null || true
import json, sys
cache_path, now, local_version, latest_version = sys.argv[1], sys.argv[2], sys.argv[3], sys.argv[4]
try:
    with open(cache_path, 'w') as f:
        json.dump({"checked_at": int(now), "checked_local_version": local_version, "latest_version": latest_version}, f)
except Exception:
    pass
PYEOF
else
  LATEST_VERSION="$CACHE_RESULT"
fi

[ -n "$LATEST_VERSION" ] || exit 0

# Compare as dotted version tuples ("2.9.0" vs "2.10.0") — not string
# comparison, which would get that pair backwards.
IS_NEWER=$($PY - "$LOCAL_VERSION" "$LATEST_VERSION" <<'PYEOF'
import sys
def parts(v):
    out = []
    for p in v.split('.'):
        try:
            out.append(int(p))
        except ValueError:
            out.append(0)
    return out
a, b = parts(sys.argv[1]), parts(sys.argv[2])
print("yes" if b > a else "no")
PYEOF
) || exit 0

if [ "$IS_NEWER" = "yes" ]; then
  MSG="qa-engineer plugin is outdated (you have v${LOCAL_VERSION}, latest is v${LATEST_VERSION}). Update: run /plugin, update qa-engineer in the marketplace you installed it from, then restart Claude Code."
  ESCAPED_MSG=$(printf '%s' "$MSG" | sed 's/\\/\\\\/g; s/"/\\"/g')
  printf '{"systemMessage":"%s"}\n' "$ESCAPED_MSG"
fi

exit 0
