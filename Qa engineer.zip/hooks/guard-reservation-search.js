#!/usr/bin/env node
/**
 * PreToolUse guard for the Playwright browser tools (the bundled server, playwright-w2, playwright, playwright-headed).
 *
 * A reservation has no field that holds a QA-SEED-… name, so typing one into a reservation search box or filter
 * matches nothing and only sends the run into guessing filters (Test Data Setup, "Search by what the list can
 * search"). When browser_type or browser_fill_form is about to put a QA-SEED- text into an element whose
 * description says both "reservation" and "search" or "filter", the call is denied with the reason, and the agent
 * finds the reservation by its number, its customer or guest, its dates, status or type instead.
 *
 * Only that narrow case is denied: a creation form's reference field, or a customer search for the QA-SEED
 * customer, is left alone. The check reads the element description the agent gives; a call without one passes,
 * so the Test Data Setup rule stays the primary control and this is the backstop.
 *
 * Failure mode: any other tool, and any error reading the payload, passes through untouched (no output, exit 0).
 */
'use strict';

const TOOL_RE = /^mcp__.*playwright.*__browser_(type|fill_form)$/;
const SEED_RE = /QA-SEED-/i;

/** True when the label names a search or filter of reservations. A group reservation is named by its TCs, so its list is left alone. */
function isReservationSearch(label) {
  return /reservation/i.test(label) && /(search|filter)/i.test(label) && !/group/i.test(label);
}

const text = (value) => (typeof value === 'string' ? value : '');

/** The deny payload for a payload that breaks the rule, or null to let the call through. */
function check(payload) {
  const toolName = payload && payload.tool_name;
  const input = payload && payload.tool_input;
  if (typeof toolName !== 'string' || !TOOL_RE.test(toolName) || !input) return null;

  const entries = toolName.endsWith('__browser_fill_form')
    ? (Array.isArray(input.fields) ? input.fields : []).map((f) => ({ label: [f && f.element, f && f.name, f && f.target].map(text).join(' '), value: text(f && f.value) }))
    : [{ label: [input.element, input.target].map(text).join(' '), value: text(input.text) }];

  if (!entries.some((e) => SEED_RE.test(e.value) && isReservationSearch(e.label))) return null;
  return {
    hookSpecificOutput: {
      hookEventName: 'PreToolUse',
      permissionDecision: 'deny',
      permissionDecisionReason:
        'Blocked: a reservation has no name field, so searching or filtering reservations for a QA-SEED- name finds nothing.\n' +
        'Find the reservation by its number, by the customer or guest named QA-SEED-<STORY_KEY>-Customer, or by dates, status or type, ' +
        'and apply only filters the precondition names (Test Data Setup, "Search by what the list can search").',
    },
  };
}

function main() {
  let input = '';
  process.stdin.setEncoding('utf8');
  process.stdin.on('data', (chunk) => { input += chunk; });
  process.stdin.on('end', () => {
    try {
      const deny = check(JSON.parse(input));
      if (deny) process.stdout.write(JSON.stringify(deny) + '\n');
    } catch { /* fail open: not our payload */ }
  });
}

if (require.main === module) main();
module.exports = { isReservationSearch, check };
