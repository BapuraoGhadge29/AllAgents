#!/usr/bin/env bash
set -euo pipefail

# SessionStart hook (matcher: resume) — when a session is resumed with a large
# transcript, tell Claude to offer the user /clear plus the exact resume
# command. /test-ticket streams huge Playwright output into the transcript and
# every turn re-reads it; all pipeline state lives in
# test-output/<EPIC_ID>/run-state.json, so clearing loses nothing.
#
# The reminder only OFFERS /clear — it never clears anything itself. Fail-open
# always: a missing dependency, unreadable input, or any other error exits 0
# with no output and never blocks session start.
#
# Env overrides:
#   QA_ENGINEER_RESUME_REMINDER=off              — disable the reminder
#   QA_ENGINEER_RESUME_REMINDER_MIN_BYTES=<n>    — size threshold (default 2097152)

# Everything is guarded: no failure may escape as a non-zero exit.
trap 'exit 0' ERR

[ "${QA_ENGINEER_RESUME_REMINDER:-}" = "off" ] && exit 0
command -v node >/dev/null 2>&1 || exit 0

HOOK_INPUT=$(cat 2>/dev/null) || HOOK_INPUT=""
[ -n "$HOOK_INPUT" ] || exit 0

# One node process does the JSON parsing, size check, run-state lookup and
# JSON encoding, so user-controlled strings (Windows paths, epic ids) never pass
# through shell quoting or hand-built JSON.
NODE_SCRIPT='
const fs = require("fs");
const path = require("path");
try {
  const input = JSON.parse(process.env.HOOK_INPUT || "");
  const transcript = input && input.transcript_path;
  if (typeof transcript !== "string" || !transcript) process.exit(0);
  const size = fs.statSync(transcript).size;
  const parsed = parseInt(process.env.QA_ENGINEER_RESUME_REMINDER_MIN_BYTES || "", 10);
  const threshold = Number.isFinite(parsed) && parsed >= 0 ? parsed : 2097152;
  if (!(size > threshold)) process.exit(0);

  const safe = (v) => typeof v === "string" && /^[A-Za-z0-9._-]{1,40}$/.test(v) ? v : null;
  const dayMs = 24 * 60 * 60 * 1000;
  const roots = [];
  if (process.env.CLAUDE_PROJECT_DIR) roots.push(path.join(process.env.CLAUDE_PROJECT_DIR, "test-output"));
  roots.push(path.join(process.cwd(), "test-output"));

  let best = null;
  for (const root of roots) {
    let entries = [];
    try { entries = fs.readdirSync(root); } catch (e) { continue; }
    for (const name of entries) {
      try {
        const file = path.join(root, name, "run-state.json");
        const mtime = fs.statSync(file).mtimeMs;
        if (Date.now() - mtime > dayMs) continue;
        if (best && best.mtime >= mtime) continue;
        const state = JSON.parse(fs.readFileSync(file, "utf8"));
        const epic = safe(state.epic);
        const phase = safe(state.phase);
        if (epic && phase) best = { mtime, epic, phase };
      } catch (e) { /* skip unreadable run-state */ }
    }
    if (best) break;
  }

  const mb = (size / 1048576).toFixed(1);
  let text = "This resumed session carries a ~" + mb + " MB transcript, and every turn re-reads it, which makes the session slow and costly. Before doing anything else, offer the user to run /clear first: the /test-ticket pipeline state is on disk in test-output/<EPIC_ID>/run-state.json, so nothing is lost.";
  if (best) {
    text += " After /clear, resume with: /test-ticket " + best.epic + " <URL> --from=" + best.phase + " (the user must re-add their own URL).";
  } else {
    text += " After /clear, the user can resume /test-ticket with their ticket ID, their URL and --from=<phase>.";
  }
  text += " Only offer /clear; do not run it yourself.";
  process.stdout.write(JSON.stringify({ hookSpecificOutput: { hookEventName: "SessionStart", additionalContext: text } }) + "\n");
} catch (e) {
  process.exit(0);
}
'

export HOOK_INPUT
node -e "$NODE_SCRIPT" 2>/dev/null || true

exit 0
