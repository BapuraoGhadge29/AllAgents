#!/usr/bin/env node
/**
 * Diagnoses (and, with --fix, repairs) qa-engineer's PLUGIN-MANAGER
 * registration — the layer above run-playwright.js --doctor.
 *
 * --doctor assumes the plugin already loaded in this session and only checks
 * the Chrome/Node environment underneath it. It has no way to see the two
 * failure modes that stop the plugin from loading correctly in the first
 * place, which is what actually produces "Playwright MCP tools not
 * available" before the server is ever asked to start:
 *
 *   1. Name collision — a second "qa-engineer" plugin from a different
 *      source (most often a claude.ai-account-synced one, reported as
 *      "qa-engineer@synced") is also registered. Claude Code loads only one
 *      by its own precedence rules, so which .mcp.json wins — and therefore
 *      whether Playwright tools register at all — can flip between sessions.
 *   2. Stale cache — the user-scope install predates this launcher (no mcp/
 *      folder at all) or predates a fix inside it, because the local
 *      marketplace clone / plugin cache never picked up a newer version.
 *
 * Usage:
 *   node check-registration.js              — report only
 *   node check-registration.js --fix        — show what --fix WOULD change
 *                                              (disable colliding sources,
 *                                              refresh the install) without
 *                                              doing it — a dry run
 *   node check-registration.js --fix --yes  — actually apply it
 *
 * --fix alone never mutates anything — it requires --yes in the same
 * invocation to run the disable/refresh commands below. This script disables
 * plugins and reinstalls one; that is a state change a human (or an agent
 * acting on a human's behalf) should see and confirm first, not something
 * that should fire just because something else decided to run `--fix`.
 *
 * Every state change shells out to the real `claude` CLI (plugin disable /
 * marketplace update / plugin install — the same commands documented in
 * README.md and plugins/onboarding/skills/setting-up-workspace/SKILL.md).
 * This never hand-edits installed_plugins.json or any other Claude Code
 * internal file — only reads them, using the same path and shape as that
 * onboarding skill's verified probe.
 *
 * Env overrides (tests only — production always uses the real ~/.claude and
 * the real `claude` binary on PATH):
 *   QA_ENGINEER_CLAUDE_HOME   — root to treat as the Claude Code home directory
 *   QA_ENGINEER_FAKE_CLAUDE   — path to a fake-CLI Node script to run instead
 *                               of spawning the real `claude` binary
 */

'use strict';

const fs   = require('fs');
const os   = require('os');
const path = require('path');
const { spawnSync } = require('child_process');

const PLUGIN_NAME      = 'qa-engineer';
// The same repo is offered twice: as a GitHub marketplace, and through the
// claude.ai org library (no local clone). An org install is home when present.
const GITHUB_MARKETPLACE = 'maxxton-marketplace';
const ORG_MARKETPLACE    = 'claudeai-maxxtongroup-claude-marketplace';
const HOME_MARKETPLACE = homeMarketplace();
const HOME_KEY         = PLUGIN_NAME + '@' + HOME_MARKETPLACE;
const FIX              = process.argv.includes('--fix');
const CONFIRMED        = process.argv.includes('--yes');

function out(s) { process.stdout.write((s || '') + '\n'); }

// Override lets the test suite point this at a throwaway fixture directory
// instead of the real ~/.claude — never set in production.
function claudeHome() {
  return process.env.QA_ENGINEER_CLAUDE_HOME || path.join(os.homedir(), '.claude');
}
function ledgerPath()  { return path.join(claudeHome(), 'plugins', 'installed_plugins.json'); }
function cacheDir()    { return path.join(claudeHome(), 'plugins', 'cache', HOME_MARKETPLACE, PLUGIN_NAME); }
function marketplaceCheckout() { return path.join(claudeHome(), 'plugins', 'marketplaces', HOME_MARKETPLACE); }

function readJson(p) {
  try { return JSON.parse(fs.readFileSync(p, 'utf8')); } catch { return null; }
}

function ledgerEntries(key) {
  return readJson(ledgerPath())?.plugins?.[key] ?? [];
}

// User scope only, as checkUserScope(): a repo-scoped org entry must not make
// --fix disable a valid user-scope GitHub install.
function homeMarketplace() {
  const orgEntries = ledgerEntries(PLUGIN_NAME + '@' + ORG_MARKETPLACE);
  return orgEntries.some((i) => i.scope === 'user') ? ORG_MARKETPLACE : GITHUB_MARKETPLACE;
}

// No clone to read for the org marketplace; Claude Code syncs its revision, so
// the installed one is the current one.
function installedOrgRevision() {
  const user = ledgerEntries(HOME_KEY).find((i) => i.scope === 'user');
  return user?.version ? String(user.version) : null;
}

/**
 * Never throws — a missing/unspawnable `claude` binary is reported, not fatal.
 *
 * QA_ENGINEER_FAKE_CLAUDE (tests only — production always spawns the real
 * `claude` binary): path to a Node script to run via this same `node`
 * instead, so the test suite can exercise disableCollisions()/refreshInstall()
 * without touching the developer's actual Claude Code install.
 */
function claudeCli(args) {
  const fake = process.env.QA_ENGINEER_FAKE_CLAUDE;
  const res = fake
    ? spawnSync(process.execPath, [fake].concat(args), { encoding: 'utf8' })
    : spawnSync('claude', args, { encoding: 'utf8' });
  return {
    status: res.status,
    stdout: (res.stdout || '').trim(),
    stderr: (res.stderr || '').trim(),
    error:  res.error,
  };
}

// ---------------------------------------------------------------------------
// 1. Name-collision + scope check, via the same ledger and key shape
//    (`"<plugin>@<marketplace>": [ { scope, ... }, ... ]`) that
//    setting-up-workspace/SKILL.md's step-7 probe reads.
// ---------------------------------------------------------------------------
function readRegistrations() {
  const ledger = readJson(ledgerPath());
  if (!ledger || !ledger.plugins) return { keys: [], plugins: {} };
  const keys = Object.keys(ledger.plugins).filter(
    (k) => k === PLUGIN_NAME || k.startsWith(PLUGIN_NAME + '@'),
  );
  return { keys, plugins: ledger.plugins };
}

function reportRegistrations() {
  out('1. Plugin-manager registration (' + ledgerPath() + ')');
  if (!fs.existsSync(ledgerPath())) {
    out('   ledger not found at this path — Claude Code plugin layout may differ on');
    out('   this install; skipping this check.');
    return { keys: [], plugins: {} };
  }
  const { keys, plugins } = readRegistrations();
  if (!keys.length) {
    out('   no "' + PLUGIN_NAME + '" entry found — plugin was never installed for this user.');
    return { keys, plugins };
  }
  for (const k of keys) {
    const instances = plugins[k] || [];
    const scopes = instances.map((i) => i.scope).filter(Boolean).join(', ') || '(no scope on record)';
    out('   ' + k + '  ->  scope(s): ' + scopes);
  }
  if (keys.length > 1) {
    out('');
    out('   COLLISION: more than one source is registered under the name "' + PLUGIN_NAME + '".');
    out('   Only "' + HOME_KEY + '" ships the bundled Playwright MCP — keep that one only.');
  }
  return { keys, plugins };
}

function checkUserScope(plugins) {
  const instances = (plugins && plugins[HOME_KEY]) || [];
  const hasUser = instances.some((i) => i.scope === 'user');
  out('');
  out('2. User-scope install of ' + HOME_KEY);
  out('   ' + (hasUser ? 'OK — installed at user scope.' : 'MISSING — no user-scope install found.'));
  return hasUser;
}

// ---------------------------------------------------------------------------
// 3. Cached plugin content vs. what the marketplace currently publishes.
// ---------------------------------------------------------------------------
function latestMarketplaceVersion() {
  if (HOME_MARKETPLACE === ORG_MARKETPLACE) return installedOrgRevision();
  const mp = readJson(path.join(marketplaceCheckout(), '.claude-plugin', 'marketplace.json'));
  if (!mp || !Array.isArray(mp.plugins)) return null;
  const entry = mp.plugins.find((p) => p.name === PLUGIN_NAME);
  return entry ? entry.version : null;
}

function reportCache() {
  out('');
  out('3. Cached plugin content (' + cacheDir() + ')');
  let versions = [];
  try {
    versions = fs.readdirSync(cacheDir(), { withFileTypes: true })
      .filter((d) => d.isDirectory())
      .map((d) => d.name);
  } catch { /* not installed, or cache layout differs on this Claude Code version */ }

  if (!versions.length) {
    out('   no cached version found.');
    return { versions: [], latest: null };
  }
  const latest = latestMarketplaceVersion();
  for (const v of versions) {
    const hasScript = fs.existsSync(path.join(cacheDir(), v, 'mcp', 'run-playwright.js'));
    const staleTag = latest && v !== latest ? '  (marketplace currently publishes ' + latest + ')' : '';
    out('   ' + v + ' — mcp/run-playwright.js: ' + (hasScript ? 'present' : 'MISSING') + staleTag);
  }
  return { versions, latest };
}

// ---------------------------------------------------------------------------
// --fix
// ---------------------------------------------------------------------------
function disableCollisions(keys) {
  const bad = keys.filter((k) => k !== HOME_KEY);
  for (const k of bad) {
    out('   disabling ' + k + ' ...');
    const r = claudeCli(['plugin', 'disable', k]);
    if (r.error) { out('   could not run `claude` (' + r.error.code + ') — disable this manually.'); continue; }
    const text = r.stdout + ' ' + r.stderr;
    out('   ' + (text.trim() || (r.status === 0 ? 'done' : 'failed, exit ' + r.status)));
    if (/synced/i.test(k) && /cannot be uninstalled|manage it on claude\.ai/i.test(text)) {
      out('   -> synced from your claude.ai account: local disable is all this script can');
      out('      do. Also remove/disconnect it on claude.ai (Settings -> Plugins) so');
      out('      account-level sync does not re-enable it later.');
    }
  }
}

function refreshInstall() {
  out('   updating marketplace "' + HOME_MARKETPLACE + '" ...');
  let r = claudeCli(['plugin', 'marketplace', 'update', HOME_MARKETPLACE]);
  if (r.error) {
    out('   could not run `claude` (' + r.error.code + ') — is it on PATH?');
    return;
  }
  out('   ' + ((r.stdout + ' ' + r.stderr).trim() || (r.status === 0 ? 'ok' : 'failed, exit ' + r.status)));

  out('   reinstalling ' + HOME_KEY + ' at user scope ...');
  r = claudeCli(['plugin', 'install', HOME_KEY, '--scope', 'user']);
  out('   ' + ((r.stdout + ' ' + r.stderr).trim() || (r.status === 0 ? 'ok' : 'failed, exit ' + r.status)));
}

// ---------------------------------------------------------------------------
// Main
// ---------------------------------------------------------------------------
out(PLUGIN_NAME + ' — plugin-registration report');
out('');
let { keys, plugins } = reportRegistrations();
let hasUserScope = checkUserScope(plugins);
let { versions, latest } = reportCache();

if (FIX) {
  const collisions = keys.length > 1;
  const currentIsFresh = latest
    && versions.includes(latest)
    && fs.existsSync(path.join(cacheDir(), latest, 'mcp', 'run-playwright.js'));
  const needsRefresh = !hasUserScope || !currentIsFresh;

  if (!CONFIRMED) {
    out('');
    out('--fix requested, but nothing has been changed yet (dry run).');
    if (!collisions && !needsRefresh) {
      out('Nothing to do — no collision and the install already looks current.');
    } else {
      out('This would run:');
      if (collisions) {
        for (const k of keys.filter((k) => k !== HOME_KEY)) out('   claude plugin disable ' + k);
      }
      if (needsRefresh) {
        out('   claude plugin marketplace update ' + HOME_MARKETPLACE);
        out('   claude plugin install ' + HOME_KEY + ' --scope user');
      }
      out('');
      out('Re-run with --fix --yes to actually apply it.');
    }
  } else {
    out('');
    out('--fix --yes: applying...');
    if (collisions) disableCollisions(keys);
    if (needsRefresh) refreshInstall();

    out('');
    out('Re-checking...');
    out('');
    ({ keys, plugins } = reportRegistrations());
    hasUserScope = checkUserScope(plugins);
    reportCache();
  }
}

out('');
out('Whatever this reports, MCP tool lists are built once at session start.');
out('Fully quit and reopen Claude Code (a window reload is not enough) before');
out('retrying ' + PLUGIN_NAME + "'s tools.");
if (!FIX) {
  out('');
  out('Re-run with --fix to see what a fix would change (dry run), or --fix --yes');
  out('to apply it — disabling colliding sources and refreshing the install.');
  out('Nothing here is ever deleted from disk by this script — every change goes');
  out('through the `claude` CLI itself.');
}
