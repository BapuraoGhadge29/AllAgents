#!/usr/bin/env node
/**
 * Tests for mcp/check-registration.js.
 *
 * Run:  node plugins/qa-engineer/mcp/tests/check-registration.test.js
 *
 * All fixtures point QA_ENGINEER_CLAUDE_HOME at a throwaway temp directory
 * built to look like ~/.claude/plugins/*, so this never touches the real
 * installed_plugins.json / marketplace clone / plugin cache on the machine
 * running the suite.
 */

'use strict';

const assert = require('assert');
const fs     = require('fs');
const os     = require('os');
const path   = require('path');
const { spawnSync } = require('child_process');

const SCRIPT  = path.join(__dirname, '..', 'check-registration.js');
const results = [];

function test(name, fn) {
  try {
    fn();
    results.push(['PASS', name]);
  } catch (err) {
    results.push(['FAIL', name, err.message]);
  }
}

function fixtureHome(label) {
  const home = fs.mkdtempSync(path.join(os.tmpdir(), 'qa-reg-' + label + '-'));
  fs.mkdirSync(path.join(home, 'plugins'), { recursive: true });
  return home;
}

function writeLedger(home, plugins) {
  fs.writeFileSync(
    path.join(home, 'plugins', 'installed_plugins.json'),
    JSON.stringify({ plugins }, null, 2),
  );
}

function writeCachedVersion(home, version, withScript) {
  const dir = path.join(home, 'plugins', 'cache', 'maxxton-marketplace', 'qa-engineer', version);
  fs.mkdirSync(dir, { recursive: true });
  if (withScript) {
    fs.mkdirSync(path.join(dir, 'mcp'), { recursive: true });
    fs.writeFileSync(path.join(dir, 'mcp', 'run-playwright.js'), '// fixture\n');
  }
}

function writeMarketplaceVersion(home, version) {
  const dir = path.join(home, 'plugins', 'marketplaces', 'maxxton-marketplace', '.claude-plugin');
  fs.mkdirSync(dir, { recursive: true });
  fs.writeFileSync(
    path.join(dir, 'marketplace.json'),
    JSON.stringify({ plugins: [{ name: 'qa-engineer', version }] }, null, 2),
  );
}

const FAKE_CLAUDE = path.join(__dirname, 'fixtures', 'fake-claude.js');

function run(home, args, extraEnv) {
  return spawnSync(process.execPath, [SCRIPT].concat(args || []), {
    encoding: 'utf8',
    timeout: 30000,
    env: Object.assign({}, process.env, { QA_ENGINEER_CLAUDE_HOME: home }, extraEnv || {}),
  });
}

// --------------------------------------------------------------------------

test('no ledger at all is reported, not thrown', () => {
  const home = fixtureHome('empty');
  const res  = run(home);
  assert.strictEqual(res.status, 0, 'stderr: ' + res.stderr);
  assert.match(res.stdout, /ledger not found/);
});

test('single healthy user-scope install with a fresh cache reports OK, no collision', () => {
  const home = fixtureHome('healthy');
  writeLedger(home, { 'qa-engineer@maxxton-marketplace': [{ scope: 'user' }] });
  writeCachedVersion(home, '2.11.10', true);
  writeMarketplaceVersion(home, '2.11.10');

  const res = run(home);
  assert.strictEqual(res.status, 0, 'stderr: ' + res.stderr);
  assert.match(res.stdout, /qa-engineer@maxxton-marketplace\s+->\s+scope\(s\): user/);
  assert.doesNotMatch(res.stdout, /COLLISION/);
  assert.match(res.stdout, /OK — installed at user scope/);
  assert.match(res.stdout, /2\.11\.10 — mcp\/run-playwright\.js: present/);
});

test('a second same-name source is flagged as a collision', () => {
  const home = fixtureHome('collision');
  writeLedger(home, {
    'qa-engineer@maxxton-marketplace': [{ scope: 'user' }],
    'qa-engineer@synced':              [{ scope: 'user' }],
  });
  writeCachedVersion(home, '2.11.10', true);
  writeMarketplaceVersion(home, '2.11.10');

  const res = run(home);
  assert.strictEqual(res.status, 0, 'stderr: ' + res.stderr);
  assert.match(res.stdout, /COLLISION/);
  assert.match(res.stdout, /qa-engineer@synced/);
});

test('a cached version missing mcp/run-playwright.js is flagged as stale', () => {
  const home = fixtureHome('stale');
  writeLedger(home, { 'qa-engineer@maxxton-marketplace': [{ scope: 'user' }] });
  writeCachedVersion(home, '2.10.4', false);
  writeMarketplaceVersion(home, '2.11.10');

  const res = run(home);
  assert.strictEqual(res.status, 0, 'stderr: ' + res.stderr);
  assert.match(res.stdout, /2\.10\.4 — mcp\/run-playwright\.js: MISSING\s+\(marketplace currently publishes 2\.11\.10\)/);
});

test('project-only scope (no user-scope instance) is flagged as MISSING', () => {
  const home = fixtureHome('project-scope');
  writeLedger(home, { 'qa-engineer@maxxton-marketplace': [{ scope: 'project' }] });
  writeCachedVersion(home, '2.11.10', true);
  writeMarketplaceVersion(home, '2.11.10');

  const res = run(home);
  assert.strictEqual(res.status, 0, 'stderr: ' + res.stderr);
  assert.match(res.stdout, /MISSING — no user-scope install found/);
});

test('--fix never touches disk directly — no cache file is deleted or created by the script itself', () => {
  const home = fixtureHome('fix-noop-disk');
  writeLedger(home, { 'qa-engineer@maxxton-marketplace': [{ scope: 'user' }] });
  writeCachedVersion(home, '2.11.10', true);
  writeMarketplaceVersion(home, '2.11.10');
  const before = fs.readdirSync(path.join(home, 'plugins', 'cache', 'maxxton-marketplace', 'qa-engineer'));

  // No real `claude` state change expected here (already healthy), but this
  // also documents that --fix's own code path never calls fs.rmSync/writeFileSync
  // against the cache — only claudeCli() (spawnSync('claude', ...)) does anything.
  const res = run(home, ['--fix']);
  assert.strictEqual(res.status, 0, 'stderr: ' + res.stderr);
  const after = fs.readdirSync(path.join(home, 'plugins', 'cache', 'maxxton-marketplace', 'qa-engineer'));
  assert.deepStrictEqual(after, before);
});

test('--fix without --yes is a dry run — plans the collision disable but never calls claudeCli', () => {
  const home = fixtureHome('fix-dry-run-collision');
  writeLedger(home, {
    'qa-engineer@maxxton-marketplace': [{ scope: 'user' }],
    'qa-engineer@synced':              [{ scope: 'user' }],
  });
  writeCachedVersion(home, '2.11.10', true);
  writeMarketplaceVersion(home, '2.11.10');

  const res = run(home, ['--fix']);
  assert.strictEqual(res.status, 0, 'stderr: ' + res.stderr);
  assert.match(res.stdout, /dry run/);
  assert.match(res.stdout, /claude plugin disable qa-engineer@synced/);
  assert.match(res.stdout, /Re-run with --fix --yes to actually apply it/);
  // Dry run must not reach disableCollisions()'s "disabling ..." execution line.
  assert.doesNotMatch(res.stdout, /disabling qa-engineer@synced \.\.\./);
});

test('--fix --yes actually attempts the disable (reaches claudeCli, not just the plan)', () => {
  const home = fixtureHome('fix-yes-collision');
  writeLedger(home, {
    'qa-engineer@maxxton-marketplace': [{ scope: 'user' }],
    'qa-engineer@synced':              [{ scope: 'user' }],
  });
  writeCachedVersion(home, '2.11.10', true);
  writeMarketplaceVersion(home, '2.11.10');

  // QA_ENGINEER_FAKE_CLAUDE swaps in fixtures/fake-claude.js for the real
  // `claude` binary — without it, this would actually run `claude plugin
  // disable` against whatever Claude Code install is on this machine's PATH.
  const res = run(home, ['--fix', '--yes'], { QA_ENGINEER_FAKE_CLAUDE: FAKE_CLAUDE });
  assert.strictEqual(res.status, 0, 'stderr: ' + res.stderr);
  assert.match(res.stdout, /applying/);
  assert.match(res.stdout, /disabling qa-engineer@synced \.\.\./);
  // The fake CLI's own echoed output proves claudeCli() actually invoked it
  // with the expected subcommand, not just that the "disabling ..." log line
  // printed before a swallowed spawn error.
  assert.match(res.stdout, /fake-claude: plugin disable qa-engineer@synced/);
});

// The claude.ai org library registers the same repo as its own marketplace,
// with no clone: installed_plugins.json records the revision it installed.
const ORG_KEY = 'qa-engineer@claudeai-maxxtongroup-claude-marketplace';

function writeOrgInstall(home, revision) {
  const dir = path.join(home, 'plugins', 'cache', 'claudeai-maxxtongroup-claude-marketplace', 'qa-engineer', revision);
  fs.mkdirSync(path.join(dir, 'mcp'), { recursive: true });
  fs.writeFileSync(path.join(dir, 'mcp', 'run-playwright.js'), '// fixture\n');
  return { scope: 'user', installPath: dir, version: revision };
}

test('an org-marketplace install alone is healthy, not a collision', () => {
  const home = fixtureHome('org-only');
  writeLedger(home, { [ORG_KEY]: [writeOrgInstall(home, '0012')] });

  const res = run(home, ['--fix']);
  assert.strictEqual(res.status, 0, 'stderr: ' + res.stderr);
  assert.doesNotMatch(res.stdout, /COLLISION/);
  assert.match(res.stdout, /OK — installed at user scope/);
  assert.match(res.stdout, /0012 — mcp\/run-playwright\.js: present/);
  assert.match(res.stdout, /Nothing to do/);
});

test('--fix with both marketplaces keeps the org install and disables the GitHub one', () => {
  const home = fixtureHome('org-and-github');
  writeLedger(home, {
    'qa-engineer@maxxton-marketplace': [{ scope: 'user' }],
    [ORG_KEY]:                         [writeOrgInstall(home, '0012')],
  });
  writeCachedVersion(home, '2.11.10', true);
  writeMarketplaceVersion(home, '2.11.10');

  const res = run(home, ['--fix']);
  assert.strictEqual(res.status, 0, 'stderr: ' + res.stderr);
  assert.match(res.stdout, /claude plugin disable qa-engineer@maxxton-marketplace/);
  assert.doesNotMatch(res.stdout, /claude plugin disable qa-engineer@claudeai/);
});

test('a project-scoped org entry does not displace a user-scope GitHub install', () => {
  const home = fixtureHome('org-project-scope');
  writeLedger(home, {
    'qa-engineer@maxxton-marketplace': [{ scope: 'user' }],
    [ORG_KEY]:                         [Object.assign(writeOrgInstall(home, '0012'), { scope: 'project' })],
  });
  writeCachedVersion(home, '2.11.10', true);
  writeMarketplaceVersion(home, '2.11.10');

  const res = run(home, ['--fix']);
  assert.strictEqual(res.status, 0, 'stderr: ' + res.stderr);
  assert.match(res.stdout, /User-scope install of qa-engineer@maxxton-marketplace/);
  assert.doesNotMatch(res.stdout, /claude plugin disable qa-engineer@maxxton-marketplace/);
});

// --------------------------------------------------------------------------

const failed = results.filter(([status]) => status === 'FAIL');
for (const [status, name, message] of results) {
  process.stdout.write(status + '  ' + name + (message ? '\n     ' + message : '') + '\n');
}
process.stdout.write('\n' + (results.length - failed.length) + '/' + results.length + ' passed\n');
process.exit(failed.length ? 1 : 0);
