#!/usr/bin/env node
/**
 * Tests for mcp/run-playwright.js.
 *
 * Run:  node plugins/qa-engineer/mcp/tests/run-playwright.test.js
 *
 * Covers the properties that broke in production and would break silently again:
 *   - the launcher is spawnable with `node` alone (no bash, no npx on PATH)
 *   - stdout carries nothing but MCP JSON-RPC (a stray log line kills the server)
 *   - the profile directory is per-repo, so two repos cannot contend for one lock
 *   - a stale lock file is cleared rather than blocking the launch
 *   - --doctor reports a missing dependency as a BLOCKER and exits non-zero
 *
 * The MCP handshake test needs the server package reachable (a local --install or
 * a warm npx cache). It is skipped, not failed, when neither is available, so the
 * suite still runs offline.
 */

'use strict';

const assert = require('assert');
const fs     = require('fs');
const os     = require('os');
const path   = require('path');
const { spawnSync, spawn } = require('child_process');

const LAUNCHER = path.join(__dirname, '..', 'run-playwright.js');
const results  = [];

function test(name, fn) {
  try {
    fn();
    results.push(['PASS', name]);
  } catch (err) {
    results.push(['FAIL', name, err.message]);
  }
}

function tmpdir(label) {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'qa-pw-' + label + '-'));
  return dir;
}

/** Run the launcher in a non-serve mode and capture its output. */
function runMode(args, opts) {
  return spawnSync(process.execPath, [LAUNCHER].concat(args), Object.assign({
    encoding: 'utf8',
    timeout: 60000,
  }, opts));
}

// --------------------------------------------------------------------------

test('--doctor exits 0 and reports the required facts on a healthy machine', () => {
  // Force Chrome resolution to succeed via the documented override, rather than
  // relying on the machine this happens to run on actually having Chrome
  // installed — a CI runner or a contributor's dev box may not. Any existing
  // executable proves the override path is honoured; process.execPath always
  // exists. This keeps the test deterministic instead of environment-dependent.
  const res = runMode(['--doctor'], {
    env: Object.assign({}, process.env, { QA_ENGINEER_PLAYWRIGHT_CHROME_PATH: process.execPath }),
  });
  assert.strictEqual(res.status, 0, 'expected exit 0, got ' + res.status + '\n' + res.stdout + res.stderr);
  for (const key of ['profile dir', 'google chrome', 'output dir', 'server package']) {
    assert.ok(res.stdout.includes(key), 'doctor output missing "' + key + '"');
  }
});

test('--doctor flags an unreachable Chrome as a BLOCKER and exits non-zero', () => {
  // Drive this through the documented override rather than by rewriting
  // PROGRAMFILES/LOCALAPPDATA: Windows env lookups are case-insensitive, so an
  // added upper-case key does not reliably shadow the existing mixed-case one.
  const res = runMode(['--doctor'], {
    env: Object.assign({}, process.env, {
      QA_ENGINEER_PLAYWRIGHT_CHROME_PATH: path.join(tmpdir('nochrome'), 'chrome-does-not-exist'),
    }),
  });
  assert.strictEqual(res.status, 1, 'expected exit 1 when Chrome is unreachable');
  assert.ok(res.stdout.includes('BLOCKERS'), 'expected a BLOCKERS section');
  assert.ok(/google chrome\s+NOT FOUND/.test(res.stdout), 'expected Chrome reported NOT FOUND');
});

test('QA_ENGINEER_PLAYWRIGHT_CHROME_PATH is accepted when it points at a real file', () => {
  // Any existing executable proves the override path is honoured; the launcher
  // only checks existence and hands it to the server as --executable-path.
  const res = runMode(['--doctor'], {
    env: Object.assign({}, process.env, { QA_ENGINEER_PLAYWRIGHT_CHROME_PATH: process.execPath }),
  });
  assert.strictEqual(res.status, 0, 'override with a real file should not block');
  assert.ok(res.stdout.includes(process.execPath), 'override path missing from the report');
});

test('serverArgs wires --storage-state into the isolated launch, and never kills a holder', () => {
  // The branch that actually launches isolated with a real lock holder needs a
  // second real browser process, which (like the live-session isolate branch
  // below) is covered by the manual e2e harness, not this offline suite. This
  // checks the wiring at the source level instead: the isolated arg list must
  // conditionally add --storage-state=<path>, and reclaimProfile must contain no
  // process.kill call at all — the whole point of this change.
  const src = fs.readFileSync(LAUNCHER, 'utf8');
  assert.ok(/\['--isolated'\]\.concat\(fs\.existsSync\(stateFile\) \? \['--storage-state=' \+ stateFile\]/.test(src),
    'isolated launch no longer conditionally attaches --storage-state=<path>');
  const reclaimSrc = src.slice(src.indexOf('function reclaimProfile'), src.indexOf('function serverArgs'));
  assert.ok(!/process\.kill/.test(reclaimSrc),
    'reclaimProfile still kills a process — it must never kill a lock holder, orphaned or not');
});

test('--doctor only blocks on npx when the shell fallback also fails, not just npx-cli.js', () => {
  // serve() has three ways to reach the server: a local install, node+npx-cli.js,
  // and (last resort) shell-invoked npx. --doctor's blocker check used to only look
  // at the first two, so a machine where local install and npx-cli.js are both
  // absent but shell npx genuinely works (a relocated npm, nvm, etc.) was reported
  // as blocked even though serve() would have started fine via the third path.
  // Can't fake "npx-cli.js absent" without relocating this machine's real node
  // install, so this checks the fix at the source level instead: the blocker
  // condition must gate on shell-npx too, and the check that decides that must
  // itself use a shell (mirroring how serve()'s own npx fallback needs one on
  // Windows, where npx is npx.cmd).
  const src = fs.readFileSync(LAUNCHER, 'utf8');
  assert.ok(/if \(!localCli && !npxCli && !npxShellWorks\)/.test(src),
    'blocker condition no longer checks the shell-npx fallback before reporting blocked');
  assert.ok(/spawnSync\(cmd \+ ' --version', \{[^}]*shell:\s*true/.test(src),
    'the npx spawnability probe no longer runs through a shell');
});

if (process.platform === 'win32') {
  test('a spawnable-but-failing npx is not reported as working (Windows only)', () => {
    // Under shell:true, a command that doesn't (fully) work still *spawns* fine --
    // the shell itself starts, then the command inside it fails -- so it comes back
    // as a non-zero exit with no r.error at all. Checking only r.error therefore
    // reports "yes" for a command that plainly does not work. Proven directly (not
    // just by reading the source) with a fake npx.cmd on PATH that spawns and exits
    // 1, mimicking e.g. an npx that resolves but can't reach the registry.
    const fakeDir = tmpdir('fake-npx');
    fs.writeFileSync(path.join(fakeDir, 'npx.cmd'), '@echo off\r\nexit /b 1\r\n');
    const res = runMode(['--doctor'], {
      env: Object.assign({}, process.env, {
        PATH: fakeDir + path.delimiter + process.env.PATH,
        QA_ENGINEER_PLAYWRIGHT_CHROME_PATH: process.execPath,
      }),
    });
    assert.ok(/spawnable: npx\s+no/.test(res.stdout),
      'a failing npx.cmd (spawns, exits 1) was reported spawnable:\n' + res.stdout);
  });
}

test('profile directory is per-repo — two cwds never share one lock', () => {
  const a = tmpdir('repo-a');
  const b = tmpdir('repo-b');
  const readProfile = (cwd) => {
    const out = runMode(['--doctor'], { cwd }).stdout;
    const m = out.match(/profile dir\s+(.+)/);
    assert.ok(m, 'no profile dir line for ' + cwd);
    return m[1].trim();
  };
  assert.notStrictEqual(readProfile(a), readProfile(b), 'two repos resolved to the same profile');
  assert.strictEqual(readProfile(a), readProfile(a), 'profile is not stable for one repo');
});

if (process.platform === 'win32') {
  test('profile directory is stable across drive-letter case (Windows only)', () => {
    // Caught live: process.cwd() returned "D:\..." on one run and "d:\..." on the
    // next, for the identical directory — the same repo, same disk location. An
    // un-normalized hash would mint a fresh (logged-out) profile every time the
    // case happens to drift, silently defeating the whole point of a stable
    // per-repo profile. Windows paths are case-insensitive on disk; the hash must
    // treat them that way too.
    const dir = tmpdir('CaseTest');
    // Compare only the trailing hash, not the full path: the human-readable slug
    // (the directory's basename) is deliberately left un-normalized for readability
    // and legitimately varies with input case, but on a case-insensitive filesystem
    // "CaseTest-...-<hash>" and "casetest-...-<hash>" are the same directory on
    // disk regardless — it's the hash that has to agree for the profile to be
    // the same one Chrome actually opens.
    const readHash = (cwd) => {
      const out = runMode(['--doctor'], { cwd }).stdout;
      const m = out.match(/profile dir\s+.*-([0-9a-f]{8})\s*$/m);
      assert.ok(m, 'no profile dir hash found for ' + cwd + '\n' + out);
      return m[1];
    };
    assert.strictEqual(readHash(dir), readHash(dir.toLowerCase()),
      'same directory hashed differently by drive-letter case alone');
    assert.strictEqual(readHash(dir), readHash(dir.toUpperCase()),
      'same directory hashed differently by full-path case');
  });

  test('the case-fix is not hardcoded to whatever drive letter os.tmpdir() happens to use', () => {
    // The test above only ever exercises the one drive os.tmpdir() resolves to on
    // this machine. A fix that special-cased that letter (or "D" specifically, since
    // that's the letter the bug was first caught on) would pass it and still be
    // wrong for anyone else. Node refuses to spawn with a `cwd` that doesn't exist,
    // so a genuinely different, possibly-absent drive letter (E:, F:, Z:, ...) can't
    // be exercised through a real spawn — this reproduces profileDir()'s exact
    // normalization (read back from the source, not retyped, so it can't silently
    // drift from the real implementation) against synthetic paths on four different
    // letters instead.
    const src = fs.readFileSync(LAUNCHER, 'utf8');
    const m = src.match(/const hashOf = process\.platform === 'win32' \? cwd\.(\w+)\(\) : cwd;/);
    assert.ok(m, 'profileDir()\'s win32 normalization call not found in source — did it move or change shape?');
    const normalize = (s) => s[m[1]]();  // e.g. cwd.toLowerCase()

    const hash = (cwd) => require('crypto').createHash('sha256').update(normalize(cwd)).digest('hex').slice(0, 8);
    for (const letter of ['D', 'E', 'F', 'Z']) {
      const base = letter + ':\\Playwright\\claude-marketplace';
      const variants = [base, base.toLowerCase(), letter + ':\\PLAYWRIGHT\\CLAUDE-MARKETPLACE'];
      const hashes = variants.map(hash);
      assert.ok(hashes.every((h) => h === hashes[0]),
        'drive ' + letter + ': case variants hashed differently: ' + hashes.join(', '));
    }
    assert.notStrictEqual(hash('D:\\Playwright\\claude-marketplace'), hash('E:\\Playwright\\claude-marketplace'),
      'two genuinely different drives collided onto the same hash');
  });
}

test('QA_ENGINEER_PLAYWRIGHT_PROFILE_DIR / _OUTPUT_DIR override the defaults', () => {
  const profile = tmpdir('profile');
  const output  = tmpdir('output');
  const out = runMode(['--doctor'], {
    env: Object.assign({}, process.env, {
      QA_ENGINEER_PLAYWRIGHT_PROFILE_DIR: profile,
      QA_ENGINEER_PLAYWRIGHT_OUTPUT_DIR: output,
    }),
  }).stdout;
  assert.ok(out.includes(profile), 'profile override ignored');
  assert.ok(out.includes(output), 'output override ignored');
});

test('--storage-state-path prints a path inside this repo\'s OUTPUT dir, not the profile dir', () => {
  // Confirmed the hard way (2026-09-17): browser_storage_state is sandboxed by
  // @playwright/mcp to only write inside the server's own allowed roots (cwd and
  // --output-dir) — a path inside the Chrome profile dir is outside those roots and
  // the save fails with "File access denied ... outside allowed roots". This test
  // pins the fix: the path must resolve inside output, never inside profile.
  const profile = tmpdir('state-path-profile');
  const output  = tmpdir('state-path-output');
  const out = runMode(['--storage-state-path'], {
    env: Object.assign({}, process.env, {
      QA_ENGINEER_PLAYWRIGHT_PROFILE_DIR: profile,
      QA_ENGINEER_PLAYWRIGHT_OUTPUT_DIR: output,
    }),
  }).stdout.trim();
  assert.strictEqual(out, path.join(output, 'storage-state.json'),
    '--storage-state-path did not resolve inside the output dir (the only writable allowed root)');
  assert.ok(!out.startsWith(profile), '--storage-state-path resolved inside the profile dir again — this was the bug');
});

test('doctor reports "saved login" as absent when no storage-state.json exists yet', () => {
  const output = tmpdir('no-state');
  const out = runMode(['--doctor'], {
    env: Object.assign({}, process.env, { QA_ENGINEER_PLAYWRIGHT_OUTPUT_DIR: output }),
  }).stdout;
  assert.ok(/saved login\s+no /.test(out), 'expected "saved login" to report absent:\n' + out);
});

test('doctor reports "saved login" as present once storage-state.json exists', () => {
  const output = tmpdir('has-state');
  fs.mkdirSync(output, { recursive: true });
  fs.writeFileSync(path.join(output, 'storage-state.json'), '{}');
  const out = runMode(['--doctor'], {
    env: Object.assign({}, process.env, { QA_ENGINEER_PLAYWRIGHT_OUTPUT_DIR: output }),
  }).stdout;
  assert.ok(/saved login\s+yes/.test(out), 'expected "saved login" to report present:\n' + out);
});

test('a stale lock file is reported as unlocked, not as a blocked profile', () => {
  const profile = tmpdir('stale');
  // A crashed Chrome leaves this behind. On Windows the OS has already released
  // the handle, so it must not read as locked; on POSIX a symlink to a dead pid
  // must not either.
  if (process.platform === 'win32') {
    fs.writeFileSync(path.join(profile, 'lockfile'), '');
  } else {
    fs.symlinkSync('somehost-2147483646', path.join(profile, 'SingletonLock'));
  }
  const out = runMode(['--doctor'], {
    env: Object.assign({}, process.env, { QA_ENGINEER_PLAYWRIGHT_PROFILE_DIR: profile }),
  }).stdout;
  assert.ok(/profile locked\s+no/.test(out), 'stale lock reported as locked:\n' + out);
  assert.ok(/lock holders\s+none/.test(out), 'stale lock attributed to a live process');
});

// --------------------------------------------------------------------------
// Serve mode: the launcher must speak MCP over stdout and nothing else, and must
// still start when the shared profile cannot be freed.
// --------------------------------------------------------------------------

/**
 * A profile that reads as locked but has no findable owner.
 *
 * Windows: a read-only `lockfile` makes playwright's own check (openSync r+) throw
 * EACCES — not ENOENT — which is exactly how it reports "locked". (A directory
 * would not work: openSync on one succeeds on Windows.)
 * POSIX: a SingletonLock symlink naming this very process, which is alive.
 *
 * Returns null if the platform will not hold the simulation, so the test can skip
 * rather than fail on a harness limitation.
 */
function unfreeableProfile() {
  const dir  = tmpdir('wedged');
  const lock = path.join(dir, process.platform === 'win32' ? 'lockfile' : 'SingletonLock');
  if (process.platform === 'win32') {
    fs.writeFileSync(lock, '');
    fs.chmodSync(lock, 0o444);   // sets the Windows read-only attribute
    try { fs.closeSync(fs.openSync(lock, 'r+')); return null; } catch { /* locked, as intended */ }
  } else {
    fs.symlinkSync('somehost-' + process.pid, lock);
  }
  return dir;
}

function serveIsolatedFallback(done) {
  const profile = unfreeableProfile();
  if (!profile) return done(null);
  const child = spawn(process.execPath, [LAUNCHER], {
    cwd: tmpdir('serve-iso'),
    stdio: ['pipe', 'pipe', 'pipe'],
    env: Object.assign({}, process.env, { QA_ENGINEER_PLAYWRIGHT_PROFILE_DIR: profile }),
  });
  let stderr = '';
  child.stderr.on('data', (d) => { stderr += d; });
  setTimeout(() => {
    try { child.kill(); } catch { /* already gone */ }
    done(stderr);
  }, 8000);
}

function serveHandshake(done) {
  const cwd   = tmpdir('serve');
  const child = spawn(process.execPath, [LAUNCHER], { cwd, stdio: ['pipe', 'pipe', 'pipe'] });
  let stdout = '';
  let stderr = '';
  child.stdout.on('data', (d) => { stdout += d; });
  child.stderr.on('data', (d) => { stderr += d; });
  child.stdin.write(JSON.stringify({
    jsonrpc: '2.0', id: 1, method: 'initialize',
    params: { protocolVersion: '2024-11-05', capabilities: {}, clientInfo: { name: 'test', version: '1' } },
  }) + '\n');
  setTimeout(() => {
    child.stdin.write(JSON.stringify({ jsonrpc: '2.0', id: 2, method: 'tools/list', params: {} }) + '\n');
  }, 4000);
  setTimeout(() => {
    try { child.kill(); } catch { /* already gone */ }
    done({ stdout, stderr });
  }, 20000);
}

/** Start the launcher with flags and return what it logged before the server took over stderr. */
function serveFlags(args, done) {
  const child = spawn(process.execPath, [LAUNCHER].concat(args), {
    cwd: tmpdir('serve-flags'),
    stdio: ['pipe', 'pipe', 'pipe'],
    env: Object.assign({}, process.env, { QA_ENGINEER_PLAYWRIGHT_PROFILE_DIR: tmpdir('flags-profile') }),
  });
  let stderr = '';
  child.stderr.on('data', (d) => { stderr += d; });
  setTimeout(() => {
    try { child.kill(); } catch { /* already gone */ }
    done(stderr);
  }, 4000);
}

function report() {
  let failed = 0;
  for (const [status, name, msg] of results) {
    process.stdout.write(status + '  ' + name + (msg ? '\n      ' + msg : '') + '\n');
    if (status === 'FAIL') failed++;
  }
  process.stdout.write('\n' + results.length + ' test(s), ' + failed + ' failed\n');
  process.exit(failed ? 1 : 0);
}

serveHandshake(({ stdout, stderr }) => {
  test('serve mode writes only JSON-RPC to stdout (diagnostics go to stderr)', () => {
    assert.ok(stderr.includes('[qa-engineer/playwright]'), 'launcher diagnostics missing from stderr');
    for (const line of stdout.split('\n').filter(Boolean)) {
      JSON.parse(line); // throws if anything non-JSON reached stdout
    }
  });

  test('serve mode completes an MCP handshake and registers browser tools', () => {
    const msgs = stdout.split('\n').filter(Boolean).map((l) => JSON.parse(l));
    const init  = msgs.find((m) => m.id === 1);
    const tools = msgs.find((m) => m.id === 2);
    if (!init) {
      // No local install and no warm npx cache — nothing to test against.
      results.push(['SKIP', 'MCP handshake (server package unreachable offline)']);
      return;
    }
    assert.ok(init.result && init.result.serverInfo, 'initialize returned no serverInfo');
    assert.ok(tools && tools.result.tools.length > 0, 'tools/list returned no tools');
    assert.ok(tools.result.tools.some((t) => t.name === 'browser_snapshot'),
      'browser_snapshot not registered');
    // browser_storage_state lives behind @playwright/mcp's opt-in "storage" capability
    // group — confirmed against the installed package's own README that this tool (and
    // browser_set_storage_state) is NOT a core/default tool, unlike browser_snapshot
    // above. serverArgs() must pass --caps=storage or the login-saving step this launcher
    // exists to support silently has no tool to call, despite being in allowed-tools.
    assert.ok(tools.result.tools.some((t) => t.name === 'browser_storage_state'),
      'browser_storage_state not registered — serverArgs() must be missing --caps=storage');
  });

  serveIsolatedFallback((stderr) => {
    if (stderr === null) {
      results.push(['SKIP', 'ownerless lock (platform will not hold a fake lock)']);
    } else {
      // An ownerless lock is cleared and the real profile is kept, so the user's
      // login survives. The other branch — a lock a *live* session holds, which
      // must not be cleared and sends this server to --isolated instead — needs two
      // concurrent servers and a real browser, so it is covered by the manual e2e
      // harness rather than here.
      test('a locked profile with no owner is cleared, not treated as blocked', () => {
        assert.ok(/lock:\s+stale lock cleared/.test(stderr),
          'expected the ownerless lock to be cleared, got:\n' + stderr);
        assert.ok(!/starting isolated/.test(stderr),
          'should not fall back to isolated when the lock could be cleared:\n' + stderr);
      });
    }

    serveFlags(['--isolated'], (isolatedErr) => {
      serveFlags(['--headless'], (headlessErr) => {
        test('--isolated serves an in-memory browser and skips the shared-profile lock handling', () => {
          assert.ok(/profile:\s+isolated \(in-memory\) — forced by --isolated/.test(isolatedErr),
            'expected a forced isolated launch, got:\n' + isolatedErr);
          assert.ok(/lock:\s+skipped \(--isolated\)/.test(isolatedErr),
            'reclaimProfile must not run for a forced isolated server:\n' + isolatedErr);
          assert.ok(/browser:\s+headed/.test(isolatedErr),
            'headed must stay the default when --headless is not passed:\n' + isolatedErr);
        });

        test('--headless switches the browser mode without isolating it', () => {
          assert.ok(/browser:\s+headless/.test(headlessErr), 'expected a headless launch, got:\n' + headlessErr);
          assert.ok(!/forced by --isolated/.test(headlessErr), '--headless alone must not isolate:\n' + headlessErr);
        });

        test('serverArgs adds --headless once, even when EXTRA_ARGS already carries it', () => {
          const src = fs.readFileSync(LAUNCHER, 'utf8');
          assert.ok(/HEADLESS && !extraArgs\.includes\('--headless'\)/.test(src),
            'serverArgs no longer guards against a duplicate --headless');
        });

        report();
      });
    });
  });
});
