#!/usr/bin/env node
/**
 * Stand-in for the real `claude` binary, used only via check-registration.js's
 * QA_ENGINEER_FAKE_CLAUDE test override — see that file's claudeCli(). Echoes
 * the subcommand it was invoked with and exits 0, so tests can assert that
 * check-registration.js actually reached the point of shelling out, without
 * ever touching the developer's real Claude Code install.
 */
'use strict';

const args = process.argv.slice(2);
process.stdout.write('fake-claude: ' + args.join(' ') + '\n');
process.exit(0);
