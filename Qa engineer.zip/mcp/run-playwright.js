#!/usr/bin/env node
/**
 * Shell-free launcher for the bundled Playwright MCP server.
 *
 * WHY THIS EXISTS
 * ---------------
 * Claude Code spawns MCP servers *directly* — no shell. The previous config was
 *
 *   { "command": "bash", "args": ["-c", "exec npx -y @playwright/mcp@latest ..."] }
 *
 * which needs `bash` to be a resolvable executable on PATH. On Windows it usually
 * is not: Git for Windows puts `Git\cmd` on PATH (git.exe), not `Git\bin`
 * (bash.exe). `spawn("bash")` then fails with ENOENT before the server ever
 * starts, so zero `mcp__plugin_qa-engineer_playwright__*` tools get registered and
 * every TC ends up BLOCKED with "Playwright MCP tools not available". `spawn("npx")`
 * fails the same way (npx is `npx.cmd` on Windows, unusable without a shell), and
 * `$HOME` is not set in a plain Windows environment either.
 *
 * `node` is the one command that is always spawnable on every platform the plugin
 * supports — the plugin already requires it for every script under
 * skills/test-ticket/scripts/. So `.mcp.json` runs this file with `node`, and
 * everything the old bash one-liner did is done here in portable JavaScript.
 *
 * WHAT IT DOES BEYOND JUST STARTING THE SERVER
 * --------------------------------------------
 * 1. Per-repo persistent Chrome profile under the plugin's own data dir, keyed by
 *    cwd. The old config pinned every repo and every concurrent session on the
 *    machine to a single `~/.playwright-mcp-profile`, so any second session — or
 *    any Chrome window left open by a previous one — held the lock and Playwright
 *    refused to launch with "Browser is already in use for <dir>".
 * 2. Lock handling at server start, and it never kills anything: a stale/ownerless
 *    lock file is cleared, but a profile actively held by any process — orphaned
 *    or a genuinely live session, deliberately not distinguished, because guessing
 *    wrong about a live session mid-run is worse than just isolating — is left
 *    alone, and this server starts `--isolated` instead, exactly what Playwright's
 *    own error message recommends. If a login was saved earlier for this repo (see
 *    `--storage-state-path` below), the isolated run starts already authenticated
 *    via `--storage-state`, so a second ticket in a second Claude Code session can
 *    start testing immediately instead of prompting for another login or waiting
 *    on the first session to finish.
 * 3. A deterministic `--output-dir` (<cwd>/.playwright-mcp), so screenshots land
 *    where upload-screenshot.js expects them instead of wherever the server
 *    process happened to be launched from.
 * 4. A pinned package version. `@latest` makes npx hit the npm registry on *every*
 *    server start; on a slow, offline, or VPN-restricted network that stalls past
 *    Claude Code's MCP startup timeout and the server is marked failed — another
 *    route to "tools not available". Pinned means the cached copy is used.
 * 5. `--storage-state-path` prints the exact file this repo's login state is
 *    saved to/read from, so a skill can call `browser_storage_state` at that path
 *    right after confirming a login, without re-deriving the profile-hash logic
 *    above in prompt text.
 *
 * Diagnostics go to stderr only. stdout is the MCP JSON-RPC stream — writing
 * anything to it corrupts the protocol and the server drops off.
 *
 * Usage:
 *   node run-playwright.js                      — start the MCP server (what .mcp.json does)
 *   node run-playwright.js --doctor             — print an environment report and exit
 *   node run-playwright.js --install            — pre-install the server package, then exit
 *   node run-playwright.js --storage-state-path — print this repo's saved-login file path
 *   node run-playwright.js --isolated           — serve an in-memory browser with the saved login; the shared
 *                                                 profile is never used (extra servers for parallel workers)
 *   node run-playwright.js --headless           — serve a headless browser (headed otherwise)
 *
 * Env overrides:
 *   QA_ENGINEER_PLAYWRIGHT_MCP_SPEC     — npm spec to run (default: pinned below;
 *                                         set to "@playwright/mcp@latest" to float)
 *   QA_ENGINEER_PLAYWRIGHT_PROFILE_DIR  — override the Chrome profile directory
 *   QA_ENGINEER_PLAYWRIGHT_OUTPUT_DIR   — override the screenshot/output directory
 *   QA_ENGINEER_PLAYWRIGHT_CHROME_PATH  — path to the chrome executable, for a portable
 *                                         or org-managed install in a non-standard place
 *   QA_ENGINEER_PLAYWRIGHT_EXTRA_ARGS   — extra CLI args, whitespace-separated
 *                                         (e.g. "--headless", "--isolated")
 *   QA_ENGINEER_PLAYWRIGHT_NO_RECLAIM   — set to any value to skip lock reclaim
 */

'use strict';

const fs     = require('fs');
const os     = require('os');
const path   = require('path');
const crypto = require('crypto');
const { spawn, spawnSync } = require('child_process');

const PINNED_SPEC  = '@playwright/mcp@0.0.80';
const PACKAGE_NAME = '@playwright/mcp';
const TAG          = '[qa-engineer/playwright]';
const LOCK_FILES   = ['SingletonLock', 'SingletonCookie', 'SingletonSocket', 'lockfile'];

const MODE = process.argv.includes('--doctor')             ? 'doctor'
           : process.argv.includes('--install')            ? 'install'
           : process.argv.includes('--storage-state-path') ? 'storage-state-path'
           : 'serve';

// Extra servers for parallel workers run an in-memory browser and never contend for the shared profile.
const FORCE_ISOLATED = process.argv.includes('--isolated');
const HEADLESS       = process.argv.includes('--headless');

/** stderr only — stdout belongs to the MCP JSON-RPC stream. */
function log(msg) { process.stderr.write(TAG + ' ' + msg + '\n'); }

// ---------------------------------------------------------------------------
// Paths
// ---------------------------------------------------------------------------

/** Root for everything this launcher owns. Survives plugin updates, unlike CLAUDE_PLUGIN_ROOT. */
function dataDir() {
  return path.join(os.homedir(), '.claude', 'qa-engineer');
}

/**
 * Chrome profile directory for this repo.
 *
 * Stable for a given cwd so the QA engineer's login survives between runs (the
 * whole pipeline is pre-authenticated — see "Login required before Phase 3a"),
 * but distinct per repo so two repos never contend for one lock. The cwd hash
 * keeps two same-named directories on different paths apart.
 */
function profileDir() {
  if (process.env.QA_ENGINEER_PLAYWRIGHT_PROFILE_DIR)
    return path.resolve(process.env.QA_ENGINEER_PLAYWRIGHT_PROFILE_DIR);
  // Windows paths are case-insensitive on disk, but process.cwd() reflects whatever
  // case the process that launched us happened to use — confirmed on this machine to
  // vary run to run for the identical directory ("D:\..." vs "d:\..."). Hashing the
  // raw string would silently mint a new, logged-out profile every time the case
  // drifts, defeating the whole point of a stable per-repo profile. Normalize case
  // before hashing on win32 only — POSIX filesystems are case-sensitive, where two
  // different cases really are two different paths.
  const cwd    = process.cwd();
  const hashOf = process.platform === 'win32' ? cwd.toLowerCase() : cwd;
  const slug   = (path.basename(cwd) || 'repo').replace(/[^A-Za-z0-9._-]/g, '-').slice(0, 40);
  const hash   = crypto.createHash('sha256').update(hashOf).digest('hex').slice(0, 8);
  return path.join(dataDir(), 'pw-profiles', slug + '-' + hash);
}

/**
 * Where this repo's saved login (cookies + localStorage) lives.
 *
 * Deliberately a file inside `outputDir()`, not inside the Chrome profile
 * directory — confirmed the hard way (2026-09-17, a real end-to-end test with a
 * real login): `browser_storage_state` is sandboxed by @playwright/mcp to only
 * write inside the server's own "allowed roots", which are the cwd and
 * `--output-dir` — anything else, including the profile directory, fails with
 * "File access denied: ... is outside allowed roots" and the save silently never
 * happens. `outputDir()` is already inside those allowed roots (it *is* one of
 * them) and is already derived from cwd the same way `profileDir()` is, so this
 * still gets the same per-repo, per-machine scoping without a second hashing
 * scheme — just anchored to the writable root instead of the profile.
 */
function storageStatePath() {
  return path.join(outputDir(), 'storage-state.json');
}

/**
 * Where the server writes screenshots and traces.
 *
 * Without this, output lands relative to wherever the *server process* was
 * launched from, which is not guaranteed to match the shell tool's cwd — that
 * mismatch is what made upload-screenshot.js fail with "File not found" on
 * MXTS-78302 and forced a human to supply the real path by hand.
 */
function outputDir() {
  if (process.env.QA_ENGINEER_PLAYWRIGHT_OUTPUT_DIR)
    return path.resolve(process.env.QA_ENGINEER_PLAYWRIGHT_OUTPUT_DIR);
  return path.resolve(process.cwd(), '.playwright-mcp');
}

/** Managed install target, so startup needs neither npx nor the network once seeded. */
function runtimeDir() { return path.join(dataDir(), 'mcp-runtime'); }

// ---------------------------------------------------------------------------
// Profile lock handling
// ---------------------------------------------------------------------------

/**
 * Mirrors playwright-core's own `isProfileLocked` check, so this agrees with the
 * test that actually decides whether launch throws "Browser is already in use".
 *
 * Windows: the lock is an exclusively-held `lockfile`. A crashed Chrome releases
 * the OS handle, so a leftover file opens fine and is correctly reported unlocked
 * — on Windows only a *live* process locks.
 * POSIX: `SingletonLock` is a `<host>-<pid>` symlink, live iff that pid exists.
 */
function isProfileLocked(dir) {
  const lockPath = path.join(dir, process.platform === 'win32' ? 'lockfile' : 'SingletonLock');
  if (process.platform === 'win32') {
    try {
      fs.closeSync(fs.openSync(lockPath, 'r+'));
      return false;
    } catch (err) {
      return err.code !== 'ENOENT';
    }
  }
  try {
    const pid = parseInt(String(fs.readlinkSync(lockPath)).split('-').pop(), 10);
    if (Number.isNaN(pid)) return false;
    process.kill(pid, 0);
    return true;
  } catch {
    return false;
  }
}

/**
 * Browser processes holding `dir`, as `{ pid, orphaned }`. `reclaimProfile` no
 * longer branches on `orphaned` (nothing here is ever killed) — it is kept purely
 * for the doctor report, so a human can still see whether a lock is a leftover
 * from a crashed session or a genuinely live one.
 *
 * Two deliberate narrowings:
 *
 * - Matched on the profile path appearing in the command line, never on the process
 *   name alone. Matching every chrome.exe would pull in the user's real browser too.
 *   Only MCP-launched browsers are ever passed this path.
 * - Only the *main* browser process, identified by the absence of `--type=`. Chrome's
 *   renderer/GPU/utility children all carry the same `--user-data-dir` on their
 *   command line but are not the lock owner, and they exit with their parent.
 */
function browsersHoldingProfile(dir) {
  const found = [];
  if (process.platform === 'win32') {
    // powershell.exe lives in System32 and is always spawnable; wmic is gone on
    // current Windows 11. -Filter narrows to browsers before the CommandLine match.
    // The glob travels via the environment so the path never needs quoting inside
    // the PowerShell source.
    const script = [
      '$live = @{}; Get-Process | ForEach-Object { $live[$_.Id] = $true };',
      'Get-CimInstance Win32_Process -Filter "Name=\'chrome.exe\' OR Name=\'msedge.exe\'" |',
      'Where-Object { $_.CommandLine -like $env:QA_PW_PROFILE_GLOB -and $_.CommandLine -notlike \'*--type=*\' } |',
      'ForEach-Object { "$($_.ProcessId) $(if ($live[[int]$_.ParentProcessId]) { 1 } else { 0 })" }',
    ].join(' ');
    const res = spawnSync('powershell.exe', ['-NoProfile', '-NonInteractive', '-Command', script], {
      encoding: 'utf8',
      timeout: 20000,
      // -like treats * ? [ ] as wildcards; only * is wanted here, so escape the rest
      // in case the user's home path contains brackets.
      env: Object.assign({}, process.env, {
        QA_PW_PROFILE_GLOB: '*' + dir.replace(/[[\]?*`]/g, '`$&') + '*',
      }),
    });
    for (const line of String(res.stdout || '').split(/\r?\n/)) {
      const [pidStr, parentAlive] = line.trim().split(/\s+/);
      const pid = parseInt(pidStr, 10);
      if (pid > 0) found.push({ pid, orphaned: parentAlive === '0' });
    }
    return found;
  }

  const res = spawnSync('ps', ['-A', '-o', 'pid=,ppid=,command='], { encoding: 'utf8', timeout: 20000 });
  const lines = String(res.stdout || '').split('\n');
  const livePids = new Set();
  for (const line of lines) {
    const pid = parseInt(line.trim().split(/\s+/)[0], 10);
    if (pid > 0) livePids.add(pid);
  }
  for (const line of lines) {
    if (!line.includes(dir)) continue;
    if (!/chrom|msedge/i.test(line)) continue;
    if (line.includes('--type=')) continue;
    const [pidStr, ppidStr] = line.trim().split(/\s+/);
    const pid  = parseInt(pidStr, 10);
    const ppid = parseInt(ppidStr, 10);
    if (pid > 0 && pid !== process.pid)
      found.push({ pid, orphaned: ppid <= 1 || !livePids.has(ppid) });
  }
  return found;
}

function removeLockFiles(dir) {
  for (const f of LOCK_FILES) {
    try { fs.unlinkSync(path.join(dir, f)); } catch { /* absent, or held open */ }
  }
}

/**
 * Free `dir` for launch, without ever killing a process. Returns a short status
 * string for the log/report.
 *
 * Only a lock with no findable owner (a stale POSIX symlink, or a Windows lock
 * file left behind by a crash) is cleared — that is deleting inert leftover
 * bytes, not touching a running process. Once `dir` is actively held by *any*
 * process, this deliberately does not try to tell an orphan apart from a
 * genuinely live session: killing a browser on a guess is never worth it, and a
 * live session may be mid-run. Every actively-held case gets the same answer —
 * start `--isolated` instead (see serverArgs) — so the run proceeds rather than
 * failing with Playwright's own "Browser is already in use", and rather than
 * asking the user to decide whom to kill. If this repo has a saved login (see
 * storageStatePath), the isolated browser starts already authenticated, so a
 * second concurrent ticket needs no prompt at all.
 */
function reclaimProfile(dir) {
  const ok = (status) => ({ status, isolate: false });
  const isolate = (status) => ({ status, isolate: true });

  if (process.env.QA_ENGINEER_PLAYWRIGHT_NO_RECLAIM) return ok('skipped (NO_RECLAIM set)');
  if (!fs.existsSync(dir)) return ok('fresh profile');
  if (!isProfileLocked(dir)) {
    // Windows leaves the file behind after a crash; it is inert, but removing it
    // keeps the doctor report honest.
    if (process.platform === 'win32') removeLockFiles(dir);
    return ok('not locked');
  }

  const holders = browsersHoldingProfile(dir);
  if (!holders.length) {
    // Locked but nothing owns it: a stale POSIX symlink, or a recycled pid.
    removeLockFiles(dir);
    return isProfileLocked(dir)
      ? isolate('owner not found and lock would not clear — starting isolated')
      : ok('stale lock cleared');
  }

  return isolate(holders.length + ' process(es) actively holding the profile (pid '
    + holders.map((h) => h.pid).join(', ') + ') — starting isolated, nothing killed');
}

// ---------------------------------------------------------------------------
// Resolving the server package
// ---------------------------------------------------------------------------

/** npm's own npx entry point, reached through `node` so no .cmd shim is needed. */
function npxCliCandidates() {
  const nodeDir = path.dirname(process.execPath);
  return [
    path.join(nodeDir, 'node_modules', 'npm', 'bin', 'npx-cli.js'),                             // Windows
    path.join(nodeDir, '..', 'lib', 'node_modules', 'npm', 'bin', 'npx-cli.js'),                // Unix prefix
    path.join(nodeDir, '..', 'libexec', 'lib', 'node_modules', 'npm', 'bin', 'npx-cli.js'),     // Homebrew
  ].filter((p) => fs.existsSync(p));
}

function npmCliCandidates() {
  return npxCliCandidates()
    .map((p) => p.replace(/npx-cli\.js$/, 'npm-cli.js'))
    .filter((p) => fs.existsSync(p));
}

/**
 * Absolute path to a locally resolvable @playwright/mcp CLI, or null.
 *
 * Resolved via the package's own package.json rather than `require.resolve` on the
 * subpath: the package ships an `exports` map that lists only "." and
 * "./package.json", so asking for "@playwright/mcp/cli.js" directly fails with
 * ERR_PACKAGE_PATH_NOT_EXPORTED even when the file is right there. Its `bin` entry
 * is the declared, supported way to find the executable.
 */
function resolveLocalCli() {
  const paths = [runtimeDir(), __dirname, process.cwd()];
  let manifestPath;
  try {
    manifestPath = require.resolve(PACKAGE_NAME + '/package.json', { paths });
  } catch {
    return null;
  }
  try {
    const manifest = JSON.parse(fs.readFileSync(manifestPath, 'utf8'));
    const bin = manifest.bin;
    const rel = typeof bin === 'string' ? bin : (bin && (bin['playwright-mcp'] || Object.values(bin)[0]));
    const cli = path.join(path.dirname(manifestPath), rel || 'cli.js');
    return fs.existsSync(cli) ? cli : null;
  } catch {
    return null;
  }
}

function spec() {
  return process.env.QA_ENGINEER_PLAYWRIGHT_MCP_SPEC || PINNED_SPEC;
}

/** Seed runtimeDir() so later starts need neither npx nor the network. */
function installRuntime() {
  const target = runtimeDir();
  fs.mkdirSync(target, { recursive: true });
  const pkgJson = path.join(target, 'package.json');
  if (!fs.existsSync(pkgJson))
    fs.writeFileSync(pkgJson, JSON.stringify({ name: 'qa-engineer-mcp-runtime', private: true }, null, 2) + '\n');

  const args   = ['install', '--no-audit', '--no-fund', '--loglevel=error', spec()];
  const npmCli = npmCliCandidates()[0];
  const res = npmCli
    ? spawnSync(process.execPath, [npmCli].concat(args), { cwd: target, stdio: 'inherit', timeout: 300000 })
    : spawnSync('npm', args, { cwd: target, stdio: 'inherit', shell: true, timeout: 300000 });
  return res.status === 0;
}

// ---------------------------------------------------------------------------
// Modes
// ---------------------------------------------------------------------------

/**
 * `isolate` is set when the shared profile could not be freed — some process
 * (orphaned or a genuinely live Claude Code session, reclaimProfile does not ask
 * which) still holds it. `--isolated` is Playwright's own answer to that (it is
 * what its "Browser is already in use" message tells you to pass): the browser
 * starts with an in-memory profile, so the run proceeds instead of marking every
 * TC BLOCKED. If this repo has a saved login (see storageStatePath), it is passed
 * via `--storage-state` so the isolated browser starts already authenticated —
 * only a repo with no saved login yet falls back to a fresh login prompt.
 */
function serverArgs(isolate, profile) {
  const override  = process.env.QA_ENGINEER_PLAYWRIGHT_CHROME_PATH;
  const stateFile = storageStatePath();
  const modeArgs  = isolate
    ? ['--isolated'].concat(fs.existsSync(stateFile) ? ['--storage-state=' + stateFile] : [])
    : ['--user-data-dir', profile];

  // browser_storage_state / browser_set_storage_state (what saves/restores the login
  // above) live behind @playwright/mcp's opt-in "storage" capability group (confirmed
  // against the installed 0.0.80 package's own README — core tools like
  // browser_network_requests are not gated, but this whole group is). Without --caps
  // including "storage" the tools are simply never registered, and a skill's call to
  // them fails as "tool not available" despite being listed in allowed-tools. Merge
  // with any caps the user already set via EXTRA_ARGS instead of emitting a second
  // --caps flag, which would just have the last one win and silently drop the other's.
  const extraArgs = (process.env.QA_ENGINEER_PLAYWRIGHT_EXTRA_ARGS || '').trim().split(/\s+/).filter(Boolean);
  const capsIndex = extraArgs.findIndex((a) => /^--caps=/.test(a));
  let capsArg;
  if (capsIndex === -1) {
    capsArg = '--caps=storage';
  } else {
    const requested = extraArgs[capsIndex].slice('--caps='.length).split(',').filter(Boolean);
    if (!requested.includes('storage')) requested.push('storage');
    capsArg = '--caps=' + requested.join(',');
    extraArgs.splice(capsIndex, 1);
  }

  if (HEADLESS && !extraArgs.includes('--headless')) extraArgs.push('--headless');

  return ['--browser', 'chrome', '--output-dir', outputDir(), capsArg]
    .concat(modeArgs)
    .concat(override && fs.existsSync(override) ? ['--executable-path', override] : [])
    .concat(extraArgs);
}

function serve() {
  const profile   = profileDir();
  const output    = outputDir();
  // before mkdir, so "fresh profile" stays accurate
  const lock      = FORCE_ISOLATED ? { status: 'skipped (--isolated)', isolate: true } : reclaimProfile(profile);
  const stateFile = storageStatePath();
  const hasState  = fs.existsSync(stateFile);
  fs.mkdirSync(profile, { recursive: true });
  fs.mkdirSync(output,  { recursive: true });

  log('profile: ' + (lock.isolate
    ? 'isolated (in-memory) — ' + (FORCE_ISOLATED ? 'forced by --isolated' : 'shared profile unavailable')
      + (hasState ? ', restoring saved login from ' + stateFile
                  : ' (no saved login yet for this repo — will ask to log in)')
    : profile));
  log('output:  ' + output);
  log('lock:    ' + lock.status);
  log('browser: ' + (HEADLESS ? 'headless' : 'headed'));

  const args = serverArgs(lock.isolate, profile);

  // Preferred: run the CLI in-process. No child, no npx, no registry round-trip,
  // and stdio is already exactly what the MCP transport expects.
  const localCli = resolveLocalCli();
  if (localCli) {
    log('starting in-process: ' + localCli);
    process.argv = [process.execPath, localCli].concat(args);
    require(localCli);
    return;
  }

  // Fall back to npx, reached via `node npx-cli.js` rather than a bare `npx`
  // (a .cmd shim on Windows, unspawnable without a shell).
  const npxCli = npxCliCandidates()[0];
  let child;
  if (npxCli) {
    log('starting via npx: ' + spec());
    child = spawn(process.execPath, [npxCli, '-y', spec()].concat(args), { stdio: 'inherit' });
  } else {
    log('starting via shell npx: ' + spec() + ' (npx-cli.js not found next to node)');
    child = spawn('npx', ['-y', spec()].concat(args), { stdio: 'inherit', shell: true });
  }

  child.on('error', (err) => {
    log('FAILED to start the Playwright MCP server: ' + (err.code || err.message));
    log('Run for a full diagnosis:  node "' + __filename + '" --doctor');
    process.exit(1);
  });
  for (const sig of ['SIGINT', 'SIGTERM']) {
    process.on(sig, () => { try { child.kill(sig); } catch { /* already gone */ } });
  }
  child.on('exit', (code, signal) => process.exit(signal ? 1 : (code === null ? 0 : code)));
}

/**
 * Path to the Chrome the server will drive, or null if none was found.
 *
 * QA_ENGINEER_PLAYWRIGHT_CHROME_PATH wins when set — the standard locations below
 * miss a portable or org-managed install, and without an override the doctor would
 * report "NOT FOUND" on a machine that does have Chrome.
 */
function chromePath() {
  const override = process.env.QA_ENGINEER_PLAYWRIGHT_CHROME_PATH;
  if (override) return fs.existsSync(override) ? override : null;

  let candidates;
  if (process.platform === 'win32') {
    candidates = [
      path.join(process.env['PROGRAMFILES'] || 'C:\\Program Files', 'Google', 'Chrome', 'Application', 'chrome.exe'),
      path.join(process.env['PROGRAMFILES(X86)'] || 'C:\\Program Files (x86)', 'Google', 'Chrome', 'Application', 'chrome.exe'),
      path.join(process.env.LOCALAPPDATA || '', 'Google', 'Chrome', 'Application', 'chrome.exe'),
    ];
  } else if (process.platform === 'darwin') {
    candidates = ['/Applications/Google Chrome.app/Contents/MacOS/Google Chrome'];
  } else {
    candidates = [
      '/usr/bin/google-chrome', '/usr/bin/google-chrome-stable', '/opt/google/chrome/chrome',
      '/usr/bin/chromium', '/usr/bin/chromium-browser', '/snap/bin/chromium',
    ];
  }
  return candidates.filter((p) => p && fs.existsSync(p))[0] || null;
}

/**
 * Environment report. This is the piece that made the failure so hard to pin down:
 * every symptom ("tools not available", "server unavailable", all TCs BLOCKED)
 * looked identical from inside a run, so people re-installed the plugin and
 * switched install scopes instead of seeing which dependency was actually absent.
 */
function doctor() {
  const out = (s) => process.stdout.write(s + '\n');
  const profile  = profileDir();
  const localCli = resolveLocalCli();
  const npxCli   = npxCliCandidates()[0];
  const chrome   = chromePath();
  const holders  = fs.existsSync(profile) ? browsersHoldingProfile(profile) : [];

  out('qa-engineer — Playwright MCP environment report');
  out('');
  out('  platform            ' + process.platform + ' ' + process.arch);
  out('  node                ' + process.version + '  (' + process.execPath + ')');
  out('  cwd                 ' + process.cwd());
  out('  server package      ' + (localCli ? 'installed (' + localCli + ')'
                                           : 'not installed locally — will use npx ' + spec()));
  out('  npx via node        ' + (npxCli || 'NOT FOUND next to node — will fall back to shell npx'));
  out('  google chrome       ' + (chrome || 'NOT FOUND — install from google.com/chrome'));
  out('  profile dir         ' + profile);
  out('  profile exists      ' + (fs.existsSync(profile) ? 'yes' : 'no (created on first run)'));
  out('  profile locked      ' + (fs.existsSync(profile) && isProfileLocked(profile) ? 'YES' : 'no'));
  out('  lock holders        ' + (holders.length
        ? holders.map((h) => 'pid ' + h.pid + (h.orphaned ? ' (orphaned)' : ' (live session)')).join(', ')
          + ' — next server start uses an isolated browser, nothing killed'
        : 'none'));
  out('  saved login         ' + (fs.existsSync(storageStatePath())
        ? 'yes — ' + storageStatePath()
        : 'no (saved automatically after the next successful login)'));
  out('  output dir          ' + outputDir());
  out('  spawnable: node     yes');
  // `npx` here is the *shell* fallback serve() reaches for only when neither a
  // local install nor npx-cli.js next to node panned out (all three are checked in
  // that order). Its result feeds the blocker check below — a machine where npx.cmd
  // is on PATH but laid out somewhere npxCliCandidates() doesn't look (nvm, a
  // relocated npm, etc.) still has a working path to the server and must not be
  // reported as blocked.
  let npxShellWorks = false;
  for (const cmd of ['bash', 'npx']) {
    // Single command string + shell:true (no separate `args` array) so Node doesn't
    // emit its "args with shell:true" deprecation warning — there's nothing dynamic
    // here to be unsafe about, just the fixed literal below.
    const r  = spawnSync(cmd + ' --version', { encoding: 'utf8', timeout: 10000, shell: true });
    // "no spawn error" only means the shell itself started; under shell:true a
    // missing command still spawns (the shell runs, then reports "command not
    // found") and comes back as a non-zero exit, not an r.error — so status must be
    // checked too, or a genuinely absent command gets reported as spawnable.
    const ok = !r.error && r.status === 0;
    if (cmd === 'npx') npxShellWorks = ok;
    out('  spawnable: ' + cmd.padEnd(9) + (ok ? 'yes'
        : 'no' + (r.error ? ' (' + r.error.code + ')' : r.status !== 0 ? ' (exit ' + r.status + ')' : '')
        + ' — not required by this launcher'));
  }
  out('');

  const blockers = [];
  if (!chrome)
    blockers.push('Google Chrome was not found — the MCP server drives your system Chrome. '
      + 'Install it from google.com/chrome, or set QA_ENGINEER_PLAYWRIGHT_CHROME_PATH to '
      + 'your existing chrome executable if it lives somewhere non-standard.');
  if (!localCli && !npxCli && !npxShellWorks)
    blockers.push('No way to reach the @playwright/mcp server package: no local install, no '
      + "npm's npx-cli.js next to node, and shell-invoked npx also failed. Run "
      + 'node "' + __filename + '" --install to install a local copy, or reinstall Node.js from nodejs.org.');

  if (blockers.length) {
    out('BLOCKERS');
    blockers.forEach((b, i) => out('  ' + (i + 1) + '. ' + b));
    process.exitCode = 1;
    return;
  }

  out('No blockers found — the server should start.');
  if (!localCli) {
    out('');
    out('Optional, makes startup instant and offline-proof:');
    out('  node "' + __filename + '" --install');
  }
  out('');
  out('If tools are still missing after this reports clean, the session simply has not');
  out('picked them up: MCP tool lists are built once at session start. Fully quit and');
  out('reopen Claude Code (a window reload is not enough), then re-run.');
  out('');
  out('If a full restart still does not fix it, this check cannot see the problem — it');
  out('only covers Chrome/Node, not whether the plugin itself loaded the right version.');
  out('Run: node "' + path.join(path.dirname(__filename), 'check-registration.js') + '"');
}

switch (MODE) {
  case 'doctor':
    doctor();
    break;
  case 'install':
    process.stdout.write('Installing ' + spec() + ' into ' + runtimeDir() + '\n');
    if (installRuntime() && resolveLocalCli()) {
      process.stdout.write('Installed. The server now starts in-process, with no npx call and no network.\n');
    } else {
      process.stdout.write('Install failed — the server will fall back to npx at startup.\n');
      process.exitCode = 1;
    }
    break;
  case 'storage-state-path':
    process.stdout.write(storageStatePath() + '\n');
    break;
  default:
    serve();
}
