# qa-engineer

QA pipeline for the Customer Care Module and other Maxxton features. Reads requirements from Confluence and Jira, generates structured test cases, executes live browser tests, triages failures, and raises Jira defects — orchestrated via `/test-ticket`. Reports (`/generate-reports`) and PR review (`/review-pr`) are available as standalone skills.

## Pipeline Flowchart

```
     [ /test-ticket  EPIC-ID · URL (log in to primary app first) ]
                              |
                              v
              +--------------------------------+
              |  1. READ                       |
              |  -> Requirements + AC summary  |
              |  -> Developer impl comments    |
              |     (exact locations/flows)    |
              |  -> Readiness gate             |
              +--------------------------------+
                              |
                              v
              +--------------------------------+
              |  2. PLAN                       |
              |  /generating-test-cases        |
              |  -> Primary TCs from ACs       |
              |  -> 10-column TC table         |
              |  -> Risk column (H/M/L)        |
              |  -> Gate 1: scenario review    |
              |  -> Gate 2: automation exclude |
              +--------------------------------+
                              |
                              v
              +--------------------------------+
              |  2.5 IMPACT                    |
              |  /analyzing-impact             |
              |  -> Blast radius via tech graph|
              |  -> Direct + transitive modules|
              |  -> Impact Summary (auto)      |
              |  (skip with --skip-impact)     |
              +--------------------------------+
                              |
                              v
              +--------------------------------+
              |  3. EXECUTE                    |
              |  -> Sequential per TC          |
              |  -> Session auto-detected      |
              |  -> Build version auto-picked  |
              |  -> PASS / FAIL /              |
              |     BLOCKED / NEEDS REVIEW     |
              |  -> 3-attempt retry on FAIL    |
              +--------------------------------+
                              |
                              v
              +--------------------------------+
              |  3b. AUTOMATE                  |
              |  /generate-playwright-tests    |
              |  -> .spec.js (real selectors   |
              |     from execution log)        |
              |  -> import { test, expect }    |
              |     from '#mxts-test'          |
              |  -> test.step() mandatory      |
              +--------------------------------+
                              |
                              v
              +--------------------------------+
              |  4. TRIAGE                     |
              |  /triage-defect                |
              |  -> Product defect / Tooling   |
              |     misread / TC issue /       |
              |     Needs review               |
              |  -> Data integrity gate        |
              +--------------------------------+
                              |
                              v
              +--------------------------------+
              |  5. DEFECTS                    |
              |  /raise-defect                 |
              |  -> Propose → confirm → raise  |
              |  -> Dedup + component routing  |
              +--------------------------------+
                              |
                              v
              +--------------------------------+
              |  6. PUBLISH                    |
              |  -> Push spec files to GitHub  |
              |  -> Open PR in mxts- or        |
              |     mcms-qa-automation         |
              |     (by URL, see SKILL.md)     |
              |  (auto when specs generated)   |
              +--------------------------------+
                              |
                              v
                    [ DONE — /test-ticket ]

  Optional manual steps afterwards:
  /generate-reports  →  Confluence / DOCX / PPT
  /review-pr         →  Spec file quality check
```

## Skills

| Skill | Command | Description |
|---|---|---|
| Test Ticket | `/test-ticket <Jira Epic ID> [URL]` | Orchestrates the full pipeline (Phases 1–2.5–3–4–5–6) — reads requirements, generates TCs, runs cross-module impact analysis, executes live browser tests, triages, raises defects, and pushes spec files to GitHub. Log in to the app first |
| Analyzing Impact | `/analyzing-impact <Jira ticket key>` | Standalone cross-module blast radius analysis — identifies impacted modules, owning teams, and test areas via the Maxxton technical graph |
| Read Requirements | `/read-requirements <Jira ID>` | Reads Confluence LLD/HLD/exit docs and Jira stories, produces a structured requirement summary |
| Generate Test Cases | `/generating-test-cases <Jira ID or paste summary>` · `/generating-test-cases <Jira ID> --extend` to add cases a human found missing | Generates test cases across functional areas, posts to Jira, and labels the ticket `HL-Scenarios_Covered` |
| Generate Playwright Tests | `/generate-playwright-tests <Jira ID or paste table>` | Converts test cases into Playwright JS spec files using real selectors from the execution log |
| Triage Defect | `/triage-defect <paste output or results path>` | Classifies each live-MCP failure as product defect, tooling misread, test case issue, or needs review |
| Raise Defect | `/raise-defect <paste triage report>` | Creates structured Jira Bug tickets with full evidence for confirmed product defects |
| Generate Reports | `/generate-reports <Jira ID> and paste triage` | Creates a Confluence page, DOCX report, and PPT summary deck for the test run |
| Review PR | `/review-pr <PR number or URL>` | Reviews and merges the Playwright spec PR after checking selector quality and coverage |
| Execute Tests | `/execute-tests <Jira ID> [URL]` | Opens a browser, runs every test step live via Playwright MCP, posts results to Jira — log in to the app first |

## Generate Test Cases — Workflow

```
     [ Input: Jira Story ID  OR  Requirement Summary ]
                          |
           +--------------+--------------+
           |                             |
           v                             v
  [ Jira Story ID ]          [ Requirement Summary ]
  getJiraIssue()             Use as-is
           |                             |
           +-------------+---------------+
                         |
                         v
          +--------------------------------+
          |  2. DERIVE                     |
          |  Steps + Preconditions         |
          |  from requirements             |
          +--------------------------------+
                         |
                         v
          +--------------------------------+
          |  3. HIGH-LEVEL SCENARIOS       |
          |  6-10 per issue                |
          |  TC_ID + category + scenario   |
          +--------------------------------+
                         |
                         v
          +--------------------------------+
          |  4. EXPAND                     |
          |  Each scenario ->              |
          |  multiple detailed test cases  |
          +--------------------------------+
                         |
                         v
          +--------------------------------+
          |  5. TEST CASE TABLE            |
          |  10-column format per issue    |
          |  Actual result = To be Tested  |
          +--------------------------------+
                         |
                         v
          +--------------------------------+
          |  6. COVERAGE GAPS              |
          |  AC with no test case          |
          |  Vague / untestable criteria   |
          +--------------------------------+
                         |
                         v
          +--------------------------------+
          |  7. POST TO JIRA               |
          |  HL Scenarios + Detail table   |
          |  + Coverage Gaps -> comment    |
          +--------------------------------+
                         |
                         v
          +--------------------------------+
          |  8. APPLY LABEL                |
          |  HL-Scenarios_Covered -> Jira  |
          +--------------------------------+
                         |
                         v
                      [ DONE ]

  -- Later, after test execution --

          +--------------------------------+
          |  9. UPDATE ACTUAL RESULTS      |
          |  PASS / FAIL / BLOCKED         |
          |  -> new superseding comment    |
          +--------------------------------+
```

## Quick Start

### Run a single story end-to-end

```
/read-requirements MXTS-12345
/generating-test-cases      <- paste the requirement summary
/execute-tests MXTS-12345 https://rcn-test.maxxton.net
/generate-playwright-tests  <- paste the test case table
/triage-defect              <- paste execution results
/raise-defect               <- paste triage report
```

Optional steps afterwards:
```
/generate-reports MXTS-12345
/review-pr                  <- spec file quality check
```

### Run the full pipeline with one command

Log in to the app in your browser first, then:

```
/test-ticket MXTS-12345 https://rcn-test.maxxton.net
```

Claude detects your existing browser session, executes every test step live, posts results to Jira, and proposes defects for your confirmation before raising them.

> **Environment check:** URLs matching `*-dev.maxxton.net` or `*-test.maxxton.net` run without prompting. Any other URL (production, staging, anything else) is a hard stop — there is no confirmation that lets it proceed anyway. Re-run with a dev/test URL.

### Run generation only (no URL)

```
/test-ticket MXTS-12345
```

Reads requirements and generates test cases only. Spec files are displayed for manual copy — no browser execution.

### Run multiple Epics in one command

```
/test-ticket MXTS-12345 https://rcn-test.maxxton.net MXTS-12360 https://rcn-test.maxxton.net
```

All Epics complete Phase 1+2 first, then each Epic fully completes 2.5 → Impact Summary → 3a → 3b → 4 → 5 before the next starts — one Claude thread, one browser. A URL repeats to the next Epic if omitted for it. The Final Summary prints per-Epic results plus combined totals.

## Flags Reference

Flags are primarily for `/test-ticket`; `/execute-tests` supports only `--retest`, `--max-tcs`, `--tc-timeout`, `--max-time`, `--screenshots`, `--unattended`, `--clear-nav-cache`, `--skip-review` and `--workers`.

| Flag | Default | Description |
|---|---|---|
| `--force` | off | Re-run all phases from scratch (skip resume check) |
| `--retest` | off | Scoped retest after a fix: re-runs only the TCs that did not pass before (FAIL, then NEEDS REVIEW, then BLOCKED), then the High-risk TCs that passed before (only if every FAIL TC now passes); stops at the first FAIL TC that fails again. Posts a new results comment that marks Run 1 against the retest |
| `--from=phaseN` | — | Resume from a specific phase (e.g. `--from=phase3a`) |
| `--skip-impact` | off | Skip Phase 2.5 (cross-module impact analysis) — use when blast radius is already known |
| `--max-tcs=N` | unlimited | Run only the top N test cases by risk order |
| `--tc-timeout=N` | 180s | Per-test timeout in seconds — hung step → BLOCKED |
| `--max-time=N` | 90 min | Total Phase 3a time limit in minutes |
| `--unattended` | off | Umbrella flag — expands to `--auto-specs --auto-raise`; removes every prompt except Jira ticket creation, which always asks regardless; ticket videos on Bugs are not read |
| `--auto-raise` | off | No-op, kept for backward compatibility — ticket creation always asks for confirmation, with no exceptions |
| `--skip-specs` | off | Force Gate 2 to exclude every TC from automation — no spec files for this run, for any story |
| `--auto-specs` | off | Skip Gate 2's ask — automate every TC (spec files generated for all of them) |
| `--min-completeness=N` | 60 | Minimum execution completeness % before Phase 5 runs |
| `--screenshots` | off | `/execute-tests` only — also capture a before-screenshot on attempt 1 (its default: before-screenshot only on retries). Not accepted by `/test-ticket`, which never takes before/mid-TC screenshots — exactly one result screenshot per TC, except the Before/After pair of a bill-changing TC (see **Bill recalculation + before/after bill** below) |
| `--skip-review` | off | Skip the batched Evidence Review (one reviewer subagent that checks the screenshots behind every High-risk PASS and can only downgrade it to NEEDS REVIEW) |
| `--clear-nav-cache` | off | Delete `test-output/nav-cache.json` before Phase 3a starts — use after a major app restructure where route paths have changed |
| `--workers=N` | automatic | Override of the automatic parallel mode: `1` turns it off, `2` is the most browsers the plugin has today. Without it, test cases run on 2 browsers at once when that pays off (the session's own browser and the `playwright-w2` server). With fewer than 8 test cases, a small saving or mostly shared data it runs sequentially. See [Parallel execution](#parallel-execution-automatic) |

## Features

| Feature | Where |
|---|---|
| **Implementation comment scanning** | Phase 1 — reads all story comments (not just "Quick summary" format), subtasks, and linked bugs to extract exact scope, regression areas, and out-of-scope exclusions |
| **Cross-module blast radius** | Phase 2.5 — reads linked PR diff for code-accurate entry points, then queries Maxxton technical graph for direct + transitive impacted modules. Impact table is `Module \| Team \| QA \| Impact Type \| What is affected` — QA is looked up by Team from a shared ownership reference (real `@mention` in both Jira and Slack, never a guessed/fallback name), and "What is affected" leads with plain-language business impact before the technical reference |
| **Sequential execution** | Phase 3a — one TC at a time; session auto-detected on first navigate |
| **Build version auto-detection** | Phase 3a — picks version in order: Jira `fixVersions` → Assistance button popup (V2026.x.x-tXXX pattern) → DOM heuristic |
| **Status-based pipeline branching** | Status Gate — dev-stage → test cases only; QA-stage → full pipeline. The live Jira status is re-read on every invocation (resume, `--from=`, `--retest`, standalone `/execute-tests`), so a story that was moved to `Reopened` or `Resolved` is never executed again until it is back in a QA status |
| **Configurable status mapping** | `## Configuration` block in each skill — add custom Jira statuses |
| **Risk column (High/Medium/Low)** | Phase 2 — TCs ordered by risk; High runs first |
| **Gate 1 — Scenario Review** | Phase 2 — user can remove or add TC scenarios before posting |
| **Gate 2 — Automation Exclusion** | Phase 2 — user marks TCs to skip from spec generation (still executed); the *only* spec-generation decision point — no separate ask later in Phase 3a, and the resume-path equivalent derives the same answer from the existing TC comment instead of asking again |
| **Boundary + authorization scenarios** | Phase 2 — auto-generated for text/number fields and role-restricted actions |
| **Environment hard stop (prod guard)** | Pre-flight — non-dev/test URLs block the run outright, no override path |
| **Smart execution defaults** | Phase 3a — result screenshot on every TC (named `<TC_ID>-<slug>.png`); `browser_snapshot` only when verdict is ambiguous; PASS corroboration on High-risk write TCs only — saves ~30–60s on a typical 20-TC run |
| **Bill recalculation + before/after bill** | Phase 2 — every TC that saves a change to what a reservation is charged (override rates, add-on, offer, dates…) carries a "Recalculate reservation" step and a whole-bill comparison, and the self-check log has a `bill-recalc` count. Phase 3a — such a TC records the full bill, VAT included, before the change and after the recalculation (`bill-diff.js` does the arithmetic) and takes a Before/After screenshot pair; the Actual Result lists the lines and totals that moved, and a total the recalculation moved without the Expected Result naming it downgrades the TC to NEEDS REVIEW (FAIL when the Expected Result says it stays). Reference: `skills/execute-tests/references/bill-snapshot.md` |
| **BLOCKED dependency model** | Phase 3a — Playwright MCP / environment down → all BLOCKED, straight to Final Summary; mid-run session loss → Session Recovery (re-login and continue, not mass-BLOCKED; the wait counts as a pause in Test Execution Timing, not as test time); setup TC fail → dependent TCs BLOCKED |
| **3-attempt retry + flaky detection** | Phase 3a — FAIL retried 3×; pass on retry → flagged as flaky |
| **NEEDS REVIEW verdict** | Phase 3a — ambiguous snapshot; never guesses PASS/FAIL |
| **TC ID enforcement** | Phase 3b — only TC IDs from Phase 2 are posted to Jira; no invented IDs (`EXTRA_01` etc.) are ever added to the results comment or triage |
| **Per-test timeout + run budget** | Phase 3a — hung step → BLOCKED; budget exhausted → partial results |
| **3b uses 3a selectors** | Phase 3b — spec files get real validated selectors from the execution log |
| **Data integrity gate** | Phase 5 — suppresses defects if execution completeness < 60% |
| **Defect confirmation gate** | Phase 5 — proposes defects, awaits yes/no before filing |
| **Story Action (automatic)** | Phase 5 → Exit — no ask: `Checked by QA` if a defect is tracked by a Bug (new or existing), `Reopened` if a real product defect was found but ended up tracked by none |
| **Dedup by TC_ID + regression detection** | Phase 5 — skips open dupes; re-files closed bugs as regressions |
| **Component + severity routing** | Phase 5 — auto-maps defects to Jira component via keyword match |
| **QA-RUNNING concurrency lock** | Pre-flight — blocks parallel runs on same Epic via Jira label; auto-continues without asking if the lock is the same runner's own, and auto-releases + re-acquires a different runner's lock once it exceeds `stale_lock_threshold_hours` (default 3h) — the threshold itself is the policy decision, never a per-run ask |
| **Navigation cache** | Phase 3a — cache-first route navigation shared across all tickets/Epics (`test-output/nav-cache.json`, max 200 entries, oldest evicted first); also used as a spec-file URL fallback in Phase 3b. Reset with `--clear-nav-cache` after a route restructure |
| **Fixture Cache** | Test Data Setup — the same cache-first pattern as Navigation Cache, applied to the four "combination of attributes" preconditions (allotment-on-fully-booked, child/addition resource, differing stay lengths, resource quantity ≠ 1) that can require checking multiple environments/resorts to find at all. A fixture found once (`test-output/fixture-cache.json`, shared across all tickets) is re-verified and reused by later tickets needing the same shape, instead of repeating the expensive search — directly targets the recurring "high BLOCKED rate from missing test data" QA feedback |
| **Environment Health Check retry** | Phase 3a — a failed health probe (5xx, blank page, connection error) gets exactly one retry after a 30s wait before mass-blocking the Epic, so a transient blip (mid-deploy restart) doesn't cost a full re-run the way an immediate mass-block used to |
| **Exit Gate auto-transition** | Exit Gate — `auto_transition: true` in Configuration transitions the story to `transition_target` automatically on DoD PASS, no per-run ask (the config flag itself is the confirmation) |
| **Cross-Module Impact broadcast** | Phase 2.5 — auto-posts the impact table to `impact_slack_channel` (no confirmation, config value itself is the opt-in); skipped with no prompt if there's no impact to report; any send failure (auth, permission, or otherwise) just logs one line and continues — never an interactive error |
| **Slack notifications** | Phase 5 + Final Summary — notifies on defects raised and run complete |
| **Debug Evidence Capture** | Phase 3a — on `FAIL`/`BLOCKED`, a corroborating console error or failing network request is captured (sanitized — auth headers/tokens stripped) and appended directly under the screenshot in the Test Proof cell; on `NEEDS REVIEW`, the same capture is saved locally instead (`TC_ID-console.txt` / `TC_ID-network.txt`) rather than posted. Skipped entirely for a plain PASS |
| **Precondition Evidence Check** | Phase 3a — detects a *ticket-level* precondition (a companion ticket/PR/fix that must be deployed before any TC result means anything, distinct from per-TC data preconditions), verifies it via an automated Jira-status check with a manual tester-confirmation fallback, and evidences the outcome as a `Preconditions` row in the results comment plus a local audit-trail record — see `references/precondition-evidence.md` (`execute-tests`) / "Precondition Evidence Check" (`test-ticket`) |
| **Extended cases added after Human review** | When a human reviewer says cases or validations are missing (`/generating-test-cases <KEY> --extend`, or `add` at Gate 1), Claude answers each one first — **accepted**, **already covered by TC_xx**, or **declined** with a reason (the human can `insist <n>`). Accepted cases are never merged silently: they go into a separate section of the same Jira comment with a line such as `Claude generated 12 · Human requested 4 (accepted 2, already covered 1, declined 1, added on request 0) · Miss rate 14% (2/14)`. The numbers are computed by `extend-tc-comment.js` and re-checked by the post/update validators, so they cannot be typed wrongly. The extended cases are executed with the rest, and `run-metrics.js summarize` adds up the miss rate across runs |
| **Developer QA template** | Phase 1 step 3l — parses the developer's "For QA:" comment (Major Impact, Main Tests, Concerns, Additional Notes) into `story.dev_qa`, following a "re-test this QA template: <link>" or "requirements found in <link>" pointer one hop. Major Impact: Yes raises Low TCs to Medium; developer Main Tests bullets no TC covers are listed at Gate 1 (never auto-added); Concerns this run did not cover are reported in the Final Summary. Refreshed on every pass because the comment can land after the TCs were generated |
| **Ticket videos (Bug tickets only)** | Phase 1 step 3o — a Bug with an attached screen recording: Claude asks once (`Read it` / `Skip`), then reads it through `/global:analyzing-videos` (needs ffmpeg; the frames are read locally, nothing is uploaded) and adds the repro steps to the ticket context; Phase 2 then adds a TC that replays them. Other issue types are never asked. A Loom link cannot be read automatically — the Final Summary tells you to download it and run `/global:analyzing-videos <file>`. Skipped with `--unattended`; a missing `global` plugin or ffmpeg only skips the video, never the run |
| **Sub-task keys** | Phase 1 — `/test-ticket <SUBTASK-KEY>` tests the sub-task's own scope under its parent: TCs, results and the `QA_Pipeline` label go on the parent ticket (the parent's ACs are context only, uncovered ones show as coverage gaps) and no status changes. If the parent already carries pipeline comments from another run, the sub-task is tested under its own key instead |
| **Live progress per TC** | Phase 3a / `/execute-tests` — after every TC the running table (`TC \| Result \| Time taken \| Pending`, one row per TC finished so far, so it grows by one row each time, e.g. `TC_01 \| PASS ✅ \| 3m \| 25`), a reason line under the table for each FAIL / BLOCKED / NEEDS REVIEW / SKIP, then a tally line after the last one. Time taken comes from `run-timing.js tc-start` / `tc-end`, not from an estimate: pauses are subtracted in `/test-ticket`, `/execute-tests` shows wall-clock time. The session's task list follows the phases and the TC count |
| **Control Discovery** | Before a TC is `BLOCKED` for "no matching control", the pipeline searches the UI: the screens of the thing the step acts on (reservation → unit → status), the step's own words, the module that owns the object — at most 10 snapshots or 5 minutes, and a found path is reused by later TCs. A BLOCKED reason lists every place that was checked, and the run metrics count it as `control_not_found`. It never asks the tester "how do I do X" first (and never with `--unattended`) |
| **Missing-field API cross-check** | When a field that should be shown is absent from the UI, the final attempt reads the screen's API response and writes into the Actual Result whether the key is sent but not shown (frontend) or not sent (backend, a feature flag or a permission). Never a value from the response; the verdict stays FAIL |
| **Short browser calls** | Every `browser_evaluate` call is at most 60 seconds and bounds itself; waits such as the Supplier import / Reseller export job (15-minute cap) are repeated short calls, so the per-TC timeout and the progress list keep working between calls |
| **Change-type TC groups** | Phase 1 step 3m + Phase 2 — `i18n` (raw translation-key check, second locale, EN fallback), `api_only` (response structure, 401/403, consumer screen), `multi_repo` (end-to-end across services), `widget` (admin config → front end, shared-widget regression) each add their own mandatory TC group when the ticket shows that signal; part of the Phase 2 self-check |
| **Ticket images** | Phase 1 step 3n — when an attached image is the only statement of expected behaviour, reads it at full resolution (Jira media URL `width=1920`); optional and fail-open |
| **Host Guard** | Pre-flight and every navigation — standalone `/execute-tests` gets the same dev/test hard stop as `/test-ticket`, and the browser is re-checked after every navigation/redirect. A host that is not `*-dev` / `*-test` (e.g. a Login button that opens a production hostname) stops interaction and ends the TC `BLOCKED (browser left dev/test)`, never FAIL. A third-party hop the TC itself names is allowed for that step only — see `execute-tests/references/host-guard.md` |
| **Evidence Review** | After Phase 3a — one batched reviewer subagent (paths only, no shared reasoning) checks the screenshots behind every High-risk PASS (max 15 TCs): control named but not visible, empty result taken as proof, last image stops before the outcome, log/token in the image. It can only downgrade PASS → NEEDS REVIEW; a reviewer failure keeps the PASS and is reported, never counted as a pass. Also the positive-control rule: no PASS on a negative assertion without the positive state shown first. `--skip-review` to turn off |
| **Environment-Down Check** | Read-only Slack lookup of the Oracle Bot patch status in `#guild-development` (a fixed channel, no config value). A `:x:` for the concern in the last 24 h makes a failed health check say so, and keeps triage from proposing product defects when half or more of a story's TCs failed. `:warning:` is never a failure; no Slack connector or no read access to the channel → silently skipped |
| **Run Metrics** | Local-only `test-output/<EPIC_ID>/run-metrics.json` per run — phases and durations, BLOCKED reasons by bucket, friction events, TC counts, pauses (how often and how long the tester was away). Never records code, TC text, URLs, hostnames, Jira keys, paths, customer data or secrets; opt out with `QA_ENGINEER_METRICS=off`. Summarise runs you collected with `node skills/test-ticket/scripts/run-metrics.js summarize <dir>...` |
| **Integration Manager Setup** | Phase 3a — Supplier/Reseller (Integration Manager) tickets get dedicated per-integration test-credential handling (`manage-integration-credentials.js`, never reads/prints values), test setup (IDs, link/unlink), a poll-until-done wait for variable-duration import/export jobs, and cross-module verification. Verifying data on a third-party client portal (Booking.com Extranet, Airbnb Developer Portal, etc.) is a **permanent scope boundary** — those TCs are `BLOCKED`, not attempted — see `references/integration-manager-setup.md` (`execute-tests`) / "Integration Manager Setup" (`test-ticket`) |

## Process Integration

| | |
|---|---|
| **Entry criteria** | Story status is `Ready for QA` + test case comment exists on the story |
| **Exit criteria** | Pass rate ≥ 80% AND no open P1/P2 defects from this run |
| **Definition of Done** | `/test-ticket` run complete + results comment posted on Jira story = "QA tested" |
| **Owner** | QA Engineer assigned on the Jira story |
| **Accountable** | QA Lead — approves triage classification, signs off on exit criteria |
| **Consulted** | Developer (tooling-misread disputes), Product Owner (requirements gaps) |
| **Informed** | Scrum Master, Squad Lead (via Slack notification) |
| **Sprint ceremony** | Run during QA phase after dev sign-off; results shared in sprint review |
| **Defect dispute** | If dev disagrees with a raised defect → QA Lead makes final call on tooling misread vs product defect |
| **Partial runs** | If completeness < 80% → QA Lead decides whether to accept partial results or block story |

> **This plugin is a tool, not a substitute for QA judgment.** NEEDS REVIEW verdicts, triage classifications, and defect proposals all require explicit human confirmation before any action is taken.

---

## Prerequisites

### Install at user scope (do this first)

```
/plugin install qa-engineer@maxxton-marketplace --scope user
```

**Use `--scope user`, not the default/project/local scope.** A user-scope install is available in *every* repo on your machine automatically — no per-repo setup. A project- or local-scope install only covers the one repo it was run from; running `/test-ticket` from any other repo will fail with "Playwright MCP tools not available" even though the plugin itself is fine. If you already installed at the wrong scope, re-run the command above — it's a one-time fix, not something to repeat per repo. Check your current scope any time with `/plugin list`.

### MCP Connectors (set up via claude.ai account)

| Connector | Used by | Required for |
|---|---|---|
| Atlassian | All skills | Jira and Confluence read/write |
| Maxxton Knowledge | `/test-ticket`, `/analyzing-impact` | Cross-module impact analysis via technical graph (`get_service_overview`, `get_call_chain`, `get_entity_usage`, `search_technical_graph`). `/test-ticket` checks at preflight and asks you to connect it if it is missing (the run continues without it) |
| Slack | `/test-ticket`, `/triage-defect` | Optional — defect/run-complete notifications (`slack_channel`), feedback collection (`feedback_canvas_id`, `feedback_slack_channel`), Cross-Module Impact broadcast (`impact_slack_channel`), and the read-only Environment-Down Check (fixed channel `#guild-development`, no config value; skipped when the connector or read access is missing). Leave the relevant config value blank to skip the other features without needing this connector |

### Auto-approve Playwright tool calls (recommended)

By default, Claude Code asks for permission before every browser tool call (click, navigate, fill, etc.). This pauses execution — if you miss the prompt, the run stalls. To auto-approve all Playwright tools for this plugin, add to `~/.claude/settings.json`:

```json
{
  "permissions": {
    "allow": [
      "mcp__plugin_qa-engineer_playwright__*"
    ]
  }
}
```

If the file already exists, merge the `allow` array — don't overwrite the whole file. This setting is global (all projects) and only covers the plugin's bundled Playwright MCP; it does not auto-approve Jira write operations.

### Parallel execution (automatic)

`/execute-tests` and `/test-ticket` share the test cases out over two browsers on their own when that pays off; `--workers=1` turns it off:

1. The coordinator session does the setup as usual (login, preconditions, test data, feature flags), saves the login, and sorts each test case into **run alone** (feature flags, permissions, user settings, whole-list checks such as counts or availability), **stay together** (changes the same shared record or pool) or **free**. `skills/test-ticket/scripts/parallel-split.js` balances them over the workers.
2. Two worker agents run their share, each on its own browser: worker 1 is the coordinator's own browser, worker 2 an isolated one. The coordinator saves its session cookies to a file outside the repository and worker 2 loads that file. Workers make one attempt per test case and never touch flags or permissions. If worker 2's browser is closed it comes back empty; the worker restores the login once and goes on, and the cut-off test case is re-run alone.
3. The coordinator re-runs alone every FAIL, NEEDS REVIEW, data-related BLOCKED and unfinished test case, and every PASS that overlapped in time with another worker changing data it reads. The solo result is the final one. Then the usual gates, one results comment.

The extra browser is the `playwright-w2` server in `.mcp.json`. It runs `npx @playwright/mcp@latest --isolated`, the one command Maxxton's managed MCP allowlist permits for a second Playwright server in a plugin: a server whose command is not on that list is dropped without any message, which is why the bundled launcher cannot supply it, and a second server with the same command is dropped as a duplicate, which is why there is no third browser. It costs about 112 MB while idle and opens Chrome only when its first tool is called. Chrome windows are visible by default, so leave them alone during a run. Full procedure: `skills/execute-tests/references/parallel-execution.md`.

Test cases that change the user's own settings (a saved Card/Table view, language, saved filters) are kept per user by the app, so two browsers on one login would overwrite each other's setting. They are classed `user_scoped` and run one after another. When that is the only thing holding a run back, the pipeline says so and asks for a second login: the same site with another test user, or another environment's URL. A browser opens for worker 2, you sign in, reply `done`, and the test cases are split over both users. On another environment worker 2 works with that tenant's data and flags, so only a PASS stands, anything else is re-run alone in the main session, and the kept test cases say `(ran on <host>)` in the Actual Result. `--unattended` and `--workers=1` skip the offer.

While the workers run, the main session prints the running table live: the coordinator watches `parallel-split.js progress … --watch` through Monitor and, on each finished test case, prints the table with one more row (`TC | Worker | Result | Time taken | Pending`) and the reason under the table for every verdict that is not a PASS. It starts Step 6 only once every worker has reported (or is silent for 10 minutes). The same table can be watched in a second terminal: `node skills/test-ticket/scripts/parallel-split.js progress test-output/<STORY_KEY>/parallel --watch`.

When a run ends (after the feature flag teardown, which still needs the browser), the pipeline closes the Playwright browsers it opened: the session's own and the second worker browser. It closes only those browsers and never ends Chrome processes, so your own Chrome windows stay as they are.

### Playwright MCP — First-time Setup

The plugin bundles Playwright MCP via `.mcp.json` — **no separate Playwright install, no browser download.** The server is started by `mcp/run-playwright.js` through `node`, and drives your system's existing Google Chrome.

The only two requirements are things you already have:

- **Node.js** — already required by the rest of the plugin. `node` is the one command that is spawnable on every platform, which is why the launcher is a Node script rather than a shell one-liner.
- **Google Chrome** — the server drives your real Chrome install. If it's missing, get it from [google.com/chrome](https://www.google.com/chrome/).

There is **nothing to pre-install**, and **Git Bash is not required** (an earlier version launched the server via `bash -c` and broke on any Windows machine without `bash` on `PATH` — that is fixed).

Optional, and worth doing once — it makes server startup instant and removes the network from the path entirely:

```bash
node "<plugin root>/mcp/run-playwright.js" --install
```

#### If Playwright tools are missing or all TCs come back BLOCKED

Don't reinstall anything yet. Run the diagnostic — it reports the actual cause for your machine and this repo:

```bash
node "<plugin root>/mcp/run-playwright.js" --doctor
```

It prints whether Node can reach the server package, whether Chrome was found, where this repo's Chrome profile lives, whether anything is holding its lock, and exits `1` with a `BLOCKERS` section when a real dependency is missing. Then:

1. **Blockers listed** → fix those. They're concrete (Chrome not installed, Node install broken).
2. **"No blockers found"** → your environment is fine and the session just hasn't picked the server up. **Fully quit and reopen Claude Code** — not "reload window". MCP tool lists are built once at session start and never refresh mid-session, so retrying in the same session cannot work.
3. **Script not found** → your installed plugin predates this fix. Run `/plugin` → update the marketplace, then `/plugin install qa-engineer@maxxton-marketplace --scope user`.
4. **Still missing after a full restart, or "Script not found" persists after reinstalling** → `--doctor` only checks Chrome/Node; it has no visibility into whether the plugin itself loaded the version you think it did. Run the plugin-manager-level check instead:
   ```
   node "<plugin root>/mcp/check-registration.js"
   ```
   This reports two things `--doctor` can't see: (a) a **name collision** — a second `qa-engineer` registered from another source (most often a claude.ai-account-synced one, shown as `qa-engineer@synced`) that wins over `qa-engineer@maxxton-marketplace` and has no bundled Playwright MCP; and (b) a **stale cache** — the user-scope install exists but the cached copy predates `mcp/run-playwright.js` (or a fix inside it). Add `--fix` to see exactly what it would disable/reinstall — this is a dry run, it changes nothing yet:
   ```
   node "<plugin root>/mcp/check-registration.js" --fix
   ```
   Add `--yes` once you're happy with the plan to actually apply it — disable colliding sources and re-run the marketplace-update + reinstall:
   ```
   node "<plugin root>/mcp/check-registration.js" --fix --yes
   ```
   It only ever calls the `claude` CLI to change state (`plugin disable`, `plugin marketplace update`, `plugin install`) — it never hand-edits `installed_plugins.json` or deletes anything from disk. A claude.ai-synced collision can only be *disabled* locally; fully removing it needs claude.ai → Settings → Plugins, otherwise account-level sync can re-enable it later.

> **You can also just use your own Playwright MCP — if it's named `playwright` or `playwright-headed`.** `/test-ticket`, `/execute-tests` and `/generate-playwright-tests` will run on `mcp__playwright__*` or `mcp__playwright-headed__*` when the bundled server is absent — both are the same `@playwright/mcp` server, and both are pre-listed in the skills' `allowed-tools`. The run notes which one it used so you still know the bundled one needs fixing. A server registered under any other name won't be picked up — a tool call under a prefix that isn't in a skill's `allowed-tools` is silently rejected, not routed — so rename it to one of the two above, or add its tool names to the relevant `SKILL.md` yourself.

#### Browser profile and screenshot output

- **Chrome profile:** `~/.claude/qa-engineer/pw-profiles/<repo>-<hash>` — one per repo, so your login persists between runs but two repos never fight over the same lock. (Earlier versions pinned every repo and every concurrent session to a single `~/.playwright-mcp-profile`, which is what produced `Browser is already in use for …`. After updating you'll log in once more; the old directory is no longer used and can be deleted.)
- **Locked profile:** the launcher sorts this out at startup instead of failing mid-run, and it never kills a process to do it. A lock file with no live owner is cleared — that's deleting an inert leftover, not touching anything running. A profile actively held by *any* process — an orphan from a crashed session or a genuinely live second session, deliberately not distinguished — is left alone: this session starts `--isolated` instead. If this repo has a saved login (see below), the isolated session starts already authenticated, so testing a second ticket in a second Claude Code session against the same repo just works — no login prompt, no risk to the first session's browser.
- **Saved login:** right after you log in, `/execute-tests` and `/test-ticket` save your session (cookies + localStorage) to `storage-state.json` inside `<repo>/.playwright-mcp/` via the `browser_storage_state` tool — not inside the Chrome profile directory above, because that tool can only write inside the server's own allowed roots (the cwd and `--output-dir`), and the profile directory is outside those. This is what lets a parallel run skip the login prompt. `node "$CLAUDE_PLUGIN_ROOT/mcp/run-playwright.js" --storage-state-path` prints the exact file; `--doctor` reports whether it currently exists.
- **Screenshots:** written to `<repo>/.playwright-mcp/` (already git-ignored), pinned via `--output-dir` so the upload step always finds them.

Override any of it from the `env` block in your `~/.claude/settings.json`:

| Variable | Use |
|---|---|
| `QA_ENGINEER_PLAYWRIGHT_CHROME_PATH` | Path to `chrome`, for a portable or org-managed install the doctor can't find |
| `QA_ENGINEER_PLAYWRIGHT_PROFILE_DIR` | Pin the Chrome profile somewhere else |
| `QA_ENGINEER_PLAYWRIGHT_OUTPUT_DIR` | Pin the screenshot/trace output directory |
| `QA_ENGINEER_PLAYWRIGHT_MCP_SPEC` | Run a different server version (e.g. `@playwright/mcp@latest`) |
| `QA_ENGINEER_PLAYWRIGHT_EXTRA_ARGS` | Extra server flags, e.g. `--headless` or `--isolated` |
| `QA_ENGINEER_PLAYWRIGHT_NO_RECLAIM` | Always use the persistent profile as-is, skipping the lock check entirely |

### Permissions required

- Jira: read issues, write comments, edit labels, create bugs
- Confluence: read pages (for LLD/HLD docs)
- Slack (optional): send messages, read/update a Canvas — only needed if you configure `slack_channel`, `feedback_canvas_id`, `feedback_slack_channel`, or `impact_slack_channel`

## Generated Output

For each story, `/test-ticket` produces:

- **Jira comment (Phase 2)** — 10-column test case table (`TC_ID | Scenario | Preconditions | Steps | Expected Result | Actual Result | Story | Epic | Automate | Risk`)
- **Jira label** — `HL-Scenarios_Covered` applied automatically
- **Jira results comment (Phase 3b)** — summary table (Build/Version, pass/fail counts, **Test Execution Timing**) + 6-column TC results table (`TC_ID | Scenario | Expected Result | Actual Result | Status | Test Proof`); FAIL/BLOCKED rows get sanitized console/network evidence appended under the screenshot when a corroborating cause was found. **Test Execution Timing** is always a number — the pipeline's active time, with tester pauses left out: `42m`, `1h 12m`, or `38m (2 pauses)` when the tester was away. A pause is a Session Recovery wait or a gap of more than 10 minutes before the run was resumed; only `N/A (generation only)` replaces the number, when no test was executed. The other numbers the dashboard reads (Total TCs, Passed, Failed, Blocked, Needs Review, Skipped, QA Pipeline Version) must be plain too — explanations go in Preconditions. The validators enforce both, and on the Atlassian-connector write path a `PreToolUse` hook (`hooks/guard-results-comment.js`) denies a results comment that breaks them. A comment split into parts (more than 45 rows) repeats the same Concern, Build / Version and Timing in every part, and the final reconcile checks it
- **Playwright spec file** — `import { test, expect } from '#mxts-test'`; mandatory `test.step()` blocks; real selectors from execution; tags `[@module @submenu]`. Skipped per-TC when a spec already exists in `target_repo` (duplicate automation check, before Gate 2 in Phase 2) — that TC still shows `Automate = Yes` since it genuinely is automated, just not by a new spec this run.
- **Jira Bug tickets** — one per confirmed product defect (proposed for confirmation before filing), each tagged `QA_Pipeline_Bug` (in addition to its dedup label) so pipeline-raised defects are identifiable for usage tracking
- **GitHub draft PR (Phase 6)** — spec files pushed to `MaxxtonGroup/mxts-qa-automation`, or `MaxxtonGroup/mcms-qa-automation` for MCMS/CMS URLs (hostname contains `cms`, e.g. `krm-cms-test.maxxton.net`) — see "Target repo detection" in `SKILL.md` — as a **draft** PR, always (not user-configurable); runs automatically once you've opted into spec generation — there's no separate PR confirmation, since a draft PR can't be merged without review anyway
- **Jira label + draft-PR-link comment (Phase 6)** — `QA_Pipeline_Automation` applied and the draft PR URL commented on the story once it's open, distinct from the `QA_Pipeline` label applied in Phase 3b on local spec generation alone
- **Feedback entry** — the pipeline always asks for feedback (the answer itself is optional) once per test cycle: right after the results comment and `QA_Pipeline` label are posted (end of Phase 3b, skipped for `--unattended`), and again at any later point where it has not been asked yet — when the ticket completes, is stopped, errors, or reaches the Final Summary. The answer is saved to `run-state.json` first, then posted automatically (no confirmation — answering the prompt is itself the opt-in) to a shared Slack Canvas as a checkbox line (Slack user, date, feedback text, ticket and outcome) and, when `feedback_slack_channel` is set, as a formatted message in that channel (`#qa-all`); configure `feedback_canvas_id` (and `feedback_slack_channel`) in the skill's Configuration block, or leave `feedback_canvas_id` blank to disable. The canvas entry and the channel message are always sent together; a post that failed is finished at the next start. A closed, killed or cleared session cannot ask at that instant, so the next `/test-ticket` run asks about it first (outcome `interrupted`). See "Feedback Collection" in `SKILL.md`.
- **Cross-Module Impact broadcast (optional)** — after Phase 2.5 runs, the impact table is posted automatically (no confirmation) to `impact_slack_channel`; configure it in the skill's Configuration block, or leave it blank to disable. See "Slack posting" under Phase 2.5 in `SKILL.md`.

Available on demand (manual invocation):
- **`/generate-reports`** — Confluence page, DOCX content, PPT deck script
- **`/review-pr`** — spec file quality check (selector quality, TC coverage, structure)

## Playwright Spec Conventions

- Source of truth: the target repo's own `CLAUDE.md`, `TEST_WRITING_REFERENCE_MAIN.md` and module reference file, read fresh from the latest `origin/develop` on every `/generate-playwright-tests` run (Step 4) — this list is only a summary
- Language: JavaScript (`import { test, expect } from '#mxts-test'`)
- Selectors: `getByRole()` → `getByLabel()` → `getByText()` → `getByTestId()` → simple CSS as a last resort, each one verified in the live app
- Steps: `test.step()` for every logical group of actions
- Tags: `[@module @submodule]` inside the test name — both mandatory, `@regression` optional
- Target path: `tests/modules/<module>/<sub_menu>/<feature>/<name>.spec.js` (descriptive snake_case name)
- Test data: `randomString()` from `#utils/account-data`; burn-in is 5 clean passes

## Staying Up To Date

A `SessionStart` hook (`hooks/session-start.sh`) checks once a day whether your installed `qa-engineer` version is behind the version published on this repo's `main` branch — via `git fetch`/`git show` against your own local checkout of this repo (the marketplace repo is private, so an unauthenticated fetch would 404; this reuses whatever git credentials already got the plugin installed). If you're behind, you'll see a message at session start telling you the current/latest version and how to update (`/plugin` → Marketplace → update `qa-engineer`). Purely informational — it never blocks session start, and any network hiccup fails silently.

A second hook (`hooks/resume-reminder.sh`, `SessionStart` matcher `resume`) fires only when a session is resumed: if its transcript is over 2 MB it tells Claude to offer `/clear` and the exact `/test-ticket <EPIC> <URL> --from=<phase>` command (all pipeline state is on disk in `test-output/<EPIC_ID>/run-state.json`, so nothing is lost). It only offers; it never clears anything. Threshold override: `QA_ENGINEER_RESUME_REMINDER_MIN_BYTES`; turn off with `QA_ENGINEER_RESUME_REMINDER=off`.

## Known Limitations

- **Run metrics are local.** Nothing is sent anywhere; to get team-wide numbers, collect the `run-metrics.json` files by hand. `execution_mode` is always `inline` — running each TC in a subagent is an experiment that has to be measured (same Epic, both modes, `summarize`) before it ships.
- **Environment-Down Check needs Slack read access** to `#guild-development`; without it the check is skipped and nothing else changes.

- `execute-tests` and `/test-ticket` run test steps via Playwright MCP — they cannot run compiled `.spec.js` files directly; generated spec files are for CI use. If you see `BLOCKED (Playwright MCP server unavailable)` on all TCs, run `node "<plugin root>/mcp/run-playwright.js" --doctor` (see [Playwright MCP — First-time Setup](#playwright-mcp--first-time-setup)), fix whatever it names, fully quit and reopen Claude Code, then re-run with `--from=phase3a`.
- BLOCKED tests (missing precondition data) must be set up manually in the target environment before re-running
- **Login required before Phase 3a** — `/test-ticket` detects browser sessions automatically per tab; only prompts for tabs that are not logged in. Log in to the primary app before running; cross-module apps are checked silently
- **Jira comment corrections go through the scripts** — `update-comment.js` / `update-tc-comment.js` (or `addOrEditJiraIssueComment` with `commentId` on the MCP-fallback path) fix a pipeline comment in place; the pipeline never posts a second superseding copy
- Screenshots from `execute-tests` are saved locally under `test-output/<STORY_KEY>/<TC_ID>-*.png` — not committed anywhere
- **Network inspection test cases** — Supported via `browser_network_requests` (intercept calls triggered by UI actions) and `browser_evaluate` (direct authenticated fetch). Not BLOCKED — see `execute-tests` API validation patterns.
- **Phase 5 data integrity gate** — if execution completeness is below 60%, defect filing is suppressed to avoid raising false positives from a degraded run; use `--min-completeness=N` to adjust
- **Reseller external-portal validation is out of scope, permanently** — verifying an export landed correctly on a client's own portal (Booking.com Extranet, Airbnb Developer Portal, etc.) requires a live session into a third-party system this pipeline has no access to. Those TCs are `BLOCKED` with an explicit reason, never attempted or guessed at. The internal half of the same ticket (setup → import/export → cross-module verification within Maxxton's own apps) is in scope — see "Integration Manager Setup" in `test-ticket`'s Phase 3a reference
- **Jira writes need no token.** If `JIRA_EMAIL` / `JIRA_API_TOKEN` are in your `~/.claude/settings.json` (or the environment) and Jira accepts them, the pipeline uses its scripts as before. If they are missing, expired or Jira cannot be reached with them, the run silently uses the Atlassian MCP connector instead (comments, labels, transitions, defects, links — and screenshots, uploaded and embedded in the Test Proof column). Nothing is asked of you and nothing has to be set up. The one limit: screenshot upload needs a normal local shell (Claude Code in VS Code, the CLI or the Desktop Code tab). In a cloud/sandboxed session `api.media.atlassian.com` is blocked, so Test Proof carries plain filenames and the run says so under ACTION REQUIRED. Details: `skills/test-ticket/references/jira-mcp-write-path.md`.
- **Supplier/Reseller test credentials are per-integration, not a single fixed pair** — unlike the optional Jira token, each named integration (e.g. MaxxtonLink, Booking.com) gets its own placeholder fields in `~/.claude/settings.json` via `manage-integration-credentials.js`, prompted for on first use per integration
